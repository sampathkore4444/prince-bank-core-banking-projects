CREATE OR REPLACE PACKAGE BODY IFPKS_FAST_INCOMING IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_FAST_INCOMING ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN
  
    SELECT TRSQ_FAST_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    RETURN L_REF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  FUNCTION GET_PARAM_VAL(PNAME VARCHAR2) RETURN VARCHAR2 RESULT_CACHE RELIES_ON(CSTB_PARAM_CUSTOM) IS
    RETVAL VARCHAR2(255);
    CURSOR C(PN VARCHAR2) IS
      SELECT PARAM_VAL FROM CSTB_PARAM_CUSTOM WHERE PARAM_NAME = PN;
  BEGIN
    OPEN C(UPPER(LTRIM(RTRIM(PNAME))));
    FETCH C
      INTO RETVAL;
    CLOSE C;
    DBG('RETVAL=' || RETVAL);
    RETURN RETVAL;
  END GET_PARAM_VAL;

  FUNCTION FN_RETURN_INCOMING_MSG RETURN CLOB IS
    L_FORMATTED_MSG CLOB;
  BEGIN
    DBG('SATRT OF FN_RETURN_INCOMING_MSG');
  
    L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fas="http://fastwebservice.nbc.org.kh/">
   <soapenv:Header/>
   <soapenv:Body>
      <fas:getIncomingTransaction>
         <cm_user_name>' ||
                       GET_PARAM_VAL('PGW_OUT_FAST_UID') ||
                       '</cm_user_name>
         <cm_password>' ||
                       GET_PARAM_VAL('PGW_OUT_FAST_PWD') ||
                       '</cm_password>
         <payee_participant_code>PINCKHPPXXXX</payee_participant_code>
      </fas:getIncomingTransaction>
   </soapenv:Body>
</soapenv:Envelope>';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_RETURN_INCOMING_MSG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_INCOMING_MSG');
      DBG('ERROR CODE IN FN_RETURN_INCOMING_MSG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_INCOMING_MSG=' || SQLERRM);
  END FN_RETURN_INCOMING_MSG;

  FUNCTION FN_RETURN_REFUND_MSG RETURN CLOB IS
    L_FORMATTED_MSG CLOB;
  BEGIN
    DBG('SATRT OF FN_RETURN_REFUND_MSG');
  
    /*L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fas="http://fastwebservice.nbc.org.kh/">
       <soapenv:Header/>
       <soapenv:Body>
          <fas:makeReverseTransaction>
             <cm_user_name>' ||
                           GET_PARAM_VAL('PGW_OUT_FAST_UID') ||
                           '</cm_user_name>
             <cm_password>' ||
                           GET_PARAM_VAL('PGW_OUT_FAST_PWD') ||
                           '</cm_password>
             <content_message><![CDATA[<?xml version="1.0" encoding="utf-16"?>
    <Document xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.007.001.05">
      <CstmrPmtRvsl>
        <GrpHdr>
          <MsgId>$L_MSG_ID</MsgId>
          <CreDtTm>$L_CREDTTM</CreDtTm>
          <NbOfTxs>1</NbOfTxs>
          <InitgPty>
            <Nm>$L_INITGPTY_NM</Nm>
            <PstlAdr>
              <StrtNm></StrtNm>
              <BldgNb></BldgNb>
              <PstCd></PstCd>
              <TwnNm></TwnNm>
              <Ctry></Ctry>
            </PstlAdr>
          </InitgPty>
          <DbtrAgt>
            <FinInstnId>
              <BICFI>$L_CRTRAGT_BICFI</BICFI>
            </FinInstnId>
          </DbtrAgt>
          <CdtrAgt>
            <FinInstnId>
              <BICFI>$L_DBTRAGT_BICFI</BICFI>
            </FinInstnId>
          </CdtrAgt>
        </GrpHdr>
        <OrgnlGrpInf>
          <OrgnlMsgId>$L_MSG_ID</OrgnlMsgId>
          <OrgnlMsgNmId>pacs.003.001.04</OrgnlMsgNmId>
          <OrgnlCreDtTm>$L_CREDTTM</OrgnlCreDtTm>
        </OrgnlGrpInf>
        <OrgnlPmtInfAndRvsl>
          <OrgnlPmtInfId>$L_PMTINFID</OrgnlPmtInfId>
          <TxInf>
            <RvslId>Reversal001</RvslId>
            <OrgnlEndToEndId>$L_ENDTOENDID</OrgnlEndToEndId>
            <OrgnlInstdAmt Ccy="KHR">$L_AMT</OrgnlInstdAmt>
            <RvsdInstdAmt Ccy="KHR">$L_AMT</RvsdInstdAmt>
            <RvslRsnInf>
              <Orgtr>
                <Nm>SYSTEM</Nm>
                <PstlAdr>
                  <StrtNm></StrtNm>
                  <BldgNb></BldgNb>
                  <PstCd></PstCd>
                  <TwnNm></TwnNm>
                  <Ctry></Ctry>
                </PstlAdr>
              </Orgtr>
              <Rsn>
                <Cd>AM05</Cd>
              </Rsn>
            </RvslRsnInf>
            <OrgnlTxRef>
              <ReqdExctnDt>' ||
                           TO_CHAR(SYSDATE, 'YYYY-MM-DD') ||
                           '</ReqdExctnDt>
              <Dbtr>
                <Nm>$L_DBTR_NM</Nm>
                <PstlAdr>
                  <StrtNm></StrtNm>
                  <BldgNb></BldgNb>
                  <PstCd></PstCd>
                  <TwnNm></TwnNm>
                  <Ctry></Ctry>
                </PstlAdr>
              </Dbtr>
              <DbtrAcct>
                <Id>
                  <Othr>
                    <Id>$L_DBTRACCT_NO</Id>
                  </Othr>
                </Id>
              </DbtrAcct>
              <Cdtr>
                <Nm>$L_CDTR_NM</Nm>
                <PstlAdr>
                  <StrtNm></StrtNm>
                  <BldgNb></BldgNb>
                  <PstCd></PstCd>
                  <TwnNm></TwnNm>
                  <Ctry></Ctry>
                </PstlAdr>
              </Cdtr>
            </OrgnlTxRef>
          </TxInf>
        </OrgnlPmtInfAndRvsl>
      </CstmrPmtRvsl>
    </Document>]]></content_message>
          </fas:makeReverseTransaction>
       </soapenv:Body>
    </soapenv:Envelope>';*/
  
    L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fas="http://fastwebservice.nbc.org.kh/">
   <soapenv:Header/>
   <soapenv:Body>
      <fas:makeReverseTransaction>
         <cm_user_name>' ||
                       GET_PARAM_VAL('PGW_OUT_FAST_UID') ||
                       '</cm_user_name>
         <cm_password>' ||
                       GET_PARAM_VAL('PGW_OUT_FAST_PWD') ||
                       '</cm_password>
         <content_message><![CDATA[<?xml version="1.0" encoding="utf-16"?>
<Document xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.007.001.05">
  <CstmrPmtRvsl>
    <GrpHdr>
      <MsgId>$L_NEW_MSG_ID</MsgId>
      <CreDtTm>$L_CREDTTM</CreDtTm>
      <NbOfTxs>1</NbOfTxs>
      <InitgPty>
        <Nm>$L_INITGPTY_NM</Nm>

      </InitgPty>
      <DbtrAgt>
        <FinInstnId>
          <BICFI>$L_CRTRAGT_BICFI</BICFI>
        </FinInstnId>
      </DbtrAgt>
      <CdtrAgt>
        <FinInstnId>
          <BICFI>$L_DBTRAGT_BICFI</BICFI>
        </FinInstnId>
      </CdtrAgt>
    </GrpHdr>
    <OrgnlGrpInf>
      <OrgnlMsgId>$L_MSG_ID</OrgnlMsgId>
      <OrgnlMsgNmId>pacs.003.001.04</OrgnlMsgNmId>
      <OrgnlCreDtTm>$L_CREDTTM</OrgnlCreDtTm>
    </OrgnlGrpInf>
    <OrgnlPmtInfAndRvsl>
      <OrgnlPmtInfId>$L_PMTINFID</OrgnlPmtInfId>
      <TxInf>
        <RvslId>Reversal001</RvslId>
        <OrgnlEndToEndId>$L_ENDTOENDID</OrgnlEndToEndId>
        <OrgnlInstdAmt Ccy="KHR">$L_AMT</OrgnlInstdAmt>
        <RvsdInstdAmt Ccy="KHR">$L_AMT</RvsdInstdAmt>
        <RvslRsnInf>
          <Orgtr>
            <Nm>SYSTEM</Nm>

          </Orgtr>
          <Rsn>
            <Cd>AM05</Cd>
          </Rsn>
        </RvslRsnInf>
        <OrgnlTxRef>
          <ReqdExctnDt>' ||
                       TO_CHAR(SYSDATE, 'YYYY-MM-DD') ||
                       '</ReqdExctnDt>
          <Dbtr>
            <Nm>$L_DBTR_NM</Nm>

          </Dbtr>
          <DbtrAcct>
            <Id>
              <Othr>
                <Id>$L_DBTRACCT_NO</Id>
              </Othr>
            </Id>
          </DbtrAcct>
          <Cdtr>
            <Nm>$L_CDTR_NM</Nm>

          </Cdtr>
        </OrgnlTxRef>
      </TxInf>
    </OrgnlPmtInfAndRvsl>
  </CstmrPmtRvsl>
</Document>]]></content_message>
      </fas:makeReverseTransaction>
   </soapenv:Body>
</soapenv:Envelope>';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_RETURN_REFUND_MSG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_REFUND_MSG');
      DBG('ERROR CODE IN FN_RETURN_REFUND_MSG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_REFUND_MSG=' || SQLERRM);
  END FN_RETURN_REFUND_MSG;

  FUNCTION FN_RETURN_ACK_MSG RETURN CLOB IS
    L_FORMATTED_MSG CLOB;
  BEGIN
    DBG('SATRT OF FN_RETURN_ACK_MSG');
  
    L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fas="http://fastwebservice.nbc.org.kh/">
   <soapenv:Header/>
   <soapenv:Body>
      <fas:makeAcknowledgment>
         <cm_user_name>' ||
                       GET_PARAM_VAL('PGW_OUT_FAST_UID') ||
                       '</cm_user_name>
         <cm_password>' ||
                       GET_PARAM_VAL('PGW_OUT_FAST_PWD') ||
                       '</cm_password>
         <content_message><![CDATA[<?xml version="1.0" encoding="utf-16"?>
<Document xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.06">
  <CstmrPmtStsRpt>
    <GrpHdr>
      <MsgId>$L_MSG_ID</MsgId>
      <CreDtTm>$L_CREDTTM</CreDtTm>
      <InitgPty>
        <Nm>$L_INITGPTY_NM</Nm>

      </InitgPty>
      <DbtrAgt>
        <FinInstnId>
          <BICFI>$L_DBTRAGT_BICFI</BICFI>
        </FinInstnId>
      </DbtrAgt>
      <CdtrAgt>
        <FinInstnId>
          <BICFI>$L_CRTRAGT_BICFI</BICFI>
        </FinInstnId>
      </CdtrAgt>
    </GrpHdr>
    <OrgnlGrpInfAndSts>
      <OrgnlMsgId>$L_MSG_ID</OrgnlMsgId>
      <OrgnlMsgNmId>pacs.003.001.04</OrgnlMsgNmId>
      <OrgnlCreDtTm>$L_CREDTTM</OrgnlCreDtTm>
    </OrgnlGrpInfAndSts>
    <OrgnlPmtInfAndSts>
      <OrgnlPmtInfId>$L_PMTINFID</OrgnlPmtInfId>
      <TxInfAndSts>
        <OrgnlEndToEndId>$L_ENDTOENDID</OrgnlEndToEndId>
        <TxSts>ACSC</TxSts>
        <OrgnlTxRef>
          <Amt>
            <InstdAmt Ccy="KHR">$L_AMT</InstdAmt>
          </Amt>
          <Dbtr>
            <Nm>$L_DBTR_NM</Nm>

          </Dbtr>
          <Cdtr>
            <Nm>$L_CDTR_NM</Nm>

          </Cdtr>
        </OrgnlTxRef>
      </TxInfAndSts>
    </OrgnlPmtInfAndSts>
  </CstmrPmtStsRpt>
</Document>]]></content_message>
      </fas:makeAcknowledgment>
   </soapenv:Body>
</soapenv:Envelope>';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_RETURN_ACK_MSG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_ACK_MSG');
      DBG('ERROR CODE IN FN_RETURN_ACK_MSG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_ACK_MSG=' || SQLERRM);
  END FN_RETURN_ACK_MSG;

  FUNCTION FN_RETURN_DOCUMENT(P_CLOB IN CLOB) RETURN CLOB IS
    L_START    NUMBER := 1;
    L_END      NUMBER := 0;
    L_DOCUMENT CLOB;
  BEGIN
  
    --PR_RETURN_COSMETIC_XML(P_CLOB,L_DOCUMENT);
  
    L_START := INSTR(P_CLOB, '<Document ', l_start, 1);
    L_END   := INSTR(P_CLOB, '</Document>', l_start, 1);
  
    L_DOCUMENT := SUBSTR(P_CLOB,
                         L_START,
                         L_END - L_START + LENGTH('</Document>'));
  
    DBG('L_DOCUMENT=' || L_DOCUMENT);
  
    RETURN L_DOCUMENT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING DOCUMENT');
      DBG('ERROR CODE IN FN_RETURN_DOCUMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_DOCUMENT=' || SQLERRM);
    
  END FN_RETURN_DOCUMENT;

  PROCEDURE PR_INSERT_DOC_TRACKER(P_DOCUMENT IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_MSG_ID           IFTBS_FAST_MASTER.MSG_ID%TYPE;
    L_COUNT            NUMBER;
  BEGIN
    DBG('BEFORE START OF PR_INSERT_DOC_TRACKER');
  
    PR_RETURN_COSMETIC_XML(P_DOCUMENT, L_COSMETIC_RES_MSG);
  
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
  
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
  
    L_MSG_ID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/MsgId/text()')
                .GETSTRINGVAL;
  
    --Check if above MSG ID already available
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
        FROM IFTBS_FAST_INCOMING_TRACK
       WHERE MSG_ID = L_MSG_ID;
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT := 0;
    END;
  
    IF L_COUNT = 0 THEN
      INSERT INTO IFTBS_FAST_INCOMING_TRACK
        (MSG_ID, INC_REQ_MSG, STATUS, TIME_IN)
      VALUES
        (L_MSG_ID, P_DOCUMENT, 'U', SYSDATE);
    END IF;
  
    DBG('AFTER INSERTING INTO PR_INSERT_DOC_TRACKER');
    DBG('COMMITTING');
    COMMIT;
    DBG('RETURNING SUCCESSFULLY FROM PR_INSERT_DOC_TRACKER');
  
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      DBG('DUPLICATE DOCUMENT FOUND....SO NOT ISERTING INTO IFTBS_FAST_INCOMING_TRACK');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
    WHEN OTHERS THEN
      DBG('FAILED WHILE INERTING INTO PR_INSERT_DOCUMENT');
      DBG('ERROR CODE IN PR_INSERT_DOCUMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_DOCUMENT=' || SQLERRM);
    
  END PR_INSERT_DOC_TRACKER;

  PROCEDURE PR_UPDATE_DOC_TRACKER(P_MSG_ID   IN IFTB_FAST_MASTER.MSG_ID%TYPE,
                                  P_STATUS   IN IFTB_FAST_INCOMING_TRACK.STATUS%TYPE,
                                  P_ERR_CODE IN ERTB_MSGS.ERR_CODE%TYPE,
                                  P_ERR_MSGS IN ERTB_MSGS.MESSAGE%TYPE) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
    L_MSG_ID IFTBS_FAST_MASTER.MSG_ID%TYPE;
  BEGIN
    DBG('START OF PR_UPDATE_DOC_TRACKER');
  
    UPDATE IFTBS_FAST_INCOMING_TRACK
       SET STATUS     = P_STATUS,
           ERROR_CODE = P_ERR_CODE,
           ERROR_MSG  = P_ERR_MSGS
     WHERE MSG_ID = P_MSG_ID;
    --COMMIT;
  
    DBG('END OF PR_UPDATE_DOC_TRACKER');
  
    DBG('RETURNING SUCCESSFULLY FROM PR_UPDATE_DOC_TRACKER');
  
  EXCEPTION
  
    WHEN OTHERS THEN
      DBG('FAILED WHILE UPDATING INTO PR_UPDATE_DOC_TRACKER');
      DBG('ERROR CODE IN PR_UPDATE_DOC_TRACKER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_DOC_TRACKER=' || SQLERRM);
    
  END PR_UPDATE_DOC_TRACKER;

  PROCEDURE PR_INSERT_FAST_INCOMING(P_SOURCE_CODE      VARCHAR2,
                                    P_BRANCH_CODE      VARCHAR2,
                                    P_MSG_FLOW         VARCHAR2,
                                    P_TRANSFER_MODE    VARCHAR2,
                                    P_TRN_REF_NO       VARCHAR2,
                                    P_PRODUCT_CODE     VARCHAR2,
                                    P_TRANSFER_DATE    DATE,
                                    P_TXN_CCY          VARCHAR2,
                                    P_TXN_AMT          NUMBER,
                                    P_TOT_CHG_AMT      NUMBER,
                                    P_NET_TXN_AMT      NUMBER,
                                    P_EXCH_RATE        NUMBER,
                                    P_TXN_STATUS       VARCHAR2,
                                    P_TXN_REMARKS      VARCHAR2,
                                    P_MSG_ID           VARCHAR2,
                                    P_PAY_ID           VARCHAR2,
                                    P_REM_ACC          VARCHAR2,
                                    P_REM_NAME         VARCHAR2,
                                    P_REM_ADD1         VARCHAR2,
                                    P_REM_ADD2         VARCHAR2,
                                    P_REM_ADD3         VARCHAR2,
                                    P_REM_ADD4         VARCHAR2,
                                    P_BEN_ACC          VARCHAR2,
                                    P_BEN_BIC          VARCHAR2,
                                    P_BEN_NAME         VARCHAR2,
                                    P_BEN_ADD1         VARCHAR2,
                                    P_BEN_ADD2         VARCHAR2,
                                    P_BEN_ADD3         VARCHAR2,
                                    P_BEN_ADD4         VARCHAR2,
                                    P_BEN_REMARKS      VARCHAR2,
                                    P_BEN_PHONE        VARCHAR2,
                                    P_BEN_EMAIL        VARCHAR2,
                                    P_INSTR_ID         VARCHAR2,
                                    P_ETEND_ID         VARCHAR2,
                                    P_MAKER_ID         VARCHAR2,
                                    P_MAKER_DT_STAMP   DATE,
                                    P_CHECKER_ID       VARCHAR2,
                                    P_CHECKER_DT_STAMP DATE,
                                    P_AUTH_STAT        VARCHAR2,
                                    P_RECORD_STAT      VARCHAR2,
                                    P_ONCE_AUTH        VARCHAR2,
                                    P_MOD_NO           NUMBER) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_FAST_INCOMING');
    DBG('BEFORE INSERTING INTO IFTBS_FAST_MASTER');
    INSERT INTO IFTBS_FAST_MASTER
      (SOURCE_CODE,
       BRANCH_CODE,
       MSG_FLOW,
       TRANSFER_MODE,
       TRN_REF_NO,
       PRODUCT_CODE,
       TRANSFER_DATE,
       TXN_CCY,
       TXN_AMT,
       TOT_CHG_AMT,
       NET_TXN_AMT,
       EXCH_RATE,
       TXN_STATUS,
       TXN_REMARKS,
       MSG_ID,
       PAY_ID,
       REM_ACC,
       REM_NAME,
       REM_ADD1,
       REM_ADD2,
       REM_ADD3,
       REM_ADD4,
       BEN_ACC,
       BEN_BIC,
       BEN_NAME,
       BEN_ADD1,
       BEN_ADD2,
       BEN_ADD3,
       BEN_ADD4,
       BEN_REMARKS,
       BEN_PHONE,
       BEN_EMAIL,
       INSTR_ID,
       ETEND_ID,
       MAKER_ID,
       MAKER_DT_STAMP,
       CHECKER_ID,
       CHECKER_DT_STAMP,
       AUTH_STAT,
       RECORD_STAT,
       ONCE_AUTH,
       MOD_NO)
    VALUES
      (P_SOURCE_CODE,
       P_BRANCH_CODE,
       P_MSG_FLOW,
       P_TRANSFER_MODE,
       P_TRN_REF_NO,
       P_PRODUCT_CODE,
       P_TRANSFER_DATE,
       P_TXN_CCY,
       P_TXN_AMT,
       P_TOT_CHG_AMT,
       P_NET_TXN_AMT,
       P_EXCH_RATE,
       P_TXN_STATUS,
       P_TXN_REMARKS,
       P_MSG_ID,
       P_PAY_ID,
       P_REM_ACC,
       P_REM_NAME,
       P_REM_ADD1,
       P_REM_ADD2,
       P_REM_ADD3,
       P_REM_ADD4,
       P_BEN_ACC,
       P_BEN_BIC,
       P_BEN_NAME,
       P_BEN_ADD1,
       P_BEN_ADD2,
       P_BEN_ADD3,
       P_BEN_ADD4,
       P_BEN_REMARKS,
       P_BEN_PHONE,
       P_BEN_EMAIL,
       P_INSTR_ID,
       P_ETEND_ID,
       P_MAKER_ID,
       P_MAKER_DT_STAMP,
       P_CHECKER_ID,
       P_CHECKER_DT_STAMP,
       P_AUTH_STAT,
       P_RECORD_STAT,
       P_ONCE_AUTH,
       P_MOD_NO);
    DBG('AFTER INSERTING INTO IFTBS_FAST_MASTER');
    --COMMIT;
    DBG('END OF PR_INSERT_FAST_INCOMING');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_FAST_WS_LOG');
  END PR_INSERT_FAST_INCOMING;

  PROCEDURE PR_UPDATE_STATUS_FAST_INCOMING(P_TRN_REF_NO IN VARCHAR2,
                                           P_STATUS     IN VARCHAR2) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
    L_TXN_REMARKS IFTBS_FAST_MASTER.TXN_REMARKS%TYPE;
  BEGIN
    DBG('START OF PR_UPDATE_STATUS_FAST_INCOMING');
    DBG('BEFORE UPDATING IFTBS_FAST_MASTER');
  
    --Get Remarks for a status
    BEGIN
      SELECT VALUE
        INTO L_TXN_REMARKS
        FROM LMTM_TYPE_VALUES
       WHERE TYPE = 'FAST_IN_STATUS'
         AND CODE = P_STATUS;
    EXCEPTION
      WHEN OTHERS THEN
        L_TXN_REMARKS := NULL;
    END;
  
    DBG('L_TXN_REMARKS=' || L_TXN_REMARKS);
  
    UPDATE IFTBS_FAST_MASTER
       SET TXN_STATUS = P_STATUS, TXN_REMARKS = L_TXN_REMARKS
     WHERE TRN_REF_NO = P_TRN_REF_NO;
  
    DBG('AFTER UPDATING IFTBS_FAST_MASTER');
    --COMMIT;
    DBG('END OF PR_UPDATE_STATUS_FAST_INCOMING');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_STATUS_FAST_INCOMING');
  END PR_UPDATE_STATUS_FAST_INCOMING;

  PROCEDURE PR_INSERT_FAST_WS_LOG(P_MSG_ID            IN VARCHAR2,
                                  P_SEQ_NO            IN VARCHAR2,
                                  P_TRN_REF_NO        IN VARCHAR2,
                                  P_DATE              IN DATE,
                                  P_REQ_TYPE          IN VARCHAR2,
                                  P_REQ_MSG           IN CLOB,
                                  P_PAY_TYPE          IN CHAR,
                                  P_ACK_REFUND_REASON IN VARCHAR2,
                                  P_ADDL_INFO         IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_FAST_WS_LOG');
    DBG('BEFORE INSERTING INTO STTB_FAST_WS_LOG');
    INSERT INTO STTB_FAST_WS_LOG
      (MSG_ID,
       SEQ_NO,
       TRN_REF_NO,
       INVOKE_DATE,
       REQ_TYPE,
       REQ_MSG,
       PAYMENT_TYPE,
       REFUND_REASON,
       ADDL_INFO)
    VALUES
      (P_MSG_ID,
       P_SEQ_NO,
       P_TRN_REF_NO,
       P_DATE,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_PAY_TYPE,
       P_ACK_REFUND_REASON,
       
       P_ADDL_INFO);
  
    COMMIT;
    DBG('AFTER INSERTING INTO STTB_FAST_WS_LOG');
    DBG('END OF PR_INSERT_FAST_WS_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_FAST_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_FAST_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_FAST_WS_LOG=' || SQLERRM);
    
  END PR_INSERT_FAST_WS_LOG;

  PROCEDURE PR_UPDATE_FAST_WS_SEQ_LOG(P_MSG_ID     IN VARCHAR2,
                                      P_STATUS     IN CHAR,
                                      P_RES_MSG    IN CLOB,
                                      P_TRN_REF_NO IN VARCHAR2) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_FAST_WS_LOG');
    DBG('BEFORE UPDATING STTB_FAST_WS_LOG');
    UPDATE STTB_FAST_WS_LOG
       SET STATUS = P_STATUS, RES_MSG = P_RES_MSG
     WHERE MSG_ID = P_MSG_ID
       AND TRN_REF_NO = P_TRN_REF_NO;
  
    --COMMIT;
    DBG('AFTER UPDATING STTB_FAST_WS_LOG');
    DBG('END OF PR_UPDATE_FAST_WS_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_FAST_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_FAST_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_FAST_WS_LOG=' || SQLERRM);
  END PR_UPDATE_FAST_WS_SEQ_LOG;

  PROCEDURE PR_UPDATE_FAST_WS_LOG(P_MSG_ID  IN VARCHAR2,
                                  P_SEQ_NO  IN VARCHAR2,
                                  P_STATUS  IN CHAR,
                                  P_RES_MSG IN CLOB) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF OVERLOADED PR_UPDATE_FAST_WS_LOG');
    DBG('BEFORE UPDATING STTB_FAST_WS_LOG');
    UPDATE STTB_FAST_WS_LOG
       SET STATUS = P_STATUS, RES_MSG = P_RES_MSG
     WHERE MSG_ID = P_MSG_ID
       AND SEQ_NO = P_SEQ_NO;
    --COMMIT;
    DBG('AFTER UPDATING STTB_FAST_WS_LOG');
    DBG('END OF OVERLOADED PR_UPDATE_FAST_WS_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN OVERLOADED PR_UPDATE_FAST_WS_LOG');
      DBG('ERROR CODE IN OVERLOADED PR_UPDATE_FAST_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN OVERLOADED PR_UPDATE_FAST_WS_LOG=' || SQLERRM);
  END PR_UPDATE_FAST_WS_LOG;

  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_COSMETIC_XML := P_XML;
  
    --This is for Fund Transfer
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xsi:schemaLocation="xsd/pain.001.001.05.xsd" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.05" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"',
                              NULL);
  
    --This is for makeReverse API
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><ns2:makeReverseTransactionResponse xmlns:ns2="http://fastwebservice.nbc.org.kh/"><return><?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                              NULL);
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xsi:schemaLocation="xsd/pain.002.001.06.xsd" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.06" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"',
                              NULL);
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '</return></ns2:makeReverseTransactionResponse></soap:Body></soap:Envelope>',
                              NULL);
  
    --This is for Ack API
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><ns2:makeAcknowledgmentResponse xmlns:ns2="http://fastwebservice.nbc.org.kh/"><return><?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                              NULL);
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '</return></ns2:makeAcknowledgmentResponse></soap:Body></soap:Envelope>',
                              NULL);
  
    --RETURN P_COSMETIC_XML;
  
  END PR_RETURN_COSMETIC_XML;

  PROCEDURE PR_PROCESS_FAST_INCOMING_TXN /*(P_DOCUMENT   IN CLOB,
                                                                                                                                                                                                                                                  P_ERR_CODE   OUT VARCHAR2,
                                                                                                                                                                                                                                                  P_ERR_PARAMS OUT VARCHAR2)*/
   IS
  
    L_MSG_ID      IFTBS_FAST_MASTER.MSG_ID%TYPE;
    L_NEW_MSG_ID  IFTBS_FAST_MASTER.MSG_ID%TYPE;
    L_CREDTTM     VARCHAR2(100);
    L_NBOFTXS     CHAR(1);
    L_CTRLSUM     VARCHAR2(100);
    L_INITGPTY_NM VARCHAR2(100);
  
    L_PMTINFID      VARCHAR2(100);
    L_PMTMTD        VARCHAR2(100);
    L_BTCHBOOKG     VARCHAR2(100);
    L_REQDEXCTNDT   VARCHAR2(100);
    L_DBTR_NM       IFTBS_FAST_MASTER.REM_NAME%TYPE;
    L_DBTRACCT_NO   IFTBS_FAST_MASTER.REM_ACC%TYPE;
    L_DBTRACCT_CCY  IFTBS_FAST_MASTER.TXN_CCY%TYPE;
    L_DBTRAGT_BICFI IFTBS_FAST_MASTER.BEN_BIC%TYPE;
    L_INSTRID       IFTBS_FAST_MASTER.INSTR_ID%TYPE;
    L_ENDTOENDID    IFTBS_FAST_MASTER.ETEND_ID%TYPE;
    L_AMT           IFTBS_FAST_MASTER.TXN_AMT%TYPE;
  
    L_CHRGBR        VARCHAR2(100);
    L_CRTRAGT_BICFI IFTBS_FAST_MASTER.BEN_BIC%TYPE;
    L_CDTR_NM       IFTBS_FAST_MASTER.BEN_NAME%TYPE;
    L_CDTRACCT_NO   IFTBS_FAST_MASTER.BEN_ACC%TYPE;
    L_PURP          IFTBS_FAST_MASTER.TXN_REMARKS%TYPE;
  
    L_TY_RTUPLD             DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC;
    L_IB_FLAG               VARCHAR2(1) DEFAULT 'Y';
    L_ARC_MAINT             IFTMS_ARC_MAINT%ROWTYPE;
    L_CUST_AC               STTM_CUST_ACCOUNT%ROWTYPE;
    L_CUST                  STTM_CUSTOMER%ROWTYPE;
    L_TRN_REF_NO            IFTB_FAST_MASTER.TRN_REF_NO%TYPE;
    PKG_DETB_RTL_TELLER_REC DETBS_RTL_TELLER%ROWTYPE;
    L_SERIAL_NO             VARCHAR2(16);
    L_TXN_STATUS            VARCHAR2(10);
  
    P_DOCUMENT_XML     XMLTYPE;
    L_FORMATTED_MSG    CLOB;
    L_COUNT            NUMBER;
    L_AC_CLOSURE_COUNT NUMBER;
    L_IN_RESP          CLOB;
    L_COSMETIC_RES_MSG CLOB;
    P_ERR_CODE         VARCHAR2(255);
    P_ERR_PARAMS       VARCHAR2(255);
    L_RATE_FLAG        NUMBER;
    L_PROD             CSTM_PRODUCT%ROWTYPE;
    L_TXN_AMT          IFTB_FAST_MASTER.TXN_AMT%TYPE;
    L_EXCH_RATE        IFTB_FAST_MASTER.EXCH_RATE%TYPE;
    L_RATE_CODE1       CSTM_PRODUCT.RATE_CODE_PREFERRED%TYPE;
    L_REFUND_CODE      VARCHAR2(20);
    L_TRN_REF          VARCHAR2(255);
    L_STTB_ACCOUNT     STTB_ACCOUNT%ROWTYPE;
    P_ERROR_CODE       ERTB_MSGS.ERR_CODE%TYPE;
    P_ERROR_MSG        ERTB_MSGS.MESSAGE%TYPE;
    --APPLE EXCEPTION;
    CURSOR C1 IS
      SELECT * FROM IFTBS_FAST_INCOMING_TRACK WHERE STATUS IN ('U', 'E');
  
    L_GEN_SEQ_NO VARCHAR2(100);
  
    --Charge Pickup Starts
    l_rel_customer              sttm_customer.customer_no%TYPE;
    l_rate                      NUMBER;
    l_charge_amt                NUMBER := 0;
    p_ifdofast                  ifpks_ifdofast_main.ty_ifdofast;
    l_ac_ccy                    sttm_cust_account.ccy%TYPE;
    l_tot_chg_amt_in_txn_ccy    iftb_fast_master.txn_amt%TYPE;
    l_tot_chg_amt_in_lcy_ccy    iftb_fast_master.txn_amt%TYPE;
    l_tot_chg_amount_in_txn_ccy iftb_fast_master.txn_amt%TYPE;
    l_tot_chg_amount_in_acc_ccy iftb_fast_master.txn_amt%TYPE;
    l_txn_amt1                  iftb_fast_master.txn_amt%TYPE;
    l_ccy1                      iftb_fast_master.txn_ccy%TYPE;
    l_ccy2                      iftb_fast_master.txn_ccy%TYPE;
    l_rate_code                 cstm_product.rate_code_preferred%Type;
    l_tot_chg_amt               NUMBER(22, 3);
    l_tot_chg_amount            iftb_fast_master.net_txn_amt%TYPE;
    --Charge Pickup Ends
  
  BEGIN
  
    --GLOBAL.PR_INIT('000', 'SYSTEM');
  
    DBG('INSIDE PR_PROCESS_FAST_INCOMING_TXN');
  
    --Get product Code
    SELECT X.* INTO L_PROD FROM CSTM_PRODUCT X WHERE PRODUCT_CODE = 'FSIN';
  
    FOR G IN C1 LOOP
    
      BEGIN
      
        GLOBAL.PR_INIT('000', 'SYSTEM');
      
        L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;
      
        PR_RETURN_COSMETIC_XML(G.INC_REQ_MSG, L_COSMETIC_RES_MSG);
      
        DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
      
        P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
      
        --check if it is already refunded by other bank since message id is different
        L_REFUND_CODE := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Purp/Cd/text()')
                         .GETSTRINGVAL;
      
        IF L_REFUND_CODE = 'REFU' THEN
        
          --Do Reversal into a
          IFPKS_IFDOFAST_CUSTOM.PR_REVERSE_FAST_OUT_TXN(P_DOCUMENT_XML);
        
        ELSE
        
          L_MSG_ID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/MsgId/text()')
                      .GETSTRINGVAL;
          DBG('L_MSG_ID=' || L_MSG_ID);
        
          L_CREDTTM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/CreDtTm/text()')
                       .GETSTRINGVAL;
          DBG('L_CreDtTm=' || L_CreDtTm);
        
          L_NBOFTXS := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/NbOfTxs/text()')
                       .GETSTRINGVAL;
          DBG('L_NbOfTxs=' || L_NbOfTxs);
        
          L_CTRLSUM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/CtrlSum/text()')
                       .GETSTRINGVAL;
          DBG('L_CTRLSUM=' || L_CTRLSUM);
        
          L_INITGPTY_NM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/InitgPty/Nm/text()')
                           .GETSTRINGVAL;
          DBG('L_INITGPTY_NM=' || L_INITGPTY_NM);
        
          L_PMTINFID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/PmtInfId/text()')
                        .GETSTRINGVAL;
          DBG('L_PMTINFID=' || L_PMTINFID);
        
          L_PMTMTD := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/PmtMtd/text()')
                      .GETSTRINGVAL;
          DBG('L_PMTMTD=' || L_PMTMTD);
        
          L_BTCHBOOKG := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/BtchBookg/text()')
                         .GETSTRINGVAL;
          DBG('L_BTCHBOOKG=' || L_BTCHBOOKG);
        
          L_REQDEXCTNDT := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/ReqdExctnDt/text()')
                           .GETSTRINGVAL;
          DBG('L_REQDEXCTNDT=' || L_REQDEXCTNDT);
        
          L_DBTR_NM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/Dbtr/Nm/text()')
                       .GETSTRINGVAL;
          DBG('L_DBTR_NM=' || L_DBTR_NM);
        
          L_DBTRACCT_NO := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/DbtrAcct/Id/Othr/Id/text()')
                           .GETSTRINGVAL;
          DBG('L_DBTRACCT_NO=' || L_DBTRACCT_NO);
        
          L_DBTRACCT_CCY := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/DbtrAcct/Ccy/text()')
                            .GETSTRINGVAL;
          DBG('L_DBTRACCT_CCY=' || L_DBTRACCT_CCY);
        
          L_DBTRAGT_BICFI := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/DbtrAgt/FinInstnId/BICFI/text()')
                             .GETSTRINGVAL;
          DBG('L_DBTRAGT_BICFI=' || L_DBTRAGT_BICFI);
        
          L_INSTRID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/PmtId/InstrId/text()')
                       .GETSTRINGVAL;
          DBG('L_INSTRID=' || L_INSTRID);
        
          L_ENDTOENDID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/PmtId/EndToEndId/text()')
                          .GETSTRINGVAL;
          DBG('L_ENDTOENDID=' || L_ENDTOENDID);
        
          L_AMT := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Amt/InstdAmt/text()')
                   .GETSTRINGVAL;
          DBG('L_AMT=' || L_AMT);
        
          L_CHRGBR := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/ChrgBr/text()')
                      .GETSTRINGVAL;
          DBG('L_CHRGBR=' || L_CHRGBR);
        
          L_CRTRAGT_BICFI := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/CdtrAgt/FinInstnId/BICFI/text()')
                             .GETSTRINGVAL;
          DBG('L_CRTRAGT_BICFI=' || L_CRTRAGT_BICFI);
        
          L_CDTR_NM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Cdtr/Nm/text()')
                       .GETSTRINGVAL;
          DBG('L_CDTR_NM=' || L_CDTR_NM);
        
          L_CDTRACCT_NO := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/CdtrAcct/Id/Othr/Id/text()')
                           .GETSTRINGVAL;
          DBG('L_CDTRACCT_NO=' || L_CDTRACCT_NO);
        
          L_PURP := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Purp/Cd/text()')
                    .GETSTRINGVAL;
          DBG('L_PURP=' || L_PURP);
        
          --Get Ben Acc details
          BEGIN
            SELECT *
              INTO L_CUST_AC
              FROM STTM_CUST_ACCOUNT
             WHERE CUST_AC_NO = L_CDTRACCT_NO;
          
          EXCEPTION
            WHEN OTHERS THEN
              L_CUST_AC := NULL;
              DBG('FAILED IN GETTING ACCOUNT DETAILS');
          END;
        
          --Get Account details
          BEGIN
            SELECT *
              INTO L_STTB_ACCOUNT
              FROM STTB_ACCOUNT
             WHERE AC_GL_NO = L_CDTRACCT_NO;
          
          EXCEPTION
            WHEN OTHERS THEN
              L_STTB_ACCOUNT := NULL;
              DBG('FAILED IN GETTING ACCOUNT DETAILS');
          END;
        
          --Get Count of Beneficiary Account
          BEGIN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM STTM_CUST_ACCOUNT
             WHERE CUST_AC_NO = L_CDTRACCT_NO;
          
          EXCEPTION
            WHEN OTHERS THEN
              L_COUNT := 0;
          END;
        
          IF L_COUNT = 0 OR L_CUST_AC.RECORD_STAT = 'C' OR
             L_STTB_ACCOUNT.AC_STAT_FROZEN = 'Y' OR
             L_STTB_ACCOUNT.AC_STAT_NO_CR = 'Y' OR
             L_STTB_ACCOUNT.AC_STAT_DORMANT = 'Y' THEN
          
            DBG('SOMETHING WRONG WITH BENEFICIARY ACCOUNT......SO LETS REJECT/REFUND INCOMING FAST TRANSACTION');
          
            --Get Refund Message
            L_FORMATTED_MSG := FN_RETURN_REFUND_MSG;
          
            DBG('BEFORE REPLACEMENT OF REFUND XML=' || L_FORMATTED_MSG);
          
            --Replace tags with actual values
            L_NEW_MSG_ID := IFPKS_IFDOFAST_CUSTOM.FN_RETURN_MSG_ID;
          
            L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                       '$L_NEW_MSG_ID',
                                       L_NEW_MSG_ID);
          
            L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                       '$L_MSG_ID',
                                       L_MSG_ID);
          
            L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                       '$L_CREDTTM',
                                       L_CREDTTM);
          
            L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                       '$L_INITGPTY_NM',
                                       L_INITGPTY_NM);
          
            L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                       '$L_CRTRAGT_BICFI',
                                       L_CRTRAGT_BICFI);
          
            L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                       '$L_DBTRAGT_BICFI',
                                       L_DBTRAGT_BICFI);
          
            L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                       '$L_PMTINFID',
                                       L_PMTINFID);
          
            L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                       '$L_ENDTOENDID',
                                       L_ENDTOENDID);
          
            L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMT', L_AMT);
          
            L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                       '$L_DBTR_NM',
                                       L_DBTR_NM);
          
            L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                       '$L_DBTRACCT_NO',
                                       L_DBTRACCT_NO);
          
            L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                       '$L_CDTR_NM',
                                       L_CDTR_NM);
          
            DBG('AFTER REPLACEMENT OF REFUND XML=' || L_FORMATTED_MSG);
          
            --Log Refund Request to NBC
            DBG('LOGGING REFUND REQUEST TO NBC');
            IF L_COUNT = 0 THEN
              P_ERROR_CODE := 'FT-MTUP100';
              P_ERROR_MSG  := 'Beneficiary Account Not Found';
              PR_INSERT_FAST_WS_LOG(L_MSG_ID,
                                    L_GEN_SEQ_NO,
                                    NULL,
                                    SYSDATE,
                                    'Refund',
                                    L_FORMATTED_MSG,
                                    'I',
                                    'Beneficiary Account Not Found',
                                    'Refund for Incoming');
            
            ELSIF L_CUST_AC.RECORD_STAT = 'C' THEN
              P_ERROR_CODE := 'AC-VAC12';
              P_ERROR_MSG  := 'Beneficiary Account Status Closed';
              PR_INSERT_FAST_WS_LOG(L_MSG_ID,
                                    L_GEN_SEQ_NO,
                                    NULL,
                                    SYSDATE,
                                    'Refund',
                                    L_FORMATTED_MSG,
                                    'I',
                                    'Beneficiary Account Status Closed',
                                    'Refund for Incoming');
            
            ELSIF L_STTB_ACCOUNT.AC_STAT_FROZEN = 'Y' THEN
              P_ERROR_CODE := 'AC-VAC04';
              P_ERROR_MSG  := 'Beneficiary Account Status Frozen';
              PR_INSERT_FAST_WS_LOG(L_MSG_ID,
                                    L_GEN_SEQ_NO,
                                    NULL,
                                    SYSDATE,
                                    'Refund',
                                    L_FORMATTED_MSG,
                                    'I',
                                    'Beneficiary Account Status Frozen',
                                    'Refund for Incoming');
            ELSIF L_STTB_ACCOUNT.AC_STAT_NO_CR = 'Y' THEN
              P_ERROR_CODE := 'AC-VAC03';
              P_ERROR_MSG  := 'Beneficiary Account Status No Credit';
              PR_INSERT_FAST_WS_LOG(L_MSG_ID,
                                    L_GEN_SEQ_NO,
                                    NULL,
                                    SYSDATE,
                                    'Refund',
                                    L_FORMATTED_MSG,
                                    'I',
                                    'Beneficiary Account Status No Credit',
                                    'Refund for Incoming');
            
            ELSIF L_STTB_ACCOUNT.AC_STAT_DORMANT = 'Y' THEN
              PR_INSERT_FAST_WS_LOG(L_MSG_ID,
                                    L_GEN_SEQ_NO,
                                    NULL,
                                    SYSDATE,
                                    'Refund',
                                    L_FORMATTED_MSG,
                                    'I',
                                    'Beneficiary Account Status Dormant',
                                    'Refund for Incoming');
            
            END IF;
          
            IF NOT IFPKS_IFDOFAST_CUSTOM.FN_FAST_HTTP_CALL('F',
                                                           L_FORMATTED_MSG,
                                                           L_IN_RESP) THEN
              DBG('FAILED IN REVERSING THE REFUND API');
              PR_UPDATE_DOC_TRACKER(L_MSG_ID,
                                    'E',
                                    P_ERR_CODE,
                                    P_ERR_PARAMS);
              COMMIT;
            
            ELSE
            
              --Log Refund Response
              L_IN_RESP := REPLACE(L_IN_RESP, '&lt;', '<');
              L_IN_RESP := REPLACE(L_IN_RESP, '&gt;', '>');
              DBG('L_IN_RESP=' || L_IN_RESP);
            
              --Get Cosmetic XML
              PR_RETURN_COSMETIC_XML(L_IN_RESP, L_COSMETIC_RES_MSG);
            
              DBG('L_COSMETIC_RES_MSG OF REFUND RESPONSE=' ||
                  L_COSMETIC_RES_MSG);
            
              --Convert into XMLTYPE
              P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
            
              --Get Node Value
              L_TXN_STATUS := P_DOCUMENT_XML.EXTRACT('/Document/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/TxSts/text()')
                              .GETSTRINGVAL;
            
              DBG('L_TXN_STATUS=' || L_TXN_STATUS);
            
              --Log Refund Response from NBC
              DBG('LOGGING REFUND RESPONSE FROM NBC');
            
              --Just check this tomorrow
              PR_UPDATE_STATUS_FAST_INCOMING(L_TRN_REF_NO, L_TXN_STATUS);
            
              --Update status to processed for current row
              PR_UPDATE_DOC_TRACKER(L_MSG_ID,
                                    'R',
                                    P_ERROR_CODE,
                                    P_ERROR_MSG);
            
              PR_UPDATE_FAST_WS_LOG(L_MSG_ID,
                                    L_GEN_SEQ_NO,
                                    L_TXN_STATUS,
                                    L_IN_RESP);
            
              DBG('SUCCESS IN REFUNDING/REVERSING THE INCOMING FAST TRANSACTION');
            
            END IF;
          
            COMMIT;
          
          ELSE
            GLOBAL.PR_INIT(L_CUST_AC.BRANCH_CODE, 'SYSTEM');
          
            SAVEPOINT A;
          
            DBG('BENEFICIARY ACCOUNT AVAILABLE......SO LETS PROCESS INCOMING FAST TRANSACTION');
          
            --GET BEN CUSTOMER DETAILS
            BEGIN
              SELECT X.*
                INTO L_CUST
                FROM STTM_CUSTOMER X
               WHERE X.CUSTOMER_NO = L_CUST_AC.CUST_NO;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('FAILED IN GETTING CUSTOMER DETAILS');
            END;
          
            --XRATE CALCULATION STARTS
            IF 'KHR' <> L_CUST_AC.CCY THEN
            
              BEGIN
                SELECT DECODE(L_PROD.RATE_CODE_PREFERRED,
                              'B',
                              'S',
                              'S',
                              'S',
                              'M',
                              'M',
                              L_PROD.RATE_TYPE_PREFERRED)
                  INTO L_RATE_CODE1
                  FROM DUAL;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Exception found l_rate_code-> ' || L_RATE_CODE1);
              END;
              DBG('L_RATE_CODE1=' || L_RATE_CODE1);
              DBG('l_prod.rate_type_preferred=' ||
                  L_PROD.RATE_TYPE_PREFERRED);
            
              IF NOT CYPKSS.FN_GETRATE(L_CUST_AC.BRANCH_CODE,
                                       L_CUST_AC.CCY,
                                       'KHR', --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                       L_PROD.RATE_TYPE_PREFERRED,
                                       L_RATE_CODE1, --l_prod.rate_code_preferred,
                                       GLOBAL.APPLICATION_DATE,
                                       GLOBAL.APPLICATION_DATE,
                                       L_EXCH_RATE,
                                       L_RATE_FLAG,
                                       P_ERR_CODE) THEN
                DBG('FAILED IN FN_GETRATE');
              END IF;
            ELSE
              L_EXCH_RATE := 1;
            END IF;
          
            DBG('L_EXCH_RATE=' || L_EXCH_RATE);
          
            --Using above rate..convert khr to usd amount
            IF NOT cypkss.FN_AMT1_TO_AMT2('KHR',
                                          L_CUST_AC.CCY,
                                          L_AMT,
                                          L_EXCH_RATE,
                                          'Y',
                                          L_TXN_AMT,
                                          P_ERR_PARAMS) THEN
              DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
              DBG('ROLLINGBACK TO SAVEPOINT A');
              ROLLBACK TO A;
            END IF;
            dbg('FINAL L_TXN_AMT=' || L_TXN_AMT);
            --XRATE CALCULATION ENDS
          
            --GET REFERENCE NO
            IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                               'FSIN',
                                               GLOBAL.APPLICATION_DATE,
                                               L_SERIAL_NO,
                                               L_TRN_REF_NO,
                                               P_ERR_CODE) THEN
              DBG('FAILED IN GENERATION TRANSACTION REF NO');
              DBG('ROLLINGBACK TO SAVEPOINT A');
              ROLLBACK TO A;
            ELSE
              DBG('L_TRN_REF_NO=' || L_TRN_REF_NO);
            END IF;
          
            --GET ARC PRODUCT
            CSPKSS_ARC.PR_GET_ARC_ROW(GLOBAL.CURRENT_BRANCH,
                                      'FSIN',
                                      'P',
                                      '*.*', -- TRANS_TYPE
                                      'KHR',
                                      L_IB_FLAG,
                                      L_ARC_MAINT,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS,
                                      L_CUST_AC.CUST_AC_NO,
                                      L_CUST_AC.BRANCH_CODE);
          
            IF P_ERR_CODE IS NOT NULL THEN
              DBG('CSPKSS_ARC.PR_GET_ARC_ROW returned false');
              DBG('ROLLINGBACK TO SAVEPOINT A');
              ROLLBACK TO A;
            END IF;
          
            --Charge Pickup starts
          
            SELECT x.*
              INTO l_prod
              FROM cstm_product x
             WHERE product_code = 'FSIN'; --Product
          
            BEGIN
              SELECT cust_no, ccy
                INTO l_rel_customer, l_ac_ccy
                FROM sttm_cust_account
               WHERE cust_ac_no = L_CUST_AC.CUST_AC_NO;
            EXCEPTION
              WHEN no_data_found THEN
                dbg('Invalid Ben Account for Incoming Txn');
              
            END;
          
            dbg('got l_rel_customer' || l_rel_customer);
          
            IF NOT cspkss_arc.fn_charge_pickup(GLOBAL.CURRENT_BRANCH,
                                               'FSIN',
                                               'P',
                                               'FSIN',
                                               'KHR', --txn_ccy
                                               l_cust_ac.cust_no,
                                               'KHR', --txn_ccy
                                               L_AMT, --txn amt
                                               l_prod.rate_type_preferred,
                                               l_prod.rate_code_preferred,
                                               NULL,
                                               l_cust_ac.cust_no,
                                               l_ib_flag,
                                               depks_rtl_teller.pkg_arc_row,--l_arc_maint,--,
                                               p_err_code,
                                               p_err_params,
                                               l_cust_ac.cust_ac_no,
                                               GLOBAL.CURRENT_BRANCH) THEN
              dbg('CHARGE PICKUP failed');
              --RETURN FALSE;
            END IF;
          
            DBG('l_arc_maint.cod_chg_amt =' || l_arc_maint.cod_chg_amt);
            
            l_arc_maint := depks_rtl_teller.pkg_arc_row;
            
            --depks_rtl_teller.pkg_arc_row.cod_chg_amt := l_arc_maint.cod_chg_amt;
          
            --Charge1
            IF l_arc_maint.cod_chg_amt IS NOT NULL THEN
              p_ifdofast.v_iftbs_fast_charge(1).trn_ref_no := L_TRN_REF_NO;
              p_ifdofast.v_iftbs_fast_charge(1).chg_srno := 1;
              p_ifdofast.v_iftbs_fast_charge(1).chg_desc := l_arc_maint.cod_chg_desc;
              p_ifdofast.v_iftbs_fast_charge(1).waiver := 'N';
              p_ifdofast.v_iftbs_fast_charge(1).chg_amt := l_arc_maint.cod_chg_amt;
              p_ifdofast.v_iftbs_fast_charge(1).chg_ccy := l_arc_maint.cod_chg_ccy;
            
              DBG('p_ifdofast.v_iftbs_fast_charge(1).trn_ref_no=' || p_ifdofast.v_iftbs_fast_charge(1)
                  .trn_ref_no);
              DBG('p_ifdofast.v_iftbs_fast_charge(1).chg_srno=' || p_ifdofast.v_iftbs_fast_charge(1)
                  .chg_srno);
              DBG('p_ifdofast.v_iftbs_fast_charge(1).chg_desc=' || p_ifdofast.v_iftbs_fast_charge(1)
                  .chg_desc);
              DBG('p_ifdofast.v_iftbs_fast_charge(1).waiver=' || p_ifdofast.v_iftbs_fast_charge(1)
                  .waiver);
              DBG('p_ifdofast.v_iftbs_fast_charge(1).chg_amt=' || p_ifdofast.v_iftbs_fast_charge(1)
                  .chg_amt);
              DBG('p_ifdofast.v_iftbs_fast_charge(1).chg_ccy=' || p_ifdofast.v_iftbs_fast_charge(1)
                  .chg_ccy);
            
              DBG('p_ifdofast.v_iftbs_fast_charge.count=' ||
                  p_ifdofast.v_iftbs_fast_charge.count);
            
              DBG('global.lcy=' || global.lcy);
              DBG('l_arc_maint.cod_chg_ccy=' || l_arc_maint.cod_chg_ccy);
            
              -- Converting charge into local ccy for display in charge tab
              IF l_arc_maint.cod_chg_ccy <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy,
                                              global.lcy,
                                              l_prod.rate_type_preferred,
                                              l_prod.rate_code_preferred,
                                              l_arc_maint.cod_chg_amt,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(1).lcy_chg := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(1).xrate := l_rate;
              ELSE
                p_ifdofast.v_iftbs_fast_charge(1).lcy_chg := l_arc_maint.cod_chg_amt;
                p_ifdofast.v_iftbs_fast_charge(1).xrate := 1;
              END IF;
              dbg('Amount 1 in Local ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
                  .lcy_chg);
            
              -- Converting charge into txn ccy
              IF l_arc_maint.cod_chg_ccy <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy,
                                              'KHR', --txn_ccy
                                              l_prod.rate_type_preferred,
                                              NVL(l_arc_maint.cod_rate_code_Type,
                                                  'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                              l_arc_maint.cod_chg_amt,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(1).chg_in_txn := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(1).txn_xrate := l_rate;
                dbg(' * Amount 1 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
                    .chg_in_txn);
              ELSE
                p_ifdofast.v_iftbs_fast_charge(1).chg_in_txn := l_arc_maint.cod_chg_amt;
                p_ifdofast.v_iftbs_fast_charge(1).txn_xrate := 1;
                dbg('** Amount 1 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
                    .chg_in_txn);
              END IF;
            
              -- Converting charge into acc ccy
              IF l_arc_maint.cod_chg_ccy <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                              l_arc_maint.cod_chg_ccy,
                                              l_ac_ccy,
                                              l_prod.rate_type_preferred,
                                              NVL(l_arc_maint.cod_rate_code_Type,
                                                  'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                              l_arc_maint.cod_chg_amt,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(1).chg_in_acc := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(1).acc_xrate := l_rate;
                dbg('* Amount 1 in acc ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
                    .chg_in_acc);
              ELSE
                p_ifdofast.v_iftbs_fast_charge(1).chg_in_acc := l_arc_maint.cod_chg_amt;
                p_ifdofast.v_iftbs_fast_charge(1).acc_xrate := 1;
                dbg('** Amount 1 in acc ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
                    .chg_in_acc);
              END IF;
            END IF;
          
            --Charge2
            IF l_arc_maint.cod_chg_amt1 IS NOT NULL THEN
              p_ifdofast.v_iftbs_fast_charge(2).trn_ref_no := L_TRN_REF_NO;
              p_ifdofast.v_iftbs_fast_charge(2).chg_srno := 2;
              p_ifdofast.v_iftbs_fast_charge(2).chg_desc := l_arc_maint.cod_chg_desc1;
              p_ifdofast.v_iftbs_fast_charge(2).waiver := 'N';
              p_ifdofast.v_iftbs_fast_charge(2).chg_amt := l_arc_maint.cod_chg_amt1;
              p_ifdofast.v_iftbs_fast_charge(2).chg_ccy := l_arc_maint.cod_chg_ccy1;
            
              IF l_arc_maint.cod_chg_ccy1 <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy1,
                                              global.lcy,
                                              l_prod.rate_type_preferred,
                                              l_prod.rate_code_preferred,
                                              l_arc_maint.cod_chg_amt1,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(2).lcy_chg := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(2).xrate := l_rate;
              ELSE
                p_ifdofast.v_iftbs_fast_charge(2).lcy_chg := l_arc_maint.cod_chg_amt1;
                p_ifdofast.v_iftbs_fast_charge(2).xrate := 1;
              END IF;
            
              -- Converting charge into txn ccy
              IF l_arc_maint.cod_chg_ccy1 <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy1,
                                              'KHR',
                                              l_prod.rate_type_preferred,
                                              NVL(l_arc_maint.cod_rate_code_Type1,
                                                  'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                              l_arc_maint.cod_chg_amt1,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(2).chg_in_txn := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(2).txn_xrate := l_rate;
                dbg('* Amount 2 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(2)
                    .chg_in_txn);
              ELSE
                p_ifdofast.v_iftbs_fast_charge(2).chg_in_txn := l_arc_maint.cod_chg_amt1;
                p_ifdofast.v_iftbs_fast_charge(2).txn_xrate := 1;
                dbg('** Amount 2 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(2)
                    .chg_in_txn);
              END IF;
            
              -- Converting charge into acc ccy
              IF l_arc_maint.cod_chg_ccy1 <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy1,
                                              l_ac_ccy,
                                              l_prod.rate_type_preferred,
                                              NVL(l_arc_maint.cod_rate_code_Type1,
                                                  'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                              l_arc_maint.cod_chg_amt1,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(2).chg_in_acc := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(2).acc_xrate := l_rate;
                dbg('* Amount 2 in acc ccy->' || p_ifdofast.v_iftbs_fast_charge(2)
                    .chg_in_acc);
              ELSE
                p_ifdofast.v_iftbs_fast_charge(2).chg_in_acc := l_arc_maint.cod_chg_amt1;
                p_ifdofast.v_iftbs_fast_charge(2).acc_xrate := 1;
                dbg('** Amount 2 in acc ccy->' || p_ifdofast.v_iftbs_fast_charge(2)
                    .chg_in_acc);
              END IF;
              p_ifdofast.v_iftbs_fast_charge(2).oth_ccy := l_arc_maint.cod_chg_ccy1;
            
            END IF;
          
            --Charge3
            IF l_arc_maint.cod_chg_amt2 IS NOT NULL THEN
              p_ifdofast.v_iftbs_fast_charge(3).trn_ref_no := L_TRN_REF_NO;
              p_ifdofast.v_iftbs_fast_charge(3).chg_srno := 3;
              p_ifdofast.v_iftbs_fast_charge(3).chg_desc := l_arc_maint.cod_chg_desc2;
              p_ifdofast.v_iftbs_fast_charge(3).waiver := 'N';
              p_ifdofast.v_iftbs_fast_charge(3).chg_amt := l_arc_maint.cod_chg_amt2;
              p_ifdofast.v_iftbs_fast_charge(3).chg_ccy := l_arc_maint.cod_chg_ccy2;
            
              IF l_arc_maint.cod_chg_ccy2 <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy2,
                                              global.lcy,
                                              l_prod.rate_type_preferred,
                                              l_prod.rate_code_preferred,
                                              l_arc_maint.cod_chg_amt2,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(3).lcy_chg := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(3).xrate := l_rate;
              ELSE
                p_ifdofast.v_iftbs_fast_charge(3).lcy_chg := l_arc_maint.cod_chg_amt2;
                p_ifdofast.v_iftbs_fast_charge(3).xrate := 1;
              END IF;
            
              -- Converting charge into txn ccy
              IF l_arc_maint.cod_chg_ccy2 <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy2,
                                              'KHR',
                                              l_prod.rate_type_preferred,
                                              NVL(l_arc_maint.cod_rate_code_Type2,
                                                  'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                              l_arc_maint.cod_chg_amt2,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(3).chg_in_txn := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(3).txn_xrate := l_rate;
                dbg('* Amount 3 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(3)
                    .chg_in_txn);
              ELSE
                p_ifdofast.v_iftbs_fast_charge(3).chg_in_txn := l_arc_maint.cod_chg_amt2;
                p_ifdofast.v_iftbs_fast_charge(3).txn_xrate := 1;
                dbg('** Amount 3 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(3)
                    .chg_in_txn);
              END IF;
            
              -- Converting charge into acc ccy
              IF l_arc_maint.cod_chg_ccy2 <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy2,
                                              l_ac_ccy,
                                              l_prod.rate_type_preferred,
                                              NVL(l_arc_maint.cod_rate_code_Type2,
                                                  'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                              l_arc_maint.cod_chg_amt2,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(3).chg_in_acc := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(3).acc_xrate := l_rate;
                dbg('* Amount 3 in ACC ccy->' || p_ifdofast.v_iftbs_fast_charge(3)
                    .chg_in_acc);
              ELSE
                p_ifdofast.v_iftbs_fast_charge(3).chg_in_acc := l_arc_maint.cod_chg_amt2;
                p_ifdofast.v_iftbs_fast_charge(3).acc_xrate := 1;
                dbg('** Amount 3 in ACC ccy->' || p_ifdofast.v_iftbs_fast_charge(3)
                    .chg_in_acc);
              END IF;
              p_ifdofast.v_iftbs_fast_charge(3).oth_ccy := l_arc_maint.cod_chg_ccy2;
            END IF;
          
            --Charge4
            IF l_arc_maint.cod_chg_amt3 IS NOT NULL THEN
              p_ifdofast.v_iftbs_fast_charge(4).trn_ref_no := L_TRN_REF_NO;
              p_ifdofast.v_iftbs_fast_charge(4).chg_srno := 4;
              p_ifdofast.v_iftbs_fast_charge(4).chg_desc := l_arc_maint.cod_chg_desc3;
              p_ifdofast.v_iftbs_fast_charge(4).waiver := 'N';
              p_ifdofast.v_iftbs_fast_charge(4).chg_amt := l_arc_maint.cod_chg_amt3;
              p_ifdofast.v_iftbs_fast_charge(4).chg_ccy := l_arc_maint.cod_chg_ccy3;
            
              IF l_arc_maint.cod_chg_ccy3 <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy3,
                                              global.lcy,
                                              l_prod.rate_type_preferred,
                                              l_prod.rate_code_preferred,
                                              l_arc_maint.cod_chg_amt3,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(4).lcy_chg := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(4).xrate := l_rate;
              ELSE
                p_ifdofast.v_iftbs_fast_charge(4).lcy_chg := l_arc_maint.cod_chg_amt3;
                p_ifdofast.v_iftbs_fast_charge(4).xrate := 1;
              END IF;
            
              -- Converting charge into txn ccy
              IF l_arc_maint.cod_chg_ccy3 <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy3,
                                              'KHR',
                                              l_prod.rate_type_preferred,
                                              NVL(l_arc_maint.cod_rate_code_Type3,
                                                  'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                              l_arc_maint.cod_chg_amt3,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(4).chg_in_txn := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(4).txn_xrate := l_rate;
                dbg('* Amount 4 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(4)
                    .chg_in_txn);
              ELSE
                p_ifdofast.v_iftbs_fast_charge(4).chg_in_txn := l_arc_maint.cod_chg_amt3;
                p_ifdofast.v_iftbs_fast_charge(4).txn_xrate := 1;
                dbg('** Amount 4 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(4)
                    .chg_in_txn);
              END IF;
            
              -- Converting charge into acc ccy
              IF l_arc_maint.cod_chg_ccy3 <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy3,
                                              l_ac_ccy,
                                              l_prod.rate_type_preferred,
                                              NVL(l_arc_maint.cod_rate_code_Type3,
                                                  'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                              l_arc_maint.cod_chg_amt3,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(4).chg_in_acc := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(4).acc_xrate := l_rate;
                dbg('* Amount 4 in OTH ccy->' || p_ifdofast.v_iftbs_fast_charge(4)
                    .chg_in_acc);
              ELSE
                p_ifdofast.v_iftbs_fast_charge(4).chg_in_acc := l_arc_maint.cod_chg_amt3;
                p_ifdofast.v_iftbs_fast_charge(4).acc_xrate := 1;
                dbg('** Amount 4 in OTH ccy->' || p_ifdofast.v_iftbs_fast_charge(4)
                    .chg_in_acc);
              END IF;
              p_ifdofast.v_iftbs_fast_charge(4).oth_ccy := l_arc_maint.cod_chg_ccy3;
            
            END IF;
          
            --Charge5
            IF l_arc_maint.cod_chg_amt4 IS NOT NULL THEN
              p_ifdofast.v_iftbs_fast_charge(5).trn_ref_no := L_TRN_REF_NO;
              p_ifdofast.v_iftbs_fast_charge(5).chg_srno := 5;
              p_ifdofast.v_iftbs_fast_charge(5).chg_desc := l_arc_maint.cod_chg_desc4;
              p_ifdofast.v_iftbs_fast_charge(5).waiver := 'N';
              p_ifdofast.v_iftbs_fast_charge(5).chg_amt := l_arc_maint.cod_chg_amt4;
              p_ifdofast.v_iftbs_fast_charge(5).chg_ccy := l_arc_maint.cod_chg_ccy4;
            
              IF l_arc_maint.cod_chg_ccy4 <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy4,
                                              global.lcy,
                                              l_prod.rate_type_preferred,
                                              l_prod.rate_code_preferred,
                                              l_arc_maint.cod_chg_amt4,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(5).lcy_chg := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(5).xrate := l_rate;
              ELSE
                p_ifdofast.v_iftbs_fast_charge(5).lcy_chg := l_arc_maint.cod_chg_amt4;
                p_ifdofast.v_iftbs_fast_charge(5).xrate := 1;
              END IF;
            
              -- Converting charge into txn ccy
              IF l_arc_maint.cod_chg_ccy4 <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy4,
                                              'KHR',
                                              l_prod.rate_type_preferred,
                                              NVL(l_arc_maint.cod_rate_code_Type4,
                                                  'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                              l_arc_maint.cod_chg_amt4,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(5).chg_in_txn := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(5).txn_xrate := l_rate;
                dbg('* Amount 5 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(5)
                    .chg_in_txn);
              ELSE
                p_ifdofast.v_iftbs_fast_charge(5).chg_in_txn := l_arc_maint.cod_chg_amt4;
                p_ifdofast.v_iftbs_fast_charge(5).txn_xrate := 1;
                dbg('** Amount 5 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(5)
                    .chg_in_txn);
              END IF;
            
              -- Converting charge into acc ccy
              IF l_arc_maint.cod_chg_ccy4 <> 'KHR' THEN
                l_rate       := NULL;
                l_charge_amt := NULL;
                IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                              l_arc_maint.cod_chg_ccy4,
                                              l_ac_ccy,
                                              l_prod.rate_type_preferred,
                                              NVL(l_arc_maint.cod_rate_code_Type4,
                                                  'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                              l_arc_maint.cod_chg_amt4,
                                              'Y',
                                              l_charge_amt,
                                              l_rate,
                                              p_err_params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  --RETURN FALSE;
                END IF;
                dbg('mj ...converted charge1-->' || l_charge_amt);
                p_ifdofast.v_iftbs_fast_charge(5).chg_in_acc := l_charge_amt;
                p_ifdofast.v_iftbs_fast_charge(5).acc_xrate := l_rate;
                dbg('* Amount 5 in OTH ccy->' || p_ifdofast.v_iftbs_fast_charge(5)
                    .chg_in_acc);
              ELSE
                p_ifdofast.v_iftbs_fast_charge(5).chg_in_acc := l_arc_maint.cod_chg_amt4;
                p_ifdofast.v_iftbs_fast_charge(5).acc_xrate := 1;
                dbg('** Amount 5 in OTH ccy->' || p_ifdofast.v_iftbs_fast_charge(5)
                    .chg_in_acc);
              END IF;
              p_ifdofast.v_iftbs_fast_charge(5).oth_ccy := l_arc_maint.cod_chg_ccy4;
            
            END IF;
          
            dbg('Done all charges calculation');
          
            -- Total Charge amount in transaction currency
            FOR J IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP
            
              l_tot_chg_amt_in_txn_ccy := nvl(l_tot_chg_amt_in_txn_ccy, 0) +
                                          nvl(p_ifdofast.v_iftbs_fast_charge(j)
                                              .chg_in_txn,
                                              0);
            
            END LOOP;
          
            dbg('L_TOT_CHG_AMT~P_IFDOFAST.v_iftbs_pgw_master_custom.TXN_CCY~GLOBAL.LCY' ||
                l_tot_chg_amt || '~' || 'KHR' || '~' || global.lcy);
          
            dbg('Total charge to be paid in TXN CCY ->' ||
                l_tot_chg_amt_in_txn_ccy);
          
            --p_ifdofast.v_iftbs_fast_master.tot_chg_amt := l_tot_chg_amt_in_txn_ccy; -- We are displaying total charge in txn amount only --Tuning of code in charge calculation
          
            -- Total Charge amount in local and beneficiary/account ccy
           /* FOR J IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP
              dbg('1 l_tot_chg_amt_in_lcy_ccy->' ||
                  l_tot_chg_amt_in_lcy_ccy ||
                  'p_ifdofast.v_iftbs_fast_charge(j).lcy_chg' || p_ifdofast.v_iftbs_fast_charge(j)
                  .lcy_chg);
              dbg('1 l_tot_chg_amount_in_acc_ccy->' ||
                  l_tot_chg_amount_in_acc_ccy ||
                  'p_ifdofast.v_iftbs_fast_charge(j).chg_in_acc' || p_ifdofast.v_iftbs_fast_charge(j)
                  .chg_in_acc);
              l_tot_chg_amt_in_lcy_ccy    := nvl(l_tot_chg_amt_in_lcy_ccy,
                                                 0) + nvl(p_ifdofast.v_iftbs_fast_charge(j)
                                                          .lcy_chg,
                                                          0);
              l_tot_chg_amount_in_acc_ccy := nvl(l_tot_chg_amount_in_acc_ccy,
                                                 0) + nvl(p_ifdofast.v_iftbs_fast_charge(j)
                                                          .chg_in_acc,
                                                          0);
            
              dbg('2 l_tot_chg_amt_in_lcy_ccy->' ||
                  l_tot_chg_amt_in_lcy_ccy);
              dbg('2 l_tot_chg_amount_in_acc_ccy->' ||
                  l_tot_chg_amount_in_acc_ccy);
            End Loop;
          */
            dbg('chgs calculated ->');
          
            /*If l_prod.rate_code_preferred = 'B' Then
              l_rate_code := Null;
              If ('KHR' = global.lcy and l_ac_ccy != global.lcy) OR
                 ('KHR' != global.lcy and l_ac_ccy <> global.lcy and
                 'KHR' <> l_ac_ccy) Then
                l_rate_code := 'B';
              
              Else
                l_rate_code := l_prod.rate_code_preferred;
              End If;
            Else
              l_rate_code := l_prod.rate_code_preferred;
            End If;*/
            dbg('p_ifdofast.v_iftbs_pgw_master_custom.txn_amt->' ||
                p_ifdofast.v_iftbs_fast_master.txn_amt);
          
            dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
                l_rate_code1);
          
            /*If l_ac_ccy <> global.lcy Then
              begin
                select decode(l_rate_code,
                              'B',
                              'S',
                              'S',
                              'B',
                              'M',
                              'M',
                              l_rate_code)
                  Into l_rate_code1
                  from dual;
              exception
                when others then
                  dbg('Exception found l_rate_code-> ' || l_rate_code);
              end;
            End If;*/
            dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
                l_rate_code1);
            dbg('l_txn_amt l_txn_amt l_txn_amt=' || l_txn_amt);
          
            -- Total Txn amount in remitter currency
            /*IF 'KHR' <> l_ac_ccy THEN
              l_rate := NULL;
              --l_charge_amt := NULL;
              l_txn_amt1 := p_ifdofast.v_iftbs_fast_master.txn_amt;
            
              -- xrate
              IF 'KHR' <> l_ac_ccy THEN
              
                IF 'KHR' = global.lcy THEN
                  l_ccy1 := l_ac_ccy;
                  l_ccy2 := 'KHR';
                ELSE
                  l_ccy1 := 'KHR';
                  l_ccy2 := l_ac_ccy;
                END IF;
                dbg('l_rate_code->' || l_rate_code ||
                    'l_prod.rate_type_preferred' ||
                    l_prod.rate_type_preferred);
                dbg('Before p_ifdofast.v_iftbs_pgw_master_custom.exch_rate->' ||
                    p_ifdofast.v_iftbs_fast_master.exch_rate);
              
                If ('KHR' != global.lcy and l_ac_ccy <> global.lcy and
                   'KHR' <> l_ac_ccy) and l_prod.rate_code_preferred = 'B' Then
                  l_rate_code := 'S';
                End If;
              
                dbg('l_rate_code->' || l_rate_code);
              
                dbg('l_prod.rate_type_preferred=' ||
                    l_prod.rate_type_preferred);
              
                IF NOT cypkss.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                         l_ccy2,
                                         l_ccy1, --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                         l_prod.rate_type_preferred,
                                         l_rate_code, --l_prod.rate_code_preferred,
                                         GLOBAL.APPLICATION_DATE,
                                         GLOBAL.APPLICATION_DATE,
                                         L_EXCH_RATE,
                                         l_rate_flag,
                                         p_err_code) THEN
                  dbg('Failed in Fn_GetRate');
                  --RETURN FALSE;
                END IF;
              ELSE
                L_EXCH_RATE := 1;
              END IF;
            
              DBG('L_EXCH_RATE==' || L_EXCH_RATE);
            
              --Using above rate..convert khr to usd amount
              IF NOT cypkss.FN_AMT1_TO_AMT2('KHR',
                                            l_ac_ccy,
                                            l_txn_amt1,
                                            L_EXCH_RATE,
                                            'Y',
                                            l_txn_amt,
                                            p_err_params) THEN
                DBG('FAILED IN CONVERSION');
                --RETURN FALSE;
              END IF;
            END IF;*/
            dbg('Final txn_amt->' || l_txn_amt || 'Final chg_amount->' ||
                l_tot_chg_amount);
            dbg('Total Charges in local ccy->' || l_tot_chg_amt_in_lcy_ccy);
            dbg('Total Charges in txn ccy->' ||
                l_tot_chg_amount_in_txn_ccy);
            dbg('Total Charges in acc ccy->' ||
                l_tot_chg_amount_in_acc_ccy);
          
            -- Net DB Amount (Charges + Txn amount)
           /* If 'KHR' <> l_ac_ccy Then
              dbg('apple');
              p_ifdofast.v_iftbs_fast_master.net_txn_amt := nvl(l_txn_amt,
                                                                0) +
                                                            (Nvl(l_tot_chg_amount_in_acc_ccy,
                                                                 0));
            
            Elsif p_ifdofast.v_iftbs_fast_master.txn_ccy = l_ac_ccy Then
              dbg('mango');
              p_ifdofast.v_iftbs_fast_master.net_txn_amt := nvl(p_ifdofast.v_iftbs_fast_master.txn_amt,
                                                                0) +
                                                            (Nvl(l_tot_chg_amount_in_acc_ccy,
                                                                 0));
            
            End If;*/
            dbg('p_ifdofast.v_iftbs_fast_master.net_txn_amt->' ||
                p_ifdofast.v_iftbs_fast_master.net_txn_amt);
          
            FOR k IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP
              IF k = 1 THEN
                dbg('CHG AMT' || p_ifdofast.v_iftbs_fast_charge(k).chg_amt);
                IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
                  pkg_detb_rtl_teller_rec.charge_account := p_ifdofast.v_iftbs_fast_master.rem_acc;
                ELSE
                  pkg_detb_rtl_teller_rec.charge_account := L_CUST_AC.CUST_AC_NO;--p_ifdofast.v_iftbs_fast_master.ben_acc;
                END IF;
                pkg_detb_rtl_teller_rec.chg_gl           := l_arc_maint.cod_chg_gl;
                pkg_detb_rtl_teller_rec.chg_ccy          := l_arc_maint.cod_chg_ccy;
                pkg_detb_rtl_teller_rec.chg_amt          := p_ifdofast.v_iftbs_fast_charge(k)
                                                            .chg_amt;
                depks_rtl_teller.pkg_arc_row.cod_chg_amt := p_ifdofast.v_iftbs_fast_charge(k)
                                                            .chg_amt;
              
                dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT' ||
                    depks_rtl_teller.pkg_arc_row.cod_chg_amt);
                depks_rtl_teller.pkg_arc_row.cod_chg_type := l_arc_maint.cod_chg_type;
              
                IF l_arc_maint.cod_chg_ccy <> 'KHR' THEN
                  IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                                l_arc_maint.cod_chg_ccy,
                                                l_cust_ac.ccy,
                                                l_prod.rate_type_preferred,
                                                l_prod.rate_code_preferred,
                                                p_ifdofast.v_iftbs_fast_charge(k)
                                                .chg_amt,
                                                'Y',
                                                pkg_detb_rtl_teller_rec.chg_in_acy,
                                                pkg_detb_rtl_teller_rec.chg_ccy_acy_rate,
                                                p_err_params) THEN
                    debug.pr_debug('**', 'In When Others of EX RATE.');
                    debug.pr_debug('**', SQLERRM);
                    p_err_code   := 'ST-OTHR-001';
                    p_err_params := NULL;
                    --RETURN FALSE;ROLLBACK
                    DBG('ROLLINGBACK TO SAVEPOINT A');
                    ROLLBACK TO A;
                  END IF;
                
                ELSE
                  pkg_detb_rtl_teller_rec.chg_in_acy       := p_ifdofast.v_iftbs_fast_charge(k)
                                                              .chg_amt;
                  pkg_detb_rtl_teller_rec.chg_ccy_acy_rate := 1;
                END IF;
              
                DBG('pkg_detb_rtl_teller_rec.chg_in_acy=' ||
                    pkg_detb_rtl_teller_rec.chg_in_acy);
                DBG('pkg_detb_rtl_teller_rec.chg_ccy_acy_rate=' ||
                    pkg_detb_rtl_teller_rec.chg_ccy_acy_rate);
              
                pkg_detb_rtl_teller_rec.chg_in_lcy   := p_ifdofast.v_iftbs_fast_charge(k)
                                                        .lcy_chg;
                pkg_detb_rtl_teller_rec.acy_lcy_rate := 1;--p_ifdofast.v_iftbs_fast_master.exch_rate;
                pkg_detb_rtl_teller_rec.netting_ind  := l_arc_maint.cod_chg_netting;
                pkg_detb_rtl_teller_rec.txn_code     := l_arc_maint.cod_chg_txn_code;
                pkg_detb_rtl_teller_rec.mis_head_1   := l_arc_maint.cod_mis_head;
                pkg_detb_rtl_teller_rec.chg_desc     := l_arc_maint.cod_chg_desc;
                pkg_detb_rtl_teller_rec.chg_type     := l_arc_maint.cod_chg_type;
                pkg_detb_rtl_teller_rec.waiver       := p_ifdofast.v_iftbs_fast_charge(k)
                                                        .waiver;
                pkg_detb_rtl_teller_rec.their_chgs   := l_arc_maint.cod_their_chgs;
              END IF;
              -- 2
              IF k = 2 THEN
                pkg_detb_rtl_teller_rec.chg_gl_1  := l_arc_maint.cod_chg_gl1;
                pkg_detb_rtl_teller_rec.chg_ccy_1 := l_arc_maint.cod_chg_ccy1;
                pkg_detb_rtl_teller_rec.chg_amt_1 := p_ifdofast.v_iftbs_fast_charge(k)
                                                     .chg_amt;
              
                depks_rtl_teller.pkg_arc_row.cod_chg_amt1 := p_ifdofast.v_iftbs_fast_charge(k)
                                                             .chg_amt;
              
                dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT1' ||
                    depks_rtl_teller.pkg_arc_row.cod_chg_amt1);
                depks_rtl_teller.pkg_arc_row.cod_chg_type1 := l_arc_maint.cod_chg_type1;
              
                IF l_arc_maint.cod_chg_ccy1 <> l_cust_ac.ccy THEN
                  IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                                l_arc_maint.cod_chg_ccy1,
                                                l_cust_ac.ccy,
                                                l_prod.rate_type_preferred,
                                                l_prod.rate_code_preferred,
                                                p_ifdofast.v_iftbs_fast_charge(k)
                                                .chg_amt,
                                                'Y',
                                                pkg_detb_rtl_teller_rec.chg_in_acy_1,
                                                pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1,
                                                p_err_params) THEN
                    debug.pr_debug('**', 'In When Others of EX RATE.');
                    debug.pr_debug('**', SQLERRM);
                    p_err_code   := 'ST-OTHR-001';
                    p_err_params := NULL;
                    --RETURN FALSE;ROLLBACK
                    DBG('ROLLINGBACK TO SAVEPOINT A');
                    ROLLBACK TO A;
                  END IF;
                ELSE
                  pkg_detb_rtl_teller_rec.chg_in_acy_1       := p_ifdofast.v_iftbs_fast_charge(k)
                                                                .chg_amt;
                  pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1 := 1;
                END IF;
              
                pkg_detb_rtl_teller_rec.chg_in_lcy_1   := p_ifdofast.v_iftbs_fast_charge(k)
                                                          .lcy_chg;
                pkg_detb_rtl_teller_rec.acy_lcy_rate_1 := p_ifdofast.v_iftbs_fast_master.exch_rate;
                pkg_detb_rtl_teller_rec.netting_ind_1  := l_arc_maint.cod_chg_netting1;
                pkg_detb_rtl_teller_rec.txn_code_1     := l_arc_maint.cod_chg_txn_code1;
                pkg_detb_rtl_teller_rec.mis_head_2     := l_arc_maint.cod_mis_head1;
                pkg_detb_rtl_teller_rec.chg_desc1      := l_arc_maint.cod_chg_desc1;
                pkg_detb_rtl_teller_rec.chg_type1      := l_arc_maint.cod_chg_type1;
                pkg_detb_rtl_teller_rec.waiver1        := p_ifdofast.v_iftbs_fast_charge(k)
                                                          .waiver;
                pkg_detb_rtl_teller_rec.their_chgs1    := l_arc_maint.cod_their_chgs1;
              END IF;
              -- 3
              IF k = 3 THEN
                pkg_detb_rtl_teller_rec.chg_gl_2  := l_arc_maint.cod_chg_gl2;
                pkg_detb_rtl_teller_rec.chg_ccy_2 := l_arc_maint.cod_chg_ccy2;
                pkg_detb_rtl_teller_rec.chg_amt_2 := p_ifdofast.v_iftbs_fast_charge(k)
                                                     .chg_amt;
              
                depks_rtl_teller.pkg_arc_row.cod_chg_amt2 := p_ifdofast.v_iftbs_fast_charge(k)
                                                             .chg_amt;
              
                dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT2' ||
                    depks_rtl_teller.pkg_arc_row.cod_chg_amt2);
                depks_rtl_teller.pkg_arc_row.cod_chg_type2 := l_arc_maint.cod_chg_type2;
              
                IF l_arc_maint.cod_chg_ccy2 <> l_cust_ac.ccy THEN
                  IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                                l_arc_maint.cod_chg_ccy2,
                                                l_cust_ac.ccy,
                                                l_prod.rate_type_preferred,
                                                l_prod.rate_code_preferred,
                                                p_ifdofast.v_iftbs_fast_charge(k)
                                                .chg_amt,
                                                'Y',
                                                pkg_detb_rtl_teller_rec.chg_in_acy_2,
                                                pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_2,
                                                p_err_params) THEN
                    debug.pr_debug('**', 'In When Others of EX RATE.');
                    debug.pr_debug('**', SQLERRM);
                    p_err_code   := 'ST-OTHR-001';
                    p_err_params := NULL;
                    --RETURN FALSE;ROLLBACK
                    DBG('ROLLINGBACK TO SAVEPOINT A');
                    ROLLBACK TO A;
                  END IF;
                ELSE
                  pkg_detb_rtl_teller_rec.chg_in_acy_2       := p_ifdofast.v_iftbs_fast_charge(k)
                                                                .chg_amt;
                  pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_2 := 1;
                END IF;
              
                pkg_detb_rtl_teller_rec.chg_in_lcy_2   := p_ifdofast.v_iftbs_fast_charge(k)
                                                          .lcy_chg;
                pkg_detb_rtl_teller_rec.acy_lcy_rate_2 := p_ifdofast.v_iftbs_fast_master.exch_rate;
                pkg_detb_rtl_teller_rec.netting_ind_2  := l_arc_maint.cod_chg_netting2;
                pkg_detb_rtl_teller_rec.txn_code_2     := l_arc_maint.cod_chg_txn_code2;
                pkg_detb_rtl_teller_rec.mis_head_3     := l_arc_maint.cod_mis_head2;
                pkg_detb_rtl_teller_rec.chg_desc2      := l_arc_maint.cod_chg_desc2;
                pkg_detb_rtl_teller_rec.chg_type2      := l_arc_maint.cod_chg_type2;
                pkg_detb_rtl_teller_rec.waiver2        := p_ifdofast.v_iftbs_fast_charge(k)
                                                          .waiver;
                pkg_detb_rtl_teller_rec.their_chgs2    := l_arc_maint.cod_their_chgs2;
              END IF;
            
              -- 4
              IF k = 4 THEN
                pkg_detb_rtl_teller_rec.chg_gl_3  := l_arc_maint.cod_chg_gl3;
                pkg_detb_rtl_teller_rec.chg_ccy_3 := l_arc_maint.cod_chg_ccy3;
                pkg_detb_rtl_teller_rec.chg_amt_3 := p_ifdofast.v_iftbs_fast_charge(k)
                                                     .chg_amt;
              
                depks_rtl_teller.pkg_arc_row.cod_chg_amt3 := p_ifdofast.v_iftbs_fast_charge(k)
                                                             .chg_amt;
              
                dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT3' ||
                    depks_rtl_teller.pkg_arc_row.cod_chg_amt3);
                depks_rtl_teller.pkg_arc_row.cod_chg_type3 := l_arc_maint.cod_chg_type3;
                IF l_arc_maint.cod_chg_ccy3 <> l_cust_ac.ccy THEN
                  IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                                l_arc_maint.cod_chg_ccy3,
                                                l_cust_ac.ccy,
                                                l_prod.rate_type_preferred,
                                                l_prod.rate_code_preferred,
                                                p_ifdofast.v_iftbs_fast_charge(k)
                                                .chg_amt,
                                                'Y',
                                                pkg_detb_rtl_teller_rec.chg_in_acy_3,
                                                pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_3,
                                                p_err_params) THEN
                    debug.pr_debug('**', 'In When Others of EX RATE.');
                    debug.pr_debug('**', SQLERRM);
                    p_err_code   := 'ST-OTHR-001';
                    p_err_params := NULL;
                    --RETURN FALSE;ROLLBACK
                    DBG('ROLLINGBACK TO SAVEPOINT A');
                    ROLLBACK TO A;
                  END IF;
                ELSE
                  pkg_detb_rtl_teller_rec.chg_in_acy_3       := p_ifdofast.v_iftbs_fast_charge(k)
                                                                .chg_amt;
                  pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_3 := 1;
                END IF;
              
                pkg_detb_rtl_teller_rec.chg_in_lcy_3   := p_ifdofast.v_iftbs_fast_charge(k)
                                                          .lcy_chg;
                pkg_detb_rtl_teller_rec.acy_lcy_rate_3 := p_ifdofast.v_iftbs_fast_master.exch_rate;
                pkg_detb_rtl_teller_rec.netting_ind_3  := l_arc_maint.cod_chg_netting3;
                pkg_detb_rtl_teller_rec.txn_code_3     := l_arc_maint.cod_chg_txn_code3;
                pkg_detb_rtl_teller_rec.mis_head_4     := l_arc_maint.cod_mis_head3;
                pkg_detb_rtl_teller_rec.chg_desc3      := l_arc_maint.cod_chg_desc3;
                pkg_detb_rtl_teller_rec.chg_type3      := l_arc_maint.cod_chg_type3;
                pkg_detb_rtl_teller_rec.waiver3        := p_ifdofast.v_iftbs_fast_charge(k)
                                                          .waiver;
                pkg_detb_rtl_teller_rec.their_chgs3    := l_arc_maint.cod_their_chgs3;
              END IF;
              -- 5
              IF k = 5 THEN
                pkg_detb_rtl_teller_rec.chg_gl_4  := l_arc_maint.cod_chg_gl4;
                pkg_detb_rtl_teller_rec.chg_ccy_4 := l_arc_maint.cod_chg_ccy4;
                pkg_detb_rtl_teller_rec.chg_amt_4 := p_ifdofast.v_iftbs_fast_charge(k)
                                                     .chg_amt;
              
                depks_rtl_teller.pkg_arc_row.cod_chg_amt4 := p_ifdofast.v_iftbs_fast_charge(k)
                                                             .chg_amt;
              
                dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT4' ||
                    depks_rtl_teller.pkg_arc_row.cod_chg_amt4);
                depks_rtl_teller.pkg_arc_row.cod_chg_type4 := l_arc_maint.cod_chg_type4;
                IF l_arc_maint.cod_chg_ccy4 <> l_cust_ac.ccy THEN
                  IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                                l_arc_maint.cod_chg_ccy4,
                                                l_cust_ac.ccy,
                                                l_prod.rate_type_preferred,
                                                l_prod.rate_code_preferred,
                                                p_ifdofast.v_iftbs_fast_charge(k)
                                                .chg_amt,
                                                'Y',
                                                pkg_detb_rtl_teller_rec.chg_in_acy_4,
                                                pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_4,
                                                p_err_params) THEN
                    debug.pr_debug('**', 'In When Others of EX RATE.');
                    debug.pr_debug('**', SQLERRM);
                    p_err_code   := 'ST-OTHR-001';
                    p_err_params := NULL;
                    --RETURN FALSE;ROLLBACK
                    DBG('ROLLINGBACK TO SAVEPOINT A');
                    ROLLBACK TO A;
                  END IF;
                ELSE
                  pkg_detb_rtl_teller_rec.chg_in_acy_4       := p_ifdofast.v_iftbs_fast_charge(k)
                                                                .chg_amt;
                  pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_4 := 1;
                END IF;
              
                pkg_detb_rtl_teller_rec.chg_in_lcy_4   := p_ifdofast.v_iftbs_fast_charge(k)
                                                          .lcy_chg;
                pkg_detb_rtl_teller_rec.acy_lcy_rate_4 := p_ifdofast.v_iftbs_fast_master.exch_rate;
                pkg_detb_rtl_teller_rec.netting_ind_4  := l_arc_maint.cod_chg_netting4;
                pkg_detb_rtl_teller_rec.txn_code_4     := l_arc_maint.cod_chg_txn_code4;
                pkg_detb_rtl_teller_rec.mis_head_5     := l_arc_maint.cod_mis_head4;
                pkg_detb_rtl_teller_rec.chg_desc4      := l_arc_maint.cod_chg_desc4;
                pkg_detb_rtl_teller_rec.chg_type4      := l_arc_maint.cod_chg_type4;
                pkg_detb_rtl_teller_rec.waiver4        := p_ifdofast.v_iftbs_fast_charge(k)
                                                          .waiver;
                pkg_detb_rtl_teller_rec.their_chgs4    := l_arc_maint.cod_their_chgs4;
              END IF;
            END LOOP;
            --Charge Pickup ends
          
            --BUILDING RT REC TYPE
            PKG_DETB_RTL_TELLER_REC.XREF         := L_TRN_REF_NO;
            PKG_DETB_RTL_TELLER_REC.PRODUCT_CODE := 'FSIN';
            PKG_DETB_RTL_TELLER_REC.BRANCH_CODE  := GLOBAL.CURRENT_BRANCH;
            PKG_DETB_RTL_TELLER_REC.TRN_REF_NO   := L_TRN_REF_NO;
            PKG_DETB_RTL_TELLER_REC.TXN_ACC      := L_CUST_AC.CUST_AC_NO;
            PKG_DETB_RTL_TELLER_REC.TXN_CCY      := L_CUST_AC.CCY;
            --PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := P_IFDOFAST.V_IFTBS_FAST_MASTER.BRANCH_CODE;
            PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := L_CUST_AC.BRANCH_CODE;
          
            PKG_DETB_RTL_TELLER_REC.OFS_ACC    := L_ARC_MAINT.COD_OFFSET_ACC;
            PKG_DETB_RTL_TELLER_REC.OFS_CCY    := 'KHR';
            PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT := L_AMT;
            PKG_DETB_RTL_TELLER_REC.TXN_AMOUNT := L_TXN_AMT;
            
            
            --PKG_DETB_RTL_TELLER_REC.CHG_AMT := 6000;
            --PKG_DETB_RTL_TELLER_REC.CHG_CCY := 'KHR';
            
            /*PKG_DETB_RTL_TELLER_REC.OFS_BRANCH := REPLACE(L_ARC_MAINT.COD_OFFSET_BRN,
            '*.*',
            GLOBAL.CURRENT_BRANCH);*/
            BEGIN
              SELECT BRANCH_CODE
                INTO PKG_DETB_RTL_TELLER_REC.OFS_BRANCH
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = PKG_DETB_RTL_TELLER_REC.OFS_ACC;
            EXCEPTION
              WHEN OTHERS THEN
                PKG_DETB_RTL_TELLER_REC.OFS_BRANCH := '991';
            END;
          
            PKG_DETB_RTL_TELLER_REC.TXN_TRN_CODE     := L_ARC_MAINT.COD_MAIN_TXN_CODE;
            PKG_DETB_RTL_TELLER_REC.OFS_TRN_CODE     := L_ARC_MAINT.COD_OFFSET_TXN_CODE;
            PKG_DETB_RTL_TELLER_REC.EXCH_RATE        := L_EXCH_RATE;
            PKG_DETB_RTL_TELLER_REC.TRN_DT           := GLOBAL.APPLICATION_DATE;
            PKG_DETB_RTL_TELLER_REC.VALUE_DT         := GLOBAL.APPLICATION_DATE;
            PKG_DETB_RTL_TELLER_REC.REL_CUSTOMER     := L_CUST_AC.CUST_NO;
            PKG_DETB_RTL_TELLER_REC.BENEF_NAME       := L_CUST.CUSTOMER_NAME1;
            PKG_DETB_RTL_TELLER_REC.BENEF_ADDR1      := L_CUST.ADDRESS_LINE1;
            PKG_DETB_RTL_TELLER_REC.BENEF_ADDR2      := L_CUST.ADDRESS_LINE2;
            PKG_DETB_RTL_TELLER_REC.BENEF_ADDR3      := L_CUST.ADDRESS_LINE3;
            PKG_DETB_RTL_TELLER_REC.BENEF_ADDR4      := L_CUST.ADDRESS_LINE4;
            PKG_DETB_RTL_TELLER_REC.LIQN_DT          := GLOBAL.APPLICATION_DATE;
            PKG_DETB_RTL_TELLER_REC.RECORD_STAT      := 'A';
            PKG_DETB_RTL_TELLER_REC.AUTH_STAT        := 'U';
            PKG_DETB_RTL_TELLER_REC.MAKER_ID         := GLOBAL.USER_ID;
            PKG_DETB_RTL_TELLER_REC.MAKER_DT_STAMP   := FN_SYSDATE;
            PKG_DETB_RTL_TELLER_REC.CHECKER_ID       := GLOBAL.USER_ID;
            PKG_DETB_RTL_TELLER_REC.CHECKER_DT_STAMP := FN_SYSDATE;
            PKG_DETB_RTL_TELLER_REC.MOD_NO           := 1;
            PKG_DETB_RTL_TELLER_REC.SCODE            := 'FLEXCUBE';
            PKG_DETB_RTL_TELLER_REC.DR_ACC           := L_ARC_MAINT.DR_ACC;
            PKG_DETB_RTL_TELLER_REC.MODULE           := 'RT';
            PKG_DETB_RTL_TELLER_REC.ESN              := 1;
            PKG_DETB_RTL_TELLER_REC.EVENT_CODE       := 'INIT';
            PKG_DETB_RTL_TELLER_REC.TRACK_RECEIVABLE := 'N';
            PKG_DETB_RTL_TELLER_REC.TIME_RECEIVED    := SYSDATE;
          
            --SAVE TRANSACTION
            DBG('CALLING DEPKS_RTL_TELLER.FN_SAVE');
            IF NOT DEPKS_RTL_TELLER.FN_SAVE(PKG_DETB_RTL_TELLER_REC,
                                            P_ERR_CODE,
                                            P_ERR_PARAMS) THEN
              DBG('Failed in Fn_Save=');
              DBG('P_ERR_CODE=' || P_ERR_CODE);
              DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);
              DBG('ROLLINGBACK TO SAVEPOINT A');
              ROLLBACK TO A;
              PR_UPDATE_DOC_TRACKER(L_MSG_ID,
                                    'E',
                                    P_ERR_CODE,
                                    P_ERR_PARAMS);
              COMMIT;
            
            ELSE
            
              DBG('Success in Fn_Save');
              DBG('P_ERR_CODE=' || P_ERR_CODE);
              DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);
              --AUTH TRANSACTION
              DBG('CALLING DEPKS_RTL_TELLER.FN_RTL_TELLER_AUTH');
              IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(L_CUST_AC.BRANCH_CODE,
                                                          L_TRN_REF_NO,
                                                          GLOBAL.USER_ID,
                                                          GLOBAL.LCY,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
                DBG('AUTH RETRUNED FALSE' || P_ERR_CODE);
                DBG('FAILED TO PROCESS TRANSACTION');
                DBG('ROLLINGBACK TO SAVEPOINT A');
                ROLLBACK TO A;
                PR_UPDATE_DOC_TRACKER(L_MSG_ID,
                                      'E',
                                      P_ERR_CODE,
                                      P_ERR_PARAMS);
                COMMIT;
                --PR_TRN_STATUS_UPDATE(R.MSGID, L_SEQ, 'F', '03');
              ELSE
                --Inserting Incoming Fast Transaction into a master table
                PR_INSERT_FAST_INCOMING('FLEXCUBE',
                                        GLOBAL.CURRENT_BRANCH,
                                        'I',
                                        'F',
                                        L_TRN_REF_NO,
                                        PKG_DETB_RTL_TELLER_REC.PRODUCT_CODE,
                                        PKG_DETB_RTL_TELLER_REC.TRN_DT,
                                        PKG_DETB_RTL_TELLER_REC.OFS_CCY,
                                        PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT,
                                        NULL,
                                        L_TXN_AMT, --PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT, --CHECK THIS
                                        PKG_DETB_RTL_TELLER_REC.EXCH_RATE,
                                        NULL, --TXN STATUS
                                        NULL, --REMARKS
                                        L_MSG_ID, --MSG_ID
                                        NULL, --PAY_ID
                                        PKG_DETB_RTL_TELLER_REC.OFS_ACC,
                                        NULL, --OFF ACC NAME
                                        NULL, --REMITER ADDRESS1
                                        NULL, --REMITER ADDRESS2
                                        NULL, --REMITER ADDRESS3
                                        NULL, --REMITER ADDRESS4
                                        PKG_DETB_RTL_TELLER_REC.TXN_ACC,
                                        L_CRTRAGT_BICFI,
                                        PKG_DETB_RTL_TELLER_REC.BENEF_NAME,
                                        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR1,
                                        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR2,
                                        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR3,
                                        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR4,
                                        NULL, --REMARKS
                                        NULL, --BEN PHONE
                                        NULL, --BEN MAIL
                                        NULL, --INSTR ID
                                        L_ENDTOENDID, --END TO END ID
                                        PKG_DETB_RTL_TELLER_REC.MAKER_ID,
                                        PKG_DETB_RTL_TELLER_REC.MAKER_DT_STAMP,
                                        PKG_DETB_RTL_TELLER_REC.CHECKER_ID,
                                        PKG_DETB_RTL_TELLER_REC.CHECKER_DT_STAMP,
                                        'A',
                                        'O',
                                        'Y',
                                        1);
              
                --Get Ack Message
                L_FORMATTED_MSG := FN_RETURN_ACK_MSG;
              
                DBG('BEFORE REPLACEMENT OF ACK XML=' || L_FORMATTED_MSG);
              
                L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                           '$L_MSG_ID',
                                           L_MSG_ID);
              
                L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                           '$L_CREDTTM',
                                           L_CREDTTM);
              
                L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                           '$L_INITGPTY_NM',
                                           L_INITGPTY_NM);
              
                L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                           '$L_CRTRAGT_BICFI',
                                           L_CRTRAGT_BICFI);
              
                L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                           '$L_DBTRAGT_BICFI',
                                           L_DBTRAGT_BICFI);
              
                L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                           '$L_PMTINFID',
                                           L_PMTINFID);
              
                L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                           '$L_ENDTOENDID',
                                           L_ENDTOENDID);
              
                L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMT', L_AMT);
              
                L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                           '$L_DBTR_NM',
                                           L_DBTR_NM);
              
                L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                           '$L_CDTR_NM',
                                           L_CDTR_NM);
              
                DBG('AFTER REPLACEMENT OF ACK XML=' || L_FORMATTED_MSG);
              
                --Log Ack Request to NBC
                DBG('LOGGING ACK REQUEST TO NBC');
                PR_INSERT_FAST_WS_LOG(L_MSG_ID,
                                      L_GEN_SEQ_NO,
                                      L_TRN_REF_NO,
                                      SYSDATE,
                                      'Ack',
                                      L_FORMATTED_MSG,
                                      'I',
                                      NULL,
                                      'Ack for Incoming');
              
                IF NOT IFPKS_IFDOFAST_CUSTOM.FN_FAST_HTTP_CALL('F',
                                                               L_FORMATTED_MSG,
                                                               L_IN_RESP) THEN
                  DBG('FAILED IN ACKNOWLEDGING THE ORIGINAL INCOMING TXN');
                  DBG('ROLLINGBACK TO SAVEPOINT A');
                  ROLLBACK TO A;
                  PR_UPDATE_DOC_TRACKER(L_MSG_ID,
                                        'E',
                                        P_ERR_CODE,
                                        P_ERR_PARAMS);
                  COMMIT;
                ELSE
                  DBG('SUCCESS IN ACKNOWLEDGING THE ORIGINAL FAST INCOMING TXN');
                
                  --Log Ack Resonse
                  L_IN_RESP := REPLACE(L_IN_RESP, '&lt;', '<');
                  L_IN_RESP := REPLACE(L_IN_RESP, '&gt;', '>');
                
                  --Get Cosmetic XML
                  PR_RETURN_COSMETIC_XML(L_IN_RESP, L_COSMETIC_RES_MSG);
                
                  DBG('L_COSMETIC_RES_MSG OF ACK RESPONSE=' ||
                      L_COSMETIC_RES_MSG);
                
                  --Convert into XMLTYPE
                  P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
                
                  --Get Node Value
                  L_TXN_STATUS := P_DOCUMENT_XML.EXTRACT('/Document/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/TxSts/text()')
                                  .getstringval;
                
                  DBG('L_TXN_STATUS=' || L_TXN_STATUS);
                
                  IF L_TXN_STATUS = 'RJCT' THEN
                    DBG('ROLLINGBACK TO SAVEPOINT A');
                    ROLLBACK TO A;
                  
                    DBG('LOGGING ACK RESPONSE FROM NBC');
                    PR_UPDATE_FAST_WS_LOG(L_MSG_ID,
                                          L_GEN_SEQ_NO,
                                          L_TXN_STATUS,
                                          L_IN_RESP);
                  
                    --Update status to processed for current row
                    PR_UPDATE_DOC_TRACKER(L_MSG_ID,
                                          'E',
                                          P_ERROR_CODE,
                                          P_ERROR_MSG);
                  
                    COMMIT;
                  ELSE
                  
                    DBG('LOGGING ACK RESPONSE FROM NBC');
                  
                    PR_UPDATE_FAST_WS_LOG(L_MSG_ID,
                                          L_GEN_SEQ_NO,
                                          L_TXN_STATUS,
                                          L_IN_RESP);
                  
                    PR_UPDATE_STATUS_FAST_INCOMING(L_TRN_REF_NO,
                                                   L_TXN_STATUS);
                  
                    DBG('SUCCESS IN ACKNOWLEDGING THE FAST INCOMING TRANSACTION');
                  
                    --Update status to processed for current row
                    PR_UPDATE_DOC_TRACKER(L_MSG_ID, 'P', NULL, NULL);
                  
                    COMMIT;
                  
                  END IF;
                
                END IF;
              
              END IF; --Fn_Auth End If
            END IF; --Fn_Save End If
          
          END IF; --Frozen Dormant End If
        
          /*
          BEGIN
            select BRANCH_CODE, CCY, cust_ac_no
              INTO l_ty_rtupld.ty_upld_rtl_teller.ofs_branch,
                   l_ty_rtupld.ty_upld_rtl_teller.ofs_ccy,
                   l_ty_rtupld.ty_upld_rtl_teller.ofs_acc
              from sttm_cust_account
             where cust_Ac_no = R.CRACC;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FAILED TO GET BENEFICIARY DETAILS' || SQLERRM);
              PR_TRN_STATUS_UPDATE(R.MsgId, L_SEQ, 'F', '01');
              RETURN FALSE;
          END;
          
          IF R.CtrlSum <> R.INSTDAMT THEN
            DBG('Instruction amount and control sum are not equal');
            PR_TRN_STATUS_UPDATE(R.MsgId, L_SEQ, 'F', '02');
            RETURN FALSE;
          END IF;
          
          SELECT COUNT(1)
            INTO l_bic_count
            FROM DETB_FAST_BIC_CODE_CUSTOM
           WHERE BIC_CODE = R.DRBICFI;
          IF l_bic_count <= 0 THEN
            DBG('Bic is not maintained');
            PR_TRN_STATUS_UPDATE(R.MsgId, L_SEQ, 'F', '04');
            RETURN FALSE;
          END IF;*/
        
          DBG('END OF PR_PROCESS_FAST_INCOMING_TXN');
        
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN PROCESSING CURRENT INCOMING MESSAGE ID=' ||
              L_MSG_ID);
          CONTINUE;
      END;
    END LOOP;
    -- RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_FAST_INCOMING_TXN');
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      -- RETURN FALSE;
  
  END PR_PROCESS_FAST_INCOMING_TXN;

  --Simple Job to process incoming fast transactions
  PROCEDURE PR_PROCESS_FAST_INCOMING(PARAMNAME  VARCHAR2,
                                     PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    DEBUG.PR_DEBUG('IF', 'Inside PR_PROCESS_FAST_INCOMING');
  
    DEBUG.PR_DEBUG('IF', 'paramName = ' || PARAMNAME);
    DEBUG.PR_DEBUG('IF', 'paramValue = ' || PARAMVALUE);
  
    PR_PROCESS_FAST_INCOMING_TXN;
  
    DEBUG.PR_DEBUG('IF', 'Successful return from PR_PROCESS_FAST_INCOMING');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'Exception during PR_PROCESS_FAST_INCOMING' || SQLERRM);
  END PR_PROCESS_FAST_INCOMING;

  --Simple Job to insert incoming fast transactions into CBS
  PROCEDURE PR_FAST_INCOMING_HANDOFF(P_PARAM_NAME IN VARCHAR2,
                                     PARAMVALUE   VARCHAR2) IS
  
    L_RESPONSE              VARCHAR2(32767);
    L_SNIPPET               XMLTYPE;
    L_IX                    BINARY_INTEGER;
    L_TEXT                  CLOB;
    L_START                 NUMBER := 1;
    L_END                   NUMBER := 0;
    L_NO_OF_DOCUMENTS       NUMBER := 0;
    L_DOCUMENT              CLOB;
    L_INCOMING_REQUEST_MSG  CLOB;
    L_INCOMING_RESPONSE_MSG CLOB;
    E_UPDATE_ERROR EXCEPTION;
    P_ERR_CODE   VARCHAR2(1000);
    P_ERR_PARAMS VARCHAR2(1000);
  
  BEGIN
  
    --Call getIncomingAPI Webservice
    GLOBAL.PR_INIT('000', 'SYSTEM');
  
    --Get Incoming message
    L_INCOMING_REQUEST_MSG := FN_RETURN_INCOMING_MSG;
  
    DBG('L_INCOMING_REQUEST_MSG=' || L_INCOMING_REQUEST_MSG);
  
    IF NOT
        IFPKS_IFDOFAST_CUSTOM.FN_FAST_HTTP_CALL('F',
                                                L_INCOMING_REQUEST_MSG,
                                                L_INCOMING_RESPONSE_MSG) THEN
      DBG('FAILED TO SEND PAIN_001_001_05');
      --RAISE E_UPDATE_ERROR;
    ELSE
      DBG('SUCCESS...WE GOT RESPONSE FROM FAST GETINCOMING API');
    END IF;
  
    --DBG('L_INCOMING_RESPONSE_MSG='||L_INCOMING_RESPONSE_MSG);
  
    L_INCOMING_RESPONSE_MSG := REPLACE(L_INCOMING_RESPONSE_MSG, '&lt;', '<');
    L_INCOMING_RESPONSE_MSG := REPLACE(L_INCOMING_RESPONSE_MSG, '&gt;', '>');
  
    --DBG('LIST OF INCOMING FAST TRANSACTIONS='||L_INCOMING_RESPONSE_MSG);
  
    L_NO_OF_DOCUMENTS := (LENGTH(L_INCOMING_RESPONSE_MSG) -
                         LENGTH(REPLACE(L_INCOMING_RESPONSE_MSG,
                                         '</Document>',
                                         ''))) / length('</Document>');
    DBG('L_NO_OF_DOCUMENTS=' || L_NO_OF_DOCUMENTS);
  
    FOR G IN 1 .. L_NO_OF_DOCUMENTS LOOP
      L_START := INSTR(L_INCOMING_RESPONSE_MSG, '<Document ', l_start, G);
      L_END   := INSTR(L_INCOMING_RESPONSE_MSG, '</Document>', l_start, 1);
    
      L_DOCUMENT := SUBSTR(L_INCOMING_RESPONSE_MSG,
                           L_START,
                           L_END - L_START + LENGTH('</Document>'));
    
      L_START := 1;
    
      DBG('L_DOCUMENT=' || L_DOCUMENT);
    
      --INSERT THE DOCUMENT
      PR_INSERT_DOC_TRACKER(L_DOCUMENT);
    
      --DBG('PASS THIS DOCUMENT TO YOUR STUB');
    
      --PR_DO_FAST_INCOMING(L_DOCUMENT, P_ERR_CODE, P_ERR_PARAMS);
    
      --DBG(substr(l_response,l_start,l_end-l_start+length('</Document>')));
      DBG('-------------------');
    END LOOP;
  
    -- RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      -- RETURN FALSE;
  END PR_FAST_INCOMING_HANDOFF;

END IFPKS_FAST_INCOMING;
/