insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('FAST_MEMBERS', 'Fast Payment Participant Codes', 'SAMPATH1', 'SAMPATH1', to_date('20-02-2019 08:41:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-02-2019 08:41:49', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '5', 'Y');

COMMIT;
