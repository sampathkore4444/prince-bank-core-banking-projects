insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_IN_STATUS', 'After FAST settlement session, transaction is settled successfully at FAST system receiving bank', 'STTL');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_IN_STATUS', 'Transaction is acknowledged by the receiving party to confirm fund has been credited', 'ACSC');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_IN_STATUS', 'Transaction is made successfully and well received at FAST System', 'ACSP');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_IN_STATUS', 'Transaction is received from sending bank', 'RCVD');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_IN_STATUS', 'Transaction is refunded by receiver', 'RCFI');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_OUT_STATUS', 'After FAST settlement session, transaction cannot be settled due to insufficient session', 'STLF');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_OUT_STATUS', 'After FAST settlement session, transaction is settled successfully at FAST system bank', 'STTL');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_OUT_STATUS', 'Transaction is acknowledged by the receiving party to confirm fund has been credited', 'ACSC');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_OUT_STATUS', 'Transaction is closed by Checker but rejected by Authorizer', 'RJCT');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_OUT_STATUS', 'Transaction is delivered to receiving bank but fail due to Wrong encryption key/ISO Schema/Signature', 'FLFI');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_OUT_STATUS', 'Transaction is made but fail to deliver at FAST System due to wrong encryption key/ISO Schema/Signature/Participant Code', 'FACH');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_OUT_STATUS', 'Transaction is made by Operator and Checked by Checker. The batch is closed', 'CHCL');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_OUT_STATUS', 'Transaction is made by Operator but canceled by Checker', 'CNCL');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_OUT_STATUS', 'Transaction is made by Operator but not yet checked', 'PDNG');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_OUT_STATUS', 'Transaction is made successfully and well received at FAST System', 'ACSP');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_OUT_STATUS', 'Transaction is made successfully but not yet received at FAST System', 'SENT');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('FAST_OUT_STATUS', 'Transaction is well received at receiving bank but no acknowledgement to transaction', 'RCFI');

COMMIT;
