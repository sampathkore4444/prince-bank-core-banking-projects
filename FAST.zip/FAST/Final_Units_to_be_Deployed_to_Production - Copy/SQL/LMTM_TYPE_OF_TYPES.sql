
insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('FAST_IN_STATUS', 'Fast Incoming Transaction Statuses', 'SAMPATH1', 'SAMPATH1', to_date('20-02-2019 15:23:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-02-2019 15:23:17', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('FAST_OUT_STATUS', 'Fast Outgoing Transaction Statuses', 'SAMPATH1', 'SAMPATH1', to_date('20-02-2019 15:27:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-02-2019 15:27:28', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');


COMMIT;