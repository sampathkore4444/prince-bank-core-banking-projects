create sequence TRSQ_MSGID
minvalue 1
maxvalue 999999999
start with 1
increment by 1
nocache
cycle
/

create sequence TRSQ_FAST_SEQID
minvalue 1
maxvalue 999999999
start with 1
increment by 1
nocache
cycle
/

create table IFTB_FAST_MASTER
(
  source_code      VARCHAR2(16),
  branch_code      VARCHAR2(3),
  msg_flow         VARCHAR2(1),
  transfer_mode    VARCHAR2(1),
  trn_ref_no       VARCHAR2(20) not null,
  product_code     VARCHAR2(4),
  transfer_date    DATE,
  txn_ccy          VARCHAR2(3),
  txn_amt          NUMBER(22,3),
  tot_chg_amt      NUMBER(22,3),
  net_txn_amt      NUMBER(22,3),
  exch_rate        NUMBER(24,12),
  txn_status       VARCHAR2(20),
  txn_remarks      VARCHAR2(255),
  msg_id           VARCHAR2(35),
  pay_id           VARCHAR2(35),
  rem_acc          VARCHAR2(100),
  rem_name         VARCHAR2(100),
  rem_add1         VARCHAR2(105),
  rem_add2         VARCHAR2(105),
  rem_add3         VARCHAR2(105),
  rem_add4         VARCHAR2(105),
  ben_acc          VARCHAR2(22),
  ben_bic          VARCHAR2(100),
  ben_name         VARCHAR2(100),
  ben_add1         VARCHAR2(105),
  ben_add2         VARCHAR2(105),
  ben_add3         VARCHAR2(105),
  ben_add4         VARCHAR2(105),
  ben_remarks      VARCHAR2(255),
  ben_phone        VARCHAR2(20),
  ben_email        VARCHAR2(105),
  instr_id         VARCHAR2(35),
  etend_id         VARCHAR2(35),
  maker_id         VARCHAR2(12),
  maker_dt_stamp   DATE,
  checker_id       VARCHAR2(12),
  checker_dt_stamp DATE,
  auth_stat        VARCHAR2(1),
  record_stat      VARCHAR2(1),
  once_auth        VARCHAR2(1),
  mod_no           NUMBER(4)
)
/
alter table IFTB_FAST_MASTER add primary key (TRN_REF_NO)
/
CREATE OR REPLACE SYNONYM IFTBS_FAST_MASTER FOR IFTB_FAST_MASTER
/
create table IFTB_FAST_CHARGE
(
  trn_ref_no  VARCHAR2(20) not null,
  chg_srno    NUMBER(1) not null,
  chg_desc    VARCHAR2(255),
  waiver      VARCHAR2(1),
  chg_amt     NUMBER(22,3),
  chg_ccy     VARCHAR2(3),
  lcy_chg     NUMBER(22,3),
  fcy_chg     NUMBER(22,3),
  chg_gl      VARCHAR2(20),
  netting_req CHAR(1),
  xrate       NUMBER(22,10),
  txn_code    VARCHAR2(3),
  chg_type    VARCHAR2(1),
  chg_in_txn  NUMBER(22,3),
  chg_in_acc  NUMBER(22,3),
  oth_ccy     VARCHAR2(3),
  txn_xrate   NUMBER(22,10),
  acc_xrate   NUMBER(22,10)
)
/
alter table IFTB_FAST_CHARGE add primary key (TRN_REF_NO, CHG_SRNO)
/
CREATE OR REPLACE SYNONYM IFTBS_FAST_CHARGE FOR IFTB_FAST_CHARGE
/
create table IFTB_FAST_INCOMING_TRACK
(
  msg_id      VARCHAR2(35) not null,
  inc_req_msg CLOB,
  status      CHAR(1),
  time_in     DATE,
  error_code  VARCHAR2(11),
  error_msg   VARCHAR2(4000)
)
/
alter table IFTB_FAST_INCOMING_TRACK add primary key (MSG_ID)
/
CREATE OR REPLACE SYNONYM IFTBS_FAST_INCOMING_TRACK FOR IFTB_FAST_INCOMING_TRACK
/
create table IFTB_PGW_MSGS
(
  msg_id     VARCHAR2(35),
  trn_ref_no VARCHAR2(20),
  trn_mode   VARCHAR2(1),
  req_xml    CLOB,
  resp_xml   CLOB,
  init_date  DATE,
  msg_flow   VARCHAR2(1),
  msg_status VARCHAR2(1)
)
/
CREATE OR REPLACE SYNONYM IFTBS_PGW_MSGS FOR IFTB_PGW_MSGS
/
create table STTB_FAST_WS_LOG
(
  msg_id        VARCHAR2(35),
  trn_ref_no    VARCHAR2(16),
  invoke_date   DATE,
  req_type      VARCHAR2(20),
  req_msg       CLOB,
  res_msg       CLOB,
  payment_type  CHAR(1),
  status        VARCHAR2(10),
  refund_reason VARCHAR2(255),
  addl_info     VARCHAR2(255),
  seq_no        VARCHAR2(100)
)
/
CREATE OR REPLACE SYNONYM STTBS_FAST_WS_LOG FOR STTB_FAST_WS_LOG
/
create table CSTB_PARAM_CUSTOM
(
  param_name   VARCHAR2(30) not null,
  param_val    VARCHAR2(255),
  modify_field CHAR(1) default 'N'
)
/
alter table CSTB_PARAM_CUSTOM
  add primary key (PARAM_NAME)
/
CREATE OR REPLACE SYNONYM CSTBS_PARAM_CUSTOM FOR CSTB_PARAM_CUSTOM
/