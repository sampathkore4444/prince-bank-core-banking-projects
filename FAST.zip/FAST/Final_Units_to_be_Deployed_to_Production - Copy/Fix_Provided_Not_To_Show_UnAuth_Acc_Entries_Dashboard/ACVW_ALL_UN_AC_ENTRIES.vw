CREATE OR REPLACE VIEW ACVW_ALL_UN_AC_ENTRIES AS
SELECT
       TRN_REF_NO
     , AC_ENTRY_SR_NO
     , EVENT_SR_NO
     , EVENT
     , AC_BRANCH
     , AC_NO
     , AC_CCY
     , CATEGORY
     , DRCR_IND
     , TRN_CODE
     , FCY_AMOUNT
     , EXCH_RATE
     , LCY_AMOUNT
     , TRN_DT
     , VALUE_DT
     ,TXN_INIT_DATE
     ,AMOUNT_TAG
	 ,RELATED_ACCOUNT
     ,RELATED_CUSTOMER
	 ,RELATED_REFERENCE
	 ,MIS_HEAD
	 ,MIS_FLAG
     ,INSTRUMENT_CODE
     ,BANK_CODE
     ,BALANCE_UPD
     ,AUTH_STAT
     ,MODULE
	 ,CUST_GL
	 ,'D' DLY_HIST
	 , FINANCIAL_CYCLE
	 , PERIOD_CODE
     , BATCH_NO
     , USER_ID
     , CURR_NO
     , PRINT_STAT
	 , AUTH_ID
     , GLMIS_VAL_UPD_FLAG
     ,EXTERNAL_REF_NO
     ,dont_showin_stmt
	 ,ic_bal_inclusion
	 ,aml_exception
	 ,IB
	 ,GLMIS_UPDATE_FLAG
	 ,PRODUCT_ACCRUAL
	 ,ORIG_PNL_GL
	 ,STMT_DT
     ,ENTRY_SEQ_NO
     ,VIRTUAL_AC_NO
     ,claim_amount
     ,grp_ref_no
     ,save_timestamp
     ,auth_timestamp
     ,product_processor, related_ac_entry_sr_no --FA-DA-12.4_ITR1-279
	 FROM ACTBS_DAILY_LOG
	 WHERE DELETE_STAT <> 'D'
   AND AUTH_STAT ='A' --sampath fix added this in where condition
	UNION
	SELECT
       A.TRN_REF_NO
     , A.AC_ENTRY_SR_NO
     , A.EVENT_SR_NO
     , A.EVENT
     , A.AC_BRANCH
     , A.AC_NO
     , A.AC_CCY
     , A.CATEGORY
     , A.DRCR_IND
     , A.TRN_CODE
     , A.FCY_AMOUNT
     , A.EXCH_RATE
     , A.LCY_AMOUNT
     , A.TRN_DT
     , A.VALUE_DT
     ,A.TXN_INIT_DATE
     ,A.AMOUNT_TAG
	 ,A.RELATED_ACCOUNT
     ,A.RELATED_CUSTOMER
	 ,A.RELATED_REFERENCE
	 ,A.MIS_HEAD
	 ,A.MIS_FLAG
     ,A.INSTRUMENT_CODE
     ,A.BANK_CODE
     ,A.BALANCE_UPD
     ,nvl((SELECT 'A'
              FROM ACTB_ACSERVICE_HANDOFF B
              WHERE B.GRP_REF_NO = A.GRP_REF_NO
              AND   B.TRN_REF_NO = A.TRN_REF_NO
              AND   B.EVENT_SR_NO = A.EVENT_SR_NO
              AND   B.ACTION_CODE ='A'), A.AUTH_STAT) AUTH_STAT --,A.AUTH_STAT --FA-DA-12.4_ITR1-187
     ,A.MODULE
	 ,A.CUST_GL
	 ,'D' DLY_HIST
	 ,A.FINANCIAL_CYCLE
	 ,A.PERIOD_CODE
     ,A.BATCH_NO
     ,A.USER_ID
     ,A.CURR_NO
     ,CAST(NULL AS CHAR(1)) PRINT_STAT
	 ,A.AUTH_ID
     ,CAST(NULL AS CHAR(1)) GLMIS_VAL_UPD_FLAG
     ,A.EXTERNAL_REF_NO
     ,A.dont_showin_stmt
	 ,CAST(NULL AS CHAR(1)) ic_bal_inclusion
	 ,CAST (NULL AS VARCHAR2(1)) aml_exception
	 ,A.IB
	 ,CAST(NULL AS VARCHAR2(1)) GLMIS_UPDATE_FLAG
	 ,CAST(NULL AS VARCHAR2(1)) PRODUCT_ACCRUAL
	 ,CAST(NULL AS VARCHAR2(9)) ORIG_PNL_GL
	 ,A.STMT_DT
     ,A.ENTRY_SEQ_NO
     ,A.VIRTUAL_AC_NO
     ,A.claim_amount
     ,A.grp_ref_no
     ,A.save_timestamp
     ,A.auth_timestamp
     ,A.product_processor, null as related_ac_entry_sr_no --FA-DA-12.4_ITR1-279
     FROM ACTB_ENTRIES_HANDOFF A
            WHERE A.TXN_STAT <> 'P' --='U' --FA-DA-12.4_ITR1-187
			AND NOT EXISTS (SELECT 1
							FROM ACTB_ACSERVICE_HANDOFF B
							WHERE B.GRP_REF_NO = A.GRP_REF_NO
							AND   B.TRN_REF_NO = A.TRN_REF_NO
							AND   B.EVENT_SR_NO = A.EVENT_SR_NO
							AND   B.ACTION_CODE ='D')
    UNION ALL
       SELECT TRN_REF_NO,
	   AC_ENTRY_SR_NO,
	   EVENT_SR_NO,
	   EVENT,
	   AC_BRANCH,
	   AC_NO,
	   AC_CCY,
      CATEGORY,
	  DRCR_IND,
	  TRN_CODE,
	  FCY_AMOUNT,
	  EXCH_RATE,
	  LCY_AMOUNT,
	  TRN_DT,
	  VALUE_DT,
	  TXN_INIT_DATE,
	  amount_tag,
	  related_account,
	  related_customer,
	  related_reference
	  ,MIS_HEAD
	  ,MIS_FLAG
	  ,instrument_code
	  , bank_code
	  , 'U'
	  , 'A'
	  , module
	  ,CUST_GL
	  ,'H'
	  , FINANCIAL_CYCLE
	  , PERIOD_CODE
	  ,BATCH_NO
	  ,USER_ID
	  ,CURR_NO
	  ,PRINT_STAT
	  , Auth_id
	  ,GLMIS_VAL_UPD_FLAG
	  ,EXTERNAL_REF_NO
	  ,dont_showin_stmt
	  ,ic_bal_inclusion
	  ,aml_exception
	  ,IB
	  ,GLMIS_UPDATE_FLAG
	  ,PRODUCT_ACCRUAL
	  ,ORIG_PNL_GL
	  ,STMT_DT
	  ,ENTRY_SEQ_NO
      ,VIRTUAL_AC_NO
      ,claim_amount
      ,grp_ref_no
      ,save_timestamp
      ,auth_timestamp
      ,product_processor, related_ac_entry_sr_no --FA-DA-12.4_ITR1-279
 FROM
 ACTBS_HISTORY
;
