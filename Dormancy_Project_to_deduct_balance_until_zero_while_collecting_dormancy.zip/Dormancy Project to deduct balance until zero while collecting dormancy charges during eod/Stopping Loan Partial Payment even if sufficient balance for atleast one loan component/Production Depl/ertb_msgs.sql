update ertb_msgs set batch_type = 'O' where err_code = 'AC-OVD05' and language = 'ENG'
/
