CREATE OR REPLACE PACKAGE BODY IFPKS_SVCARD_DETAILS_CUSTOM IS

  /*
          -----------------------------------------------------------------------------------------------------------------

          =================================================================================================================
          ****************************************    CHANGE HISTORY      *************************************************
          =================================================================================================================

              CREATED BY    : Techurate Dev Team
              CREATED ON    : 12-DEC-2018
			  
			   MODIFIED BY    : Kore Sampath Kumar
            MODIFIED ON    : 16-SEP-2021
            MODIFIED REASON: Stopped all flows for Instant Card Project
            SEARCH STRING  : instant card project


  */

  PROCEDURE DBG(LINE IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('IF', 'IFPKS_SVCARD_DETAILS_CUSTOM-->' || LINE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed IN IFPKS_SVCARD_DETAILS_CUSTOM.DBMS_OUTPUT.PUT_LINE');
      DBG(SQLERRM);
  END;

  FUNCTION FN_GENERATE_ADD_NEW_CUST RETURN BOOLEAN IS

    /*SV_MESSAGE_ADD_NEW_CUST CONSTANT VARCHAR2(32767) := '<application xmlns=' ||
                                                            CHR(34) ||
                                                            'http://sv.bpc.in/SVAP' ||
                                                            CHR(34) || '>
      <application_type>APTPISSA</application_type>
      <application_flow_id>$XML_TYPE</application_flow_id>
      <application_status>APST0006</application_status>
      <operator_id>admin</operator_id>
      <institution_id>1001</institution_id>' ||
                                                           -- <agent_id>70000359</agent_id> -- removed and added branch code tag
                                                            '<agent_number>$BRANCH_CODE</agent_number>
      <customer_type>ENTTPERS</customer_type>
      <customer id=' ||
                                                            CHR(34) ||
                                                            'customer_1' ||
                                                            CHR(34) || '>
        ' ||
                                                           -- <command>CMMDCREX</command>-- Changed the Command
                                                            ' <command>CMMDCRUP</command>
        <customer_number>$CUSTOMER_NO</customer_number>
        <resident>$RES_STAT</resident>
        <contract>
          <command>CMMDCREX</command>
          <contract_type>CNTPINIC</contract_type>
          <product_id>$PRODUCT_ID</product_id>
          <card id=' ||
                                                            CHR(34) || 'card_1' ||
                                                            CHR(34) || '>
            <command>CMMDCRUP</command>
            <card_id>$CARD_ID</card_id>
            <card_type>8060</card_type>
            <cardholder>
              <command>CMMDCREX</command>
              <cardholder_number>$CARDHOLDER_NO</cardholder_number>
              <cardholder_name>$FULL_NAME</cardholder_name>
              <person>
                <command>CMMDCRUP</command>
                <person_name language=' ||
                                                            CHR(34) ||
                                                            'LANGENG' ||
                                                            CHR(34) || '>
                  <surname>$LAST_NAME</surname>
                  <first_name>$FIRST_NAME</first_name>
                </person_name>
                <birthday>$DOB</birthday>
              </person>
              <contact>
                <command>CMMDEXPR</command>
                <contact_type>CNTTPRMC</contact_type>
                <preferred_lang>LANGENG</preferred_lang>
                <contact_data>
                  <commun_method>CMNM0001</commun_method>
                  <commun_address>$MOBILE_NUMBER</commun_address>
                </contact_data>
              </contact>
              <sec_word>
                <secret_question>SEQUWORD</secret_question>
                <secret_answer>INSTANT</secret_answer>
              </sec_word>

          <notification>
          <command>CMMDCRUP</command>
          <delivery_channel>3</delivery_channel>
          <delivery_address>$MOBILE_NUMBER</delivery_address>
          <is_active>1</is_active>
          <service_number>302</service_number>
        </notification>
         <notification>
          <command>CMMDCRUP</command>
          <delivery_channel>1</delivery_channel>
          <delivery_address>$EMAIL_ID</delivery_address>
          <is_active>1</is_active>
        </notification>
        </cardholder>
          </card>
          <service value=' ||
                                                            CHR(34) ||
                                                            '70000002' ||
                                                            CHR(34) || '>
            <service_object ref_id=' ||
                                                            CHR(34) || 'card_1' ||
                                                            CHR(34) || ' />
          </service>
          <service value=' ||
                                                            CHR(34) ||
                                                            '70000003' ||
                                                            CHR(34) || '>
            <service_object ref_id=' ||
                                                            CHR(34) || 'card_1' ||
                                                            CHR(34) || ' />
          </service>
          <service value=' ||
                                                            CHR(34) ||
                                                            '70000001' ||
                                                            CHR(34) || '>
            <service_object ref_id=' ||
                                                            CHR(34) ||
                                                            'account_1' ||
                                                            CHR(34) || ' />
          </service>
          <account id=' ||
                                                            CHR(34) ||
                                                            'account_1' ||
                                                            CHR(34) || '>
            <command>CMMDCREX</command>
            <account_number>$ACCOUNT_NUMBER</account_number>
            <currency>$CCY</currency>
            <account_type>$ACC_TYPE</account_type>
            <account_object ref_id=' ||
                                                            CHR(34) || 'card_1' ||
                                                            CHR(34) || '>
              <account_link_flag>1</account_link_flag>
            </account_object>
          </account>
        </contract>
        <person>
          <command>CMMDCRUP</command>
          <person_name language=' ||
                                                            CHR(34) ||
                                                            'LANGENG' ||
                                                            CHR(34) || '>
            <surname>$LAST_NAME</surname>
            <first_name>$FIRST_NAME</first_name>
          </person_name>
        </person>
      </customer>
    </application>';*/

    --sampath commented starts
    /*
    SV_MESSAGE_ADD_NEW_CUST CONSTANT VARCHAR2(32767) := '<application xmlns=' ||
                                                        CHR(34) ||
                                                        'http://sv.bpc.in/SVAP' ||
                                                        CHR(34) || '>
  <application_type>APTPISSA</application_type>
  <application_flow_id>$XML_TYPE</application_flow_id>
  <application_status>APST0006</application_status>
  <operator_id>admin</operator_id>
  <institution_id>1001</institution_id>' ||
                                                       -- <agent_id>70000359</agent_id> -- removed and added branch code tag
                                                        '<agent_number>$BRANCH_CODE</agent_number>
  <customer_type>ENTTPERS</customer_type>
  <customer id=' ||
                                                        CHR(34) ||
                                                        'customer_1' ||
                                                        CHR(34) || '>
    ' ||
                                                       -- <command>CMMDCREX</command>-- Changed the Command
                                                        ' <command>CMMDCRUP</command>
    <customer_number>$CUSTOMER_NO</customer_number>
    <resident>$RES_STAT</resident>
    <contract>
      <command>CMMDCREX</command>
      <contract_type>$CONTRACT_TYPE</contract_type>
      <product_id>$PRODUCT_ID</product_id>
      <card id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || '>
        <command>CMMDEXUP</command>
        ' ||
                                                       -- <command>CMMDCREX</command> to <command>CMMDEXUP</command> -- DARAROTH Changed the Command
                                                        '<card_id>$CARD_ID</card_id>
        <card_type>8060</card_type>
        <cardholder>
          <command>CMMDCREX</command>
          <cardholder_number>$CARDHOLDER_NO</cardholder_number>
          <cardholder_name>$FULL_NAME</cardholder_name>
          <person>
            <command>CMMDCRUP</command>
            <person_name language=' ||
                                                        CHR(34) ||
                                                        'LANGENG' ||
                                                        CHR(34) || '>
              <surname>$LAST_NAME</surname>
              <first_name>$FIRST_NAME</first_name>
            </person_name>
            <birthday>$DOB</birthday>
          </person>
          <contact>
            <command>CMMDEXPR</command>
            <contact_type>CNTTPRMC</contact_type>
            <preferred_lang>LANGENG</preferred_lang>
            <contact_data>
              <commun_method>CMNM0001</commun_method>
              <commun_address>$MOBILE_NUMBER</commun_address>
            </contact_data>
          </contact>
          <sec_word>
            <secret_question>SEQUWORD</secret_question>
            <secret_answer>INSTANT</secret_answer>
          </sec_word>

      <notification>
      <command>CMMDCRUP</command>
      <delivery_channel>3</delivery_channel>
      <delivery_address>$MOBILE_NUMBER</delivery_address>
      <is_active>1</is_active>
      <service_number>302</service_number>
    </notification>
     <notification>
      <command>CMMDCRUP</command>
      <delivery_channel>1</delivery_channel>
      <delivery_address>$EMAIL_ID</delivery_address>
      <is_active>1</is_active>
    </notification>
    </cardholder>
      </card>
      <service value=' ||
                                                        CHR(34) ||
                                                        '70000002' ||
                                                        CHR(34) || '>
        <service_object ref_id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || ' />
      </service>
      <service value=' ||
                                                        CHR(34) ||
                                                        '70000003' ||
                                                        CHR(34) || '>
        <service_object ref_id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || ' />
      </service>
      <service value=' ||
                                                        CHR(34) ||
                                                        '70000001' ||
                                                        CHR(34) || '>
        <service_object ref_id=' ||
                                                        CHR(34) ||
                                                        'account_1' ||
                                                        CHR(34) || ' />
      </service>
      <account id=' ||
                                                        CHR(34) ||
                                                        'account_1' ||
                                                        CHR(34) || '>
        <command>CMMDCREX</command>
        <account_number>$ACCOUNT_NUMBER</account_number>
        <currency>$CCY</currency>
        <account_type>$ACC_TYPE</account_type>
        <account_object ref_id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || '>
          <account_link_flag>1</account_link_flag>
        </account_object>
      </account>
    </contract>
    <person>
      <command>CMMDCRUP</command>
      <person_name language=' ||
                                                        CHR(34) ||
                                                        'LANGENG' ||
                                                        CHR(34) || '>
        <surname>$LAST_NAME</surname>
        <first_name>$FIRST_NAME</first_name>
      </person_name>
    </person>
  </customer>
</application>';*/
--sampath commented ends
/*
--sampath changes starts
SV_MESSAGE_ADD_NEW_CUST CONSTANT VARCHAR2(32767) := '<application xmlns=' ||
                                                        CHR(34) ||
                                                        'http://sv.bpc.in/SVAP' ||
                                                        CHR(34) || '>
  <application_type>APTPISSA</application_type>
  <application_flow_id>$XML_TYPE</application_flow_id>
  <application_status>APST0006</application_status>
  <operator_id>admin</operator_id>
  <institution_id>1001</institution_id>' ||
                                                       -- <agent_id>70000359</agent_id> -- removed and added branch code tag
                                                        '<agent_number>$BRANCH_CODE</agent_number>
  <customer_type>ENTTPERS</customer_type>
  <customer id=' ||
                                                        CHR(34) ||
                                                        'customer_1' ||
                                                        CHR(34) || '>
    ' ||
                                                       -- <command>CMMDCREX</command>-- Changed the Command
                                                        ' <command>CMMDCRUP</command>
    <customer_number>$CUSTOMER_NO</customer_number>
    <resident>$RES_STAT</resident>
    <contract>
      <command>CMMDCREX</command>
      <contract_type>$CONTRACT_TYPE</contract_type>
      <product_id>$PRODUCT_ID</product_id>
      <card id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || '>
        <command>CMMDEXUP</command>
        ' ||
                                                       -- <command>CMMDCREX</command> to <command>CMMDEXUP</command> -- DARAROTH Changed the Command
                                                        '<card_id>$CARD_ID</card_id>
        <card_type>$CARD_TYPE</card_type>
        <cardholder>
          <command>CMMDCREX</command>
          <cardholder_number>$CARDHOLDER_NO</cardholder_number>
          <cardholder_name>$FULL_NAME</cardholder_name>
          <person>
            <command>CMMDCRUP</command>
            <person_name language=' ||
                                                        CHR(34) ||
                                                        'LANGENG' ||
                                                        CHR(34) || '>
              <surname>$LAST_NAME</surname>
              <first_name>$FIRST_NAME</first_name>
            </person_name>
            <birthday>$DOB</birthday>
          </person>
          <contact>
            <command>CMMDEXPR</command>
            <contact_type>CNTTPRMC</contact_type>
            <preferred_lang>LANGENG</preferred_lang>
            <contact_data>
              <commun_method>CMNM0001</commun_method>
              <commun_address>$MOBILE_NUMBER</commun_address>
            </contact_data>
          </contact>
          <sec_word>
            <secret_question>SEQUWORD</secret_question>
            <secret_answer>INSTANT</secret_answer>
          </sec_word>

      <notification>
      <command>CMMDCRUP</command>
      <delivery_channel>3</delivery_channel>
      <delivery_address>$MOBILE_NUMBER</delivery_address>
      <is_active>1</is_active>
      <service_number>302</service_number>
    </notification>
     <notification>
      <command>CMMDCRUP</command>
      <delivery_channel>1</delivery_channel>
      <delivery_address>$EMAIL_ID</delivery_address>
      <is_active>1</is_active>
    </notification>
    </cardholder>
      </card>
      <service value=' ||
                                                        CHR(34) ||
                                                        '70000002' ||
                                                        CHR(34) || '>
        <service_object ref_id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || ' />
      </service>
      <service value=' ||
                                                        CHR(34) ||
                                                        '70000003' ||
                                                        CHR(34) || '>
        <service_object ref_id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || ' />
      </service>
      <service value=' ||
                                                        CHR(34) ||
                                                        '70000001' ||
                                                        CHR(34) || '>
        <service_object ref_id=' ||
                                                        CHR(34) ||
                                                        'account_1' ||
                                                        CHR(34) || ' />
      </service>
      <service value=' ||
                                                        CHR(34) ||
                                                        '70000022' ||
                                                        CHR(34) || '>
        <service_object ref_id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || ' />
      </service>
      <account id=' ||
                                                        CHR(34) ||
                                                        'account_1' ||
                                                        CHR(34) || '>
        <command>CMMDCREX</command>
        <account_number>$ACCOUNT_NUMBER</account_number>
        <currency>$CCY</currency>
        <account_type>$ACC_TYPE</account_type>
        <account_object ref_id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || '>
          <account_link_flag>1</account_link_flag>
        </account_object>
      </account>
    </contract>
    <person>
      <command>CMMDCRUP</command>
      <person_name language=' ||
                                                        CHR(34) ||
                                                        'LANGENG' ||
                                                        CHR(34) || '>
        <surname>$LAST_NAME</surname>
        <first_name>$FIRST_NAME</first_name>
      </person_name>
    </person>
  </customer>
</application>';
--sampath changes ends*/


--sampath instant card project changes starts
SV_MESSAGE_ADD_NEW_CUST CONSTANT VARCHAR2(32767) := '<application xmlns=' ||
                                                        CHR(34) ||
                                                        'http://sv.bpc.in/SVAP' ||
                                                        CHR(34) || '>
  <application_type>APTPISSA</application_type>
  <application_flow_id>$XML_TYPE</application_flow_id>
  <application_status>APST0006</application_status>
  <operator_id>admin</operator_id>
  <institution_id>1001</institution_id>' ||
                                                       -- <agent_id>70000359</agent_id> -- removed and added branch code tag
                                                        '<agent_number>$BRANCH_CODE</agent_number>
  <customer_type>ENTTPERS</customer_type>
  <customer id=' ||
                                                        CHR(34) ||
                                                        'customer_1' ||
                                                        CHR(34) || '>
    ' ||
                                                       -- <command>CMMDCREX</command>-- Changed the Command
                                                        ' <command>CMMDCRUP</command>
    <customer_number>$CUSTOMER_NO</customer_number>
    <resident>$RES_STAT</resident>
    <contract>
      <command>CMMDCREX</command>
      <contract_type>$CONTRACT_TYPE</contract_type>
      <product_id>$PRODUCT_ID</product_id>
      <card id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || '>
        <command>CMMDEXUP</command>
        ' ||
                                                       -- <command>CMMDCREX</command> to <command>CMMDEXUP</command> -- DARAROTH Changed the Command
                                                        '<card_id>$CARD_ID</card_id>
        <card_type>$CARD_TYPE</card_type>
        <cardholder>
          <command>CMMDCREX</command>
          <cardholder_number>$CARDHOLDER_NO</cardholder_number>
          <cardholder_name>$FULL_NAME</cardholder_name>
          <person>
            <command>CMMDCRUP</command>
            <person_name language=' ||
                                                        CHR(34) ||
                                                        'LANGENG' ||
                                                        CHR(34) || '>
              <surname>$LAST_NAME</surname>
              <first_name>$FIRST_NAME</first_name>
            </person_name>
            <birthday>$DOB</birthday>
          </person>
          <contact>
            <command>CMMDEXPR</command>
            <contact_type>CNTTPRMC</contact_type>
            <preferred_lang>LANGENG</preferred_lang>
            <contact_data>
              <commun_method>CMNM0003</commun_method>
              <commun_address>$EMAIL_ID</commun_address>
            </contact_data>
          </contact>
          <sec_word>
            <secret_question>SEQUWORD</secret_question>
            <secret_answer>INSTANT</secret_answer>
          </sec_word>

      <notification>
      <command>CMMDCRUP</command>
      <delivery_channel>3</delivery_channel>
      <delivery_address>$MOBILE_NUMBER</delivery_address>
      <is_active>1</is_active>
      <service_number>302</service_number>
    </notification>
     
    </cardholder>
      </card>
      <service value=' ||
                                                        CHR(34) ||
                                                        '70000002' ||
                                                        CHR(34) || '>
        <service_object ref_id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || ' />
      </service>
      <service value=' ||
                                                        CHR(34) ||
                                                        '70000003' ||
                                                        CHR(34) || '>
        <service_object ref_id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || ' />
      </service>
      <service value=' ||
                                                        CHR(34) ||
                                                        '70000001' ||
                                                        CHR(34) || '>
        <service_object ref_id=' ||
                                                        CHR(34) ||
                                                        'account_1' ||
                                                        CHR(34) || ' />
      </service>
      <service value=' ||
                                                        CHR(34) ||
                                                        '70000022' ||
                                                        CHR(34) || '>
        <service_object ref_id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || ' />
      </service>
      <account id=' ||
                                                        CHR(34) ||
                                                        'account_1' ||
                                                        CHR(34) || '>
        <command>CMMDCREX</command>
        <account_number>$ACCOUNT_NUMBER</account_number>
        <currency>$CCY</currency>
        <account_type>$ACC_TYPE</account_type>
        <account_object ref_id=' ||
                                                        CHR(34) || 'card_1' ||
                                                        CHR(34) || '>
          <account_link_flag>1</account_link_flag>
		  <is_pos_default>1</is_pos_default>
          <is_atm_default>1</is_atm_default>
	 
        </account_object>
		<is_default2>ACSD0001</is_default2>
      </account>
    </contract>
    <person>
      <command>CMMDCRUP</command>
      <person_name language=' ||
                                                        CHR(34) ||
                                                        'LANGENG' ||
                                                        CHR(34) || '>
        <surname>$LAST_NAME</surname>
        <first_name>$FIRST_NAME</first_name>
      </person_name>
    </person>
	
	<contact>
      <command>CMMDCRUP</command>
      <contact_type>CNTTPRMC</contact_type>
      <contact_data>
        <commun_method>CMNM0001</commun_method>
        <commun_address>$MOBILE_NUMBER</commun_address>
      </contact_data>
  </contact>
  
  </customer>
</application>';
--sampath instant card project changes ends

    XMLTYPE VARCHAR2(4) := IFPKS_SV_CDC_CUSTOM.FN_GET_XML_TYPE('ADD_NEW_CUST');
    CURSOR CUR_SV_DETAILS IS
      SELECT *
        FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM
       WHERE STATUS = 'I'
         AND XML_TYPE = XMLTYPE;

    L_COUNT NUMBER;

  BEGIN
    OPEN CUR_SV_DETAILS;
    LOOP
      FETCH CUR_SV_DETAILS
        INTO L_SV_DETAILS;
      IF CUR_SV_DETAILS%NOTFOUND THEN
        EXIT;
      END IF;

      DBG('processing :' || L_SV_DETAILS.CUSTOMER_NO);
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = L_SV_DETAILS.CUST_AC_NO
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';

      IF L_COUNT = 1 THEN

        RES_STAT     := FN_GET_RESISIDENT_STAT(L_SV_DETAILS.RESIDENT_STATUS);
        COUNTRY_CODE := FN_GET_CNTRY_CODE(L_SV_DETAILS.NATIONALITY);
        CCYCODE      := FN_GET_CCY_CD(L_SV_DETAILS.CCY);
        -- CTRYCODE := FN_GET_CNTRY_CODE(L_SV_DETAILS.COUNTRY);
        --  ACC_TYPE := FN_GET_ACC_TYPE(L_SV_DETAILS.ACCOUNT_TYPE);
        --ACC_TYPE := FN_GET_ACC_TYPE(L_SV_DETAILS.ACCOUNT_TYPE, L_SV_DETAILS.CCY); --sampath commented
        -- ID_TYPE := FN_GET_IDTYPE(L_SV_DETAILS.UNIQUE_ID_NAME);

        SVMESSAGE := SV_MESSAGE_ADD_NEW_CUST;
        SVMESSAGE := REPLACE(SVMESSAGE, '$XML_TYPE', XMLTYPE);
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$CUSTOMER_NO',
                             L_SV_DETAILS.CUSTOMER_NO);
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$BRANCH_CODE',
                             L_SV_DETAILS.BRANCH_CODE);
        SVMESSAGE := REPLACE(SVMESSAGE, '$RES_STAT', RES_STAT);
        SVMESSAGE := REPLACE(SVMESSAGE, '$PRODUCT_ID', L_SV_DETAILS.PROD_ID);

        --sampath starts
        /*BEGIN

          SELECT ACC_TYPE_CODE
            INTO CONTRACT_TYPE
            FROM IFTB_SVCARD_PRODUCT_CUSTOM
           WHERE ACCOUNT_TYPE = L_SV_DETAILS.ACCOUNT_TYPE
             AND ACCOUNT_CCY = L_SV_DETAILS.CCY
             AND PRODUCT_ID = L_SV_DETAILS.PROD_ID;

        EXCEPTION
          WHEN OTHERS THEN
            CONTRACT_TYPE := NULL;

        END;*/

        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$CONTRACT_TYPE',
                             FN_GET_CONTRACT_TYPE_NEW(L_SV_DETAILS.ACCOUNT_TYPE,
                                                 L_SV_DETAILS.CCY,
                                                 L_SV_DETAILS.PROD_ID));

        --sampath ends

        SVMESSAGE := REPLACE(SVMESSAGE, '$CARD_ID', L_SV_DETAILS.CARD_ID);
        --SVMESSAGE := REPLACE(SVMESSAGE, '$CARD_TYPE', CARD_TYPE); --sampath commented

         --sampath starts
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$CARD_TYPE',
                             FN_GET_CARD_TYPE_NEW(L_SV_DETAILS.ACCOUNT_TYPE,
                                                  L_SV_DETAILS.CCY,
                                                  L_SV_DETAILS.PROD_ID));
        --sampath ends

        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$CARDHOLDER_NO',
                             L_SV_DETAILS.CUSTOMER_NO ||
                             SUBSTR(L_SV_DETAILS.CARD_ID, -4));
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$FULL_NAME',
                             L_SV_DETAILS.FULL_NAME);
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$MOBILE_NUMBER',
                             L_SV_DETAILS.MOBILE_NUMBER);
        SVMESSAGE := REPLACE(SVMESSAGE, '$EMAIL_ID', L_SV_DETAILS.E_MAIL);
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$DOB',
                             TO_CHAR(L_SV_DETAILS.DATE_OF_BIRTH,
                                     'YYYY-MM-dd'));
        SVMESSAGE := REPLACE(SVMESSAGE, '$CCY', CCYCODE);
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$ACCOUNT_NUMBER',
                             L_SV_DETAILS.CUST_AC_NO);

        --SVMESSAGE := REPLACE(SVMESSAGE, '$ACC_TYPE', ACC_TYPE); --sampath commented

        --sampath starts

        /* BEGIN

          SELECT ACC_TYPE_CODE
            INTO ACC_TYPE
            FROM IFTB_SVCARD_PRODUCT_CUSTOM
           WHERE ACCOUNT_TYPE = L_SV_DETAILS.ACCOUNT_TYPE
             AND ACCOUNT_CCY = L_SV_DETAILS.CCY
             AND PRODUCT_ID = L_SV_DETAILS.PROD_ID;

        EXCEPTION
          WHEN OTHERS THEN
            ACC_TYPE := NULL;

        END;*/

        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$ACC_TYPE',
                             FN_GET_ACC_TYPE_NEW(L_SV_DETAILS.ACCOUNT_TYPE,
                                                 L_SV_DETAILS.CCY,
                                                 L_SV_DETAILS.PROD_ID));

        --SVMESSAGE := REPLACE(SVMESSAGE, '$ACC_TYPE', ACC_TYPE);

        --sampath ends

        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$LAST_NAME',
                             SUBSTR(L_SV_DETAILS.FULL_NAME,
                                    1,
                                    (INSTR(L_SV_DETAILS.FULL_NAME, ' ') - 1)));
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$FIRST_NAME',
                             SUBSTR(L_SV_DETAILS.FULL_NAME,
                                    (INSTR(L_SV_DETAILS.FULL_NAME, ' ') + 1)));

        DBG('now the message IS ' || SVMESSAGE);

        IF NOT FN_UPDATE_MSG(L_SV_DETAILS.SEQ_NO, SVMESSAGE) THEN
          DBG('failed for ' || L_SV_DETAILS.CUSTOMER_NO);
          DBG(SQLCODE || ' ' || SQLERRM);
          RETURN FALSE;
        END IF;

        DBG('generated AND updated successfully for ' ||
            L_SV_DETAILS.CUSTOMER_NO);
      ELSE
        DBG('THE ACCOUNT IS NOT AUTHORISED ' || L_SV_DETAILS.CUST_AC_NO);
      END IF;
    END LOOP;
    DBG('no of customer generated :' || CUR_SV_DETAILS%ROWCOUNT);
    CLOSE CUR_SV_DETAILS;
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN FALSE;

  END FN_GENERATE_ADD_NEW_CUST;
  ------------------------------------------------------------
  FUNCTION FN_GENERATE_OPN_ADD_ACC RETURN BOOLEAN IS

  --sampath commented starts
    /*SV_MESSAGE_OPN_ADD_ACC CONSTANT VARCHAR2(32767) := '<?xml version=' ||
                                                       CHR(34) || '1.0' ||
                                                       CHR(34) ||
                                                       ' encoding=' ||
                                                       CHR(34) || 'UTF-8' ||
                                                       CHR(34) || '?>
<application xmlns=' ||
                                                       CHR(34) ||
                                                       'http://sv.bpc.in/SVAP' ||
                                                       CHR(34) || '>
  <application_type>APTPISSA</application_type>
  <application_flow_id>$XML_TYPE</application_flow_id>
  <application_status>APST0006</application_status>
  <operator_id>ADMIN</operator_id>
  <institution_id>1001</institution_id>' ||
                                                      -- <agent_id>70000359</agent_id> -- removed and added branch code tag
                                                       '<agent_number>$BRANCH_CODE</agent_number>
  <customer_type>ENTTPERS</customer_type>
  <customer>
    <command>CMMDEXPR</command>
    <customer_number>$CUSTOMER_NO</customer_number>
    <contract>
      <command>CMMDCREX</command>' ||
                                                      -- <command>CMMDCRUP</command> -- replace command with CMMDCREX tag
                                                       '
      <contract_type>$CONTRACT_TYPE</contract_type>
      <product_id>$PRODUCT_ID</product_id>
      <start_date>' ||
                                                       TO_CHAR(TRUNC(SYSDATE),
                                                               'YYYY-MM-dd') ||
                                                       '</start_date>
      <card id=' ||
                                                       CHR(34) || 'card_1' ||
                                                       CHR(34) || '>
        <card_id>$CARD_ID</card_id>
        <command>CMMDCRUP</command>
        <card_type>8060</card_type>
        <cardholder_name>$FULL_NAME</cardholder_name>
        <category>CRCG0200</category>
        <cardholder>
          <command>CMMDCRUP</command>
          <cardholder_name>$FULL_NAME</cardholder_name>
          <person>
            <command>CMMDCRUP</command>
            <person_name language=' ||
                                                       CHR(34) || 'LANGENG' ||
                                                       CHR(34) || '>
              <surname>$LAST_NAME</surname>
              <first_name>$FIRST_NAME</first_name>
            </person_name>
            <birthday>$DOB</birthday>
          </person>
          <contact>
            <command>CMMDEXPR</command>
            <contact_type>CNTTPRMC</contact_type>
            <preferred_lang>LANGENG</preferred_lang>
            <contact_data>
              <commun_method>CMNM0001</commun_method>
              <commun_address>$MOBILE_NUMBER</commun_address>
            </contact_data>
          </contact>
          <sec_word>
            <secret_question>SEQUW001</secret_question>
            <secret_answer>asas</secret_answer>
          </sec_word>
        </cardholder>
      </card>
       <service value=' ||
                                                       CHR(34) ||
                                                       '70000002' ||
                                                       CHR(34) || '>
        <service_object ref_id=' ||
                                                       CHR(34) || 'card_1' ||
                                                       CHR(34) || '>
          <start_date>' ||
                                                       TO_CHAR(TRUNC(SYSDATE),
                                                               'YYYY-MM-dd') ||
                                                       '</start_date>
        </service_object>
      </service>
       <service value=' ||
                                                       CHR(34) ||
                                                       '70000003' ||
                                                       CHR(34) || '>
        <service_object ref_id=' ||
                                                       CHR(34) || 'card_1' ||
                                                       CHR(34) || '>
          <start_date>' ||
                                                       TO_CHAR(TRUNC(SYSDATE),
                                                               'YYYY-MM-dd') ||
                                                       '</start_date>
        </service_object>
      </service>
      <service value=' ||
                                                       CHR(34) ||
                                                       '70000001' ||
                                                       CHR(34) || '>
        <service_object ref_id=' ||
                                                       CHR(34) ||
                                                       'account_1' ||
                                                       CHR(34) || '>
          <start_date>' ||
                                                       TO_CHAR(TRUNC(SYSDATE),
                                                               'YYYY-MM-dd') ||
                                                       '</start_date>
        </service_object>
      </service>
      <account id=' ||
                                                       CHR(34) ||
                                                       'account_1' ||
                                                       CHR(34) || '>
        <command>CMMDCRUP</command>
        <account_number>$ACCOUNT_NUMBER</account_number>
        <currency>$CCY</currency>
        <account_type>$ACC_TYPE</account_type>
        <account_object ref_id=' ||
                                                       CHR(34) || 'card_1' ||
                                                       CHR(34) || '>
                     <account_link_flag>1</account_link_flag>
                </account_object>
      </account>
    </contract>
    <person>
      <command>CMMDCRUP</command>
      <person_name language=' ||
                                                       CHR(34) || 'LANGENG' ||
                                                       CHR(34) || '>
        <surname>$LAST_NAME</surname>
        <first_name>$FIRST_NAME</first_name>
      </person_name>

      <identity_card>
        <id_type>$UNIQUE_ID_TYPE</id_type>
        <id_series></id_series>
        <id_number>$UNIQUE_ID_NUM</id_number>
      </identity_card>
    </person>
  </customer>
</application>';*/
--sampath commented ends

--sampath changes starts
 SV_MESSAGE_OPN_ADD_ACC CONSTANT VARCHAR2(32767) := '<?xml version=' ||
                                                       CHR(34) || '1.0' ||
                                                       CHR(34) ||
                                                       ' encoding=' ||
                                                       CHR(34) || 'UTF-8' ||
                                                       CHR(34) || '?>
<application xmlns=' ||
                                                       CHR(34) ||
                                                       'http://sv.bpc.in/SVAP' ||
                                                       CHR(34) || '>
  <application_type>APTPISSA</application_type>
  <application_flow_id>$XML_TYPE</application_flow_id>
  <application_status>APST0006</application_status>
  <operator_id>ADMIN</operator_id>
  <institution_id>1001</institution_id>' ||
                                                      -- <agent_id>70000359</agent_id> -- removed and added branch code tag
                                                       '<agent_number>$BRANCH_CODE</agent_number>
  <customer_type>ENTTPERS</customer_type>
  <customer>
    <command>CMMDEXPR</command>
    <customer_number>$CUSTOMER_NO</customer_number>
    <contract>
      <command>CMMDCREX</command>' ||
                                                      -- <command>CMMDCRUP</command> -- replace command with CMMDCREX tag
                                                       '
      <contract_type>$CONTRACT_TYPE</contract_type>
      <product_id>$PRODUCT_ID</product_id>
      <start_date>' ||
                                                       TO_CHAR(TRUNC(SYSDATE),
                                                               'YYYY-MM-dd') ||
                                                       '</start_date>
      <card id=' ||
                                                       CHR(34) || 'card_1' ||
                                                       CHR(34) || '>
        <card_id>$CARD_ID</card_id>
        <command>CMMDCRUP</command>
        <card_type>$CARD_TYPE</card_type>
        <cardholder_name>$FULL_NAME</cardholder_name>
        <category>CRCG0200</category>
        <cardholder>
          <command>CMMDCRUP</command>
          <cardholder_name>$FULL_NAME</cardholder_name>
          <person>
            <command>CMMDCRUP</command>
            <person_name language=' ||
                                                       CHR(34) || 'LANGENG' ||
                                                       CHR(34) || '>
              <surname>$LAST_NAME</surname>
              <first_name>$FIRST_NAME</first_name>
            </person_name>
            <birthday>$DOB</birthday>
          </person>
          <contact>
            <command>CMMDEXPR</command>
            <contact_type>CNTTPRMC</contact_type>
            <preferred_lang>LANGENG</preferred_lang>
            <contact_data>
              <commun_method>CMNM0001</commun_method>
              <commun_address>$MOBILE_NUMBER</commun_address>
            </contact_data>
          </contact>
          <sec_word>
            <secret_question>SEQUW001</secret_question>
            <secret_answer>asas</secret_answer>
          </sec_word>
        </cardholder>
      </card>
       <service value=' ||
                                                       CHR(34) ||
                                                       '70000002' ||
                                                       CHR(34) || '>
        <service_object ref_id=' ||
                                                       CHR(34) || 'card_1' ||
                                                       CHR(34) || '>
          <start_date>' ||
                                                       TO_CHAR(TRUNC(SYSDATE),
                                                               'YYYY-MM-dd') ||
                                                       '</start_date>
        </service_object>
      </service>
       <service value=' ||
                                                       CHR(34) ||
                                                       '70000003' ||
                                                       CHR(34) || '>
        <service_object ref_id=' ||
                                                       CHR(34) || 'card_1' ||
                                                       CHR(34) || '>
          <start_date>' ||
                                                       TO_CHAR(TRUNC(SYSDATE),
                                                               'YYYY-MM-dd') ||
                                                       '</start_date>
        </service_object>
      </service>
      <service value=' ||
                                                       CHR(34) ||
                                                       '70000001' ||
                                                       CHR(34) || '>
        <service_object ref_id=' ||
                                                       CHR(34) ||
                                                       'account_1' ||
                                                       CHR(34) || '>
          <start_date>' ||
                                                       TO_CHAR(TRUNC(SYSDATE),
                                                               'YYYY-MM-dd') ||
                                                       '</start_date>
        </service_object>
      </service>
      <service value=' ||
                                                       CHR(34) ||
                                                       '70000022' ||
                                                       CHR(34) || '>
        <service_object ref_id=' ||
                                                       CHR(34) || 'card_1' ||
                                                       CHR(34) || '>
          <start_date>' ||
                                                       TO_CHAR(TRUNC(SYSDATE),
                                                               'YYYY-MM-dd') ||
                                                       '</start_date>
        </service_object>
      </service>
      <account id=' ||
                                                       CHR(34) ||
                                                       'account_1' ||
                                                       CHR(34) || '>
        <command>CMMDCRUP</command>
        <account_number>$ACCOUNT_NUMBER</account_number>
        <currency>$CCY</currency>
        <account_type>$ACC_TYPE</account_type>
        <account_object ref_id=' ||
                                                       CHR(34) || 'card_1' ||
                                                       CHR(34) || '>
                     <account_link_flag>1</account_link_flag>
                </account_object>
      </account>
    </contract>
    <person>
      <command>CMMDCRUP</command>
      <person_name language=' ||
                                                       CHR(34) || 'LANGENG' ||
                                                       CHR(34) || '>
        <surname>$LAST_NAME</surname>
        <first_name>$FIRST_NAME</first_name>
      </person_name>

      <identity_card>
        <id_type>$UNIQUE_ID_TYPE</id_type>
        <id_series></id_series>
        <id_number>$UNIQUE_ID_NUM</id_number>
      </identity_card>
    </person>
  </customer>
</application>';
--sampath changes ends


    XMLTYPE VARCHAR2(4) := IFPKS_SV_CDC_CUSTOM.FN_GET_XML_TYPE('OPN_ADD_ACC');
    CURSOR CUR_SV_DETAILS IS
      SELECT *
        FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM
       WHERE STATUS = 'I'
         AND XML_TYPE = XMLTYPE;
    L_COUNT NUMBER;

  BEGIN
    OPEN CUR_SV_DETAILS;
    LOOP
      FETCH CUR_SV_DETAILS
        INTO L_SV_DETAILS;
      IF CUR_SV_DETAILS%NOTFOUND THEN
        EXIT;
      END IF;

      DBG('processing :' || L_SV_DETAILS.CUSTOMER_NO);
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = L_SV_DETAILS.CUST_AC_NO
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';

      IF L_COUNT = 1 THEN

        CCYCODE := FN_GET_CCY_CD(L_SV_DETAILS.CCY);
        --  ACC_TYPE := FN_GET_ACC_TYPE(L_SV_DETAILS.ACCOUNT_TYPE);
        --ACC_TYPE := FN_GET_ACC_TYPE(L_SV_DETAILS.ACCOUNT_TYPE,L_SV_DETAILS.CCY); --sampath commented
        ID_TYPE := FN_GET_IDTYPE(L_SV_DETAILS.UNIQUE_ID_NAME);

        SVMESSAGE := SV_MESSAGE_OPN_ADD_ACC;
        SVMESSAGE := REPLACE(SVMESSAGE, '$XML_TYPE', XMLTYPE);
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$CUSTOMER_NO',
                             L_SV_DETAILS.CUSTOMER_NO);
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$BRANCH_CODE',
                             L_SV_DETAILS.BRANCH_CODE);
        SVMESSAGE := REPLACE(SVMESSAGE, '$PRODUCT_ID', L_SV_DETAILS.PROD_ID);

        --sampath starts
        /*BEGIN

          SELECT CONTRACT_TYPE
            INTO CONTRACT_TYPE
            FROM IFTB_SVCARD_PRODUCT_CUSTOM
           WHERE ACCOUNT_TYPE = L_SV_DETAILS.ACCOUNT_TYPE
             AND ACCOUNT_CCY = L_SV_DETAILS.CCY
             AND PRODUCT_ID = L_SV_DETAILS.PROD_ID;

        EXCEPTION
          WHEN OTHERS THEN
            CONTRACT_TYPE := NULL;

        END;

        SVMESSAGE := REPLACE(SVMESSAGE, '$CONTRACT_TYPE', CONTRACT_TYPE);*/

        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$CONTRACT_TYPE',
                             FN_GET_CONTRACT_TYPE_NEW(L_SV_DETAILS.ACCOUNT_TYPE,
                                                 L_SV_DETAILS.CCY,
                                                 L_SV_DETAILS.PROD_ID));


        --sampath ends

        SVMESSAGE := REPLACE(SVMESSAGE, '$CARD_ID', L_SV_DETAILS.CARD_ID);
        --SVMESSAGE := REPLACE(SVMESSAGE, '$CARD_TYPE', CARD_TYPE); --sampath commented

         --sampath starts
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$CARD_TYPE',
                             FN_GET_CARD_TYPE_NEW(L_SV_DETAILS.ACCOUNT_TYPE,
                                                  L_SV_DETAILS.CCY,
                                                  L_SV_DETAILS.PROD_ID));
        --sampath ends


        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$FULL_NAME',
                             L_SV_DETAILS.FULL_NAME);
        SVMESSAGE := REPLACE(SVMESSAGE, '$CCY', CCYCODE);
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$MOBILE_NUMBER',
                             L_SV_DETAILS.MOBILE_NUMBER);
        SVMESSAGE := REPLACE(SVMESSAGE, '$EMAIL_ID', L_SV_DETAILS.E_MAIL);
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$DOB',
                             TO_CHAR(L_SV_DETAILS.DATE_OF_BIRTH,
                                     'YYYY-MM-dd'));
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$ACCOUNT_NUMBER',
                             L_SV_DETAILS.CUST_AC_NO);

        --SVMESSAGE := REPLACE(SVMESSAGE, '$ACC_TYPE', ACC_TYPE); --sampath commented

        --sampath starts

        BEGIN

          SELECT ACC_TYPE_CODE
            INTO ACC_TYPE
            FROM IFTB_SVCARD_PRODUCT_CUSTOM
           WHERE ACCOUNT_TYPE = L_SV_DETAILS.ACCOUNT_TYPE
             AND ACCOUNT_CCY = L_SV_DETAILS.CCY
             AND PRODUCT_ID = L_SV_DETAILS.PROD_ID;

        EXCEPTION
          WHEN OTHERS THEN
            ACC_TYPE := NULL;

        END;

        SVMESSAGE := REPLACE(SVMESSAGE, '$ACC_TYPE', ACC_TYPE);

        --sampath ends

        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$LAST_NAME',
                             SUBSTR(L_SV_DETAILS.FULL_NAME,
                                    1,
                                    (INSTR(L_SV_DETAILS.FULL_NAME, ' ') - 1)));
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$FIRST_NAME',
                             SUBSTR(L_SV_DETAILS.FULL_NAME,
                                    (INSTR(L_SV_DETAILS.FULL_NAME, ' ') + 1)));
        SVMESSAGE := REPLACE(SVMESSAGE, '$UNIQUE_ID_TYPE', ID_TYPE);
        SVMESSAGE := REPLACE(SVMESSAGE,
                             '$UNIQUE_ID_NUM',
                             L_SV_DETAILS.UNIQUE_ID_VALUE);

        DBG('now the message IS ' || SVMESSAGE);

        IF NOT FN_UPDATE_MSG(L_SV_DETAILS.SEQ_NO, SVMESSAGE) THEN
          DBG('failed for ' || L_SV_DETAILS.CUSTOMER_NO);
          DBG(SQLCODE || ' ' || SQLERRM);
          RETURN FALSE;
        END IF;
        DBG('generated AND updated successfully for ' ||
            L_SV_DETAILS.CUSTOMER_NO);
      ELSE
        DBG('THE ACCOUNT IS NOT AUTHORISED ' || L_SV_DETAILS.CUST_AC_NO);
      END IF;
    END LOOP;
    DBG('no of customer generated :' || CUR_SV_DETAILS%ROWCOUNT);
    CLOSE CUR_SV_DETAILS;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN FALSE;

  END FN_GENERATE_OPN_ADD_ACC;
  ------------------------------------------------------------
  FUNCTION FN_GENERATE_CHG_CUST_DATA RETURN BOOLEAN IS

    SV_MESSAGE_CHG_CUST_DATA CONSTANT VARCHAR2(32767) := '<?xml version=' ||
                                                         CHR(34) || '1.0' ||
                                                         CHR(34) ||
                                                         ' encoding=' ||
                                                         CHR(34) || 'UTF-8' ||
                                                         CHR(34) || '?>
<application xmlns=' ||
                                                         CHR(34) ||
                                                         'http://sv.bpc.in/SVAP/iss' ||
                                                         CHR(34) || '>
    <application_type>APTPISSA</application_type>
    <application_flow_id>$XML_TYPE</application_flow_id>
    <application_status>APST0006</application_status>
    <operator_id>OPERATOR1</operator_id>
    <institution_id>1001</institution_id>' ||
                                                        -- <agent_id>70000359</agent_id> -- removed and added branch code tag
                                                         '<agent_number>$BRANCH_CODE</agent_number>
    <customer_type>ENTTPERS</customer_type>
    <customer>
        <command>CMMDEXUP</command>
        <customer_number>$CUSTOMER_NO</customer_number>
        <resident>$RES_STAT</resident>
        <person>
            <command>CMMDCRUP</command>
            <person_name language=' ||
                                                         CHR(34) ||
                                                         'LANGENG' ||
                                                         CHR(34) || '>
                <surname>$LAST_NAME</surname>
                <first_name>$FIRST_NAME</first_name>
        </person_name>
            <identity_card>
                <command>CMMDEXPR</command>
                <id_type>$UNIQUE_ID_TYPE</id_type>
                <id_series></id_series>
                <id_number>$UNIQUE_ID_NUM</id_number>
            </identity_card>
        </person>
        <contact>
            <command>CMMDCRUP</command>
            <contact_type>$CONTRACT_TYPE</contact_type>
            <preferred_lang>LANGENG</preferred_lang>
            <contact_data>
                <commun_method>CMNM0001</commun_method>
                <commun_address>$MOBILE_NUMBER</commun_address>
            </contact_data>
        </contact>
        <address>
            <command>CMMDCRUP</command>
            <address_type>ADTPHOME</address_type>
            <country>$COUNTRY</country>
            <address_name language=' ||
                                                         CHR(34) ||
                                                         'LANGENG' ||
                                                         CHR(34) || '>
                <region>$addr_line1</region>
                <city>$addr_line2</city>
                <street>$addr_line3</street>
            </address_name>
            <house>$addr_line4</house>
            <apartment>$addr_line4</apartment>
        </address>
    </customer>
</application>';

    XMLTYPE VARCHAR2(4) := IFPKS_SV_CDC_CUSTOM.FN_GET_XML_TYPE('CHG_CUST_DATA');
    CURSOR CUR_SV_DETAILS IS
      SELECT *
        FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM
       WHERE STATUS = 'I'
         AND XML_TYPE = XMLTYPE;

  BEGIN
    OPEN CUR_SV_DETAILS;
    LOOP
      FETCH CUR_SV_DETAILS
        INTO L_SV_DETAILS;
      IF CUR_SV_DETAILS%NOTFOUND THEN
        EXIT;
      END IF;
      DBG('processing :' || L_SV_DETAILS.CUSTOMER_NO);

      --CUST_REL:= FN_GET_CUSTOMER_REL(L_SV_DETAILS.STAFF);
      RES_STAT := FN_GET_RESISIDENT_STAT(L_SV_DETAILS.RESIDENT_STATUS);
      CTRYCODE := FN_GET_CNTRY_CODE(L_SV_DETAILS.COUNTRY);
      ID_TYPE  := FN_GET_IDTYPE(L_SV_DETAILS.UNIQUE_ID_NAME);

      SVMESSAGE := SV_MESSAGE_CHG_CUST_DATA;
      SVMESSAGE := REPLACE(SVMESSAGE, '$XML_TYPE', XMLTYPE);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$CUSTOMER_NO',
                           L_SV_DETAILS.CUSTOMER_NO);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$BRANCH_CODE',
                           L_SV_DETAILS.BRANCH_CODE);
      SVMESSAGE := REPLACE(SVMESSAGE, '$RES_STAT', RES_STAT);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$MOBILE_NUMBER',
                           L_SV_DETAILS.MOBILE_NUMBER);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$LAST_NAME',
                           SUBSTR(L_SV_DETAILS.FULL_NAME,
                                  1,
                                  (INSTR(L_SV_DETAILS.FULL_NAME, ' ') - 1)));
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$FIRST_NAME',
                           SUBSTR(L_SV_DETAILS.FULL_NAME,
                                  (INSTR(L_SV_DETAILS.FULL_NAME, ' ') + 1)));
      SVMESSAGE := REPLACE(SVMESSAGE, '$UNIQUE_ID_TYPE', ID_TYPE);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$UNIQUE_ID_NUM',
                           L_SV_DETAILS.UNIQUE_ID_VALUE);
      SVMESSAGE := REPLACE(SVMESSAGE, '$COUNTRY', CTRYCODE);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$addr_line1',
                           L_SV_DETAILS.ADDRESS_LINE1);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$addr_line2',
                           L_SV_DETAILS.ADDRESS_LINE2);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$addr_line3',
                           L_SV_DETAILS.ADDRESS_LINE3);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$addr_line4',
                           L_SV_DETAILS.ADDRESS_LINE4);

      --sampath starts
     /* BEGIN

        SELECT CONTRACT_TYPE
          INTO CONTRACT_TYPE
          FROM IFTB_SVCARD_PRODUCT_CUSTOM
         WHERE ACCOUNT_TYPE = L_SV_DETAILS.ACCOUNT_TYPE
           AND ACCOUNT_CCY = L_SV_DETAILS.CCY
           AND PRODUCT_ID = L_SV_DETAILS.PROD_ID;

      EXCEPTION
        WHEN OTHERS THEN
          CONTRACT_TYPE := NULL;

      END;*/

      --SVMESSAGE := REPLACE(SVMESSAGE, '$CONTRACT_TYPE', CONTRACT_TYPE);

      SVMESSAGE := REPLACE(SVMESSAGE,
                             '$CONTRACT_TYPE',
                             FN_GET_CONTRACT_TYPE_NEW(L_SV_DETAILS.ACCOUNT_TYPE,
                                                 L_SV_DETAILS.CCY,
                                                 L_SV_DETAILS.PROD_ID));


      --sampath ends

      DBG('now the message IS ' || SVMESSAGE);

      IF NOT FN_UPDATE_MSG(L_SV_DETAILS.SEQ_NO, SVMESSAGE) THEN
        DBG('failed for ' || L_SV_DETAILS.CUSTOMER_NO);
        DBG(SQLCODE || ' ' || SQLERRM);
        RETURN FALSE;
      END IF;

      DBG('generated AND updated successfully for ' ||
          L_SV_DETAILS.CUSTOMER_NO);

    END LOOP;
    DBG('no of customer generated :' || CUR_SV_DETAILS%ROWCOUNT);
    CLOSE CUR_SV_DETAILS;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN FALSE;

  END FN_GENERATE_CHG_CUST_DATA;
  ------------------------------------------------------------
  FUNCTION FN_GENERATE_CLO_CUST_CARD RETURN BOOLEAN IS

    SV_MESSAGE_CLO_CUST_CARD CONSTANT VARCHAR2(32767) := '<?xml version=' ||
                                                         CHR(34) || '1.0' ||
                                                         CHR(34) ||
                                                         ' encoding=' ||
                                                         CHR(34) || 'UTF-8' ||
                                                         CHR(34) || '?>
<application xmlns=' ||
                                                         CHR(34) ||
                                                         'http://sv.bpc.in/SVAP/iss' ||
                                                         CHR(34) || '>
    <application_type>APTPISSA</application_type>
    <application_flow_id>$XML_TYPE</application_flow_id>
    <application_status>APST0006</application_status>
    <operator_id>OPERATOR1</operator_id>
    <institution_id>1001</institution_id>' ||
                                                        -- <agent_id>70000359</agent_id> -- removed and added branch code tag
                                                         '<agent_number>$BRANCH_CODE</agent_number>
    <customer_type>ENTTPERS</customer_type>
    <customer>
        <command>CMMDEXPR</command>
        <customer_number>$CUSTOMER_NO</customer_number>
        <contract>
            <command>CMMDEXPR</command>
            <card id=' ||
                                                         CHR(34) ||
                                                         'card_1' ||
                                                         CHR(34) || '>
                <command>CMMDEXRE</command>
            <card_id>$CARD_ID</card_id>
            </card>
        </contract>
    </customer>
</application>';

    XMLTYPE VARCHAR2(4) := IFPKS_SV_CDC_CUSTOM.FN_GET_XML_TYPE('CLO_CUST_CARD');

    CURSOR CUR_SV_DETAILS IS
      SELECT *
        FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM
       WHERE STATUS = 'I'
         AND XML_TYPE = XMLTYPE;

  BEGIN
    OPEN CUR_SV_DETAILS;
    LOOP
      FETCH CUR_SV_DETAILS
        INTO L_SV_DETAILS;
      IF CUR_SV_DETAILS%NOTFOUND THEN
        EXIT;
      END IF;
      DBG('processing :' || L_SV_DETAILS.CUSTOMER_NO);

      SVMESSAGE := SV_MESSAGE_CLO_CUST_CARD;
      SVMESSAGE := REPLACE(SVMESSAGE, '$XML_TYPE', XMLTYPE);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$CUSTOMER_NO',
                           L_SV_DETAILS.CUSTOMER_NO);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$BRANCH_CODE',
                           L_SV_DETAILS.BRANCH_CODE);
      SVMESSAGE := REPLACE(SVMESSAGE, '$CARD_ID', L_SV_DETAILS.CARD_ID);

      DBG('now the message IS ' || SVMESSAGE);

      IF NOT FN_UPDATE_MSG(L_SV_DETAILS.SEQ_NO, SVMESSAGE) THEN
        DBG('failed for ' || L_SV_DETAILS.CUSTOMER_NO);
        DBG(SQLCODE || ' ' || SQLERRM);
        RETURN FALSE;
      END IF;
      DBG('generated AND updated successfully for ' ||
          L_SV_DETAILS.CUSTOMER_NO);
    END LOOP;
    DBG('no of customer generated :' || CUR_SV_DETAILS%ROWCOUNT);
    CLOSE CUR_SV_DETAILS;
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN FALSE;

  END FN_GENERATE_CLO_CUST_CARD;
  ------------------------------------------------------------
  FUNCTION FN_GENERATE_CLO_CUST_ACC RETURN BOOLEAN IS

    SV_MESSAGE_CLO_CUST_ACC CONSTANT VARCHAR2(32767) := '<?xml version=' ||
                                                        CHR(34) || '1.0' ||
                                                        CHR(34) ||
                                                        ' encoding=' ||
                                                        CHR(34) || 'UTF-8' ||
                                                        CHR(34) || '?>
<application xmlns=' ||
                                                        CHR(34) ||
                                                        'http://sv.bpc.in/SVAP/iss' ||
                                                        CHR(34) || '>
    <application_type>APTPISSA</application_type>
    <application_flow_id>$XML_TYPE</application_flow_id>
    <application_status>APST0006</application_status>
    <operator_id>OPERATOR1</operator_id>
    <institution_id>1001</institution_id>' ||
                                                       -- <agent_id>70000359</agent_id> -- removed and added branch code tag
                                                        '<agent_number>$BRANCH_CODE</agent_number>
    <customer_type>ENTTPERS</customer_type>
    <customer>
        <command>CMMDEXPR</command>
        <customer_number>$CUSTOMER_NO</customer_number>
        <contract>
            <command>CMMDEXPR</command>
            <account id=' ||
                                                        CHR(34) ||
                                                        'account_1' ||
                                                        CHR(34) || '>
                <command>CMMDEXRE</command>
                <account_number>$ACCOUNT_NUMBER</account_number>
            </account>
        </contract>
    </customer>
</application> ';

    XMLTYPE VARCHAR2(4) := IFPKS_SV_CDC_CUSTOM.FN_GET_XML_TYPE('CLO_CUST_ACC');
    CURSOR CUR_SV_DETAILS IS
      SELECT *
        FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM
       WHERE STATUS = 'I'
         AND XML_TYPE = XMLTYPE;

  BEGIN
    OPEN CUR_SV_DETAILS;
    LOOP
      FETCH CUR_SV_DETAILS
        INTO L_SV_DETAILS;
      IF CUR_SV_DETAILS%NOTFOUND THEN
        EXIT;
      END IF;
      DBG('processing :' || L_SV_DETAILS.CUSTOMER_NO);

      SVMESSAGE := SV_MESSAGE_CLO_CUST_ACC;
      SVMESSAGE := REPLACE(SVMESSAGE, '$XML_TYPE', XMLTYPE);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$CUSTOMER_NO',
                           L_SV_DETAILS.CUSTOMER_NO);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$BRANCH_CODE',
                           L_SV_DETAILS.BRANCH_CODE);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$ACCOUNT_NUMBER',
                           L_SV_DETAILS.CUST_AC_NO);

      DBG('now the message IS ' || SVMESSAGE);

      IF NOT FN_UPDATE_MSG(L_SV_DETAILS.SEQ_NO, SVMESSAGE) THEN
        DBG('failed for ' || L_SV_DETAILS.CUSTOMER_NO);
        DBG(SQLCODE || ' ' || SQLERRM);
        RETURN FALSE;
      END IF;
      DBG('generated AND updated successfully for ' ||
          L_SV_DETAILS.CUSTOMER_NO);
    END LOOP;
    DBG('no of customer generated :' || CUR_SV_DETAILS%ROWCOUNT);
    CLOSE CUR_SV_DETAILS;
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN FALSE;
  END FN_GENERATE_CLO_CUST_ACC;
  ------------------------------------------------------------
  FUNCTION FN_GENERATE_CHG_CARD_INFO RETURN BOOLEAN IS
    SV_MESSAGE_CHG_CARD_INFO CONSTANT VARCHAR2(32767) := '<?xml version=' ||
                                                         CHR(34) || '1.0' ||
                                                         CHR(34) ||
                                                         ' encoding=' ||
                                                         CHR(34) || 'UTF-8' ||
                                                         CHR(34) || '?>
<application xmlns=' ||
                                                         CHR(34) ||
                                                         'http://sv.bpc.in/SVAP/iss' ||
                                                         CHR(34) || '>
    <application_type>APTPISSA</application_type>
    <application_flow_id>$XML_TYPE</application_flow_id>
    <application_status>APST0006</application_status>
    <operator_id>OPERATOR1</operator_id>
    <institution_id>1001</institution_id>' ||
                                                        -- <agent_id>70000359</agent_id> -- removed and added branch code tag
                                                         '<agent_number>$BRANCH_CODE</agent_number>
    <customer_type>ENTTPERS</customer_type>
    <customer>
        <command>CMMDEXPR</command>
        <customer_number>$CUSTOMER_NO</customer_number>
        <contract>
            <command>CMMDEXPR</command>
            <product_id>$PRODUCT_ID</product_id>
            <card id=' ||
                                                         CHR(34) ||
                                                         'card_1' ||
                                                         CHR(34) || '>
                <command>CMMDEXPR</command>
                <card_id>$CARD_ID</card_id>
                <cardholder>
                    <command>CMMDEXUP</command>
                    <cardholder_name>$FULL_NAME</cardholder_name>
                    <person>
                        <command>CMMDCRUP</command>
                        <person_name language=' ||
                                                         CHR(34) ||
                                                         'LANGENG' ||
                                                         CHR(34) || '>
                            <surname>$LAST_NAME</surname>
              <first_name>$FIRST_NAME</first_name>
                        </person_name>
                        <identity_card>
                            <command>CMMDEXPR</command>
                            <id_type>$UNIQUE_ID_TYPE</id_type>
              <id_series></id_series>
              <id_number>$UNIQUE_ID_NUM</id_number>
                        </identity_card>
                    </person>
                    <address>
                        <command>CMMDCRUP</command>
                        <address_type>ADTPHOME</address_type>
            <country>$COUNTRY</country>
            <address_name language=' ||
                                                         CHR(34) ||
                                                         'LANGENG' ||
                                                         CHR(34) || '>
              <region>$addr_line1</region>
              <city>$addr_line2</city>
              <street>$addr_line3</street>
            </address_name>
            <house>$addr_line4</house>
          <apartment>$addr_line4</apartment>
                    </address>
                    <sec_word>
                        <secret_question>SEQUWORD</secret_question>
                        <secret_answer>qwerty</secret_answer>
                    </sec_word>
                    <notification>
                        <command>CMMDCREX</command>
                        <delivery_channel>3</delivery_channel>
                        <delivery_address>$MOBILE_NUMBER</delivery_address>
                        <is_active>1</is_active>
                    </notification>
                    <notification>
                        <command>CMMDCREX</command>
                        <delivery_channel>1</delivery_channel>
                        <delivery_address>$EMAIL_ID</delivery_address>
                        <is_active>1</is_active>
                    </notification>
                </cardholder>
            </card>
        </contract>
    </customer>
</application>';

    XMLTYPE VARCHAR2(4) := IFPKS_SV_CDC_CUSTOM.FN_GET_XML_TYPE('CHG_CARD_INFO');
    CURSOR CUR_SV_DETAILS IS
      SELECT *
        FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM
       WHERE STATUS = 'I'
         AND XML_TYPE = XMLTYPE;

  BEGIN
    OPEN CUR_SV_DETAILS;
    LOOP
      FETCH CUR_SV_DETAILS
        INTO L_SV_DETAILS;
      IF CUR_SV_DETAILS%NOTFOUND THEN
        EXIT;
      END IF;
      DBG('processing :' || L_SV_DETAILS.CUSTOMER_NO);

      CTRYCODE := FN_GET_CNTRY_CODE(L_SV_DETAILS.COUNTRY);
      ID_TYPE  := FN_GET_IDTYPE(L_SV_DETAILS.UNIQUE_ID_NAME);

      SVMESSAGE := SV_MESSAGE_CHG_CARD_INFO;
      SVMESSAGE := REPLACE(SVMESSAGE, '$XML_TYPE', XMLTYPE);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$CUSTOMER_NO',
                           L_SV_DETAILS.CUSTOMER_NO);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$BRANCH_CODE',
                           L_SV_DETAILS.BRANCH_CODE);
      SVMESSAGE := REPLACE(SVMESSAGE, '$PRODUCT_ID', L_SV_DETAILS.PROD_ID);
      SVMESSAGE := REPLACE(SVMESSAGE, '$CARD_ID', L_SV_DETAILS.CARD_ID);
      SVMESSAGE := REPLACE(SVMESSAGE, '$COUNTRY', CTRYCODE);
      SVMESSAGE := REPLACE(SVMESSAGE, '$FULL_NAME', L_SV_DETAILS.FULL_NAME);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$MOBILE_NUMBER',
                           L_SV_DETAILS.MOBILE_NUMBER);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$LAST_NAME',
                           SUBSTR(L_SV_DETAILS.FULL_NAME,
                                  1,
                                  (INSTR(L_SV_DETAILS.FULL_NAME, ' ') - 1)));
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$FIRST_NAME',
                           SUBSTR(L_SV_DETAILS.FULL_NAME,
                                  (INSTR(L_SV_DETAILS.FULL_NAME, ' ') + 1)));
      SVMESSAGE := REPLACE(SVMESSAGE, '$UNIQUE_ID_TYPE', ID_TYPE);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$UNIQUE_ID_NUM',
                           L_SV_DETAILS.UNIQUE_ID_VALUE);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$addr_line1',
                           L_SV_DETAILS.ADDRESS_LINE1);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$addr_line2',
                           L_SV_DETAILS.ADDRESS_LINE2);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$addr_line3',
                           L_SV_DETAILS.ADDRESS_LINE3);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$addr_line4',
                           L_SV_DETAILS.ADDRESS_LINE4);
      SVMESSAGE := REPLACE(SVMESSAGE, '$EMAIL_ID', L_SV_DETAILS.E_MAIL);

      DBG('now the message IS ' || SVMESSAGE);

      IF NOT FN_UPDATE_MSG(L_SV_DETAILS.SEQ_NO, SVMESSAGE) THEN
        DBG('failed for ' || L_SV_DETAILS.CUSTOMER_NO);
        DBG(SQLCODE || ' ' || SQLERRM);
        RETURN FALSE;
      END IF;
      DBG('generated AND updated successfully for ' ||
          L_SV_DETAILS.CUSTOMER_NO);
    END LOOP;
    DBG('no of customer generated :' || CUR_SV_DETAILS%ROWCOUNT);
    CLOSE CUR_SV_DETAILS;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN FALSE;
  END FN_GENERATE_CHG_CARD_INFO;
  ------------------------------------------------------------

  FUNCTION FN_GENERATE_CHG_ACC_STAT RETURN BOOLEAN IS

    SV_MESSAGE_CHG_ACC_STAT CONSTANT VARCHAR2(32767) := '<?xml version=' ||
                                                        CHR(34) || '1.0' ||
                                                        CHR(34) ||
                                                        ' encoding=' ||
                                                        CHR(34) || 'UTF-8' ||
                                                        CHR(34) || '?>
<application xmlns=' ||
                                                        CHR(34) ||
                                                        'http://sv.bpc.in/SVAP/iss' ||
                                                        CHR(34) || '>
    <application_type>APTPISSA</application_type>
    <application_flow_id>$XML_TYPE</application_flow_id>
    <application_status>APST0006</application_status>
    <operator_id>ADMIN</operator_id>
    <institution_id>1001</institution_id>' ||
                                                       -- <agent_id>70000359</agent_id> -- removed and added branch code tag
                                                        '<agent_number>$BRANCH_CODE</agent_number>
    <customer_type>ENTTPERS</customer_type>
    <customer>
        <command>CMMDEXPR</command>
        <customer_number>$CUSTOMER_NO</customer_number>
        <contract>
            <command>CMMDEXPR</command>
            <product_id>70000249</product_id>
            <account>
                <command>CMMDEXUP</command>
                <account_number>$ACCOUNT_NUMBER</account_number>
                <account_status>$ACC_STAT</account_status>
            </account>
        </contract>
    </customer>
</application>';

    XMLTYPE VARCHAR2(4) := IFPKS_SV_CDC_CUSTOM.FN_GET_XML_TYPE('CHG_ACC_STAT');
    CURSOR CUR_SV_DETAILS IS
      SELECT *
        FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM
       WHERE STATUS = 'I'
         AND XML_TYPE = XMLTYPE;

  BEGIN
    OPEN CUR_SV_DETAILS;
    LOOP
      FETCH CUR_SV_DETAILS
        INTO L_SV_DETAILS;
      IF CUR_SV_DETAILS%NOTFOUND THEN
        EXIT;
      END IF;
      DBG('processing :' || L_SV_DETAILS.CUSTOMER_NO);

      SELECT X.AC_STAT_NO_DR,
             X.AC_STAT_NO_CR,
             X.RECORD_STAT,
             NVL(X.AC_STAT_DORMANT, 'N')
        INTO P_AC_STAT_NO_DR,
             P_AC_STAT_NO_CR,
             P_RECORD_STAT,
             P_AC_STAT_DORMANT
        FROM STTM_CUST_ACCOUNT X
       WHERE CUST_AC_NO = L_SV_DETAILS.CUST_AC_NO;

      IF (L_SV_DETAILS.ATM_FACILITY = 'Y') THEN
        IF P_AC_STAT_DORMANT = 'N' THEN
          AC_STAT := 'ACSTACTV';
        ELSIF P_AC_STAT_NO_CR = 'N' AND P_AC_STAT_NO_DR = 'Y' THEN
          AC_STAT := 'ACSTCRED';
        ELSE
          AC_STAT := 'ACSTPEND'; -- NEED CLARIFICATION FROM BPC
        END IF;
      ELSE
        AC_STAT := 'ACSTCLSD';
      END IF;

      SVMESSAGE := SV_MESSAGE_CHG_ACC_STAT;
      SVMESSAGE := REPLACE(SVMESSAGE, '$XML_TYPE', XMLTYPE);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$CUSTOMER_NO',
                           L_SV_DETAILS.CUSTOMER_NO);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$BRANCH_CODE',
                           L_SV_DETAILS.BRANCH_CODE);
      SVMESSAGE := REPLACE(SVMESSAGE,
                           '$ACCOUNT_NUMBER',
                           L_SV_DETAILS.CUST_AC_NO);
      SVMESSAGE := REPLACE(SVMESSAGE, '$ACC_STAT', AC_STAT);

      DBG('now the message IS ' || SVMESSAGE);

      IF NOT FN_UPDATE_MSG(L_SV_DETAILS.SEQ_NO, SVMESSAGE) THEN
        DBG('failed for ' || L_SV_DETAILS.CUSTOMER_NO);
        DBG(SQLCODE || ' ' || SQLERRM);
        RETURN FALSE;
      END IF;
      DBG('generated AND updated successfully for ' ||
          L_SV_DETAILS.CUSTOMER_NO);
    END LOOP;
    DBG('no of customer generated :' || CUR_SV_DETAILS%ROWCOUNT);
    CLOSE CUR_SV_DETAILS;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN FALSE;
  END FN_GENERATE_CHG_ACC_STAT;
  ------------------------------------------------------------
  FUNCTION FN_GENERATE_SVXP_CCYRATE RETURN BOOLEAN IS

    SV_MESSAGE_SVXP CLOB := '<?xml version=' || CHR(34) || '1.0' || CHR(34) ||
                            ' encoding=' || CHR(34) || 'UTF-8' || CHR(34) || '?>
  <currency_rates xmlns=' || CHR(34) ||
                            'http://sv.bpc.in/SVXP' || CHR(34) || '>';

    XMLTYPE VARCHAR2(4) := IFPKS_SV_CDC_CUSTOM.FN_GET_XML_TYPE('CCY_RATE');
    CURSOR CUR_SV_DETAILS IS
      SELECT *
        FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM
       WHERE STATUS = 'I'
         AND XML_TYPE = XMLTYPE;

  BEGIN
    OPEN CUR_SV_DETAILS;
    LOOP
      FETCH CUR_SV_DETAILS
        INTO L_SV_DETAILS;
      IF CUR_SV_DETAILS%NOTFOUND THEN
        EXIT;
      END IF;

      SV_MESSAGE_CCY := '<currency_rate>
    <inst_id>1001</inst_id>
    <rate_type>RTTPCUST</rate_type>
    <effective_date>' ||
                        TO_CHAR(TRUNC(SYSDATE), 'YYYY-MM-dd') || 'T' ||
                        TO_CHAR(SYSDATE, 'hh:mm:ss') ||
                        '</effective_date>
    <src_currency>
      <scale>1</scale>
      <currency>$DEST_CCY</currency>
     <exponent_scale>1</exponent_scale>
    </src_currency>
    <dst_currency>
      <scale>1</scale>
      <currency>$SRC_CCY</currency>
      <exponent_scale>1</exponent_scale>
    </dst_currency>
    <rate>$BUY_RATE</rate>
    <inverted>0</inverted>
    </currency_rate>
    <currency_rate>
    <inst_id>1001</inst_id>
    <rate_type>RTTPCUST</rate_type>
    <effective_date>' ||
                        TO_CHAR(TRUNC(SYSDATE), 'YYYY-MM-dd') || 'T' ||
                        TO_CHAR(SYSDATE, 'hh:mm:ss') ||
                        '</effective_date>
    <src_currency>
      <scale>1</scale>
      <currency>$SRC_CCY</currency>
     <exponent_scale>1</exponent_scale>
    </src_currency>
    <dst_currency>
      <scale>1</scale>
      <currency>$DEST_CCY</currency>
      <exponent_scale>1</exponent_scale>
    </dst_currency>
    <rate>$SALE_RATE</rate>
    <inverted>0</inverted>
    </currency_rate>';

      SRCCCYCODE  := FN_GET_CCY_CD(L_SV_DETAILS.SRC_CCY);
      DESTCCYCODE := FN_GET_CCY_CD(L_SV_DETAILS.DEST_CCY);

      SV_MESSAGE_CCY := REPLACE(SV_MESSAGE_CCY, '$DEST_CCY', DESTCCYCODE);
      SV_MESSAGE_CCY := REPLACE(SV_MESSAGE_CCY, '$XML_TYPE', XMLTYPE);
      SV_MESSAGE_CCY := REPLACE(SV_MESSAGE_CCY, '$SRC_CCY', SRCCCYCODE);
      SV_MESSAGE_CCY := REPLACE(SV_MESSAGE_CCY,
                                '$BUY_RATE',
                                Trim(TO_char(1 / L_SV_DETAILS.BUY_RATE,
                                             '0.99999999')));
      SV_MESSAGE_CCY := REPLACE(SV_MESSAGE_CCY,
                                '$SALE_RATE',
                                Trim(TO_CHAR(L_SV_DETAILS.SALE_RATE,
                                             '9999999.99')));

      SV_MESSAGE_SVXP := SV_MESSAGE_SVXP || ' ' || SV_MESSAGE_CCY;

      DBG('generated AND updated successfully for ' || L_SV_DETAILS.SEQ_NO);
      IF NOT (FN_UPDATE_STATUS(L_SV_DETAILS.SEQ_NO, 'H')) THEN
        DBG('failed to update status' || L_SV_DETAILS.SEQ_NO);
        RETURN FALSE;
      END IF;
    END LOOP;
    SV_MESSAGE_SVXP := SV_MESSAGE_SVXP || ' ' || '</currency_rates>';
    DBG('now the message IS ' || SV_MESSAGE_SVXP);
    --FOR REC IN (SELECT SEQ_NO FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM WHERE XML_TYPE=XMLTYPE AND STATUS='I') LOOP
    IF NOT FN_UPDATE_MSG(L_SV_DETAILS.SEQ_NO, SV_MESSAGE_SVXP) THEN
      DBG('failed for ' || L_SV_DETAILS.CUSTOMER_NO);
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN FALSE;
    END IF;
    --END LOOP;
    DBG('no of currencies generated :' || CUR_SV_DETAILS%ROWCOUNT);
    CLOSE CUR_SV_DETAILS;
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN FALSE;
  END FN_GENERATE_SVXP_CCYRATE;

  ------------------------------------------------------------

  FUNCTION FN_UPDATE_MSG(P_SEQ_NO     IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.SEQ_NO%TYPE,
                         P_SV_MESSAGE IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('came to FN_UPDATE_MSG' || P_SEQ_NO);
    UPDATE IFTB_SVCARD_CUSTDETAILS_CUSTOM
       SET MESSAGE = P_SV_MESSAGE
     WHERE SEQ_NO = P_SEQ_NO;

    IF NOT (FN_UPDATE_STATUS(P_SEQ_NO, 'G')) THEN
      DBG('failed to update status' || P_SEQ_NO);
      RETURN FALSE;
    END IF;
    COMMIT;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN FALSE;
  END FN_UPDATE_MSG;

  --------------------------------------------------------------
  FUNCTION FN_UPDATE_STATUS(P_SEQ_NO IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.SEQ_NO%TYPE,
                            P_STATUS IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.STATUS%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('came to fn_update_status' || P_SEQ_NO);
    UPDATE IFTB_SVCARD_CUSTDETAILS_CUSTOM
       SET STATUS = P_STATUS
     WHERE SEQ_NO = P_SEQ_NO;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN FALSE;
  END FN_UPDATE_STATUS;

  --------------------------------------------------------------

  FUNCTION FN_GET_CUSTOMER_REL(P_STAFF IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.STAFF%TYPE)
    RETURN VARCHAR2 IS
  BEGIN
    DBG('came to fn_get_customer_rel');
    IF P_STAFF = 'Y' THEN
      CUST_REL := 'RSCBEMPL';
    ELSE
      CUST_REL := 'RSCBEXTR';
    END IF;
    RETURN CUST_REL;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in fn_get_customer_rel');
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN NULL;
  END FN_GET_CUSTOMER_REL;

  FUNCTION FN_GET_RESISIDENT_STAT(P_RES_STAT IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.RESIDENT_STATUS%TYPE)
    RETURN VARCHAR2 IS
  BEGIN
    DBG('came to fn_get_RESISIDENT_STAT');

    IF P_RES_STAT = 'R' THEN
      RES_STAT := '1';
    ELSE
      RES_STAT := '0';
    END IF;
    RETURN RES_STAT;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in fn_get_RESISIDENT_STAT');
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN NULL;
  END FN_GET_RESISIDENT_STAT;

  FUNCTION FN_GET_CNTRY_CODE(P_NATIONALITY IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.NATIONALITY%TYPE)
    RETURN STTM_COUNTRY.ISO_NUM_COUNTRY_CODE%TYPE IS
  BEGIN
    DBG('came to FN_GET_CNTRY_CODE');
    SELECT ISO_NUM_COUNTRY_CODE
      INTO COUNTRY_CODE
      FROM STTM_COUNTRY
     WHERE COUNTRY_CODE = P_NATIONALITY;
    RETURN COUNTRY_CODE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in FN_GET_CNTRY_CODE');
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN NULL;
  END FN_GET_CNTRY_CODE;

  FUNCTION FN_GET_CCY_CD(P_CCY IN VARCHAR2)
    RETURN CYTM_CCY_DEFN_MASTER.ISO_NUM_CCY_CODE%TYPE IS
  BEGIN
    DBG('came to fn_get_ccy_cd');
    SELECT ISO_NUM_CCY_CODE
      INTO CCYCODE
      FROM CYTM_CCY_DEFN_MASTER
     WHERE CCY_CODE = P_CCY;
    RETURN CCYCODE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in fn_get_ccy_cd');
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN NULL;
  END FN_GET_CCY_CD;

  --FUNCTION FN_GET_ACC_TYPE(P_ACC_TYPE IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.ACCOUNT_TYPE%TYPE)

  FUNCTION FN_GET_ACC_TYPE(P_ACC_TYPE IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.ACCOUNT_TYPE%TYPE,
                           P_ACC_CCY  IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.Ccy%type)
    RETURN VARCHAR2 IS
  BEGIN
    DBG('came to FN_GET_ACC_TYPE');
    /* IF P_ACC_TYPE = 'U' THEN
      IF P_ACC_CCY = 'USD' THEN
      ACC_TYPE := 'ACTP0120';
      ELSIF
    ELSIF P_ACC_TYPE = 'S' THEN
      ACC_TYPE := 'ACTP0110';
    END IF;*/
    SELECT DISTINCT ACC_TYPE_CODE
      INTO ACC_TYPE
      FROM IFTB_SVCARD_PRODUCT_CUSTOM X
     WHERE ACCOUNT_TYPE = P_ACC_TYPE
       AND ACCOUNT_CCY = P_ACC_CCY;

    RETURN ACC_TYPE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in FN_GET_ACC_TYPE');
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN NULL;
  END FN_GET_ACC_TYPE;

  FUNCTION FN_GET_ACC_TYPE_NEW(P_ACC_TYPE IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.ACCOUNT_TYPE%TYPE,
                               P_ACC_CCY  IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.Ccy%type,
                               P_PROD_ID  IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID%TYPE)
    RETURN VARCHAR2 IS
  BEGIN
    DBG('came to FN_GET_ACC_TYPE_NEW');

    SELECT DISTINCT ACC_TYPE_CODE
      INTO ACC_TYPE
      FROM IFTB_SVCARD_PRODUCT_CUSTOM X
     WHERE ACCOUNT_TYPE = P_ACC_TYPE
       AND ACCOUNT_CCY = P_ACC_CCY
       AND PRODUCT_ID = P_PROD_ID;

    RETURN ACC_TYPE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in FN_GET_ACC_TYPE_NEW');
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN NULL;
  END FN_GET_ACC_TYPE_NEW;

  FUNCTION FN_GET_CARD_TYPE_NEW(P_ACCOUNT_TYPE IN IFTB_SVCARD_PRODUCT_CUSTOM.ACCOUNT_TYPE%TYPE,
                                P_ACC_CCY   IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.Ccy%type,
                                P_PROD_ID   IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID%TYPE)
    RETURN VARCHAR2 IS
  BEGIN
    DBG('came to FN_GET_CARD_TYPE_NEW');

    SELECT DISTINCT CARD_TYPE
      INTO CARD_TYPE
      FROM IFTB_SVCARD_PRODUCT_CUSTOM X
     WHERE ACCOUNT_TYPE = P_ACCOUNT_TYPE
       AND ACCOUNT_CCY = P_ACC_CCY
       AND PRODUCT_ID = P_PROD_ID;

    RETURN CARD_TYPE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in FN_GET_CARD_TYPE_NEW');
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN NULL;
  END FN_GET_CARD_TYPE_NEW;

  FUNCTION FN_GET_CONTRACT_TYPE_NEW(P_ACC_TYPE IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.ACCOUNT_TYPE%TYPE,
                               P_ACC_CCY  IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.Ccy%type,
                               P_PROD_ID  IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID%TYPE)
    RETURN VARCHAR2 IS
  BEGIN
    DBG('came to FN_GET_CONTRACT_TYPE_NEW');

    SELECT DISTINCT CONTRACT_TYPE
      INTO CONTRACT_TYPE
      FROM IFTB_SVCARD_PRODUCT_CUSTOM X
     WHERE ACCOUNT_TYPE = P_ACC_TYPE
       AND ACCOUNT_CCY = P_ACC_CCY
       AND PRODUCT_ID = P_PROD_ID;

    RETURN CONTRACT_TYPE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in FN_GET_CONTRACT_TYPE_NEW');
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN NULL;
  END FN_GET_CONTRACT_TYPE_NEW;

  FUNCTION FN_GET_IDTYPE(P_ID_NAME IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.UNIQUE_ID_NAME%TYPE)
    RETURN VARCHAR2 IS
  BEGIN
    DBG('came to FN_GET_IDTYPE');
    IF P_ID_NAME = 'PASSPORT' THEN
      ID_TYPE := 'IDTP0001';
    ELSIF P_ID_NAME = 'NATIONAL ID' THEN
      ID_TYPE := 'IDTP0045';
    ELSE
      ID_TYPE := 'IDTP0005';
    END IF;
    RETURN ID_TYPE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in FN_GET_IDTYPE');
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN NULL;
  END FN_GET_IDTYPE;

  PROCEDURE PR_PROCESS_GEN_MSG IS
  BEGIN
    DBG('Started Generating ');
    IF NOT FN_GENERATE_SVXP_CCYRATE() THEN
      DBG('Failed in  FN_GENERATE_SVXP_CCYRATE');
    END IF;
    IF NOT FN_GENERATE_ADD_NEW_CUST() THEN
      DBG('Failed in  FN_GENERATE_ADD_NEW_CUST');
    END IF;
    --sampath stopped jobs for instant card project starts
    /*IF NOT FN_GENERATE_OPN_ADD_ACC() THEN
      DBG('Failed in  fn_Generate_OPN_ADD_ACC');
    END IF;
    IF NOT FN_GENERATE_CHG_CUST_DATA() THEN
      DBG('Failed in  fn_Generate_CHG_CUST_DATA');
    END IF;
    IF NOT FN_GENERATE_CLO_CUST_CARD() THEN
      DBG('Failed in  fn_Generate_CLO_CUST_CARD');
    END IF;
    IF NOT FN_GENERATE_CLO_CUST_ACC() THEN
      DBG('Failed in  fn_Generate_CLO_CUST_ACC');
    END IF;
    IF NOT FN_GENERATE_CHG_CARD_INFO() THEN
      DBG('Failed in  fn_Generate_CHG_CARD_INFO');
    END IF;
    IF NOT FN_GENERATE_CHG_ACC_STAT() THEN
      DBG('Failed in  fn_Generate_CHG_ACC_STAT');
    END IF;*/
    --sampath stopped jobs for instant card project ends

  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT PR_PROCESS_GEN ' || SQLERRM);

  END PR_PROCESS_GEN_MSG;

END IFPKS_SVCARD_DETAILS_CUSTOM;
