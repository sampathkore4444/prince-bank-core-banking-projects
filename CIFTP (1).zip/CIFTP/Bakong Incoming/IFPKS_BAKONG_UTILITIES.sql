CREATE OR REPLACE PACKAGE BODY IFPKS_BAKONG_UTILITIES IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_BAKONG_UTILITIES ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  FUNCTION FN_RETURN_MSG_ID RETURN IFTBS_BAKONG_MASTER.MSG_ID%TYPE IS
    l_bank_code cstm_arc_settle.route_code%TYPE;
    l_seq       NUMBER;
    L_MSG_ID    IFTBS_BAKONG_MASTER.MSG_ID%TYPE;
  BEGIN
    BEGIN
      SELECT route_code
        INTO l_bank_code
        FROM cstm_arc_settle
       WHERE product_code = 'BKGI'
         AND auth_stat = 'A'
         AND record_stat = 'O';
    EXCEPTION
      WHEN no_data_found THEN
        dbg('query fail with ' || SQLERRM);
        l_bank_code := 'PINCKHPPXXX';
        --RETURN FALSE;
    END;

    DBG('l_bank_code=' || l_bank_code);

    SELECT TRSQ_BAKONG_MSGID.NEXTVAL INTO L_SEQ FROM DUAL;
    L_MSG_ID := l_bank_code || lpad(TRIM(to_char(l_seq)), 5, '0');
    dbg('Returns p_msgid as ' || L_MSG_ID);
    RETURN L_MSG_ID;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END FN_RETURN_MSG_ID;

  FUNCTION GET_PARAM_VAL(PNAME VARCHAR2) RETURN VARCHAR2 RESULT_CACHE RELIES_ON(CSTB_PARAM_CUSTOM) IS
    RETVAL VARCHAR2(255);
    CURSOR C(PN VARCHAR2) IS
      SELECT PARAM_VAL FROM CSTB_PARAM_CUSTOM WHERE PARAM_NAME = PN;
  BEGIN
    OPEN C(UPPER(LTRIM(RTRIM(PNAME))));
    FETCH C
      INTO RETVAL;
    CLOSE C;
    DBG('RETVAL=' || RETVAL);
    RETURN RETVAL;
  END GET_PARAM_VAL;

  FUNCTION FN_RETURN_INCOMING_MSG RETURN CLOB IS
    L_FORMATTED_MSG CLOB;
  BEGIN
    DBG('SATRT OF FN_RETURN_INCOMING_MSG');

  --CIFTP Sampath Commented Changes Starts              
    /*L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:web="http://webservice.nbc.org.kh/">
   <soapenv:Header/>
   <soapenv:Body>
      <web:getIncomingTransaction>
         <web:cm_user_name>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_UID') ||
                       '</web:cm_user_name>
         <web:cm_password>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_PWD') ||
                       '</web:cm_password>
         <web:payee_participant_code>PINCKHPPXXX</web:payee_participant_code>
      </web:getIncomingTransaction>
   </soapenv:Body>
</soapenv:Envelope>';*/
    --CIFTP Sampath Commented Changes Ends
   
   --CIFTP Sampath Changes Starts
    L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:web="http://webservice.nbc.org.kh/">
   <soapenv:Header/>
   <soapenv:Body>
      <web:getIncomingTransaction>
         <web:cm_user_name>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_CIFTP_UID') ||
                       '</web:cm_user_name>
         <web:cm_password>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_CIFTP_PWD') ||
                       '</web:cm_password>
         <web:payee_participant_code>PINCKHPPXXX</web:payee_participant_code>
          <web:size>200</web:size>
      </web:getIncomingTransaction>
   </soapenv:Body>
</soapenv:Envelope>';
    --CIFTP Sampath Changes Ends
  
    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_INCOMING_MSG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_INCOMING_MSG');
      DBG('ERROR CODE IN FN_RETURN_INCOMING_MSG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_INCOMING_MSG=' || SQLERRM);
  END FN_RETURN_INCOMING_MSG;

  FUNCTION FN_RETURN_OUTGOING_MSG RETURN CLOB IS
    L_FORMATTED_MSG CLOB;
  BEGIN
    DBG('SATRT OF FN_RETURN_OUTGOING_MSG');

  --CIFTP Sampath Commented Changes Starts
  /*L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:web="http://webservice.nbc.org.kh/">
   <soapenv:Header/>
   <soapenv:Body>
      <web:getOutgoingTransaction>
         <web:cm_user_name>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_UID') ||
                       '</web:cm_user_name>
         <web:cm_password>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_PWD') ||
                       '</web:cm_password>
         <web:payee_participant_code>PINCKHPPXXX</web:payee_participant_code>
      </web:getOutgoingTransaction>
   </soapenv:Body>
</soapenv:Envelope>';*/
  --CIFTP Sampath Commented Changes Ends
  
  --CIFTP Sampath Changes Starts
    L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:web="http://webservice.nbc.org.kh/">
   <soapenv:Header/>
   <soapenv:Body>
      <web:getOutgoingTransaction>
         <web:cm_user_name>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_CIFTP_UID') ||
                       '</web:cm_user_name>
         <web:cm_password>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_CIFTP_PWD') ||
                       '</web:cm_password>
         <web:payee_participant_code>PINCKHPPXXX</web:payee_participant_code>
      </web:getOutgoingTransaction>
   </soapenv:Body>
</soapenv:Envelope>';
    --CIFTP Sampath Changes Ends
  
    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_OUTGOING_MSG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_OUTGOING_MSG');
      DBG('ERROR CODE IN FN_RETURN_OUTGOING_MSG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_OUTGOING_MSG=' || SQLERRM);
  END FN_RETURN_OUTGOING_MSG;

  FUNCTION FN_RETURN_REFUND_MSG RETURN CLOB IS
    L_FORMATTED_MSG CLOB;
  BEGIN
    DBG('SATRT OF FN_RETURN_REFUND_MSG');
  
  --CIFTP Sampath Commented Changes Starts
  /*L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:web="http://webservice.nbc.org.kh/">
   <soapenv:Header/>
   <soapenv:Body>
      <web:makeReverseTransaction>
         <web:cm_user_name>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_UID') ||
                       '</web:cm_user_name>
         <web:cm_password>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_PWD') ||
                       '</web:cm_password>
         <web:content_message><![CDATA[<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.007.001.05"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <CstmrPmtRvsl>
    <GrpHdr>
      <MsgId>$L_NEW_MSG_ID</MsgId>
      <CreDtTm>$L_CREDTTM</CreDtTm>
      <NbOfTxs>1</NbOfTxs>
      <DbtrAgt>
        <FinInstnId>
          <BICFI>$L_CRTRAGT_BICFI</BICFI>
        </FinInstnId>
      </DbtrAgt>
      <CdtrAgt>
        <FinInstnId>
          <BICFI>$L_DBTRAGT_BICFI</BICFI>
        </FinInstnId>
      </CdtrAgt>
    </GrpHdr>
    <OrgnlGrpInf>
      <OrgnlMsgId>$L_MSG_ID</OrgnlMsgId>
      <OrgnlMsgNmId>pain.001.001.05</OrgnlMsgNmId>
      <OrgnlCreDtTm>$L_CREDTTM</OrgnlCreDtTm>
    </OrgnlGrpInf>
    <OrgnlPmtInfAndRvsl>
      <OrgnlPmtInfId>$L_PMTINFID</OrgnlPmtInfId>
      <TxInf>
        <RvslId>Reversal001</RvslId>
        <OrgnlInstdAmt Ccy=$L_CURRENCY>$L_AMT</OrgnlInstdAmt>
        <RvsdInstdAmt Ccy=$L_CURRENCY>$L_AMT</RvsdInstdAmt>
        <RvslRsnInf>
          <Orgtr>
            <Nm>SYSTEM</Nm>
          </Orgtr>
         <Rsn>
                       <Cd>GDDS</Cd>
                   </Rsn>
        </RvslRsnInf>
        <OrgnlTxRef>

          <ReqdExctnDt>' ||
                       TO_CHAR(SYSDATE, 'YYYY-MM-DD') ||
                       '</ReqdExctnDt>
          <Dbtr>
            <Nm>$L_DBTR_NM</Nm>

          </Dbtr>
          <DbtrAcct>
            <Id>
            <Othr>
                       <Id>$L_DBTRACCT_NO</Id>
             </Othr>
             </Id>
            </DbtrAcct>
        <Cdtr>
                       <Nm>Receiver Bank Name</Nm>
                   </Cdtr>
        </OrgnlTxRef>
      </TxInf>
    </OrgnlPmtInfAndRvsl>
  </CstmrPmtRvsl>
</Document>]]></web:content_message>
      </web:makeReverseTransaction>
   </soapenv:Body>
</soapenv:Envelope>';*/
  --CIFTP Sampath Commented Changes Ends
  
  --CIFTP Sampath Changes Starts         
    L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:web="http://webservice.nbc.org.kh/">
   <soapenv:Header/>
   <soapenv:Body>
      <web:makeReverseTransaction>
         <web:cm_user_name>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_CIFTP_UID') ||
                       '</web:cm_user_name>
         <web:cm_password>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_CIFTP_PWD') ||
                       '</web:cm_password>
         <web:content_message><![CDATA[<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.007.001.05"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <CstmrPmtRvsl>
    <GrpHdr>
      <MsgId>$L_NEW_MSG_ID</MsgId>
      <CreDtTm>$L_CREDTTM</CreDtTm>
      <NbOfTxs>1</NbOfTxs>
      <InitgPty>
           <Nm>$L_INITGPTY_NM</Nm> 
      </InitgPty>
      <DbtrAgt>
        <FinInstnId>
          <BICFI>$L_CRTRAGT_BICFI</BICFI>
        </FinInstnId>
      </DbtrAgt>
      <CdtrAgt>
        <FinInstnId>
          <BICFI>$L_DBTRAGT_BICFI</BICFI>
        </FinInstnId>
      </CdtrAgt>
    </GrpHdr>
    <OrgnlGrpInf>
      <OrgnlMsgId>$L_MSG_ID</OrgnlMsgId>
      <OrgnlMsgNmId>pain.001.001.05</OrgnlMsgNmId>
      <OrgnlCreDtTm>$L_CREDTTM</OrgnlCreDtTm>
    </OrgnlGrpInf>
    <OrgnlPmtInfAndRvsl>
      <OrgnlPmtInfId>$L_PMTINFID</OrgnlPmtInfId>
      <TxInf>
        <RvslId>Reversal001</RvslId>
        <OrgnlEndToEndId>$L_PMTINFID</OrgnlEndToEndId>
        <OrgnlInstdAmt Ccy=$L_CURRENCY>$L_AMT</OrgnlInstdAmt>
        <RvsdInstdAmt Ccy=$L_CURRENCY>$L_AMT</RvsdInstdAmt>
        <RvslRsnInf>
          <Orgtr>
            <Nm>SYSTEM</Nm>
          </Orgtr>
         <Rsn>
                       <Cd>GDDS</Cd>
                   </Rsn>
        </RvslRsnInf>
        <OrgnlTxRef>

          <ReqdExctnDt>' ||
                       TO_CHAR(SYSDATE, 'YYYY-MM-DD') ||
                       '</ReqdExctnDt>
          <Dbtr>
            <Nm>$L_DBTR_NM</Nm>

          </Dbtr>
          <DbtrAcct>
            <Id>
            <Othr>
                       <Id>$L_DBTRACCT_NO</Id>
             </Othr>
             </Id>
            </DbtrAcct>
        <Cdtr>
                       <Nm>Receiver Bank Name</Nm>
                   </Cdtr>
        </OrgnlTxRef>
      </TxInf>
    </OrgnlPmtInfAndRvsl>
  </CstmrPmtRvsl>
</Document>]]></web:content_message>
      </web:makeReverseTransaction>
   </soapenv:Body>
</soapenv:Envelope>';
    --CIFTP Sampath Changes Ends 

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_REFUND_MSG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_REFUND_MSG');
      DBG('ERROR CODE IN FN_RETURN_REFUND_MSG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_REFUND_MSG=' || SQLERRM);
  END FN_RETURN_REFUND_MSG;

  FUNCTION FN_RETURN_ACK_MSG RETURN CLOB IS
    L_FORMATTED_MSG CLOB;
  BEGIN
    DBG('SATRT OF FN_RETURN_ACK_MSG');

  --CIFTP Sampath Commented Changes Starts          
  /*L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:web="http://webservice.nbc.org.kh/">
   <soapenv:Header/>
   <soapenv:Body>
      <web:makeAcknowledgement>
         <web:cm_user_name>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_UID') ||
                       '</web:cm_user_name>
         <web:cm_password>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_PWD') ||
                       '</web:cm_password>
         <web:content_message><![CDATA[<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Document xsi:schemaLocation="jaxb/iso20022/pain.002.001.06.xsd" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.06" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <CstmrPmtStsRpt>
    <GrpHdr>
      <MsgId>$L_MSG_ID</MsgId>
      <CreDtTm>$L_CREDTTM</CreDtTm>
      <InitgPty>
        <Nm>$L_INITGPTY_NM</Nm>

      </InitgPty>
      <DbtrAgt>
           <FinInstnId>
              <BICFI>PINCKHPP</BICFI>
           </FinInstnId>
        </DbtrAgt>
      <CdtrAgt>
        <FinInstnId>
          <BICFI>$L_CRTRAGT_BICFI</BICFI>
        </FinInstnId>
      </CdtrAgt>
       </GrpHdr>

    <OrgnlGrpInfAndSts>
      <OrgnlMsgId>$L_MSG_ID</OrgnlMsgId>
      <OrgnlMsgNmId>pain.001.001.05</OrgnlMsgNmId>
      <OrgnlCreDtTm>$L_CREDTTM</OrgnlCreDtTm>
    </OrgnlGrpInfAndSts>
    <OrgnlPmtInfAndSts>
      <OrgnlPmtInfId>$L_PMTINFID</OrgnlPmtInfId>
      <TxInfAndSts>
        <TxSts>ACSC</TxSts>
        <OrgnlTxRef>
          <Amt>
            <InstdAmt Ccy="USD">$L_AMT</InstdAmt>
          </Amt>
          <Dbtr>
            <Nm>$L_DBTR_NM</Nm>

          </Dbtr>
          <Cdtr>
            <Nm>$L_CDTR_NM</Nm>

          </Cdtr>
        </OrgnlTxRef>
      </TxInfAndSts>
    </OrgnlPmtInfAndSts>
  </CstmrPmtStsRpt>
</Document>]]></web:content_message>
      </web:makeAcknowledgement>
   </soapenv:Body>
</soapenv:Envelope>';*/
    --CIFTP Sampath Commented Changes Ends 

--CIFTP Sampath Changes Starts  
    L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:web="http://webservice.nbc.org.kh/">
   <soapenv:Header/>
   <soapenv:Body>
      <web:makeAcknowledgement>
         <web:cm_user_name>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_CIFTP_UID') ||
                       '</web:cm_user_name>
         <web:cm_password>' ||
                       GET_PARAM_VAL('PGW_OUT_BAKONG_CIFTP_PWD') ||
                       '</web:cm_password>
         <web:content_message><![CDATA[<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Document xsi:schemaLocation="xsd/pain.002.001.06.xsd" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.06" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <CstmrPmtStsRpt>
    <GrpHdr>
      <MsgId>$L_MSG_ID</MsgId>
      <CreDtTm>$L_CREDTTM</CreDtTm>
      <InitgPty>
        <Nm>$L_INITGPTY_NM</Nm>

      </InitgPty>
      <DbtrAgt>
           <FinInstnId>
              <BICFI>$L_DBTRAGT_BICFI</BICFI>
           </FinInstnId>
        </DbtrAgt>
      <CdtrAgt>
        <FinInstnId>
          <BICFI>$L_CRTRAGT_BICFI</BICFI>
        </FinInstnId>
      </CdtrAgt>
       </GrpHdr>

    <OrgnlGrpInfAndSts>
      <OrgnlMsgId>$L_MSG_ID</OrgnlMsgId>
      <OrgnlMsgNmId>pain.001.001.05</OrgnlMsgNmId>
      <OrgnlCreDtTm>$L_CREDTTM</OrgnlCreDtTm>
    </OrgnlGrpInfAndSts>
    <OrgnlPmtInfAndSts>
      <OrgnlPmtInfId>$L_PMTINFID</OrgnlPmtInfId>
      <TxInfAndSts>
        <OrgnlEndToEndId>$L_PMTINFID</OrgnlEndToEndId>
        <TxSts>ACSC</TxSts>
        <OrgnlTxRef>
          <Amt>
            <InstdAmt Ccy="$L_INSTD_CCY">$L_AMT</InstdAmt>
          </Amt>
          <Dbtr>
            <Nm>$L_DBTR_NM</Nm>

          </Dbtr>
          <Cdtr>
            <Nm>$L_CDTR_NM</Nm>

          </Cdtr>
        </OrgnlTxRef>
      </TxInfAndSts>
    </OrgnlPmtInfAndSts>
  </CstmrPmtStsRpt>
</Document>]]></web:content_message>
      </web:makeAcknowledgement>
   </soapenv:Body>
</soapenv:Envelope>';
    --CIFTP Sampath Changes Ends    

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_ACK_MSG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_ACK_MSG');
      DBG('ERROR CODE IN FN_RETURN_ACK_MSG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_ACK_MSG=' || SQLERRM);
  END FN_RETURN_ACK_MSG;

  FUNCTION FN_RETURN_DOCUMENT(P_CLOB IN CLOB) RETURN CLOB IS
    L_START    NUMBER := 1;
    L_END      NUMBER := 0;
    L_DOCUMENT CLOB;
  BEGIN

    --PR_RETURN_COSMETIC_XML(P_CLOB,L_DOCUMENT);

    L_START := INSTR(P_CLOB, '<Document ', l_start, 1);
    L_END   := INSTR(P_CLOB, '</Document>', l_start, 1);

    L_DOCUMENT := SUBSTR(P_CLOB,
                         L_START,
                         L_END - L_START + LENGTH('</Document>'));

    DBG('L_DOCUMENT=' || L_DOCUMENT);

    RETURN L_DOCUMENT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING DOCUMENT');
      DBG('ERROR CODE IN FN_RETURN_DOCUMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_DOCUMENT=' || SQLERRM);

  END FN_RETURN_DOCUMENT;

  PROCEDURE PR_INSERT_DOC_TRACKER(P_DOCUMENT IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_MSG_ID           IFTB_BAKONG_INCOMING_TRACK.MSG_ID%TYPE;
    L_COUNT            NUMBER;
  BEGIN
    DBG('BEFORE START OF PR_INSERT_DOC_TRACKER');

    PR_RETURN_COSMETIC_XML(P_DOCUMENT, L_COSMETIC_RES_MSG);

    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);

    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);

    L_MSG_ID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/MsgId/text()')
                .GETSTRINGVAL;

    --Check if above MSG ID already available
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
        FROM IFTBS_BAKONG_INCOMING_TRACK
       WHERE MSG_ID = L_MSG_ID;
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT := 0;
    END;

    IF L_COUNT = 0 THEN
      INSERT INTO IFTBS_BAKONG_INCOMING_TRACK
        (MSG_ID, INC_REQ_MSG, STATUS, TIME_IN)
      VALUES
        (L_MSG_ID, P_DOCUMENT, 'U', SYSDATE);
    ELSE
      DBG('This document already been inserted into incomig tracker table');
    END IF;

    DBG('AFTER INSERTING INTO PR_INSERT_DOC_TRACKER');
    DBG('COMMITTING');
    COMMIT;
    DBG('RETURNING SUCCESSFULLY FROM PR_INSERT_DOC_TRACKER');

  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      DBG('DUPLICATE DOCUMENT FOUND....SO NOT ISERTING INTO IFTBS_BAKONG_INCOMING_TRACK');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
    WHEN OTHERS THEN
      DBG('FAILED WHILE INERTING INTO PR_INSERT_DOCUMENT');
      DBG('ERROR CODE IN PR_INSERT_DOCUMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_DOCUMENT=' || SQLERRM);

  END PR_INSERT_DOC_TRACKER;
  /*
  PROCEDURE PR_INSERT_DOC_OUTGNG_TRACKER(P_DOCUMENT IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_MSG_ID           IFTB_BAKONG_INCOMING_TRACK.MSG_ID%TYPE;
    L_COUNT            NUMBER;
  BEGIN
    DBG('BEFORE START OF PR_INSERT_DOC_OUTGNG_TRACKER');

    PR_RETURN_COSMETIC_XML(P_DOCUMENT, L_COSMETIC_RES_MSG);

    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);

    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);

    L_MSG_ID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/MsgId/text()')
                .GETSTRINGVAL;

    --Check if above MSG ID already available
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
        FROM IFTBS_BAKONG_OUTGOING_TRACK
       WHERE MSG_ID = L_MSG_ID;
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT := 0;
    END;

    IF L_COUNT = 0 THEN
      INSERT INTO IFTBS_BAKONG_OUTGOING_TRACK
        (MSG_ID, OUT_REQ_MSG, TIME_IN)
      VALUES
        (L_MSG_ID, P_DOCUMENT, SYSDATE);
    ELSE
      DBG('This document already been inserted into outgoing tracker table');
    END IF;

    DBG('AFTER INSERTING INTO PR_INSERT_DOC_OUTGNG_TRACKER');
    DBG('COMMITTING');
    COMMIT;
    DBG('RETURNING SUCCESSFULLY FROM PR_INSERT_DOC_OUTGNG_TRACKER');

  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      DBG('DUPLICATE DOCUMENT FOUND....SO NOT ISERTING INTO IFTBS_BAKONG_OUTGOING_TRACK');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
    WHEN OTHERS THEN
      DBG('FAILED WHILE INERTING INTO PR_INSERT_DOCUMENT');
      DBG('ERROR CODE IN PR_INSERT_DOCUMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_DOCUMENT=' || SQLERRM);

  END PR_INSERT_DOC_OUTGNG_TRACKER;*/

  PROCEDURE PR_UPDATE_DOC_TRACKER(P_MSG_ID   IN IFTB_BAKONG_INCOMING_TRACK.MSG_ID%TYPE,
                                  P_STATUS   IN IFTB_BAKONG_INCOMING_TRACK.STATUS%TYPE,
                                  P_ERR_CODE IN ERTB_MSGS.ERR_CODE%TYPE,
                                  P_ERR_MSGS IN ERTB_MSGS.MESSAGE%TYPE) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
    L_MSG_ID IFTB_BAKONG_INCOMING_TRACK.MSG_ID%TYPE;
  BEGIN
    DBG('START OF PR_UPDATE_DOC_TRACKER');

    UPDATE IFTBS_BAKONG_INCOMING_TRACK
       SET STATUS     = P_STATUS,
           ERROR_CODE = P_ERR_CODE,
           ERROR_MSG  = P_ERR_MSGS
     WHERE MSG_ID = P_MSG_ID;

    --COMMIT;

    DBG('END OF PR_UPDATE_DOC_TRACKER');

    DBG('RETURNING SUCCESSFULLY FROM PR_UPDATE_DOC_TRACKER');

  EXCEPTION

    WHEN OTHERS THEN
      DBG('FAILED WHILE UPDATING INTO PR_UPDATE_DOC_TRACKER');
      DBG('ERROR CODE IN PR_UPDATE_DOC_TRACKER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_DOC_TRACKER=' || SQLERRM);

  END PR_UPDATE_DOC_TRACKER;

  PROCEDURE PR_INSERT_BAKONG_INCOMING(P_SOURCE_CODE   VARCHAR2,
                                      P_BRANCH_CODE   VARCHAR2,
                                      P_MSG_FLOW      VARCHAR2,
                                      P_TRN_REF_NO    VARCHAR2,
                                      P_PRODUCT_CODE  VARCHAR2,
                                      P_TRANSFER_DATE DATE,
                                      P_TXN_CCY       VARCHAR2,
                                      P_TXN_AMT       NUMBER,
                                      P_NET_TXN_AMT   NUMBER,
                                      P_EXCH_RATE     NUMBER,
                                      P_TXN_STATUS    VARCHAR2,
                                      P_TXN_REMARKS   VARCHAR2,
                                      P_MSG_ID        VARCHAR2,
                                      P_REM_ACC       VARCHAR2,

                                      P_BEN_ACC          VARCHAR2,
                                      P_BEN_BIC          VARCHAR2,
                                      P_BEN_NAME         VARCHAR2,
                                      P_BEN_ADD1         VARCHAR2,
                                      P_BEN_ADD2         VARCHAR2,
                                      P_BEN_ADD3         VARCHAR2,
                                      P_BEN_ADD4         VARCHAR2,
                                      P_ETEND_ID         VARCHAR2,
                                      P_MAKER_ID         VARCHAR2,
                                      P_MAKER_DT_STAMP   DATE,
                                      P_CHECKER_ID       VARCHAR2,
                                      P_CHECKER_DT_STAMP DATE,
                                      P_AUTH_STAT        VARCHAR2,
                                      P_RECORD_STAT      VARCHAR2,
                                      P_ONCE_AUTH        VARCHAR2,
                                      P_MOD_NO           NUMBER) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_FAST_INCOMING');
    DBG('BEFORE INSERTING INTO IFTBS_FAST_MASTER');
    INSERT INTO IFTBS_BAKONG_MASTER
      (SOURCE_CODE,
       BRANCH_CODE,
       MSG_FLOW,
       TRN_REF_NO,
       PRODUCT_CODE,
       TRANSFER_DATE,
       TXN_CCY,
       TXN_AMT,
       NET_TXN_AMT,
       EXCH_RATE,
       TXN_STATUS,
       TXN_REMARKS,
       MSG_ID,
       REM_ACC,

       BEN_ACC,
       BEN_BIC,
       BEN_NAME,
       BEN_ADD1,
       BEN_ADD2,
       BEN_ADD3,
       BEN_ADD4,
       ETEND_ID,

       MAKER_ID,
       MAKER_DT_STAMP,
       CHECKER_ID,
       CHECKER_DT_STAMP,
       AUTH_STAT,
       RECORD_STAT,
       ONCE_AUTH,
       MOD_NO)
    VALUES
      (P_SOURCE_CODE,
       P_BRANCH_CODE,
       P_MSG_FLOW,
       P_TRN_REF_NO,
       P_PRODUCT_CODE,
       P_TRANSFER_DATE,
       P_TXN_CCY,
       P_TXN_AMT,
       P_NET_TXN_AMT,
       P_EXCH_RATE,
       P_TXN_STATUS,
       P_TXN_REMARKS,
       P_MSG_ID,
       P_REM_ACC,

       P_BEN_ACC,
       P_BEN_BIC,
       P_BEN_NAME,
       P_BEN_ADD1,
       P_BEN_ADD2,
       P_BEN_ADD3,
       P_BEN_ADD4,
       P_ETEND_ID,
       P_MAKER_ID,
       P_MAKER_DT_STAMP,
       P_CHECKER_ID,
       P_CHECKER_DT_STAMP,
       P_AUTH_STAT,
       P_RECORD_STAT,
       P_ONCE_AUTH,
       P_MOD_NO);
    DBG('AFTER INSERTING INTO IFTBS_FAST_MASTER');
    --COMMIT;
    DBG('END OF PR_INSERT_FAST_INCOMING');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_FAST_WS_LOG');
  END PR_INSERT_BAKONG_INCOMING;

  PROCEDURE PR_UPDATE_STAT_BAKONG_INCOMING(P_TRN_REF_NO IN VARCHAR2,
                                           P_STATUS     IN VARCHAR2) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
    L_TXN_REMARKS IFTBS_BAKONG_MASTER.TXN_REMARKS%TYPE;
  BEGIN
    DBG('START OF PR_UPDATE_STATUS_BAKONG_INCOMING');
    DBG('BEFORE UPDATING IFTBS_BAKONG_MASTER');

    --Get Remarks for a status
    BEGIN
      SELECT VALUE
        INTO L_TXN_REMARKS
        FROM LMTM_TYPE_VALUES
       WHERE TYPE = 'BAKONG_IN_STATUS'
         AND CODE = P_STATUS;
    EXCEPTION
      WHEN OTHERS THEN
        L_TXN_REMARKS := NULL;
    END;

    DBG('L_TXN_REMARKS=' || L_TXN_REMARKS);

    UPDATE IFTBS_BAKONG_MASTER
       SET TXN_STATUS = P_STATUS, TXN_REMARKS = L_TXN_REMARKS
     WHERE TRN_REF_NO = P_TRN_REF_NO;

    DBG('AFTER UPDATING IFTBS_BAKONG_MASTER');
    --COMMIT;
    DBG('END OF PR_UPDATE_STATUS_BAKONG_INCOMING');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_STATUS_BAKONG_INCOMING');
  END PR_UPDATE_STAT_BAKONG_INCOMING;

  PROCEDURE PR_INSERT_BAKONG_WS_LOG(P_MSG_ID            IN VARCHAR2,
                                    P_SEQ_NO            IN VARCHAR2,
                                    P_TRN_REF_NO        IN VARCHAR2,
                                    P_DATE              IN DATE,
                                    P_REQ_TYPE          IN VARCHAR2,
                                    P_REQ_MSG           IN CLOB,
                                    P_PAY_TYPE          IN CHAR,
                                    P_ACK_REFUND_REASON IN VARCHAR2,
                                    P_ADDL_INFO         IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_BAKONG_WS_LOG');
    DBG('BEFORE INSERTING INTO IFTBS_BAKONG_WS_LOG');
    INSERT INTO IFTBS_BAKONG_WS_LOG
      (MSG_ID,
       SEQ_NO,
       TRN_REF_NO,
       INVOKE_DATE,
       REQ_TYPE,
       REQ_MSG,
       PAYMENT_TYPE,
       REFUND_REASON,
       ADDL_INFO)
    VALUES
      (P_MSG_ID,
       P_SEQ_NO,
       P_TRN_REF_NO,
       P_DATE,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_PAY_TYPE,
       P_ACK_REFUND_REASON,

       P_ADDL_INFO);

    COMMIT;
    DBG('AFTER INSERTING INTO IFTBS_BAKONG_WS_LOG');
    DBG('END OF PR_INSERT_BAKONG_WS_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_BAKONG_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_BAKONG_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_BAKONG_WS_LOG=' || SQLERRM);

  END PR_INSERT_BAKONG_WS_LOG;

  /*PROCEDURE PR_UPDATE_BAKONG_WS_LOG(P_MSG_ID  IN VARCHAR2,
                                    P_STATUS  IN CHAR,
                                    P_RES_MSG IN CLOB) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_BAKONG_WS_LOG');
    DBG('BEFORE UPDATING IFTBS_BAKONG_WS_LOG');
    UPDATE IFTBS_BAKONG_WS_LOG
       SET STATUS = P_STATUS, RES_MSG = P_RES_MSG
     WHERE MSG_ID = P_MSG_ID;

    --COMMIT;
    DBG('AFTER UPDATING STTB_FAST_WS_LOG');
    DBG('END OF PR_UPDATE_FAST_WS_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_BAKONG_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_BAKONG_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_BAKONG_WS_LOG=' || SQLERRM);
  END PR_UPDATE_BAKONG_WS_LOG;*/

  PROCEDURE PR_UPDATE_BAKONG_WS_LOG(P_MSG_ID     IN VARCHAR2,
                                    P_STATUS     IN CHAR,
                                    P_RES_MSG    IN CLOB,
                                    P_TRN_REF_NO IN VARCHAR2) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF OVERLOADED PR_UPDATE_BAKONG_WS_LOG');
    DBG('BEFORE UPDATING IFTBS_BAKONG_WS_LOG');
    IF P_TRN_REF_NO IS NOT NULL THEN
      UPDATE IFTBS_BAKONG_WS_LOG
         SET STATUS = P_STATUS, RES_MSG = P_RES_MSG
       WHERE MSG_ID = P_MSG_ID
         AND TRN_REF_NO = P_TRN_REF_NO;
    END IF;
    --COMMIT;
    DBG('AFTER UPDATING STTB_FAST_WS_LOG');
    DBG('END OF OVERLOADED PR_UPDATE_FAST_WS_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN OVERLOADED PR_UPDATE_BAKONG_WS_LOG');
      DBG('ERROR CODE IN OVERLOADED PR_UPDATE_BAKONG_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN OVERLOADED PR_UPDATE_BAKONG_WS_LOG=' ||
          SQLERRM);
  END PR_UPDATE_BAKONG_WS_LOG;

  PROCEDURE PR_UPDATE_BAKONG_WS_SEQ_LOG(P_MSG_ID  IN VARCHAR2,
                                        P_SEQ_NO  IN VARCHAR2,
                                        P_STATUS  IN CHAR,
                                        P_RES_MSG IN CLOB) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF OVERLOADED PR_UPDATE_BAKONG_WS_SEQ_LOG');
    DBG('BEFORE UPDATING IFTBS_BAKONG_WS_LOG');
    UPDATE IFTBS_BAKONG_WS_LOG
       SET STATUS = P_STATUS, RES_MSG = P_RES_MSG
     WHERE MSG_ID = P_MSG_ID
       AND SEQ_NO = P_SEQ_NO;
    --COMMIT;
    DBG('AFTER UPDATING STTB_FAST_WS_LOG');
    DBG('END OF OVERLOADED PR_UPDATE_BAKONG_WS_SEQ_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN OVERLOADED PR_UPDATE_BAKONG_WS_SEQ_LOG');
      DBG('ERROR CODE IN OVERLOADED PR_UPDATE_BAKONG_WS_SEQ_LOG=' ||
          SQLCODE);
      DBG('ERROR MESSAGE IN OVERLOADED PR_UPDATE_BAKONG_WS_SEQ_LOG=' ||
          SQLERRM);
  END PR_UPDATE_BAKONG_WS_SEQ_LOG;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN

    SELECT TRSQ_BAKONG_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;

    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

    RETURN L_REF;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2) IS

    --P_COSMETIC_XML VARCHAR2(32000);

  BEGIN

    P_COSMETIC_XML := P_XML;

    --This is for Refund Response
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"><SOAP-ENV:Header/><SOAP-ENV:Body><ns2:makeReverseTransactionResponse xmlns:ns2="http://webservice.nbc.org.kh/"><ns2:return><?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                              NULL);

    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '</ns2:return></ns2:makeReverseTransactionResponse></SOAP-ENV:Body></SOAP-ENV:Envelope>',
                              NULL);

    --This is for Acknowledgement
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"',
                              NULL);

    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xmlns:ns2="http://webservice.nbc.org.kh/"',
                              NULL);

    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                              NULL);

    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.06"',
                              NULL);

    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<SOAP-ENV:Envelope><SOAP-ENV:Header/><SOAP-ENV:Body><ns2:makeAcknowledgementResponse><ns2:return>',
                              NULL);

    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '</ns2:return></ns2:makeAcknowledgementResponse></SOAP-ENV:Body></SOAP-ENV:Envelope>',
                              NULL);

    --This is for Incoming BAKONG Transaction
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.05"',
                              NULL);

    --This is for Fund Transfer
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xsi:schemaLocation="xsd/pain.001.001.05.xsd" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.05" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"',
                              NULL);

    --This is for makeReverse API
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><ns2:makeReverseTransactionResponse xmlns:ns2="http://fastwebservice.nbc.org.kh/"><return><?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                              NULL);
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xsi:schemaLocation="xsd/pain.002.001.06.xsd" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.06" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"',
                              NULL);

    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '</return></ns2:makeReverseTransactionResponse></soap:Body></soap:Envelope>',
                              NULL);

    --This is for Ack API
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><ns2:makeAcknowledgmentResponse xmlns:ns2="http://fastwebservice.nbc.org.kh/"><return><?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                              NULL);
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '</return></ns2:makeAcknowledgmentResponse></soap:Body></soap:Envelope>',
                              NULL);

    --RETURN P_COSMETIC_XML;

  END PR_RETURN_COSMETIC_XML;

  FUNCTION FN_BAKONG_HTTP_CALL(p_out_msg VARCHAR2, p_in_resp IN OUT CLOB)
    RETURN BOOLEAN IS
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_buffer_size   NUMBER(10) := 512;
    l_substring_msg VARCHAR2(32767);
    l_raw_data      RAW(2000);
    l_clob_response CLOB;
    l_url           cstb_param.param_val%TYPE;
    l_resp_ok       BOOLEAN;
    l_resp_num      NUMBER;

  BEGIN
    dbg('In FN_BAKONG_HTTP_CALL');
    dbg('Length of p_out_msg=' || length(p_out_msg));
    dbms_lob.createtemporary(lob_loc => l_clob_response, cache => TRUE);

                           
    --l_url := get_param_val('PGW_OUT_BAKONG_URL'); --CIFTP Sampath Changes
	l_url := get_param_val('PGW_OUT_BAKONG_CIFTP_URL'); --CIFTP Sampath Changes

    dbg('l_url-->' || l_url);
    l_http_request := utl_http.begin_request(url          => l_url,
                                             method       => 'POST',
                                             http_version => 'HTTP/1.1');
    utl_http.set_header(l_http_request, 'User-Agent', 'Mozilla/4.0');
    utl_http.set_header(l_http_request, 'Connection', 'close');
    utl_http.set_header(l_http_request,
                        'Content-Type',
                        'text/xml; charset=utf-8');
    -- UTL_HTTP.set_header (l_http_request, 'Content-Length', lengthb(CONVERT(p_out_msg, 'UTF8')));

    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
    <<request_loop>>

    FOR i IN 0 .. ceil(length(p_out_msg) / l_buffer_size) - 1 LOOP
      l_substring_msg := substr(p_out_msg,
                                i * l_buffer_size + 1,
                                l_buffer_size);
      BEGIN
        l_raw_data := utl_raw.cast_to_raw(l_substring_msg);
        utl_http.write_raw(r => l_http_request, data => l_raw_data);
      EXCEPTION
        WHEN no_data_found THEN
          dbg('Request Loop NDF');
          EXIT request_loop;
      END;
    END LOOP request_loop;
    l_http_response := utl_http.get_response(l_http_request);
    dbg('Response> status_code: "' || l_http_response.status_code || '"');

    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;

    DBG('l_resp_num=' || l_resp_num);

    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;

    DBG('BEFORE IF');

    IF l_resp_ok THEN
      BEGIN
        <<response_loop>>
        LOOP
          utl_http.read_raw(l_http_response, l_raw_data, l_buffer_size);
          l_clob_response := l_clob_response ||
                             --utl_raw.cast_to_varchar2(l_raw_data);
               CONVERT(utl_raw.cast_to_varchar2(l_raw_data)||'','WE8MSWIN1252','UTF8');
                          
                       
        END LOOP response_loop;
      EXCEPTION
        WHEN utl_http.end_of_body THEN
          utl_http.end_response(l_http_response);
        WHEN OTHERS THEN
          dbg('Inside Exception others in response');
          dbg(SQLERRM);
          utl_http.end_response(l_http_response);
      END;
      dbg('Out of Loop');
      --dbg('Length of response-->' || dbms_lob.getlength(l_clob_response));
      -- dbg('value of response-->' ||
      --    dbms_lob.substr(l_clob_response, 32767));
      p_in_resp := l_clob_response;

    END IF;

    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;

    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;

    dbms_lob.freetemporary(l_clob_response);
  
    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      RETURN FALSE;
  END FN_BAKONG_HTTP_CALL;
  
  FUNCTION FN_BAKONG_HTTP_CALL(p_out_msg  VARCHAR2,
                               p_in_resp  IN OUT CLOB,
                               P_REQ_TYPE IN VARCHAR2) RETURN BOOLEAN IS
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_buffer_size   NUMBER(10) := 512;
    l_substring_msg VARCHAR2(32767);
    l_raw_data      RAW(2000);
    l_clob_response CLOB;
    l_url           cstb_param.param_val%TYPE;
    l_resp_ok       BOOLEAN;
    l_resp_num      NUMBER;
  
  BEGIN
    dbg('In FN_BAKONG_HTTP_CALL');
    dbg('Length of p_out_msg=' || length(p_out_msg));
    dbms_lob.createtemporary(lob_loc => l_clob_response, cache => TRUE);
  
    --l_url := get_param_val('PGW_OUT_BAKONG_URL');
    IF P_REQ_TYPE = 'GETINC' THEN
    
      l_url := get_param_val('PGW_OUT_BAKONG_CIFTP_URL');
    
    ELSIF P_REQ_TYPE = 'MAKEACK' THEN
    
      l_url := get_param_val('PGW_OUT_BAKONG_CIFTP_URL');
    
    ELSIF P_REQ_TYPE = 'REFUND' THEN
    
      l_url := get_param_val('PGW_OUT_BAKONG_CIFTP_URL');
    
    END IF;
  
    dbg('l_url-->' || l_url);
    l_http_request := utl_http.begin_request(url          => l_url,
                                             method       => 'POST',
                                             http_version => 'HTTP/1.1');
    utl_http.set_header(l_http_request, 'User-Agent', 'Mozilla/4.0');
    utl_http.set_header(l_http_request, 'Connection', 'close');
    --utl_http.set_header(l_http_request,
    --                  'Content-Type',
    --                 'text/xml; charset=utf-8');
    --UTL_HTTP.set_header (l_http_request, 'Content-Length', lengthb(CONVERT(p_out_msg, 'UTF8')));
  
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
    <<request_loop>>
  
    FOR i IN 0 .. ceil(length(p_out_msg) / l_buffer_size) - 1 LOOP
      l_substring_msg := substr(p_out_msg,
                                i * l_buffer_size + 1,
                                l_buffer_size);
      BEGIN
        l_raw_data := utl_raw.cast_to_raw(l_substring_msg);
        utl_http.write_raw(r => l_http_request, data => l_raw_data);
      EXCEPTION
        WHEN no_data_found THEN
          dbg('Request Loop NDF');
          EXIT request_loop;
      END;
    END LOOP request_loop;
    l_http_response := utl_http.get_response(l_http_request);
    dbg('Response> status_code: "' || l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    DBG('l_resp_num=' || l_resp_num);
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    DBG('BEFORE IF');
  
    IF l_resp_ok THEN
      BEGIN
        <<response_loop>>
        LOOP
          utl_http.read_raw(l_http_response, l_raw_data, l_buffer_size);
          l_clob_response := l_clob_response ||
                            --utl_raw.cast_to_varchar2(l_raw_data);
                             CONVERT(utl_raw.cast_to_varchar2(l_raw_data) || '',
                                     'WE8MSWIN1252',
                                     'UTF8');
        END LOOP response_loop;
      EXCEPTION
        WHEN utl_http.end_of_body THEN
          utl_http.end_response(l_http_response);
        WHEN OTHERS THEN
          dbg('Inside Exception others in response');
          dbg(SQLERRM);
          utl_http.end_response(l_http_response);
      END;
      dbg('Out of Loop');
      dbg('Length of response-->' || dbms_lob.getlength(l_clob_response));
      --dbg('value of response-->' ||
      --dbms_lob.substr(l_clob_response, 32767));
    
      l_clob_response := regexp_replace(l_clob_response, '&lt;', '<');
      l_clob_response := regexp_replace(l_clob_response, '&gt;', '>');
    
      p_in_resp := l_clob_response;
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    dbms_lob.freetemporary(l_clob_response);
  
    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      
      RETURN FALSE;
  END FN_BAKONG_HTTP_CALL;

  FUNCTION FN_BAKONG_HTTP_CALL_FAULTY_ACK(p_out_msg VARCHAR2,
                                   p_in_resp IN OUT CLOB) RETURN BOOLEAN IS

  
  BEGIN
    RETURN FALSE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      RETURN FALSE;
  END FN_BAKONG_HTTP_CALL_FAULTY_ACK;

  PROCEDURE PR_PROCESS_BAKONG_INCOMING_TXN /*(P_DOCUMENT   IN CLOB,
                                                                                                                                                                                                                                                                                                      P_ERR_CODE   OUT VARCHAR2,                                                                                                                                                                                                                                                                                                   P_ERR_PARAMS OUT VARCHAR2)*/

   IS

    L_MSG_ID      IFTB_BAKONG_MASTER.MSG_ID%TYPE;
    L_NEW_MSG_ID  IFTB_BAKONG_MASTER.MSG_ID%TYPE;
    L_CREDTTM     VARCHAR2(100);
    L_NBOFTXS     CHAR(10);
    L_CTRLSUM     VARCHAR2(100);
    L_INITGPTY_NM VARCHAR2(100);

    L_PMTINFID    VARCHAR2(100);
    L_PMTMTD      VARCHAR2(100);
    L_BTCHBOOKG   VARCHAR2(100);
    L_REQDEXCTNDT VARCHAR2(100);
    L_DBTR_NM     VARCHAR2(1000);--IFTB_BAKONG_MASTER.REM_NAME%TYPE;
    --L_DBTRACCT_NO   IFTB_BAKONG_MASTER.REM_ACC%TYPE;
    L_DBTRACCT_NO   VARCHAR2(100);
    L_DBTRACCT_CCY  IFTB_BAKONG_MASTER.TXN_CCY%TYPE;
    L_DBTRAGT_BICFI IFTB_BAKONG_MASTER.BEN_BIC%TYPE;
    --L_INSTRID       IFTB_BAKONG_MASTER.INSTR_ID%TYPE;
    --L_ENDTOENDID    IFTB_BAKONG_MASTER.ETEND_ID%TYPE;
    L_AMT IFTB_BAKONG_MASTER.TXN_AMT%TYPE;

    L_CHRGBR        VARCHAR2(100);
    L_CRTRAGT_BICFI IFTB_BAKONG_MASTER.BEN_BIC%TYPE;
    L_CDTR_NM       VARCHAR2(105); --IFTB_BAKONG_MASTER.BEN_NAME%TYPE;
    L_CDTRACCT_NO   IFTB_BAKONG_MASTER.BEN_ACC%TYPE;
    L_PURP          IFTB_BAKONG_MASTER.TXN_REMARKS%TYPE;

    L_TY_RTUPLD             DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC;
    L_IB_FLAG               VARCHAR2(1) DEFAULT 'Y';
    L_ARC_MAINT             IFTMS_ARC_MAINT%ROWTYPE;
    L_CUST_AC               STTM_CUST_ACCOUNT%ROWTYPE;
    L_CUST                  STTM_CUSTOMER%ROWTYPE;
    L_TRN_REF_NO            IFTB_BAKONG_MASTER.TRN_REF_NO%TYPE;
    PKG_DETB_RTL_TELLER_REC DETBS_RTL_TELLER%ROWTYPE;
    L_SERIAL_NO             VARCHAR2(16);
    L_TXN_STATUS            VARCHAR2(10);

    P_DOCUMENT_XML     XMLTYPE;
    L_FORMATTED_MSG    CLOB;
    L_COUNT            NUMBER;
    L_IN_RESP          CLOB;
    L_COSMETIC_RES_MSG CLOB;
    P_ERR_CODE         VARCHAR2(255);
    P_ERR_PARAMS       VARCHAR2(255);
    L_RATE_FLAG        NUMBER;
    L_PROD             CSTM_PRODUCT%ROWTYPE;
    L_TXN_AMT          IFTBS_BAKONG_MASTER.TXN_AMT%TYPE;
    L_EXCH_RATE        IFTBS_BAKONG_MASTER.EXCH_RATE%TYPE;
    L_RATE_CODE1       CSTM_PRODUCT.RATE_CODE_PREFERRED%TYPE;
    L_REFUND_CODE      VARCHAR2(20);
    L_TRN_REF          VARCHAR2(255);
    L_TXN_CCY          VARCHAR2(3);
    L_TXN_CCY_POS      NUMBER;
    L_STTB_ACCOUNT     STTB_ACCOUNT%ROWTYPE;
    P_ERROR_CODE       ERTB_MSGS.ERR_CODE%TYPE;
    P_ERROR_MSG        ERTB_MSGS.MESSAGE%TYPE;
    L_SEQ_NO           VARCHAR2(23);
    L_GEN_SEQ_NO       VARCHAR2(100);

    L_PRODUCT_CODE CSTB_PARAM_CUSTOM.PARAM_VAL%TYPE;
    L_ENDTOENDID IFTB_BAKONG_MASTER.ETEND_ID%TYPE; --ciftp sampath changes 


  L_MAS_DUP_COUNT NUMBER := 0;
    L_WS_DUP_COUNT  NUMBER := 0;

    CURSOR C1 IS
      SELECT *
        FROM IFTBS_BAKONG_INCOMING_TRACK A
       WHERE STATUS IN ('U') --('U', 'E')
         AND A.MSG_ID NOT IN (SELECT MSG_ID
                                FROM IFTB_BAKONG_MASTER
                               WHERE TXN_STATUS IN ('ACSP', 'RJCT')
                                 AND AUTH_STAT = 'A')
                              
                      
     AND A.MSG_ID NOT IN (select MSG_ID from iftb_bakong_ws_log a);
 /* SELECT *
        FROM IFTBS_BAKONG_INCOMING_TRACK A
       WHERE MSG_ID IN ('943ace01ccfb4556bec3c9a36ff633f8') AND A.MSG_ID NOT IN (SELECT MSG_ID
                                FROM IFTB_BAKONG_MASTER
                               WHERE TXN_STATUS IN ('ACSP', 'RJCT')
                                 AND AUTH_STAT = 'A');*/
  BEGIN

    --GLOBAL.PR_INIT('000', 'SYSTEM');

    DBG('INSIDE PR_PROCESS_BAKONG_INCOMING_TXN');

    /*--Get Product code for Bakong Incoming Deposit from cstb_param_custom
    BEGIN
      SELECT PARAM_VAL
        INTO L_PRODUCT_CODE
        FROM CSTB_PARAM_CUSTOM
       WHERE PARAM_NAME = 'BAKONG_INC_PRODUCT';

    EXCEPTION
      WHEN OTHERS THEN
        L_PRODUCT_CODE := 'BKGI';
    END;

    --Get product Code
    SELECT X.*
      INTO L_PROD
      FROM CSTM_PRODUCT X
     WHERE PRODUCT_CODE = L_PRODUCT_CODE;*/

    FOR G IN C1 LOOP
      BEGIN

        --GLOBAL.PR_INIT('000', 'SYSTEM');

        L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

        PR_RETURN_COSMETIC_XML(G.INC_REQ_MSG, L_COSMETIC_RES_MSG);

        DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);

        P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);

        /*      --check if it is already refunded by other bank since message id is different
          L_REFUND_CODE := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Purp/Cd/text()')
                           .GETSTRINGVAL;
        */
        --IF L_REFUND_CODE = 'REFU' THEN

        --Do Reversal into a
        --  IFPKS_IFDOFAST_CUSTOM.PR_REVERSE_FAST_OUT_TXN(P_DOCUMENT_XML);

        --ELSE

        L_MSG_ID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/MsgId/text()')
                    .GETSTRINGVAL;
        DBG('L_MSG_ID=' || L_MSG_ID);

        L_CREDTTM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/CreDtTm/text()')
                     .GETSTRINGVAL;
        DBG('L_CreDtTm=' || L_CreDtTm);

        L_NBOFTXS := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/NbOfTxs/text()')
                     .GETSTRINGVAL;
        DBG('L_NbOfTxs=' || L_NbOfTxs);

        L_CTRLSUM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/CtrlSum/text()')
                     .GETSTRINGVAL;
        DBG('L_CTRLSUM=' || L_CTRLSUM);

        L_INITGPTY_NM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/InitgPty/Nm/text()')
                         .GETSTRINGVAL;
        DBG('L_INITGPTY_NM=' || L_INITGPTY_NM);

        L_INITGPTY_NM := 'PRINCE_DEF';

        L_PMTINFID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/PmtInfId/text()')
                      .GETSTRINGVAL;
        DBG('L_PMTINFID=' || L_PMTINFID);

        L_PMTMTD := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/PmtMtd/text()')
                    .GETSTRINGVAL;
        DBG('L_PMTMTD=' || L_PMTMTD);

        L_BTCHBOOKG := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/BtchBookg/text()')
                       .GETSTRINGVAL;
        DBG('L_BTCHBOOKG=' || L_BTCHBOOKG);

        L_REQDEXCTNDT := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/ReqdExctnDt/text()')
                         .GETSTRINGVAL;
        DBG('L_REQDEXCTNDT=' || L_REQDEXCTNDT);

        L_DBTR_NM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/Dbtr/Nm/text()')
                     .GETSTRINGVAL;
        DBG('L_DBTR_NM=' || L_DBTR_NM);

        L_DBTR_NM := 'PRINCE_DEF';

        L_DBTRACCT_NO := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/DbtrAcct/Id/Othr/Id/text()')
                         .GETSTRINGVAL;
        DBG('L_DBTRACCT_NO=' || L_DBTRACCT_NO);

        L_DBTRACCT_CCY := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/DbtrAcct/Ccy/text()')
                          .GETSTRINGVAL;
        DBG('L_DBTRACCT_CCY=' || L_DBTRACCT_CCY);

        L_DBTRAGT_BICFI := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/DbtrAgt/FinInstnId/BICFI/text()')
                           .GETSTRINGVAL;
        DBG('L_DBTRAGT_BICFI=' || L_DBTRAGT_BICFI);

        /*L_INSTRID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/PmtId/InstrId/text()')
                     .GETSTRINGVAL;
        DBG('L_INSTRID=' || L_INSTRID);

        L_ENDTOENDID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/PmtId/EndToEndId/text()')
                        .GETSTRINGVAL;
        DBG('L_ENDTOENDID=' || L_ENDTOENDID);*/

    --ciftp sampath changes starts
        L_ENDTOENDID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/PmtId/EndToEndId/text()')
                        .GETSTRINGVAL;
        DBG('L_ENDTOENDID=' || L_ENDTOENDID);
        --ciftp sampath changes ends  
    
        L_AMT := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Amt/InstdAmt/text()')
                 .GETSTRINGVAL;
        DBG('L_AMT=' || L_AMT);

    --check if already available
        BEGIN
          SELECT COUNT(1)
            INTO L_MAS_DUP_COUNT
            FROM IFTB_BAKONG_MASTER A
           WHERE A.MSG_ID = L_MSG_ID;

        EXCEPTION
          WHEN OTHERS THEN
            L_MAS_DUP_COUNT := 0;
            CONTINUE;
        END;

        BEGIN
          SELECT COUNT(1)
            INTO L_WS_DUP_COUNT
            FROM IFTB_BAKONG_WS_LOG A
           WHERE A.MSG_ID = L_MSG_ID;

        EXCEPTION
          WHEN OTHERS THEN
            L_WS_DUP_COUNT := 0;
            CONTINUE;
        END;

        DBG('L_MAS_DUP_COUNT=' || L_MAS_DUP_COUNT);
        DBG('L_WS_DUP_COUNT=' || L_WS_DUP_COUNT);

        IF L_MAS_DUP_COUNT > 0 OR L_WS_DUP_COUNT > 0 THEN
          CONTINUE;
        END IF;

        SELECT INSTR(P_DOCUMENT_XML, '<InstdAmt Ccy="USD">')
          INTO L_TXN_CCY_POS
          FROM DUAL;

        IF L_TXN_CCY_POS > 0 THEN
          L_TXN_CCY := 'USD';
        ELSE
          L_TXN_CCY := 'KHR';
        END IF;

        DBG('L_TXN_CCY =' || L_TXN_CCY);

        L_CHRGBR := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/ChrgBr/text()')
                    .GETSTRINGVAL;
        DBG('L_CHRGBR=' || L_CHRGBR);

        L_CRTRAGT_BICFI := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/CdtrAgt/FinInstnId/BICFI/text()')
                           .GETSTRINGVAL;
        DBG('L_CRTRAGT_BICFI=' || L_CRTRAGT_BICFI);

        L_CDTR_NM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Cdtr/Nm/text()')
                     .GETSTRINGVAL;
        DBG('L_CDTR_NM=' || L_CDTR_NM);

        L_CDTRACCT_NO := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/CdtrAcct/Id/Othr/Id/text()')
                         .GETSTRINGVAL;
        DBG('L_CDTRACCT_NO=' || L_CDTRACCT_NO);

        L_PURP := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Purp/Cd/text()')
                  .GETSTRINGVAL;
        DBG('L_PURP=' || L_PURP);

        --Get Ben Acc details
        BEGIN
          SELECT *
            INTO L_CUST_AC
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = L_CDTRACCT_NO;

        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_AC := NULL;
            DBG('FAILED IN GETTING ACCOUNT DETAILS');
        END;

        --Get Account details
        BEGIN
          SELECT *
            INTO L_STTB_ACCOUNT
            FROM STTB_ACCOUNT
           WHERE AC_GL_NO = L_CDTRACCT_NO;

        EXCEPTION
          WHEN OTHERS THEN
            L_STTB_ACCOUNT := NULL;
            DBG('FAILED IN GETTING ACCOUNT DETAILS');
        END;

        --Get Count of Beneficiary Account
        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = L_CDTRACCT_NO
       AND AUTH_STAT = 'A'
       AND ACCOUNT_TYPE IN ('S','U');

        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;

    DBG('L_COUNT='||L_COUNT);

        IF L_COUNT = 0 OR L_CUST_AC.RECORD_STAT = 'C' OR
           L_STTB_ACCOUNT.AC_STAT_FROZEN = 'Y' OR
           L_STTB_ACCOUNT.AC_STAT_NO_CR = 'Y' /*OR
                                                       L_STTB_ACCOUNT.AC_STAT_DORMANT = 'Y'*/
         THEN

          DBG('SOMETHING WRONG WITH BENEFICIARY ACCOUNT......SO LETS REJECT/REFUND INCOMING FAST TRANSACTION');

          --SAVEPOINT B;

          --Get Refund Message
          L_FORMATTED_MSG := FN_RETURN_REFUND_MSG;

          DBG('BEFORE REPLACEMENT OF REFUND XML=' || L_FORMATTED_MSG);

          --Replace tags with actual values
          L_NEW_MSG_ID := FN_RETURN_MSG_ID;

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_NEW_MSG_ID',
                                     L_NEW_MSG_ID);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_MSG_ID', L_MSG_ID);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_CREDTTM',
                                     L_CREDTTM);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_INITGPTY_NM',
                                     L_INITGPTY_NM);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_CRTRAGT_BICFI',
                                     L_CRTRAGT_BICFI);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_DBTRAGT_BICFI',
                                     L_DBTRAGT_BICFI);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_PMTINFID',
                                     L_PMTINFID);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_ENDTOENDID',
                   L_ENDTOENDID); --ciftp sampath changes                    
          --'123456789012-000000009008/AAAA0056'); --ciftp sampath changes

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMT', L_AMT);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_DBTR_NM',
                                     L_DBTR_NM);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_DBTRACCT_NO',
                                     L_DBTRACCT_NO);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_CDTR_NM',
                                     L_CDTR_NM);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_CURRENCY',
                                     '"' || L_TXN_CCY || '"');

          DBG('AFTER REPLACEMENT OF REFUND XML=' || L_FORMATTED_MSG);

          --Log Refund Request to NBC
          DBG('LOGGING REFUND REQUEST TO NBC');
          IF L_COUNT = 0 THEN
            P_ERROR_CODE := 'FT-MTUP100';
            P_ERROR_MSG  := 'Beneficiary Account Not Found/UN-AUTH';
            PR_INSERT_BAKONG_WS_LOG(L_MSG_ID,
                                    L_GEN_SEQ_NO,
                                    NULL,
                                    SYSDATE,
                                    'Refund',
                                    L_FORMATTED_MSG,
                                    'I',
                                    P_ERROR_MSG,
                                    'Refund for Incoming');

          ELSIF L_CUST_AC.RECORD_STAT = 'C' THEN
            P_ERROR_CODE := 'AC-VAC12';
            P_ERROR_MSG  := 'Beneficiary Account Status Closed';
            PR_INSERT_BAKONG_WS_LOG(L_MSG_ID,
                                    L_GEN_SEQ_NO,
                                    NULL,
                                    SYSDATE,
                                    'Refund',
                                    L_FORMATTED_MSG,
                                    'I',
                                    P_ERROR_MSG,
                                    'Refund for Incoming');

          ELSIF L_STTB_ACCOUNT.AC_STAT_FROZEN = 'Y' THEN
            P_ERROR_CODE := 'AC-VAC04';
            P_ERROR_MSG  := 'Beneficiary Account Status Frozen';
            PR_INSERT_BAKONG_WS_LOG(L_MSG_ID,
                                    L_GEN_SEQ_NO,
                                    NULL,
                                    SYSDATE,
                                    'Refund',
                                    L_FORMATTED_MSG,
                                    'I',
                                    P_ERROR_MSG,
                                    'Refund for Incoming');

          ELSIF L_STTB_ACCOUNT.AC_STAT_NO_CR = 'Y' THEN
            P_ERROR_CODE := 'AC-VAC03';
            P_ERROR_MSG  := 'Beneficiary Account Status No Credit';
            PR_INSERT_BAKONG_WS_LOG(L_MSG_ID,
                                    L_GEN_SEQ_NO,
                                    NULL,
                                    SYSDATE,
                                    'Refund',
                                    L_FORMATTED_MSG,
                                    'I',
                                    P_ERROR_MSG,
                                    'Refund for Incoming');

            /* ELSIF L_STTB_ACCOUNT.AC_STAT_DORMANT = 'Y' THEN
            P_ERROR_CODE := 'AC-VAC05';
            P_ERROR_MSG  := 'Beneficiary Account Status Dormant';
            PR_INSERT_BAKONG_WS_LOG(L_MSG_ID,
                                    NULL,
                                    SYSDATE,
                                    'Refund',
                                    L_FORMATTED_MSG,
                                    'I',
                                    P_ERROR_MSG,
                                    'Refund for Incoming');*/
          END IF;

          --IF NOT FN_BAKONG_HTTP_CALL(L_FORMATTED_MSG, L_IN_RESP) THEN --CiFTP changes
      IF NOT FN_BAKONG_HTTP_CALL(L_FORMATTED_MSG, L_IN_RESP, 'REFUND') THEN
      --CiFTP changes                    
      DBG('FAILED IN REVERSING THE REFUND API');
            --ROLLBACK TO B;
            PR_UPDATE_DOC_TRACKER(L_MSG_ID, 'E', P_ERR_CODE, P_ERR_PARAMS);
            COMMIT;
          ELSE
            --Log Refund Response
            L_IN_RESP := REPLACE(L_IN_RESP, '&lt;', '<');
            L_IN_RESP := REPLACE(L_IN_RESP, '&gt;', '>');
            DBG('L_IN_RESP=' || L_IN_RESP);

            --Get Cosmetic XML
            PR_RETURN_COSMETIC_XML(L_IN_RESP, L_COSMETIC_RES_MSG);

            DBG('L_COSMETIC_RES_MSG OF REFUND RESPONSE=' ||
                L_COSMETIC_RES_MSG);

            --Convert into XMLTYPE
            P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);

            --Get Node Value
            L_TXN_STATUS := P_DOCUMENT_XML.EXTRACT('/Document/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/TxSts/text()')
                            .GETSTRINGVAL;

            DBG('L_TXN_STATUS=' || L_TXN_STATUS);

            --Log Refund Response from NBC
            DBG('LOGGING REFUND RESPONSE FROM NBC');

            --Just check this tomorrow
            PR_UPDATE_STAT_BAKONG_INCOMING(L_TRN_REF_NO, L_TXN_STATUS);

            --Update status to processed for current row
            PR_UPDATE_DOC_TRACKER(L_MSG_ID, 'R', P_ERROR_CODE, P_ERROR_MSG);

            PR_UPDATE_BAKONG_WS_SEQ_LOG(L_MSG_ID,
                                        L_GEN_SEQ_NO,
                                        L_TXN_STATUS,
                                        L_IN_RESP);

            DBG('SUCCESS IN REFUNDING/REVERSING THE INCOMING FAST TRANSACTION');

          END IF;

          COMMIT;

        ELSE

          GLOBAL.PR_INIT(L_CUST_AC.BRANCH_CODE, 'SYSTEM');

          SAVEPOINT A;

          DBG('BENEFICIARY ACCOUNT AVAILABLE......SO LETS PROCESS INCOMING FAST TRANSACTION');

          DBG('L_TXN_CCY L_TXN_CCY=' || L_TXN_CCY);

          --GET BEN CUSTOMER DETAILS
          BEGIN
            SELECT X.*
              INTO L_CUST
              FROM STTM_CUSTOMER X
             WHERE X.CUSTOMER_NO = L_CUST_AC.CUST_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FAILED IN GETTING CUSTOMER DETAILS');
          END;

      --Get Product
      IF L_DBTRAGT_BICFI = 'PINCKHPP' THEN

            BEGIN
              SELECT PARAM_VAL
                INTO L_PRODUCT_CODE
                FROM CSTB_PARAM_CUSTOM
               WHERE PARAM_NAME = 'BAKONG_SETTL_ACC_PRINCE_WALLET';

            EXCEPTION
              WHEN OTHERS THEN
                L_PRODUCT_CODE := 'BKIP';
            END;

          ELSE

            BEGIN
              SELECT PARAM_VAL
                INTO L_PRODUCT_CODE
                FROM CSTB_PARAM_CUSTOM
               WHERE PARAM_NAME = 'BAKONG_INC_PRODUCT';

            EXCEPTION
              WHEN OTHERS THEN
                L_PRODUCT_CODE := 'BKGI';
            END;

          END IF;

          --Get product Code
          BEGIN
            SELECT X.*
              INTO L_PROD
              FROM CSTM_PRODUCT X
             WHERE PRODUCT_CODE = L_PRODUCT_CODE;
          EXCEPTION

            WHEN OTHERS THEN
              L_PROD := NULL;
        CONTINUE;
          END;

          --XRATE CALCULATION STARTS
          IF L_TXN_CCY <> L_CUST_AC.CCY THEN

            BEGIN
              SELECT DECODE(L_PROD.RATE_CODE_PREFERRED,
                            'B',
                            'S',
                            'S',
                            'B',
                            'M',
                            'M',
                            L_PROD.RATE_TYPE_PREFERRED)
                INTO L_RATE_CODE1
                FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Exception found l_rate_code-> ' || L_RATE_CODE1);
            END;
            DBG('L_RATE_CODE1=' || L_RATE_CODE1);
            DBG('l_prod.rate_type_preferred=' ||
                L_PROD.RATE_TYPE_PREFERRED);

            IF NOT CYPKSS.FN_GETRATE(L_CUST_AC.BRANCH_CODE,
                                     L_CUST_AC.CCY,
                                     L_TXN_CCY, --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                     L_PROD.RATE_TYPE_PREFERRED,
                                     L_RATE_CODE1, --l_prod.rate_code_preferred,
                                     GLOBAL.APPLICATION_DATE,
                                     GLOBAL.APPLICATION_DATE,
                                     L_EXCH_RATE,
                                     L_RATE_FLAG,
                                     P_ERR_CODE) THEN
              DBG('FAILED IN FN_GETRATE');
            END IF;
          ELSE
            L_EXCH_RATE := 1;
          END IF;

          DBG('L_EXCH_RATE=' || L_EXCH_RATE);

          --Using above rate..convert khr to usd amount
          IF NOT cypkss.FN_AMT1_TO_AMT2(L_TXN_CCY,
                                        L_CUST_AC.CCY,
                                        L_AMT,
                                        L_EXCH_RATE,
                                        'Y',
                                        L_TXN_AMT,
                                        P_ERR_PARAMS) THEN
            DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
            ROLLBACK TO A;
          END IF;

          dbg('FINAL L_TXN_AMT=' || L_TXN_AMT);
          --XRATE CALCULATION ENDS

          --GET REFERENCE NO
          IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                             L_PRODUCT_CODE,
                                             GLOBAL.APPLICATION_DATE,
                                             L_SERIAL_NO,
                                             L_TRN_REF_NO,
                                             P_ERR_CODE) THEN
            DBG('FAILED IN GENERATION TRANSACTION REF NO');
            ROLLBACK TO A;
          ELSE
            DBG('L_TRN_REF_NO=' || L_TRN_REF_NO);
          END IF;

          --GET ARC PRODUCT
          CSPKSS_ARC.PR_GET_ARC_ROW(GLOBAL.CURRENT_BRANCH,
                                    L_PRODUCT_CODE,
                                    'P',
                                    '*.*', -- TRANS_TYPE
                                    'KHR',
                                    L_IB_FLAG,
                                    L_ARC_MAINT,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS,
                                    L_CUST_AC.CUST_AC_NO,
                                    L_CUST_AC.BRANCH_CODE);

          IF P_ERR_CODE IS NOT NULL THEN
            DBG('CSPKSS_ARC.PR_GET_ARC_ROW returned false');
            ROLLBACK TO A;
          END IF;

          --BUILDING RT REC TYPE
          PKG_DETB_RTL_TELLER_REC.XREF         := L_TRN_REF_NO;
          PKG_DETB_RTL_TELLER_REC.PRODUCT_CODE := L_PRODUCT_CODE;
          PKG_DETB_RTL_TELLER_REC.BRANCH_CODE  := GLOBAL.CURRENT_BRANCH;
          PKG_DETB_RTL_TELLER_REC.TRN_REF_NO   := L_TRN_REF_NO;
          PKG_DETB_RTL_TELLER_REC.TXN_ACC      := L_CUST_AC.CUST_AC_NO;
          PKG_DETB_RTL_TELLER_REC.TXN_CCY      := L_CUST_AC.CCY;
          --PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := P_IFDOFAST.V_IFTBS_FAST_MASTER.BRANCH_CODE;
          PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := L_CUST_AC.BRANCH_CODE;


      IF L_DBTRAGT_BICFI = 'PINCKHPP' THEN
            --sampath starts for prince bank wallet changes

            BEGIN
              SELECT COD_OFFSET_ACC
                INTO PKG_DETB_RTL_TELLER_REC.OFS_ACC
                FROM IFTM_ARC_MAINT
               WHERE COD_PROD_ACC_CLS = L_PRODUCT_CODE
                 AND COD_IB_PRODUCT = 'Y'
                 AND ROWNUM = 1;
            EXCEPTION
              WHEN OTHERS THEN
                PKG_DETB_RTL_TELLER_REC.OFS_ACC := '392200001';
            END;

          ELSE
          IF L_TXN_CCY = 'USD' THEN

            BEGIN
              SELECT PARAM_VAL
                INTO PKG_DETB_RTL_TELLER_REC.OFS_ACC
                FROM CSTB_PARAM_CUSTOM
               WHERE PARAM_NAME = 'BAKONG_USD_SETTL_ACCOUNT';
            EXCEPTION
              WHEN OTHERS THEN
                PKG_DETB_RTL_TELLER_REC.OFS_ACC := '000072693';
            END;

            --PKG_DETB_RTL_TELLER_REC.OFS_ACC := '000020962'; --L_ARC_MAINT.COD_OFFSET_ACC;

          ELSE

            BEGIN
                
              SELECT PARAM_VAL
                INTO PKG_DETB_RTL_TELLER_REC.OFS_ACC
                                 
             
                FROM CSTB_PARAM_CUSTOM
               WHERE PARAM_NAME = 'BAKONG_KHR_SETTL_ACCOUNT';
            EXCEPTION
              WHEN OTHERS THEN
                PKG_DETB_RTL_TELLER_REC.OFS_ACC := '000072707';
             
                
                                 
          
            END;
           
          END IF;
      END IF;

          PKG_DETB_RTL_TELLER_REC.OFS_CCY    := L_TXN_CCY;
          PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT := L_AMT;
          PKG_DETB_RTL_TELLER_REC.TXN_AMOUNT := L_TXN_AMT;
          /*PKG_DETB_RTL_TELLER_REC.OFS_BRANCH := REPLACE(L_ARC_MAINT.COD_OFFSET_BRN,
          '*.*',
          GLOBAL.CURRENT_BRANCH);*/


      IF L_DBTRAGT_BICFI = 'PINCKHPP' THEN
            PKG_DETB_RTL_TELLER_REC.OFS_BRANCH := L_CUST_AC.BRANCH_CODE;
          ELSE
          BEGIN
            SELECT BRANCH_CODE
              INTO PKG_DETB_RTL_TELLER_REC.OFS_BRANCH
              FROM STTM_CUST_ACCOUNT
             WHERE CUST_AC_NO = PKG_DETB_RTL_TELLER_REC.OFS_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              PKG_DETB_RTL_TELLER_REC.OFS_BRANCH := '991';
          END;
      END IF;

          PKG_DETB_RTL_TELLER_REC.TXN_TRN_CODE     := L_ARC_MAINT.COD_MAIN_TXN_CODE;
          PKG_DETB_RTL_TELLER_REC.OFS_TRN_CODE     := L_ARC_MAINT.COD_OFFSET_TXN_CODE;
          PKG_DETB_RTL_TELLER_REC.EXCH_RATE        := L_EXCH_RATE;
          PKG_DETB_RTL_TELLER_REC.TRN_DT           := GLOBAL.APPLICATION_DATE;
          PKG_DETB_RTL_TELLER_REC.VALUE_DT         := GLOBAL.APPLICATION_DATE;
          PKG_DETB_RTL_TELLER_REC.REL_CUSTOMER     := L_CUST_AC.CUST_NO;
          PKG_DETB_RTL_TELLER_REC.BENEF_NAME       := L_CUST.CUSTOMER_NAME1;
          PKG_DETB_RTL_TELLER_REC.BENEF_ADDR1      := L_CUST.ADDRESS_LINE1;
          PKG_DETB_RTL_TELLER_REC.BENEF_ADDR2      := L_CUST.ADDRESS_LINE2;
          PKG_DETB_RTL_TELLER_REC.BENEF_ADDR3      := L_CUST.ADDRESS_LINE3;
          PKG_DETB_RTL_TELLER_REC.BENEF_ADDR4      := L_CUST.ADDRESS_LINE4;
          PKG_DETB_RTL_TELLER_REC.LIQN_DT          := GLOBAL.APPLICATION_DATE;
          PKG_DETB_RTL_TELLER_REC.RECORD_STAT      := 'A';
          PKG_DETB_RTL_TELLER_REC.AUTH_STAT        := 'U';
          PKG_DETB_RTL_TELLER_REC.MAKER_ID         := GLOBAL.USER_ID;
          PKG_DETB_RTL_TELLER_REC.MAKER_DT_STAMP   := FN_SYSDATE;
          PKG_DETB_RTL_TELLER_REC.CHECKER_ID       := GLOBAL.USER_ID;
          PKG_DETB_RTL_TELLER_REC.CHECKER_DT_STAMP := FN_SYSDATE;
          PKG_DETB_RTL_TELLER_REC.MOD_NO           := 1;
          PKG_DETB_RTL_TELLER_REC.SCODE            := 'FLEXCUBE';
          PKG_DETB_RTL_TELLER_REC.DR_ACC           := L_ARC_MAINT.DR_ACC;
          PKG_DETB_RTL_TELLER_REC.MODULE           := 'RT';
          PKG_DETB_RTL_TELLER_REC.ESN              := 1;
          PKG_DETB_RTL_TELLER_REC.EVENT_CODE       := 'INIT';
          PKG_DETB_RTL_TELLER_REC.TRACK_RECEIVABLE := 'N';
          PKG_DETB_RTL_TELLER_REC.TIME_RECEIVED    := SYSDATE;

          --SAVE TRANSACTION
          DBG('CALLING DEPKS_RTL_TELLER.FN_SAVE');
          IF NOT DEPKS_RTL_TELLER.FN_SAVE(PKG_DETB_RTL_TELLER_REC,
                                          P_ERR_CODE,
                                          P_ERR_PARAMS) THEN
            DBG('Failed in Fn_Save');
            DBG('P_ERR_CODE=' || P_ERR_CODE);
            DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);
            ROLLBACK TO A;
            PR_UPDATE_DOC_TRACKER(L_MSG_ID, 'E', P_ERR_CODE, P_ERR_PARAMS);
            COMMIT;
          ELSE

            DBG('Success in Fn_Save');
            DBG('P_ERR_CODE=' || P_ERR_CODE);
            DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);
            --AUTH TRANSACTION
            DBG('CALLING DEPKS_RTL_TELLER.FN_RTL_TELLER_AUTH');
            IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(L_CUST_AC.BRANCH_CODE,
                                                        L_TRN_REF_NO,
                                                        GLOBAL.USER_ID,
                                                        GLOBAL.LCY,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
              DBG('AUTH RETRUNED FALSE' || P_ERR_CODE);
              DBG('FAILED TO PROCESS TRANSACTION');

              ROLLBACK TO A;
              PR_UPDATE_DOC_TRACKER(L_MSG_ID,
                                    'E',
                                    P_ERR_CODE,
                                    P_ERR_PARAMS);
              COMMIT;
              --PR_TRN_STATUS_UPDATE(R.MSGID, L_SEQ, 'F', '03');

            ELSE
              --Inserting Incoming Fast Transaction into a master table
              PR_INSERT_BAKONG_INCOMING('FLEXCUBE',
                                        GLOBAL.CURRENT_BRANCH,
                                        'I',
                                        L_TRN_REF_NO,
                                        PKG_DETB_RTL_TELLER_REC.PRODUCT_CODE,
                                        PKG_DETB_RTL_TELLER_REC.TRN_DT,
                                        PKG_DETB_RTL_TELLER_REC.OFS_CCY,
                                        PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT,
                                        L_TXN_AMT, --PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT, --CHECK THIS
                                        PKG_DETB_RTL_TELLER_REC.EXCH_RATE,
                                        NULL, --TXN STATUS
                                        NULL, --REMARKS
                                        L_MSG_ID, --MSG_ID
                                        PKG_DETB_RTL_TELLER_REC.OFS_ACC,
                                        PKG_DETB_RTL_TELLER_REC.TXN_ACC,
                                        L_CRTRAGT_BICFI,
                                        PKG_DETB_RTL_TELLER_REC.BENEF_NAME,
                                        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR1,
                                        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR2,
                                        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR3,
                                        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR4,
                                        '123456789012-000000009008/AAAA0056', --END TO END ID
                                        PKG_DETB_RTL_TELLER_REC.MAKER_ID,
                                        PKG_DETB_RTL_TELLER_REC.MAKER_DT_STAMP,
                                        PKG_DETB_RTL_TELLER_REC.CHECKER_ID,
                                        PKG_DETB_RTL_TELLER_REC.CHECKER_DT_STAMP,
                                        'A',
                                        'O',
                                        'Y',
                                        1);

              --Get Ack Message
              L_FORMATTED_MSG := FN_RETURN_ACK_MSG;

              DBG('BEFORE REPLACEMENT OF ACK XML=' || L_FORMATTED_MSG);

              L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                         '$L_MSG_ID',
                                         L_MSG_ID);

              L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                         '$L_CREDTTM',
                                         L_CREDTTM);

              L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                         '$L_INITGPTY_NM',
                                         L_INITGPTY_NM);

              L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                         '$L_CRTRAGT_BICFI',
                                         L_CRTRAGT_BICFI);

              L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                         '$L_DBTRAGT_BICFI',
                                         L_DBTRAGT_BICFI);

              L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                         '$L_PMTINFID',
                                         L_PMTINFID);

              L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                         '$L_ENDTOENDID',
                                         '123456789012-000000009008/AAAA0056');

              L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMT', L_AMT);

              L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                         '$L_DBTR_NM',
                                         L_DBTR_NM);

              L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                         '$L_CDTR_NM',
                                         L_CDTR_NM);

       L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                         '$L_INSTD_CCY',
                                         L_TXN_CCY);-- L_CDTR_NM); --CIFTP sampath changes
                                   
       
      
              DBG('AFTER REPLACEMENT OF ACK XML=' || L_FORMATTED_MSG);

              --Log Ack Request to NBC
              DBG('LOGGING ACK REQUEST TO NBC');
              PR_INSERT_BAKONG_WS_LOG(L_MSG_ID,
                                      L_GEN_SEQ_NO,
                                      L_TRN_REF_NO,
                                      SYSDATE,
                                      'Ack',
                                      L_FORMATTED_MSG,
                                      'I',
                                      NULL,
                                      'Ack for Incoming');

              --IF NOT FN_BAKONG_HTTP_CALL(L_FORMATTED_MSG, L_IN_RESP) THEN --CIFTP changes
        IF NOT  
                  FN_BAKONG_HTTP_CALL(L_FORMATTED_MSG, L_IN_RESP, 'MAKEACK') THEN 
                                     
                DBG('FAILED IN ACKNOWLEDGING THE ORIGINAL INCOMING TXN');
                ROLLBACK TO A;
                PR_UPDATE_DOC_TRACKER(L_MSG_ID,
                                      'E',
                                      P_ERR_CODE,
                                      P_ERR_PARAMS);
                COMMIT;
              ELSE
                DBG('SUCCESS CALL FROM MAKING ACK REQUEST');
                --Log Ack Resonse
                L_IN_RESP := REPLACE(L_IN_RESP, '&lt;', '<');
                L_IN_RESP := REPLACE(L_IN_RESP, '&gt;', '>');

                --Get Cosmetic XML
                PR_RETURN_COSMETIC_XML(L_IN_RESP, L_COSMETIC_RES_MSG);

                DBG('L_COSMETIC_RES_MSG OF ACK RESPONSE=' ||
                    L_COSMETIC_RES_MSG);

                --Convert into XMLTYPE
                P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);

                --Get Node Value
                L_TXN_STATUS := P_DOCUMENT_XML.EXTRACT('/Document/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/TxSts/text()')
                                .getstringval;

                DBG('L_TXN_STATUS=' || L_TXN_STATUS);

                IF L_TXN_STATUS = 'RJCT' THEN

                  ROLLBACK TO A;

                  DBG('LOGGING ACK RESPONSE FROM NBC');
                  PR_UPDATE_BAKONG_WS_LOG(L_MSG_ID,
                                          L_GEN_SEQ_NO,
                                          L_TXN_STATUS,
                                          L_IN_RESP);

                  --Update status to processed for current row
                  PR_UPDATE_DOC_TRACKER(L_MSG_ID,
                                        'E',
                                        P_ERROR_CODE,
                                        P_ERROR_MSG);

                  COMMIT;
                ELSE

                  DBG('LOGGING ACK RESPONSE FROM NBC');

                  PR_UPDATE_BAKONG_WS_LOG(L_MSG_ID,
                                          L_TXN_STATUS,
                                          L_IN_RESP,
                                          L_TRN_REF_NO);

                  PR_UPDATE_STAT_BAKONG_INCOMING(L_TRN_REF_NO,
                                                 L_TXN_STATUS);

                  DBG('SUCCESS IN ACKNOWLEDGING THE BAKONG INCOMING TRANSACTION');

                  --Update status to processed for current row
                  PR_UPDATE_DOC_TRACKER(L_MSG_ID, 'P', NULL, NULL);

                  COMMIT;
                END IF;
              END IF;

            END IF; --Fn_Auth End If

          END IF; --Fn_Save End If

        END IF; --Frozen Dormant End If

        DBG('END OF PR_PROCESS_BAKONG_INCOMING_TXN');
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN PROCESSING CURRENT INCOMING MESSAGE ID=' ||
              L_MSG_ID);

    ROLLBACK TO A;

      PR_UPDATE_DOC_TRACKER(L_MSG_ID, 'R', P_ERROR_CODE, P_ERROR_MSG);

            PR_UPDATE_BAKONG_WS_SEQ_LOG(L_MSG_ID,
                                        L_GEN_SEQ_NO,
                                        L_TXN_STATUS,
                                        L_IN_RESP);
    COMMIT;
      CONTINUE;
      END;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_BAKONG_INCOMING_TXN');
      DBG('ERROR CODE IN PR_PROCESS_BAKONG_INCOMING_TXN=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_BAKONG_INCOMING_TXN=' || SQLERRM);
      -- RETURN FALSE;

  END PR_PROCESS_BAKONG_INCOMING_TXN;

  --Simple Job to process incoming bakong transactions
  PROCEDURE PR_PROCESS_BAKONG_INCOMING(PARAMNAME  VARCHAR2,
                                       PARAMVALUE VARCHAR2) AS

  BEGIN

    DEBUG.PR_DEBUG('IF', 'Inside PR_PROCESS_BAKONG_INCOMING');

    DEBUG.PR_DEBUG('IF', 'paramName = ' || PARAMNAME);
    DEBUG.PR_DEBUG('IF', 'paramValue = ' || PARAMVALUE);

    PR_PROCESS_BAKONG_INCOMING_TXN;

    DEBUG.PR_DEBUG('IF',
                   'Successful return from PR_PROCESS_BAKONG_INCOMING');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'Exception during PR_PROCESS_BAKONG_INCOMING' ||
                     SQLERRM);
  END PR_PROCESS_BAKONG_INCOMING;

  PROCEDURE PR_BAKONG_INCOMING_HANDOFF(P_PARAM_NAME IN VARCHAR2,
                                       PARAMVALUE   VARCHAR2) IS

    L_RESPONSE              VARCHAR2(32767);
    L_SNIPPET               XMLTYPE;
    L_IX                    BINARY_INTEGER;
    L_TEXT                  CLOB;
    L_START                 NUMBER := 1;
    L_END                   NUMBER := 0;
    L_NO_OF_DOCUMENTS       NUMBER := 0;
    L_DOCUMENT              CLOB;
    L_INCOMING_REQUEST_MSG  CLOB;
    L_INCOMING_RESPONSE_MSG CLOB;
    E_UPDATE_ERROR EXCEPTION;
    P_ERR_CODE   VARCHAR2(1000);
    P_ERR_PARAMS VARCHAR2(1000);

  BEGIN

    --Call getIncomingAPI Webservice
    --GLOBAL.PR_INIT('000', 'SYSTEM');

    --Get Incoming message
    L_INCOMING_REQUEST_MSG := FN_RETURN_INCOMING_MSG;

    DBG('L_INCOMING_REQUEST_MSG=' || L_INCOMING_REQUEST_MSG);

    --IF NOT
        --FN_BAKONG_HTTP_CALL(L_INCOMING_REQUEST_MSG, L_INCOMING_RESPONSE_MSG) THEN --CIFTP changes
           IF NOT FN_BAKONG_HTTP_CALL(L_INCOMING_REQUEST_MSG,
                               L_INCOMING_RESPONSE_MSG,
                               'GETINC') THEN                      
                       
                      
      DBG('FAILED TO SEND PAIN_001_001_05');
      --RAISE E_UPDATE_ERROR;
    ELSE
      DBG('SUCCESS...WE GOT RESPONSE FROM BAKOG GETINCOMING API');
    END IF;
                                     
    --DBG('L_INCOMING_RESPONSE_MSG='||length(L_INCOMING_RESPONSE_MSG));

    L_INCOMING_RESPONSE_MSG := REPLACE(L_INCOMING_RESPONSE_MSG, '&lt;', '<');
    L_INCOMING_RESPONSE_MSG := REPLACE(L_INCOMING_RESPONSE_MSG, '&gt;', '>');

    L_NO_OF_DOCUMENTS := (LENGTH(L_INCOMING_RESPONSE_MSG) -
                         LENGTH(REPLACE(L_INCOMING_RESPONSE_MSG,
                                         '</Document>',
                                         ''))) / length('</Document>');
    DBG('L_NO_OF_DOCUMENTS=' || L_NO_OF_DOCUMENTS);

    FOR G IN 1 .. L_NO_OF_DOCUMENTS LOOP
      L_START := INSTR(L_INCOMING_RESPONSE_MSG, '<Document ', l_start, G);
      L_END   := INSTR(L_INCOMING_RESPONSE_MSG, '</Document>', l_start, 1);

      L_DOCUMENT := SUBSTR(L_INCOMING_RESPONSE_MSG,
                           L_START,
                           L_END - L_START + LENGTH('</Document>'));

      L_START := 1;

      DBG('L_DOCUMENT=' || L_DOCUMENT);

      PR_INSERT_DOC_TRACKER(L_DOCUMENT);

      DBG('-------------------');
    END LOOP;

    -- RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      -- RETURN FALSE;
  END PR_BAKONG_INCOMING_HANDOFF;
  /*
  PROCEDURE PR_BAKONG_OUTGOING_HANDOFF(P_PARAM_NAME IN VARCHAR2,
                                       PARAMVALUE   VARCHAR2) IS

    L_RESPONSE              VARCHAR2(32767);
    L_SNIPPET               XMLTYPE;
    L_IX                    BINARY_INTEGER;
    L_TEXT                  CLOB;
    L_START                 NUMBER := 1;
    L_END                   NUMBER := 0;
    L_NO_OF_DOCUMENTS       NUMBER := 0;
    L_DOCUMENT              CLOB;
    L_OUTGOING_REQUEST_MSG  CLOB;
    L_OUTGOING_RESPONSE_MSG CLOB;
    E_UPDATE_ERROR EXCEPTION;
    P_ERR_CODE   VARCHAR2(1000);
    P_ERR_PARAMS VARCHAR2(1000);

  BEGIN

    --Call getIncomingAPI Webservice
    --GLOBAL.PR_INIT('000', 'SYSTEM');

    --Get Incoming message
    L_OUTGOING_REQUEST_MSG := FN_RETURN_OUTGOING_MSG;

    DBG('L_OUTGOING_REQUEST_MSG=' || L_OUTGOING_REQUEST_MSG);

    IF NOT
        FN_BAKONG_HTTP_CALL(L_OUTGOING_REQUEST_MSG, L_OUTGOING_RESPONSE_MSG) THEN
      DBG('FAILED TO SEND PAIN_001_001_05');
      --RAISE E_UPDATE_ERROR;
    ELSE
      DBG('SUCCESS...WE GOT RESPONSE FROM FAST GETOUTGOING API');
    END IF;

    L_OUTGOING_RESPONSE_MSG := REPLACE(L_OUTGOING_RESPONSE_MSG, '&lt;', '<');
    L_OUTGOING_RESPONSE_MSG := REPLACE(L_OUTGOING_RESPONSE_MSG, '&gt;', '>');

    L_NO_OF_DOCUMENTS := (LENGTH(L_OUTGOING_RESPONSE_MSG) -
                         LENGTH(REPLACE(L_OUTGOING_RESPONSE_MSG,
                                         '</Document>',
                                         ''))) / length('</Document>');
    DBG('L_NO_OF_DOCUMENTS=' || L_NO_OF_DOCUMENTS);

    FOR G IN 1 .. L_NO_OF_DOCUMENTS LOOP
      L_START := INSTR(L_OUTGOING_RESPONSE_MSG, '<Document ', l_start, G);
      L_END   := INSTR(L_OUTGOING_RESPONSE_MSG, '</Document>', l_start, 1);

      L_DOCUMENT := SUBSTR(L_OUTGOING_RESPONSE_MSG,
                           L_START,
                           L_END - L_START + LENGTH('</Document>'));

      L_START := 1;

      DBG('L_DOCUMENT=' || L_DOCUMENT);

      --INSERT THE DOCUMENT
      PR_INSERT_DOC_OUTGNG_TRACKER(L_DOCUMENT);

      DBG('-------------------');
    END LOOP;

    -- RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      -- RETURN FALSE;
  END PR_BAKONG_OUTGOING_HANDOFF;

  --Simple Job to process outgoing Bakong transactions
  PROCEDURE PR_PROCESS_BAKONG_OUTGOING(PARAMNAME  VARCHAR2,
                                       PARAMVALUE VARCHAR2) AS

  BEGIN

    DEBUG.PR_DEBUG('IF', 'Inside PR_PROCESS_BAKONG_OUTGOING');

    DEBUG.PR_DEBUG('IF', 'paramName = ' || PARAMNAME);
    DEBUG.PR_DEBUG('IF', 'paramValue = ' || PARAMVALUE);

    --PR_PROCESS_BAKONG_OUTGOING_TXN;

    DEBUG.PR_DEBUG('IF',
                   'Successful return from PR_PROCESS_BAKONG_OUTGOING_TXN');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'Exception during PR_PROCESS_BAKONG_OUTGOING_TXN' ||
                     SQLERRM);
  END PR_PROCESS_BAKONG_OUTGOING;*/

END IFPKS_BAKONG_UTILITIES;
