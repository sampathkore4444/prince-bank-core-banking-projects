CREATE OR REPLACE PACKAGE IFPKS_BAKONG_UTILITIES IS

  FUNCTION FN_RETURN_REFUND_MSG RETURN CLOB;
  FUNCTION FN_RETURN_ACK_MSG RETURN CLOB;
  FUNCTION FN_RETURN_DOCUMENT(P_CLOB IN CLOB) RETURN CLOB;
  FUNCTION FN_RETURN_INCOMING_MSG RETURN CLOB;

/*PROCEDURE PR_INSERT_BAKONG_WS_LOG(P_MSG_ID            IN VARCHAR2,
                                    P_TRN_REF_NO        IN VARCHAR2,
                                    P_DATE              IN DATE,
                                    P_REQ_TYPE          IN VARCHAR2,
                                    P_REQ_MSG           IN CLOB,
                                    P_PAY_TYPE          IN CHAR,
                                    P_ACK_REFUND_REASON IN VARCHAR2,
                                    P_ADDL_INFO         IN VARCHAR2);*/

  PROCEDURE PR_INSERT_BAKONG_WS_LOG(P_MSG_ID            IN VARCHAR2,
									P_SEQ_NO            IN VARCHAR2,
                                    P_TRN_REF_NO        IN VARCHAR2,
                                    P_DATE              IN DATE,
                                    P_REQ_TYPE          IN VARCHAR2,
                                    P_REQ_MSG           IN CLOB,
                                    P_PAY_TYPE          IN CHAR,
                                    P_ACK_REFUND_REASON IN VARCHAR2,
                                    P_ADDL_INFO         IN VARCHAR2);

  PROCEDURE PR_INSERT_DOC_TRACKER(P_DOCUMENT IN CLOB);

  --PROCEDURE PR_UPDATE_DOC_TRACKER(P_MSG_ID IN IFTB_FAST_MASTER.MSG_ID%TYPE);

  PROCEDURE PR_INSERT_BAKONG_INCOMING(P_SOURCE_CODE   VARCHAR2,
                                      P_BRANCH_CODE   VARCHAR2,
                                      P_MSG_FLOW      VARCHAR2,
                                      P_TRN_REF_NO    VARCHAR2,
                                      P_PRODUCT_CODE  VARCHAR2,
                                      P_TRANSFER_DATE DATE,
                                      P_TXN_CCY       VARCHAR2,
                                      P_TXN_AMT       NUMBER,
                                      P_NET_TXN_AMT   NUMBER,
                                      P_EXCH_RATE     NUMBER,
                                      P_TXN_STATUS    VARCHAR2,
                                      P_TXN_REMARKS   VARCHAR2,
                                      P_MSG_ID        VARCHAR2,
                                      P_REM_ACC       VARCHAR2,

                                      P_BEN_ACC          VARCHAR2,
                                      P_BEN_BIC          VARCHAR2,
                                      P_BEN_NAME         VARCHAR2,
                                      P_BEN_ADD1         VARCHAR2,
                                      P_BEN_ADD2         VARCHAR2,
                                      P_BEN_ADD3         VARCHAR2,
                                      P_BEN_ADD4         VARCHAR2,
                                      P_ETEND_ID         VARCHAR2,
                                      P_MAKER_ID         VARCHAR2,
                                      P_MAKER_DT_STAMP   DATE,
                                      P_CHECKER_ID       VARCHAR2,
                                      P_CHECKER_DT_STAMP DATE,
                                      P_AUTH_STAT        VARCHAR2,
                                      P_RECORD_STAT      VARCHAR2,
                                      P_ONCE_AUTH        VARCHAR2,
                                      P_MOD_NO           NUMBER);

  /*PROCEDURE PR_UPDATE_BAKONG_WS_LOG(P_MSG_ID  IN VARCHAR2,
                                    P_STATUS  IN CHAR,
                                    P_RES_MSG IN CLOB);*/

  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2);

  PROCEDURE PR_BAKONG_INCOMING_HANDOFF(P_PARAM_NAME IN VARCHAR2,
                                       PARAMVALUE   VARCHAR2);

  PROCEDURE PR_PROCESS_BAKONG_INCOMING(PARAMNAME  VARCHAR2,
                                       PARAMVALUE VARCHAR2);

  PROCEDURE PR_PROCESS_BAKONG_INCOMING_TXN;

END IFPKS_BAKONG_UTILITIES;

