insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_OUT_BAKONG_CIFTP_PWD', 'P@$$w0rd', 'N');

insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_OUT_BAKONG_CIFTP_UID', 'princebank', 'N');

COMMIT;
