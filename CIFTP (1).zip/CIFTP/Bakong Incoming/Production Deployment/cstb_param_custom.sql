insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_OUT_BAKONG_CIFTP_PWD', 'TFZF(XKdt#xx_!XC', 'N');

insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_OUT_BAKONG_CIFTP_UID', 'princebank', 'N');

--insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
--values ('PGW_OUT_BAKONG_CIFTP_URL', 'http://10.80.81.49:8765/ciftp-payment-service/cb-adapter/BakongWebService/NBCInterface.wsdl', 'Y');

--Dormain name
insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_OUT_BAKONG_CIFTP_URL', 'http://ciftp.princeplc.com.kh:8765/ciftp-payment-service/cb-adapter/BakongWebService/NBCInterface.wsdl', 'Y');

--IP
insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_OUT_BAKONG_CIFTP_URL', 'http://192.168.20.120:8765/ciftp-payment-service/cb-adapter/BakongWebService/NBCInterface.wsdl', 'Y');



COMMIT;
