begin

dbms_network_acl_admin.create_acl (

acl => 'http_permissions_ciftp.xml', -- or any other name

description => 'HTTP Access',

principal => 'P1FCHPRFM', -- the user name trying to access the network resource

is_grant => TRUE,

privilege => 'connect',

start_date => null,

end_date => null

);

end;

/


commit;

begin

DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE(acl => 'http_permissions_ciftp.xml',

principal => 'P1FCHPRFM',

is_grant => true,

privilege => 'connect');

end;

/


commit;

begin

DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE(acl => 'http_permissions_ciftp.xml',

principal => 'P1FCHPRFM',

is_grant => true,

privilege => 'resolve');

end;

/

commit;

BEGIN

dbms_network_acl_admin.assign_acl (

acl => 'http_permissions_ciftp.xml',

host => 'ciftp.princeplc.com.kh', /*can be computer name or IP , wildcards are accepted as well for example - '*.us.oracle.com'*/

lower_port => null,

upper_port => null

);

END;
/