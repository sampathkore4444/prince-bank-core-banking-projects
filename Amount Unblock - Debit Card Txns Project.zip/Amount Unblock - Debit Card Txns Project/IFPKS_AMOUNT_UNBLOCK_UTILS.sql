CREATE OR REPLACE PACKAGE BODY IFPKS_AMOUNT_UNBLOCK_UTILS AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_AMOUNT_UNBLOCK_UTILS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;

  PROCEDURE PR_INSERT_OPER_ID_INVOKE_LOG(P_ORDER_ID          IN VARCHAR2,
                                         P_REF_NO            IN VARCHAR2,
                                         P_INVOKE_START_DATE IN DATE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_OPER_ID_INVOKE_LOG');
  
    INSERT INTO IFTB_AUTO_DEBIT_ORDER_ID_LOG
      (ORDER_ID, TRN_REF_NO, INVOKE_DATE_START)
    VALUES
      (P_ORDER_ID, P_REF_NO, P_INVOKE_START_DATE);
  
    COMMIT;
    DBG('END OF PR_INSERT_OPER_ID_INVOKE_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_OPER_ID_INVOKE_LOG');
      DBG('ERROR CODE IN PR_INSERT_OPER_ID_INVOKE_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_OPER_ID_INVOKE_LOG=' || SQLERRM);
    
  END PR_INSERT_OPER_ID_INVOKE_LOG;

  PROCEDURE PR_UPDATE_OPER_ID_INVOKE_LOG(P_ORDER_ID        IN VARCHAR2,
                                         P_REF_NO          IN VARCHAR2,
                                         P_STATUS          IN CHAR,
                                         P_ERR_CODE        IN VARCHAR2,
                                         P_ERR_PARAM       IN VARCHAR2,
                                         P_INVOKE_DATE_END IN DATE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_OPER_ID_INVOKE_LOG');
  
    UPDATE IFTB_AUTO_DEBIT_ORDER_ID_LOG
       SET STATUS          = P_STATUS,
           ERROR_CODE      = P_ERR_CODE,
           ERROR_PARAM     = P_ERR_PARAM,
           INVOKE_DATE_END = P_INVOKE_DATE_END
     WHERE ORDER_ID = P_ORDER_ID
       AND TRN_REF_NO = P_REF_NO;
    COMMIT;
    DBG('END OF PR_UPDATE_OPER_ID_INVOKE_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_OPER_ID_INVOKE_LOG');
      DBG('ERROR CODE IN PR_UPDATE_OPER_ID_INVOKE_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_OPER_ID_INVOKE_LOG=' || SQLERRM);
  END PR_UPDATE_OPER_ID_INVOKE_LOG;

  PROCEDURE PR_UPDATE_AMTUNBLOCK_TRACKER(P_ORDER_ID IN VARCHAR2,
                                         P_STATUS   IN CHAR) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_AMTUNBLOCK_TRACKER');
  
    UPDATE IFTB_AUTO_DEBIT_INCOMING_TRACK
       SET STATUS = P_STATUS
     WHERE ORDER_ID = P_ORDER_ID;
  
    UPDATE IFTB_AUTODEBIT_INC_TRACK
       SET STATUS = P_STATUS
     WHERE ORDER_ID = P_ORDER_ID;
    COMMIT;
    DBG('END OF PR_UPDATE_AMTUNBLOCK_TRACKER');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_AMTUNBLOCK_TRACKER');
      DBG('ERROR CODE IN PR_UPDATE_AMTUNBLOCK_TRACKER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_AMTUNBLOCK_TRACKER=' || SQLERRM);
  END PR_UPDATE_AMTUNBLOCK_TRACKER;

  FUNCTION FN_GET_AMTUNBLOCK_RES_CLOB RETURN CLOB IS
    L_CLOB CLOB;
  BEGIN
  
    L_CLOB := '<payment_order>
  <order_id>$L_ORDER_ID</order_id>
  <resp_code>$L_RESP_CODE</resp_code>
  <amount>
    <amount_value>$L_AMOUNT</amount_value>
    <currency>$L_ISO_CCY</currency>
  </amount>
  <currency>$L_ISO_CCY</currency>
  <resp_amount>
    <amount_value>$L_AMOUNT</amount_value>
    <currency>$L_ISO_CCY</currency>
  </resp_amount>
</payment_order>';
  
    RETURN L_CLOB;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN RETURNING FN_GET_AMTUNBLOCK_RES_CLOB');
      DBG('ERROR CODE IN FN_GET_AMTUNBLOCK_RES_CLOB=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AMTUNBLOCK_RES_CLOB=' || SQLERRM);
  END FN_GET_AMTUNBLOCK_RES_CLOB;

  FUNCTION FN_GET_ISO_CURRENCY_CODE(P_ISO_CCY IN VARCHAR2)
    RETURN CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE AS
    L_CCY_CODE CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE;
  BEGIN
    BEGIN
      SELECT CCY_CODE
        INTO L_CCY_CODE
        FROM CYTMS_CCY_DEFN_MASTER
       WHERE ISO_NUM_CCY_CODE = P_ISO_CCY
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      RETURN L_CCY_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN L_CCY_CODE;
    END;
    RETURN L_CCY_CODE;
  END FN_GET_ISO_CURRENCY_CODE;

  FUNCTION FN_GET_PARAMS RETURN CSTB_PARAM_CUSTOM%ROWTYPE RESULT_CACHE RELIES_ON(CSTB_PARAM_CUSTOM) IS
  BEGIN
    DBG('Inside FN_GET_PARAMS');
    SELECT *
      INTO g_cstb_params
      FROM CSTB_PARAM_CUSTOM
     WHERE PARAM_NAME = 'AUTO_DEBIT_PAYMENT_DTLS';
    DBG('Returing from FN_GET_PARAMS');
    RETURN g_cstb_params;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in FN_GET_PARAMS' || SQLERRM);
      DBG('Error ' || dbms_utility.format_error_backtrace);
      g_cstb_params := NULL;
      RETURN g_cstb_params;
  END;

  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_COSMETIC_XML := P_XML;
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<?xml version="1.0" encoding="UTF-8"?>',
                              NULL);
  
  END PR_RETURN_COSMETIC_XML;

  PROCEDURE PR_WRITE_CLOB_TO_FILE(P_IN_DIR_NAME  IN VARCHAR2,
                                  P_IN_FILE_NAME IN VARCHAR2,
                                  P_IN_CLOB      IN CLOB) IS
    L_FILE   UTL_FILE.FILE_TYPE;
    L_AMT    NUMBER := 32000;
    L_OFFSET NUMBER := 1;
    L_LENGTH NUMBER := NVL(DBMS_LOB.GETLENGTH(P_IN_CLOB), 0);
    L_BUFF   VARCHAR2(32760);
  BEGIN
    --OPEN FILE
    L_FILE := UTL_FILE.FOPEN(P_IN_DIR_NAME, P_IN_FILE_NAME, 'w', 32760);
  
    --READ CLOB AND UPLOAD INTO FILE
    WHILE (L_OFFSET < L_LENGTH) LOOP
      DBMS_LOB.READ(P_IN_CLOB, L_AMT, L_OFFSET, L_BUFF);
    
      UTL_FILE.PUT(L_FILE, L_BUFF);
      UTL_FILE.FFLUSH(L_FILE);
      UTL_FILE.NEW_LINE(L_FILE);
    
      L_OFFSET := L_OFFSET + L_AMT;
    END LOOP;
  
    --CLOSE FILE
    UTL_FILE.FCLOSE(L_FILE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_WRITE_CLOB_TO_FILE');
      DBG('ERROR CODE IN PR_WRITE_CLOB_TO_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_WRITE_CLOB_TO_FILE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN PR_WRITE_CLOB_TO_FILE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END PR_WRITE_CLOB_TO_FILE;

  PROCEDURE PR_GEN_AMTUNBLOCK_RESPONSE IS
    L_RESP_CLOB                CLOB;
    L_RESP_TEMPLATE            CLOB;
    L_FILE_NAME                VARCHAR2(32767);
    L_RESP_CODE                VARCHAR2(10);
    L_IFTB_AUTODEBIT_INC_TRACK IFTB_AUTODEBIT_INC_TRACK%ROWTYPE;
  BEGIN
  
    DBG('START OF PR_GEN_AMTUNBLOCK_RESPONSE');
  
    FOR G IN (SELECT * FROM IFTB_AUTODEBIT_INC_TRACK) LOOP
    
      L_RESP_TEMPLATE := FN_GET_AMTUNBLOCK_RES_CLOB;
    
      L_FILE_NAME := G.FILE_NAME;
    
      L_RESP_CODE := CASE G.STATUS
                       WHEN 'P' THEN
                        'PORC0001'
                       WHEN 'E' THEN
                        'PORC0002'
                       ELSE
                        'PORC0003'
                     END;
    
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE, '$L_ORDER_ID', G.ORDER_ID);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_RESP_CODE',
                                 L_RESP_CODE);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_AMOUNT',
                                 G.TXN_AMOUNT * 100);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_ISO_CCY',
                                 G.ISO_CCY_CODE);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_ISO_CCY',
                                 G.ISO_CCY_CODE);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_AMOUNT',
                                 G.TXN_AMOUNT * 100);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_ISO_CCY',
                                 G.ISO_CCY_CODE);
    
      L_RESP_CLOB := L_RESP_CLOB || L_RESP_TEMPLATE;
    
      L_RESP_TEMPLATE := NULL;
    
    END LOOP;
  
    BEGIN
      SELECT *
        INTO L_IFTB_AUTODEBIT_INC_TRACK
        FROM IFTB_AUTODEBIT_INC_TRACK
       WHERE ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        L_IFTB_AUTODEBIT_INC_TRACK := NULL;
    END;
  
    L_RESP_CLOB := '<?xml version="1.0" encoding="utf-8"?>
<payment_orders xmlns="http://bpc.ru/sv/SVXP/payment_order"><inst_id>9999</inst_id>
  <file_date>' ||
                   TO_CHAR(GLOBAL.APPLICATION_DATE, 'YYYY-MM-DD') ||
                   '</file_date>
  <file_number>' || L_IFTB_AUTODEBIT_INC_TRACK.FILE_NO ||
                   '</file_number>' || L_RESP_CLOB || '</payment_orders>';
  
    --DBG('DONE WITH GENERATING CLOB RESPONSE=' || L_RESP_CLOB);
  
    --Write to output file
    DBG('START OF WRITING CLOB TO AN XML FILE');
    PR_WRITE_CLOB_TO_FILE('CC_PAY_AUTO_DEBIT_COMP',
                          L_FILE_NAME || '_RESPONSE' || '.XML',
                          L_RESP_CLOB);
  
    DBG('END OF WRITING CLOB TO AN XML FILE');
  
    DBG('DELETING FROM TEMP TABLE:IFTB_AUTODEBIT_INC_TRACK');
    DELETE FROM IFTB_AUTODEBIT_INC_TRACK;
    COMMIT;
  
    DBG('END OF PR_GEN_AMTUNBLOCK_RESPONSE');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_GEN_AMTUNBLOCK_RESPONSE');
      DBG('ERROR CODE IN PR_GEN_AMTUNBLOCK_RESPONSE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_GEN_AMTUNBLOCK_RESPONSE=' || SQLERRM);
  END PR_GEN_AMTUNBLOCK_RESPONSE;

  PROCEDURE PR_PROCESS_AMT_UNBLOCK_OPER_ID IS
    --Accounting Entry Table Building
    l_init_acc_hoff   actbs_handoff%ROWTYPE;
    l_acc_hoff        acpkss.tbl_achoff;
    l_hoff_count      INTEGER := 0;
    L_error_code      VARCHAR2(200);
    L_error_parameter VARCHAR2(200);
    l_contract_ref_no cstbs_contract.contract_ref_no%TYPE;
    l_event_sr_no     cstbs_contract_event_log.event_seq_no%TYPE := '1';
    --l_ac_no           sttm_cust_account.cust_ac_no%TYPE := '000002756';
    l_ac_no sttm_cust_account.cust_ac_no%TYPE;
    --l_ac_ccy          sttm_cust_account.ccy%TYPE := 'USD';
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_fcy_amount   actbs_daily_log.fcy_amount%TYPE := '';
    l_counterparty sttm_cust_account.cust_no%TYPE := '';
    l_mishead      actbs_daily_log.mis_head%TYPE := '';
    l_amount_tag   actbs_daily_log.amount_tag%TYPE := 'TXN_AMT';
    l_event        actbs_daily_log.event%TYPE := 'INIT';
    l_drcrind      VARCHAR2(1) := 'D';
    l_trn_code     sttms_trn_code.trn_code%TYPE := 'CCI'; --check with team
  
    L_ORDER_ID   IFTB_AUTO_DEBIT_INCOMING_TRACK.ORDER_ID%TYPE;
    L_CUST_NO    IFTB_AUTO_DEBIT_INCOMING_TRACK.CUST_NO%TYPE;
    L_AMOUNT     IFTB_AUTO_DEBIT_INCOMING_TRACK.TXN_AMOUNT%TYPE;
    L_CURRENCY   IFTB_AUTO_DEBIT_INCOMING_TRACK.ISO_CCY_CODE%TYPE;
    L_ORDER_DATE IFTB_AUTO_DEBIT_INCOMING_TRACK.ORDER_DATE%TYPE;
    L_PURPOSE_ID IFTB_AUTO_DEBIT_INCOMING_TRACK.PURPOSE_ID %TYPE;
  
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
  
    L_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;
    L_EXCH_RATE    ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE_FLAG    NUMBER;
    L_TXN_AMT      IFTB_AUTO_DEBIT_INCOMING_TRACK.TXN_AMOUNT%TYPE;
    L_CCY_CODE     CYTM_CCY_DEFN_MASTER.CCY_CODE%TYPE;
    L_SERIAL_NO    VARCHAR2(16);
    L_TRN_REF_NO   Actb_Daily_Log.TRN_REF_NO%TYPE;
  
    CURSOR C1 IS
      SELECT * FROM IFTB_AUTO_DEBIT_INCOMING_TRACK WHERE STATUS IN ('U');
  
    pkg_detb_rtl_teller_rec detbs_rtl_teller%ROWTYPE;
    L_CUST_AC               STTM_CUST_ACCOUNT%ROWTYPE;
    L_CUST                  STTM_CUSTOMER%ROWTYPE;
    l_rate                  NUMBER;
    P_ERR_CODE              VARCHAR2(255);
    P_ERR_PARAMS            VARCHAR2(255);
    L_CARD_TYPE             VARCHAR2(100);
    L_ARC_MAINT             IFTM_ARC_MAINT%ROWTYPE;
    L_LMTM_TYPE_VALUES      LMTM_TYPE_VALUES%ROWTYPE;
    L_COUNT                 NUMBER;
  
  BEGIN
  
    --GLOBAL.PR_INIT('001', 'SYSTEM');
  
    DBG('INSIDE PR_PROCESS_AMT_UNBLOCK_OPER_ID');
  
    FOR G IN C1 LOOP
    
      BEGIN
      
        --Initialize Branch
        --GLOBAL.pr_init('001', 'SYSTEM');
      
        SAVEPOINT A;
      
        PR_RETURN_COSMETIC_XML(G.REQUEST_MSG, L_COSMETIC_RES_MSG);
      
        DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
      
        P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
      
        --Get Order id
      
        L_ORDER_ID := P_DOCUMENT_XML.EXTRACT('/payment_order/order_id/text()')
                      .GETSTRINGVAL;
        DBG('L_ORDER_ID=' || L_ORDER_ID);
      
        --Get Customer No
        L_CUST_NO := P_DOCUMENT_XML.EXTRACT('/payment_order/customer_number/text()')
                     .GETSTRINGVAL;
        DBG('L_CUST_NO=' || L_CUST_NO);
      
        --Get Amount
        L_AMOUNT := P_DOCUMENT_XML.EXTRACT('/payment_order/amount/text()')
                    .GETSTRINGVAL;
        DBG('L_AMOUNT=' || L_AMOUNT);
      
        --Get Currency
        L_CURRENCY := P_DOCUMENT_XML.EXTRACT('/payment_order/currency/text()')
                      .GETSTRINGVAL;
        DBG('L_CURRENCY=' || L_CURRENCY);
      
        --Get Iso Numeric Currency Code
        L_CCY_CODE := FN_GET_ISO_CURRENCY_CODE(L_CURRENCY);
      
        DBG('L_CCY_CODE=' || L_CCY_CODE);
      
        --Get Order Date
        L_ORDER_DATE := TO_DATE(CAST(TO_TIMESTAMP(P_DOCUMENT_XML.EXTRACT('/payment_order/order_date/text()')
                                                  .GETSTRINGVAL,
                                                  'YYYY-MM-DD"T"HH24:mi:ss') AS DATE),
                                'YYYY-MM-DD');
      
        /*L_ORDER_DATE := P_DOCUMENT_XML.EXTRACT('/payment_order/order_date/text()')
        .GETSTRINGVAL;*/
      
        DBG('L_ORDER_DATE=' || L_ORDER_DATE);
      
        L_CARD_TYPE := P_DOCUMENT_XML.EXTRACT('/payment_order/parameter[1]/param_value/text()')
                       .GETSTRINGVAL;
      
        L_CARD_TYPE := CASE L_CARD_TYPE
                         WHEN 'MASTER CARD' THEN
                          'M'
                         WHEN 'VISA CARD' THEN
                          'V'
                       END;
      
        --Get Savings Account
        L_AC_NO := P_DOCUMENT_XML.EXTRACT('/payment_order/parameter[2]/param_value/text()')
                   .GETSTRINGVAL;
        DBG('L_AC_NO=' || L_AC_NO);
      
        --Get Purpose Id
        L_PURPOSE_ID := P_DOCUMENT_XML.EXTRACT('/payment_order/purpose_id/text()')
                        .GETSTRINGVAL;
        DBG('L_PURPOSE_ID=' || L_PURPOSE_ID);
      
        --Get Account details
        BEGIN
          SELECT *
            INTO L_CUST_ACCOUNT
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = L_AC_NO;
        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACCOUNT := NULL;
        END;
      
        --GLOBAL.PR_INIT(L_CUST_ACCOUNT.BRANCH_CODE, 'SYSTEM');
      
        IF L_CARD_TYPE = 'M' THEN
        
          pkg_detb_rtl_teller_rec.product_code := 'CCMA';
        
          BEGIN
            SELECT B.*
              INTO L_LMTM_TYPE_VALUES
              FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
             WHERE A.TYPE = B.TYPE
               AND A.TYPE = 'CREDIT_CARD_ACCS'
               AND B.CODE = 'MCCP'
               AND A.RECORD_STAT = 'O'
               AND A.AUTH_STAT = 'A';
          EXCEPTION
            WHEN OTHERS THEN
              L_LMTM_TYPE_VALUES := NULL;
          END;
        
        ELSE
          pkg_detb_rtl_teller_rec.product_code := 'CCVA';
        
          BEGIN
            SELECT B.*
              INTO L_LMTM_TYPE_VALUES
              FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
             WHERE A.TYPE = B.TYPE
               AND A.TYPE = 'CREDIT_CARD_ACCS'
               AND B.CODE = 'VCCP'
               AND A.RECORD_STAT = 'O'
               AND A.AUTH_STAT = 'A';
          EXCEPTION
            WHEN OTHERS THEN
              L_LMTM_TYPE_VALUES := NULL;
          END;
        
        END IF;
      
        --Get Acc Details
        SELECT X.*
          INTO L_CUST_AC
          FROM STTM_CUST_ACCOUNT X
         WHERE X.CUST_AC_NO = L_AC_NO;
      
        --GET BEN CUSTOMER DETAILS
        BEGIN
          SELECT X.*
            INTO L_CUST
            FROM STTM_CUSTOMER X
           WHERE X.CUSTOMER_NO = L_CUST_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED IN GETTING CUSTOMER DETAILS');
        END;
      
        GLOBAL.PR_INIT(L_CUST_AC.BRANCH_CODE, 'SYSTEM');
      
        --GET REFERENCE NO
        IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                           PKG_DETB_RTL_TELLER_REC.PRODUCT_CODE,
                                           GLOBAL.APPLICATION_DATE,
                                           L_SERIAL_NO,
                                           L_TRN_REF_NO,
                                           P_ERR_CODE) THEN
          DBG('FAILED IN GENERATION TRANSACTION REF NO');
          ROLLBACK TO A;
          CONTINUE;
        ELSE
          DBG('L_TRN_REF_NO=' || L_TRN_REF_NO);
        END IF;
      
        --Log Auto Debit Accounting Entry Log
        PR_INSERT_OPER_ID_INVOKE_LOG(L_ORDER_ID, L_TRN_REF_NO, SYSDATE);
      
        PKG_DETB_RTL_TELLER_REC.XREF := L_TRN_REF_NO;
      
        --Get Arc Maintenance
        SELECT *
          INTO L_ARC_MAINT
          FROM IFTM_ARC_MAINT A
         WHERE A.COD_PROD_ACC_CLS = pkg_detb_rtl_teller_rec.product_code
           AND ROWNUM = 1;
      
        --Get Count of Beneficiary Account
        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = L_AC_NO;
        
        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;
      
        IF L_COUNT = 0 THEN
        
          ROLLBACK TO A;
          PR_UPDATE_AMTUNBLOCK_TRACKER(L_ORDER_ID, 'E');
          PR_UPDATE_OPER_ID_INVOKE_LOG(L_ORDER_ID,
                                       L_TRN_REF_NO,
                                       'E',
                                       'FT-MTUP100',
                                       'BEN ACC NOT FOUND',
                                       GLOBAL.application_date);
        
          CONTINUE;
        
        END IF;
      
        --pkg_detb_rtl_teller_rec.product_code := 'CCFT';
      
        PKG_DETB_RTL_TELLER_REC.BRANCH_CODE := L_CUST_AC.BRANCH_CODE;
        PKG_DETB_RTL_TELLER_REC.TRN_REF_NO  := L_TRN_REF_NO;
      
        PKG_DETB_RTL_TELLER_REC.TXN_ACC    := L_LMTM_TYPE_VALUES.VALUE;
        PKG_DETB_RTL_TELLER_REC.TXN_CCY    := GLOBAL.LCY;
        PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := GLOBAL.CURRENT_BRANCH;
        --PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := PKG_DETB_RTL_TELLER_REC.OFS_BRANCH;
      
        --XRATE CALCULATION STARTS
        IF L_CUST_ACCOUNT.CCY <> 'USD' THEN
        
          IF NOT CYPKSS.FN_GETRATE(L_CUST_ACCOUNT.BRANCH_CODE,
                                   L_CUST_ACCOUNT.CCY,
                                   L_CCY_CODE, --'KHR', --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                   'STANDARD', --L_PROD.RATE_TYPE_PREFERRED,
                                   'B', --L_RATE_CODE1, --l_prod.rate_code_preferred,
                                   GLOBAL.APPLICATION_DATE,
                                   GLOBAL.APPLICATION_DATE,
                                   L_EXCH_RATE,
                                   L_RATE_FLAG,
                                   L_ERROR_CODE) THEN
            DBG('FAILED IN FN_GETRATE');
            ROLLBACK;
          END IF;
        ELSE
          L_EXCH_RATE := 1;
        END IF;
      
        DBG('L_EXCH_RATE=' || L_EXCH_RATE);
      
        --USING ABOVE RATE..CONVERT KHR TO USD AMOUNT
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(L_CCY_CODE,
                                      L_CUST_ACCOUNT.CCY,
                                      G.TXN_AMOUNT,
                                      L_EXCH_RATE,
                                      'Y',
                                      L_TXN_AMT,
                                      L_ERROR_PARAMETER) THEN
          DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
          ROLLBACK;
        END IF;
        DBG('FINAL L_TXN_AMT=' || L_TXN_AMT);
      
        PKG_DETB_RTL_TELLER_REC.OFS_ACC    := G.CUST_AC_NO;
        PKG_DETB_RTL_TELLER_REC.OFS_CCY    := L_CUST_AC.CCY;
        PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT := L_TXN_AMT; -- L_AMOUNT/100;
      
        PKG_DETB_RTL_TELLER_REC.OFS_BRANCH := L_CUST_AC.BRANCH_CODE; --GLOBAL.current_branch;
      
        PKG_DETB_RTL_TELLER_REC.TXN_AMOUNT := G.TXN_AMOUNT; --L_TXN_AMT;
      
        PKG_DETB_RTL_TELLER_REC.TXN_TRN_CODE     := L_ARC_MAINT.COD_MAIN_TXN_CODE; --'000'; --TRANSACION CODE
        PKG_DETB_RTL_TELLER_REC.OFS_TRN_CODE     := L_ARC_MAINT.COD_OFFSET_TXN_CODE; --'000'; --TRANSACION CODE
        PKG_DETB_RTL_TELLER_REC.EXCH_RATE        := L_EXCH_RATE;
        PKG_DETB_RTL_TELLER_REC.TRN_DT           := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.VALUE_DT         := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.REL_CUSTOMER     := L_CUST.CUSTOMER_NO;
        PKG_DETB_RTL_TELLER_REC.BENEF_NAME       := L_CUST.CUSTOMER_NAME1;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR1      := L_CUST.ADDRESS_LINE1;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR2      := L_CUST.ADDRESS_LINE2;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR3      := L_CUST.ADDRESS_LINE3;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR4      := L_CUST.ADDRESS_LINE4;
        PKG_DETB_RTL_TELLER_REC.LIQN_DT          := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.RECORD_STAT      := 'A';
        PKG_DETB_RTL_TELLER_REC.AUTH_STAT        := 'U';
        PKG_DETB_RTL_TELLER_REC.MAKER_ID         := 'SYSTEM';
        PKG_DETB_RTL_TELLER_REC.MAKER_DT_STAMP   := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.CHECKER_ID       := 'SYSTEM';
        PKG_DETB_RTL_TELLER_REC.CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.MOD_NO           := 1;
        PKG_DETB_RTL_TELLER_REC.SCODE            := 'FLEXCUBE';
        PKG_DETB_RTL_TELLER_REC.DR_ACC           := 'OFS';
        PKG_DETB_RTL_TELLER_REC.MODULE           := 'RT';
        PKG_DETB_RTL_TELLER_REC.ESN              := 1;
        PKG_DETB_RTL_TELLER_REC.EVENT_CODE       := 'INIT';
        PKG_DETB_RTL_TELLER_REC.TRACK_RECEIVABLE := 'N';
        PKG_DETB_RTL_TELLER_REC.TIME_RECEIVED    := SYSDATE;
      
        DBG('Calling depks_rtl_teller.fn_save');
      
        IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN
          dbg('FAILED IN FN_SAVE');
          --PR_LOG_ERROR('IFDCCPFT', 'FLEXCUBE', p_err_code, p_err_params);
          ROLLBACK TO A;
          PR_UPDATE_AMTUNBLOCK_TRACKER(L_ORDER_ID, 'E');
          PR_UPDATE_OPER_ID_INVOKE_LOG(L_ORDER_ID,
                                       L_TRN_REF_NO,
                                       'E',
                                       P_ERR_CODE,
                                       P_ERR_PARAMS,
                                       GLOBAL.application_date);
        ELSE
          DBG('SUCCESS IN FN_sAVE');
          DBG('CALLING DEPKS_RTL_TELLER.FN_RTL_TELLER_AUTH');
          IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(L_CUST_AC.BRANCH_CODE,
                                                      L_TRN_REF_NO,
                                                      GLOBAL.USER_ID,
                                                      GLOBAL.LCY,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
            DBG('AUTH RETRUNED FALSE' || P_ERR_CODE);
            DBG('FAILED TO PROCESS TRANSACTION');
            DBG('ROLLINGBACK TO SAVEPOINT A');
            ROLLBACK TO A;
            PR_UPDATE_AMTUNBLOCK_TRACKER(L_ORDER_ID, 'E');
            PR_UPDATE_OPER_ID_INVOKE_LOG(L_ORDER_ID,
                                         L_TRN_REF_NO,
                                         'E',
                                         P_ERR_CODE,
                                         P_ERR_PARAMS,
                                         GLOBAL.application_date);
          ELSE
            DBG('SUCCESS IN FN_AUTH');
            PR_UPDATE_AMTUNBLOCK_TRACKER(L_ORDER_ID, 'P');
            PR_UPDATE_OPER_ID_INVOKE_LOG(L_ORDER_ID,
                                         L_TRN_REF_NO,
                                         'P',
                                         NULL,
                                         NULL,
                                         GLOBAL.application_date);
          END IF;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN PROCESSING CURRENT INCOMING ORDER ID=' ||
              L_ORDER_ID);
          DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
          CONTINUE;
      END;
    
    END LOOP;
  
    --Done processing order ids
  
    --Generate Outgoing Auto Debit Respnse xml file
    --PR_GENERATE_AUTODEBIT_RESPONSE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_AMT_UNBLOCK_OPER_ID');
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
  END PR_PROCESS_AMT_UNBLOCK_OPER_ID;

  PROCEDURE PR_INIT_MSG IS
    FILE      VARCHAR2(32767);
    FILE_NAME VARCHAR2(100);
    FPATH     VARCHAR2(1000);
  BEGIN
    --global.pr_init('000', 'SYSTEM');
    --debug.pr_close;
    DBG('entered  ');
    g_cstb_params := FN_GET_PARAMS;
    DBG('Income path :' || g_cstb_params.PARAM_VAL);
    SELECT DIRECTORY_PATH
      INTO FPATH
      FROM DBA_DIRECTORIES
     WHERE DIRECTORY_NAME = g_cstb_params.PARAM_VAL;
  
    DBG('FPATH  - ' || FPATH);
    FILE_NAME := FN_READ_AUTO_DEBIT_FILE('/u01/fcubs/interfaces/Credit_Card_Payment/Incoming/ready');
    DBG('FILE_NAME  - ' || FILE_NAME);
    /*LOOP
     EXIT WHEN FILE IS NULL;
     P_FILE_NAME := SUBSTR(FILE, INSTR(FILE, ',', -1) + 1);
     DBG('FILE NAME IS: ' || P_FILE_NAME);
    
      --FOR G IN (SELECT * FROM )
    
      --P_FILE_NAME := 'DIRECT_DEBIT_REQ_'|| TO_CHAR(SYSDATE,'YYYYMMDD')||'_';
    
    
      --FILE := SUBSTR(FILE, 1, INSTR(FILE, ',', -1) - 1);
    END LOOP;*/
    PR_MOVE_FILE(FILE_NAME);
    DBG('Success  ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INIT_MSG ' || SQLERRM);
  END PR_INIT_MSG;

  PROCEDURE PR_MOVE_FILE(P_FILE_NAME IN VARCHAR2) IS
    L_XML XMLTYPE;
  BEGIN
  
    --GLOBAL.PR_INIT('002', 'SYSTEM');
  
    DBG('INSIDE PR_MOVE_FILE=' || P_FILE_NAME);
  
    IF P_FILE_NAME IS NOT NULL THEN
      UTL_FILE.FRENAME('CC_PAY_AUTO_DEBIT_READY',
                       P_FILE_NAME,
                       'CC_PAY_AUTO_DEBIT_WIP',
                       P_FILE_NAME,
                       TRUE);
      DBG('moved to wip');
      DBG('File name: ' || P_FILE_NAME);
    
      SELECT XMLTYPE(BFILENAME('CC_PAY_AUTO_DEBIT_WIP', P_FILE_NAME),
                     NLS_CHARSET_ID('AL32UTF16'))
        INTO L_XML
        FROM DUAL;
    
      --Handle Handoff
      PR_AMOUNT_UNBLOCK_INC_HANDOFF(L_XML, P_FILE_NAME);
    
      --Handle Process
      PR_PROCESS_AMT_UNBLOCK_OPER_ID;
    
      --Generate Outgoing Auto Debit Respnse xml file
      PR_GEN_AMTUNBLOCK_RESPONSE;
    
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN WOT OF PR_MOVE_FILE=' || SQLERRM);
  END PR_MOVE_FILE;

  FUNCTION FN_GET_INST_ID(P_REQUEST_MSG IFTM_AUTO_DEBIT_PAYMENT_REQ.REQUEST_MSG%TYPE)
    RETURN VARCHAR2 IS
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_INST_ID          VARCHAR2(100);
  BEGIN
  
    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
  
    L_INST_ID := P_DOCUMENT_XML.EXTRACT('/payment_orders/inst_id/text()')
                 .GETSTRINGVAL;
  
    DBG('L_INST_ID=' || L_INST_ID);
  
    RETURN L_INST_ID;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING FN_GET_INST_ID');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN L_INST_ID;
  END FN_GET_INST_ID;

  FUNCTION FN_GET_FILE_DATE(P_REQUEST_MSG IFTM_AUTO_DEBIT_PAYMENT_REQ.REQUEST_MSG%TYPE)
    RETURN DATE IS
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_FILE_DATE        VARCHAR2(100);
  BEGIN
  
    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
  
    L_FILE_DATE := TO_DATE(P_DOCUMENT_XML.EXTRACT('/payment_orders/file_date/text()')
                           .GETSTRINGVAL,
                           'YYYY-MM-DD');
    DBG('L_FILE_DATE=' || L_FILE_DATE);
    RETURN L_FILE_DATE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING FN_GET_FILE_DATE');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN L_FILE_DATE;
  END FN_GET_FILE_DATE;

  FUNCTION FN_GET_FILE_NO(P_REQUEST_MSG IFTM_AUTO_DEBIT_PAYMENT_REQ.REQUEST_MSG%TYPE)
    RETURN VARCHAR2 IS
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_FILE_NO          VARCHAR2(100);
  BEGIN
  
    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
  
    L_FILE_NO := P_DOCUMENT_XML.EXTRACT('/payment_orders/file_number/text()')
                 .GETSTRINGVAL;
    DBG('L_FILE_NO=' || L_FILE_NO);
    RETURN L_FILE_NO;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING FN_GET_FILE_NO');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN L_FILE_NO;
  END FN_GET_FILE_NO;

  PROCEDURE PR_AMOUNT_UNBLOCK_INC_HANDOFF(P_REQ_MSG   IN XMLTYPE,
                                          P_FILE_NAME IN VARCHAR2) IS
  
    L_RESPONSE         VARCHAR2(32767);
    L_SNIPPET          XMLTYPE;
    L_IX               BINARY_INTEGER;
    L_TEXT             CLOB;
    L_START            NUMBER := 1;
    L_END              NUMBER := 0;
    L_NO_OF_PAY_ORDERS NUMBER := 0;
    L_PAY_ORDER        CLOB;
    L_INST_ID          VARCHAR2(100);
    L_FILE_DATE        DATE;
    L_FILE_NUMBER      VARCHAR2(100);
  
    E_UPDATE_ERROR EXCEPTION;
    P_ERR_CODE     VARCHAR2(1000);
    P_ERR_PARAMS   VARCHAR2(1000);
    P_REQ_MSG_CLOB CLOB;
  
  BEGIN
  
    DBG('START OF PR_AMOUNT_UNBLOCK_INC_HANDOFF');
  
    P_REQ_MSG_CLOB := P_REQ_MSG.getClobVal();
  
    --DBG('P_REQ_MSG_CLOB=' || P_REQ_MSG_CLOB);
  
    L_INST_ID := FN_GET_INST_ID(P_REQ_MSG_CLOB);
  
    DBG('L_INST_ID=' || L_INST_ID);
  
    L_FILE_DATE := FN_GET_FILE_DATE(P_REQ_MSG_CLOB);
  
    DBG('L_FILE_DATE=' || L_FILE_DATE);
  
    L_FILE_NUMBER := FN_GET_FILE_NO(P_REQ_MSG_CLOB);
  
    DBG('L_FILE_NUMBER=' || L_FILE_NUMBER);
  
    L_NO_OF_PAY_ORDERS := (LENGTH(P_REQ_MSG_CLOB) -
                          LENGTH(REPLACE(P_REQ_MSG_CLOB,
                                          '</payment_order>',
                                          ''))) /
                          length('</payment_order>');
  
    DBG('L_NO_OF_PAY_ORDERS=' || L_NO_OF_PAY_ORDERS);
  
    FOR G IN 1 .. L_NO_OF_PAY_ORDERS LOOP
    
      DBG('G value=' || G);
      DBG('BEGIN L_START=' || L_START);
      DBG('BEGIN L_END=' || L_END);
    
      L_START := INSTR(P_REQ_MSG_CLOB, '<payment_order>', L_START, G);
      L_END   := INSTR(P_REQ_MSG_CLOB, '</payment_order>', L_START, 1);
    
      DBG('AFTER L_START=' || L_START);
      DBG('AFTER L_END=' || L_END);
    
      --DBMS_OUTPUT.PUT_LINE('FINAL SUB END=' || L_END - L_START + LENGTH('</payment_order>'));
    
      L_PAY_ORDER := SUBSTR(P_REQ_MSG_CLOB,
                            L_START,
                            L_END - L_START + LENGTH('</payment_order>'));
    
      --DBMS_OUTPUT.PUT_LINE('L_PAY_ORDER=' || L_PAY_ORDER);
    
      PR_INSERT_AMT_UNBLOCK_TRACKER(L_INST_ID,
                                    L_FILE_DATE,
                                    L_FILE_NUMBER,
                                    L_PAY_ORDER,
                                    P_FILE_NAME);
    
      L_START := 1;
    
      DBG('-------------------');
    
    END LOOP;
  
    DBG('DONE WITH HANDOFF');
  
    -- RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      -- RETURN FALSE;
  END PR_AMOUNT_UNBLOCK_INC_HANDOFF;

  PROCEDURE PR_INSERT_AMT_UNBLOCK_TRACKER(P_INST_ID     IN VARCHAR2,
                                          P_FILE_DATE   IN VARCHAR2,
                                          P_FILE_NO     IN VARCHAR2,
                                          P_REQUEST_MSG IN IFTM_AUTO_DEBIT_PAYMENT_REQ.REQUEST_MSG%TYPE,
                                          P_FILE_NAME   IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_ORDER_ID         IFTM_AUTO_DEBIT_PAYMENT_REQ.ORDER_ID%TYPE;
    L_CUST_NO          IFTB_AUTO_DEBIT_INCOMING_TRACK.CUST_NO%TYPE;
    L_TXN_AMOUNT       IFTB_AUTO_DEBIT_INCOMING_TRACK.TXN_AMOUNT%TYPE;
    L_ISO_CCY_CODE     IFTB_AUTO_DEBIT_INCOMING_TRACK.ISO_CCY_CODE%TYPE;
    L_CCY_CODE         IFTB_AUTO_DEBIT_INCOMING_TRACK.CCY_CODE%TYPE;
    L_ORDER_DATE       IFTB_AUTO_DEBIT_INCOMING_TRACK.ORDER_DATE%TYPE;
    L_CARD_TYPE        VARCHAR2(100);
    L_AC_NO            IFTB_AUTO_DEBIT_INCOMING_TRACK.CUST_AC_NO%TYPE;
    L_PURPOSE_ID       IFTB_AUTO_DEBIT_INCOMING_TRACK.PURPOSE_ID%TYPE;
    L_COUNT            NUMBER;
  
  BEGIN
  
    DBG('BEFORE START OF PR_INSERT_AMT_UNBLOCK_TRACKER');
  
    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
  
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
  
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
  
    L_ORDER_ID := P_DOCUMENT_XML.EXTRACT('/payment_order/order_id/text()')
                  .GETSTRINGVAL;
  
    DBG('L_ORDER_ID=' || L_ORDER_ID);
  
    L_CUST_NO := P_DOCUMENT_XML.EXTRACT('/payment_order/customer_number/text()')
                 .GETSTRINGVAL;
  
    DBG('L_CUST_NO=' || L_CUST_NO);
  
    L_TXN_AMOUNT := (P_DOCUMENT_XML.EXTRACT('/payment_order/amount/text()')
                    .GETSTRINGVAL) / 100;
  
    DBG('L_TXN_AMOUNT=' || L_TXN_AMOUNT);
  
    L_ISO_CCY_CODE := P_DOCUMENT_XML.EXTRACT('/payment_order/currency/text()')
                      .GETSTRINGVAL;
  
    DBG('L_ISO_CCY_CODE=' || L_ISO_CCY_CODE);
  
    L_CCY_CODE := FN_GET_ISO_CURRENCY_CODE(L_ISO_CCY_CODE);
  
    DBG('L_CCY_CODE=' || L_CCY_CODE);
  
    L_ORDER_DATE := TO_DATE(CAST(TO_TIMESTAMP(P_DOCUMENT_XML.EXTRACT('/payment_order/order_date/text()')
                                              .GETSTRINGVAL,
                                              'YYYY-MM-DD"T"HH24:mi:ss') AS DATE),
                            'YYYY-MM-DD');
  
    DBG('L_ORDER_DATE=' || L_ORDER_DATE);
  
    L_CARD_TYPE := P_DOCUMENT_XML.EXTRACT('/payment_order/parameter[1]/param_value/text()')
                   .GETSTRINGVAL;
  
    DBG('L_CARD_TYPE=' || L_CARD_TYPE);
  
    L_CARD_TYPE := CASE L_CARD_TYPE
                     WHEN 'MASTER CARD' THEN
                      'M'
                     WHEN 'VISA CARD' THEN
                      'V'
                   END;
  
    DBG('L_CARD_TYPE=' || L_CARD_TYPE);
  
    L_AC_NO := P_DOCUMENT_XML.EXTRACT('/payment_order/parameter[2]/param_value/text()')
               .GETSTRINGVAL;
  
    DBG('L_AC_NO=' || L_AC_NO);
  
    L_PURPOSE_ID := P_DOCUMENT_XML.EXTRACT('/payment_order/purpose_id/text()')
                    .GETSTRINGVAL;
  
    DBG('L_PURPOSE_ID=' || L_PURPOSE_ID);
  
    --Check if above ORDER ID already available
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
        FROM IFTB_AUTO_DEBIT_INCOMING_TRACK
       WHERE ORDER_ID = L_ORDER_ID;
      -- AND STATUS = 'P';
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT := 0;
    END;
  
    IF L_COUNT = 0 THEN
      INSERT INTO IFTB_AUTO_DEBIT_INCOMING_TRACK
        (INST_ID,
         FILE_DATE,
         FILE_NO,
         ORDER_ID,
         REQUEST_MSG,
         STATUS,
         TIME_IN,
         CUST_NO,
         TXN_AMOUNT,
         ISO_CCY_CODE,
         CCY_CODE,
         ORDER_DATE,
         CARD_TYPE,
         CUST_AC_NO,
         PURPOSE_ID,
         FILE_NAME)
      VALUES
        (P_INST_ID,
         P_FILE_DATE,
         P_FILE_NO,
         L_ORDER_ID,
         P_REQUEST_MSG,
         'U',
         SYSDATE,
         L_CUST_NO,
         L_TXN_AMOUNT,
         L_ISO_CCY_CODE,
         L_CCY_CODE,
         L_ORDER_DATE,
         L_CARD_TYPE,
         L_AC_NO,
         L_PURPOSE_ID,
         P_FILE_NAME);
    
      --Temp table
      INSERT INTO IFTB_AUTODEBIT_INC_TRACK
        (INST_ID,
         FILE_DATE,
         FILE_NO,
         ORDER_ID,
         REQUEST_MSG,
         STATUS,
         TIME_IN,
         CUST_NO,
         TXN_AMOUNT,
         ISO_CCY_CODE,
         CCY_CODE,
         ORDER_DATE,
         CARD_TYPE,
         CUST_AC_NO,
         PURPOSE_ID,
         FILE_NAME)
      VALUES
        (P_INST_ID,
         P_FILE_DATE,
         P_FILE_NO,
         L_ORDER_ID,
         P_REQUEST_MSG,
         'U',
         SYSDATE,
         L_CUST_NO,
         L_TXN_AMOUNT,
         L_ISO_CCY_CODE,
         L_CCY_CODE,
         L_ORDER_DATE,
         L_CARD_TYPE,
         L_AC_NO,
         L_PURPOSE_ID,
         P_FILE_NAME);
    END IF;
  
    DBG('AFTER INSERTING INTO PR_INSERT_AMOUNT_UNBLOCK_TRACKER');
    DBG('COMMITTING');
    COMMIT;
    DBG('RETURNING SUCCESSFULLY FROM PR_INSERT_AMT_UNBLOCK_TRACKER');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      DBG('FAILED IN PR_INSERT_AMT_UNBLOCK_TRACKER');
    
  END PR_INSERT_AMT_UNBLOCK_TRACKER;

  PROCEDURE PR_AMOUNT_UNBLOCK_UPLOAD(PARAMNAME  VARCHAR2,
                                     PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    GLOBAL.PR_INIT('001', 'SYSTEM');
  
    DBG('Inside PR_AMOUNT_UNBLOCK_UPLOAD');
  
    PR_INIT_MSG;
    DBG('Successful return from PR_AMOUNT_UNBLOCK_UPLOAD');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception during PR_AMOUNT_UNBLOCK_UPLOAD' || SQLERRM);
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
  END PR_AMOUNT_UNBLOCK_UPLOAD;

  PROCEDURE PR_PROCESS_AMOUNT_UNBLOCK(PARAMNAME  VARCHAR2,
                                      PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    --GLOBAL.PR_INIT('000', 'SYSTEM');
  
    PR_PROCESS_AMT_UNBLOCK_OPER_ID;
  
    DBG('SUCCESSFUL RETURN FROM PR_PROCESS_AMOUNT_UNBLOCK');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_AMOUNT_UNBLOCK');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
  END PR_PROCESS_AMOUNT_UNBLOCK;

END IFPKS_AMOUNT_UNBLOCK_UTILS;
