CREATE OR REPLACE PACKAGE BODY IFPKS_AMOUNT_UNBLOCK_UTILS AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_AMOUNT_UNBLOCK_UTILS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;

  PROCEDURE PR_UPDATE_OPER_ID_INVOKE_LOG(P_ORDER_ID        IN VARCHAR2,
                                         P_REF_NO          IN VARCHAR2,
                                         P_STATUS          IN CHAR,
                                         P_ERR_CODE        IN VARCHAR2,
                                         P_ERR_PARAM       IN VARCHAR2,
                                         P_INVOKE_DATE_END IN DATE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_OPER_ID_INVOKE_LOG');

    UPDATE IFTB_AUTO_DEBIT_ORDER_ID_LOG
       SET STATUS          = P_STATUS,
           ERROR_CODE      = P_ERR_CODE,
           ERROR_PARAM     = P_ERR_PARAM,
           INVOKE_DATE_END = P_INVOKE_DATE_END
     WHERE ORDER_ID = P_ORDER_ID
       AND TRN_REF_NO = P_REF_NO;
    COMMIT;
    DBG('END OF PR_UPDATE_OPER_ID_INVOKE_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_OPER_ID_INVOKE_LOG');
      DBG('ERROR CODE IN PR_UPDATE_OPER_ID_INVOKE_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_OPER_ID_INVOKE_LOG=' || SQLERRM);
  END PR_UPDATE_OPER_ID_INVOKE_LOG;

  PROCEDURE PR_UPDATE_AMTUNBLOCK_TRACKER(P_ORDER_ID IN VARCHAR2,
                                         P_STATUS   IN CHAR) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_AMTUNBLOCK_TRACKER');

    UPDATE IFTB_AUTO_DEBIT_INCOMING_TRACK
       SET STATUS = P_STATUS
     WHERE ORDER_ID = P_ORDER_ID;

    UPDATE IFTB_AUTODEBIT_INC_TRACK
       SET STATUS = P_STATUS
     WHERE ORDER_ID = P_ORDER_ID;
    COMMIT;
    DBG('END OF PR_UPDATE_AMTUNBLOCK_TRACKER');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_AMTUNBLOCK_TRACKER');
      DBG('ERROR CODE IN PR_UPDATE_AMTUNBLOCK_TRACKER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_AMTUNBLOCK_TRACKER=' || SQLERRM);
  END PR_UPDATE_AMTUNBLOCK_TRACKER;

  FUNCTION FN_GET_AMTUNBLOCK_RES_CLOB RETURN CLOB IS
    L_CLOB CLOB;
  BEGIN

    L_CLOB := '<payment_order>
  <order_id>$L_ORDER_ID</order_id>
  <resp_code>$L_RESP_CODE</resp_code>
  <amount>
    <amount_value>$L_AMOUNT</amount_value>
    <currency>$L_ISO_CCY</currency>
  </amount>
  <currency>$L_ISO_CCY</currency>
  <resp_amount>
    <amount_value>$L_AMOUNT</amount_value>
    <currency>$L_ISO_CCY</currency>
  </resp_amount>
</payment_order>';

    RETURN L_CLOB;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN RETURNING FN_GET_AMTUNBLOCK_RES_CLOB');
      DBG('ERROR CODE IN FN_GET_AMTUNBLOCK_RES_CLOB=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AMTUNBLOCK_RES_CLOB=' || SQLERRM);
  END FN_GET_AMTUNBLOCK_RES_CLOB;

  FUNCTION FN_GET_ISO_CURRENCY_CODE(P_ISO_CCY IN VARCHAR2)
    RETURN CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE AS
    L_CCY_CODE CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE;
  BEGIN
    BEGIN
      SELECT CCY_CODE
        INTO L_CCY_CODE
        FROM CYTMS_CCY_DEFN_MASTER
       WHERE ISO_NUM_CCY_CODE = P_ISO_CCY
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      RETURN L_CCY_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN L_CCY_CODE;
    END;
    RETURN L_CCY_CODE;
  END FN_GET_ISO_CURRENCY_CODE;

  FUNCTION FN_GET_PARAMS RETURN CSTB_PARAM_CUSTOM%ROWTYPE RESULT_CACHE RELIES_ON(CSTB_PARAM_CUSTOM) IS
  BEGIN
    DBG('Inside FN_GET_PARAMS');
    SELECT *
      INTO g_cstb_params
      FROM CSTB_PARAM_CUSTOM
     WHERE PARAM_NAME = 'AUTO_DEBIT_PAYMENT_DTLS';
    DBG('Returing from FN_GET_PARAMS');
    RETURN g_cstb_params;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in FN_GET_PARAMS' || SQLERRM);
      DBG('Error ' || dbms_utility.format_error_backtrace);
      g_cstb_params := NULL;
      RETURN g_cstb_params;
  END;

  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2) IS

    --P_COSMETIC_XML VARCHAR2(32000);

  BEGIN

    P_COSMETIC_XML := P_XML;

    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<?xml version="1.0" encoding="UTF-8"?>',
                              NULL);

  END PR_RETURN_COSMETIC_XML;

  PROCEDURE PR_WRITE_CLOB_TO_FILE(P_IN_DIR_NAME  IN VARCHAR2,
                                  P_IN_FILE_NAME IN VARCHAR2,
                                  P_IN_CLOB      IN CLOB) IS
    L_FILE   UTL_FILE.FILE_TYPE;
    L_AMT    NUMBER := 32000;
    L_OFFSET NUMBER := 1;
    L_LENGTH NUMBER := NVL(DBMS_LOB.GETLENGTH(P_IN_CLOB), 0);
    L_BUFF   VARCHAR2(32760);
  BEGIN
    --OPEN FILE
    L_FILE := UTL_FILE.FOPEN(P_IN_DIR_NAME, P_IN_FILE_NAME, 'w', 32760);

    --READ CLOB AND UPLOAD INTO FILE
    WHILE (L_OFFSET < L_LENGTH) LOOP
      DBMS_LOB.READ(P_IN_CLOB, L_AMT, L_OFFSET, L_BUFF);

      UTL_FILE.PUT(L_FILE, L_BUFF);
      UTL_FILE.FFLUSH(L_FILE);
      UTL_FILE.NEW_LINE(L_FILE);

      L_OFFSET := L_OFFSET + L_AMT;
    END LOOP;

    --CLOSE FILE
    UTL_FILE.FCLOSE(L_FILE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_WRITE_CLOB_TO_FILE');
      DBG('ERROR CODE IN PR_WRITE_CLOB_TO_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_WRITE_CLOB_TO_FILE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN PR_WRITE_CLOB_TO_FILE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END PR_WRITE_CLOB_TO_FILE;

  PROCEDURE PR_GEN_AMTUNBLOCK_RESPONSE IS
    L_RESP_CLOB                CLOB;
    L_RESP_TEMPLATE            CLOB;
    L_FILE_NAME                VARCHAR2(32767);
    L_RESP_CODE                VARCHAR2(10);
    L_IFTB_AUTODEBIT_INC_TRACK IFTB_AUTODEBIT_INC_TRACK%ROWTYPE;
  BEGIN

    DBG('START OF PR_GEN_AMTUNBLOCK_RESPONSE');

    FOR G IN (SELECT * FROM IFTB_AUTODEBIT_INC_TRACK) LOOP

      L_RESP_TEMPLATE := FN_GET_AMTUNBLOCK_RES_CLOB;

      L_FILE_NAME := G.FILE_NAME;

      L_RESP_CODE := CASE G.STATUS
                       WHEN 'P' THEN
                        'PORC0001'
                       WHEN 'E' THEN
                        'PORC0002'
                       ELSE
                        'PORC0003'
                     END;

      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE, '$L_ORDER_ID', G.ORDER_ID);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_RESP_CODE',
                                 L_RESP_CODE);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_AMOUNT',
                                 G.TXN_AMOUNT * 100);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_ISO_CCY',
                                 G.ISO_CCY_CODE);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_ISO_CCY',
                                 G.ISO_CCY_CODE);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_AMOUNT',
                                 G.TXN_AMOUNT * 100);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_ISO_CCY',
                                 G.ISO_CCY_CODE);

      L_RESP_CLOB := L_RESP_CLOB || L_RESP_TEMPLATE;

      L_RESP_TEMPLATE := NULL;

    END LOOP;

    BEGIN
      SELECT *
        INTO L_IFTB_AUTODEBIT_INC_TRACK
        FROM IFTB_AUTODEBIT_INC_TRACK
       WHERE ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        L_IFTB_AUTODEBIT_INC_TRACK := NULL;
    END;

    L_RESP_CLOB := '<?xml version="1.0" encoding="utf-8"?>
<payment_orders xmlns="http://bpc.ru/sv/SVXP/payment_order"><inst_id>9999</inst_id>
  <file_date>' ||
                   TO_CHAR(GLOBAL.APPLICATION_DATE, 'YYYY-MM-DD') ||
                   '</file_date>
  <file_number>' || L_IFTB_AUTODEBIT_INC_TRACK.FILE_NO ||
                   '</file_number>' || L_RESP_CLOB || '</payment_orders>';

    --DBG('DONE WITH GENERATING CLOB RESPONSE=' || L_RESP_CLOB);

    --Write to output file
    DBG('START OF WRITING CLOB TO AN XML FILE');
    PR_WRITE_CLOB_TO_FILE('CC_PAY_AUTO_DEBIT_COMP',
                          L_FILE_NAME || '_RESPONSE' || '.XML',
                          L_RESP_CLOB);

    DBG('END OF WRITING CLOB TO AN XML FILE');

    DBG('DELETING FROM TEMP TABLE:IFTB_AUTODEBIT_INC_TRACK');
    DELETE FROM IFTB_AUTODEBIT_INC_TRACK;
    COMMIT;

    DBG('END OF PR_GEN_AMTUNBLOCK_RESPONSE');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_GEN_AMTUNBLOCK_RESPONSE');
      DBG('ERROR CODE IN PR_GEN_AMTUNBLOCK_RESPONSE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_GEN_AMTUNBLOCK_RESPONSE=' || SQLERRM);
  END PR_GEN_AMTUNBLOCK_RESPONSE;

  PROCEDURE PR_PROCESS_AMT_UNBLOCK_OPER_ID IS
    --Accounting Entry Table Building
    l_init_acc_hoff   actbs_handoff%ROWTYPE;
    l_acc_hoff        acpkss.tbl_achoff;
    l_hoff_count      INTEGER := 0;
    L_error_code      VARCHAR2(200);
    L_error_parameter VARCHAR2(200);
    l_contract_ref_no cstbs_contract.contract_ref_no%TYPE;
    l_event_sr_no     cstbs_contract_event_log.event_seq_no%TYPE := '1';
    --l_ac_no           sttm_cust_account.cust_ac_no%TYPE := '000002756';
    l_ac_no sttm_cust_account.cust_ac_no%TYPE;
    --l_ac_ccy          sttm_cust_account.ccy%TYPE := 'USD';
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_fcy_amount   actbs_daily_log.fcy_amount%TYPE := '';
    l_counterparty sttm_cust_account.cust_no%TYPE := '';
    l_mishead      actbs_daily_log.mis_head%TYPE := '';
    l_amount_tag   actbs_daily_log.amount_tag%TYPE := 'TXN_AMT';
    l_event        actbs_daily_log.event%TYPE := 'INIT';
    l_drcrind      VARCHAR2(1) := 'D';
    l_trn_code     sttms_trn_code.trn_code%TYPE := 'CCI'; --check with team

    L_ORDER_ID   IFTB_AUTO_DEBIT_INCOMING_TRACK.ORDER_ID%TYPE;
    L_CUST_NO    IFTB_AUTO_DEBIT_INCOMING_TRACK.CUST_NO%TYPE;
    L_AMOUNT     IFTB_AUTO_DEBIT_INCOMING_TRACK.TXN_AMOUNT%TYPE;
    L_CURRENCY   IFTB_AUTO_DEBIT_INCOMING_TRACK.ISO_CCY_CODE%TYPE;
    L_ORDER_DATE IFTB_AUTO_DEBIT_INCOMING_TRACK.ORDER_DATE%TYPE;
    L_PURPOSE_ID IFTB_AUTO_DEBIT_INCOMING_TRACK.PURPOSE_ID %TYPE;

    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;

    L_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;
    L_EXCH_RATE    ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE_FLAG    NUMBER;
    L_TXN_AMT      IFTB_AUTO_DEBIT_INCOMING_TRACK.TXN_AMOUNT%TYPE;
    L_CCY_CODE     CYTM_CCY_DEFN_MASTER.CCY_CODE%TYPE;
    L_SERIAL_NO    VARCHAR2(16);
    L_TRN_REF_NO   Actb_Daily_Log.TRN_REF_NO%TYPE;

    CURSOR C1 IS
      SELECT * FROM IFTB_AMT_UNBLK_INCOMING_TRACK WHERE STATUS IN ('U');

    pkg_detb_rtl_teller_rec detbs_rtl_teller%ROWTYPE;
    L_CUST_AC               STTM_CUST_ACCOUNT%ROWTYPE;
    L_CUST                  STTM_CUSTOMER%ROWTYPE;
    l_rate                  NUMBER;
    P_ERR_CODE              VARCHAR2(255);
    P_ERR_PARAMS            VARCHAR2(255);
    L_CARD_TYPE             VARCHAR2(100);
    L_ARC_MAINT             IFTM_ARC_MAINT%ROWTYPE;
    L_LMTM_TYPE_VALUES      LMTM_TYPE_VALUES%ROWTYPE;
    L_COUNT                 NUMBER;

    L_TY_ATM_TXN_REC GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC;

    PROCESS_STATUS CHAR(1);
    P_ERR_PARAM    VARCHAR2(100);
    ERROR_EXCEPTION EXCEPTION;

  BEGIN

    --GLOBAL.PR_INIT('001', 'SYSTEM');

    DBG('INSIDE PR_PROCESS_AMT_UNBLOCK_OPER_ID');
    BEGIN
      FOR G IN C1 LOOP
        BEGIN
          L_TY_ATM_TXN_REC                  := NULL;
          L_TY_ATM_TXN_REC.FILE_PROCESS     := 'Y';
          L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE := '991'; --L_SWTB_SETTLEMENT.BRANCH_CODE;
          L_TY_ATM_TXN_REC.USER_ID          := 'FLEXSWITCH'; --P_USER;
          L_TY_ATM_TXN_REC.SOURCE           := 'FLEXSWITCH';
          ---L_TY_ATM_TXN_REC.TY_PROCESSING_INSTRUCTIONS        := L_INSTR_REC;
          --L_TY_ATM_TXN_REC.TY_BIZ_PROCESS_HEADER             := L_REC_MSG_HEADER;
          L_TY_ATM_TXN_REC.MSG_TYPE                          := NULL; --L_SWTB_SETTLEMENT.MSG_TYPE;
          L_TY_ATM_TXN_REC.PAN                               := G.ISSUER_CARD_NUMBER; -- L_SWTB_SETTLEMENT.PAN;
          L_TY_ATM_TXN_REC.TY_BIZ_PROCESS_HEADER.BRANCH_CODE := '991'; --L_SWTB_SETTLEMENT.BRANCH_CODE;

          --L_TXN_CODE                 := NULL;--L_SWTB_SETTLEMENT.TXN_CODE;
          L_TY_ATM_TXN_REC.PROC_CODE := NULL; --L_SWTB_SETTLEMENT.PROC_CODE;
          L_TY_ATM_TXN_REC.TXN_AMT   := G.OPER_AMOUNT; --L_SWTB_SETTLEMENT.TXN_AMT;

          L_TY_ATM_TXN_REC.TXN_CCY_CODE  := G.OPER_ISO_CCY_CODE; --G.OPER_CCY --L_SWTB_SETTLEMENT.TXN_CCY_CODE;
          L_TY_ATM_TXN_REC.SETL_AMT      := G.SETTLEMENT_AMOUNT; --L_SWTB_SETTLEMENT.SETL_AMT;
          L_TY_ATM_TXN_REC.SETL_CCY_CODE := G.SETTLEMENT_CCY; --L_SWTB_SETTLEMENT.SETL_CCY_CODE;
          L_TY_ATM_TXN_REC.BILL_AMT      := G.SETTLEMENT_AMOUNT; --L_SWTB_SETTLEMENT.BILL_AMT;
          L_TY_ATM_TXN_REC.BILL_CCY_CODE := G.SETTLEMENT_CCY; --L_SWTB_SETTLEMENT.BILL_CCY_CODE;
          L_TY_ATM_TXN_REC.TXN_DT        := G.OPER_DATE; --L_SWTB_SETTLEMENT.TXN_DATE;
          L_TY_ATM_TXN_REC.TRANS_DT_TIME := G.OPER_DATE; --L_SWTB_SETTLEMENT.TXN_DATE;

          L_TY_ATM_TXN_REC.STAN := SUBSTR(G.RRN, -1, 6); --L_SWTB_SETTLEMENT.STAN;

          L_TY_ATM_TXN_REC.SETL_DATE      := TO_CHAR(G.OPER_DATE,
                                                     'YYYYMMDD');
          L_TY_ATM_TXN_REC.ACQ_INS_ID     := G.ACQUIRER_BIN; --L_SWTB_SETTLEMENT.ACQ_ID;
          L_TY_ATM_TXN_REC.TERM_ID        := NULL; --L_SWTB_SETTLEMENT.TERM_ID;
          L_TY_ATM_TXN_REC.ACCEPT_ID_CODE := NULL; --L_SWTB_SETTLEMENT.CARD_ACCPTOR_ID;

          L_TY_ATM_TXN_REC.RRN       := G.RRN; --L_SWTB_SETTLEMENT.RRN;
          L_TY_ATM_TXN_REC.AUTH_CODE := G.ISSUER_AUTH_CODE; --L_SWTB_SETTLEMENT.AUTH_CODE;

          L_TY_ATM_TXN_REC.RESP_CODE := NULL; --L_SWTB_SETTLEMENT.RESP_CODE;

          /* IF SUBSTR(L_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('20', '21') THEN
            L_TY_ATM_TXN_REC.TO_ACC         := L_SWTB_SETTLEMENT.ACC;
            L_TY_ATM_TXN_REC.TXN_CCY_MINOR  := NVL(L_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                   0);
            L_TY_ATM_TXN_REC.SETL_CCY_MINOR := NVL(L_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                                   0);
          ELSE
            L_TY_ATM_TXN_REC.FROM_ACC := L_SWTB_SETTLEMENT.ACC;
          END IF;

          IF L_SWTB_SETTLEMENT.PRE_AUTH_N_CHG_BCK IS NOT NULL THEN
            L_TY_ATM_TXN_REC.PRE_AUTH_N_CHG_BCK := L_SWTB_SETTLEMENT.PRE_AUTH_N_CHG_BCK;
            L_TY_ATM_TXN_REC.PRE_AUTH_SEQ_NO    := SUBSTR(L_TY_ATM_TXN_REC.PRE_AUTH_N_CHG_BCK,
                                                          7,
                                                          12);
            DBG('[Pre_Auth_N_Chg_Bck]=>' ||
                L_TY_ATM_TXN_REC.PRE_AUTH_N_CHG_BCK);
          END IF;

          BEGIN
            SELECT *
              INTO L_TY_ATM_TXN_REC.SWITCH_PARAM_FLG
              FROM SWTBS_PARAM
             WHERE CHANNEL = L_SWTB_SETTLEMENT.CHANNEL;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Exception while selecting data from swtbs_param');
              P_ERR_CODE := 'SW-PRM-01';
          END;*/

          L_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL := 'POS';

          IF NOT SWPKS_UTILS.FN_GET_PKEY(L_TY_ATM_TXN_REC,
                                         P_ERR_CODE,
                                         P_ERR_PARAM) THEN
            DBG(' swpks_utils.fn_get_pkey returned false ');
            P_ERR_CODE  := 'SW-KEY-01';
            P_ERR_PARAM := '~' || P_ERR_CODE;

            RAISE ERROR_EXCEPTION;
          END IF;

          SELECT COUNT(1)
            INTO L_COUNT
            FROM SWTB_TXN_LOG
           WHERE P_KEY = L_TY_ATM_TXN_REC.P_KEY;

          IF L_COUNT < 1 THEN

            DBG('Transaction was not processed online... doIt now!');

            IF NOT
                GWPKSS_CREATESWTRANSACTION.FN_DERIVE_NORMAL(L_TY_ATM_TXN_REC,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAM) THEN
              DBG(' fn_derive_normal returned false ');
              P_ERR_CODE  := 'SW-DRV-01';
              P_ERR_PARAM := '~' || P_ERR_CODE;

              RAISE ERROR_EXCEPTION;
            END IF;

            DBG('[From_Acc]=>' || L_TY_ATM_TXN_REC.FROM_ACC ||
                '   txn_acc_no_fcc  ' || L_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);

            IF L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE IS NULL THEN
              L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE := L_TY_ATM_TXN_REC.ACC_BRANCH_CODE;
            END IF;
            DBG('l_ty_atm_txn_rec.orig_branch_code=>' ||
                L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE);

            /*BEGIN
              SELECT ORIG_BRANCH
                INTO L_HOST_NAME
                FROM SWTBS_TERMID_BRANCH_MAPPING
               WHERE TERMID = L_TY_ATM_TXN_REC.TERM_ID;

              L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE := L_HOST_NAME;
              GLOBAL.PR_INIT(L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE,
                             L_TY_ATM_TXN_REC.USER_ID);

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
            END;
            DBG('l_ty_atm_txn_rec.orig_branch_code=>' ||
                L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE);*/

            IF NOT
                GWPKSS_CREATESWTRANSACTION.FN_CCY_TRANS(L_TY_ATM_TXN_REC.TXN_CCY_CODE,
                                                        L_TY_ATM_TXN_REC.TXN_CCY_FCC,
                                                        L_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                        L_TY_ATM_TXN_REC.RESP_CODE) THEN
              DEBUG.PR_DEBUG('E',
                             ' No proper translation avl for ccy type ' ||
                             L_TY_ATM_TXN_REC.TXN_CCY_CODE || '~' ||
                             L_TY_ATM_TXN_REC.TXN_CCY_FCC);
              P_ERR_CODE  := 'SW-CCY01';
              P_ERR_PARAM := '~' || P_ERR_CODE;

              RAISE ERROR_EXCEPTION;
            END IF;
            DBG('[Txn_Ccy_Code]=>' || L_TY_ATM_TXN_REC.TXN_CCY_CODE);
            DBG('[txn_ccy_fcc]=>' || L_TY_ATM_TXN_REC.TXN_CCY_FCC);

            IF L_TY_ATM_TXN_REC.SETL_AMT IS NOT NULL THEN
              IF L_TY_ATM_TXN_REC.SETL_CCY_CODE =
                 L_TY_ATM_TXN_REC.TXN_CCY_CODE THEN
                L_TY_ATM_TXN_REC.SETL_CCY_FCC := L_TY_ATM_TXN_REC.TXN_CCY_FCC;
              ELSE
                IF NOT
                    GWPKSS_CREATESWTRANSACTION.FN_CCY_TRANS(L_TY_ATM_TXN_REC.SETL_CCY_CODE,
                                                            L_TY_ATM_TXN_REC.SETL_CCY_FCC,
                                                            L_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                                            L_TY_ATM_TXN_REC.RESP_CODE) THEN
                  DBG('No proper translation avl for ccy type ' ||
                      L_TY_ATM_TXN_REC.SETL_CCY_CODE || '~' ||
                      L_TY_ATM_TXN_REC.SETL_CCY_FCC);
                  P_ERR_CODE  := 'SW-CCY01';
                  P_ERR_PARAM := '~' || P_ERR_CODE;

                  RAISE ERROR_EXCEPTION;
                END IF;
              END IF;
            END IF;

            IF L_TY_ATM_TXN_REC.BILL_AMT IS NOT NULL THEN
              IF L_TY_ATM_TXN_REC.BILL_CCY_CODE =
                 L_TY_ATM_TXN_REC.SETL_CCY_CODE THEN
                L_TY_ATM_TXN_REC.BILL_CCY_FCC := L_TY_ATM_TXN_REC.SETL_CCY_FCC;
              ELSE
                IF NOT
                    GWPKSS_CREATESWTRANSACTION.FN_CCY_TRANS(L_TY_ATM_TXN_REC.BILL_CCY_CODE,
                                                            L_TY_ATM_TXN_REC.BILL_CCY_FCC,
                                                            L_TY_ATM_TXN_REC.BILL_CCY_MINOR,
                                                            L_TY_ATM_TXN_REC.RESP_CODE) THEN
                  DBG(' No proper translation avl for ccy type ' ||
                      L_TY_ATM_TXN_REC.BILL_CCY_CODE || '~' ||
                      L_TY_ATM_TXN_REC.BILL_CCY_FCC || 'Y');
                  P_ERR_CODE  := 'SW-CCY01';
                  P_ERR_PARAM := '~' || P_ERR_CODE;

                  RAISE ERROR_EXCEPTION;
                END IF;
              END IF;
            END IF;

            IF L_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC IS NULL THEN
              L_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC := L_TY_ATM_TXN_REC.TXN_CCY_FCC;
            END IF;

            CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') := 'FLEXSWITCH';
            DBG('Cspks_Req_Global.g_Header source ' ||
                CSPKS_REQ_GLOBAL.G_HEADER('SOURCE'));

            IF NOT GWPKSS_CREATESWTRANSACTION.FN_PROCESS_REQ(L_TY_ATM_TXN_REC,
                                                             'N',
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
              DBG('gwpks_createswtransaction : fn_process_req returned false ');

              P_ERR_PARAM    := '~' || P_ERR_CODE;
              PROCESS_STATUS := 'E';
              RAISE ERROR_EXCEPTION;
            END IF;

            IF P_ERR_CODE = 'SW-DRV-01' THEN
              DBG('Transaction was alrady done online... Post the transation as Reversal-R ');
              /*UPDATE SWTBS_SETTLEMENT
                SET STATUS = 'R'
              WHERE MSG_TYPE = L_SWTB_SETTLEMENT.MSG_TYPE
                AND STAN = L_SWTB_SETTLEMENT.STAN
                AND RRN = L_SWTB_SETTLEMENT.RRN
                AND TERM_ID = L_SWTB_SETTLEMENT.TERM_ID;*/
            ELSIF PROCESS_STATUS = 'E' THEN
              DBG('Transaction is Unsuccussfull.. Post the transation as Failure-F  ');
              /* UPDATE SWTBS_SETTLEMENT
                SET STATUS    = 'F',
                    ERR_CODE  = P_ERR_CODE,
                    ERR_PARAM = P_ERR_PARAM
              WHERE MSG_TYPE = L_SWTB_SETTLEMENT.MSG_TYPE
                AND STAN = L_SWTB_SETTLEMENT.STAN
                AND RRN = L_SWTB_SETTLEMENT.RRN
                AND TERM_ID = L_SWTB_SETTLEMENT.TERM_ID;*/
            ELSE
              DBG('Transaction is Succussfull.. Post the transation as Success-S  ');
              /*UPDATE SWTBS_SETTLEMENT
                SET STATUS = 'S'
              WHERE MSG_TYPE = L_SWTB_SETTLEMENT.MSG_TYPE
                AND STAN = L_SWTB_SETTLEMENT.STAN
                AND RRN = L_SWTB_SETTLEMENT.RRN
                AND TERM_ID = L_SWTB_SETTLEMENT.TERM_ID;*/
            END IF;

            UPDATE SWTBS_TXN_LOG
               SET RECONSILED      = 'S',
                   WORK_PROGRESS   = 'C',
                   AMOUNT_BLOCK_NO = L_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO,
                   TRN_REF_NO      = L_TY_ATM_TXN_REC.TRN_REF_NO_FCC,
                   PURGE_DATE      = L_TY_ATM_TXN_REC.TXN_DT +
                                     L_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.BLOCK_EXP_DAYS,
                   FILE_PROCESS    = L_TY_ATM_TXN_REC.FILE_PROCESS
             WHERE P_KEY = L_TY_ATM_TXN_REC.P_KEY;
            DBG('l_ty_atm_txn_rec.trn_ref_no_fcc' ||
                L_TY_ATM_TXN_REC.TRN_REF_NO_FCC);
            DBG('l_ty_atm_txn_rec.p_key' || L_TY_ATM_TXN_REC.P_KEY);

          ELSE

            UPDATE SWTBS_TXN_LOG
               SET RECONSILED    = 'S',
                   WORK_PROGRESS = 'C',
                   FILE_PROCESS  = L_TY_ATM_TXN_REC.FILE_PROCESS
             WHERE P_KEY = L_TY_ATM_TXN_REC.P_KEY;

          END IF;
          DBG('SWTB_SETTLEMENT settlement Grand Success!!!');

          /*UPDATE SWTBS_SETTLEMENT
            SET STATUS    = 'S',
                ERR_CODE  = P_ERR_CODE,
                ERR_PARAM = P_ERR_PARAM
          WHERE MSG_TYPE = L_SWTB_SETTLEMENT.MSG_TYPE
            AND STAN = L_SWTB_SETTLEMENT.STAN
            AND RRN = L_SWTB_SETTLEMENT.RRN
            AND TERM_ID = L_SWTB_SETTLEMENT.TERM_ID;*/
          EXIT WHEN C1%NOTFOUND;

        EXCEPTION
          WHEN ERROR_EXCEPTION THEN
            DBG('Inside error exception 1 ' || SQLERRM);
            DBG('Transaction is Unsuccussfull.. Post the transation as Failure-F  ');
            UPDATE SWTBS_SETTLEMENT
               SET STATUS    = 'F',
                   ERR_CODE  = P_ERR_CODE,
                   ERR_PARAM = P_ERR_PARAM
             WHERE MSG_TYPE = L_TY_ATM_TXN_REC.MSG_TYPE
               AND STAN = L_TY_ATM_TXN_REC.STAN
               AND RRN = L_TY_ATM_TXN_REC.RRN
               AND TERM_ID = L_TY_ATM_TXN_REC.TERM_ID;

            DBG('l_swtb_settlement.msg_type' || L_TY_ATM_TXN_REC.MSG_TYPE);
            DBG('l_swtb_settlement.rrn' || L_TY_ATM_TXN_REC.RRN);

            CONTINUE;
        END;

      END LOOP;

      --RETURN TRUE;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN PR_PROCESS_AMT_UNBLOCK_OPER_ID');
        DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
        DBG('ERROR CODE=' || SQLCODE);
        DBG('ERROR MESSAGE=' || SQLERRM);

      /* UPDATE SWTBS_SETTLEMENT
        SET STATUS = 'F', ERR_CODE = P_ERR_CODE, ERR_PARAM = P_ERR_PARAM
      WHERE MSG_TYPE = L_SWTB_SETTLEMENT.MSG_TYPE
        AND STAN = L_SWTB_SETTLEMENT.STAN
        AND RRN = L_SWTB_SETTLEMENT.RRN
        AND TERM_ID = L_SWTB_SETTLEMENT.TERM_ID;*/
    END;

    COMMIT;

  END PR_PROCESS_AMT_UNBLOCK_OPER_ID;

  PROCEDURE PR_INIT_MSG IS
    FILE      VARCHAR2(32767);
    FILE_NAME VARCHAR2(100);
    FPATH     VARCHAR2(1000);
  BEGIN
    --global.pr_init('000', 'SYSTEM');
    --debug.pr_close;
    DBG('entered  ');
    g_cstb_params := FN_GET_PARAMS;
    DBG('Income path :' || g_cstb_params.PARAM_VAL);
    SELECT DIRECTORY_PATH
      INTO FPATH
      FROM DBA_DIRECTORIES
     WHERE DIRECTORY_NAME = g_cstb_params.PARAM_VAL;

    DBG('FPATH  - ' || FPATH);
    FILE_NAME := FN_READ_AUTO_DEBIT_FILE('/u01/fcubs/interfaces/Credit_Card_Payment/Incoming/ready');
    DBG('FILE_NAME  - ' || FILE_NAME);
    /*LOOP
     EXIT WHEN FILE IS NULL;
     P_FILE_NAME := SUBSTR(FILE, INSTR(FILE, ',', -1) + 1);
     DBG('FILE NAME IS: ' || P_FILE_NAME);

      --FOR G IN (SELECT * FROM )

      --P_FILE_NAME := 'DIRECT_DEBIT_REQ_'|| TO_CHAR(SYSDATE,'YYYYMMDD')||'_';


      --FILE := SUBSTR(FILE, 1, INSTR(FILE, ',', -1) - 1);
    END LOOP;*/
    PR_MOVE_FILE(FILE_NAME);
    DBG('Success  ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INIT_MSG ' || SQLERRM);
  END PR_INIT_MSG;

  PROCEDURE PR_MOVE_FILE(P_FILE_NAME IN VARCHAR2) IS
    L_XML XMLTYPE;
  BEGIN

    --GLOBAL.PR_INIT('002', 'SYSTEM');

    DBG('INSIDE PR_MOVE_FILE=' || P_FILE_NAME);

    IF P_FILE_NAME IS NOT NULL THEN
      UTL_FILE.FRENAME('CC_PAY_AUTO_DEBIT_READY',
                       P_FILE_NAME,
                       'CC_PAY_AUTO_DEBIT_WIP',
                       P_FILE_NAME,
                       TRUE);
      DBG('moved to wip');
      DBG('File name: ' || P_FILE_NAME);

      SELECT XMLTYPE(BFILENAME('CC_PAY_AUTO_DEBIT_WIP', P_FILE_NAME),
                     NLS_CHARSET_ID('AL32UTF16'))
        INTO L_XML
        FROM DUAL;

      --Handle Handoff
      PR_AMOUNT_UNBLOCK_INC_HANDOFF(L_XML, P_FILE_NAME);

      --Handle Process
      PR_PROCESS_AMT_UNBLOCK_OPER_ID;

      --Generate Outgoing Auto Debit Respnse xml file
      PR_GEN_AMTUNBLOCK_RESPONSE;

    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN WOT OF PR_MOVE_FILE=' || SQLERRM);
  END PR_MOVE_FILE;

  FUNCTION FN_GET_INST_ID(P_REQUEST_MSG IFTM_AUTO_DEBIT_PAYMENT_REQ.REQUEST_MSG%TYPE)
    RETURN VARCHAR2 IS
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_INST_ID          VARCHAR2(100);
  BEGIN

    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);

    L_INST_ID := P_DOCUMENT_XML.EXTRACT('/clearing/inst_id/text()')
                 .GETSTRINGVAL;

    DBG('L_INST_ID=' || L_INST_ID);

    RETURN L_INST_ID;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING FN_GET_INST_ID');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN L_INST_ID;
  END FN_GET_INST_ID;

  FUNCTION FN_GET_FILE_DATE(P_REQUEST_MSG IFTM_AUTO_DEBIT_PAYMENT_REQ.REQUEST_MSG%TYPE)
    RETURN DATE IS
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_FILE_DATE        VARCHAR2(100);
  BEGIN

    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);

    L_FILE_DATE := TO_DATE(P_DOCUMENT_XML.EXTRACT('/clearing/file_date/text()')
                           .GETSTRINGVAL,
                           'YYYY-MM-DD');
    DBG('L_FILE_DATE=' || L_FILE_DATE);
    RETURN L_FILE_DATE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING FN_GET_FILE_DATE');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN L_FILE_DATE;
  END FN_GET_FILE_DATE;

  FUNCTION FN_GET_FILE_ID(P_REQUEST_MSG IFTM_AUTO_DEBIT_PAYMENT_REQ.REQUEST_MSG%TYPE)
    RETURN VARCHAR2 IS
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_FILE_ID          VARCHAR2(100);
  BEGIN

    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);

    L_FILE_ID := P_DOCUMENT_XML.EXTRACT('/clearing/file_id/text()')
                 .GETSTRINGVAL;
    DBG('L_FILE_ID=' || L_FILE_ID);
    RETURN L_FILE_ID;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING FN_GET_FILE_NO');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN L_FILE_ID;
  END FN_GET_FILE_ID;

  PROCEDURE PR_AMOUNT_UNBLOCK_INC_HANDOFF(P_REQ_MSG   IN XMLTYPE,
                                          P_FILE_NAME IN VARCHAR2) IS

    L_RESPONSE         VARCHAR2(32767);
    L_SNIPPET          XMLTYPE;
    L_IX               BINARY_INTEGER;
    L_TEXT             CLOB;
    L_START            NUMBER := 1;
    L_END              NUMBER := 0;
    L_NO_OF_OPERATIONS NUMBER := 0;
    L_OPERATION        CLOB;
    L_INST_ID          VARCHAR2(100);
    L_FILE_DATE        DATE;
    L_FILE_ID          VARCHAR2(100);

    E_UPDATE_ERROR EXCEPTION;
    P_ERR_CODE     VARCHAR2(1000);
    P_ERR_PARAMS   VARCHAR2(1000);
    P_REQ_MSG_CLOB CLOB;

  BEGIN

    DBG('START OF PR_AMOUNT_UNBLOCK_INC_HANDOFF');

    P_REQ_MSG_CLOB := P_REQ_MSG.getClobVal();

    --DBG('P_REQ_MSG_CLOB=' || P_REQ_MSG_CLOB);

    L_INST_ID := FN_GET_INST_ID(P_REQ_MSG_CLOB);

    DBG('L_INST_ID=' || L_INST_ID);

    L_FILE_DATE := FN_GET_FILE_DATE(P_REQ_MSG_CLOB);

    DBG('L_FILE_DATE=' || L_FILE_DATE);

    L_FILE_ID := FN_GET_FILE_ID(P_REQ_MSG_CLOB);

    DBG('L_FILE_ID=' || L_FILE_ID);

    L_NO_OF_OPERATIONS := (LENGTH(P_REQ_MSG_CLOB) -
                          LENGTH(REPLACE(P_REQ_MSG_CLOB,
                                          '</operation>',
                                          ''))) / length('</operation>');

    DBG('L_NO_OF_OPERATIONS=' || L_NO_OF_OPERATIONS);

    FOR G IN 1 .. L_NO_OF_OPERATIONS LOOP

      DBG('G value=' || G);
      DBG('BEGIN L_START=' || L_START);
      DBG('BEGIN L_END=' || L_END);

      L_START := INSTR(P_REQ_MSG_CLOB, '<operation>', L_START, G);
      L_END   := INSTR(P_REQ_MSG_CLOB, '</operation>', L_START, 1);

      DBG('AFTER L_START=' || L_START);
      DBG('AFTER L_END=' || L_END);

      --DBMS_OUTPUT.PUT_LINE('FINAL SUB END=' || L_END - L_START + LENGTH('</payment_order>'));

      L_OPERATION := SUBSTR(P_REQ_MSG_CLOB,
                            L_START,
                            L_END - L_START + LENGTH('</operation>'));

      --DBMS_OUTPUT.PUT_LINE('L_PAY_ORDER=' || L_PAY_ORDER);

      PR_INSERT_AMT_UNBLOCK_TRACKER(L_INST_ID,
                                    L_FILE_DATE,
                                    L_FILE_ID,
                                    L_OPERATION,
                                    P_FILE_NAME);

      L_START := 1;

      DBG('-------------------');

    END LOOP;

    DBG('DONE WITH HANDOFF');

    -- RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      -- RETURN FALSE;
  END PR_AMOUNT_UNBLOCK_INC_HANDOFF;

  PROCEDURE PR_INSERT_AMT_UNBLOCK_TRACKER(P_INST_ID     IN VARCHAR2,
                                          P_FILE_DATE   IN VARCHAR2,
                                          P_FILE_ID     IN VARCHAR2,
                                          P_REQUEST_MSG IN IFTB_AMT_UNBLK_INCOMING_TRACK.REQUEST_MSG%TYPE,
                                          P_FILE_NAME   IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_COSMETIC_RES_MSG        CLOB;
    P_DOCUMENT_XML            XMLTYPE;
    L_OPER_ID                 IFTB_AMT_UNBLK_INCOMING_TRACK.OPER_ID%TYPE;
    L_RRN                     IFTB_AMT_UNBLK_INCOMING_TRACK.RRN%TYPE;
    L_OPER_DATE               IFTB_AMT_UNBLK_INCOMING_TRACK.OPER_DATE%TYPE;
    L_HOST_DATE               IFTB_AMT_UNBLK_INCOMING_TRACK.HOST_DATE%TYPE;
    L_OPER_AMOUNT             IFTB_AMT_UNBLK_INCOMING_TRACK.OPER_AMOUNT%TYPE;
    L_OPER_ISO_CCY_CODE       IFTB_AMT_UNBLK_INCOMING_TRACK.OPER_ISO_CCY_CODE%TYPE;
    L_OPER_CCY                IFTB_AMT_UNBLK_INCOMING_TRACK.OPER_CCY %TYPE;
    L_ORIGINATOR_REF_NUM      IFTB_AMT_UNBLK_INCOMING_TRACK.ORIGINATOR_REF_NUM%TYPE;
    L_ACQUIRER_BIN            IFTB_AMT_UNBLK_INCOMING_TRACK.ACQUIRER_BIN%TYPE;
    L_IS_REVERSAL             IFTB_AMT_UNBLK_INCOMING_TRACK.IS_REVERSAL%TYPE;
    L_ISSUER_CARD_NUMBER      IFTB_AMT_UNBLK_INCOMING_TRACK.ISSUER_CARD_NUMBER%TYPE;
    L_ISSUER_CARD_ISO_COUNTRY IFTB_AMT_UNBLK_INCOMING_TRACK.ISSUER_CARD_ISO_COUNTRY%TYPE;
    L_ISSUER_AUTH_CODE        IFTB_AMT_UNBLK_INCOMING_TRACK.ISSUER_AUTH_CODE%TYPE;
    L_ISSUER_ACCOUNT_NO       IFTB_AMT_UNBLK_INCOMING_TRACK.ISSUER_ACCOUNT_NO%TYPE;
    L_ISSUER_CIF_NO           IFTB_AMT_UNBLK_INCOMING_TRACK.ISSUER_CIF_NO%TYPE;
    L_SETTLEMENT_AMOUNT       IFTB_AMT_UNBLK_INCOMING_TRACK.SETTLEMENT_AMOUNT%TYPE;
    L_SETTLEMENT_ISO_CCY_CODE IFTB_AMT_UNBLK_INCOMING_TRACK.SETTLEMENT_ISO_CCY_CODE%TYPE;
    L_SETTLEMENT_CCY          IFTB_AMT_UNBLK_INCOMING_TRACK.SETTLEMENT_CCY%TYPE;
    L_SETTLEMENT_DATE         IFTB_AMT_UNBLK_INCOMING_TRACK.SETTLEMENT_DATE%TYPE;

    L_COUNT NUMBER;

  BEGIN

    DBG('BEFORE START OF PR_INSERT_AMT_UNBLOCK_TRACKER');

    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);

    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);

    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);

    --Main under operation starts
    L_OPER_ID := P_DOCUMENT_XML.EXTRACT('/operation/oper_id/text()')
                 .GETSTRINGVAL;

    DBG('L_OPER_ID=' || L_OPER_ID);

    L_OPER_DATE := TO_DATE(CAST(TO_TIMESTAMP(P_DOCUMENT_XML.EXTRACT('/operation/oper_date/text()')
                                             .GETSTRINGVAL,
                                             'YYYY-MM-DD"T"HH24:mi:ss') AS DATE),
                           'YYYY-MM-DD');

    DBG('L_OPER_DATE=' || L_OPER_DATE);

    L_HOST_DATE := TO_DATE(CAST(TO_TIMESTAMP(P_DOCUMENT_XML.EXTRACT('/operation/host_date/text()')
                                             .GETSTRINGVAL,
                                             'YYYY-MM-DD"T"HH24:mi:ss') AS DATE),
                           'YYYY-MM-DD');

    DBG('L_HOST_DATE=' || L_HOST_DATE);

    L_OPER_AMOUNT := (P_DOCUMENT_XML.EXTRACT('/operation/oper_amount/amount_value/text()')
                     .GETSTRINGVAL) / 100;

    DBG('L_OPER_AMOUNT=' || L_OPER_AMOUNT);

    L_OPER_ISO_CCY_CODE := P_DOCUMENT_XML.EXTRACT('/operation/oper_amount/currency/text()')
                           .GETSTRINGVAL;

    DBG('L_OPER_ISO_CCY_CODE=' || L_OPER_ISO_CCY_CODE);

    L_OPER_CCY := FN_GET_ISO_CURRENCY_CODE(L_OPER_ISO_CCY_CODE);

    DBG('L_OPER_CCY=' || L_OPER_CCY);

    L_ORIGINATOR_REF_NUM := P_DOCUMENT_XML.EXTRACT('/operation/originator_refnum/text()')
                            .GETSTRINGVAL;

    DBG('L_ORIGINATOR_REF_NUM=' || L_ORIGINATOR_REF_NUM);

    L_ACQUIRER_BIN := P_DOCUMENT_XML.EXTRACT('/operation/acq_inst_bin/text()')
                      .GETSTRINGVAL;

    DBG('L_ACQUIRER_BIN=' || L_ACQUIRER_BIN);

    L_IS_REVERSAL := P_DOCUMENT_XML.EXTRACT('/operation/is_reversal/text()')
                     .GETSTRINGVAL;

    DBG('L_IS_REVERSAL=' || L_IS_REVERSAL); --0 means not reversal and 1 means reversal

    L_SETTLEMENT_DATE := P_DOCUMENT_XML.EXTRACT('/operation/sttl_date/text()')
                         .GETSTRINGVAL;

    DBG('L_SETTLEMENT_DATE=' || L_SETTLEMENT_DATE);

    --Main under operation ends

    --Issuer Details Starts
    L_ISSUER_CARD_NUMBER := P_DOCUMENT_XML.EXTRACT('/operation/issuer/card_number/text()')
                            .GETSTRINGVAL;

    DBG('L_ISSUER_CARD_NUMBER=' || L_ISSUER_CARD_NUMBER);

    L_ISSUER_CARD_ISO_COUNTRY := P_DOCUMENT_XML.EXTRACT('/operation/issuer/card_country/text()')
                                 .GETSTRINGVAL;

    DBG('L_ISSUER_CARD_ISO_COUNTRY=' || L_ISSUER_CARD_ISO_COUNTRY);

    L_ISSUER_AUTH_CODE := P_DOCUMENT_XML.EXTRACT('/operation/issuer/auth_code/text()')
                          .GETSTRINGVAL;

    DBG('L_ISSUER_AUTH_CODE=' || L_ISSUER_AUTH_CODE);

    L_ISSUER_ACCOUNT_NO := P_DOCUMENT_XML.EXTRACT('/operation/issuer/account_number/text()')
                           .GETSTRINGVAL;

    DBG('L_ISSUER_ACCOUNT_NO=' || L_ISSUER_ACCOUNT_NO);

    L_ISSUER_CIF_NO := P_DOCUMENT_XML.EXTRACT('/operation/issuer/customer_number/text()')
                       .GETSTRINGVAL;

    DBG('L_ISSUER_CIF_NO=' || L_ISSUER_CIF_NO);
    --Issuer Details Ends

    --BaseII_Data Starts
    L_RRN := P_DOCUMENT_XML.EXTRACT('/operation/baseII_data/rrn/text()')
             .GETSTRINGVAL;

    DBG('L_RRN=' || L_RRN);

    L_SETTLEMENT_AMOUNT := (P_DOCUMENT_XML.EXTRACT('/operation/baseII_data/sttl_amount/text()')
                           .GETSTRINGVAL) / 100;

    DBG('L_SETTLEMENT_AMOUNT=' || L_SETTLEMENT_AMOUNT);

    L_SETTLEMENT_ISO_CCY_CODE := P_DOCUMENT_XML.EXTRACT('/operation/baseII_data/sttl_currency/text()')
                                 .GETSTRINGVAL;

    DBG('L_SETTLEMENT_ISO_CCY_CODE=' || L_SETTLEMENT_ISO_CCY_CODE);

    L_SETTLEMENT_CCY := FN_GET_ISO_CURRENCY_CODE(L_SETTLEMENT_ISO_CCY_CODE);

    DBG('L_SETTLEMENT_CCY=' || L_SETTLEMENT_CCY);
    --BaseII_Data Ends

    --Check if above ORDER ID already available
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
        FROM IFTB_AUTO_DEBIT_INCOMING_TRACK
       WHERE ORDER_ID = L_OPER_ID;
      -- AND STATUS = 'P';
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT := 0;
    END;

    IF L_COUNT = 0 THEN
      INSERT INTO IFTB_AMT_UNBLK_INCOMING_TRACK
        (OPER_ID,
         RRN,
         OPER_DATE,
         HOST_DATE,
         OPER_AMOUNT,
         OPER_ISO_CCY_CODE,
         OPER_CCY,
         ORIGINATOR_REF_NUM,
         ACQUIRER_BIN,
         IS_REVERSAL,
         ISSUER_CARD_NUMBER,
         ISSUER_CARD_ISO_COUNTRY,
         ISSUER_AUTH_CODE,
         ISSUER_ACCOUNT_NO,
         ISSUER_CIF_NO,
         SETTLEMENT_AMOUNT,
         SETTLEMENT_ISO_CCY_CODE,
         SETTLEMENT_CCY,
         SETTLEMENT_DATE,
         REQUEST_MSG,
         STATUS,
         TIME_IN,
         FILE_NAME)
      VALUES
        (L_OPER_ID,
         L_RRN,
         L_OPER_DATE,
         L_HOST_DATE,
         L_OPER_AMOUNT,
         L_OPER_ISO_CCY_CODE,
         L_OPER_CCY,
         L_ORIGINATOR_REF_NUM,
         L_ACQUIRER_BIN,
         L_IS_REVERSAL,
         L_ISSUER_CARD_NUMBER,
         L_ISSUER_CARD_ISO_COUNTRY,
         L_ISSUER_AUTH_CODE,
         L_ISSUER_ACCOUNT_NO,
         L_ISSUER_CIF_NO,
         L_SETTLEMENT_AMOUNT,
         L_SETTLEMENT_ISO_CCY_CODE,
         L_SETTLEMENT_CCY,
         L_SETTLEMENT_DATE,
         P_REQUEST_MSG,
         'U',
         SYSDATE,
         P_FILE_NAME);

      --Temp table
      INSERT INTO IFTB_AMTUNBLK_INC_TRACK
        (OPER_ID,
         RRN,
         OPER_DATE,
         HOST_DATE,
         OPER_AMOUNT,
         OPER_ISO_CCY_CODE,
         OPER_CCY,
         ORIGINATOR_REF_NUM,
         ACQUIRER_BIN,
         IS_REVERSAL,
         ISSUER_CARD_NUMBER,
         ISSUER_CARD_ISO_COUNTRY,
         ISSUER_AUTH_CODE,
         ISSUER_ACCOUNT_NO,
         ISSUER_CIF_NO,
         SETTLEMENT_AMOUNT,
         SETTLEMENT_ISO_CCY_CODE,
         SETTLEMENT_CCY,
         SETTLEMENT_DATE,
         REQUEST_MSG,
         STATUS,
         TIME_IN,
         FILE_NAME)
      VALUES
        (L_OPER_ID,
         L_RRN,
         L_OPER_DATE,
         L_HOST_DATE,
         L_OPER_AMOUNT,
         L_OPER_ISO_CCY_CODE,
         L_OPER_CCY,
         L_ORIGINATOR_REF_NUM,
         L_ACQUIRER_BIN,
         L_IS_REVERSAL,
         L_ISSUER_CARD_NUMBER,
         L_ISSUER_CARD_ISO_COUNTRY,
         L_ISSUER_AUTH_CODE,
         L_ISSUER_ACCOUNT_NO,
         L_ISSUER_CIF_NO,
         L_SETTLEMENT_AMOUNT,
         L_SETTLEMENT_ISO_CCY_CODE,
         L_SETTLEMENT_CCY,
         L_SETTLEMENT_DATE,
         P_REQUEST_MSG,
         'U',
         SYSDATE,
         P_FILE_NAME);

    END IF;

    DBG('AFTER INSERTING INTO PR_INSERT_AMOUNT_UNBLOCK_TRACKER');
    DBG('COMMITTING');
    COMMIT;
    DBG('RETURNING SUCCESSFULLY FROM PR_INSERT_AMT_UNBLOCK_TRACKER');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      DBG('FAILED IN PR_INSERT_AMT_UNBLOCK_TRACKER');

  END PR_INSERT_AMT_UNBLOCK_TRACKER;

  PROCEDURE PR_AMOUNT_UNBLOCK_UPLOAD(PARAMNAME  VARCHAR2,
                                     PARAMVALUE VARCHAR2) AS

  BEGIN

    GLOBAL.PR_INIT('001', 'SYSTEM');

    DBG('Inside PR_AMOUNT_UNBLOCK_UPLOAD');

    PR_INIT_MSG;
    DBG('Successful return from PR_AMOUNT_UNBLOCK_UPLOAD');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception during PR_AMOUNT_UNBLOCK_UPLOAD' || SQLERRM);
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
  END PR_AMOUNT_UNBLOCK_UPLOAD;

  PROCEDURE PR_PROCESS_AMOUNT_UNBLOCK(PARAMNAME  VARCHAR2,
                                      PARAMVALUE VARCHAR2) AS

  BEGIN

    --GLOBAL.PR_INIT('000', 'SYSTEM');

    PR_PROCESS_AMT_UNBLOCK_OPER_ID;

    DBG('SUCCESSFUL RETURN FROM PR_PROCESS_AMOUNT_UNBLOCK');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_AMOUNT_UNBLOCK');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
  END PR_PROCESS_AMOUNT_UNBLOCK;

END IFPKS_AMOUNT_UNBLOCK_UTILS;
