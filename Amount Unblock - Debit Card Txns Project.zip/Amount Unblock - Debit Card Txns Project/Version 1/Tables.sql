-- Create table
create table IFTB_AMT_UNBLK_INCOMING_TRACK
(
  oper_id                 VARCHAR2(16) not null,
  rrn                     VARCHAR2(12) not null,
  oper_date               DATE,
  host_date               DATE,
  oper_amount             NUMBER,
  oper_iso_ccy_code       NUMBER,
  oper_ccy                VARCHAR2(3),
  originator_ref_num      VARCHAR2(12),
  acquirer_bin            VARCHAR2(25),
  is_reversal             NUMBER,
  issuer_card_number      VARCHAR2(16),
  issuer_card_iso_country VARCHAR2(3),
  issuer_auth_code        VARCHAR2(25),
  issuer_account_no       VARCHAR2(25),
  issuer_cif_no           VARCHAR2(25),
  txn_amount              NUMBER,
  txn_iso_ccy_code        NUMBER,
  txn_ccy                 VARCHAR2(3),
  settlement_amount       NUMBER,
  settlement_iso_ccy_code NUMBER,
  settlement_ccy          VARCHAR2(3),
  settlement_date         DATE,
  request_msg             CLOB,
  status                  CHAR(1),
  time_in                 DATE,
  file_name               VARCHAR2(100)
)
/
alter table IFTB_AMT_UNBLK_INCOMING_TRACK add primary key (OPER_ID, RRN)
/
-- Create table
create table IFTB_AMTUNBLK_INC_TRACK
(
  oper_id                 VARCHAR2(16),
  rrn                     VARCHAR2(12),
  oper_date               DATE,
  host_date               DATE,
  oper_amount             NUMBER,
  oper_iso_ccy_code       NUMBER,
  oper_ccy                VARCHAR2(3),
  originator_ref_num      VARCHAR2(12),
  acquirer_bin            VARCHAR2(25),
  is_reversal             NUMBER,
  issuer_card_number      VARCHAR2(16),
  issuer_card_iso_country VARCHAR2(3),
  issuer_auth_code        VARCHAR2(25),
  issuer_account_no       VARCHAR2(25),
  issuer_cif_no           VARCHAR2(25),
  settlement_amount       NUMBER,
  settlement_iso_ccy_code NUMBER,
  settlement_ccy          VARCHAR2(3),
  settlement_date         DATE,
  request_msg             CLOB,
  status                  CHAR(1),
  time_in                 DATE,
  file_name               VARCHAR2(100)
)
/