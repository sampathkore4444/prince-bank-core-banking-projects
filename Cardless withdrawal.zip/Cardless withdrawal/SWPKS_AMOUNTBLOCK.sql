CREATE OR REPLACE

PACKAGE BODY swpks_amountblock AS

  G_ISO_CHARGE1 NUMBER;
  G_ISO_CHARGE2 NUMBER;

  FUNCTION FN_CALC_CHG(P_BRANCH   VARCHAR2,
                       P_CHG_CCY  IN VARCHAR2,
                       P_TXN_AMT  IN NUMBER,
                       P_CHG_DET  IN OUT GWPKS_CREATESWTRANSACTION.TYP_CHGDETS_REC,
                       P_INDEX    IN NUMBER,
                       P_ERR_CODE IN OUT VARCHAR2) RETURN BOOLEAN;

  G_SKIP_KERNEL  BOOLEAN := FALSE;
  G_SKIP_CLUSTER BOOLEAN := FALSE;
  G_SKIP_CUSTOM  BOOLEAN := FALSE;

  FUNCTION FN_SKIP_KERNEL RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_KERNEL;
    END IF;
  END FN_SKIP_KERNEL;

  FUNCTION FN_SKIP_CLUSTER RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CLUSTER THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CLUSTER;
    END IF;
  END FN_SKIP_CLUSTER;

  FUNCTION FN_SKIP_CUSTOM RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_KERNEL, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CUSTOM;
    END IF;
  END FN_SKIP_CUSTOM;

  PROCEDURE PR_SET_SKIP_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := TRUE;
  END PR_SET_SKIP_KERNEL;

  PROCEDURE PR_SET_ACTIVATE_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := FALSE;
  END PR_SET_ACTIVATE_KERNEL;

  PROCEDURE PR_SET_SKIP_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := TRUE;
  END PR_SET_SKIP_CLUSTER;

  PROCEDURE PR_SET_ACTIVATE_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := FALSE;
  END PR_SET_ACTIVATE_CLUSTER;

  PROCEDURE DBG(P_DBG IN VARCHAR2) IS
  BEGIN
  
    DEBUG.PR_DEBUG('SW', '[DEBUG]' || 'swpks_amountblock :' || P_DBG);
  END DBG;

  PROCEDURE DBG(P_DBG_IND IN VARCHAR2, P_DBG IN VARCHAR2) IS
  BEGIN
  
    IF P_DBG_IND = 'E' THEN
      DEBUG.PR_DEBUG('SW', '[ERROR] ' || 'swpks_amountblock :' || P_DBG);
    ELSE
      DEBUG.PR_DEBUG('SW', '[DEBUG] ' || 'swpks_amountblock :' || P_DBG);
    END IF;
  END DBG;

  FUNCTION FN_IS_GL(P_BRN IN VARCHAR2,
                    P_ACC IN VARCHAR2,
                    P_CCY OUT VARCHAR2) RETURN BOOLEAN IS
    L_STTB_ACCOUNT STTBS_ACCOUNT%ROWTYPE;
  BEGIN
    IF NOT CVPKS_UTILS.GET_STTB_ACC(P_BRN, P_ACC, L_STTB_ACCOUNT) THEN
      DBG('E', 'Checking for which G or A............');
      RETURN FALSE;
    END IF;
    IF L_STTB_ACCOUNT.AC_OR_GL = 'G' THEN
      RETURN TRUE;
    ELSE
      P_CCY := L_STTB_ACCOUNT.AC_GL_CCY;
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('E', 'FROM fn IS gl ' || SQLERRM);
      DBG('Err FOR ' || P_BRN || ' ' || P_ACC);
      P_CCY := NULL;
      RETURN FALSE;
  END FN_IS_GL;

  FUNCTION FN_MAPPING_ISO_TO_FCC(P_TY_ATM_TXN_REC IN OUT GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC
                                 
                                ,
                                 P_CADAMBLK IN OUT CAPKSS_CADAMBLK_MAIN.TY_CADAMBLK
                                 
                                ,
                                 P_AC_CCY    IN OUT VARCHAR2,
                                 P_ERR_CODE  IN OUT VARCHAR2,
                                 P_ERR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_BLK_AMOUNT NUMBER(22, 3);
    L_BLK_CCY    VARCHAR2(3);
    L_ACC_CCY    CYTM_CCY_DEFN.CCY_CODE%TYPE;
    L_ACC_AMT    NUMBER(22, 3);
  
    L_ACTUAL_COUNT   NUMBER := 0;
    L_ROW_FOUND      BOOLEAN := FALSE;
    L_ISO_CHARGE1    NUMBER;
    L_ISO_CHARGE2    NUMBER;
    L_CHG_CCY        VARCHAR2(3);
    L_CHG_AMT        NUMBER := 0;
    L_CHG_SUM        NUMBER := 0;
    PKG_STTB_ACCOUNT STTBS_ACCOUNT%ROWTYPE;
    L_REL_CUSTOMER   VARCHAR2(10);
    L_IB_FLAG        VARCHAR2(1);
  
    L_AMT NUMBER := 0;
  BEGIN
    DBG('Inside swpks_amountblock fn_mapping_iso_to_fcc');
  
    IF NOT SWPKS_AMOUNTBLOCK.FN_SKIP_CUSTOM THEN
      DBG('Calling swpks_amountblock_custom.fn_pre_mapping_iso_to_fcc..');
      IF NOT
          SWPKS_AMOUNTBLOCK_CUSTOM.FN_PRE_MAPPING_ISO_TO_FCC(P_TY_ATM_TXN_REC,
                                                             P_CADAMBLK,
                                                             P_AC_CCY,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
        DBG('Failed in swpks_amountblock_custom.fn_pre_mapping_iso_to_fcc..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT SWPKS_AMOUNTBLOCK.FN_SKIP_CLUSTER THEN
      DBG('Calling swpks_amountblock_cluster.fn_pre_mapping_iso_to_fcc.');
      IF NOT
          SWPKS_AMOUNTBLOCK_CLUSTER.FN_PRE_MAPPING_ISO_TO_FCC(P_TY_ATM_TXN_REC,
                                                              P_CADAMBLK,
                                                              P_AC_CCY,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAM) THEN
        DBG('Failed in swpks_amountblock_cluster.fn_pre_mapping_iso_to_fcc...');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT SWPKS_AMOUNTBLOCK.FN_SKIP_KERNEL THEN
    
      P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.ACCOUNT        := P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC;
      P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.EFFECTIVE_DATE := P_TY_ATM_TXN_REC.TXN_DT;
      P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.EXPIRY_DATE    := P_TY_ATM_TXN_REC.TXN_DT +
                                                         P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.BLOCK_EXP_DAYS;
    
      IF P_TY_ATM_TXN_REC.AMT_BLK_TYPE IS NOT NULL THEN
        P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.AMOUNT_BLOCK_TYPE := P_TY_ATM_TXN_REC.AMT_BLK_TYPE;
      ELSE
        P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.AMOUNT_BLOCK_TYPE := 'S';
      END IF;
    
      P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.REMARKS     := P_TY_ATM_TXN_REC.TXN_DESC;
      P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.MAKER_ID    := P_TY_ATM_TXN_REC.SOURCE;
      P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.AUTH_STAT   := 'U';
      P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.RECORD_STAT := 'O';
      P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.BRANCH      := P_TY_ATM_TXN_REC.ACC_BRANCH_CODE;
    
      DBG('p_ty_atm_txn_rec.SOURCE :' || P_TY_ATM_TXN_REC.SOURCE);
      DBG('p_ty_atm_txn_rec.orig_branch_code==>' ||
          P_TY_ATM_TXN_REC.ORIG_BRANCH_CODE);
      DBG('p_cadamblk.amblk_catms_amount_blocks.account==>' ||
          P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.ACCOUNT);
    
      IF P_TY_ATM_TXN_REC.TXN_FEE_AMT IS NOT NULL THEN
        P_TY_ATM_TXN_REC.TXN_FEE_AMT := SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                               2,
                                               8);
      END IF;
    
      IF P_TY_ATM_TXN_REC.SETL_FEE_AMT IS NOT NULL THEN
        P_TY_ATM_TXN_REC.SETL_FEE_AMT := SUBSTR(P_TY_ATM_TXN_REC.SETL_FEE_AMT,
                                                2,
                                                8);
      END IF;
    
      IF P_TY_ATM_TXN_REC.TXN_PROC_FEE IS NOT NULL THEN
        P_TY_ATM_TXN_REC.TXN_PROC_FEE := SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                2,
                                                8);
      END IF;
    
      IF P_TY_ATM_TXN_REC.SETL_PROC_FEE IS NOT NULL THEN
        P_TY_ATM_TXN_REC.SETL_PROC_FEE := SUBSTR(P_TY_ATM_TXN_REC.SETL_PROC_FEE,
                                                 2,
                                                 8);
      END IF;
    
      DBG('p_Ty_Atm_Txn_Rec.Txn_Fee_Amt==>' ||
          P_TY_ATM_TXN_REC.TXN_FEE_AMT);
      DBG('p_Ty_Atm_Txn_Rec.Setl_Fee_Am==>' ||
          P_TY_ATM_TXN_REC.SETL_FEE_AMT);
      DBG('p_Ty_Atm_Txn_Rec.Txn_Proc_Fee==>' ||
          P_TY_ATM_TXN_REC.TXN_PROC_FEE);
      DBG('p_Ty_Atm_Txn_Rec.Setl_Proc_Fee==>' ||
          P_TY_ATM_TXN_REC.SETL_PROC_FEE);
    
      IF NOT
          GWPKSS_CREATESWTRANSACTION.FN_AMT_CHG_DERIVE_NEW(P_TY_ATM_TXN_REC,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN
        DBG('E',
            'Failed while calling gwpkss_createswtransaction.fn_amt_chg_derive' ||
            P_ERR_CODE);
        RETURN FALSE;
      END IF;
    
      DBG('p_ty_atm_txn_rec.txn_fee_amt-->' ||
          P_TY_ATM_TXN_REC.TXN_FEE_AMT);
    
      IF NOT GWPKSS_CREATESWTRANSACTION.FN_PRODUCT_DERIVE(P_TY_ATM_TXN_REC,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAM) THEN
        DBG('E',
            'Failed while calling Gwpks_CreateSWTransaction.fn_product_derive' ||
            P_ERR_CODE);
        RETURN FALSE;
      END IF;
      DBG('Before Getting Charge Details');
      DBG('Before Getting Charge Details  Charge 1------>' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1)
          .CHG_AMT);
      L_ISO_CHARGE1 := NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT, 0);
      G_ISO_CHARGE1 := NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT, 0);
      DBG('Before Getting Charge Details  Charge 2------>' || P_TY_ATM_TXN_REC.TBL_CHGDETS(2)
          .CHG_AMT);
      L_ISO_CHARGE2 := NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0);
      G_ISO_CHARGE2 := NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0);
    
      IF NOT FN_IS_GL(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                      P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                      L_ACC_CCY) THEN
        DBG('l_acc_ccy' || L_ACC_CCY);
        IF NVL(P_TY_ATM_TXN_REC.SETL_AMT, 0) <= 0 AND
           P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'R' THEN
          L_BLK_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED;
          L_CHG_CCY    := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
        
        ELSIF P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NULL AND
              P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NOT NULL AND
              P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'O' THEN
          L_BLK_AMOUNT := P_TY_ATM_TXN_REC.SETL_AMT_DERIVED;
          L_CHG_CCY    := P_TY_ATM_TXN_REC.SETL_CCY_DERIVED;
        
        ELSIF P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NOT NULL AND
              P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NOT NULL AND
              P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'F' THEN
          L_BLK_AMOUNT := P_TY_ATM_TXN_REC.BILL_AMT_DERIVED;
          L_CHG_CCY    := P_TY_ATM_TXN_REC.BILL_CCY_DERIVED;
        
        ELSIF P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NOT NULL AND
              P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NOT NULL AND
              P_TY_ATM_TXN_REC.OFFUS_ONUS = 'F' THEN
          L_BLK_AMOUNT := P_TY_ATM_TXN_REC.SETL_AMT_DERIVED;
          L_CHG_CCY    := P_TY_ATM_TXN_REC.SETL_CCY_DERIVED;
        
        ELSE
          L_BLK_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED;
          L_CHG_CCY    := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
        END IF;
      ELSE
        L_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
      END IF;
    
      DBG('l_Chg_Ccy---' || L_CHG_CCY);
    
      BEGIN
        DBG('Inside get chgdets');
      
        DBG('Get default_relcustomer');
        DBG('p_Ty_Atm_Txn_Rec.txn_acc----> ' ||
            P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);
        DBG('p_Ty_Atm_Txn_Rec.Acc_Branch_Code----> ' ||
            P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
      
        IF P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC IS NOT NULL THEN
          DBG('Transaction acc is not null');
          IF NOT CVPKS_UTILS.GET_STTB_ACC(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                          P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                                          PKG_STTB_ACCOUNT) THEN
            P_ERR_CODE := 'DE-TUD-055';
          
            RETURN FALSE;
          END IF;
          DBG('l_Rel_Customer--->' || PKG_STTB_ACCOUNT.CUST_NO);
        
          IF PKG_STTB_ACCOUNT.AC_OR_GL = 'A' THEN
            L_REL_CUSTOMER := PKG_STTB_ACCOUNT.CUST_NO;
          END IF;
        
        END IF;
      
        DBG('checking the values 1 account branch code---' ||
            P_TY_ATM_TXN_REC.ACC_BRANCH_CODE ||
            '---values for originating brn' ||
            P_TY_ATM_TXN_REC.ORIG_BRANCH_CODE);
        IF P_TY_ATM_TXN_REC.ACC_BRANCH_CODE <>
           P_TY_ATM_TXN_REC.ORIG_BRANCH_CODE THEN
          L_IB_FLAG := 'Y';
        ELSE
          L_IB_FLAG := 'N';
        END IF;
      
        CSPKSS_ARC.PR_GET_ARC_ROW(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                  P_TY_ATM_TXN_REC.PRODUCT_CODE,
                                  'P',
                                  L_REL_CUSTOMER,
                                  P_TY_ATM_TXN_REC.TXN_CCY_DERIVED,
                                  L_IB_FLAG,
                                  PKG_ARC_ROW,
                                  P_ERR_CODE,
                                  P_ERR_PARAM,
                                  P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                                  P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
        IF P_ERR_CODE IS NOT NULL THEN
          P_ERR_CODE := NULL;
        
          IF L_IB_FLAG = 'N' THEN
            L_IB_FLAG := 'Y';
          ELSE
            L_IB_FLAG := 'N';
          END IF;
        
          CSPKSS_ARC.PR_GET_ARC_ROW(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                    P_TY_ATM_TXN_REC.PRODUCT_CODE,
                                    'P',
                                    '*.*',
                                    P_TY_ATM_TXN_REC.TXN_CCY_DERIVED,
                                    L_IB_FLAG,
                                    PKG_ARC_ROW,
                                    P_ERR_CODE,
                                    P_ERR_PARAM,
                                    P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                                    P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
        
        END IF;
      
        IF P_ERR_CODE IS NOT NULL THEN
          DBG('Failed while fetching arc details....');
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
        
          RETURN FALSE;
        END IF;
      
        IF NOT
            CSPKSS_ARC.FN_CHARGE_PICKUP(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                        P_TY_ATM_TXN_REC.PRODUCT_CODE,
                                        'P',
                                        P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                        L_CHG_CCY,
                                        L_REL_CUSTOMER,
                                        L_CHG_CCY,
                                        L_BLK_AMOUNT,
                                        'STANDARD',
                                        'M',
                                        NULL,
                                        L_REL_CUSTOMER,
                                        L_IB_FLAG,
                                        PKG_ARC_ROW,
                                        P_ERR_CODE,
                                        P_ERR_PARAM,
                                        P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                                        P_TY_ATM_TXN_REC.ACC_BRANCH_CODE) THEN
          RETURN FALSE;
        END IF;
      
        FOR L_ROW IN 1 .. 5 LOOP
          IF L_ROW = 1 AND PKG_ARC_ROW.COD_CHG_DESC IS NOT NULL THEN
            DBG('Actual row = ' || L_ROW || ' found.');
            L_ACTUAL_COUNT := L_ACTUAL_COUNT + 1;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).COD_CHG_DESC := PKG_ARC_ROW.COD_CHG_DESC;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_AMT := PKG_ARC_ROW.COD_CHG_AMT;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).MIS_HEAD := PKG_ARC_ROW.COD_MIS_HEAD1;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).COD_CHG_CCY := PKG_ARC_ROW.COD_CHG_CCY;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_GL := PKG_ARC_ROW.COD_CHG_GL;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).TXN_CODE := PKG_ARC_ROW.COD_CHG_TXN_CODE;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).NETTING_IND := PKG_ARC_ROW.COD_CHG_NETTING;
          
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE := PKG_ARC_ROW.COD_CHG_RATE;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_TYPE := PKG_ARC_ROW.COD_CHG_TYPE;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_BASIS := PKG_ARC_ROW.COD_BASIS;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_CODE := PKG_ARC_ROW.COD_RATE_CODE;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_CODE_TYPE := PKG_ARC_ROW.COD_RATE_CODE_TYPE;
          
          ELSIF L_ROW = 2 AND PKG_ARC_ROW.COD_CHG_DESC1 IS NOT NULL THEN
            DBG('Actual row = ' || L_ROW || ' found.');
            L_ACTUAL_COUNT := L_ACTUAL_COUNT + 1;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).COD_CHG_DESC := PKG_ARC_ROW.COD_CHG_DESC1;
			
			IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL <> 'DMC' THEN
            --sampath for cardless withdrawal
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_AMT := PKG_ARC_ROW.COD_CHG_AMT1;
			ELSE
            --sampath for cardless withdrawal
          
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                            1,
                                                                            LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) - 2) || '.' ||
                                                                     SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                            LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) + 1 - 2,
                                                                            2));
            /*TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                   1,
                   LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) -
                   P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
            SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                   LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) + 1 -
                   P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                   P_TY_ATM_TXN_REC.TXN_CCY_MINOR));*/
          
          END IF; --sampath for cardless withdrawal
		  
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).MIS_HEAD := PKG_ARC_ROW.COD_MIS_HEAD2;
			
			IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL = 'DMC' THEN
            
			--sampath for cardless withdrawal
            
			P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_PROC_FEE_CCY_FCC;
            
			ELSE
            --sampath for cardless withdrawal
			
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).COD_CHG_CCY := PKG_ARC_ROW.COD_CHG_CCY1;
			
			END IF; --sampath for cardless withdrawal
			
			
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_GL := PKG_ARC_ROW.COD_CHG_GL1;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).TXN_CODE := PKG_ARC_ROW.COD_CHG_TXN_CODE1;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).NETTING_IND := PKG_ARC_ROW.COD_CHG_NETTING1;
          
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE := PKG_ARC_ROW.COD_CHG_RATE1;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_TYPE := PKG_ARC_ROW.COD_CHG_TYPE1;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_BASIS := PKG_ARC_ROW.COD_BASIS1;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_CODE := PKG_ARC_ROW.COD_RATE_CODE1;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_CODE_TYPE := PKG_ARC_ROW.COD_RATE_CODE_TYPE1;
          
          ELSIF L_ROW = 3 AND PKG_ARC_ROW.COD_CHG_DESC2 IS NOT NULL THEN
            DBG('Actual row = ' || L_ROW || ' found.');
            L_ACTUAL_COUNT := L_ACTUAL_COUNT + 1;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).COD_CHG_DESC := PKG_ARC_ROW.COD_CHG_DESC2;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_AMT := PKG_ARC_ROW.COD_CHG_AMT2;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).MIS_HEAD := PKG_ARC_ROW.COD_MIS_HEAD3;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).COD_CHG_CCY := PKG_ARC_ROW.COD_CHG_CCY2;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_GL := PKG_ARC_ROW.COD_CHG_GL2;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).TXN_CODE := PKG_ARC_ROW.COD_CHG_TXN_CODE2;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).NETTING_IND := PKG_ARC_ROW.COD_CHG_NETTING2;
          
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE := PKG_ARC_ROW.COD_CHG_RATE2;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_TYPE := PKG_ARC_ROW.COD_CHG_TYPE2;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_BASIS := PKG_ARC_ROW.COD_BASIS2;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_CODE := PKG_ARC_ROW.COD_RATE_CODE2;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_CODE_TYPE := PKG_ARC_ROW.COD_RATE_CODE_TYPE2;
          
            DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets(l_row).chg_amt ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW)
                .CHG_AMT);
          
            IF NOT FN_CALC_CHG(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                               L_CHG_CCY,
                               L_BLK_AMOUNT,
                               P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW),
                               L_ROW,
                               P_ERR_CODE) THEN
              DBG('Failed in Getting Charges for charge component ' ||
                  L_ROW);
            ELSE
              L_AMT := P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_AMT;
            
              IF NVL(L_AMT, 0) < NVL(PKG_ARC_ROW.COD_MIN_CHG2, 0) THEN
                L_AMT := NVL(PKG_ARC_ROW.COD_MIN_CHG2, 0);
              ELSIF NVL(L_AMT, 0) >
                    NVL(PKG_ARC_ROW.COD_MAX_CHG2, POWER(10, 38)) THEN
                L_AMT := PKG_ARC_ROW.COD_MAX_CHG2;
              END IF;
              P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_AMT := L_AMT;
              DBG('Final Charge Calculated as  ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW)
                  .CHG_AMT);
            END IF;
          
          ELSIF L_ROW = 4 AND PKG_ARC_ROW.COD_CHG_DESC3 IS NOT NULL THEN
            DBG('Actual row = ' || L_ROW || ' found.');
            L_ACTUAL_COUNT := L_ACTUAL_COUNT + 1;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).COD_CHG_DESC := PKG_ARC_ROW.COD_CHG_DESC3;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_AMT := PKG_ARC_ROW.COD_CHG_AMT3;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).MIS_HEAD := PKG_ARC_ROW.COD_MIS_HEAD4;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).COD_CHG_CCY := PKG_ARC_ROW.COD_CHG_CCY3;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_GL := PKG_ARC_ROW.COD_CHG_GL3;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).TXN_CODE := PKG_ARC_ROW.COD_CHG_TXN_CODE3;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).NETTING_IND := PKG_ARC_ROW.COD_CHG_NETTING3;
          
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE := PKG_ARC_ROW.COD_CHG_RATE3;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_TYPE := PKG_ARC_ROW.COD_CHG_TYPE3;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_BASIS := PKG_ARC_ROW.COD_BASIS3;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_CODE := PKG_ARC_ROW.COD_RATE_CODE3;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_CODE_TYPE := PKG_ARC_ROW.COD_RATE_CODE_TYPE3;
          
            IF NOT FN_CALC_CHG(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                               L_CHG_CCY,
                               L_BLK_AMOUNT,
                               P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW),
                               L_ROW,
                               P_ERR_CODE) THEN
              DBG('Failed in Getting Charges for charge component ' ||
                  L_ROW);
            ELSE
              L_AMT := P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_AMT;
            
              IF NVL(L_AMT, 0) < NVL(PKG_ARC_ROW.COD_MIN_CHG3, 0) THEN
                L_AMT := NVL(PKG_ARC_ROW.COD_MIN_CHG3, 0);
              ELSIF NVL(L_AMT, 0) >
                    NVL(PKG_ARC_ROW.COD_MAX_CHG3, POWER(10, 38)) THEN
                L_AMT := PKG_ARC_ROW.COD_MAX_CHG3;
              END IF;
              P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_AMT := L_AMT;
              DBG('Final Charge Calculated as  ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW)
                  .CHG_AMT);
            END IF;
          
          ELSIF L_ROW = 5 AND PKG_ARC_ROW.COD_CHG_DESC4 IS NOT NULL THEN
            DBG('Actual row = ' || L_ROW || ' found.');
            L_ACTUAL_COUNT := L_ACTUAL_COUNT + 1;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).COD_CHG_DESC := PKG_ARC_ROW.COD_CHG_DESC4;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_AMT := PKG_ARC_ROW.COD_CHG_AMT4;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).MIS_HEAD := PKG_ARC_ROW.COD_MIS_HEAD5;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).COD_CHG_CCY := PKG_ARC_ROW.COD_CHG_CCY4;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_GL := PKG_ARC_ROW.COD_CHG_GL4;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).TXN_CODE := PKG_ARC_ROW.COD_CHG_TXN_CODE4;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).NETTING_IND := PKG_ARC_ROW.COD_CHG_NETTING4;
          
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE := PKG_ARC_ROW.COD_CHG_RATE4;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_TYPE := PKG_ARC_ROW.COD_CHG_TYPE4;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_BASIS := PKG_ARC_ROW.COD_BASIS4;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_CODE := PKG_ARC_ROW.COD_RATE_CODE4;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_RATE_CODE_TYPE := PKG_ARC_ROW.COD_RATE_CODE_TYPE4;
          
            IF NOT FN_CALC_CHG(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                               L_CHG_CCY,
                               L_BLK_AMOUNT,
                               P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW),
                               L_ROW,
                               P_ERR_CODE) THEN
              DBG('Failed in Getting Charges for charge component ' ||
                  L_ROW);
            ELSE
              L_AMT := P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_AMT;
              IF NVL(L_AMT, 0) < NVL(PKG_ARC_ROW.COD_MIN_CHG4, 0) THEN
                L_AMT := NVL(PKG_ARC_ROW.COD_MIN_CHG4, 0);
              ELSIF NVL(L_AMT, 0) >
                    NVL(PKG_ARC_ROW.COD_MAX_CHG4, POWER(10, 38)) THEN
                L_AMT := PKG_ARC_ROW.COD_MAX_CHG4;
              END IF;
              P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).CHG_AMT := L_AMT;
              DBG('Final Charge Calculated as  ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW)
                  .CHG_AMT);
            END IF;
          
          END IF;
          IF L_ACTUAL_COUNT = L_ROW THEN
            DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets(' || L_ACTUAL_COUNT ||
                ').mis_head..... : ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ACTUAL_COUNT)
                .MIS_HEAD);
            DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets(' || L_ACTUAL_COUNT ||
                ').waiver....... : ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ACTUAL_COUNT)
                .WAIVER);
            DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets(' || L_ACTUAL_COUNT ||
                ').chg_amt...... : ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ACTUAL_COUNT)
                .CHG_AMT);
            DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets(' || L_ACTUAL_COUNT ||
                ').chg_ccy...... : ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ACTUAL_COUNT)
                .COD_CHG_CCY);
            DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets(' || L_ACTUAL_COUNT ||
                ').txn_code..... : ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ACTUAL_COUNT)
                .TXN_CODE);
            DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets(' || L_ACTUAL_COUNT ||
                ').chg_gl....... : ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ACTUAL_COUNT)
                .CHG_GL);
            DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets(' || L_ACTUAL_COUNT ||
                ').netting_ind.. : ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ACTUAL_COUNT)
                .NETTING_IND);
          END IF;
        
          IF P_TY_ATM_TXN_REC.TBL_CHGDETS.EXISTS(L_ROW) THEN
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW).WAIVER := NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(L_ROW)
                                                              .WAIVER,
                                                              'N');
          END IF;
        
        END LOOP;
      
        DBG('Total No of actual charges defined : ' || L_ACTUAL_COUNT);
        DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets.COUNT : ' ||
            P_TY_ATM_TXN_REC.TBL_CHGDETS.COUNT);
      
        FOR L_PROW IN 1 .. P_TY_ATM_TXN_REC.TBL_CHGDETS.COUNT LOOP
        
          L_ROW_FOUND := TRUE;
        
          IF NOT L_ROW_FOUND THEN
          
            DBG('E',
                'Wrong Charge component received : ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
                .COD_CHG_DESC);
            OVPKSS.PR_APPENDTBL('GW-RTL-009',
                                NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
                                    .COD_CHG_DESC,
                                    'Nill') || '~');
            RETURN FALSE;
          END IF;
          DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets(' || L_PROW || ').chg_amt  : ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
              .CHG_AMT);
          DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets(' || L_PROW ||
              ').cod_chg_ccy  : ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
              .COD_CHG_CCY);
			  
          IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL = 'DMC' THEN
          --sampath for cardless withdrawal
        
          IF P_TY_ATM_TXN_REC.txn_ccy_fcc /*P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
                       .COD_CHG_CCY*/
             <> P_TY_ATM_TXN_REC.TXN_PROC_FEE_CCY_FCC THEN
            DBG('Go for Exchange Rate for charge ');
            L_CHG_AMT                       := 0;
            P_TY_ATM_TXN_REC.X_RATE_DERIVED := NULL;
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                          P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
                                          .COD_CHG_CCY,
                                          P_TY_ATM_TXN_REC.txn_ccy_fcc,
                                          
                                          'COMM',--'STANDARD',
                                          'S'--'M'
                                          
                                         ,
                                          P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
                                          .CHG_AMT,
                                          
                                          'Y',
                                          L_CHG_AMT,
                                          P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                          P_ERR_CODE) THEN
              P_ERR_CODE  := 'SW-AMT-01';
              P_ERR_PARAM := '~' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
                            .COD_CHG_CCY || '~' || L_CHG_CCY;
              DBG('E',
                  'fn_amount_derive : Calling cypks.fn_amt1_to_amt2 failed ' ||
                  P_ERR_CODE || '~' || P_ERR_PARAM);
              RETURN FALSE;
            END IF;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW).CHG_AMT := L_CHG_AMT;
            DBG('After Conversion ---p_Ty_Atm_Txn_Rec.Tbl_Chgdets(' ||
                L_PROW || ').chg_amt  : ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
                .CHG_AMT);
          
          END IF;
        
        ELSE
          --sampath for cardless withdrawal
          IF P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW).COD_CHG_CCY <> L_CHG_CCY THEN
            DBG('Go for Exchange Rate ');
            L_CHG_AMT                       := 0;
            P_TY_ATM_TXN_REC.X_RATE_DERIVED := NULL;
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                          P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
                                          .COD_CHG_CCY,
                                          L_CHG_CCY,
                                          
                                          'STANDARD',
                                          'M'
                                          
                                         ,
                                          P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
                                          .CHG_AMT,
                                          
                                          'Y',
                                          L_CHG_AMT,
                                          P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                          P_ERR_CODE) THEN
              P_ERR_CODE  := 'SW-AMT-01';
              P_ERR_PARAM := '~' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
                            .COD_CHG_CCY || '~' || L_CHG_CCY;
              DBG('E',
                  'fn_amount_derive : Calling cypks.fn_amt1_to_amt2 failed ' ||
                  P_ERR_CODE || '~' || P_ERR_PARAM);
              RETURN FALSE;
            END IF;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW).CHG_AMT := L_CHG_AMT;
            DBG('After Conversion ---p_Ty_Atm_Txn_Rec.Tbl_Chgdets(' ||
                L_PROW || ').chg_amt  : ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW)
                .CHG_AMT);
          
          END IF;
		  END IF; --sampath for cardless withdrawal
          L_CHG_SUM := L_CHG_SUM +
                       NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(L_PROW).CHG_AMT, 0);
        
        END LOOP;
      
        DBG('Successfully finished Getting Charge Details');
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Exception caught in getting chgdets with : ' || SQLCODE || ':' ||
              SQLERRM);
          OVPKSS.PR_APPENDTBL('GW-RTL-003', NULL);
        
          RETURN FALSE;
      END;
      L_CHG_SUM := L_CHG_SUM -
                   NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT, 0) -
                   NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0);
      P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := L_ISO_CHARGE1;
	  
	  --sampath for cardless withdrawal starts
    IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL = 'DMC' AND
       P_TY_ATM_TXN_REC.txn_ccy_fcc <>
       P_TY_ATM_TXN_REC.TXN_PROC_FEE_CCY_FCC THEN
      P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT;
    ELSE
      --sampath for cardless withdrawal ends
      P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := L_ISO_CHARGE2;
	
	END IF; --sampath for cardless withdrawal 
	
      DBG('Sum Of Charges' || L_CHG_SUM);
    
    DBG('P_TY_ATM_TXN_REC.TXN_AMT_DERIVED=' ||
        P_TY_ATM_TXN_REC.TXN_AMT_DERIVED);
    DBG('P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT=' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1)
        .CHG_AMT);
    DBG('P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT=' || P_TY_ATM_TXN_REC.TBL_CHGDETS(2)
        .CHG_AMT);
      IF P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NULL AND
         P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NULL THEN
        DBG('Only TXN-AMT Present.Both BIL-AMT and SETL-AMT is NULL');
      
        L_BLK_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED +
                        NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT, 0) +
                        NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0) +
                        L_CHG_SUM;
        L_BLK_CCY    := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
        DBG('l_blk_amount' || L_BLK_AMOUNT);
      
      ELSIF P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NULL AND
            P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NOT NULL AND
            P_TY_ATM_TXN_REC.TXN_AMT_DERIVED IS NOT NULL THEN
        DBG('TXN-AMT and SETL-AMT Present.(BIL-AMT is NULL)');
      
        DBG('ONUS AMount Block' || L_BLK_AMOUNT);
      
        IF P_TY_ATM_TXN_REC.OFFUS_ONUS IN ('R', 'O') THEN
        
          IF NOT
             
              FN_IS_GL(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                       P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.ACCOUNT,
                       L_ACC_CCY)
          
           THEN
          
            IF NVL(P_TY_ATM_TXN_REC.SETL_AMT, 0) <= 0 THEN
            
              L_BLK_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED +
                              NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT,
                                  0) +
                              NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT,
                                  0) + L_CHG_SUM;
            
              L_BLK_CCY := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
            
            ELSE
            
              L_BLK_AMOUNT := P_TY_ATM_TXN_REC.SETL_AMT_DERIVED +
                              NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT,
                                  0) +
                              NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT,
                                  0) + L_CHG_SUM;
            
              L_BLK_CCY := P_TY_ATM_TXN_REC.SETL_CCY_DERIVED;
            
            END IF;
          END IF;
        
        ELSIF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'F' THEN
          DBG('Off-Us');
        
          L_BLK_AMOUNT := P_TY_ATM_TXN_REC.SETL_AMT_DERIVED +
                          NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT, 0) +
                          NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0) +
                          L_CHG_SUM;
        
          L_BLK_CCY := P_TY_ATM_TXN_REC.SETL_CCY_DERIVED;
        END IF;
      
      ELSIF P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NULL AND
            P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NOT NULL AND
            P_TY_ATM_TXN_REC.TXN_AMT_DERIVED IS NOT NULL THEN
        DBG('TXN-AMT and BIL-AMT Present.(SETL-AMT is NULL)');
      
        IF NOT FN_IS_GL(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                        P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.ACCOUNT,
                        L_ACC_CCY) THEN
        
        DBG('NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0)=' ||
            NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0));
      
        IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL = 'DMC' AND
           p_ty_atm_txn_rec.msg_type = '1100' THEN
          --sampath for cardless withdrawal starts
        
          P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                      1,
                                                                      LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) -
                                                                      P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                               SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                      LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) + 1 -
                                                                      P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                      P_TY_ATM_TXN_REC.TXN_CCY_MINOR));
        
          DBG('P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT step1=' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1)
              .CHG_AMT);
        
          P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                      1,
                                                                      LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) -
                                                                      P_TY_ATM_TXN_REC.BILL_CCY_MINOR) || '.' ||
                                                               SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                      LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) + 1 -
                                                                      P_TY_ATM_TXN_REC.BILL_CCY_MINOR,
                                                                      P_TY_ATM_TXN_REC.BILL_CCY_MINOR));
        
          DBG('P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT step1=' || P_TY_ATM_TXN_REC.TBL_CHGDETS(2)
              .CHG_AMT);
        
          L_BLK_AMOUNT := P_TY_ATM_TXN_REC.BILL_AMT_DERIVED +
                          NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT, 0) +
                          NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0) +
                          L_CHG_SUM;
        
          L_BLK_CCY := P_TY_ATM_TXN_REC.BILL_CCY_DERIVED;
        
        ELSE
          --sampath for cardless withdrawal added else 
          L_BLK_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED +
                          NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT, 0) +
                          NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0) +
                          L_CHG_SUM;
        
          L_BLK_CCY := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
        
        END IF; --sampath for cardless withdrawal ends
        END IF;
      
      ELSIF P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NOT NULL AND
            P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NOT NULL AND
            P_TY_ATM_TXN_REC.TXN_AMT_DERIVED IS NULL THEN
        IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'O' THEN
        
          L_BLK_AMOUNT := P_TY_ATM_TXN_REC.BILL_AMT_DERIVED +
                          NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT, 0) +
                          NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0) +
                          L_CHG_SUM;
          L_BLK_CCY    := P_TY_ATM_TXN_REC.BILL_CCY_DERIVED;
        
        ELSIF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'R' THEN
        
          L_BLK_AMOUNT := P_TY_ATM_TXN_REC.BILL_AMT_DERIVED +
                          NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT, 0) +
                          NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0) +
                          L_CHG_SUM;
          L_BLK_CCY    := P_TY_ATM_TXN_REC.BILL_CCY_DERIVED;
        
        ELSIF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'F' THEN
        
          L_BLK_AMOUNT := P_TY_ATM_TXN_REC.SETL_AMT_DERIVED +
                          NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT, 0) +
                          NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0) +
                          L_CHG_SUM;
        
          L_BLK_CCY := P_TY_ATM_TXN_REC.SETL_CCY_DERIVED;
        END IF;
      END IF;
    
      IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'R' AND
         L_ACC_CCY = P_TY_ATM_TXN_REC.TXN_CCY_DERIVED THEN
      
        IF L_CHG_CCY <> L_ACC_CCY THEN
          P_TY_ATM_TXN_REC.X_RATE_DERIVED := NULL;
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                        L_CHG_CCY,
                                        L_ACC_CCY,
                                        'STANDARD',
                                        'M',
                                        L_CHG_SUM,
                                        'Y',
                                        L_CHG_AMT,
                                        P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                        P_ERR_CODE) THEN
            P_ERR_CODE  := 'SW-AMT-01';
            P_ERR_PARAM := L_CHG_CCY || '~' || L_ACC_CCY;
            DBG('E',
                'fn_amount_derive : Calling cypks.fn_amt1_to_amt2 failed ' ||
                P_ERR_CODE || '~' || P_ERR_PARAM);
            RETURN FALSE;
          END IF;
          L_CHG_SUM := L_CHG_AMT;
        END IF;
      
        L_BLK_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED +
                        NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT, 0) +
                        NVL(P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT, 0) +
                        L_CHG_SUM;
      
        L_BLK_CCY := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
      ELSE
      
        IF NOT FN_IS_GL(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                        P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.ACCOUNT,
                        L_ACC_CCY) AND L_ACC_CCY <> L_BLK_CCY AND
           L_BLK_AMOUNT IS NOT NULL AND
           P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.ACCOUNT IS NOT NULL THEN
        
          BEGIN
          
            SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
              INTO P_TY_ATM_TXN_REC.RATE_CODE, P_TY_ATM_TXN_REC.RATE_TYPE
              FROM CSTMS_PRODUCT
             WHERE PRODUCT_CODE = P_TY_ATM_TXN_REC.PRODUCT_CODE
               AND MODULE = 'RT'
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERR_CODE                 := 'SW-PRD-01';
              P_TY_ATM_TXN_REC.RESP_CODE := '05';
              DBG('E',
                  'NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
                  P_ERR_PARAM);
              RETURN FALSE;
          END;
        
          DBG('Pkg_Arc_Row.Dr_Acc ' || PKG_ARC_ROW.DR_ACC);
          IF P_TY_ATM_TXN_REC.RATE_CODE = 'B' AND
             PKG_ARC_ROW.DR_ACC = 'TXN' THEN
            P_TY_ATM_TXN_REC.RATE_CODE := 'S';
          END IF;
        
          P_TY_ATM_TXN_REC.X_RATE_DERIVED := NULL;
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                        L_BLK_CCY,
                                        L_ACC_CCY,
                                        P_TY_ATM_TXN_REC.RATE_TYPE,
                                        P_TY_ATM_TXN_REC.RATE_CODE
                                        
                                       ,
                                        L_BLK_AMOUNT
                                        
                                       ,
                                        'Y',
                                        L_ACC_AMT,
                                        P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                        P_ERR_CODE) THEN
            P_ERR_CODE  := 'SW-AMT-01';
            P_ERR_PARAM := '~' || L_BLK_CCY || '~' || L_ACC_CCY;
            DBG('E',
                'fn_amount_derive : Calling cypks.fn_amt1_to_amt2 failed ' ||
                P_ERR_CODE || '~' || P_ERR_PARAM);
            RETURN FALSE;
          END IF;
        
          L_BLK_AMOUNT := L_ACC_AMT;
        
        END IF;
      END IF;
    
      P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.AMOUNT := L_BLK_AMOUNT;
    
      P_AC_CCY := L_BLK_CCY;
      DBG(' p_cadamblk.amblk_catms_amount_blocks.amount :' ||
          P_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.AMOUNT);
    
    END IF;
    SWPKS_AMOUNTBLOCK.PR_SET_ACTIVATE_KERNEL;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE  := 'SW-MAP-01';
      P_ERR_PARAM := 'fn_mapping_iso_to_fcc' || '~' || P_ERR_CODE;
      RETURN FALSE;
  END FN_MAPPING_ISO_TO_FCC;

  FUNCTION FN_BLOCK_EXPIRY_UPDATE(P_TY_ATM_TXN_REC IN OUT GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                  P_ERR_CODE       IN OUT VARCHAR2,
                                  P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_AMT_BLK_NO CATMS_AMOUNT_BLOCKS.AMOUNT_BLOCK_NO%TYPE;
  BEGIN
  
    L_AMT_BLK_NO := P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO;
    DBG(' about to update the expiry date for the amount block :' ||
        L_AMT_BLK_NO);
  
    UPDATE CATMS_AMOUNT_BLOCKS
    
       SET EXPIRY_DATE = P_TY_ATM_TXN_REC.TXN_DT +
                         P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.BLOCK_EXP_DAYS
     WHERE AMOUNT_BLOCK_NO = L_AMT_BLK_NO;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE  := 'SW-UBK-01';
      P_ERR_PARAM := 'fn_block_expiry_update' || '~' || P_ERR_CODE;
      RETURN FALSE;
  END FN_BLOCK_EXPIRY_UPDATE;

  FUNCTION FN_MAIN(P_TY_ATM_TXN_REC IN OUT GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                   P_ERR_CODE       IN OUT VARCHAR2,
                   P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
    ERROR_EXCEPTION EXCEPTION;
    L_SOURCE           COTMS_SOURCE.SOURCE_CODE%TYPE;
    L_SOURCE_OPERATION VARCHAR2(32767);
    L_ACTION_CODE      VARCHAR2(32767);
    L_MULTI_TRIP_ID    VARCHAR2(32767);
  
    L_CADAMBLK    CAPKS_CADAMBLK_MAIN.TY_CADAMBLK;
    L_FUNCTION_ID SMTB_MENU.FUNCTION_ID%TYPE;
  
    L_STATUS     VARCHAR2(32767);
    L_AC_CCY     VARCHAR2(3);
    L_REQUEST_NO VARCHAR2(55);
  
    L_BRANCH_DATE    DATE;
    L_ACC_BRANCH     VARCHAR2(3);
    L_ACCOUNT        STTBS_ACCOUNT.AC_GL_NO%TYPE;
    L_AMOUNT         NUMBER(22, 3);
    L_EFFECTIVE_DATE DATE;
    L_EXPIRY_DATE    DATE;
    L_REMARKS        SWTB_TXN_LOG.TXN_DESC%TYPE;
    L_BLOCK_ID       CATMS_AMOUNT_BLOCKS.AMOUNT_BLOCK_NO%TYPE;
    L_BLOCK_TYPE     CATMS_AMOUNT_BLOCKS.AMOUNT_BLOCK_TYPE%TYPE;
    L_LIM_FLAG       VARCHAR2(1) := 'Y';
  
    L_MIN_BAL   VARCHAR2(35);
    L_TOD_LIMIT STTMS_ACCOUNT_BAL_TOV.TOD_LIMIT%TYPE := 0;
  
    L_BNDBAL STTMS_ACCLS_MIN_BAL_DET%ROWTYPE;
  
    L_ACCREC    STTBS_ACCOUNT%ROWTYPE;
    L_AVLBAL    ACTBS_HANDOFF.LCY_AMOUNT%TYPE := 0;
    L_RET_CODE  VARCHAR2(2000);
    L_RET_PARAM VARCHAR2(2000);
  
  BEGIN
    DBG('Inside swpks_amountblock fn_main');
  
    IF NOT FN_MAPPING_ISO_TO_FCC(P_TY_ATM_TXN_REC,
                                 L_CADAMBLK,
                                 L_AC_CCY,
                                 P_ERR_CODE,
                                 P_ERR_PARAM) THEN
      DBG('E', 'Failed while calling fn_mapping_iso_to_fcc' || SQLCODE);
      RETURN FALSE;
    
    END IF;
  
    L_BRANCH_DATE    := P_TY_ATM_TXN_REC.TXN_DT;
    L_ACC_BRANCH     := L_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.BRANCH;
    L_ACCOUNT        := L_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.ACCOUNT;
    L_AMOUNT         := L_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.AMOUNT;
    L_EFFECTIVE_DATE := L_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.EFFECTIVE_DATE;
    L_EXPIRY_DATE    := L_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.EXPIRY_DATE;
    L_REMARKS        := L_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.REMARKS;
	
	--sampath for cardless withdrawal starts
    IF P_TY_ATM_TXN_REC.PRODUCT_CODE = 'DPOW' AND P_TY_ATM_TXN_REC.msg_type = '1100' THEN
    L_REMARKS := 'CARDLESS_AMOUNT_BLOCK';
    END IF;
    --sampath for cardless withdrawal ends
  
    L_SOURCE           := P_TY_ATM_TXN_REC.SOURCE;
    L_SOURCE_OPERATION := 'CADAMBLK_DEFAULT';
    L_ACTION_CODE      := 'DEFAULT';
    L_FUNCTION_ID      := 'CADAMBLK';
    DBG('Calling capks_fcj_cadamblk.fn_main for default......... ');
  
    DBG('Calling swpkss_utils.fn_validate_ac ......... ');
    IF NOT SWPKSS_UTILS.FN_VALIDATE_AC(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                       P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                                       'D',
                                       P_TY_ATM_TXN_REC.TXN_DT,
                                       L_AC_CCY,
                                       P_ERR_CODE,
                                       P_ERR_PARAM) THEN
      DBG('E',
          'Failed while calling swpkss_utils.fn_validate_ac' || SQLCODE);
      P_ERR_CODE := 'SW-BLK-100';
      RETURN FALSE;
    
    END IF;
  
    DBG('Calling casapks for default......... ');
    IF NVL(L_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.AMOUNT, 0) <> 0 THEN
    
      IF CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') = 'FLEXSWITCH' THEN
        --sampath added if
        DBG('INSIDE SWITCH');
        IF NOT CASAPKS_CUSTOM.FN_VALIDATE_BLOCK_AMOUNT_PRIN(L_AMOUNT,
                                                            L_ACC_BRANCH,
                                                            L_ACCOUNT,
                                                            L_LIM_FLAG,
                                                            P_ERR_CODE) THEN
          DBG('failed while Updating the record ');
          RETURN FALSE;
        END IF;
      ELSE
        --sampath added else
      IF NOT CASAPKS.FN_VALIDATE_BLOCK_AMOUNT(L_AMOUNT,
                                              L_ACC_BRANCH,
                                              L_ACCOUNT,
                                              L_LIM_FLAG,
                                              P_ERR_CODE) THEN
        DBG('failed while Updating the record ');
        RETURN FALSE;
      END IF;
      END IF; --sampath added end if
    
      IF NOT CVPKS_UTILS.GET_STTB_ACC(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                      P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                                      L_ACCREC) THEN
        RETURN FALSE;
      END IF;
    
      IF NOT CVPKS_UTILS.FN_GET_ACC_MIN_BAL(L_ACCREC.BRANCH_CODE,
                                            L_ACCREC.AC_GL_NO,
                                            L_BNDBAL) THEN
        DBG('AC', 'Nothing needs to be done here');
      END IF;
    
      IF NOT ACPKS_MISC.FN_GETAVLBAL(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                     P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                                     L_AVLBAL,
                                     'Y') THEN
        DBG('Failed in the call to fn_getavlbal');
        P_ERR_CODE := 'SW-BAL-01';
        RETURN FALSE;
      END IF;
      DBG('In swpks_amountblock testing Min_Balance: ' ||
          L_BNDBAL.MIN_BALANCE || ',' || L_AVLBAL);
      DBG('p_ty_atm_txn_rec.txn_acc_no_fcc  ' ||
          P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);
      DBG('p_ty_atm_txn_rec.acc_branch_code' ||
          P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
    
      BEGIN
        SELECT TOD_LIMIT
          INTO L_TOD_LIMIT
          FROM STTMS_ACCOUNT_BAL_TOV
         WHERE CUST_AC_NO = P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC
           AND BRANCH_CODE = P_TY_ATM_TXN_REC.ACC_BRANCH_CODE;
        DBG('l_tod_limit ' || L_TOD_LIMIT);
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('in exception setting l_tod_limit to 0 ');
          L_TOD_LIMIT := 0;
      END;
    
      DBG('CNSL l_Bndbal.Min_Balance  before tod addition' ||
          L_BNDBAL.MIN_BALANCE);
      DBG('CNSL l_Avlbal before tod addition ' || L_AVLBAL);
      DBG('CNSL l_Avlbal after tod addition ' ||
          (L_AVLBAL + NVL(L_TOD_LIMIT, 0)));
    
      IF (((L_AVLBAL) + NVL(L_TOD_LIMIT, 0) - L_AMOUNT) <
         (L_BNDBAL.MIN_BALANCE)) THEN
        DBG('CNSL Avl. Bal less than min reqd for A/Class+CCY');
        L_MIN_BAL := TRIM(CSFNS_FORMAT_AMT(L_AC_CCY,
                                           ABS(L_BNDBAL.MIN_BALANCE)));
      
        IF P_ERR_CODE IS NULL THEN
          P_ERR_CODE := 'AC-OVD05' || ';';
        ELSE
          P_ERR_CODE := P_ERR_CODE || ';' || 'AC-OVD05;';
        END IF;
      
        IF (L_AVLBAL < 0) THEN
          DBG('l_Avl < 0 ');
          P_ERR_PARAM := P_ERR_PARAM || P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC || '~' ||
                         L_AVLBAL || '-' || '~' || L_MIN_BAL || '~;';
        ELSE
          DBG('l_Avl > 0 ');
          P_ERR_PARAM := P_ERR_PARAM || P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC || '~' ||
                         L_AVLBAL || '~' || L_MIN_BAL || '~;';
        END IF;
      END IF;
    
      IF NOT
          ACPKS.FN_GET_OVR(P_ERR_CODE, P_ERR_PARAM, L_RET_CODE, L_RET_PARAM) THEN
        RETURN FALSE;
      END IF;
    
      IF P_ERR_CODE IS NOT NULL THEN
      
        IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
          IF NOT GWPKS_EXT_SWITCHSERVICE.FN_BLOCK_MAIN(P_TY_ATM_TXN_REC,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM) THEN
            DBG('E',
                'gwpks_ext_switchservice.Fn_Block_Main returned false ');
            RETURN FALSE;
          END IF;
        ELSE
          RETURN FALSE;
        END IF;
      
      END IF;
    
      IF L_SOURCE = 'FLEXSWITCH' THEN
        L_BLOCK_TYPE := 'S';
      END IF;
      IF NOT CASAPKS.FN_CREATE_AMOUNT_BLOCK(L_BRANCH_DATE,
                                            L_ACC_BRANCH,
                                            L_ACCOUNT,
                                            L_AMOUNT,
                                            L_EFFECTIVE_DATE,
                                            L_EXPIRY_DATE,
                                            L_REMARKS,
                                            L_BLOCK_ID,
                                            NULL,
                                            NULL,
                                            L_BLOCK_TYPE,
                                            P_ERR_CODE,
                                            P_ERR_PARAM) THEN
        DBG('E', 'casapks.fn_create_amount_block' || SQLCODE);
        RETURN FALSE;
      
      END IF;
      L_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.AMOUNT_BLOCK_NO := L_BLOCK_ID;
    END IF;
  
    DBG('l_cadamblk.amblk_catms_amount_blocks.amount_block_no' ||
        L_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.AMOUNT_BLOCK_NO);
  
    IF (P_TY_ATM_TXN_REC.AUTH_CODE IS NULL) THEN
    
      P_TY_ATM_TXN_REC.AUTH_CODE := SUBSTR(P_TY_ATM_TXN_REC.XREF, 14, 3) ||
                                    LPAD(SW_AUTHSEQNUM.NEXTVAL, 3, '0');
    END IF;
    DBG('Before AUTH_Response-------->p_ty_atm_txn_rec.auth_code INSIDE ' ||
        P_TY_ATM_TXN_REC.AUTH_CODE);
  
    P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO := L_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.AMOUNT_BLOCK_NO;
  
    G_BLK_AMT := L_AMOUNT;
    G_BLK_CCY := L_AC_CCY;
  
    DBG('returning sucess ful from  capks_fcj_cadamblk.fn_main.........');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE  := 'SW-BLK-01';
      P_ERR_PARAM := 'fn_main' || '~' || P_ERR_CODE;
      RETURN FALSE;
  END FN_MAIN;

  FUNCTION FN_CALC_CHG(P_BRANCH   VARCHAR2,
                       P_CHG_CCY  IN VARCHAR2,
                       P_TXN_AMT  IN NUMBER,
                       P_CHG_DET  IN OUT GWPKS_CREATESWTRANSACTION.TYP_CHGDETS_REC,
                       P_INDEX    IN NUMBER,
                       P_ERR_CODE IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_BASIS_AMT  NUMBER;
    L_BASIS_CCY  VARCHAR2(3);
    L_BASIS_IDX  SMALLINT;
    L_AMT        NUMBER := 0;
    L_BASIS_RATE VARCHAR2(10);
    L_BASIS_TYPE VARCHAR2(1);
    L_CHG_CCY    VARCHAR2(3);
    L_RATE       NUMBER;
  
  BEGIN
    DBG('inside fn_calc_chg OF swpks_amountblock');
    DBG('Index Passed ' || P_INDEX);
    DBG('p_chg_ccy ' || P_CHG_CCY);
    DBG('p_txn_amt ' || P_TXN_AMT);
    DBG('p_chg_basis ' || P_CHG_DET.CHG_BASIS);
    DBG('p_chg_rate ' || P_CHG_DET.CHG_RATE);
    DBG('p_chg_type ' || P_CHG_DET.CHG_RATE_TYPE);
    DBG('p_chg_rate_code ' || P_CHG_DET.CHG_RATE_CODE);
    DBG('p_chg_type ' || P_CHG_DET.CHG_RATE_CODE_TYPE);
    DBG('g_Iso_Charge1 ' || G_ISO_CHARGE1);
    DBG('p_chg_det.cod_chg_ccy' || P_CHG_DET.COD_CHG_CCY);
    L_BASIS_IDX  := P_CHG_DET.CHG_BASIS;
    L_BASIS_RATE := P_CHG_DET.CHG_RATE;
    L_BASIS_TYPE := P_CHG_DET.CHG_RATE_TYPE;
  
    IF P_CHG_DET.COD_CHG_CCY != '*.*' THEN
      L_CHG_CCY := P_CHG_DET.COD_CHG_CCY;
    ELSE
      L_CHG_CCY := P_CHG_CCY;
    END IF;
  
    IF L_BASIS_IDX IS NOT NULL THEN
      IF L_BASIS_IDX = 0 THEN
        L_BASIS_AMT := P_TXN_AMT;
        L_BASIS_CCY := P_CHG_CCY;
      ELSIF L_BASIS_IDX = 1 THEN
        L_BASIS_AMT := G_ISO_CHARGE1;
        L_BASIS_CCY := P_CHG_CCY;
      ELSIF L_BASIS_IDX = 2 THEN
        L_BASIS_AMT := G_ISO_CHARGE2;
        L_BASIS_CCY := P_CHG_CCY;
      ELSIF L_BASIS_IDX = 3 THEN
        L_BASIS_AMT := PKG_ARC_ROW.COD_CHG_AMT2;
        L_BASIS_CCY := PKG_ARC_ROW.COD_CHG_CCY2;
      ELSIF L_BASIS_IDX = 4 THEN
        L_BASIS_AMT := PKG_ARC_ROW.COD_CHG_AMT3;
        L_BASIS_CCY := PKG_ARC_ROW.COD_CHG_CCY3;
      
      END IF;
    END IF;
    IF L_BASIS_CCY = '*.*' THEN
      L_BASIS_CCY := P_CHG_CCY;
    END IF;
  
    IF L_BASIS_TYPE = 'P' THEN
    
      L_AMT := P_CHG_DET.CHG_AMT;
    
      IF L_BASIS_CCY <> L_CHG_CCY THEN
        L_RATE := NULL;
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_BRANCH,
                                      L_BASIS_CCY,
                                      L_CHG_CCY,
                                      NVL(P_CHG_DET.CHG_RATE_CODE, 'STANDARD'),
                                      NVL(P_CHG_DET.CHG_RATE_CODE_TYPE, 'M'),
                                      L_AMT,
                                      'Y',
                                      L_AMT,
                                      L_RATE,
                                      P_ERR_CODE) THEN
          DBG('Currency Conversion from ' || L_BASIS_CCY || ' to ' ||
              L_CHG_CCY || 'FAILED');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
    DBG('l_amt ' || L_AMT);
    IF L_AMT != 0 THEN
      DBG('l_amt ' || L_AMT);
      P_CHG_DET.CHG_AMT := L_AMT;
    END IF;
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE := 'SW-BLK-01';
    
      RETURN FALSE;
    
  END FN_CALC_CHG;

END SWPKS_AMOUNTBLOCK;
