CREATE OR REPLACE PACKAGE BODY SWPKS_RTTRANSACTION AS

  PROCEDURE DBG(P_DBG IN VARCHAR2) IS
  BEGIN

    DEBUG.PR_DEBUG('SW', '[DEBUG]' || 'swpks_rttransaction :' || P_DBG);
  END DBG;

  PROCEDURE DBG(P_DBG_IND IN VARCHAR2, P_DBG IN VARCHAR2) IS
  BEGIN

    IF P_DBG_IND = 'E' THEN
      DEBUG.PR_DEBUG('SW', '[ERROR] ' || 'swpks_rttransaction :' || P_DBG);
    ELSE
      DEBUG.PR_DEBUG('SW', '[DEBUG] ' || 'swpks_rttransaction :' || P_DBG);
    END IF;
  END DBG;

  FUNCTION CHECK_ERROR(P_TY_ATM_TXN_REC IN OUT NOCOPY GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                       P_ERR_CODE       IN OUT VARCHAR2) RETURN BOOLEAN AS
    L_ERR_TYPE ERTB_MSGS.TYPE%TYPE DEFAULT NULL;
    L_ERR_TBL  OVPKSS.TBL_ERROR;

  BEGIN

    L_ERR_TBL := OVPKSS.GL_TBLERROR;

    FOR I IN 1 .. L_ERR_TBL.COUNT LOOP
      L_ERR_TYPE := OVPKSS.FN_GETTYPE(L_ERR_TBL(I).ERR_CODE);
      IF L_ERR_TYPE IN ('E', 'X') THEN
        DBG('E', 'Error Found... ' || L_ERR_TBL(I).ERR_CODE);

        P_ERR_CODE := L_ERR_TBL(I).ERR_CODE;
      END IF;
    END LOOP;
    IF L_ERR_TYPE NOT IN ('E', 'X') THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END CHECK_ERROR;

  --sampath starts for css
  FUNCTION FN_GET_CSS_ACC(P_PARAM_NAME IN CSTB_PARAM_CUSTOM.PARAM_NAME%TYPE)
    RETURN CSTB_PARAM_CUSTOM.PARAM_VAL%TYPE AS
    L_PARAM_VAL CSTB_PARAM_CUSTOM.PARAM_VAL%TYPE;
  BEGIN
    SELECT PARAM_VAL
      INTO L_PARAM_VAL
      FROM CSTB_PARAM_CUSTOM
     WHERE PARAM_NAME = P_PARAM_NAME;
    RETURN L_PARAM_VAL;
  EXCEPTION
    WHEN OTHERS THEN
      L_PARAM_VAL := NULL;
      RETURN L_PARAM_VAL;
  END FN_GET_CSS_ACC;
  --sampath ends for css

  FUNCTION FN_IS_GL(P_BRN IN VARCHAR2,
                    P_ACC IN VARCHAR2,
                    P_CCY OUT VARCHAR2) RETURN BOOLEAN IS
    L_STTB_ACCOUNT STTBS_ACCOUNT%ROWTYPE;
  BEGIN
    DBG('p_brn==>' || P_BRN);
    DBG('p_acc==>' || P_ACC);
    IF NOT CVPKS_UTILS.GET_STTB_ACC(P_BRN, P_ACC, L_STTB_ACCOUNT) THEN
      DBG('E', 'Checking for which G or A............');
      RETURN FALSE;
    END IF;
    IF L_STTB_ACCOUNT.AC_OR_GL = 'G' THEN
      RETURN TRUE;
    ELSE
      P_CCY := L_STTB_ACCOUNT.AC_GL_CCY;
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('E', 'FROM fn IS gl ' || SQLERRM);
      DBG('Err FOR ' || P_BRN || ' ' || P_ACC);
      P_CCY := NULL;
      RETURN FALSE;
  END FN_IS_GL;

  FUNCTION FN_PROCESS(P_TY_ATM_TXN_REC IN OUT NOCOPY GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                      P_TY_RTUPLD      IN OUT NOCOPY DEPKSS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                      P_ERR_CODE       IN OUT VARCHAR2,
                      P_ERR_PARAM      IN OUT VARCHAR) RETURN BOOLEAN AS

    L_ACC_CCY CYTM_CCY_DEFN.CCY_CODE%TYPE;
    L_ACC_AMT NUMBER(22, 3);

    L_TXN_BRN CSTB_PARAM.PARAM_VAL%TYPE;

    --sampath starts added for off us
    L_TXN_CCY   CYTM_CCY_DEFN.CCY_CODE%TYPE;
    L_RATE_FLAG NUMBER;
  L_OFS_BRN   CSTB_PARAM.PARAM_VAL%TYPE; --added for CSS
    --sampath ends added for off us

  --sampath starts for account limit per day
    L_AMOUNT  STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    L_AMOUNT1 STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    l_txn_amt DETB_RTL_TELLER.TXN_AMOUNT%TYPE;
    --sampath ends for account limit per day

  BEGIN

   DBG('P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC=' ||
        P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);
    DBG('WHO CALLED ME=' || DBMS_UTILITY.format_call_stack);
    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_PROCESS_SWRTTXN(P_TY_ATM_TXN_REC,
                                                        P_TY_RTUPLD,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAM) THEN
        DBG('E',
            'gwpks_ext_switchservice.Fn_Process_rttxn returned false ');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('p_ty_atm_txn_rec.SOURCE :' || P_TY_ATM_TXN_REC.SOURCE);

      IF P_TY_ATM_TXN_REC.TXN_FEE_AMT IS NOT NULL THEN
        P_TY_ATM_TXN_REC.TXN_FEE_AMT := SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                               2,
                                               8);

        --sampath starts to waive markup fee
        IF P_TY_ATM_TXN_REC.fc_literal = 'CAB' THEN
          P_TY_ATM_TXN_REC.TXN_FEE_AMT := '00000000';
        END IF;
        --sampath ends to waive markup fee

    --sampath starts not to double charge acquirere fee on the customer account
        IF P_TY_ATM_TXN_REC.network_id IN ('MASTER', 'VISA') AND P_TY_ATM_TXN_REC.offus_onus = 'R' THEN
        P_TY_ATM_TXN_REC.TXN_FEE_AMT := '00000000';
        END IF;

      END IF;
      IF P_TY_ATM_TXN_REC.SETL_FEE_AMT IS NOT NULL THEN
        P_TY_ATM_TXN_REC.SETL_FEE_AMT := SUBSTR(P_TY_ATM_TXN_REC.SETL_FEE_AMT,
                                                2,
                                                8);
      END IF;
      IF P_TY_ATM_TXN_REC.TXN_PROC_FEE IS NOT NULL THEN
        P_TY_ATM_TXN_REC.TXN_PROC_FEE := SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                2,
                                                8);

        --sampath starts to waive markup fee
        IF P_TY_ATM_TXN_REC.fc_literal = 'CAB' THEN
          P_TY_ATM_TXN_REC.TXN_PROC_FEE := '00000000';
        END IF;
        --sampath ends to waive markup fee

      END IF;
      IF P_TY_ATM_TXN_REC.SETL_PROC_FEE IS NOT NULL THEN
        P_TY_ATM_TXN_REC.SETL_PROC_FEE := SUBSTR(P_TY_ATM_TXN_REC.SETL_PROC_FEE,
                                                 2,
                                                 8);
      END IF;

      DBG('p_Ty_Atm_Txn_Rec.Txn_Fee_Amt==>' ||
          P_TY_ATM_TXN_REC.TXN_FEE_AMT);
      DBG('p_Ty_Atm_Txn_Rec.Setl_Fee_Am==>' ||
          P_TY_ATM_TXN_REC.SETL_FEE_AMT);
      DBG('p_Ty_Atm_Txn_Rec.Txn_Proc_Fee==>' ||
          P_TY_ATM_TXN_REC.TXN_PROC_FEE);
      DBG('p_Ty_Atm_Txn_Rec.Setl_Proc_Fee==>' ||
          P_TY_ATM_TXN_REC.SETL_PROC_FEE);

      DBG('P_TY_ATM_TXN_REC.BILL_AMT=' || P_TY_ATM_TXN_REC.BILL_AMT);
      DBG('P_TY_ATM_TXN_REC.BILL_CCY_CODE=' ||
          P_TY_ATM_TXN_REC.BILL_CCY_CODE);

      IF NOT
          GWPKSS_CREATESWTRANSACTION.FN_AMT_CHG_DERIVE_NEW(P_TY_ATM_TXN_REC,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN
        DBG('E',
            'Failed while calling gwpks_createswitch.fn_amt_chg_derive' ||
            P_ERR_CODE);
        RETURN FALSE;
      END IF;

      IF NOT GWPKSS_CREATESWTRANSACTION.FN_PRODUCT_DERIVE(P_TY_ATM_TXN_REC,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAM) THEN
        DBG('E',
            'Failed while calling Gwpks_CreateSWTransaction.fn_product_derive' ||
            P_ERR_CODE);
        RETURN FALSE;
      END IF;

      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF      := P_TY_ATM_TXN_REC.XREF;
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.EXCH_RATE := P_TY_ATM_TXN_REC.X_RATE_DERIVED;

      IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'R' THEN
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('HEAD_OFFICE_BRANCH_NAME'),
                                                          P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
      ELSE

        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE := P_TY_ATM_TXN_REC.ORIG_BRANCH_CODE;
      END IF;
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT := P_TY_ATM_TXN_REC.TXN_DT;

      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.VALUE_DT     := P_TY_ATM_TXN_REC.VALUE_DT;
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE := P_TY_ATM_TXN_REC.PRODUCT_CODE;

      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.AUTH_STAT   := 'A';
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.RECORD_STAT := 'O';

      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.MAKER_ID := P_TY_ATM_TXN_REC.USER_ID;

      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.MAKER_DT_STAMP := FN_SYSDATE;
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.MAKER_DT_STAMP := GLOBAL.APPLICATION_DATE +
                                                       (P_TY_RTUPLD.TY_UPLD_RTL_TELLER.MAKER_DT_STAMP -
                                                       TRUNC(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.MAKER_DT_STAMP));
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.NARRATIVE      := P_TY_ATM_TXN_REC.TXN_DESC;

      IF P_TY_ATM_TXN_REC.FC_LITERAL IN
         ('CAW',
      'CCP', --sampath starts for credit card payment via ATM
          'CDP',
          'MSD',
          'NPA',
          'CAB',
          'CQP',
          'FTR',
      'DFT', --sampath added DFT for Debit payment for css
          'CFT', --sampath added CFT for Credit payment for css
          'PAY',
          'PAD',
          'MRE',
          'MRA',
          'MER') THEN
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH := P_TY_ATM_TXN_REC.ACC_BRANCH_CODE;
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC    := P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC;

        IF P_TY_ATM_TXN_REC.RSV_60 IN ('CCONUS') THEN
          --sampath added code for credit card cash withdrawal starts
          --P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC :=
          DBG('P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC=' ||
              P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC);
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC    := P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC;
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH := P_TY_ATM_TXN_REC.OFF_BRANCH_CODE;

      --sampath starts for credit card payment

        ELSIF SUBSTR(P_TY_ATM_TXN_REC.proc_code,1,2)= '49' THEN
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC    := P_TY_ATM_TXN_REC.TO_ACC;
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH := P_TY_ATM_TXN_REC.OFF_BRANCH_CODE;
        --sampath ends for credit card payment

        ELSE
          --sampath added code for credit card cash withdrawal starts

          IF P_TY_ATM_TXN_REC.FC_LITERAL IN ('FTR', 'PAY') THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC    := P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH := P_TY_ATM_TXN_REC.OFF_BRANCH_CODE;
          ELSE
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC    := P_TY_ATM_TXN_REC.TXN_GL;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH := P_TY_ATM_TXN_REC.ORIG_BRANCH_CODE;

            IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'R' THEN
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('HEAD_OFFICE_BRANCH_NAME'),
                                                               P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
            END IF;

          END IF;

        END IF; --sampath added code for credit card cash withdrawal starts

        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH);
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH);
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);


    --sampath starts added if condition as ofs amount is going as txn amount for CFT when account is KHR and currency is USD and amount is USD for css
        IF P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NULL AND
           P_TY_ATM_TXN_REC.bill_ccy_code IS NULL AND
           P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NULL AND
           P_TY_ATM_TXN_REC.fc_literal = 'CFT' AND
           P_TY_ATM_TXN_REC.offus_onus = 'F' THEN

           P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED;
       /*
        ELSIF P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NULL AND --sampath starts added else keyword as ofs amount is going as txn amount for CFT when account is KHR and currency is USD and amount is USD
           P_TY_ATM_TXN_REC.bill_ccy_code IS NULL AND
           P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NULL AND
           P_TY_ATM_TXN_REC.fc_literal = 'FTR' AND
           P_TY_ATM_TXN_REC.offus_onus = 'O' AND
           P_TY_ATM_TXN_REC.network_id = 'PRINCE'
           AND p_ty_atm_txn_rec.txn_ccy_code = '840' THEN  --sampath

          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED;*/

        ELSE  --sampath starts added else keyword as ofs amount is going as txn amount for CFT when account is KHR and currency is USD and amount is USD for css


        IF P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NULL AND
           P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NULL THEN
          DBG('Only TXN-AMT Present.Both BIL-AMT and SETL-AMT is NULL');
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED;
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY    := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
          DBG(' p_ty_rtupld.ty_upld_rtl_teller.ofs_amount =' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT);
        ELSIF P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NULL AND
              P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NOT NULL AND
              P_TY_ATM_TXN_REC.TXN_AMT_DERIVED IS NOT NULL THEN
          DBG('TXN-AMT and SETL-AMT Present.(BIL-AMT is NULL)');
          IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'O' THEN
            DBG('Onus');

            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := P_TY_ATM_TXN_REC.SETL_AMT_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY    := P_TY_ATM_TXN_REC.SETL_CCY_DERIVED;

          ELSIF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'R' THEN

            IF NOT FN_IS_GL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC,
                            L_ACC_CCY) THEN

              IF L_ACC_CCY = P_TY_ATM_TXN_REC.TXN_CCY_DERIVED THEN
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED;
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY    := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
              END IF;
            ELSE
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED;
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY    := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
              DBG('p_ty_rtupld.ty_upld_rtl_teller.txn_ccy' ||
                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);
            END IF;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := P_TY_ATM_TXN_REC.SETL_AMT_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY    := P_TY_ATM_TXN_REC.SETL_CCY_DERIVED;
          ELSIF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'F' THEN
            DBG('Off-Us');
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT := P_TY_ATM_TXN_REC.SETL_AMT_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY    := P_TY_ATM_TXN_REC.SETL_CCY_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY    := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
          END IF;

        ELSIF P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NULL AND
              P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NOT NULL AND
              P_TY_ATM_TXN_REC.TXN_AMT_DERIVED IS NOT NULL THEN
          DBG('TXN-AMT and BIL-AMT Present.(SETL-AMT is NULL)');
          IF NOT FN_IS_GL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC,
                          L_ACC_CCY) THEN

            IF L_ACC_CCY = P_TY_ATM_TXN_REC.TXN_CCY_DERIVED THEN
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED;
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY    := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
            ELSE
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT := P_TY_ATM_TXN_REC.BILL_AMT_DERIVED;
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY    := P_TY_ATM_TXN_REC.BILL_CCY_DERIVED;
            END IF;
          END IF;

          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := P_TY_ATM_TXN_REC.TXN_AMT_DERIVED;
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY    := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;

        ELSIF P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NOT NULL AND
              P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NOT NULL AND
              P_TY_ATM_TXN_REC.TXN_AMT_DERIVED IS NULL THEN
          IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'O' THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := P_TY_ATM_TXN_REC.SETL_AMT_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY    := P_TY_ATM_TXN_REC.SETL_CCY_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT := P_TY_ATM_TXN_REC.BILL_AMT_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY    := P_TY_ATM_TXN_REC.BILL_CCY_DERIVED;
          ELSIF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'R' THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := P_TY_ATM_TXN_REC.SETL_AMT_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY    := P_TY_ATM_TXN_REC.SETL_CCY_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT := P_TY_ATM_TXN_REC.BILL_AMT_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY    := P_TY_ATM_TXN_REC.BILL_CCY_DERIVED;
          ELSIF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'F' THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := P_TY_ATM_TXN_REC.BILL_AMT_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY    := P_TY_ATM_TXN_REC.BILL_CCY_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT := P_TY_ATM_TXN_REC.SETL_AMT_DERIVED;
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY    := P_TY_ATM_TXN_REC.SETL_CCY_DERIVED;
          END IF;
        END IF;
    END IF;  --sampath added end if condition as ofs amount is going as txn amount for CFT when account is KHR and currency is USD and amount is USD for css

      ELSIF P_TY_ATM_TXN_REC.FC_LITERAL IN
            ('BEQ', 'BIQ', 'CHB', 'ADS', 'MST') THEN
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH := P_TY_ATM_TXN_REC.ACC_BRANCH_CODE;
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC    := P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC;
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := 0;
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH := P_TY_ATM_TXN_REC.ACC_BRANCH_CODE;
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC    := P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC;
      END IF;

      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.SERVICE_PROVIDER := P_TY_ATM_TXN_REC.RSV_60;
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BILL_NUMBER      := P_TY_ATM_TXN_REC.RSV_PVT_61;
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BILL_ISSUE_DATE  := TO_DATE(P_TY_ATM_TXN_REC.RSV_PVT_62,
                                                                 'mmddhh24miss');
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.CONSUMER_NO      := P_TY_ATM_TXN_REC.RSV_PVT_63;

      DBG('p_ty_atm_txn_rec.offus_onus is ' || P_TY_ATM_TXN_REC.OFFUS_ONUS);
      DBG('p_ty_rtupld.ty_upld_rtl_teller.txn_branch BEFORE is  ' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH);
      IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'F' AND
         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH IS NULL THEN

        --sampath commented starts
        /*L_TXN_BRN := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('HEAD_OFFICE_BRANCH_NAME'),
        P_TY_ATM_TXN_REC.ORIG_BRANCH_CODE);*/
        --sampath commented ends
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);

        --sampath added starts
        --Get transaction account from arc maint
        DBG('P_TY_ATM_TXN_REC.RSV_60=' || P_TY_ATM_TXN_REC.RSV_60);
        DBG('P_TY_ATM_TXN_REC.FC_LITERAL=' || P_TY_ATM_TXN_REC.FC_LITERAL);
        IF P_TY_ATM_TXN_REC.RSV_60 = 'MAS' AND
           P_TY_ATM_TXN_REC.FC_LITERAL IN ('CAW', 'BEQ') THEN
          BEGIN
            SELECT A.COD_TXN_ACCOUNT
              INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC
              FROM IFTM_ARC_MAINT A
             WHERE A.COD_PROD_ACC_CLS = 'ACW1'
               AND ROWNUM = 1;
          EXCEPTION
            WHEN OTHERS THEN
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC := '000069531';
          END;
          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);

          BEGIN
            SELECT A.BRANCH_CODE
              INTO L_TXN_BRN
              FROM STTB_ACCOUNT A
             WHERE A.AC_GL_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              L_TXN_BRN := '991';
          END;

        ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'VIS' AND
              P_TY_ATM_TXN_REC.FC_LITERAL IN ('CAW', 'BEQ') THEN
          BEGIN
            SELECT A.COD_TXN_ACCOUNT
              INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC
              FROM IFTM_ARC_MAINT A
             WHERE A.COD_PROD_ACC_CLS = 'ACW2'
               AND ROWNUM = 1;
          EXCEPTION
            WHEN OTHERS THEN
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC := '000069269';
          END;

          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);

          BEGIN
            SELECT A.BRANCH_CODE
              INTO L_TXN_BRN
              FROM STTB_ACCOUNT A
             WHERE A.AC_GL_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              L_TXN_BRN := '991';
          END;

    --UPI starts
        ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'UPI' AND
           P_TY_ATM_TXN_REC.FC_LITERAL IN ('CAW', 'BEQ') THEN
          BEGIN
            SELECT A.COD_TXN_ACCOUNT
              INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC
              FROM IFTM_ARC_MAINT A
             WHERE A.COD_PROD_ACC_CLS = 'ACWU'
               AND ROWNUM = 1;
          EXCEPTION
            WHEN OTHERS THEN
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC := '000069531';
          END;
          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);

          BEGIN
            SELECT A.BRANCH_CODE
              INTO L_TXN_BRN
              FROM STTB_ACCOUNT A
             WHERE A.AC_GL_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              L_TXN_BRN := '991';
          END;
        --UPI ends

        --sampath added for css starts
        ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'CSS' AND
              P_TY_ATM_TXN_REC.FC_LITERAL IN ('CAW', 'PIN', 'BEQ', 'MST') AND
              P_TY_ATM_TXN_REC.offus_onus = 'F' THEN

          DBG('INSIDE CSS OFF US');

          IF P_TY_ATM_TXN_REC.FC_LITERAL IN ('PIN', 'BEQ', 'MST') THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC := '000000036';
          END IF;

          IF P_TY_ATM_TXN_REC.FC_LITERAL IN ('CAW') THEN
            IF P_TY_ATM_TXN_REC.TXN_CCY_DERIVED = 'KHR' THEN

              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC := FN_GET_CSS_ACC('CSS_KHR_TXN_ACC'); --'000021069';
              DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
            ELSE
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC := FN_GET_CSS_ACC('CSS_USD_TXN_ACC'); --'000021058';
              DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
            END IF;
          END IF;

          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);

          BEGIN
            SELECT A.BRANCH_CODE
              INTO L_TXN_BRN
              FROM STTB_ACCOUNT A
             WHERE A.AC_GL_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              L_TXN_BRN := '991';
          END;

          BEGIN
            SELECT CCY_CODE
              INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY
              FROM CYTMS_CCY_DEFN_MASTER
             WHERE ISO_NUM_CCY_CODE = P_TY_ATM_TXN_REC.txn_ccy_code
               AND RECORD_STAT = 'O'
               AND AUTH_STAT = 'A';
          EXCEPTION
            WHEN OTHERS THEN
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := 'USD';
          END;

        ELSIF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('42') AND
              p_ty_atm_txn_rec.Fc_Literal = 'CFT' AND
              P_TY_ATM_TXN_REC.offus_onus = 'F' THEN

          BEGIN
            SELECT AC_GL_NO, BRANCH_CODE
              INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC,
                   P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH
              FROM STTB_ACCOUNT
             WHERE AC_GL_NO = P_TY_ATM_TXN_REC.TO_ACC
               AND AUTH_STAT = 'A'
               AND AC_GL_REC_STATUS = 'O'
               AND AC_OR_GL = 'A';
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;

          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC PINEAPPLE=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH PINEAPPLE=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH);

          BEGIN
            SELECT CCY_CODE
              INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY
              FROM CYTMS_CCY_DEFN_MASTER
             WHERE ISO_NUM_CCY_CODE = P_TY_ATM_TXN_REC.txn_ccy_code
               AND RECORD_STAT = 'O'
               AND AUTH_STAT = 'A';
          EXCEPTION
            WHEN OTHERS THEN
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := 'USD';
          END;

        END IF;

        --sampath added ends for css

        --sampath added ends

        DBG('l_txn_brn is  ' || L_TXN_BRN);
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH := L_TXN_BRN;

      END IF;
      DBG('p_ty_rtupld.ty_upld_rtl_teller.txn_branch is  ' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH);

    --Again for credit IBFT as transaction branch is not null starts
      IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('42') AND
         p_ty_atm_txn_rec.Fc_Literal = 'CFT' AND
         P_TY_ATM_TXN_REC.offus_onus = 'F' THEN

        IF P_TY_ATM_TXN_REC.TXN_CCY_DERIVED = 'KHR' THEN

          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC := FN_GET_CSS_ACC('CSS_KHR_TXN_ACC'); --'000021069';
          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
        ELSE
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC := FN_GET_CSS_ACC('CSS_USD_TXN_ACC'); --'000021058';
          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
        END IF;

        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);

        BEGIN
          SELECT A.BRANCH_CODE
            INTO L_TXN_BRN
            FROM STTB_ACCOUNT A
           WHERE A.AC_GL_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC;
        EXCEPTION
          WHEN OTHERS THEN
            L_TXN_BRN := '991';
        END;

        DBG('l_txn_brn is  ' || L_TXN_BRN);
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH := L_TXN_BRN;

        BEGIN
          SELECT AC_GL_NO, BRANCH_CODE
            INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC,
                 P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH
            FROM STTB_ACCOUNT
           WHERE AC_GL_NO = P_TY_ATM_TXN_REC.TO_ACC
             AND AUTH_STAT = 'A'
             AND AC_GL_REC_STATUS = 'O'
             AND AC_OR_GL = 'A';
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;

        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC PINEAPPLE=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH PINEAPPLE=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH);

        BEGIN
          SELECT CCY_CODE
            INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY
            FROM CYTMS_CCY_DEFN_MASTER
           WHERE ISO_NUM_CCY_CODE = P_TY_ATM_TXN_REC.txn_ccy_code
             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A';
        EXCEPTION
          WHEN OTHERS THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := 'USD';
        END;

      END IF;

      --Again for credit IBFT as transaction branch is not null ends

      --sampath starts for us on us fund transfer to derive the ofs account and not sending css value in field 60 for css
      IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('41') AND
         p_ty_atm_txn_rec.Fc_Literal = 'DFT' AND
         P_TY_ATM_TXN_REC.offus_onus = 'O' THEN

        IF P_TY_ATM_TXN_REC.TXN_CCY_DERIVED = 'KHR' THEN

          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC := FN_GET_CSS_ACC('CSS_KHR_TXN_ACC'); --'000021069';
          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
        ELSE
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC := FN_GET_CSS_ACC('CSS_USD_TXN_ACC'); --'000021058';
          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
        END IF;

        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);

        BEGIN
          SELECT A.BRANCH_CODE
            INTO L_OFS_BRN
            FROM STTB_ACCOUNT A
           WHERE A.AC_GL_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC;
        EXCEPTION
          WHEN OTHERS THEN
            L_OFS_BRN := '991';
        END;

        DBG('l_ofs_brn is  ' || L_OFS_BRN);
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH := L_OFS_BRN;

        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC PINEAPPLE=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH PINEAPPLE=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH);

        BEGIN
          SELECT CCY_CODE
            INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY
            FROM CYTMS_CCY_DEFN_MASTER
           WHERE ISO_NUM_CCY_CODE = P_TY_ATM_TXN_REC.txn_ccy_code
             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A';
        EXCEPTION
          WHEN OTHERS THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY := 'USD';
        END;

      END IF;
      --sampath ends for us on us fund transfer to derive the ofs account and not sending css value in field 60 for css


      IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'F' AND
         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY IS NULL THEN
        --sampath commented starts for off us
        --P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
        --sampath commented ends for off us

        --sampath added starts for off us
        IF P_TY_ATM_TXN_REC.RSV_60 IN ('MAS','VIS', 'UPI') AND --added VISA now and --added UPI now
           P_TY_ATM_TXN_REC.FC_LITERAL = 'CAW' THEN
          BEGIN
            SELECT A.AC_GL_CCY
              INTO L_TXN_CCY
              FROM STTB_ACCOUNT A
             WHERE A.AC_GL_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              L_TXN_CCY := 'USD';
          END;
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := L_TXN_CCY;
        END IF;
        --sampath added ends for off us

      END IF;

      DBG('p_ty_rtupld.ty_upld_rtl_teller.txn_branch' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH);
      DBG('p_ty_rtupld.ty_upld_rtl_teller.txn_acc--' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
      DBG('l_acc_ccy --> ' || L_ACC_CCY);
      DBG('p_ty_rtupld.ty_upld_rtl_teller.txn_ccy --> ' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);
      DBG('p_ty_rtupld.ty_upld_rtl_teller.txn_amount --> ' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT);

      DBG('P_TY_ATM_TXN_REC.TXN_CCY_DERIVED=' ||
          P_TY_ATM_TXN_REC.TXN_CCY_DERIVED);
      DBG('P_TY_ATM_TXN_REC.txn_ccy_code=' ||
          P_TY_ATM_TXN_REC.txn_ccy_code);

      DBG('P_TY_ATM_TXN_REC.BILL_CCY_DERIVED=' ||
          P_TY_ATM_TXN_REC.BILL_CCY_DERIVED);

    --sampath starts for css
      IF P_TY_ATM_TXN_REC.RSV_60 IN ('CSS') AND
         P_TY_ATM_TXN_REC.fc_literal in ('CAW', /*'FTR',*/ 'DFT') AND
         P_TY_ATM_TXN_REC.offus_onus IN ('R') THEN
        --pls include processing code as well as this is for debit or credit payment

        dbg('I am inside remote on us');

        IF P_TY_ATM_TXN_REC.fc_literal = 'DFT' THEN

          IF P_TY_ATM_TXN_REC.SETL_AMT_DERIVED IS NULL AND
             P_TY_ATM_TXN_REC.BILL_AMT_DERIVED IS NULL
          /* AND P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC <>
                                 P_TY_ATM_TXN_REC.TXN_CCY_FCC*/
           THEN

            IF NOT FN_IS_GL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC,
                            L_ACC_CCY) THEN

              IF L_ACC_CCY = P_TY_ATM_TXN_REC.TXN_CCY_DERIVED THEN
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := P_TY_ATM_TXN_REC.TXN_CCY_DERIVED;
              ELSE
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := L_ACC_CCY;
              END IF;
            END IF;

            --P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := P_TY_ATM_TXN_REC.txn_ccy_derived;

          ELSE
            BEGIN
              SELECT CCY_CODE
                INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY
                FROM CYTMS_CCY_DEFN_MASTER
               WHERE ISO_NUM_CCY_CODE = P_TY_ATM_TXN_REC.BILL_CCY_DERIVED
                 AND RECORD_STAT = 'O'
                 AND AUTH_STAT = 'A';
            EXCEPTION
              WHEN OTHERS THEN
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := 'USD';
            END;
          END IF;

          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);

          --IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY = 'USD' THEN
          IF P_TY_ATM_TXN_REC.Txn_Ccy_Fcc = 'USD' THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC := FN_GET_CSS_ACC('CSS_USD_TXN_ACC'); --'000021058';
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY := 'USD';
            DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC APPLE=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
            --ELSIF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY = 'KHR' THEN
          ELSIF P_TY_ATM_TXN_REC.Txn_Ccy_Fcc = 'KHR' THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC := FN_GET_CSS_ACC('CSS_KHR_TXN_ACC'); --'000021069';
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY := 'KHR';
            DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC APPLE1=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
          END IF;

          BEGIN
            SELECT A.BRANCH_CODE
              INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH
              FROM STTB_ACCOUNT A
             WHERE A.AC_GL_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH := '991';
          END;

        ELSIF P_TY_ATM_TXN_REC.fc_literal = 'CAW' THEN

          --IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY = 'USD' THEN
          IF P_TY_ATM_TXN_REC.Txn_Ccy_Fcc = 'USD' THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC := FN_GET_CSS_ACC('CSS_USD_TXN_ACC'); --'000021058';
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY := 'USD';
            DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC APPLE=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
            --ELSIF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY = 'KHR' THEN
          ELSIF P_TY_ATM_TXN_REC.Txn_Ccy_Fcc = 'KHR' THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC := FN_GET_CSS_ACC('CSS_KHR_TXN_ACC'); --'000021069';
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY := 'KHR';
            DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC APPLE1=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
          END IF;

          BEGIN
            SELECT A.BRANCH_CODE
              INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH
              FROM STTB_ACCOUNT A
             WHERE A.AC_GL_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH := '991';
          END;

        END IF;

      END IF;
    --sampath ends for css

      --sampath starts
      IF P_TY_ATM_TXN_REC.RSV_60 IN ('CCONUS') THEN
        BEGIN
          SELECT CCY_CODE
            INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY
            FROM CYTMS_CCY_DEFN_MASTER
           WHERE ISO_NUM_CCY_CODE = P_TY_ATM_TXN_REC.txn_ccy_code
             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A';
        EXCEPTION
          WHEN OTHERS THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := 'USD';
        END;
      END IF;

    --Sampath Credit Card Currency Should be USD starts
      IF P_TY_ATM_TXN_REC.RSV_60 IN ('CCONUS') OR P_TY_ATM_TXN_REC.NETWORK_ID IN ('CREDITCARDV') THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := 'USD'; --P_TY_ATM_TXN_REC.txn_ccy_code--As per Long Sina, Credit Card account should be USD
      END IF;
    --Sampath Credit Card Currency Should be USD ends

      --sampath ends

      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
      DBG('L_ACC_CCY=' || L_ACC_CCY);
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);

      --sampath starts for cash deposit exchange rate column in acc entry
      IF P_TY_ATM_TXN_REC.fc_literal = 'CDP' AND
         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY <>
         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY AND
         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY = 'USD' AND
         P_TY_ATM_TXN_REC.OFFUS_ONUS = 'O' THEN

        BEGIN

          SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
            INTO P_TY_ATM_TXN_REC.RATE_CODE, P_TY_ATM_TXN_REC.RATE_TYPE
            FROM CSTMS_PRODUCT
           WHERE PRODUCT_CODE = P_TY_ATM_TXN_REC.PRODUCT_CODE
             AND MODULE = 'RT'
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ERR_CODE := 'SW-PRD-01';
            DBG('E',
                'NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
                P_ERR_PARAM);
            RETURN FALSE;
        END;

        IF NOT CYPKSS.FN_GETRATE(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                                 P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                 P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY,
                                 P_TY_ATM_TXN_REC.RATE_TYPE,
                                 P_TY_ATM_TXN_REC.RATE_CODE,
                                 P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT,
                                 P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT,
                                 P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          RETURN FALSE;
        END IF;

        --P_TY_RTUPLD.TY_UPLD_RTL_TELLER.EXCH_RATE := P_TY_ATM_TXN_REC.X_RATE_DERIVED;
        DBG('P_TY_ATM_TXN_REC.X_RATE_DERIVED P_TY_ATM_TXN_REC.X_RATE_DERIVED=' ||
            P_TY_ATM_TXN_REC.X_RATE_DERIVED);
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.EXCH_RATE := P_TY_ATM_TXN_REC.X_RATE_DERIVED;
      END IF;
      --sampath ends for cash deposit exchange rate column in acc entry ends

      --sampath starts for cash withdrawal exchange rate column in acc entry
      IF P_TY_ATM_TXN_REC.fc_literal = 'CAW' AND
         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY <>
         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY AND
         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY = 'USD' AND
         P_TY_ATM_TXN_REC.OFFUS_ONUS = 'O' THEN

        BEGIN

          SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
            INTO P_TY_ATM_TXN_REC.RATE_CODE, P_TY_ATM_TXN_REC.RATE_TYPE
            FROM CSTMS_PRODUCT
           WHERE PRODUCT_CODE = P_TY_ATM_TXN_REC.PRODUCT_CODE
             AND MODULE = 'RT'
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ERR_CODE := 'SW-PRD-01';
            DBG('E',
                'NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
                P_ERR_PARAM);
            RETURN FALSE;
        END;

        IF NOT CYPKSS.FN_GETRATE(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                                 P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY,
                                 P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,

                                 P_TY_ATM_TXN_REC.RATE_TYPE,
                                 P_TY_ATM_TXN_REC.RATE_CODE,
                                 P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT,
                                 P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT,
                                 P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          RETURN FALSE;
        END IF;

        --P_TY_RTUPLD.TY_UPLD_RTL_TELLER.EXCH_RATE := P_TY_ATM_TXN_REC.X_RATE_DERIVED;
        DBG('P_TY_ATM_TXN_REC.X_RATE_DERIVED P_TY_ATM_TXN_REC.X_RATE_DERIVED=' ||
            P_TY_ATM_TXN_REC.X_RATE_DERIVED);
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.EXCH_RATE := P_TY_ATM_TXN_REC.X_RATE_DERIVED;
      END IF;
      --sampath ends for cash withdrawal exchange rate column in acc entry ends

      IF NOT FN_IS_GL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC,
                      L_ACC_CCY) AND
         L_ACC_CCY <> P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY AND
         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT IS NOT NULL AND
         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC IS NOT NULL THEN
        BEGIN

          SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
            INTO P_TY_ATM_TXN_REC.RATE_CODE, P_TY_ATM_TXN_REC.RATE_TYPE
            FROM CSTMS_PRODUCT
           WHERE PRODUCT_CODE = P_TY_ATM_TXN_REC.PRODUCT_CODE
             AND MODULE = 'RT'
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ERR_CODE := 'SW-PRD-01';
            DBG('E',
                'NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
                P_ERR_PARAM);
            RETURN FALSE;
        END;
		
		IF  L_ACC_CCY = 'KHR' AND P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL = 'DMC'
          AND  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY = 'USD' AND P_TY_ATM_TXN_REC.BILL_CCY_DERIVED = 'USD'
          AND P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY = 'USD'
          AND  P_TY_ATM_TXN_REC.msg_type = '1220' THEN --sampath cardless withdrawal
		
		IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                                      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY,
                                      L_ACC_CCY,
                                      P_TY_ATM_TXN_REC.RATE_TYPE,
                                      'S'
                                      
                                     ,
                                      NVL(p_ty_atm_txn_rec.txn_amt_derived,P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT)
                                      
                                     ,
                                      'Y',
                                      L_ACC_AMT,
                                      P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                      P_ERR_CODE) THEN
          P_ERR_CODE  := 'SW-AMT-01';
          P_ERR_PARAM := P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY || '~' ||
                         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT;
          DBG('E',
              'fn_amount_derive : Calling cypks.fn_amt1_to_amt2 failed ' ||
              P_ERR_CODE || '~' || P_ERR_PARAM);
          RETURN FALSE;
        END IF;
          
        ELSE --sampath cardless withdrawal
		
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                                      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY,
                                      L_ACC_CCY,
                                      P_TY_ATM_TXN_REC.RATE_TYPE,
                                      P_TY_ATM_TXN_REC.RATE_CODE

                                     ,
                                      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT

                                     ,
                                      'Y',
                                      L_ACC_AMT,
                                      P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                      P_ERR_CODE) THEN
          P_ERR_CODE  := 'SW-AMT-01';
          P_ERR_PARAM := P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY || '~' ||
                         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT;
          DBG('E',
              'fn_amount_derive : Calling cypks.fn_amt1_to_amt2 failed ' ||
              P_ERR_CODE || '~' || P_ERR_PARAM);
          RETURN FALSE;
        END IF;
		END IF; --sampath cardless withdrawal

        DBG('P_TY_ATM_TXN_REC.X_RATE_DERIVED2=' ||
            P_TY_ATM_TXN_REC.X_RATE_DERIVED);

        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT := L_ACC_AMT;
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY    := L_ACC_CCY;
      END IF;

      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
      DBG('L_ACC_CCY=' || L_ACC_CCY);
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY);

      DBG('P_TY_ATM_TXN_REC.proc_code FINAL=' ||
          P_TY_ATM_TXN_REC.proc_code);

      --sampath starts for account limit per day cardless deposit
     IF SUBSTR(P_TY_ATM_TXN_REC.proc_code, 1, 2) = '21' /*AND
                                                                     P_TY_ATM_TXN_REC.PAN = '7777777XXXXXXXXXX'*/
       THEN

        DBG('INSIDE CARDLESS DEPOSIT');

        DBG('P_TY_ATM_TXN_REC.txn_acc_no_fcc=' ||
            P_TY_ATM_TXN_REC.txn_acc_no_fcc);
        DBG('P_TY_ATM_TXN_REC.TXN_AMT_DERIVED=' ||
            P_TY_ATM_TXN_REC.TXN_AMT_DERIVED);
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY);
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);
        DBG('P_TY_ATM_TXN_REC.OFFUS_ONUS=' || P_TY_ATM_TXN_REC.OFFUS_ONUS);
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH);

        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := L_ACC_CCY;

        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);

        DBG('P_TY_ATM_TXN_REC.fc_literal=' || P_TY_ATM_TXN_REC.fc_literal);

        --sampath starts for cash deposit exchange rate column in acc entry
        IF P_TY_ATM_TXN_REC.fc_literal = 'CDP' AND
           P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY <>
           P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY AND
           P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY = 'KHR' AND  --KHR AMOUNT COMING IN SWITCH
           P_TY_ATM_TXN_REC.OFFUS_ONUS = 'O' THEN

          dbg('inside else condition100');
          dbg('amount coming in switch is KHR nothing but ofs_ccy');
          dbg('amount currency in switch is KHR nothing but txn_amount_Derived');
          dbg('account currency is USD');

          BEGIN

            SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
              INTO P_TY_ATM_TXN_REC.RATE_CODE, P_TY_ATM_TXN_REC.RATE_TYPE
              FROM CSTMS_PRODUCT
             WHERE PRODUCT_CODE = P_TY_ATM_TXN_REC.PRODUCT_CODE
               AND MODULE = 'RT'
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERR_CODE := 'SW-PRD-01';
              DBG('E',
                  'NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
                  P_ERR_PARAM);
              RETURN FALSE;
          END;

          --Get Rate
          IF NOT CYPKSS.FN_GETRATE(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                                   P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY, --KHR currency coming in switch
                                   P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY, --USD account ccy
                                   P_TY_ATM_TXN_REC.RATE_TYPE,
                                   P_TY_ATM_TXN_REC.RATE_CODE,
                                   P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT,
                                   P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT,
                                   P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                   L_RATE_FLAG,
                                   P_ERR_CODE) THEN
            RETURN FALSE;
          END IF;

          DBG('P_TY_ATM_TXN_REC.X_RATE_DERIVED=' ||
              P_TY_ATM_TXN_REC.X_RATE_DERIVED);

          --Get USD Amount
          IF NOT cypkss.fn_amt1_to_amt2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY, --KHR currency coming in switch
                                        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY, --USD account ccy
                                        P_TY_ATM_TXN_REC.RATE_TYPE,
                                        'S',
                                        --P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                        P_TY_ATM_TXN_REC.txn_amt_derived, --khr amount coming in switch
                                        'Y',
                                        l_txn_amt,
                                        P_TY_ATM_TXN_REC.X_RATE_DERIVED, -- l_rate,
                                        P_ERR_PARAM) THEN
            debug.pr_debug('**', '');
            debug.pr_debug('**', SQLERRM);
            p_err_code  := 'ST-OTHR-001';
            P_ERR_PARAM := NULL;
            RETURN FALSE;
          END IF;

          --P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := L_TXN_AMT;

          DBG('P_TY_ATM_TXN_REC.TXN_AMT_DERIVED FINAL=' || L_TXN_AMT); --THIS IS USD AMOUNT

          --sampath ends for cash deposit exchange rate column in acc entry ends

          BEGIN

            SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
              INTO L_AMOUNT
              FROM ACTB_DAILY_LOG A, SWTB_TXN_LOG B
             WHERE A.TRN_REF_NO = B.TRN_REF_NO
               AND AC_NO = P_TY_ATM_TXN_REC.txn_acc_no_fcc
               AND CUST_GL = 'A'
               AND AUTH_STAT = 'A'
               AND USER_ID = 'FLEXSWITCH'
               AND MODULE = 'RT'
               AND DRCR_IND = 'C'
                  --AND B.PAN = '7777777XXXXXXXXXX'
               AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'APOD'
               AND A.EVENT NOT IN ('CYPO', 'REVR')
               AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

          EXCEPTION
            WHEN OTHERS THEN
              L_AMOUNT := 0;
          END;

          DBG('L_AMOUNT==' || L_AMOUNT);

          --L_AMOUNT1 := (L_AMOUNT / P_TY_ATM_TXN_REC.X_RATE_DERIVED) + L_TXN_AMT;

          L_AMOUNT1 := L_AMOUNT + L_TXN_AMT;

          DBG('SUM=' || L_AMOUNT1);

          IF 9000 - L_AMOUNT1 < 0 THEN
            P_ERR_CODE := 'SW-LMAMT-01';
            RETURN FALSE;
          END IF;

        ELSIF P_TY_ATM_TXN_REC.fc_literal = 'CDP' AND
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY <>
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY AND
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY = 'USD' AND  --USD AMOUNT COMING IN SWITCH
              P_TY_ATM_TXN_REC.OFFUS_ONUS = 'O' THEN

          dbg('inside else condition101');
          dbg('amount coming in switch is usd nothing but ofs_ccy');
          dbg('amount currency in switch is usd nothing but txn_amount_Derived');
          dbg('account currency is khr');

          BEGIN

            SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
              INTO L_AMOUNT
              FROM ACTB_DAILY_LOG A, SWTB_TXN_LOG B
             WHERE A.TRN_REF_NO = B.TRN_REF_NO
               AND AC_NO = P_TY_ATM_TXN_REC.txn_acc_no_fcc
               AND CUST_GL = 'A'
               AND AUTH_STAT = 'A'
               AND USER_ID = 'FLEXSWITCH'
               AND MODULE = 'RT'
               AND DRCR_IND = 'C'
                  --AND B.PAN = '7777777XXXXXXXXXX'
               AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'APOD'
               AND A.EVENT NOT IN ('CYPO', 'REVR')
               AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

          EXCEPTION
            WHEN OTHERS THEN
              L_AMOUNT := 0;
          END;

          DBG('L_AMOUNT==' || L_AMOUNT);

          DBG('P_TY_ATM_TXN_REC.TXN_AMT_DERIVED==' ||
              P_TY_ATM_TXN_REC.TXN_AMT_DERIVED);

          L_AMOUNT1 := (L_AMOUNT /* / P_TY_ATM_TXN_REC.X_RATE_DERIVED*/
                       ) + P_TY_ATM_TXN_REC.TXN_AMT_DERIVED;

          DBG('SUM=' || L_AMOUNT1);

          IF 9000 - L_AMOUNT1 < 0 THEN
            P_ERR_CODE := 'SW-LMAMT-01';
            RETURN FALSE;
          END IF;

        ELSE

          dbg('inside final else condition');

          BEGIN

            SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
              INTO L_AMOUNT
              FROM ACTB_DAILY_LOG A, SWTB_TXN_LOG B
             WHERE A.TRN_REF_NO = B.TRN_REF_NO
               AND AC_NO = P_TY_ATM_TXN_REC.txn_acc_no_fcc
               AND CUST_GL = 'A'
               AND AUTH_STAT = 'A'
               AND USER_ID = 'FLEXSWITCH'
               AND MODULE = 'RT'
               AND DRCR_IND = 'C'
                  --AND B.PAN = '7777777XXXXXXXXXX'
               AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'APOD'
               AND A.EVENT NOT IN ('CYPO', 'REVR')
               AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

          EXCEPTION
            WHEN OTHERS THEN
              L_AMOUNT := 0;
          END;

          DBG('L_AMOUNT==' || L_AMOUNT);

          DBG('P_TY_ATM_TXN_REC.TXN_AMT_DERIVED==' ||
              P_TY_ATM_TXN_REC.TXN_AMT_DERIVED);

          --Get Rate
          IF NOT CYPKSS.FN_GETRATE(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                                   P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY, --KHR currency coming in switch
                                   'USD', --USD account ccy
                                   P_TY_ATM_TXN_REC.RATE_TYPE,
                                   P_TY_ATM_TXN_REC.RATE_CODE,
                                   P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT,
                                   P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT,
                                   P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                   L_RATE_FLAG,
                                   P_ERR_CODE) THEN
            RETURN FALSE;
          END IF;

          DBG('P_TY_ATM_TXN_REC.X_RATE_DERIVED=' ||
              P_TY_ATM_TXN_REC.X_RATE_DERIVED);

          IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY =
             P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY AND
             P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY = 'KHR' THEN

            DBG('Inside If condition of apple');

            L_AMOUNT1 := (L_AMOUNT) + (P_TY_ATM_TXN_REC.TXN_AMT_DERIVED /
                         P_TY_ATM_TXN_REC.X_RATE_DERIVED);

          ELSE

            L_AMOUNT1 := (L_AMOUNT) + P_TY_ATM_TXN_REC.TXN_AMT_DERIVED;

          END IF;

          DBG('SUM=' || L_AMOUNT1);

          IF 9000 - L_AMOUNT1 < 0 THEN
            P_ERR_CODE := 'SW-LMAMT-01';
            RETURN FALSE;
          END IF;

          /*ELSIF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY = 'KHR' AND
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY =
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY THEN

          DBG('INSIDE ELSE CONDITION');
          --Get Rate
          IF NOT CYPKSS.FN_GETRATE(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                                   P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                   'USD',
                                   P_TY_ATM_TXN_REC.RATE_TYPE,
                                   P_TY_ATM_TXN_REC.RATE_CODE,
                                   P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT,
                                   P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT,
                                   P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                   L_RATE_FLAG,
                                   P_ERR_CODE) THEN
            RETURN FALSE;
          END IF;

          DBG('P_TY_ATM_TXN_REC.X_RATE_DERIVED=' ||
              P_TY_ATM_TXN_REC.X_RATE_DERIVED);

          --Get USD Amount
          IF NOT cypkss.fn_amt1_to_amt2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                        'USD',
                                        P_TY_ATM_TXN_REC.RATE_TYPE,
                                        'S',
                                        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                        'Y',
                                        l_txn_amt,
                                        P_TY_ATM_TXN_REC.X_RATE_DERIVED, -- l_rate,
                                        P_ERR_PARAM) THEN
            debug.pr_debug('**', '');
            debug.pr_debug('**', SQLERRM);
            p_err_code  := 'ST-OTHR-001';
            P_ERR_PARAM := NULL;
            RETURN FALSE;
          END IF;

          DBG('P_TY_ATM_TXN_REC.TXN_AMT_DERIVED FINAL=' || l_txn_amt);

          --sampath ends for cash deposit exchange rate column in acc entry ends

          BEGIN

            SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
              INTO L_AMOUNT
              FROM ACTB_DAILY_LOG A, SWTB_TXN_LOG B
             WHERE A.TRN_REF_NO = B.TRN_REF_NO
               AND AC_NO = P_TY_ATM_TXN_REC.txn_acc_no_fcc
               AND CUST_GL = 'A'
               AND AUTH_STAT = 'A'
               AND USER_ID = 'FLEXSWITCH'
               AND MODULE = 'RT'
               AND DRCR_IND = 'C'
                  --AND B.PAN = '7777777XXXXXXXXXX'
               AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'APOD'
               AND A.EVENT NOT IN ('CYPO', 'REVR')
               AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

          EXCEPTION
            WHEN OTHERS THEN
              L_AMOUNT := 0;
          END;

          DBG('L_AMOUNT==' || L_AMOUNT);

          L_AMOUNT1 := L_AMOUNT + l_txn_amt;

          DBG('SUM=' || L_AMOUNT1);

          IF 9000 - L_AMOUNT1 < 0 THEN
            P_ERR_CODE := 'SW-LMAMT-01';
            RETURN FALSE;
          END IF;*/

        END IF;

      END IF;


      --sampath ends for account limit per day cardless deposit



      IF NOT FN_IS_GL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH,
                      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC,
                      L_ACC_CCY) AND
         L_ACC_CCY <> P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY AND
         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT IS NOT NULL AND
         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC IS NOT NULL THEN
        BEGIN

          SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
            INTO P_TY_ATM_TXN_REC.RATE_CODE, P_TY_ATM_TXN_REC.RATE_TYPE
            FROM CSTMS_PRODUCT
           WHERE PRODUCT_CODE = P_TY_ATM_TXN_REC.PRODUCT_CODE
             AND MODULE = 'RT'
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ERR_CODE := 'SW-PRD-01';
            DBG('E',
                'NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
                P_ERR_PARAM);
            RETURN FALSE;
        END;

        IF NOT CYPKS.FN_AMT1_TO_AMT2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH,
                                     P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                     L_ACC_CCY,
                                     P_TY_ATM_TXN_REC.RATE_TYPE,
                                     P_TY_ATM_TXN_REC.RATE_CODE

                                    ,
                                     P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT

                                    ,
                                     'Y',
                                     L_ACC_AMT,
                                     P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                     P_ERR_CODE) THEN
          P_ERR_CODE  := 'SW-AMT-01';
          P_ERR_PARAM := P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY || '~' ||
                         P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT;
          DBG('E',
              'fn_amount_derive : Calling cypks.fn_amt1_to_amt2 failed ' ||
              P_ERR_CODE || '~' || P_ERR_PARAM);
          RETURN FALSE;
        END IF;

        DBG('E',
            'p_ty_rtupld.ty_upld_rtl_teller.ofs_amount~' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT);
        DBG('E', 'l_acc_amt~' || L_ACC_AMT);
        DBG('E', 'l_acc_ccy~' || L_ACC_CCY);

        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := L_ACC_AMT;
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY    := L_ACC_CCY;
      END IF;

      IF NOT SWPKSS_FINHANDLER.FN_MAPPING_CHARGES(P_TY_ATM_TXN_REC,
                                                  P_TY_RTUPLD,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAM) THEN
        DBG('E',
            'Failed while calling swpkss_finhandler.fn_mapping_charges' ||
            P_ERR_CODE);
        RETURN FALSE;
      END IF;

    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_POST_PROCESS_SWRTTXN(P_TY_ATM_TXN_REC,
                                                             P_TY_RTUPLD,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
        DBG('E',
            'gwpks_ext_switchservice.Fn_Process_rttxn returned false ');
        RETURN FALSE;
      END IF;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('E', 'FROM fn_process ' || SQLERRM);
      P_ERR_CODE := 'SW-RTT-04';

      RETURN FALSE;

  END FN_PROCESS;

  FUNCTION FN_COPY_BASE_TO_UPLOAD(P_TY_RETAILTLR_UPD IN DETBS_RTL_TELLER%ROWTYPE,
                                  P_TY_RETAIL_TELLER OUT DETBS_UPLOAD_RTL_TELLER%ROWTYPE,
                                  P_CHG_TBL          IN OUT DEPKSS_RETAILTELLERUPLOAD.TYP_TBLCHGDETS,
                                  P_ERR_CODE         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN
    DBG('in fn_copy_upload_to_base');
    P_TY_RETAIL_TELLER.XREF               := P_TY_RETAILTLR_UPD.XREF;
    P_TY_RETAIL_TELLER.PRODUCT_CODE       := P_TY_RETAILTLR_UPD.PRODUCT_CODE;
    P_TY_RETAIL_TELLER.BRANCH_CODE        := P_TY_RETAILTLR_UPD.BRANCH_CODE;
    P_TY_RETAIL_TELLER.TRN_REF_NO         := P_TY_RETAILTLR_UPD.TRN_REF_NO;
    P_TY_RETAIL_TELLER.TXN_ACC            := P_TY_RETAILTLR_UPD.TXN_ACC;
    P_TY_RETAIL_TELLER.TXN_CCY            := P_TY_RETAILTLR_UPD.TXN_CCY;
    P_TY_RETAIL_TELLER.TXN_AMOUNT         := P_TY_RETAILTLR_UPD.TXN_AMOUNT;
    P_TY_RETAIL_TELLER.TXN_BRANCH         := P_TY_RETAILTLR_UPD.TXN_BRANCH;
    P_TY_RETAIL_TELLER.TXN_TRN_CODE       := P_TY_RETAILTLR_UPD.TXN_TRN_CODE;
    P_TY_RETAIL_TELLER.OFS_ACC            := P_TY_RETAILTLR_UPD.OFS_ACC;
    P_TY_RETAIL_TELLER.OFS_CCY            := P_TY_RETAILTLR_UPD.OFS_CCY;
    P_TY_RETAIL_TELLER.OFS_AMOUNT         := P_TY_RETAILTLR_UPD.OFS_AMOUNT;
    P_TY_RETAIL_TELLER.OFS_BRANCH         := P_TY_RETAILTLR_UPD.OFS_BRANCH;
    P_TY_RETAIL_TELLER.OFS_TRN_CODE       := P_TY_RETAILTLR_UPD.OFS_TRN_CODE;
    P_TY_RETAIL_TELLER.EXCH_RATE          := P_TY_RETAILTLR_UPD.EXCH_RATE;
    P_TY_RETAIL_TELLER.LCY_AMOUNT         := P_TY_RETAILTLR_UPD.LCY_AMOUNT;
    P_TY_RETAIL_TELLER.TRN_DT             := P_TY_RETAILTLR_UPD.TRN_DT;
    P_TY_RETAIL_TELLER.VALUE_DT           := P_TY_RETAILTLR_UPD.VALUE_DT;
    P_TY_RETAIL_TELLER.DR_INSTRUMENT_CODE := P_TY_RETAILTLR_UPD.DR_INSTRUMENT_CODE;
    P_TY_RETAIL_TELLER.CR_INSTRUMENT_CODE := P_TY_RETAILTLR_UPD.CR_INSTRUMENT_CODE;
    P_TY_RETAIL_TELLER.REL_CUSTOMER       := P_TY_RETAILTLR_UPD.REL_CUSTOMER;
    P_TY_RETAIL_TELLER.CHARGE_ACCOUNT     := P_TY_RETAILTLR_UPD.CHARGE_ACCOUNT;
    P_TY_RETAIL_TELLER.CHG_GL             := P_TY_RETAILTLR_UPD.CHG_GL;
    P_TY_RETAIL_TELLER.CHG_CCY            := P_TY_RETAILTLR_UPD.CHG_CCY;
    P_TY_RETAIL_TELLER.CHG_AMT            := P_TY_RETAILTLR_UPD.CHG_AMT;
    P_TY_RETAIL_TELLER.CHG_IN_ACY         := P_TY_RETAILTLR_UPD.CHG_IN_ACY;
    P_TY_RETAIL_TELLER.CHG_IN_LCY         := P_TY_RETAILTLR_UPD.CHG_IN_LCY;
    P_TY_RETAIL_TELLER.CHG_CCY_ACY_RATE   := P_TY_RETAILTLR_UPD.CHG_CCY_ACY_RATE;
    P_TY_RETAIL_TELLER.ACY_LCY_RATE       := P_TY_RETAILTLR_UPD.ACY_LCY_RATE;
    P_TY_RETAIL_TELLER.NETTING_IND        := P_TY_RETAILTLR_UPD.NETTING_IND;
    P_TY_RETAIL_TELLER.TXN_CODE           := P_TY_RETAILTLR_UPD.TXN_CODE;
    P_TY_RETAIL_TELLER.MIS_HEAD_1         := P_TY_RETAILTLR_UPD.MIS_HEAD_1;
    P_TY_RETAIL_TELLER.CHG_GL_1           := P_TY_RETAILTLR_UPD.CHG_GL_1;
    P_TY_RETAIL_TELLER.CHG_CCY_1          := P_TY_RETAILTLR_UPD.CHG_CCY_1;
    P_TY_RETAIL_TELLER.CHG_AMT_1          := P_TY_RETAILTLR_UPD.CHG_AMT_1;
    P_TY_RETAIL_TELLER.CHG_IN_ACY_1       := P_TY_RETAILTLR_UPD.CHG_IN_ACY_1;
    P_TY_RETAIL_TELLER.CHG_IN_LCY_1       := P_TY_RETAILTLR_UPD.CHG_IN_LCY_1;
    P_TY_RETAIL_TELLER.CHG_CCY_ACY_RATE_1 := P_TY_RETAILTLR_UPD.CHG_CCY_ACY_RATE_1;
    P_TY_RETAIL_TELLER.ACY_LCY_RATE_1     := P_TY_RETAILTLR_UPD.ACY_LCY_RATE_1;
    P_TY_RETAIL_TELLER.NETTING_IND_1      := P_TY_RETAILTLR_UPD.NETTING_IND_1;
    P_TY_RETAIL_TELLER.TXN_CODE_1         := P_TY_RETAILTLR_UPD.TXN_CODE_1;
    P_TY_RETAIL_TELLER.MIS_HEAD_2         := P_TY_RETAILTLR_UPD.MIS_HEAD_2;
    P_TY_RETAIL_TELLER.CHG_GL_2           := P_TY_RETAILTLR_UPD.CHG_GL_2;
    P_TY_RETAIL_TELLER.CHG_CCY_2          := P_TY_RETAILTLR_UPD.CHG_CCY_2;
    P_TY_RETAIL_TELLER.CHG_AMT_2          := P_TY_RETAILTLR_UPD.CHG_AMT_2;
    P_TY_RETAIL_TELLER.CHG_IN_ACY_2       := P_TY_RETAILTLR_UPD.CHG_IN_ACY_2;
    P_TY_RETAIL_TELLER.CHG_IN_LCY_2       := P_TY_RETAILTLR_UPD.CHG_IN_LCY_2;
    P_TY_RETAIL_TELLER.CHG_CCY_ACY_RATE_2 := P_TY_RETAILTLR_UPD.CHG_CCY_ACY_RATE_2;
    P_TY_RETAIL_TELLER.ACY_LCY_RATE_2     := P_TY_RETAILTLR_UPD.ACY_LCY_RATE_2;
    P_TY_RETAIL_TELLER.NETTING_IND_2      := P_TY_RETAILTLR_UPD.NETTING_IND_2;
    P_TY_RETAIL_TELLER.TXN_CODE_2         := P_TY_RETAILTLR_UPD.TXN_CODE_2;
    P_TY_RETAIL_TELLER.MIS_HEAD_3         := P_TY_RETAILTLR_UPD.MIS_HEAD_3;
    P_TY_RETAIL_TELLER.CHG_GL_3           := P_TY_RETAILTLR_UPD.CHG_GL_3;
    P_TY_RETAIL_TELLER.CHG_CCY_3          := P_TY_RETAILTLR_UPD.CHG_CCY_3;
    P_TY_RETAIL_TELLER.CHG_AMT_3          := P_TY_RETAILTLR_UPD.CHG_AMT_3;
    P_TY_RETAIL_TELLER.CHG_IN_ACY_3       := P_TY_RETAILTLR_UPD.CHG_IN_ACY_3;
    P_TY_RETAIL_TELLER.CHG_IN_LCY_3       := P_TY_RETAILTLR_UPD.CHG_IN_LCY_3;
    P_TY_RETAIL_TELLER.CHG_CCY_ACY_RATE_3 := P_TY_RETAILTLR_UPD.CHG_CCY_ACY_RATE_3;
    P_TY_RETAIL_TELLER.ACY_LCY_RATE_3     := P_TY_RETAILTLR_UPD.ACY_LCY_RATE_3;
    P_TY_RETAIL_TELLER.NETTING_IND_3      := P_TY_RETAILTLR_UPD.NETTING_IND_3;
    P_TY_RETAIL_TELLER.TXN_CODE_3         := P_TY_RETAILTLR_UPD.TXN_CODE_3;
    P_TY_RETAIL_TELLER.MIS_HEAD_4         := P_TY_RETAILTLR_UPD.MIS_HEAD_4;
    P_TY_RETAIL_TELLER.CHG_GL_4           := P_TY_RETAILTLR_UPD.CHG_GL_4;
    P_TY_RETAIL_TELLER.CHG_CCY_4          := P_TY_RETAILTLR_UPD.CHG_CCY_4;
    P_TY_RETAIL_TELLER.CHG_AMT_4          := P_TY_RETAILTLR_UPD.CHG_AMT_4;
    P_TY_RETAIL_TELLER.CHG_IN_ACY_4       := P_TY_RETAILTLR_UPD.CHG_IN_ACY_4;
    P_TY_RETAIL_TELLER.CHG_IN_LCY_4       := P_TY_RETAILTLR_UPD.CHG_IN_LCY_4;
    P_TY_RETAIL_TELLER.CHG_CCY_ACY_RATE_4 := P_TY_RETAILTLR_UPD.CHG_CCY_ACY_RATE_4;
    P_TY_RETAIL_TELLER.ACY_LCY_RATE_4     := P_TY_RETAILTLR_UPD.ACY_LCY_RATE_4;
    P_TY_RETAIL_TELLER.NETTING_IND_4      := P_TY_RETAILTLR_UPD.NETTING_IND_4;
    P_TY_RETAIL_TELLER.TXN_CODE_4         := P_TY_RETAILTLR_UPD.TXN_CODE_4;
    P_TY_RETAIL_TELLER.MIS_HEAD_5         := P_TY_RETAILTLR_UPD.MIS_HEAD_5;
    P_TY_RETAIL_TELLER.REM_ACC            := P_TY_RETAILTLR_UPD.REM_ACC;
    P_TY_RETAIL_TELLER.REM_BANK           := P_TY_RETAILTLR_UPD.REM_BANK;
    P_TY_RETAIL_TELLER.REM_BRANCH         := P_TY_RETAILTLR_UPD.REM_BRANCH;
    P_TY_RETAIL_TELLER.ROUTING_NO         := P_TY_RETAILTLR_UPD.ROUTING_NO;
    P_TY_RETAIL_TELLER.END_POINT          := P_TY_RETAILTLR_UPD.END_POINT;
    P_TY_RETAIL_TELLER.SERIAL_NO          := P_TY_RETAILTLR_UPD.SERIAL_NO;
    P_TY_RETAIL_TELLER.RECORD_STAT        := P_TY_RETAILTLR_UPD.RECORD_STAT;
    P_TY_RETAIL_TELLER.AUTH_STAT          := P_TY_RETAILTLR_UPD.AUTH_STAT;
    P_TY_RETAIL_TELLER.MAKER_ID           := P_TY_RETAILTLR_UPD.MAKER_ID;
    P_TY_RETAIL_TELLER.MAKER_DT_STAMP     := P_TY_RETAILTLR_UPD.MAKER_DT_STAMP;
    P_TY_RETAIL_TELLER.CHECKER_ID         := P_TY_RETAILTLR_UPD.CHECKER_ID;
    P_TY_RETAIL_TELLER.CHECKER_DT_STAMP   := P_TY_RETAILTLR_UPD.CHECKER_DT_STAMP;
    P_TY_RETAIL_TELLER.REPAIR_REASON      := P_TY_RETAILTLR_UPD.REPAIR_REASON;
    P_TY_RETAIL_TELLER.MOD_NO             := P_TY_RETAILTLR_UPD.MOD_NO;
    P_TY_RETAIL_TELLER.SCODE              := P_TY_RETAILTLR_UPD.SCODE;
    P_TY_RETAIL_TELLER.MIS_HEAD           := P_TY_RETAILTLR_UPD.MIS_HEAD;
    P_TY_RETAIL_TELLER.NARRATIVE          := P_TY_RETAILTLR_UPD.NARRATIVE;
    P_TY_RETAIL_TELLER.DR_ACC             := P_TY_RETAILTLR_UPD.DR_ACC;
    P_TY_RETAIL_TELLER.MODULE             := P_TY_RETAILTLR_UPD.MODULE;
    P_TY_RETAIL_TELLER.ESN                := P_TY_RETAILTLR_UPD.ESN;
    P_TY_RETAIL_TELLER.EVENT_CODE         := P_TY_RETAILTLR_UPD.EVENT_CODE;
    P_TY_RETAIL_TELLER.ROUTE_CODE         := P_TY_RETAILTLR_UPD.ROUTE_CODE;
    P_TY_RETAIL_TELLER.FT_PROBLEM         := P_TY_RETAILTLR_UPD.FT_PROBLEM;
    P_TY_RETAIL_TELLER.TRACK_RECEIVABLE   := P_TY_RETAILTLR_UPD.TRACK_RECEIVABLE;
    P_TY_RETAIL_TELLER.TIME_RECEIVED      := P_TY_RETAILTLR_UPD.TIME_RECEIVED;
    P_TY_RETAIL_TELLER.THEIR_CHGS2        := P_TY_RETAILTLR_UPD.THEIR_CHGS2;
    P_TY_RETAIL_TELLER.THEIR_CHGS3        := P_TY_RETAILTLR_UPD.THEIR_CHGS3;
    P_TY_RETAIL_TELLER.THEIR_CHGS4        := P_TY_RETAILTLR_UPD.THEIR_CHGS4;
    P_TY_RETAIL_TELLER.THEIR_CHGS         := P_TY_RETAILTLR_UPD.THEIR_CHGS;
    P_TY_RETAIL_TELLER.THEIR_CHGS1        := P_TY_RETAILTLR_UPD.THEIR_CHGS1;
    P_TY_RETAIL_TELLER.THEIR_ACC          := P_TY_RETAILTLR_UPD.THEIR_ACC;
    P_TY_RETAIL_TELLER.THEIR_ACC1         := P_TY_RETAILTLR_UPD.THEIR_ACC1;
    P_TY_RETAIL_TELLER.THEIR_ACC2         := P_TY_RETAILTLR_UPD.THEIR_ACC2;
    P_TY_RETAIL_TELLER.THEIR_ACC3         := P_TY_RETAILTLR_UPD.THEIR_ACC3;
    P_TY_RETAIL_TELLER.THEIR_ACC4         := P_TY_RETAILTLR_UPD.THEIR_ACC4;
    P_TY_RETAIL_TELLER.LCY_EXCH_RATE      := P_TY_RETAILTLR_UPD.LCY_EXCH_RATE;
    P_TY_RETAIL_TELLER.TOT_CHG_IN_TCY     := P_TY_RETAILTLR_UPD.TOT_CHG_IN_TCY;
    P_TY_RETAIL_TELLER.CHG_DESC           := P_TY_RETAILTLR_UPD.CHG_DESC;
    P_TY_RETAIL_TELLER.CHG_DESC1          := P_TY_RETAILTLR_UPD.CHG_DESC1;
    P_TY_RETAIL_TELLER.CHG_DESC2          := P_TY_RETAILTLR_UPD.CHG_DESC2;
    P_TY_RETAIL_TELLER.CHG_DESC3          := P_TY_RETAILTLR_UPD.CHG_DESC3;
    P_TY_RETAIL_TELLER.CHG_DESC4          := P_TY_RETAILTLR_UPD.CHG_DESC4;
    P_TY_RETAIL_TELLER.CHG_TYPE           := P_TY_RETAILTLR_UPD.CHG_TYPE;
    P_TY_RETAIL_TELLER.CHG_TYPE1          := P_TY_RETAILTLR_UPD.CHG_TYPE1;
    P_TY_RETAIL_TELLER.CHG_TYPE2          := P_TY_RETAILTLR_UPD.CHG_TYPE2;
    P_TY_RETAIL_TELLER.CHG_TYPE3          := P_TY_RETAILTLR_UPD.CHG_TYPE3;
    P_TY_RETAIL_TELLER.CHG_TYPE4          := P_TY_RETAILTLR_UPD.CHG_TYPE4;
    P_TY_RETAIL_TELLER.WAIVER             := P_TY_RETAILTLR_UPD.WAIVER;
    P_TY_RETAIL_TELLER.WAIVER1            := P_TY_RETAILTLR_UPD.WAIVER1;
    P_TY_RETAIL_TELLER.WAIVER2            := P_TY_RETAILTLR_UPD.WAIVER2;
    P_TY_RETAIL_TELLER.WAIVER3            := P_TY_RETAILTLR_UPD.WAIVER3;
    P_TY_RETAIL_TELLER.WAIVER4            := P_TY_RETAILTLR_UPD.WAIVER4;
    P_TY_RETAIL_TELLER.LCY_CHG_EXCH_RATE  := P_TY_RETAILTLR_UPD.LCY_CHG_EXCH_RATE;
    P_TY_RETAIL_TELLER.LCY_CHG_EXCH_RATE1 := P_TY_RETAILTLR_UPD.LCY_CHG_EXCH_RATE1;
    P_TY_RETAIL_TELLER.LCY_CHG_EXCH_RATE2 := P_TY_RETAILTLR_UPD.LCY_CHG_EXCH_RATE2;
    P_TY_RETAIL_TELLER.LCY_CHG_EXCH_RATE3 := P_TY_RETAILTLR_UPD.LCY_CHG_EXCH_RATE3;
    P_TY_RETAIL_TELLER.LCY_CHG_EXCH_RATE4 := P_TY_RETAILTLR_UPD.LCY_CHG_EXCH_RATE4;

    P_CHG_TBL(1).COD_CHG_DESC := P_TY_RETAILTLR_UPD.CHG_DESC;
    P_CHG_TBL(1).COD_CHG_CCY := P_TY_RETAILTLR_UPD.CHG_CCY;
    P_CHG_TBL(1).CHG_AMT := P_TY_RETAILTLR_UPD.CHG_AMT;

    P_CHG_TBL(2).COD_CHG_DESC := P_TY_RETAILTLR_UPD.CHG_DESC1;
    P_CHG_TBL(2).COD_CHG_CCY := P_TY_RETAILTLR_UPD.CHG_CCY_1;
    P_CHG_TBL(2).CHG_AMT := P_TY_RETAILTLR_UPD.CHG_AMT_1;

    RETURN TRUE;
  EXCEPTION

    WHEN OTHERS THEN
      DBG('E', 'in fn_copy_base_to_upload ' || SQLERRM);
      P_ERR_CODE := 'SW-UPB-01';
      RETURN FALSE;

  END FN_COPY_BASE_TO_UPLOAD;

  FUNCTION FN_PROCESS_RT_TXN(P_TRN_REF_NO IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE,
                             P_ERR_CODE   IN OUT VARCHAR2,
                             P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_RT             DEPKSS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC;
    L_RTTELLER_TYP   DETBS_RTL_TELLER%ROWTYPE;
    L_SOURCE         VARCHAR2(15);
    L_REC_TXN_CTRL   GWPKSS_BRNTXN_CONTROL.TYP_TXN_CTRL;
    L_STATUS_ON_SAVE CHAR;
    L_FLAG           VARCHAR2(1);
    L_ERR_TBL        OVPKSS.TBL_ERROR;

    L_FN_CALL_ID           NUMBER;
    L_TB_CUSTOM_DATA       GLOBAL.TY_TB_CUSTOM_DATA;
    L_TB_CUSTOM_DATA_EMPTY GLOBAL.TY_TB_CUSTOM_DATA;

  BEGIN

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN

       (CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID     := 1;
      L_TB_CUSTOM_DATA := L_TB_CUSTOM_DATA_EMPTY;
      IF NOT
          SWPKS_RTTRANSACTION_CUSTOM.FN_PROCESS_RT_TXN_PRE(P_TRN_REF_NO,
                                                           L_FN_CALL_ID,
                                                           L_TB_CUSTOM_DATA,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN
        DBG('swpks_rttransaction.fn_process_rt_txn_pre ' || P_ERR_CODE);
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('inside fn_process_rt_txn');
      DBG('p_trn_ref_no --> ' || P_TRN_REF_NO);
      BEGIN
        SELECT *
          INTO L_RTTELLER_TYP
          FROM DETBS_RTL_TELLER
         WHERE TRN_REF_NO = P_TRN_REF_NO;

        DELETE FROM DETBS_RTL_TELLER WHERE TRN_REF_NO = P_TRN_REF_NO;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('E', 'no record found for this trn_ref_no !');
          P_ERR_CODE  := 'SW-NRT-01';
          P_ERR_PARAM := P_TRN_REF_NO;
          RETURN FALSE;

        WHEN OTHERS THEN
          DBG('E', 'in wot of process_txn with error :' || SQLERRM);
          P_ERR_CODE := 'SW-NRT-02';
          RETURN FALSE;
      END;

      DBG('Setting offset amount from 220 ');
      IF SWPKS_NETWORK_SETTLEMENT.G_OFS_AMOUNT IS NOT NULL THEN
        IF L_RTTELLER_TYP.OFS_AMOUNT <>
           SWPKS_NETWORK_SETTLEMENT.G_OFS_AMOUNT THEN
          L_RTTELLER_TYP.OFS_AMOUNT := SWPKS_NETWORK_SETTLEMENT.G_OFS_AMOUNT;
          DBG('successfully set offset amount from 220 ');
        END IF;
        SWPKS_NETWORK_SETTLEMENT.G_OFS_AMOUNT := NULL;
      END IF;

      DBG('Setting txn amount from 220 ');
      IF SWPKS_NETWORK_SETTLEMENT.G_TXN_AMOUNT IS NOT NULL THEN
        IF L_RTTELLER_TYP.TXN_AMOUNT <>
           SWPKS_NETWORK_SETTLEMENT.G_TXN_AMOUNT THEN
          L_RTTELLER_TYP.TXN_AMOUNT := SWPKS_NETWORK_SETTLEMENT.G_TXN_AMOUNT;
          DBG('successfully set txn amount from 220 ');
        END IF;
        SWPKS_NETWORK_SETTLEMENT.G_TXN_AMOUNT := NULL;
      ELSE

        L_RTTELLER_TYP.TXN_AMOUNT := NULL;
        DBG('successfully set txn amount to null');

      END IF;

      DBG('# swpks_network_settlement.g_ofs_ccy   ' ||
          SWPKS_NETWORK_SETTLEMENT.G_OFS_CCY);
      IF SWPKS_NETWORK_SETTLEMENT.G_OFS_CCY IS NOT NULL THEN
        IF L_RTTELLER_TYP.OFS_CCY <> SWPKS_NETWORK_SETTLEMENT.G_OFS_CCY THEN
          L_RTTELLER_TYP.OFS_CCY := SWPKS_NETWORK_SETTLEMENT.G_OFS_CCY;
          DBG('#  l_rtteller_typ.ofs_ccy    ' || L_RTTELLER_TYP.OFS_CCY);
        END IF;
        SWPKS_NETWORK_SETTLEMENT.G_OFS_CCY := NULL;
      END IF;
      DBG('# swpks_network_settlement.g_txn_ccy   ' ||
          SWPKS_NETWORK_SETTLEMENT.G_TXN_CCY);
      IF SWPKS_NETWORK_SETTLEMENT.G_TXN_CCY IS NOT NULL THEN
        IF L_RTTELLER_TYP.TXN_CCY <> SWPKS_NETWORK_SETTLEMENT.G_TXN_CCY THEN
          L_RTTELLER_TYP.TXN_CCY := SWPKS_NETWORK_SETTLEMENT.G_TXN_CCY;
          DBG('#  l_rtteller_typ.txn_ccy    ' || L_RTTELLER_TYP.TXN_CCY);
        END IF;
        SWPKS_NETWORK_SETTLEMENT.G_TXN_CCY := NULL;
      END IF;

      L_SOURCE := 'FLEXSWITCH';
      DBG('l_source --> ' || L_SOURCE);

      IF NOT FN_COPY_BASE_TO_UPLOAD(L_RTTELLER_TYP,
                                    L_RT.TY_UPLD_RTL_TELLER,
                                    L_RT.TBL_CHGDETS,
                                    P_ERR_CODE) THEN
        DBG('could not mapp the stuff properly');
        RETURN FALSE;
      END IF;

      IF NOT DEPKSS_RETAILTELLERUPLOAD.FN_UPLOAD(L_RT.TY_UPLD_RTL_TELLER,
                                                 L_RT.TBL_CHGDETS,
                                                 L_RT.TY_MISDETAILS,
                                                 L_RT.TBL_UDFDETAILS,
                                                 L_RT.TY_PCDETAILS,
                                                 L_RT.TY_MCKDETAILS,
                                                 L_RT.TY_MSGDETS,
                                                 L_RT.TBL_NODE,
                                                 L_SOURCE,
                                                 L_REC_TXN_CTRL.OVERRIDE_FLAG,
                                                 L_STATUS_ON_SAVE,
                                                 L_FLAG,
                                                 L_ERR_TBL) THEN
        DBG('E', 'call to fn_upload_failed');
        P_ERR_CODE := 'SW-NRT-03';

        FOR I IN 1 .. L_ERR_TBL.COUNT LOOP
          DBG('E', 'Error Found... ' || L_ERR_TBL(I).ERR_CODE);
          P_ERR_CODE := L_ERR_TBL(I).ERR_CODE;
        END LOOP;

        RETURN FALSE;
      END IF;

      DBG('rt txn passed succesfully');
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE := 'SW-PRT-04';
      RETURN FALSE;
  END FN_PROCESS_RT_TXN;

  FUNCTION FN_UNINITRTTXN(P_TY_ATM_TXN_REC IN OUT GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                          P_ERR_CODE       IN OUT VARCHAR2,
                          P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS

    ERROR_EXCEPTION EXCEPTION;
    L_TY_RTUPLD DEPKSS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC;
    L_SOURCE    VARCHAR2(15) := P_TY_ATM_TXN_REC.SOURCE;

  BEGIN

    DBG('Inside gwpks_switch_uninitrttxn.fn_main..sa');
    DBG('p_ty_atm_txn_rec.fc_literal :' || P_TY_ATM_TXN_REC.FC_LITERAL);

    DBG('Calling  fn_process');
    IF NOT
        FN_PROCESS(P_TY_ATM_TXN_REC, L_TY_RTUPLD, P_ERR_CODE, P_ERR_PARAM) THEN
      DBG('E',
          'Failed while calling Gwpks_CreateSWTransaction.fn_product_derive' ||
          P_ERR_CODE);
      P_ERR_CODE := 'SW-URT-01';
      RETURN FALSE;
    END IF;

    DBG('l_source:' || L_SOURCE);
    IF NOT DEPKSS_RETAILTELLERUPLOAD.FN_UNINITRTTXN(L_TY_RTUPLD.TY_UPLD_RTL_TELLER,
                                                    L_TY_RTUPLD.TBL_CHGDETS,
                                                    P_TY_ATM_TXN_REC.FC_LITERAL,
                                                    P_TY_ATM_TXN_REC.TRN_REF_NO_FCC,
                                                    P_ERR_CODE) THEN
      DBG('E',
          'Failed while calling depks_retailtellerupload.fn_upload' ||
          SQLCODE || '~' || P_ERR_CODE);
      IF NOT CHECK_ERROR(P_TY_ATM_TXN_REC, P_ERR_CODE) THEN
        DBG('E',
            'Failed while calling gwpks_switch_uninitrttxn.check_error' ||
            P_ERR_CODE);
        P_ERR_CODE := 'SW-ECH-01';
        RETURN FALSE;
      END IF;
      RETURN FALSE;
    END IF;
    DBG('p_ty_atm_txn_rec.trn_ref_no_fcc......... :' ||
        P_TY_ATM_TXN_REC.TRN_REF_NO_FCC);
    DBG('Calling swpkss_querybalance.........');
    IF P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'F' THEN
      IF NOT SWPKSS_QUERYBALANCE.FN_MAIN(P_TY_ATM_TXN_REC,
                                         P_ERR_CODE,
                                         P_ERR_PARAM) THEN
        DBG('E',
            'Failed while calling swpkss_querybalance.fn_main' ||
            P_ERR_CODE);
        P_ERR_CODE := 'SW-URT-03';
        RETURN FALSE;
      END IF;
    END IF;

    DBG('returning sucessful from  gwpks_switch_uninitrttxn.fn_main.........');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE := 'SW-URT-04';
      RETURN FALSE;
  END FN_UNINITRTTXN;

  FUNCTION FN_MAIN(P_TY_ATM_TXN_REC IN OUT NOCOPY GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                   P_ERR_CODE       IN OUT VARCHAR2,
                   P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS

    ERROR_EXCEPTION EXCEPTION;
    L_TY_RTUPLD      DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC;
    L_SOURCE         VARCHAR2(15) := P_TY_ATM_TXN_REC.SOURCE;
    L_ERR_TBL        OVPKSS.TBL_ERROR;
    L_REC_TXN_CTRL   GWPKS_BRNTXN_CONTROL.TYP_TXN_CTRL;
    L_STATUS_ON_SAVE CHAR;
    L_RET            NUMBER;

    L_SERIAL VARCHAR2(16);

    L_FN_CALL_ID           NUMBER;
    L_TB_CUSTOM_DATA       GLOBAL.TY_TB_CUSTOM_DATA;
    L_TB_CUSTOM_DATA_EMPTY GLOBAL.TY_TB_CUSTOM_DATA;

  BEGIN

    DBG('Inside swpks_rttransaction.fn_main..sa');
    DBG('p_ty_atm_txn_rec.fc_literal :' || P_TY_ATM_TXN_REC.FC_LITERAL);

    DBG('Calling  Gwpks_CreateSWTransaction.fn_product_derive');

    IF NOT
        FN_PROCESS(P_TY_ATM_TXN_REC, L_TY_RTUPLD, P_ERR_CODE, P_ERR_PARAM) THEN
      DBG('E',
          'Failed while calling Gwpks_CreateSWTransaction.fn_product_derive' ||
          P_ERR_CODE);
      RETURN FALSE;
    END IF;

    DBG('l_source:' || L_SOURCE);

    IF NOT TRPKSS.FN_GET_PROCESS_REFNO(GLOBAL.CURRENT_BRANCH,
                                       P_TY_ATM_TXN_REC.PRODUCT_CODE,
                                       GLOBAL.APPLICATION_DATE,
                                       L_SERIAL,
                                       L_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO,
                                       P_ERR_CODE) THEN
      DBG('E', 'Failed in generating prod ref no ' || P_ERR_CODE);
      RETURN FALSE;
    END IF;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN

       (CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID     := 1;
      L_TB_CUSTOM_DATA := L_TB_CUSTOM_DATA_EMPTY;
      IF NOT SWPKS_RTTRANSACTION_CUSTOM.FN_MAIN_PRE(L_TY_RTUPLD,
                                                    P_TY_ATM_TXN_REC,
                                                    L_FN_CALL_ID,
                                                    L_TB_CUSTOM_DATA,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM) THEN
        DBG('swpks_rttransaction.fn_process_rt_txn_pre ' || P_ERR_CODE);
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('Depks_RetailTellerUpload.g_viraccno' ||
          DEPKS_RETAILTELLERUPLOAD.G_VIRACCNO);
      DBG('Depks_Retailtellerupload.g_viraccno_ccy' ||
          DEPKS_RETAILTELLERUPLOAD.G_VIRACCNO_CCY);

      IF NOT DEPKSS_RETAILTELLERUPLOAD.FN_UPLOAD(L_TY_RTUPLD.TY_UPLD_RTL_TELLER,
                                                 L_TY_RTUPLD.TBL_CHGDETS,
                                                 L_TY_RTUPLD.TY_MISDETAILS,
                                                 L_TY_RTUPLD.TBL_UDFDETAILS,
                                                 L_TY_RTUPLD.TY_PCDETAILS,
                                                 L_TY_RTUPLD.TY_MCKDETAILS,
                                                 L_TY_RTUPLD.TY_MSGDETS,
                                                 L_TY_RTUPLD.TBL_NODE,
                                                 L_SOURCE,
                                                 L_REC_TXN_CTRL.OVERRIDE_FLAG,
                                                 L_STATUS_ON_SAVE,
                                                 L_RET,
                                                 L_ERR_TBL) THEN
        DBG('E',
            'Failed while calling depks_retailtellerupload.fn_upload' ||
            SQLCODE || '~' || P_ERR_CODE);

        FOR I IN 1 .. L_ERR_TBL.COUNT LOOP
          DBG('E', 'Error Found... ' || L_ERR_TBL(I).ERR_CODE);
          P_ERR_CODE := L_ERR_TBL(I).ERR_CODE;
        END LOOP;

        IF NOT CHECK_ERROR(P_TY_ATM_TXN_REC, P_ERR_CODE) THEN
          DBG('E',
              'Failed while calling swpks_rttransaction.check_error' ||
              P_ERR_CODE);
          RETURN FALSE;
        END IF;

        RETURN FALSE;

      END IF;

      --sampath starts
      IF (P_TY_ATM_TXN_REC.RSV_60 IN ('CCONUS')) THEN
        --sampath added if
        DBG('Inside If condition to skip the query balance for GL');

      ELSE
        --sampath added else

        IF P_TY_ATM_TXN_REC.FILE_PROCESS <> 'Y' AND
           P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'F' THEN
          IF NOT SWPKSS_QUERYBALANCE.FN_MAIN(P_TY_ATM_TXN_REC,
                                             P_ERR_CODE,
                                             P_ERR_PARAM) THEN
            DBG('E',
                'Failed while calling swpkss_querybalance.fn_main' ||
                P_ERR_CODE);
            RETURN FALSE;
          END IF;
        END IF;
      END IF; --sampath added end if
      P_TY_ATM_TXN_REC.TRN_REF_NO_FCC := L_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;

      IF (P_TY_ATM_TXN_REC.AUTH_CODE IS NULL) THEN

        P_TY_ATM_TXN_REC.AUTH_CODE := SUBSTR(P_TY_ATM_TXN_REC.XREF, 14, 3) ||
                                      LPAD(SW_AUTHSEQNUM.NEXTVAL, 3, '0');
      END IF;
      DBG('Before AUTH_Response-------->p_ty_atm_txn_rec.auth_code INSIDE ' ||
          P_TY_ATM_TXN_REC.AUTH_CODE);

      DBG('returning sucessful from  swpks_rttransaction.fn_main.........');

      IF NOT SWPKS_UTILS.FN_INSERT_ADDLTXT(P_TY_ATM_TXN_REC,
                                           P_ERR_CODE,
                                           P_ERR_PARAM) THEN
        DBG('Failed while INSERTING ADDL TEXT :' || P_ERR_CODE);
      END IF;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE := 'SW-RTT-01';
      RETURN FALSE;
  END FN_MAIN;

END SWPKS_RTTRANSACTION;
