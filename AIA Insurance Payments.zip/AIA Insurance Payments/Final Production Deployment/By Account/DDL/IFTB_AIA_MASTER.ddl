create table IFTB_AIA_MASTER
(
  trn_ref_no       VARCHAR2(16) primary key,
  policy_number    VARCHAR2(25),
  txn_ccy          VARCHAR2(3),
  txn_amount       NUMBER(22,3),
  dr_acc_no        VARCHAR2(20),
  dr_acc_ccy       VARCHAR2(3),
  dr_amount        NUMBER(22,3),
  cr_acc_no        VARCHAR2(20),
  cr_acc_ccy       VARCHAR2(3),
  cr_amount        NUMBER(22,3),
  paymnt_date      DATE,
  exch_rate        NUMBER(24,12),
  narrative        VARCHAR2(250),
  record_stat      CHAR(1),
  auth_stat        CHAR(1),
  mod_no           NUMBER(4),
  maker_id         VARCHAR2(12),
  maker_dt_stamp   DATE,
  checker_id       VARCHAR2(12),
  checker_dt_stamp DATE,
  once_auth        CHAR(1),
  txn_unique_no    VARCHAR2(105)
)
/
CREATE OR REPLACE SYNONYM IFTBS_AIA_MASTER FOR IFTB_AIA_MASTER
/
