prompt Importing table fbtb_branch_multiauth_ccy...
set feedback off
set define off
insert into fbtb_branch_multiauth_ccy (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE)
values ('ALL', 'AIAC', 'KHR');

insert into fbtb_branch_multiauth_ccy (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE)
values ('ALL', 'AIAC', 'USD');

prompt Done.
