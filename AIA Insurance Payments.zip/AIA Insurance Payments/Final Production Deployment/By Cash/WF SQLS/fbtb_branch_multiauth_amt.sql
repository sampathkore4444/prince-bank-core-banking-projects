insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'AIAC', 'KHR', 400000000.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'AIAC', 'KHR', 10000000000000000.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'AIAC', 'USD', 100000.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'AIAC', 'USD', 999999999999.000, null, null);

COMMIT;
