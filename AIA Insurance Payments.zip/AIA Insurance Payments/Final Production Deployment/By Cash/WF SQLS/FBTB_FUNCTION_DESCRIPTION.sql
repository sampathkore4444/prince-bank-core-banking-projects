
insert into FBTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'AIAC', 'Teller', 'Cash Transactions', 'AIA Insurance Payment By Cash', null, 'WB', '0', 'AIA Insurance Payment By Cash', null);

COMMIT;
