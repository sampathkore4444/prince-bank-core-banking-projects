prompt Importing table p1fchprfm.STTMS_BRANCH_MULTIAUTH_CCY...
set feedback off
set define off
insert into p1fchprfm.STTMS_BRANCH_MULTIAUTH_CCY (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE)
values ('ALL', 'AIAC', 'KHR');

insert into p1fchprfm.STTMS_BRANCH_MULTIAUTH_CCY (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE)
values ('ALL', 'AIAC', 'USD');

prompt Done.
