
insert into smtb_function_description (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'AIAC', 'Teller', 'Insurance Payment', 'AIA Insurance Payment BY Cash', null, 'WB', null, 'AIA Insurance Payment BY Cash', 'AIAC');

COMMIT;
