-- Create sequence 
create sequence TRSQ_AIA_PARTNER_RECEIPT_REF
minvalue 1
maxvalue 9999999999999
start with 1
increment by 1
cache 20;
/
grant all on TRSQ_AIA_PARTNER_RECEIPT_REF to fccndg
/