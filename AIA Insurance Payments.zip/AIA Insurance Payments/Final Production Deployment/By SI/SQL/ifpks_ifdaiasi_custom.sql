CREATE OR REPLACE PACKAGE BODY ifpks_ifdaiasi_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdaiasi_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2021 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdaiasi_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;

  FUNCTION FN_GET_AIA_POLICY_ENQUIRY RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_AIA_POLICY_ENQUIRY');
  
    L_FORMATTED_MSG := '{"channelCode":"MB","insuranceCode":"$L_INSURANCE_CODE","policyNumber":"$L_POLICY_NUMBER"}';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_AIA_POLICY_ENQUIRY');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AIA_POLICY_ENQUIRY');
      DBG('ERROR CODE IN FN_GET_AIA_POLICY_ENQUIRY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AIA_POLICY_ENQUIRY=' || SQLERRM);
    
  END FN_GET_AIA_POLICY_ENQUIRY;

  FUNCTION FN_GET_FMT_AIA_POLICY_ENQ(p_ifdaiasi IN OUT IFPKS_IFDAIASI_MAIN.ty_ifdaiasi)
    RETURN CLOB IS
  
    L_INSURANCE_CODE VARCHAR2(105);
    L_POLICY_NUMBER  VARCHAR2(105);
    L_FORMATTED_MSG  CLOB; --varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_GET_FMT_AIA_POLICY_ENQ');
  
    L_FORMATTED_MSG := FN_GET_AIA_POLICY_ENQUIRY;
  
    DBG('BEFORE REPLACEMENT OF AIA ACC ENQUIRY JSON=' || L_FORMATTED_MSG);
  
    --Replace tags with actual values
    -- L_INSURANCE_CODE := p_ifdaiasi.v_cstb_ui_columns.CHAR_FIELD10;
  
    DBG('L_INSURANCE_CODE=' || L_INSURANCE_CODE);
  
    L_INSURANCE_CODE := 'AIA001';
  
    L_POLICY_NUMBER := p_ifdaiasi.v_iftbs_aia_si_master.AIA_POLICY_NO;
  
    DBG('L_POLICY_NUMBER=' || L_POLICY_NUMBER);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSURANCE_CODE',
                               L_INSURANCE_CODE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_POLICY_NUMBER',
                               L_POLICY_NUMBER);
  
    DBG('AFTER REPLACEMENT OF AIA POLICY ENQUIRY JSON=' || L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_AIA_POLICY_ENQ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_AIA_POLICY_ENQ');
      DBG('ERROR CODE IN FN_GET_FMT_AIA_POLICY_ENQ=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_AIA_POLICY_ENQ=' || SQLERRM);
  END FN_GET_FMT_AIA_POLICY_ENQ;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN
  
    SELECT TRSQ_AIA_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    RETURN L_REF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  FUNCTION FN_AIA_WS_CALL(p_AIA_call in varchar2,
                          p_out_msg  VARCHAR2,
                          p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS
  
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255);
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);
  
    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;
  
  BEGIN
    dbg('START OF FN_AIA_WS_CALL');
  
    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));
  
    IF p_AIA_call = 'I' THEN
    
      L_URL := FN_GET_PARAM_VAL('PGW_AIA_POLICY_ENQ_URL');
    
    ELSIF p_AIA_call = 'C' THEN
    
      L_URL := FN_GET_PARAM_VAL('PGW_AIA_PAYCONFIRM_URL');
    
    END IF;
  
    DBG('l_url-->' || L_URL);
  
    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');
  
    utl_http.set_authentication(l_http_request,
                                FN_GET_PARAM_VAL('PGW_AIA_AUTH_UID'),
                                FN_GET_PARAM_VAL('PGW_AIA_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
    utl_http.set_header(l_http_request,
                        'content-type',
                        'application/x-www-form-urlencoded');
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
  
    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
  
    utl_http.set_transfer_timeout(300);
  
    utl_http.write_text(l_http_request, p_out_msg);
  
    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));
  
    l_http_response := utl_http.get_response(l_http_request);
  
    dbg('Response> status_code: "' || l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    DBG('l_resp_num=' || l_resp_num);
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;
    
      p_in_resp := buffer1;
    
      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    --    dbms_lob.freetemporary(buffer1); --buffer2 may be check
  
    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('Error Line Number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_AIA_WS_CALL;

  PROCEDURE PR_INSERT_AIA_WS_LOG(P_SEQ_NO        IN VARCHAR2,
                                 P_XREF          IN VARCHAR2,
                                 P_INVOKE_DATE   IN VARCHAR2,
                                 P_POLICY_NUMBER IN VARCHAR2,
                                 P_REQ_TYPE      IN VARCHAR2,
                                 P_REQ_MSG       IN VARCHAR2,
                                 P_ADDL_INFO     IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
    DBG('START OF PR_INSERT_AIA_WS_LOG');
  
    INSERT INTO IFTB_AIA_WS_LOG
      (SEQ_NO,
       TRN_REF_NO,
       INVOKE_DATE,
       POLICY_NUMBER,
       REQ_TYPE,
       REQ_MSG,
       ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_XREF,
       P_INVOKE_DATE,
       P_POLICY_NUMBER,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ADDL_INFO);
  
    COMMIT;
  
    DBG('END OF PR_INSERT_AIA_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_AIA_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_AIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_AIA_WS_LOG=' || SQLERRM);
    
  END PR_INSERT_AIA_WS_LOG;

  PROCEDURE PR_UPDATE_AIA_WS_LOG(P_XREF          IN IFTB_AIA_MASTER.TRN_REF_NO%TYPE,
                                 P_SEQ_NO        IN VARCHAR2,
                                 P_TXN_UNIQUE_NO IN IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE,
                                 P_STATUS        IN CHAR,
                                 P_RES_MSG       IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_AIA_WS_LOG');
  
    UPDATE IFTB_AIA_WS_LOG
       SET TXN_UNIQUE_NO = P_TXN_UNIQUE_NO,
           
           RES_MSG = P_RES_MSG,
           STATUS  = P_STATUS
     WHERE TRN_REF_NO = P_XREF
       AND SEQ_NO = P_SEQ_NO;
  
    COMMIT;
  
    DBG('END OF PR_UPDATE_AIA_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_AIA_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_AIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_AIA_WS_LOG=' || SQLERRM);
  END PR_UPDATE_AIA_WS_LOG;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;
  
    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION fn_msg_upload(p_ifdaiasi   IN OUT IFPKS_IFDAIASI_MAIN.ty_ifdaiasi,
                         P_REQ_TYPE   IN VARCHAR2,
                         P_REQ_MSG    IN OUT CLOB,
                         P_ADDL_INFO  IN VARCHAR2,
                         p_err_code   IN OUT VARCHAR2,
                         p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
  
    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);
  
    L_CLIENT_NAME          VARCHAR2(105);
    L_email                VARCHAR2(105);
    L_phone                VARCHAR2(105);
    l_paymentDueDate       VARCHAR2(105);
    l_allowPartialPayment  VARCHAR2(105);
    l_allowSchedulePayment VARCHAR2(105);
    l_frequency            VARCHAR2(105);
    l_maturityDate         VARCHAR2(105);
    l_amount               VARCHAR2(105);
    l_currency             VARCHAR2(105);
    l_transactionUniqueNo  VARCHAR2(105);
  
    L_insuranceTransactionNo VARCHAR2(105);
  
    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);
  
    L_EXISTS_FLAG NUMBER;
  
  BEGIN
  
    dbg('Inside fn_msg_upload');
  
    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;
  
    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);
  
    --Log Webservice Call
    PR_INSERT_AIA_WS_LOG(L_GEN_SEQ_NO,
                         p_ifdaiasi.v_iftbs_aia_si_master.PARTNER_RECEIPT_REF,
                         SYSDATE,
                         p_ifdaiasi.v_iftbs_aia_si_master.AIA_POLICY_NO,
                         P_REQ_TYPE,
                         P_REQ_MSG,
                         P_ADDL_INFO);
  
    IF NOT FN_AIA_WS_CALL(P_REQ_TYPE, P_REQ_MSG, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;
  
    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);
  
    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
  
    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);
  
    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
  
    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;
  
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;
  
    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);
  
    IF L_STATUS_CODE <> '000' THEN
    
      p_err_code := 'IF-AIA-000';
    
      OVPKSS.PR_APPENDTBL(p_err_code, L_STATUS_MSG || '~');
    
      RETURN FALSE;
    
    END IF;
  
    --Handle All Errro Codes ad return false
  
    IF P_REQ_TYPE = 'I' THEN
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN
      
        L_CLIENT_NAME := P_DOCUMENT_XML.EXTRACT('/root/data/clientName/text()')
                         .GETSTRINGVAL;
      
        DBG('L_CLIENT_NAME =' || L_CLIENT_NAME);
      
        p_ifdaiasi.v_iftbs_aia_si_master.POLICY_HOLDER_NAME := L_CLIENT_NAME;
      
        SELECT INSTR(P_DOCUMENT_XML, '<email>')
          INTO L_EXISTS_FLAG
          FROM DUAL;
      
        IF L_EXISTS_FLAG > 0 THEN
          L_email := P_DOCUMENT_XML.EXTRACT('/root/data/email/text()')
                     .GETSTRINGVAL;
        END IF;
      
        DBG('L_email =' || L_email);
      
        p_ifdaiasi.v_iftbs_aia_si_master.POLICY_HOLDER_EMAIL := L_email;
      
        L_phone := P_DOCUMENT_XML.EXTRACT('/root/data/phone/text()')
                   
                   .GETSTRINGVAL;
      
        DBG('L_phone =' || L_phone);
      
        p_ifdaiasi.v_iftbs_aia_si_master.POLICY_HOLDER_PHONE := L_phone;
      
        l_paymentDueDate := P_DOCUMENT_XML.EXTRACT('/root/data/paymentDueDate/text()')
                            
                            .GETSTRINGVAL;
      
        DBG('l_paymentDueDate =' || l_paymentDueDate);
      
        p_ifdaiasi.v_iftbs_aia_si_master.first_due_date := TO_DATE(l_paymentDueDate,
                                                                   'YYYY-MM-DD');
      
        /*l_allowPartialPayment := P_DOCUMENT_XML.EXTRACT('/root/data/allowPartialPayment/text()')
        
                                 .GETSTRINGVAL;
        
        DBG('l_allowPartialPayment =' || l_allowPartialPayment);
        
        p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD6 := l_allowPartialPayment;
        
        l_allowSchedulePayment := P_DOCUMENT_XML.EXTRACT('/root/data/allowSchedulePayment/text()')
        
                                  .GETSTRINGVAL;
        
        DBG('l_allowSchedulePayment =' || l_allowSchedulePayment);
        
        p_ifdaiaft.v_cstb_ui_columns.char_field42 := l_allowSchedulePayment;*/
      
        l_frequency := P_DOCUMENT_XML.EXTRACT('/root/data/frequency/text()')
                       
                       .GETSTRINGVAL;
      
        DBG('l_frequency =' || l_frequency);
      
        IF UPPER(l_frequency) = 'MONTHLY' THEN
        
          p_ifdaiasi.v_iftbs_aia_si_master.CURRENT_BILL_FREQ := 'M';
        
        ELSIF UPPER(l_frequency) = 'SEMI-ANNUAL' THEN
        
          p_ifdaiasi.v_iftbs_aia_si_master.CURRENT_BILL_FREQ := 'S';
        
        ELSIF UPPER(l_frequency) = 'ANNUAL' THEN
        
          p_ifdaiasi.v_iftbs_aia_si_master.CURRENT_BILL_FREQ := 'A';
        
        END IF;
      
        l_maturityDate := P_DOCUMENT_XML.EXTRACT('/root/data/maturityDate/text()')
                          
                          .GETSTRINGVAL;
      
        DBG('l_maturityDate =' || l_maturityDate);
      
        p_ifdaiasi.v_iftbs_aia_si_master.EXPIRY_DATE := TO_DATE(l_maturityDate,
                                                                'YYYY-MM-DD');
      
        l_amount := P_DOCUMENT_XML.EXTRACT('/root/data/amount/text()')
                    
                    .GETSTRINGVAL;
      
        DBG('l_amount =' || l_amount);
      
        p_ifdaiasi.v_iftbs_aia_si_master.PREMIUM_AMT := l_amount;
      
        l_currency := P_DOCUMENT_XML.EXTRACT('/root/data/currency/text()')
                      
                      .GETSTRINGVAL;
      
        DBG('l_currency =' || l_currency);
      
        p_ifdaiasi.v_iftbs_aia_si_master.CCY := l_currency;
      
        /*l_transactionUniqueNo := P_DOCUMENT_XML.EXTRACT('/root/data/transactionUniqueNo/text()')
        
                                 .GETSTRINGVAL;
        
        DBG('l_transactionUniqueNo =' || l_transactionUniqueNo);
        
        p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD9 := l_transactionUniqueNo;*/
      
        PR_UPDATE_AIA_WS_LOG(p_ifdaiasi.v_iftbs_aia_si_master.PARTNER_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'S',
                             L_IN_RESP);
      
      ELSE
      
        PR_UPDATE_AIA_WS_LOG(p_ifdaiasi.v_iftbs_aia_si_master.PARTNER_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'F',
                             L_IN_RESP);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      RETURN FALSE;
  END fn_msg_upload;

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdaiasi         IN OUT ifpks_ifdaiasi_Main.ty_ifdaiasi,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of ifpks_ifdaiasi_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdaiasi         IN OUT ifpks_ifdaiasi_Main.Ty_ifdaiasi,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
    l_serial_no     VARCHAR2(16);
    l_trn_ref_no    iftb_aia_si_master.partner_receipt_ref%TYPE;
    l_formatted_msg CLOB;
    L_COUNT         number := 0;
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory');
  
    dbg('p_Action_Code' || p_action_code);
  
    IF p_Action_Code = 'INVOKEAIA' THEN
    
      DBG('I AM IN PICKUP');
    
      IF p_ifdaiasi.v_iftbs_aia_si_master.partner_receipt_ref IS NULL THEN
        IF NOT trpkss.fn_get_product_refno(GLOBAL.current_branch,
                                           'AISI',
                                           global.application_date,
                                           l_serial_no,
                                           l_trn_ref_no,
                                           p_err_code) THEN
          dbg('Failed in generation Transaction Ref No');
          RETURN FALSE;
        ELSE
          dbg('l_trn_ref_no=' || l_trn_ref_no);
          p_ifdaiasi.v_iftbs_aia_si_master.partner_receipt_ref := l_trn_ref_no;
        
        END IF;
      END IF;
    
      L_FORMATTED_MSG := FN_GET_FMT_AIA_POLICY_ENQ(p_ifdaiasi);
    
      DBG('AFTER REPLACEMENT OF AIA POLICY ENQUIRY JSON=' ||
          L_FORMATTED_MSG);
    
      DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);
    
      DBG('CALLING AIA POLICY ENQUIRY WEBSERVICE');
    
      IF NOT FN_MSG_UPLOAD(p_ifdaiasi,
                           'I',
                           L_FORMATTED_MSG,
                           'Account Enquiry Call',
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
      
        DBG('FAILED IN POLICY ENQUIRY CALL');
      
        RETURN FALSE;
      
      ELSE
      
        DBG('SUCCESS IN POLICY ENQUIRY CALL');
      
      END IF;
    
    END IF;
  
    IF p_action_code = cspks_req_global.p_new THEN
    
      IF p_ifdaiasi.v_iftbs_aia_si_master.CUST_AC_NO is null THEN
      
        dbg('CUSTOMER DEBIT ACCOUNT IS NULL');
      
        p_err_code := 'IF-AIA-002';
      
        --OVPKSS.PR_APPENDTBL(P_ERR_CODE, NULL);
      
        PR_LOG_ERROR('IFDAIASI', 'FLEXCUBE', p_err_code, p_err_params);
      
        RETURN FALSE;
      
      END IF;
    
      --Get count of SI for this policy no
      BEGIN
      
        SELECT COUNT(1)
          INTO L_COUNT
          FROM IFTB_AIA_SI_MASTER A
         WHERE A.AIA_POLICY_NO =
               p_ifdaiasi.v_iftbs_aia_si_master.AIA_POLICY_NO
           AND RECORD_STAT = 'O';
      
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;
    
      IF L_COUNT <> 0 THEN
      
        p_err_code := 'IF-AIA-005';
      
        PR_LOG_ERROR('IFDAIASI', 'FLEXCUBE', p_err_code, p_err_params);
      
        RETURN FALSE;
      
      END IF;
    
      /*IF p_ifdaiasi.v_iftbs_aia_si_master.AIA_AC_NO is null THEN
      
        dbg('AIA CREDIT ACCOUNT IS NULL');
      
        p_err_code := 'IF-AIA-002';
      
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, NULL);
      
        RETURN FALSE;
      
      END IF;*/
    
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiasi_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdaiasi         IN ifpks_ifdaiasi_Main.ty_ifdaiasi,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiasi_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdaiasi         IN ifpks_ifdaiasi_Main.ty_ifdaiasi,
                                       p_Prev_ifdaiasi    IN OUT ifpks_ifdaiasi_Main.ty_ifdaiasi,
                                       p_Wrk_ifdaiasi     IN OUT ifpks_ifdaiasi_Main.ty_ifdaiasi,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiasi_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdaiasi         IN ifpks_ifdaiasi_Main.Ty_ifdaiasi,
                                        p_Prev_ifdaiasi    IN OUT ifpks_ifdaiasi_Main.Ty_ifdaiasi,
                                        p_Wrk_ifdaiasi     IN OUT ifpks_ifdaiasi_Main.Ty_ifdaiasi,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiasi_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdaiasi         IN ifpks_ifdaiasi_Main.Ty_ifdaiasi,
                            p_Prev_ifdaiasi    IN ifpks_ifdaiasi_Main.Ty_ifdaiasi,
                            p_Wrk_ifdaiasi     IN OUT ifpks_ifdaiasi_Main.Ty_ifdaiasi,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    IF p_Action_Code in (cspks_req_global.p_New, cspks_req_global.p_Modify) THEN
    
      p_Wrk_ifdaiasi.v_iftbs_aia_si_master.bank_code        := '10';
      p_Wrk_ifdaiasi.v_iftbs_aia_si_master.bank_name        := 'PRINCE BANK';
      p_Wrk_ifdaiasi.v_iftbs_aia_si_master.receipt_date     := global.application_date;
      p_Wrk_ifdaiasi.v_iftbs_aia_si_master.payment_channel  := 'OTC';
      p_Wrk_ifdaiasi.v_iftbs_aia_si_master.transaction_type := 'Create';
      p_Wrk_ifdaiasi.v_iftbs_aia_si_master.product_type     := 'FLX';
      p_Wrk_ifdaiasi.v_iftbs_aia_si_master.policy_status    := 'IF';
    
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiasi_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdaiasi         IN ifpks_ifdaiasi_Main.Ty_ifdaiasi,
                             p_prev_ifdaiasi    IN ifpks_ifdaiasi_Main.Ty_ifdaiasi,
                             p_wrk_ifdaiasi     IN OUT ifpks_ifdaiasi_Main.Ty_ifdaiasi,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.p_auth) THEN
    
      IF p_ifdaiasi.v_iftbs_aia_si_master.CURRENT_BILL_FREQ = 'M' THEN
      
        UPDATE IFTB_AIA_SI_MASTER A
           SET A.CURRENT_BILL_FREQ = '12'
         WHERE A.AIA_POLICY_NO =
               p_ifdaiasi.v_iftbs_aia_si_master.aia_policy_no;
      
      ELSIF p_ifdaiasi.v_iftbs_aia_si_master.CURRENT_BILL_FREQ = 'S' THEN
      
        UPDATE IFTB_AIA_SI_MASTER A
           SET A.CURRENT_BILL_FREQ = '2'
         WHERE A.AIA_POLICY_NO =
               p_ifdaiasi.v_iftbs_aia_si_master.aia_policy_no;
      
      ELSIF p_ifdaiasi.v_iftbs_aia_si_master.CURRENT_BILL_FREQ = 'A' THEN
      
        UPDATE IFTB_AIA_SI_MASTER A
           SET A.CURRENT_BILL_FREQ = '1'
         WHERE A.AIA_POLICY_NO =
               p_ifdaiasi.v_iftbs_aia_si_master.aia_policy_no;
      
      END IF;
    
    END IF;
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiasi_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdaiasi         IN ifpks_ifdaiasi_Main.Ty_ifdaiasi,
                        p_Wrk_ifdaiasi     IN OUT ifpks_ifdaiasi_Main.Ty_ifdaiasi,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiasi_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdaiasi         IN ifpks_ifdaiasi_Main.ty_ifdaiasi,
                         p_wrk_ifdaiasi     IN OUT ifpks_ifdaiasi_Main.ty_ifdaiasi,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  L_AIA_SI_MASTER IFTB_AIA_SI_MASTER%ROWTYPE;
  BEGIN
  
    Dbg('In Fn_Post_Query..');
    
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.p_query) THEN
      
    BEGIN
      SELECT * INTO L_AIA_SI_MASTER FROM IFTB_AIA_SI_MASTER A
      WHERE A.AIA_POLICY_NO =  p_ifdaiasi.v_iftbs_aia_si_master.AIA_POLICY_NO
      AND A.PARTNER_RECEIPT_REF = p_ifdaiasi.v_iftbs_aia_si_master.PARTNER_RECEIPT_REF;
      
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    
      IF L_AIA_SI_MASTER.CURRENT_BILL_FREQ = '12' THEN
      
        p_wrk_ifdaiasi.v_iftbs_aia_si_master.CURRENT_BILL_FREQ := 'M';
      
      ELSIF L_AIA_SI_MASTER.CURRENT_BILL_FREQ = '2' THEN
      
       p_wrk_ifdaiasi.v_iftbs_aia_si_master.CURRENT_BILL_FREQ := 'S';
      
      ELSIF L_AIA_SI_MASTER.CURRENT_BILL_FREQ = '1' THEN
      
        p_wrk_ifdaiasi.v_iftbs_aia_si_master.CURRENT_BILL_FREQ := 'A';
      
      END IF;
    
    END IF;
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of ifpks_ifdaiasi_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END ifpks_ifdaiasi_custom;
/