1)
begin

dbms_network_acl_admin.create_acl (

acl => 'http_permissions_aia.xml', -- or any other name

description => 'HTTP Access',

principal => 'P1FCHPRFM', -- the user name trying to access the network resource

is_grant => TRUE,

privilege => 'connect',

start_date => null,

end_date => null

);

end;

/


commit;


2)
begin

DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE(acl => 'http_permissions_aia.xml',

principal => 'P1FCHPRFM',

is_grant => true,

privilege => 'connect');

end;

/


commit;

3)
begin

DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE(acl => 'http_permissions_aia.xml',

principal => 'P1FCHPRFM',

is_grant => true,

privilege => 'resolve');

end;

/

commit;

4)
BEGIN

dbms_network_acl_admin.assign_acl (

acl => 'http_permissions_aia.xml',

host => 'integration-uat.princeplc.com.kh', /*can be computer name or IP , wildcards are accepted as well for example - '*.us.oracle.com'*/

lower_port => null,

upper_port => null

);

END;
/