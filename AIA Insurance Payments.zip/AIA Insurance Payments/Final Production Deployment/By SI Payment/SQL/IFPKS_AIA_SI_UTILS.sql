CREATE OR REPLACE PACKAGE BODY IFPKS_AIA_SI_UTILS AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_AIA_SI_UTILS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  --this insert for enquiry
  PROCEDURE PR_INSERT_AIA_WS_LOG(P_SEQ_NO              IN VARCHAR2,
                                 P_PARTNER_RECEIPT_REF IN VARCHAR2,
                                 P_INVOKE_DATE         IN TIMESTAMP,
                                 P_POLICY_NUMBER       IN VARCHAR2,
                                 P_REQ_TYPE            IN VARCHAR2,
                                 P_REQ_MSG             IN VARCHAR2,
                                 P_ADDL_INFO           IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
    DBG('START OF PR_INSERT_AIA_WS_LOG');
  
    INSERT INTO Iftb_Aia_si_Ws_Log
      (SEQ_NO,
       PARTNER_RECEIPT_REF,
       INVOKE_DATE,
       POLICY_NUMBER,
       REQ_TYPE,
       REQ_MSG,
       ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_PARTNER_RECEIPT_REF,
       P_INVOKE_DATE,
       P_POLICY_NUMBER,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ADDL_INFO);
  
    COMMIT;
  
    DBG('END OF PR_INSERT_AIA_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_AIA_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_AIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_AIA_WS_LOG=' || SQLERRM);
    
  END PR_INSERT_AIA_WS_LOG;

  --this insert for payment
  PROCEDURE PR_INSERT_AIA_WS_LOG(P_SEQ_NO              IN VARCHAR2,
                                 P_PARTNER_RECEIPT_REF IN VARCHAR2,
                                 P_INVOKE_DATE         IN TIMESTAMP,
                                 P_POLICY_NUMBER       IN VARCHAR2,
                                 P_REQ_TYPE            IN VARCHAR2,
                                 P_TXN_UNIQUE_NO       IN VARCHAR2,
                                 P_REQ_MSG             IN VARCHAR2,
                                 P_ADDL_INFO           IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_COUNT NUMBER;
  
  BEGIN
    DBG('START OF PR_INSERT_AIA_WS_LOG CONFIRMATION=' || P_TXN_UNIQUE_NO);
    DBG('P_REQ_TYPE=' || P_REQ_TYPE);
  
    INSERT INTO Iftb_Aia_si_Ws_Log
      (SEQ_NO,
       PARTNER_RECEIPT_REF,
       INVOKE_DATE,
       POLICY_NUMBER,
       REQ_TYPE,
       TXN_UNIQUE_NO,
       REQ_MSG,
       ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_PARTNER_RECEIPT_REF,
       P_INVOKE_DATE,
       P_POLICY_NUMBER,
       P_REQ_TYPE,
       P_TXN_UNIQUE_NO,
       P_REQ_MSG,
       P_ADDL_INFO);
  
  SELECT COUNT(1) INTO L_COUNT FROM Iftb_Aia_si_Ws_Log WHERE 
  REQ_TYPE = 'C' AND TXN_UNIQUE_NO = P_TXN_UNIQUE_NO;
  
  DBG('L_COUNT='||L_COUNT);
    
    COMMIT;
  
    DBG('END OF PR_INSERT_AIA_WS_LOG CONFIRMATION');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_AIA_WS_LOG CONFIRMATION');
      DBG('ERROR CODE IN PR_INSERT_AIA_WS_LOG CONFIRMATION=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_AIA_WS_LOG CONFIRMATION=' || SQLERRM);
    
  END PR_INSERT_AIA_WS_LOG;

  PROCEDURE PR_UPDATE_AIA_WS_LOG(P_PARTNER_RECEIPT_REF IN IFTB_AIA_SI_MASTER.AIA_RECEIPT_REF%TYPE,
                                 P_SEQ_NO              IN VARCHAR2,
                                 P_TXN_UNIQUE_NO       IN IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE,
                                 P_STATUS              IN CHAR,
                                 P_RES_MSG             IN CLOB,
                                 P_ERROR_CODE          IN VARCHAR2,
                                 P_ERROR_PARAM         IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_AIA_WS_LOG');
  
    UPDATE Iftb_Aia_si_Ws_Log
       SET PARTNER_RECEIPT_REF = P_PARTNER_RECEIPT_REF,
           RES_MSG             = P_RES_MSG,
           STATUS              = P_STATUS,
           TXN_UNIQUE_NO       = P_TXN_UNIQUE_NO,
           ERROR_CODE          = P_ERROR_CODE,
           ERROR_MESSAGE       = P_ERROR_PARAM
    
     WHERE SEQ_NO = P_SEQ_NO;
  
    COMMIT;
  
    DBG('END OF PR_UPDATE_AIA_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_AIA_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_AIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_AIA_WS_LOG=' || SQLERRM);
  END PR_UPDATE_AIA_WS_LOG;
  
  PROCEDURE PR_UPDATE_AIA_WS_LOG(P_PARTNER_RECEIPT_REF IN IFTB_AIA_SI_MASTER.AIA_RECEIPT_REF%TYPE,
                                 P_SEQ_NO              IN VARCHAR2,
                                 P_STATUS              IN CHAR,
                                 P_RES_MSG             IN CLOB,
                                 P_ERROR_CODE          IN VARCHAR2,
                                 P_ERROR_PARAM         IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_AIA_WS_LOG CONFIRMATION');
  
    UPDATE Iftb_Aia_si_Ws_Log
       SET PARTNER_RECEIPT_REF = P_PARTNER_RECEIPT_REF,
           RES_MSG             = P_RES_MSG,
           STATUS              = P_STATUS,
           ERROR_CODE          = P_ERROR_CODE,
           ERROR_MESSAGE       = P_ERROR_PARAM
    
     WHERE SEQ_NO = P_SEQ_NO;
  
    COMMIT;
  
    DBG('END OF PR_UPDATE_AIA_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_AIA_WS_LOG CONFIRMATION');
      DBG('ERROR CODE IN PR_UPDATE_AIA_WS_LOG CONFIRMATION=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_AIA_WS_LOG CONFIRMATION=' || SQLERRM);
  END PR_UPDATE_AIA_WS_LOG;

  --this update is for payment confirmation success trn_ref_no
  PROCEDURE PR_UPDATE_AIA_WS_LOG(P_SEQ_NO        IN VARCHAR2,
                                 P_TXN_UNIQUE_NO IN IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE,
                                 P_TRN_REF_NO    IN IFTB_AIA_SI_WS_LOG.TRN_REF_NO%TYPE,
                                 P_STATUS        IN CHAR,
                                 P_REQ_TYPE      IN CHAR) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_AIA_WS_LOG CONFIRMATION');
  
    UPDATE Iftb_Aia_si_Ws_Log A
       SET TRN_REF_NO = P_TRN_REF_NO, STATUS = P_STATUS
     WHERE A.SEQ_NO = P_SEQ_NO
       AND A.TXN_UNIQUE_NO = P_TXN_UNIQUE_NO
       AND REQ_TYPE = P_REQ_TYPE;
  
    COMMIT;
  
    DBG('END OF PR_UPDATE_AIA_WS_LOG CONFIRMATION');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_AIA_WS_LOG CONFIRMATION');
      DBG('ERROR CODE IN PR_UPDATE_AIA_WS_LOG CONFIRMATION=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_AIA_WS_LOG CONFIRMATION=' || SQLERRM);
  END PR_UPDATE_AIA_WS_LOG;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN
  
    SELECT TRSQ_AIA_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    RETURN L_REF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;
  
    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  FUNCTION FN_AIA_WS_CALL(p_AIA_call in varchar2,
                          p_out_msg  VARCHAR2,
                          p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS
  
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255);
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);
  
    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;
  
  BEGIN
    dbg('START OF FN_AIA_WS_CALL');
  
    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));
  
    IF p_AIA_call = 'I' THEN
    
      L_URL := FN_GET_PARAM_VAL('PGW_AIA_POLICY_ENQ_URL');
    
    ELSIF p_AIA_call = 'C' THEN
    
      L_URL := FN_GET_PARAM_VAL('PGW_AIA_PAYCONFIRM_URL');
    
    END IF;
  
    DBG('l_url-->' || L_URL);
  
    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');
  
    utl_http.set_authentication(l_http_request,
                                FN_GET_PARAM_VAL('PGW_AIA_AUTH_UID'),
                                FN_GET_PARAM_VAL('PGW_AIA_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
    utl_http.set_header(l_http_request,
                        'content-type',
                        'application/x-www-form-urlencoded');
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
  
    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
  
    utl_http.set_transfer_timeout(300);
  
    utl_http.write_text(l_http_request, p_out_msg);
  
    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));
  
    l_http_response := utl_http.get_response(l_http_request);
  
    dbg('Response> status_code: "' || l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    DBG('l_resp_num=' || l_resp_num);
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;
    
      p_in_resp := buffer1;
    
      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    --    dbms_lob.freetemporary(buffer1); --buffer2 may be check
  
    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('Error Line Number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_AIA_WS_CALL;

  FUNCTION fn_msg_upload( --p_ifdaiaft   IN OUT IFPKS_IFDAIAFT_MAIN.ty_ifdaiaft,
                         P_PARTNER_RECEIPT_REF IN VARCHAR2,
                         P_AIA_POLICY_NO       IN VARCHAR2,
                         P_REQ_TYPE            IN VARCHAR2,
                         P_REQ_MSG             IN OUT CLOB,
                         P_ADDL_INFO           IN VARCHAR2,
                         p_err_code            IN OUT VARCHAR2,
                         p_err_params          IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
  
    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);
  
    L_CLIENT_NAME          VARCHAR2(105);
    L_email                VARCHAR2(105);
    L_phone                VARCHAR2(105);
    l_paymentDueDate       VARCHAR2(105);
    l_allowPartialPayment  VARCHAR2(105);
    l_allowSchedulePayment VARCHAR2(105);
    l_frequency            VARCHAR2(105);
    l_maturityDate         VARCHAR2(105);
    l_amount               VARCHAR2(105);
    l_currency             VARCHAR2(105);
    l_transactionUniqueNo  VARCHAR2(105);
  
    L_insuranceTransactionNo VARCHAR2(105);
  
    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);
  
    P_ERROR_CODE  VARCHAR2(100);
    P_ERROR_PARAM VARCHAR2(100);
  
  BEGIN
  
    dbg('Inside fn_msg_upload normal method');
  
    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;
  
    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);
  
    --Log Webservice Call
    PR_INSERT_AIA_WS_LOG(L_GEN_SEQ_NO,
                         P_PARTNER_RECEIPT_REF,
                         SYSTIMESTAMP,
                         P_AIA_POLICY_NO,
                         P_REQ_TYPE,
                         P_REQ_MSG,
                         P_ADDL_INFO);
  
    IF NOT FN_AIA_WS_CALL(P_REQ_TYPE, P_REQ_MSG, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;
  
    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);
  
    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
  
    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);
  
    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
  
    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;
  
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;
  
    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);
  
    IF L_STATUS_CODE = 'ERROR_500' THEN
    
      dbg('AIA SYSTEM IS DOWN');
    
      p_err_code := 'IF-BNG-001';
    
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, null);
    
      RETURN FALSE;
    
    END IF;
  
    --Handle All Error Codes ad return false
  
    IF P_REQ_TYPE = 'I' THEN
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN
      
        l_amount := P_DOCUMENT_XML.EXTRACT('/root/data/amount/text()')
                    
                    .GETSTRINGVAL;
      
        DBG('l_amount =' || l_amount);
      
        l_currency := P_DOCUMENT_XML.EXTRACT('/root/data/currency/text()')
                      
                      .GETSTRINGVAL;
      
        DBG('l_currency =' || l_currency);
      
        l_transactionUniqueNo := P_DOCUMENT_XML.EXTRACT('/root/data/transactionUniqueNo/text()')
                                 
                                 .GETSTRINGVAL;
      
        DBG('l_transactionUniqueNo =' || l_transactionUniqueNo);
      
        PR_UPDATE_AIA_WS_LOG(P_PARTNER_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'S',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
      ELSE
      
        PR_UPDATE_AIA_WS_LOG(P_PARTNER_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'F',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    IF P_REQ_TYPE = 'C' THEN
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN
      
        L_insuranceTransactionNo := P_DOCUMENT_XML.EXTRACT('/root/data/insuranceTransactionNo/text()')
                                    
                                    .GETSTRINGVAL;
      
        DBG('L_insuranceTransactionNo =' || L_insuranceTransactionNo);
      
        PR_UPDATE_AIA_WS_LOG(P_PARTNER_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'S',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
        RETURN TRUE;
      
      ELSE
      
        PR_UPDATE_AIA_WS_LOG(P_PARTNER_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'F',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      RETURN FALSE;
  END fn_msg_upload;

  FUNCTION fn_msg_upload(P_PARTNER_RECEIPT_REF IN VARCHAR2,
                         P_AIA_POLICY_NO       IN VARCHAR2,
                         P_REQ_TYPE            IN VARCHAR2,
                         P_REQ_MSG             IN OUT CLOB,
                         P_ADDL_INFO           IN VARCHAR2,
                         P_PAYMENT_AMT         OUT VARCHAR2,
                         P_PAYMENT_DUEDATE     OUT VARCHAR2,
                         P_TXN_UNIQUE_NO       IN OUT VARCHAR2,
                         P_GEN_SEQ_NO          OUT VARCHAR2,
                         p_err_code            IN OUT VARCHAR2,
                         p_err_params          IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
  
    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);
  
    L_CLIENT_NAME          VARCHAR2(105);
    L_email                VARCHAR2(105);
    L_phone                VARCHAR2(105);
    l_paymentDueDate       VARCHAR2(105);
    l_allowPartialPayment  VARCHAR2(105);
    l_allowSchedulePayment VARCHAR2(105);
    l_frequency            VARCHAR2(105);
    l_maturityDate         VARCHAR2(105);
    l_amount               VARCHAR2(105);
    l_currency             VARCHAR2(105);
    l_transactionUniqueNo  VARCHAR2(105);
  
    L_insuranceTransactionNo VARCHAR2(105);
  
    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);
  
    P_ERROR_CODE  VARCHAR2(100);
    P_ERROR_PARAM VARCHAR2(100);
  
  BEGIN
  
    dbg('Inside fn_msg_upload overloaded method');
  
    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;
  
    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);
  
    P_GEN_SEQ_NO := L_GEN_SEQ_NO;
  
    --Log Webservice Call
    IF P_REQ_TYPE = 'I' THEN
    
      PR_INSERT_AIA_WS_LOG(L_GEN_SEQ_NO,
                           P_PARTNER_RECEIPT_REF,
                           SYSTIMESTAMP,
                           P_AIA_POLICY_NO,
                           P_REQ_TYPE,
                           P_REQ_MSG,
                           P_ADDL_INFO);
    
    ELSIF P_REQ_TYPE = 'C' THEN
    
      DBG('CONFIRMATION P_TXN_UNIQUE_NO=' || P_TXN_UNIQUE_NO);
    
      PR_INSERT_AIA_WS_LOG(L_GEN_SEQ_NO,
                           P_PARTNER_RECEIPT_REF,
                           SYSTIMESTAMP,
                           P_AIA_POLICY_NO,
                           P_REQ_TYPE,
                           P_TXN_UNIQUE_NO,
                           P_REQ_MSG,
                           P_ADDL_INFO);
    
    END IF;
  
    IF NOT FN_AIA_WS_CALL(P_REQ_TYPE, P_REQ_MSG, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;
  
    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);
  
    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
  
    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);
  
    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
  
    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;
  
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;
  
    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);
  
    IF L_STATUS_CODE = 'ERROR_500' THEN
    
      dbg('AIA SYSTEM IS DOWN');
    
      p_err_code := 'IF-BNG-001';
    
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, null);
    
      RETURN FALSE;
    
    END IF;
  
    --Handle All Error Codes ad return false
  
    IF P_REQ_TYPE = 'I' THEN
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN
      
        l_amount := P_DOCUMENT_XML.EXTRACT('/root/data/amount/text()')
                    
                    .GETSTRINGVAL;
      
        DBG('l_amount =' || l_amount);
      
        P_PAYMENT_AMT := l_amount;
      
        l_paymentDueDate := P_DOCUMENT_XML.EXTRACT('/root/data/paymentDueDate/text()')
                            
                            .GETSTRINGVAL;
      
        DBG('l_paymentDueDate =' || l_paymentDueDate);
      
        P_PAYMENT_DUEDATE := l_paymentDueDate;
      
        l_currency := P_DOCUMENT_XML.EXTRACT('/root/data/currency/text()')
                      
                      .GETSTRINGVAL;
      
        DBG('l_currency =' || l_currency);
      
        l_transactionUniqueNo := P_DOCUMENT_XML.EXTRACT('/root/data/transactionUniqueNo/text()')
                                 
                                 .GETSTRINGVAL;
      
        DBG('l_transactionUniqueNo =' || l_transactionUniqueNo);
      
        P_TXN_UNIQUE_NO := l_transactionUniqueNo;
      
        PR_UPDATE_AIA_WS_LOG(P_PARTNER_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'S',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
      ELSE
      
        PR_UPDATE_AIA_WS_LOG(P_PARTNER_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'F',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    IF P_REQ_TYPE = 'C' THEN
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN
      
        L_insuranceTransactionNo := P_DOCUMENT_XML.EXTRACT('/root/data/insuranceTransactionNo/text()')
                                    
                                    .GETSTRINGVAL;
      
        DBG('L_insuranceTransactionNo =' || L_insuranceTransactionNo);
      
        PR_UPDATE_AIA_WS_LOG(P_PARTNER_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             'S',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
        RETURN TRUE;
      
      ELSE
      
        PR_UPDATE_AIA_WS_LOG(P_PARTNER_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             'F',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      RETURN FALSE;
  END fn_msg_upload;

  FUNCTION FN_GET_AIA_POLICY_ENQUIRY RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_AIA_POLICY_ENQUIRY');
  
    L_FORMATTED_MSG := '{"channelCode":"CBS","insuranceCode":"$L_INSURANCE_CODE","policyNumber":"$L_POLICY_NUMBER"}';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_AIA_POLICY_ENQUIRY');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AIA_POLICY_ENQUIRY');
      DBG('ERROR CODE IN FN_GET_AIA_POLICY_ENQUIRY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AIA_POLICY_ENQUIRY=' || SQLERRM);
    
  END FN_GET_AIA_POLICY_ENQUIRY;

  FUNCTION FN_GET_FMT_AIA_POLICY_ENQ(P_POLICY_NO IN VARCHAR2) RETURN CLOB IS
  
    L_INSURANCE_CODE VARCHAR2(105);
    L_POLICY_NUMBER  VARCHAR2(105);
    L_FORMATTED_MSG  CLOB; --varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_GET_FMT_AIA_POLICY_ENQ');
  
    L_FORMATTED_MSG := FN_GET_AIA_POLICY_ENQUIRY;
  
    DBG('BEFORE REPLACEMENT OF AIA ACC ENQUIRY JSON=' || L_FORMATTED_MSG);
  
    --Replace tags with actual values
    L_INSURANCE_CODE := 'AIA001'; --p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10;
  
    DBG('L_INSURANCE_CODE=' || L_INSURANCE_CODE);
  
    L_POLICY_NUMBER := P_POLICY_NO;
  
    DBG('L_POLICY_NUMBER=' || L_POLICY_NUMBER);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSURANCE_CODE',
                               L_INSURANCE_CODE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_POLICY_NUMBER',
                               L_POLICY_NUMBER);
  
    DBG('AFTER REPLACEMENT OF AIA POLICY ENQUIRY JSON=' || L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_AIA_POLICY_ENQ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_AIA_POLICY_ENQ');
      DBG('ERROR CODE IN FN_GET_FMT_AIA_POLICY_ENQ=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_AIA_POLICY_ENQ=' || SQLERRM);
  END FN_GET_FMT_AIA_POLICY_ENQ;

  FUNCTION FN_GET_AIA_PAYMENT RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_AIA_PAYMENT');
  
    L_FORMATTED_MSG := '{"channelCode":"CBS","insuranceCode":"$L_INSURANCE_CODE","transactionUniqueNo":"$L_TXN_UNIQUE_NO","policyNumber":"$L_POLICY_NUMBER"
    ,"amount":"$L_AMOUNT","currency":"$L_CCY"}';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_AIA_PAYMENT');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_AIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AIA_PAYMENT=' || SQLERRM);
    
  END FN_GET_AIA_PAYMENT;

  FUNCTION FN_GET_FMT_AIA_PAYMENT(P_TXN_UNIQUE_NO IN VARCHAR2,
                                  P_POLICY_NO     IN VARCHAR2,
                                  P_PAYMENT_AMT   IN VARCHAR2,
                                  P_CCY           IN VARCHAR2) RETURN CLOB IS
  
    L_TXN_UNIQUE_NO  IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE; --need to change to enquiry id
    L_INSURANCE_CODE VARCHAR2(105);
    L_POLICY_NUMBER  VARCHAR2(105);
    L_AMOUNT         VARCHAR2(105);
    L_CCY            VARCHAR2(3);
    L_FORMATTED_MSG  CLOB; --varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_FMT_AIA_PAYMENT');
  
    L_FORMATTED_MSG := FN_GET_AIA_PAYMENT;
  
    DBG('BEFORE REPLACEMENT OF AIA PAYMENT JSON=' || L_FORMATTED_MSG);
  
    --Replace tags with actual values
    L_TXN_UNIQUE_NO := P_TXN_UNIQUE_NO; --need to change to enquiry id
  
    DBG('L_TXN_UNIQUE_NO=' || L_TXN_UNIQUE_NO);
  
    L_INSURANCE_CODE := 'AIA001'; --p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10;
  
    DBG('L_INSURANCE_CODE=' || L_INSURANCE_CODE);
  
    L_POLICY_NUMBER := P_POLICY_NO;
  
    DBG('L_POLICY_NUMBER=' || L_POLICY_NUMBER);
  
    L_AMOUNT := P_PAYMENT_AMT;
  
    DBG('L_AMOUNT=' || L_AMOUNT);
  
    L_CCY := P_CCY;
  
    DBG('L_CCY=' || L_CCY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_UNIQUE_NO',
                               L_TXN_UNIQUE_NO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSURANCE_CODE',
                               L_INSURANCE_CODE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_POLICY_NUMBER',
                               L_POLICY_NUMBER);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CCY', L_CCY);
  
    DBG('BEFORE REPLACEMENT OF AIA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_AIA_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_AIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_AIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_AIA_PAYMENT=' || SQLERRM);
    
  END FN_GET_FMT_AIA_PAYMENT;

/*PROCEDURE PR_PROCESS_AIA_PAYMENTS AS

    v_user_count            NUMBER(4);
    L_CUST_ACCOUNT          STTM_CUST_ACCOUNT%ROWTYPE;
    L_CUST                  STTM_CUSTOMER%ROWTYPE;
    pkg_detb_rtl_teller_rec detbs_rtl_teller%ROWTYPE;
    L_SERIAL_NO             VARCHAR2(16);
    L_TRN_REF_NO            Actb_Daily_Log.TRN_REF_NO%TYPE;
    L_GEN_SEQ_NO            VARCHAR2(100);

    P_ERR_CODE      VARCHAR2(255);
    P_ERR_PARAMS    VARCHAR2(255);
    l_formatted_msg CLOB;
    L_IN_RESP       CLOB;

    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;

    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);

    L_ARC_MAINT IFTM_ARC_MAINT%ROWTYPE;

    P_REQ_TYPE            CHAR(1);
    l_paymentDueDate      VARCHAR2(105);
    l_transactionUniqueNo VARCHAR2(105);
    l_payment_amount      VARCHAR2(105);
    l_currency            VARCHAR2(105);

    L_COUNT NUMBER;

    L_CCY_CODE  CYTM_CCY_DEFN_MASTER.CCY_CODE%TYPE;
    L_EXCH_RATE ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE_FLAG NUMBER;

    L_TXN_AMT IFTB_AIA_MASTER.TXN_AMOUNT%TYPE;

    CURSOR C1 IS
      SELECT *
        FROM IFTB_AIA_SI_MASTER
       WHERE RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';

    --PAYMENT_DUE_DATE = SYSDATE
    --AND STATUS = 'U'
    --AND SYSDATE <= EXPIRY_DATE;
  BEGIN

    FOR G IN C1 LOOP

      BEGIN

        --Call AIA Api to get the due date

        P_REQ_TYPE := 'I';

        L_FORMATTED_MSG := FN_GET_FMT_AIA_POLICY_ENQ(G.AIA_POLICY_NO);

        DBG('AFTER REPLACEMENT OF AIA POLICY ENQUIRY JSON=' ||
            L_FORMATTED_MSG);

        DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

        DBG('CALLING AIA POLICY ENQUIRY WEBSERVICE');

        IF NOT FN_MSG_UPLOAD(G.AIA_RECEIPT_REF,
                             G.AIA_POLICY_NO,
                             'I',
                             L_FORMATTED_MSG,
                             'Account Enquiry Call',
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN

          DBG('FAILED IN POLICY ENQUIRY CALL');

          --RETURN FALSE;

        ELSE

          DBG('SUCCESS IN POLICY ENQUIRY CALL');

        END IF;

        SAVEPOINT A;

        --Get Account details
        BEGIN
          SELECT *
            INTO L_CUST_ACCOUNT
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = G.CUST_AC_NO;
        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACCOUNT := NULL;
        END;

        GLOBAL.PR_INIT(L_CUST_ACCOUNT.BRANCH_CODE, 'SYSTEM');

        --GET BEN CUSTOMER DETAILS
        BEGIN
          SELECT X.*
            INTO L_CUST
            FROM STTM_CUSTOMER X
           WHERE X.CUSTOMER_NO = L_CUST_ACCOUNT.CUST_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('IF', 'FAILED IN GETTING CUSTOMER DETAILS');
        END;

        PKG_DETB_RTL_TELLER_REC.XREF := L_TRN_REF_NO;

        --Get Arc Maintenance
        SELECT *
          INTO L_ARC_MAINT
          FROM IFTM_ARC_MAINT A
         WHERE A.COD_PROD_ACC_CLS = pkg_detb_rtl_teller_rec.product_code
           AND ROWNUM = 1;

        pkg_detb_rtl_teller_rec.product_code := 'AI01'; --SI PRODICT CODE

        PKG_DETB_RTL_TELLER_REC.BRANCH_CODE := L_CUST_ACCOUNT.BRANCH_CODE;
        PKG_DETB_RTL_TELLER_REC.TRN_REF_NO  := L_TRN_REF_NO;

        PKG_DETB_RTL_TELLER_REC.TXN_ACC    := '000021058'; --AIA Credit Account pls check
        PKG_DETB_RTL_TELLER_REC.TXN_CCY    := GLOBAL.LCY;
        PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := GLOBAL.CURRENT_BRANCH;
        --PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := PKG_DETB_RTL_TELLER_REC.OFS_BRANCH;

        --XRATE CALCULATION STARTS
        IF L_CUST_ACCOUNT.CCY <> 'USD' THEN

          IF NOT CYPKSS.FN_GETRATE(L_CUST_ACCOUNT.BRANCH_CODE,
                                   L_CUST_ACCOUNT.CCY,
                                   'USD', --L_CCY_CODE, --'KHR', --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                   'COMM', --L_PROD.RATE_TYPE_PREFERRED,
                                   'B', --L_RATE_CODE1, --l_prod.rate_code_preferred,
                                   GLOBAL.APPLICATION_DATE,
                                   GLOBAL.APPLICATION_DATE,
                                   L_EXCH_RATE,
                                   L_RATE_FLAG,
                                   P_ERR_CODE) THEN
            DBG('FAILED IN FN_GETRATE');
            ROLLBACK;
          END IF;
        ELSE
          L_EXCH_RATE := 1;
        END IF;

        DBG('L_EXCH_RATE=' || L_EXCH_RATE);

        --USING ABOVE RATE..CONVERT KHR TO USD AMOUNT
        IF NOT CYPKSS.FN_AMT1_TO_AMT2('USD', --L_CCY_CODE,
                                      L_CUST_ACCOUNT.CCY,
                                      l_payment_amount, ---G.TXN_AMOUNT,
                                      L_EXCH_RATE,
                                      'Y',
                                      L_TXN_AMT,
                                      P_ERR_PARAMS) THEN
          DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
          ROLLBACK;
        END IF;

        DBG('FINAL L_TXN_AMT=' || L_TXN_AMT);

        PKG_DETB_RTL_TELLER_REC.OFS_ACC    := G.CUST_AC_NO;
        PKG_DETB_RTL_TELLER_REC.OFS_CCY    := L_CUST_ACCOUNT.CCY;
        PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT := L_TXN_AMT; -- L_AMOUNT/100;

        PKG_DETB_RTL_TELLER_REC.OFS_BRANCH := L_CUST_ACCOUNT.BRANCH_CODE; --GLOBAL.current_branch;

        PKG_DETB_RTL_TELLER_REC.TXN_AMOUNT := L_TXN_AMT;

        PKG_DETB_RTL_TELLER_REC.TXN_TRN_CODE     := L_ARC_MAINT.COD_MAIN_TXN_CODE; --'000'; --TRANSACION CODE
        PKG_DETB_RTL_TELLER_REC.OFS_TRN_CODE     := L_ARC_MAINT.COD_OFFSET_TXN_CODE; --'000'; --TRANSACION CODE
        PKG_DETB_RTL_TELLER_REC.EXCH_RATE        := L_EXCH_RATE;
        PKG_DETB_RTL_TELLER_REC.TRN_DT           := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.VALUE_DT         := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.REL_CUSTOMER     := L_CUST.CUSTOMER_NO;
        PKG_DETB_RTL_TELLER_REC.BENEF_NAME       := L_CUST.CUSTOMER_NAME1;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR1      := L_CUST.ADDRESS_LINE1;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR2      := L_CUST.ADDRESS_LINE2;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR3      := L_CUST.ADDRESS_LINE3;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR4      := L_CUST.ADDRESS_LINE4;
        PKG_DETB_RTL_TELLER_REC.LIQN_DT          := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.RECORD_STAT      := 'A';
        PKG_DETB_RTL_TELLER_REC.AUTH_STAT        := 'U';
        PKG_DETB_RTL_TELLER_REC.MAKER_ID         := 'SYSTEM';
        PKG_DETB_RTL_TELLER_REC.MAKER_DT_STAMP   := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.CHECKER_ID       := 'SYSTEM';
        PKG_DETB_RTL_TELLER_REC.CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.MOD_NO           := 1;
        PKG_DETB_RTL_TELLER_REC.SCODE            := 'FLEXCUBE';
        PKG_DETB_RTL_TELLER_REC.DR_ACC           := 'OFS';
        PKG_DETB_RTL_TELLER_REC.MODULE           := 'RT';
        PKG_DETB_RTL_TELLER_REC.ESN              := 1;
        PKG_DETB_RTL_TELLER_REC.EVENT_CODE       := 'INIT';
        PKG_DETB_RTL_TELLER_REC.TRACK_RECEIVABLE := 'N';
        PKG_DETB_RTL_TELLER_REC.TIME_RECEIVED    := SYSDATE;

        DBG('Calling depks_rtl_teller.fn_save');

        IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN
          dbg('FAILED IN FN_SAVE');
          --PR_LOG_ERROR('IFDCCPFT', 'FLEXCUBE', p_err_code, p_err_params);
          ROLLBACK TO A;
          --PR_UPDATE_AUTO_DEBIT_TRACKER(L_ORDER_ID, 'E');
          --PR_UPDATE_ORDER_ID_INVOKE_LOG(L_ORDER_ID,
          --                            L_TRN_REF_NO,
          --                          'E',
          --                        P_ERR_CODE,
          --                      P_ERR_PARAMS,
          --                    GLOBAL.application_date);

          PR_UPDATE_AIA_WS_LOG(G.AIA_RECEIPT_REF,
                               L_GEN_SEQ_NO,
                               l_transactionUniqueNo,
                               'E',
                               L_IN_RESP);

        ELSE
          DBG('SUCCESS IN FN_SAVE');

          DBG('CALLING DEPKS_RTL_TELLER.FN_RTL_TELLER_AUTH');
          IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(L_CUST_ACCOUNT.BRANCH_CODE,
                                                      L_TRN_REF_NO,
                                                      GLOBAL.USER_ID,
                                                      GLOBAL.LCY,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
            DBG('AUTH RETRUNED FALSE' || P_ERR_CODE);
            DBG('FAILED TO PROCESS TRANSACTION');
            DBG('ROLLINGBACK TO SAVEPOINT A');
            ROLLBACK TO A;
            --PR_UPDATE_AUTO_DEBIT_TRACKER(L_ORDER_ID, 'E');
            --PR_UPDATE_ORDER_ID_INVOKE_LOG(L_ORDER_ID,
            --                            L_TRN_REF_NO,
            --                          'E',
            --                        P_ERR_CODE,
            --                      P_ERR_PARAMS,
            --                    GLOBAL.application_date);

            PR_UPDATE_AIA_WS_LOG(G.AIA_RECEIPT_REF,
                                 L_GEN_SEQ_NO,
                                 l_transactionUniqueNo,
                                 'E',
                                 L_IN_RESP);
          ELSE
            DBG('SUCCESS IN FN_AUTH');
            --PR_UPDATE_AUTO_DEBIT_TRACKER(L_ORDER_ID, 'P');
            --PR_UPDATE_ORDER_ID_INVOKE_LOG(L_ORDER_ID,
            --                            L_TRN_REF_NO,
            --                          'P',
            --                        NULL,
            --                      NULL,
            --                    GLOBAL.application_date);

            --Get AIA CONFIRM PAYMENT
            L_FORMATTED_MSG := FN_GET_FMT_AIA_PAYMENT(l_transactionUniqueNo,
                                                      G.AIA_POLICY_NO,
                                                      l_payment_amount,
                                                      l_currency);

            DBG('AFTER REPLACEMENT OF AIA PAYMENT JSON=' ||
                L_FORMATTED_MSG);

            DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

            DBG('CALLING AIA PAYMENT WEBSERVICE');

            IF NOT FN_MSG_UPLOAD(G.AIA_RECEIPT_REF,
                                 G.AIA_POLICY_NO,
                                 'C',
                                 L_FORMATTED_MSG,
                                 'Payment Confirmation Call',
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN

              DBG('FAILED IN AIA PAYMENT CALL');

              --RETURN FALSE;

            ELSE

              DBG('SUCCESS IN AIA PAYMENT CALL');

            END IF;

          END IF;
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          -- DBG('FAILED IN PROCESSING CURRENT INCOMING ORDER ID=' ||
          --   L_ORDER_ID);
          DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
          CONTINUE;
      END;

    END LOOP;

  END PR_PROCESS_AIA_PAYMENTS;*/

END IFPKS_AIA_SI_UTILS;
/