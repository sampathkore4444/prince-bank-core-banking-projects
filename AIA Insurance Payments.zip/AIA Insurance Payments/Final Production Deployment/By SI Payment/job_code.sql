
*************************Final Starts*********************
BEGIN
DBMS_SCHEDULER.CREATE_PROGRAM (
program_name      => 'PROG_PROCESS_AIA_SI_PAYMENTS',
program_action    => 'PR_PROCESS_AIA_SI_PAYMENTS',
program_type      => 'STORED_PROCEDURE');
END;
/

--this is for every 2 min
BEGIN
DBMS_SCHEDULER.CREATE_SCHEDULE (
 schedule_name   => 'SCH_DAILY_AIA_PAY_SI_SCHEDULE',
 start_date    => '01-dec-2021 10:39:00 pm',--SYSTIMESTAMP,
 repeat_interval  => 'FREQ=MINUTELY;INTERVAL=2;', --BYHOUR=10;BYMINUTE=39,--INTERVAL=5; BYDAY=SAT,SUN',
 --end_date     => SYSTIMESTAMP + INTERVAL '30' day,
 comments     => 'Daily at 10:39 AM');
END;
/
--this is only for 1 time in a day

BEGIN
DBMS_SCHEDULER.CREATE_SCHEDULE (
 schedule_name   => 'SCH_DAILY_AIA_PAY_SI_SCHEDULE',
 start_date    => '01-dec-2021 10:39:00 pm',--SYSTIMESTAMP,
 repeat_interval  => 'FREQ=daily;BYHOUR=16;BYMINUTE=54',
 --end_date     => SYSTIMESTAMP + INTERVAL '30' day,
 comments     => 'Daily at 10:39 AM');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_JOB (
  job_name     => 'JOB_PROCESS_AIA_SI_PAYMENTS',
  program_name   => 'PROG_PROCESS_AIA_SI_PAYMENTS',
  schedule_name   => 'SCH_DAILY_AIA_PAY_SI_SCHEDULE',
  enabled            =>  true);
END;
/


--enable job
begin
dbms_scheduler.enable('JOB_PROCESS_AIA_SI_PAYMENTS');
end;
--enable program
begin
DBMS_SCHEDULER.ENABLE('PROG_PROCESS_AIA_SI_PAYMENTS');
end;


--drop commands in sequence

--drop1:
begin
  dbms_scheduler.drop_job('JOB_PROCESS_AIA_SI_PAYMENTS');
end;

--drop2:
begin
 dbms_scheduler.drop_schedule('SCH_DAILY_AIA_PAY_SI_SCHEDULE');
end;

--drop3:
begin
  dbms_scheduler.drop_program('PROG_PROCESS_AIA_SI_PAYMENTS');
end;
**************************Final Ends****************************



--tables to check above job details

select * from User_Scheduler_Job_Run_Details order by log_id desc 
select * from user_scheduler_job_log order by log_id desc 
select * from user_scheduler_jobs