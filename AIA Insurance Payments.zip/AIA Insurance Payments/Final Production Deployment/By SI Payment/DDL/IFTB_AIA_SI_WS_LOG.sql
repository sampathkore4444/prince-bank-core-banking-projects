-- Create table
create table IFTB_AIA_SI_WS_LOG
(
  seq_no              VARCHAR2(105),
  partner_receipt_ref VARCHAR2(105),
  trn_ref_no          VARCHAR2(16),
  invoke_date         DATE,
  policy_number       VARCHAR2(105),
  req_type            VARCHAR2(25),
  req_msg             CLOB,
  res_msg             CLOB,
  txn_unique_no       VARCHAR2(105),
  status              CHAR(1),
  addl_info           VARCHAR2(105),
  error_code          VARCHAR2(100),
  error_message       VARCHAR2(100)
)
/
alter table IFTB_AIA_SI_WS_LOG add primary key (SEQ_NO)
/
CREATE OR REPLACE SYNONYM IFTBS_AIA_SI_WS_LOG FOR IFTB_AIA_SI_WS_LOG
/