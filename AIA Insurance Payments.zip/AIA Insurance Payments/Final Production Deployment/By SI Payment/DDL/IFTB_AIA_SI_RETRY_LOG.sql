-- Create table
create table IFTB_AIA_SI_RETRY_LOG
(
  seq_no        VARCHAR2(105),
  txn_unique_no VARCHAR2(105),
  aia_policy_no VARCHAR2(105),
  due_date      DATE,
  invoke_date   DATE,
  retry_count   NUMBER
)
/
alter table IFTB_AIA_SI_RETRY_LOG add primary key (SEQ_NO)
/