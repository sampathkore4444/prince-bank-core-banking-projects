prompt Importing table sttm_job_definition...
set feedback off
set define off
insert into sttm_job_definition (JOB_CODE, JOB_GROUP, JOB_DESCRIPTION, SCHEDULER, TRG_TYPE, CRON_EXPR, JOB_TYPE, JOB_CLASS_OR_PROC, SIMPLE_TRG_REPEAT, SIMPLE_TRG_FREQUENCY, TRIGGER_LISTENER, ACTIVE, JNDI_NAME, LOGGING_REQD, AUTH_STAT, CHECKER_DT_STAMP, CHECKER_ID, MAKER_DT_STAMP, MOD_NO, ONCE_AUTH, RECORD_STAT, MAKER_ID, SCHED_TYPE, VETO_BLK_TRG, PRIORITY, MSG_QUEUE, MAX_NO_INSTANCES, STARTUP_MODE)
values ('PR_PROCESS_AIA_SI_PAYMENTS', 'PLSQL', 'Job to process AIA SI Payments', 'SchedulerFactory', 'C', '0 05 15 1/1 * ? *', 'PLSQL', 'PR_PROCESS_AIA_SI_PAYMENTS', -1, null, null, 'Y', 'jdbc/fcjdevDS', 'Y', 'A', to_date('11-11-2020 15:02:47', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('11-11-2020 15:02:47', 'dd-mm-yyyy hh24:mi:ss'), 3, 'Y', 'O', 'SAMPATH2', 'QUARTZ', 'N', 5, null, 1, 'M');

prompt Done.
