insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_AIA_AUTH_PWD', 'qwer!@#$', 'Y');

insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_AIA_AUTH_UID', 'prince', 'Y');

insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_AIA_OUT_KHR', 'KHR', 'N');

insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_AIA_OUT_USD', 'USD', 'N');

insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_AIA_PAYCONFIRM_URL', 'http://integration-uat.princeplc.com.kh/prnc-app/isr/api/v1/policy-confirm', 'Y');

insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_AIA_POLICY_ENQ_URL', 'http://integration-uat.princeplc.com.kh/prnc-app/isr/api/v1/policy-inquiry', 'Y');

insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_AIA_USD_ACC', '000000002', 'Y');

COMMIT;
