CREATE OR REPLACE

PACKAGE BODY stpks_account_close_custom IS

/*
  -------------------------------------------------------------------------------------------------------
   CHANGE HISTORY
   
	   
   ** Modified By         : Kore Sampath Kumar
   ** Modified On         : 15-Nov-2021
   ** Modified Reason     : AIA SI Payment Account Closure Validation
   ** Search String       : AIA SI Payment Account Closure Validation



    -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'stpks_account_close_custom :: ' || P_MSG;
    DEBUG.PR_DEBUG('CS', L_MSG);
  END DBG;

  FUNCTION FN_ALLOW_CLOSE(P_AC_NO          IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                          P_BRN            IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                          P_ERR_CODE       IN OUT VARCHAR2,
                          P_ERR_PARAM      IN OUT VARCHAR2,
                          P_FN_CALL_ID     NUMBER,
                          P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
	
	--AIA SI Payment Account Closure Validation Starts
	L_COUNT NUMBER;
	--AIA SI Payment Account Closure Validation Ends
  
  BEGIN
    DEBUG.PR_DEBUG('IC',
                   'Inside stpks_account_close_custom.fn_allow_close ...');
    
	dbg('GWPKS_UTIL.PKG_ACTTYPE=' || GWPKS_UTIL.PKG_ACTTYPE);
	
	--AIA SI Payment Account Closure Validation Starts
    --IF GWPKS_UTIL.PKG_ACTTYPE in ('SAVEAUTOAUTH', 'ENRICH', 'L') THEN
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM IFTB_AIA_SI_MASTER A
         WHERE A.CUST_AC_NO = P_AC_NO
           AND RECORD_STAT = 'O'
           AND ONCE_AUTH = 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
      END;

      DBG('L_COUNT=' || L_COUNT);

      IF L_COUNT > 0 THEN

        Pr_Log_Error('FLEXCUBE', 'IFDMTAPA', 'IF-AIA-006', NULL);

        RETURN FALSE;

      END IF;
    --END IF;
    --AIA SI Payment Account Closure Validation Ends
	
	DEBUG.PR_DEBUG('IC',
                   'Returning successfully from stpks_account_close_custom.fn_allow_close ...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IC',
                     'In When Others of stpks_profit_pool_custom .fn_allow_close ..');
      DEBUG.PR_DEBUG('IC', SQLERRM);
      RETURN FALSE;
  END FN_ALLOW_CLOSE;

  FUNCTION FN_GET_ACC_CLOSURE_DET(P_TY_ACC_CLOSURE_DET IN OUT STPKS_ACCOUNT_CLOSE.TY_ACC_CLOSURE_DET,
                                  P_CLOSE_REQD         IN OUT CHAR,
                                  P_ERR_CODE           IN OUT VARCHAR2,
                                  P_ERR_PARAM          IN OUT VARCHAR2,
                                  P_FN_CALL_ID         NUMBER,
                                  P_TB_CUSTOM_DATA     IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
	
	--AIA SI Payment Account Closure Validation Starts
	L_COUNT NUMBER;
	--AIA SI Payment Account Closure Validation Ends
  
  BEGIN
    DEBUG.PR_DEBUG('IC',
                   'Inside stpks_account_close_custom.fn_get_acc_closure_det ...');
    
	--AIA SI Payment Account Closure Validation Starts
    --IF GWPKS_UTIL.PKG_ACTTYPE in ('SAVEAUTOAUTH', 'ENRICH', 'L') THEN
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM IFTB_AIA_SI_MASTER A
         WHERE A.CUST_AC_NO = P_TY_ACC_CLOSURE_DET.acc_closure.ac_no
           AND RECORD_STAT = 'O'
           AND ONCE_AUTH = 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
      END;

      DBG('L_COUNT=' || L_COUNT);

      IF L_COUNT > 0 THEN

        Pr_Log_Error('FLEXCUBE', 'IFDMTAPA', 'IF-AIA-006', NULL);

        RETURN FALSE;

      END IF;
    --END IF;
    --AIA SI Payment Account Closure Validation Ends

	
	DEBUG.PR_DEBUG('IC',
                   'Returning successfully from stpks_account_close_custom.fn_get_acc_closure_det ...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IC',
                     'In When Others of stpks_profit_pool_custom .fn_get_acc_closure_det ..');
      DEBUG.PR_DEBUG('IC', SQLERRM);
      RETURN FALSE;
  END FN_GET_ACC_CLOSURE_DET;

  FUNCTION FN_UPLOAD_PAYOUTDETS(P_CLOSE_REQD         IN VARCHAR2,
                                P_TY_ACC_CLOSURE_DET IN STPKS_ACCOUNT_CLOSE.TY_ACC_CLOSURE_DET,
                                P_TY_PAYOUTDETS      IN ICPKS_FCJ_ICDREDMN.TY_TB_PAYOUTDETS,
                                P_TY_BCPAYOUTDETS    IN ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                                P_TY_PCPAYOUTDETS    IN ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                                P_TY_FTPAYOUTDETS    IN STPKS_ACCOUNT_CLOSE.TYP_FTPAYOUT_DETS,
                                P_BC_PRODCODE        IN VARCHAR2,
                                P_FT_PRODCODE        IN VARCHAR2,
                                P_CASH_PRODCODE      IN VARCHAR2,
                                P_FN_CALL_ID         NUMBER,
                                P_TB_CUSTOM_DATA     IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                                P_ERR_CODE           IN OUT VARCHAR2,
                                P_ERR_PARAM          IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
  
  BEGIN
    DBG('Inside Custom package of fn_upload_payoutdets ...');
  
    DBG('Returned successfull from fn_upload_payoutdets');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of stpks_account_close_custom.fn_upload_payoutdets ..');
      DEBUG.PR_DEBUG('IF', SQLERRM);
      RETURN FALSE;
    
  END FN_UPLOAD_PAYOUTDETS;

  FUNCTION FN_CLOSE_CUSTACC(P_TY_ACC_CLOSURE_DET IN OUT STPKS_ACCOUNT_CLOSE.TY_ACC_CLOSURE_DET,
                            P_SOURCE             IN VARCHAR2,
                            P_TY_PAYOUTDETS      IN OUT ICPKS_FCJ_ICDREDMN.TY_TB_PAYOUTDETS,
                            P_TY_BCPAYOUTDETS    IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                            P_TY_PCPAYOUTDETS    IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                            P_TY_FTPAYOUTDETS    IN OUT STPKS_ACCOUNT_CLOSE.TYP_FTPAYOUT_DETS,
                            P_TBL_NODE           IN OUT STPKS_ACCOUNT_CLOSE.TBL_NODE,
                            P_TBL_CHGDETS        IN OUT STPKS_ACCOUNT_CLOSE.TBL_CHGDETS,
                            P_UPL_MIS_DET        IN OUT MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE,
                            P_UPL_UDF_DET        IN OUT UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF,
                            P_OVERRIDE_FLAG      IN OUT VARCHAR2,
                            P_FN_CALL_ID         IN NUMBER,
                            P_TB_CLUSTER_DATA    IN OUT GLOBAL.TY_TB_CLUSTER_DATA,
                            P_ERR_CODE           IN OUT VARCHAR2,
                            P_ERR_PARAM          IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('**', 'Inside fn_close_custacc..');
  
    DEBUG.PR_DEBUG('**', 'Returning successfully from fn_close_custacc..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of fn_close_custacc' || SQLERRM);
      RETURN FALSE;
  END;

  FUNCTION FN_REDBY_PC(P_CLOSE_REQD         IN VARCHAR2,
                       P_TY_ACC_CLOSURE_DET IN OUT STPKS_ACCOUNT_CLOSE.TY_ACC_CLOSURE_DET,
                       P_TY_PAYOUTDETS      IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                       P_PCPAYOUTDETS_REC   IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                       P_ERR_CODE           IN OUT VARCHAR2,
                       P_ERR_PARAM          IN OUT VARCHAR2,
                       P_FN_CALL_ID         IN OUT NUMBER,
                       P_TB_CUSTOM_DATA     IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('**', 'Inside fn_redby_pc..');
    DEBUG.PR_DEBUG('**', 'Returning successfully from fn_redby_pc..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of fn_redby_pc');
      RETURN FALSE;
  END FN_REDBY_PC;

  FUNCTION FN_PRE_ONLINE_LIQ(P_TY_ACC_CLOSURE_DET IN OUT STPKS_ACCOUNT_CLOSE.TY_ACC_CLOSURE_DET,
                             P_CLOSE_REQD         OUT CHAR,
                             P_ERR_CODE           OUT VARCHAR2,
                             P_ERR_PARAM          OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of stpks_account_close_custom.Fn_Pre_Online_Liq');
  
    DBG('Returning Success from stpks_account_close_custom.Fn_Pre_Online_Liq');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of Fn_Pre_Online_Liq' || SQLERRM);
      RETURN FALSE;
  END FN_PRE_ONLINE_LIQ;

  FUNCTION FN_POST_ONLINE_LIQ(P_TY_ACC_CLOSURE_DET IN OUT STPKS_ACCOUNT_CLOSE.TY_ACC_CLOSURE_DET,
                              P_CLOSE_REQD         OUT CHAR,
                              P_ERR_CODE           OUT VARCHAR2,
                              P_ERR_PARAM          OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of stpks_account_close_custom.Fn_Post_Online_Liq');
  
    DBG('Returning Success from stpks_account_close_custom.Fn_Post_Online_Liq');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of Fn_Post_Online_Liq' || SQLERRM);
      RETURN FALSE;
  END FN_POST_ONLINE_LIQ;

END STPKS_ACCOUNT_CLOSE_CUSTOM;
