insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('AIA_ACCOUNT', 'Corporate Account of AIA Insurance Company', 'SAMPATH2', 'SAMPATH2', to_date('11-11-2020 16:06:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('11-11-2020 16:06:31', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '2', 'Y');

COMMIT;
