CREATE OR REPLACE PACKAGE BODY ifpks_ifdaiaft_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdaiaft_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2021 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  SFR Number         :
  Changed By         :
  Change Description :

  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdaiaft_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;

    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN

    SELECT TRSQ_AIA_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;

    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

    RETURN L_REF;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  FUNCTION FN_GET_AIA_POLICY_ENQUIRY RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_AIA_POLICY_ENQUIRY');

    L_FORMATTED_MSG := '{"channelCode":"CBS","insuranceCode":"$L_INSURANCE_CODE","policyNumber":"$L_POLICY_NUMBER"}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_AIA_POLICY_ENQUIRY');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AIA_POLICY_ENQUIRY');
      DBG('ERROR CODE IN FN_GET_AIA_POLICY_ENQUIRY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AIA_POLICY_ENQUIRY=' || SQLERRM);

  END FN_GET_AIA_POLICY_ENQUIRY;

  FUNCTION FN_GET_FMT_AIA_POLICY_ENQ(p_ifdaiaft IN OUT IFPKS_IFDAIAFT_MAIN.ty_ifdaiaft)
    RETURN CLOB IS

    L_INSURANCE_CODE VARCHAR2(105);
    L_POLICY_NUMBER  VARCHAR2(105);
    L_FORMATTED_MSG  CLOB; --varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_GET_FMT_AIA_POLICY_ENQ');

    L_FORMATTED_MSG := FN_GET_AIA_POLICY_ENQUIRY;

    DBG('BEFORE REPLACEMENT OF AIA ACC ENQUIRY JSON=' || L_FORMATTED_MSG);

    dbg('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10=' ||
        p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10);
    dbg('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD11=' ||
        p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD11);

    --Replace tags with actual values
    L_INSURANCE_CODE := 'AIA001'; --p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10;

    DBG('L_INSURANCE_CODE=' || L_INSURANCE_CODE);

    L_POLICY_NUMBER := p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD11;

    DBG('L_POLICY_NUMBER=' || L_POLICY_NUMBER);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSURANCE_CODE',
                               L_INSURANCE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_POLICY_NUMBER',
                               L_POLICY_NUMBER);

    DBG('AFTER REPLACEMENT OF AIA POLICY ENQUIRY JSON=' || L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_AIA_POLICY_ENQ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_AIA_POLICY_ENQ');
      DBG('ERROR CODE IN FN_GET_FMT_AIA_POLICY_ENQ=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_AIA_POLICY_ENQ=' || SQLERRM);
  END FN_GET_FMT_AIA_POLICY_ENQ;

  FUNCTION FN_GET_AIA_PAYMENT RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_AIA_PAYMENT');

    L_FORMATTED_MSG := '{"channelCode":"CBS","insuranceCode":"$L_INSURANCE_CODE","transactionUniqueNo":"$L_TXN_UNIQUE_NO","policyNumber":"$L_POLICY_NUMBER"
    ,"amount":"$L_AMOUNT","currency":"$L_CCY"}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_AIA_PAYMENT');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_AIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AIA_PAYMENT=' || SQLERRM);

  END FN_GET_AIA_PAYMENT;

  FUNCTION FN_GET_FMT_AIA_PAYMENT(p_ifdaiaft IN OUT IFPKS_IFDAIAFT_MAIN.ty_ifdaiaft)
    RETURN CLOB IS

    L_TXN_UNIQUE_NO  IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE; --need to change to enquiry id
    L_INSURANCE_CODE VARCHAR2(105);
    L_POLICY_NUMBER  VARCHAR2(105);
    L_AMOUNT         VARCHAR2(105);
    L_CCY            VARCHAR2(3);
    L_FORMATTED_MSG  CLOB; --varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_FMT_AIA_PAYMENT');

    L_FORMATTED_MSG := FN_GET_AIA_PAYMENT;

    DBG('BEFORE REPLACEMENT OF AIA PAYMENT JSON=' || L_FORMATTED_MSG);

    --Replace tags with actual values
    L_TXN_UNIQUE_NO := p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD9; --need to change to enquiry id

    DBG('L_TXN_UNIQUE_NO=' || L_TXN_UNIQUE_NO);

    L_INSURANCE_CODE := 'AIA001'; --p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10;

    DBG('L_INSURANCE_CODE=' || L_INSURANCE_CODE);

    L_POLICY_NUMBER := p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD11;

    DBG('L_POLICY_NUMBER=' || L_POLICY_NUMBER);

    L_AMOUNT := p_ifdaiaft.v_iftb_aia_master.cr_amount;--p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD7;

    DBG('L_AMOUNT=' || L_AMOUNT);

    L_CCY := p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD8;

    DBG('L_CCY=' || L_CCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_UNIQUE_NO',
                               L_TXN_UNIQUE_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSURANCE_CODE',
                               L_INSURANCE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_POLICY_NUMBER',
                               L_POLICY_NUMBER);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CCY', L_CCY);

    DBG('BEFORE REPLACEMENT OF AIA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_AIA_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_AIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_AIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_AIA_PAYMENT=' || SQLERRM);

  END FN_GET_FMT_AIA_PAYMENT;

  PROCEDURE PR_INSERT_AIA_WS_LOG(P_SEQ_NO        IN VARCHAR2,
                                 P_XREF          IN VARCHAR2,
                                 P_INVOKE_DATE   IN VARCHAR2,
                                 P_POLICY_NUMBER IN VARCHAR2,
                                 P_REQ_TYPE      IN VARCHAR2,
                                 P_REQ_MSG       IN VARCHAR2,
                                 P_ADDL_INFO     IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN
    DBG('START OF PR_INSERT_AIA_WS_LOG');

    INSERT INTO IFTB_AIA_WS_LOG
      (SEQ_NO,
       TRN_REF_NO,
       INVOKE_DATE,
       POLICY_NUMBER,
       REQ_TYPE,
       REQ_MSG,
       ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_XREF,
       P_INVOKE_DATE,
       P_POLICY_NUMBER,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ADDL_INFO);

    COMMIT;

    DBG('END OF PR_INSERT_AIA_WS_LOG');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_AIA_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_AIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_AIA_WS_LOG=' || SQLERRM);

  END PR_INSERT_AIA_WS_LOG;

  PROCEDURE PR_UPDATE_AIA_WS_LOG(P_XREF          IN IFTB_AIA_MASTER.TRN_REF_NO%TYPE,
                                 P_SEQ_NO        IN VARCHAR2,
                                 P_TXN_UNIQUE_NO IN IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE,
                                 P_STATUS        IN CHAR,
                                 P_RES_MSG       IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_AIA_WS_LOG');

    UPDATE IFTB_AIA_WS_LOG
       SET TXN_UNIQUE_NO = P_TXN_UNIQUE_NO,

           RES_MSG = P_RES_MSG,
           STATUS  = P_STATUS
     WHERE TRN_REF_NO = P_XREF
       AND SEQ_NO = P_SEQ_NO;

    COMMIT;

    DBG('END OF PR_UPDATE_AIA_WS_LOG');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_AIA_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_AIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_AIA_WS_LOG=' || SQLERRM);
  END PR_UPDATE_AIA_WS_LOG;

  /*FUNCTION fn_save(p_ifdaiaft              IN OUT ifpks_ifdaiaft_main.ty_ifdaiaft,
                   pkg_detb_rtl_teller_rec IN OUT detbs_rtl_teller%ROWTYPE,
                   p_err_code              IN OUT VARCHAR2,
                   p_err_params            IN OUT VARCHAR2) RETURN BOOLEAN IS

    l_cust_ac    sttm_cust_account%ROWTYPE;
    l_arc_maint  iftms_arc_maint%ROWTYPE;
    l_cust       sttm_customer%ROWTYPE;
    l_prod       cstm_product%ROWTYPE;
    l_ib_flag    VARCHAR2(1) DEFAULT 'Y';
    l_txn_amt    iftbs_fast_master.txn_amt%TYPE;
    l_txn_amt1   iftbs_fast_master.txn_amt%TYPE;
    l_rate       NUMBER;
    l_rate_code  cstm_product.rate_code_preferred%Type;
    l_rate_code1 cstm_product.rate_code_preferred%Type;

  BEGIN
    dbg('In FN_SAVE');

    SELECT x.* INTO l_prod FROM cstm_product x WHERE product_code = 'AIAO';

    SELECT x.*
      INTO l_cust_ac
      FROM sttm_cust_account x
     WHERE x.cust_ac_no = p_ifdaiaft.v_iftb_aia_master.DR_ACC_NO;

    -- msg id

    SELECT x.*
      INTO l_cust
      FROM sttm_customer x
     WHERE x.customer_no = l_cust_ac.cust_no;

    cspkss_arc.pr_get_arc_row(GLOBAL.current_branch, --l_cust_ac.branch_code,
                              'AIAO',
                              'P',
                              '*.*', -- trans_type
                              p_ifdaiaft.v_iftb_aia_master.TXN_CCY,
                              l_ib_flag,
                              l_arc_maint,
                              p_err_code,
                              p_err_params,
                              p_ifdaiaft.v_iftb_aia_master.DR_ACC_NO,
                              GLOBAL.current_branch);

    IF p_err_code IS NOT NULL THEN
      dbg('CSPKSS_ARC.PR_GET_ARC_ROW returned false');
      RETURN FALSE;
    END IF;

    pkg_detb_rtl_teller_rec.xref         := p_ifdaiaft.v_iftb_aia_master.trn_ref_no;
    pkg_detb_rtl_teller_rec.product_code := 'AIAO';
    pkg_detb_rtl_teller_rec.branch_code  := GLOBAL.CURRENT_BRANCH;
    pkg_detb_rtl_teller_rec.trn_ref_no   := p_ifdaiaft.v_iftb_aia_master.trn_ref_no;

    pkg_detb_rtl_teller_rec.txn_acc := p_ifdaiaft.v_iftb_aia_master.DR_ACC_NO;
    pkg_detb_rtl_teller_rec.txn_ccy := l_cust_ac.ccy;
    --pkg_detb_rtl_teller_rec.txn_branch := GLOBAL.CURRENT_BRANCH;
    DBG('l_cust_ac.branch_code=' || l_cust_ac.branch_code);
    pkg_detb_rtl_teller_rec.txn_branch := l_cust_ac.branch_code;

    pkg_detb_rtl_teller_rec.ofs_acc    := l_arc_maint.cod_offset_acc;
    pkg_detb_rtl_teller_rec.ofs_ccy    := p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY;
    pkg_detb_rtl_teller_rec.ofs_amount := p_ifdaiaft.v_iftb_aia_master.CR_AMOUNT; --p_ifdaiaft.v_iftb_aia_master.txn_amt;
    \* pkg_detb_rtl_teller_rec.ofs_branch := REPLACE(l_arc_maint.cod_offset_brn,
                                                    '*.*',
                                                    GLOBAL.CURRENT_BRANCH);
    *\
    --Get Nostro Account Branch for the offset leg
    BEGIN
      SELECT BRANCH_CODE
        INTO pkg_detb_rtl_teller_rec.ofs_branch
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = pkg_detb_rtl_teller_rec.ofs_acc;
    EXCEPTION
      WHEN OTHERS THEN
        pkg_detb_rtl_teller_rec.ofs_branch := '991';
    END;

    -- Begin ACCOUNTING ENTRIES Display and fix for Wrong Exch calculation
    \*IF p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY <>
       pkg_detb_rtl_teller_rec.ofs_ccy THEN
      l_rate     := NULL;
      l_txn_amt1 := p_ifdaiaft.v_iftb_aia_master.TXN_AMOUNT;

      If l_prod.rate_code_preferred = 'B' Then
        l_rate_code := Null;
        If (p_ifdaiaft.v_iftb_aia_master.TXN_CCY = global.lcy and
           l_cust_ac.ccy != global.lcy) Or
           (p_ifdaiaft.v_iftb_aia_master.TXN_CCY != global.lcy and
           l_cust_ac.ccy <> global.lcy and
           p_ifdaiaft.v_iftb_aia_master.TXN_CCY <> l_cust_ac.ccy) Then
          l_rate_code := 'B';
        Elsif p_ifdaiaft.v_iftb_aia_master.TXN_CCY != global.lcy and
              l_cust_ac.ccy = global.lcy Then
          l_rate_code := 'S';
        Else
          l_rate_code := l_prod.rate_code_preferred;
        End If;
      Else
        l_rate_code := l_prod.rate_code_preferred;
      End If;

      dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
          l_rate_code1);
      If l_cust_ac.ccy <> global.lcy Then
        begin
          select decode(l_rate_code,
                        'B',
                        'S',
                        'S',
                        'B',
                        'M',
                        'M',
                        l_rate_code)
            Into l_rate_code1
            from dual;
        exception
          when others then
            dbg('Exception found l_rate_code-> ' || l_rate_code);
        end;
      End If;
      dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
          l_rate_code1);

      IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdaiaft.v_iftb_aia_master.TXN_CCY, --check this one
                                    p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY,
                                    l_txn_amt1,
                                    p_ifdaiaft.v_iftb_aia_master.exch_rate,
                                    'Y',
                                    l_txn_amt,
                                    p_err_params) THEN
        RETURN FALSE;
      END IF;
    END IF;
    dbg('l_txn_amt1->' || l_txn_amt1);
    dbg('l_txn_amt1->' || l_txn_amt);*\

    DBG('p_ifdaiaft.v_iftb_aia_master.DR_AMOUNT=' ||
        p_ifdaiaft.v_iftb_aia_master.DR_AMOUNT);

    pkg_detb_rtl_teller_rec.txn_amount := p_ifdaiaft.v_iftb_aia_master.DR_AMOUNT; --l_txn_amt;

    DBG('pkg_detb_rtl_teller_rec.txn_amount=' ||
        pkg_detb_rtl_teller_rec.txn_amount);

    --p_ifdaiaft.v_iftb_aia_master.CR_AMOUNT := l_txn_amt;
    -- END

    pkg_detb_rtl_teller_rec.txn_trn_code := l_arc_maint.cod_main_txn_code;
    pkg_detb_rtl_teller_rec.ofs_trn_code := l_arc_maint.cod_offset_txn_code;

    -- IF l_cust_ac.ccy <> p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY THEN

    pkg_detb_rtl_teller_rec.exch_rate := p_ifdaiaft.v_iftb_aia_master.exch_rate;

    -- ELSE

    --  pkg_detb_rtl_teller_rec.exch_rate := 1;

    -- END IF;

    pkg_detb_rtl_teller_rec.trn_dt           := GLOBAL.APPLICATION_dATE;
    pkg_detb_rtl_teller_rec.value_dt         := GLOBAL.APPLICATION_dATE;
    pkg_detb_rtl_teller_rec.rel_customer     := l_cust_ac.cust_no;
    pkg_detb_rtl_teller_rec.benef_name       := l_cust.customer_name1;
    pkg_detb_rtl_teller_rec.benef_addr1      := l_cust.address_line1;
    pkg_detb_rtl_teller_rec.benef_addr2      := l_cust.address_line2;
    pkg_detb_rtl_teller_rec.benef_addr3      := l_cust.address_line3;
    pkg_detb_rtl_teller_rec.benef_addr4      := l_cust.address_line4;
    pkg_detb_rtl_teller_rec.liqn_dt          := GLOBAL.application_date;
    pkg_detb_rtl_teller_rec.record_stat      := 'A';
    pkg_detb_rtl_teller_rec.auth_stat        := 'U';
    pkg_detb_rtl_teller_rec.maker_id         := GLOBAL.USER_ID;
    pkg_detb_rtl_teller_rec.maker_dt_stamp   := p_ifdaiaft.v_iftb_aia_master.maker_dt_stamp;
    pkg_detb_rtl_teller_rec.checker_id       := p_ifdaiaft.v_iftb_aia_master.checker_id;
    pkg_detb_rtl_teller_rec.checker_dt_stamp := p_ifdaiaft.v_iftb_aia_master.checker_dt_stamp;
    pkg_detb_rtl_teller_rec.mod_no           := p_ifdaiaft.v_iftb_aia_master.mod_no;
    pkg_detb_rtl_teller_rec.scode            := 'FLEXCUBE';
    pkg_detb_rtl_teller_rec.dr_acc           := l_arc_maint.dr_acc;
    pkg_detb_rtl_teller_rec.module           := 'RT';
    pkg_detb_rtl_teller_rec.esn              := 1;
    pkg_detb_rtl_teller_rec.event_code       := 'INIT';
    pkg_detb_rtl_teller_rec.track_receivable := 'N';
    pkg_detb_rtl_teller_rec.time_received    := SYSDATE;

    dbg('Calling depks_rtl_teller.fn_save');

    IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                    p_err_code,
                                    p_err_params) THEN
      dbg('Failed in Fn_Save');
      RETURN FALSE;
    END IF;
    dbg('Calling depks_rtl_teller.pr_messaging');
    --depks_rtl_teller.pr_messaging;

    dbg('Returning Success From FN_SAVE..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdbongl_Custom.FN_SAVE ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_save;*/

  FUNCTION FN_AIA_WS_CALL(p_AIA_call in varchar2,
                          p_out_msg  VARCHAR2,
                          p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS

    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255);
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);

    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;

  BEGIN
    dbg('START OF FN_AIA_WS_CALL');

    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));

    IF p_AIA_call = 'I' THEN

      L_URL := FN_GET_PARAM_VAL('PGW_AIA_POLICY_ENQ_URL');

    ELSIF p_AIA_call = 'C' THEN

      L_URL := FN_GET_PARAM_VAL('PGW_AIA_PAYCONFIRM_URL');

    END IF;

    DBG('l_url-->' || L_URL);

    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');

    utl_http.set_authentication(l_http_request,
                                FN_GET_PARAM_VAL('PGW_AIA_AUTH_UID'),
                                FN_GET_PARAM_VAL('PGW_AIA_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
    utl_http.set_header(l_http_request,
                        'content-type',
                        'application/x-www-form-urlencoded');
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));

    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');

    utl_http.set_transfer_timeout(300);

    utl_http.write_text(l_http_request, p_out_msg);

    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));

    l_http_response := utl_http.get_response(l_http_request);

    dbg('Response> status_code: "' || l_http_response.status_code || '"');

    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;

    DBG('l_resp_num=' || l_resp_num);

    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;

    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;

      p_in_resp := buffer1;

      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);

    END IF;

    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;

    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;

    --    dbms_lob.freetemporary(buffer1); --buffer2 may be check

    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('Error Line Number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_AIA_WS_CALL;

  FUNCTION fn_msg_upload(p_ifdaiaft   IN OUT IFPKS_IFDAIAFT_MAIN.ty_ifdaiaft,
                         P_REQ_TYPE   IN VARCHAR2,
                         P_REQ_MSG    IN OUT CLOB,
                         P_ADDL_INFO  IN VARCHAR2,
                         p_err_code   IN OUT VARCHAR2,
                         p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS

    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;

    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);

    L_CLIENT_NAME          VARCHAR2(105);
    L_email                VARCHAR2(105);
    L_phone                VARCHAR2(105);
    l_paymentDueDate       VARCHAR2(105);
    l_allowPartialPayment  VARCHAR2(105);
    l_allowSchedulePayment VARCHAR2(105);
    l_frequency            VARCHAR2(105);
    l_maturityDate         VARCHAR2(105);
    l_amount               VARCHAR2(105);
    l_currency             VARCHAR2(105);
    l_transactionUniqueNo  VARCHAR2(105);

    L_insuranceTransactionNo VARCHAR2(105);

    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);

  BEGIN

    dbg('Inside fn_msg_upload');

    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);

    --Log Webservice Call
    PR_INSERT_AIA_WS_LOG(L_GEN_SEQ_NO,
                         p_ifdaiaft.v_iftb_aia_master.trn_ref_no,
                         SYSDATE,
                         p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD11,
                         P_REQ_TYPE,
                         P_REQ_MSG,
                         P_ADDL_INFO);

    IF NOT FN_AIA_WS_CALL(P_REQ_TYPE, P_REQ_MSG, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;

    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);

    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);

    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);

    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);

    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;

    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;

    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);

    IF L_STATUS_CODE <> '000' THEN

      p_err_code := 'IF-AIA-000';

      OVPKSS.PR_APPENDTBL(p_err_code, L_STATUS_MSG || '~');

      RETURN FALSE;

    END IF;

    --Handle All Errro Codes ad return false

    IF P_REQ_TYPE = 'I' THEN

      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN

        L_CLIENT_NAME := P_DOCUMENT_XML.EXTRACT('/root/data/clientName/text()')
                         .GETSTRINGVAL;

        DBG('L_CLIENT_NAME =' || L_CLIENT_NAME);

        p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD2 := L_CLIENT_NAME;

        IF INSTR(L_RESP_IN_XML, '<email>') >0 THEN
        
        L_email := P_DOCUMENT_XML.EXTRACT('/root/data/email/text()')
                   .GETSTRINGVAL;

        DBG('L_email =' || L_email);
        
        END IF;

        p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD3 := L_email;

        L_phone := P_DOCUMENT_XML.EXTRACT('/root/data/phone/text()')

                   .GETSTRINGVAL;

        DBG('L_phone =' || L_phone);

        p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD4 := L_phone;

        l_paymentDueDate := P_DOCUMENT_XML.EXTRACT('/root/data/paymentDueDate/text()')

                            .GETSTRINGVAL;

        DBG('l_paymentDueDate =' || l_paymentDueDate);

        p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD5 := l_paymentDueDate;

        l_allowPartialPayment := P_DOCUMENT_XML.EXTRACT('/root/data/allowPartialPayment/text()')

                                 .GETSTRINGVAL;

        DBG('l_allowPartialPayment =' || l_allowPartialPayment);

        p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD6 := l_allowPartialPayment;

        l_allowSchedulePayment := P_DOCUMENT_XML.EXTRACT('/root/data/allowSchedulePayment/text()')

                                  .GETSTRINGVAL;

        DBG('l_allowSchedulePayment =' || l_allowSchedulePayment);

        p_ifdaiaft.v_cstb_ui_columns.char_field42 := l_allowSchedulePayment;

        l_frequency := P_DOCUMENT_XML.EXTRACT('/root/data/frequency/text()')

                       .GETSTRINGVAL;

        DBG('l_frequency =' || l_frequency);

        p_ifdaiaft.v_cstb_ui_columns.char_field42 := l_frequency;

        l_maturityDate := P_DOCUMENT_XML.EXTRACT('/root/data/maturityDate/text()')

                          .GETSTRINGVAL;

        DBG('l_maturityDate =' || l_maturityDate);

        p_ifdaiaft.v_cstb_ui_columns.char_field42 := l_maturityDate;

        l_amount := P_DOCUMENT_XML.EXTRACT('/root/data/amount/text()')

                    .GETSTRINGVAL;

        DBG('l_amount =' || l_amount);

        p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD7 := l_amount;

        l_currency := P_DOCUMENT_XML.EXTRACT('/root/data/currency/text()')

                      .GETSTRINGVAL;

        DBG('l_currency =' || l_currency);

        p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD8 := l_currency;

        l_transactionUniqueNo := P_DOCUMENT_XML.EXTRACT('/root/data/transactionUniqueNo/text()')

                                 .GETSTRINGVAL;

        DBG('l_transactionUniqueNo =' || l_transactionUniqueNo);

        p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD9 := l_transactionUniqueNo;

        PR_UPDATE_AIA_WS_LOG(p_ifdaiaft.v_iftb_aia_master.trn_ref_no,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'S',
                             L_IN_RESP);

      ELSE

        PR_UPDATE_AIA_WS_LOG(p_ifdaiaft.v_iftb_aia_master.trn_ref_no,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'F',
                             L_IN_RESP);

        RETURN FALSE;

      END IF;
    END IF;

    IF P_REQ_TYPE = 'C' THEN

      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN

        L_insuranceTransactionNo := P_DOCUMENT_XML.EXTRACT('/root/data/insuranceTransactionNo/text()')

                                    .GETSTRINGVAL;

        DBG('L_insuranceTransactionNo =' || L_insuranceTransactionNo);

        PR_UPDATE_AIA_WS_LOG(p_ifdaiaft.v_iftb_aia_master.trn_ref_no,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'S',
                             L_IN_RESP);

        RETURN TRUE;

      ELSE

        PR_UPDATE_AIA_WS_LOG(p_ifdaiaft.v_iftb_aia_master.trn_ref_no,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'F',
                             L_IN_RESP);

        IF L_STATUS_CODE = 'ERROR_402' AND
           L_STATUS_MSG = 'Transfer is expired' THEN

          dbg('BONGLOY TRANSFER IS EXPIRED');

          p_err_code := 'IF-BNG-002';

          OVPKSS.PR_APPENDTBL(P_ERR_CODE, L_STATUS_MSG);

          RETURN FALSE;

        END IF;

        RETURN FALSE;

      END IF;
    END IF;

    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      RETURN FALSE;
  END fn_msg_upload;

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdaiaft         IN OUT ifpks_ifdaiaft_Main.ty_ifdaiaft,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Build_type_structure..');

    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of ifpks_ifdaiaft_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION FN_POST_ACC_ENTRY(p_ifdaiaft IN OUT ifpks_ifdaiaft_Main.ty_ifdaiaft)
    RETURN BOOLEAN IS

    pkg_detb_rtl_teller_rec detbs_rtl_teller%ROWTYPE;
    L_CUST_AC               STTM_CUST_ACCOUNT%ROWTYPE;
    L_CUST                  STTM_CUSTOMER%ROWTYPE;
    l_rate                  NUMBER;
    P_ERR_CODE              VARCHAR2(255);
    P_ERR_PARAMS            VARCHAR2(255);
    L_TILL_CASH_GL          DETMS_TIL_VLT_CCY_PARAMS.CASH_GL%TYPE;
    L_TILL_ID               SMTB_USER_TILLS.TILL_ID%TYPE;
    L_LMTM_TYPE_VALUES      LMTM_TYPE_VALUES%ROWTYPE;
    L_TILL_VLT_IND          FBTB_TILL_MASTER.TIL_VLT_IND%TYPE;
    L_ARC_MAINT             IFTM_ARC_MAINT%ROWTYPE;

  BEGIN

    pkg_detb_rtl_teller_rec.xref := p_ifdaiaft.v_iftb_aia_master.trn_ref_no;

    pkg_detb_rtl_teller_rec.product_code := 'AIAO';

    --Get Arc Maintenance
    SELECT *
      INTO L_ARC_MAINT
      FROM IFTM_ARC_MAINT A
     WHERE A.COD_PROD_ACC_CLS = pkg_detb_rtl_teller_rec.product_code
       AND ROWNUM = 1;

    --Get Acc Details
    SELECT x.*
      INTO l_cust_ac
      FROM sttm_cust_account x
     WHERE x.cust_ac_no = p_ifdaiaft.v_iftb_aia_master.DR_ACC_NO;

    DBG('p_ifdaiaft.v_iftb_aia_master.DR_ACC_NO=' ||
        p_ifdaiaft.v_iftb_aia_master.DR_ACC_NO);

    --GET BEN CUSTOMER DETAILS
    BEGIN
      SELECT X.*
        INTO L_CUST
        FROM STTM_CUSTOMER X
       WHERE X.CUSTOMER_NO = l_cust_ac.cust_no;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN GETTING CUSTOMER DETAILS');
    END;

    --pkg_detb_rtl_teller_rec.product_code := 'CCFT';

    pkg_detb_rtl_teller_rec.branch_code := GLOBAL.CURRENT_BRANCH;
    pkg_detb_rtl_teller_rec.trn_ref_no  := p_ifdaiaft.v_iftb_aia_master.trn_ref_no;

    pkg_detb_rtl_teller_rec.txn_acc    := p_ifdaiaft.v_iftb_aia_master.CR_ACC_NO;
    pkg_detb_rtl_teller_rec.txn_ccy    := p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY;
    pkg_detb_rtl_teller_rec.txn_branch := '032'; --GLOBAL.CURRENT_BRANCH;
    --pkg_detb_rtl_teller_rec.txn_branch := pkg_detb_rtl_teller_rec.ofs_branch;

    pkg_detb_rtl_teller_rec.ofs_acc    := p_ifdaiaft.v_iftb_aia_master.DR_ACC_NO;
    pkg_detb_rtl_teller_rec.ofs_ccy    := p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY;
    pkg_detb_rtl_teller_rec.ofs_amount := p_ifdaiaft.v_iftb_aia_master.DR_AMOUNT;

    pkg_detb_rtl_teller_rec.ofs_branch := l_cust_ac.Branch_Code; --GLOBAL.current_branch;

    pkg_detb_rtl_teller_rec.txn_amount := p_ifdaiaft.v_iftb_aia_master.cr_amount; --pls check this

    pkg_detb_rtl_teller_rec.txn_trn_code     := L_ARC_MAINT.COD_MAIN_TXN_CODE; --'000'; --transacion code
    pkg_detb_rtl_teller_rec.ofs_trn_code     := L_ARC_MAINT.COD_OFFSET_TXN_CODE; --'000'; --transacion code
    pkg_detb_rtl_teller_rec.exch_rate        := p_ifdaiaft.v_iftb_aia_master.exch_rate;
    pkg_detb_rtl_teller_rec.trn_dt           := GLOBAL.application_date;
    pkg_detb_rtl_teller_rec.value_dt         := GLOBAL.application_date;
    pkg_detb_rtl_teller_rec.rel_customer     := L_CUST.customer_no;
    pkg_detb_rtl_teller_rec.benef_name       := L_CUST.customer_name1;
    pkg_detb_rtl_teller_rec.benef_addr1      := L_CUST.address_line1;
    pkg_detb_rtl_teller_rec.benef_addr2      := L_CUST.address_line2;
    pkg_detb_rtl_teller_rec.benef_addr3      := L_CUST.address_line3;
    pkg_detb_rtl_teller_rec.benef_addr4      := L_CUST.address_line4;
    pkg_detb_rtl_teller_rec.liqn_dt          := GLOBAL.application_date;
    pkg_detb_rtl_teller_rec.record_stat      := 'A';
    pkg_detb_rtl_teller_rec.auth_stat        := 'U';
    pkg_detb_rtl_teller_rec.maker_id         := GLOBAL.USER_ID;
    pkg_detb_rtl_teller_rec.maker_dt_stamp   := p_ifdaiaft.v_iftb_aia_master.maker_dt_stamp;
    pkg_detb_rtl_teller_rec.checker_id       := p_ifdaiaft.v_iftb_aia_master.checker_id;
    pkg_detb_rtl_teller_rec.checker_dt_stamp := p_ifdaiaft.v_iftb_aia_master.checker_dt_stamp;
    pkg_detb_rtl_teller_rec.mod_no           := p_ifdaiaft.v_iftb_aia_master.mod_no;
    pkg_detb_rtl_teller_rec.scode            := 'FLEXCUBE';
    pkg_detb_rtl_teller_rec.dr_acc           := 'OFS';
    pkg_detb_rtl_teller_rec.module           := 'RT';
    pkg_detb_rtl_teller_rec.esn              := 1;
    pkg_detb_rtl_teller_rec.event_code       := 'INIT';
    pkg_detb_rtl_teller_rec.track_receivable := 'N';
    pkg_detb_rtl_teller_rec.time_received    := SYSDATE;

    dbg('Calling depks_rtl_teller.fn_save');

    IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                    p_err_code,
                                    p_err_params) THEN
      dbg('Failed in Fn_Save');
      PR_LOG_ERROR('IFDCCPFT', 'FLEXCUBE', p_err_code, p_err_params);
      RETURN FALSE;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN FALSE;
  END FN_POST_ACC_ENTRY;

  FUNCTION fn_enrich_product(p_ifdaiaft   IN OUT ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
    l_serial_no  VARCHAR2(16);
    l_trn_ref_no iftb_rft_master.trn_ref_no%TYPE;

  BEGIN

    IF p_ifdaiaft.v_iftb_aia_master.trn_ref_no IS NULL THEN
      IF NOT trpkss.fn_get_product_refno(GLOBAL.current_branch,
                                         'AIAO',
                                         global.application_date,
                                         l_serial_no,
                                         l_trn_ref_no,
                                         p_err_code) THEN
        dbg('Failed in generation Transaction Ref No');
        RETURN FALSE;
      ELSE
        dbg('l_trn_ref_no=' || l_trn_ref_no);
        p_ifdaiaft.v_iftb_aia_master.trn_ref_no := l_trn_ref_no;

      END IF;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN

      debug.pr_debug('**',
                     'In When Others of ifpks_ifdaiadr_Custom.FN_ENRICH_PRODUCT ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;

  END fn_enrich_product;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdaiaft         IN OUT ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
    l_formatted_msg CLOB;
    L_COUNT         NUMBER;
    L_EXCH_RATE     ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE_FLAG     NUMBER;
    L_TXN_AMT       IFTB_AIA_MASTER.TXN_AMOUNT%TYPE;
    L_DEBIT_AMT     IFTB_AIA_MASTER.DR_AMOUNT%TYPE;
    L_CREDIT_AMT    IFTB_AIA_MASTER.CR_AMOUNT%TYPE;
    L_EXCH_RATE_ONLY_DISPLAY ACTB_DAILY_LOG.EXCH_RATE%TYPE;

  BEGIN

    Dbg('In Fn_Pre_Check_Mandatory');

    dbg('p_Action_Code' || p_action_code);

    IF p_Action_Code = 'PICKUP'  OR p_Action_Code = cspks_req_global.p_new THEN --Exchange Rate Input Changes

      DBG('I am in PICKUP');

      DBG('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD2=' ||
          p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD2);
      DBG('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD3=' ||
          p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD3);
      DBG('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD4=' ||
          p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD4);
      DBG('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD5=' ||
          p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD5);
      DBG('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD6=' ||
          p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD6);
      DBG('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD7=' ||
          p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD7);
      DBG('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD8=' ||
          p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD8);
      DBG('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD9=' ||
          p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD9);
      DBG('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10=' ||
          p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10);
      DBG('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD11=' ||
          p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD11);

      IF p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD2 IS NULL OR
         --p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD3 IS NULL OR
         p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD4 IS NULL OR
         p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD5 IS NULL OR
         p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD6 IS NULL OR
         p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD7 IS NULL OR
         p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD8 IS NULL OR
         p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD9 IS NULL OR
        --p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10 IS NULL OR
         p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD11 IS NULL THEN

        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IF-SVCC001', NULL);
        RETURN FALSE;
      END IF;

      IF p_ifdaiaft.v_iftb_aia_master.CR_ACC_NO IS NULL or
         p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY is null then

        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IF-AIA-001', NULL);
        RETURN FALSE;

      END IF;

      --Currency Conversion
      IF p_ifdaiaft.v_iftb_aia_master.TXN_CCY <>
         p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY THEN

        --Get Exchange Rate
        IF p_ifdaiaft.v_iftb_aia_master.EXCH_RATE IS NOT NULL THEN --Exchange Rate Input Changes
          L_EXCH_RATE := p_ifdaiaft.v_iftb_aia_master.EXCH_RATE; --Exchange Rate Input Changes
        ELSE --Exchange Rate Input Changes
        IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                 p_ifdaiaft.v_iftb_aia_master.TXN_CCY,
                                 p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY, --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                 --'STANDARD', --Commercial Exchange Rate Changes Commented
                                 'COMM', --Commercial Exchange Rate Changes Added
                                 'S', --l_prod.rate_code_preferred,
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 L_EXCH_RATE,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          DBG('FAILED IN FN_GETRATE');
        END IF;
        END IF; --Exchange Rate Input Changes

      ELSE
        L_EXCH_RATE := 1;

      END IF;

      DBG('L_EXCH_RATE=' || L_EXCH_RATE);

      --p_ifdaiaft.v_iftb_aia_master.EXCH_RATE := L_EXCH_RATE;

      DBG('p_ifdaiaft.v_iftb_aia_master.EXCH_RATE=' ||
          p_ifdaiaft.v_iftb_aia_master.EXCH_RATE);

      --Using above rate..convert /*khr to usd amount*/  ...usd to khr amount
      --this is between txn ccy and debit acc ccy
      IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdaiaft.v_iftb_aia_master.TXN_CCY,
                                    p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY,
                                    p_ifdaiaft.v_iftb_aia_master.TXN_AMOUNT,
                                    L_EXCH_RATE,
                                    'Y',
                                    L_DEBIT_AMT,
                                    P_ERR_PARAMS) THEN
        DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
      END IF;
      dbg('FINAL L_DEBIT_AMT=' || L_DEBIT_AMT);

      p_ifdaiaft.v_iftb_aia_master.DR_AMOUNT := L_DEBIT_AMT;

      --check if debit currency not equal to credit acc currency
      IF p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY <>
         p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY AND
         p_ifdaiaft.v_iftb_aia_master.TXN_CCY <>
         p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY THEN

        --Get Exchange Rate
        IF p_ifdaiaft.v_iftb_aia_master.EXCH_RATE IS NOT NULL THEN --Exchange Rate Input Changes
          L_EXCH_RATE := p_ifdaiaft.v_iftb_aia_master.EXCH_RATE; --Exchange Rate Input Changes
        ELSE --Exchange Rate Input Changes
        IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                 p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY,
                                 p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY, --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                 --'STANDARD', --Commercial Exchange Rate Changes Commented
                                 'COMM', --Commercial Exchange Rate Changes Added
                                 CASE 
                                   WHEN p_ifdaiaft.v_iftb_aia_master.TXN_CCY = 'KHR' AND p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY = 'USD' THEN 'B'
                                   ELSE
                                 'S' --l_prod.rate_code_preferred,
                                 END,
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 L_EXCH_RATE,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          DBG('FAILED IN FN_GETRATE');
        END IF;
        END IF; --Exchange Rate Input Changes
      ELSE
        L_EXCH_RATE := 1;

      END IF;

      --only to dispaly exchange rate between debit and credit currencies starts
      IF p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY <>
         p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY AND p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY = 'KHR'
         AND p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY = 'USD' THEN

        --Get Exchange Rate
                IF p_ifdaiaft.v_iftb_aia_master.EXCH_RATE IS NOT NULL THEN --Exchange Rate Input Changes
          L_EXCH_RATE_ONLY_DISPLAY := p_ifdaiaft.v_iftb_aia_master.EXCH_RATE; --Exchange Rate Input Changes
        ELSE --Exchange Rate Input Changes
        IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                 p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY,
                                 p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY, --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                 --'STANDARD', --Commercial Exchange Rate Changes Commented
                                 'COMM', --Commercial Exchange Rate Changes Added
                                 
                                 'B' --l_prod.rate_code_preferred,
                                 ,
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 L_EXCH_RATE_ONLY_DISPLAY,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          DBG('FAILED IN FN_GETRATE');
        END IF;
        END IF; --Exchange Rate Input Changes

      ELSE
        L_EXCH_RATE_ONLY_DISPLAY := 1;

      END IF;
      DBG('L_EXCH_RATE_ONLY_DISPLAY='||L_EXCH_RATE_ONLY_DISPLAY);
      --only to dispaly exchange rate between debit and credit currencies ends

      p_ifdaiaft.v_iftb_aia_master.EXCH_RATE := L_EXCH_RATE_ONLY_DISPLAY;

      --Using above rate..convert /*khr to usd amount*/  ...usd to khr amount
      --this is between debit acc ccy and credit acc ccy

      IF p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY <>
         p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY AND
         p_ifdaiaft.v_iftb_aia_master.TXN_CCY <>
         p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY THEN
        IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY,
                                      p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY,
                                      p_ifdaiaft.v_iftb_aia_master.DR_AMOUNT,
                                      L_EXCH_RATE,
                                      'Y',
                                      L_CREDIT_AMT,
                                      P_ERR_PARAMS) THEN
          DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
        END IF;
      END IF;

      dbg('FINAL L_CREDIT_AMT=' || L_CREDIT_AMT);

      IF L_CREDIT_AMT = 0 THEN

        P_ERR_CODE := 'IF-AIA-003';

        Pr_Log_Error(p_Function_id, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

        RETURN FALSE;

      END IF;

      IF p_ifdaiaft.v_iftb_aia_master.DR_ACC_CCY <>
         p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY AND
         p_ifdaiaft.v_iftb_aia_master.TXN_CCY <>
         p_ifdaiaft.v_iftb_aia_master.CR_ACC_CCY THEN
      p_ifdaiaft.v_iftb_aia_master.CR_AMOUNT := L_CREDIT_AMT;

      ELSE

      p_ifdaiaft.v_iftb_aia_master.CR_AMOUNT := p_ifdaiaft.v_iftb_aia_master.TXN_AMOUNT;

      END IF;

    END IF;

    IF p_action_code = 'INVOKEAIA' THEN

      IF NOT fn_enrich_product(p_ifdaiaft, p_err_code, p_err_params) THEN
        dbg('Failed in Fn_Enrich_Product');
        RETURN FALSE;
      END IF;

      --Get AIA Account Enquiry
      dbg('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10=' ||
          p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10);
      dbg('p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD11=' ||
          p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD11);

      L_FORMATTED_MSG := FN_GET_FMT_AIA_POLICY_ENQ(p_ifdaiaft);

      DBG('AFTER REPLACEMENT OF AIA POLICY ENQUIRY JSON=' ||
          L_FORMATTED_MSG);

      DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

      DBG('CALLING AIA POLICY ENQUIRY WEBSERVICE');

      IF NOT FN_MSG_UPLOAD(p_ifdaiaft,
                           'I',
                           L_FORMATTED_MSG,
                           'Account Enquiry Call',
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN

        DBG('FAILED IN POLICY ENQUIRY CALL');

        RETURN FALSE;

      ELSE

        DBG('SUCCESS IN POLICY ENQUIRY CALL');

      END IF;

    END IF;

    --Save Transaction
    IF p_action_code = cspks_req_global.p_new THEN
      IF NOT FN_POST_ACC_ENTRY(p_ifdaiaft) THEN
        --p_ifdccpft.v_cstbs_ui_columns.char_field2) THEN

        DBG('FAILED IN CREDITING TO GL');
        RETURN FALSE;
      ELSE
        DBG('SUCCESS IN CREDITING TO GL');
        RETURN TRUE;
      END IF;
    END IF;

    --Delete Transaction
    IF p_action_code = cspks_req_global.p_delete THEN
      IF NOT depks_rtl_teller.fn_delete(p_ifdaiaft.v_iftb_aia_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in FN_DELETE');
        RETURN FALSE;
      END IF;
    END IF;

    --Auth Transaction
    IF p_action_code = cspks_req_global.p_auth THEN

      DBG('p_ifdaiaft.v_iftb_aia_master.MAKER_ID=' ||
          p_ifdaiaft.v_iftb_aia_master.MAKER_ID);

      DBG('p_ifdaiaft.v_iftb_aia_master.CHECKER_ID=' ||
          p_ifdaiaft.v_iftb_aia_master.CHECKER_ID);

      DBG('GLOBAL.USER_ID' || GLOBAL.USER_ID);

      --Maker Can not authorize
      IF p_ifdaiaft.v_iftb_aia_master.MAKER_ID = GLOBAL.USER_ID THEN
        pr_log_error(p_function_id, p_source, 'CF-AUT-002', NULL);
        RETURN FALSE;
      END IF;

      dbg(' Message generation success, going to upload now');

      --Get AIA CONFIRM PAYMENT
      L_FORMATTED_MSG := FN_GET_FMT_AIA_PAYMENT(p_ifdaiaft);

      DBG('AFTER REPLACEMENT OF AIA PAYMENT JSON=' || L_FORMATTED_MSG);

      DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

      DBG('CALLING AIA PAYMENT WEBSERVICE');

      IF NOT FN_MSG_UPLOAD(p_ifdaiaft,
                           'C',
                           L_FORMATTED_MSG,
                           'Payment Confirmation Call',
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN

        DBG('FAILED IN AIA PAYMENT CALL');

        RETURN FALSE;

      ELSE

        DBG('SUCCESS IN AIA PAYMENT CALL');

        --Check if already authorised

        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM IFTB_AIA_MASTER
           WHERE TRN_REF_NO = p_ifdaiaft.v_iftb_aia_master.trn_ref_no
                -- AND AUTH_STAT = 'A'
             AND ONCE_AUTH = 'Y';

        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;

        IF L_COUNT > 0 THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'ST-VALS-007',
                       'Transaction No:' ||
                       p_ifdaiaft.v_iftb_aia_master.trn_ref_no);
          RETURN FALSE;
        END IF;

        --AUTH TRANSACTION
        DBG('CALLING DEPKS_RTL_TELLER.FN_RTL_TELLER_AUTH');
        IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(GLOBAL.current_branch,
                                                    p_ifdaiaft.v_iftb_aia_master.trn_ref_no,
                                                    GLOBAL.USER_ID,
                                                    GLOBAL.LCY,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
          DBG('AUTH RETRUNED FALSE' || P_ERR_CODE);
          PR_LOG_ERROR('IFDAIAFT', 'FLEXCUBE', p_err_code, p_err_params);
          RETURN FALSE;
        ELSE
          --generate SVXP File
          dbg('done with authorization');
        END IF;

      END IF;

      dbg('fn_msg_upload successful');
    END IF;

    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiaft_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdaiaft         IN ifpks_ifdaiaft_Main.ty_ifdaiaft,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
  BEGIN

    Dbg('In Fn_Post_Check_Mandatory..');

    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiaft_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdaiaft         IN ifpks_ifdaiaft_Main.ty_ifdaiaft,
                                       p_Prev_ifdaiaft    IN OUT ifpks_ifdaiaft_Main.ty_ifdaiaft,
                                       p_Wrk_ifdaiaft     IN OUT ifpks_ifdaiaft_Main.ty_ifdaiaft,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Default_And_Validate..');

    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiaft_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdaiaft         IN ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                                        p_Prev_ifdaiaft    IN OUT ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                                        p_Wrk_ifdaiaft     IN OUT ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Default_And_Validate..');

    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiaft_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdaiaft         IN ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                            p_Prev_ifdaiaft    IN ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                            p_Wrk_ifdaiaft     IN OUT ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Upload_Db..');

    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiaft_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdaiaft         IN ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                             p_prev_ifdaiaft    IN ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                             p_wrk_ifdaiaft     IN OUT ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Upload_Db..');

    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiaft_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdaiaft         IN ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                        p_Wrk_ifdaiaft     IN OUT ifpks_ifdaiaft_Main.Ty_ifdaiaft,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Query..');

    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdaiaft_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdaiaft         IN ifpks_ifdaiaft_Main.ty_ifdaiaft,
                         p_wrk_ifdaiaft     IN OUT ifpks_ifdaiaft_Main.ty_ifdaiaft,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Query..');

    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of ifpks_ifdaiaft_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END ifpks_ifdaiaft_custom;
