var g_PickupClicked = 0;
var n =0;

function fnPickupReqd(){
	debugs("In fnPickupReqd", "A");
	g_PickupClicked = 0;
	n=0;
	return true;
}								
function fnPostNew_CUSTOM(){
	debugs("In fnPostNew_CUSTOM", "A");
	//fnDisableElement(document.getElementById("BLK_MASTER__OFF_CCY"));
	//fnDisableElement(document.getElementById("BLK_MASTER__OFF_AMOUNT"));
	//fnDisableElement(document.getElementById("BLK_MASTER__BTN_ENRICH"));
	return true;	
}

function fn_Pickup() {
	debugs("In fn_Pickup", "A");
	g_prevAction = gAction;
	gAction = "PICKUP";
	appendData();
	gAction = "PICKUP";
	fcjRequestDOM = buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	
	}
	gAction=g_prevAction;
	g_PickupClicked = 1;
	
	return true;
}

function fn_getPolicyDtls() {
	debugs("In fn_getPolicyDtls", "A");
	g_prevAction = gAction;
	gAction = "INVOKEAIA";
	appendData();
	gAction = "INVOKEAIA";
	fcjRequestDOM = buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	
	//fnEnableElement(document.getElementById("BLK_MASTER__OFF_CCY"));
	//fnEnableElement(document.getElementById("BLK_MASTER__OFF_AMOUNT"));
	//fnEnableElement(document.getElementById("BLK_MASTER__BTN_ENRICH"));
	}
	gAction=g_prevAction;
	g_PickupClicked = 1;
	
	return true;
}

function fnPreSave_CUSTOM(){
	debugs("In fnPreSave_CUSTOM", "A");

	if (document.getElementById("BLK_MASTER__CR_AMOUNT").value == "" || g_PickupClicked != 1) {			
		debugs("In Please click on Pick up before save", "A");
		alert("Please click on Pick up before save");
		return false;
	}
	return true;	
}