-- Create table
create table IFTB_AIA_WS_LOG
(
  seq_no        VARCHAR2(105) PRIMARY KEY,
  trn_ref_no    VARCHAR2(16),
  invoke_date   DATE,
  policy_number VARCHAR2(105),
  req_type      VARCHAR2(25),
  req_msg       CLOB,
  res_msg       CLOB,
  txn_unique_no VARCHAR2(105),
  status        CHAR(1),
  addl_info     VARCHAR2(105)
)
/