-- Create table
create table IFTB_AIA_SI_MASTER_HIST
(
  bank_code           VARCHAR2(10),
  bank_name           VARCHAR2(105),
  receipt_date        DATE,
  payment_channel     VARCHAR2(105),
  transaction_type    VARCHAR2(105),
  partner_receipt_ref VARCHAR2(16),
  aia_policy_no       VARCHAR2(105),
  premium_amt         NUMBER,
  aia_receipt_ref     VARCHAR2(105),
  product_type        VARCHAR2(105),
  policy_status       VARCHAR2(105),
  current_bill_freq   VARCHAR2(105),
  update_bill_freq    VARCHAR2(105),
  first_due_date      DATE,
  next_due_date       DATE,
  expiry_date         DATE,
  payment_date        DATE,
  ccy                 VARCHAR2(3),
  policy_holder_name  VARCHAR2(105),
  policy_holder_phone VARCHAR2(105),
  policy_holder_email VARCHAR2(105),
  customer_no         VARCHAR2(9),
  cust_ac_no          VARCHAR2(20),
  aia_ac_no           VARCHAR2(20),
  cust_name           VARCHAR2(105),
  maker_id            VARCHAR2(12),
  maker_dt_stamp      DATE,
  checker_id          VARCHAR2(12),
  checker_dt_stamp    DATE,
  auth_stat           VARCHAR2(1),
  record_stat         VARCHAR2(1),
  once_auth           VARCHAR2(1),
  mod_no              NUMBER(4)
)
/
alter table IFTB_AIA_SI_MASTER_HIST add unique_reference_no varchar2(105)
/
create sequence TRSQ_AIASI_SEQID
minvalue 1
maxvalue 999999999
start with 1
increment by 1
nocache
cycle
/
GRANT ALL ON P1FCHPRFM.TRSQ_AIASI_SEQID TO FCCNDG
/