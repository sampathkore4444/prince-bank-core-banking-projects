CREATE OR REPLACE PACKAGE BODY IFPKS_AIA_SI_UTILS AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_AIA_SI_UTILS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  PROCEDURE PR_INSERT_AIA_WS_LOG(P_SEQ_NO          IN VARCHAR2,
                                 P_AIA_RECEIPT_REF IN VARCHAR2,
                                 P_INVOKE_DATE     IN VARCHAR2,
                                 P_POLICY_NUMBER   IN VARCHAR2,
                                 P_REQ_TYPE        IN VARCHAR2,
                                 P_REQ_MSG         IN VARCHAR2,
                                 P_ADDL_INFO       IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
    DBG('START OF PR_INSERT_AIA_WS_LOG');
  
    INSERT INTO Iftb_Aia_si_Ws_Log
      (SEQ_NO,
       AIA_RECEIPT_REF,
       INVOKE_DATE,
       POLICY_NUMBER,
       REQ_TYPE,
       REQ_MSG,
       ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_AIA_RECEIPT_REF,
       P_INVOKE_DATE,
       P_POLICY_NUMBER,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ADDL_INFO);
  
    COMMIT;
  
    DBG('END OF PR_INSERT_AIA_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_AIA_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_AIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_AIA_WS_LOG=' || SQLERRM);
    
  END PR_INSERT_AIA_WS_LOG;

  PROCEDURE PR_UPDATE_AIA_WS_LOG(P_AIA_RECEIPT_REF IN IFTB_AIA_SI_MASTER.AIA_RECEIPT_REF%TYPE,
                                 P_SEQ_NO          IN VARCHAR2,
                                 P_TXN_UNIQUE_NO   IN IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE,
                                 P_STATUS          IN CHAR,
                                 P_RES_MSG         IN CLOB,
                                 P_ERROR_CODE      IN VARCHAR2,
                                 P_ERROR_PARAM     IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_AIA_WS_LOG');
  
    UPDATE Iftb_Aia_si_Ws_Log
       SET AIA_RECEIPT_REF = P_AIA_RECEIPT_REF,
           RES_MSG         = P_RES_MSG,
           STATUS          = P_STATUS,
           TXN_UNIQUE_NO   = P_TXN_UNIQUE_NO,
           ERROR_CODE      = P_ERROR_CODE,
           ERROR_MESSAGE   = P_ERROR_PARAM
     WHERE SEQ_NO = P_SEQ_NO;
  
    COMMIT;
  
    DBG('END OF PR_UPDATE_AIA_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_AIA_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_AIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_AIA_WS_LOG=' || SQLERRM);
  END PR_UPDATE_AIA_WS_LOG;

  PROCEDURE PR_UPDATE_AIA_WS_LOG(P_SEQ_NO        IN VARCHAR2,
                                 P_TXN_UNIQUE_NO IN IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE,
                                 P_TRN_REF_NO    IN IFTB_AIA_SI_WS_LOG.TRN_REF_NO%TYPE,
                                 P_STATUS        IN CHAR) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_AIA_WS_LOG');
  
    UPDATE Iftb_Aia_si_Ws_Log A
       SET TRN_REF_NO = P_TRN_REF_NO, STATUS = P_STATUS
     WHERE A.SEQ_NO = P_SEQ_NO
       AND A.TXN_UNIQUE_NO = P_TXN_UNIQUE_NO;
  
    COMMIT;
  
    DBG('END OF PR_UPDATE_AIA_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_AIA_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_AIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_AIA_WS_LOG=' || SQLERRM);
  END PR_UPDATE_AIA_WS_LOG;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN
  
    SELECT TRSQ_AIA_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    RETURN L_REF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;
  
    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  FUNCTION FN_AIA_WS_CALL(p_AIA_call in varchar2,
                          p_out_msg  VARCHAR2,
                          p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS
  
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255);
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);
  
    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;
  
  BEGIN
    dbg('START OF FN_AIA_WS_CALL');
  
    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));
  
    IF p_AIA_call = 'I' THEN
    
      L_URL := FN_GET_PARAM_VAL('PGW_AIA_POLICY_ENQ_URL');
    
    ELSIF p_AIA_call = 'C' THEN
    
      L_URL := FN_GET_PARAM_VAL('PGW_AIA_PAYCONFIRM_URL');
    
    END IF;
  
    DBG('l_url-->' || L_URL);
  
    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');
  
    utl_http.set_authentication(l_http_request,
                                FN_GET_PARAM_VAL('PGW_AIA_AUTH_UID'),
                                FN_GET_PARAM_VAL('PGW_AIA_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
    utl_http.set_header(l_http_request,
                        'content-type',
                        'application/x-www-form-urlencoded');
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
  
    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
  
    utl_http.set_transfer_timeout(300);
  
    utl_http.write_text(l_http_request, p_out_msg);
  
    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));
  
    l_http_response := utl_http.get_response(l_http_request);
  
    dbg('Response> status_code: "' || l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    DBG('l_resp_num=' || l_resp_num);
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;
    
      p_in_resp := buffer1;
    
      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    --    dbms_lob.freetemporary(buffer1); --buffer2 may be check
  
    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('Error Line Number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_AIA_WS_CALL;

  FUNCTION fn_msg_upload( --p_ifdaiaft   IN OUT IFPKS_IFDAIAFT_MAIN.ty_ifdaiaft,
                         P_AIA_RECEIPT_REF IN VARCHAR2,
                         P_AIA_POLICY_NO   IN VARCHAR2,
                         P_REQ_TYPE        IN VARCHAR2,
                         P_REQ_MSG         IN OUT CLOB,
                         P_ADDL_INFO       IN VARCHAR2,
                         p_err_code        IN OUT VARCHAR2,
                         p_err_params      IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
  
    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);
  
    L_CLIENT_NAME          VARCHAR2(105);
    L_email                VARCHAR2(105);
    L_phone                VARCHAR2(105);
    l_paymentDueDate       VARCHAR2(105);
    l_allowPartialPayment  VARCHAR2(105);
    l_allowSchedulePayment VARCHAR2(105);
    l_frequency            VARCHAR2(105);
    l_maturityDate         VARCHAR2(105);
    l_amount               VARCHAR2(105);
    l_currency             VARCHAR2(105);
    l_transactionUniqueNo  VARCHAR2(105);
  
    L_insuranceTransactionNo VARCHAR2(105);
  
    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);
  
    P_ERROR_CODE  VARCHAR2(100);
    P_ERROR_PARAM VARCHAR2(100);
  
  BEGIN
  
    dbg('Inside fn_msg_upload');
  
    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;
  
    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);
  
    --Log Webservice Call
    PR_INSERT_AIA_WS_LOG(L_GEN_SEQ_NO,
                         P_AIA_RECEIPT_REF,
                         SYSDATE,
                         P_AIA_POLICY_NO,
                         P_REQ_TYPE,
                         P_REQ_MSG,
                         P_ADDL_INFO);
  
    IF NOT FN_AIA_WS_CALL(P_REQ_TYPE, P_REQ_MSG, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;
  
    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);
  
    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
  
    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);
  
    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
  
    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;
  
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;
  
    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);
  
    IF L_STATUS_CODE = 'ERROR_500' THEN
    
      dbg('AIA SYSTEM IS DOWN');
    
      p_err_code := 'IF-BNG-001';
    
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, null);
    
      RETURN FALSE;
    
    END IF;
  
    --Handle All Error Codes ad return false
  
    IF P_REQ_TYPE = 'I' THEN
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN
      
        l_amount := P_DOCUMENT_XML.EXTRACT('/root/data/amount/text()')
                    
                    .GETSTRINGVAL;
      
        DBG('l_amount =' || l_amount);
      
        l_currency := P_DOCUMENT_XML.EXTRACT('/root/data/currency/text()')
                      
                      .GETSTRINGVAL;
      
        DBG('l_currency =' || l_currency);
      
        l_transactionUniqueNo := P_DOCUMENT_XML.EXTRACT('/root/data/transactionUniqueNo/text()')
                                 
                                 .GETSTRINGVAL;
      
        DBG('l_transactionUniqueNo =' || l_transactionUniqueNo);
      
        PR_UPDATE_AIA_WS_LOG(P_AIA_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'S',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
      ELSE
      
        PR_UPDATE_AIA_WS_LOG(P_AIA_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'F',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    IF P_REQ_TYPE = 'C' THEN
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN
      
        L_insuranceTransactionNo := P_DOCUMENT_XML.EXTRACT('/root/data/insuranceTransactionNo/text()')
                                    
                                    .GETSTRINGVAL;
      
        DBG('L_insuranceTransactionNo =' || L_insuranceTransactionNo);
      
        PR_UPDATE_AIA_WS_LOG(P_AIA_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'S',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
        RETURN TRUE;
      
      ELSE
      
        PR_UPDATE_AIA_WS_LOG(P_AIA_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'F',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      RETURN FALSE;
  END fn_msg_upload;

  FUNCTION fn_msg_upload( --p_ifdaiaft   IN OUT IFPKS_IFDAIAFT_MAIN.ty_ifdaiaft,
                         P_AIA_RECEIPT_REF IN VARCHAR2,
                         P_AIA_POLICY_NO   IN VARCHAR2,
                         P_REQ_TYPE        IN VARCHAR2,
                         P_REQ_MSG         IN OUT CLOB,
                         P_ADDL_INFO       IN VARCHAR2,
                         P_PAYMENT_AMT     OUT VARCHAR2,
                         P_PAYMENT_DUEDATE OUT VARCHAR2,
                         P_TXN_UNIQUE_NO   OUT VARCHAR2,
                         P_GEN_SEQ_NO      OUT VARCHAR2,
                         p_err_code        IN OUT VARCHAR2,
                         p_err_params      IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
  
    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);
  
    L_CLIENT_NAME          VARCHAR2(105);
    L_email                VARCHAR2(105);
    L_phone                VARCHAR2(105);
    l_paymentDueDate       VARCHAR2(105);
    l_allowPartialPayment  VARCHAR2(105);
    l_allowSchedulePayment VARCHAR2(105);
    l_frequency            VARCHAR2(105);
    l_maturityDate         VARCHAR2(105);
    l_amount               VARCHAR2(105);
    l_currency             VARCHAR2(105);
    l_transactionUniqueNo  VARCHAR2(105);
  
    L_insuranceTransactionNo VARCHAR2(105);
  
    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);
  
    P_ERROR_CODE  VARCHAR2(100);
    P_ERROR_PARAM VARCHAR2(100);
  
  BEGIN
  
    dbg('Inside fn_msg_upload');
  
    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;
  
    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);
  
    P_GEN_SEQ_NO := L_GEN_SEQ_NO;
  
    --Log Webservice Call
    PR_INSERT_AIA_WS_LOG(L_GEN_SEQ_NO,
                         P_AIA_RECEIPT_REF,
                         SYSDATE,
                         P_AIA_POLICY_NO,
                         P_REQ_TYPE,
                         P_REQ_MSG,
                         P_ADDL_INFO);
  
    IF NOT FN_AIA_WS_CALL(P_REQ_TYPE, P_REQ_MSG, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;
  
    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);
  
    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
  
    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);
  
    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
  
    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;
  
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;
  
    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);
  
    IF L_STATUS_CODE = 'ERROR_500' THEN
    
      dbg('AIA SYSTEM IS DOWN');
    
      p_err_code := 'IF-BNG-001';
    
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, null);
    
      RETURN FALSE;
    
    END IF;
  
    --Handle All Error Codes ad return false
  
    IF P_REQ_TYPE = 'I' THEN
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN
      
        l_amount := P_DOCUMENT_XML.EXTRACT('/root/data/amount/text()')
                    
                    .GETSTRINGVAL;
      
        DBG('l_amount =' || l_amount);
      
        P_PAYMENT_AMT := l_amount;
      
        l_paymentDueDate := P_DOCUMENT_XML.EXTRACT('/root/data/paymentDueDate/text()')
                            
                            .GETSTRINGVAL;
      
        DBG('l_paymentDueDate =' || l_paymentDueDate);
      
        P_PAYMENT_DUEDATE := l_paymentDueDate;
      
        l_currency := P_DOCUMENT_XML.EXTRACT('/root/data/currency/text()')
                      
                      .GETSTRINGVAL;
      
        DBG('l_currency =' || l_currency);
      
        l_transactionUniqueNo := P_DOCUMENT_XML.EXTRACT('/root/data/transactionUniqueNo/text()')
                                 
                                 .GETSTRINGVAL;
      
        DBG('l_transactionUniqueNo =' || l_transactionUniqueNo);
      
        P_TXN_UNIQUE_NO := l_transactionUniqueNo;
      
        PR_UPDATE_AIA_WS_LOG(P_AIA_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'S',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
      ELSE
      
        PR_UPDATE_AIA_WS_LOG(P_AIA_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'F',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    IF P_REQ_TYPE = 'C' THEN
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN
      
        L_insuranceTransactionNo := P_DOCUMENT_XML.EXTRACT('/root/data/insuranceTransactionNo/text()')
                                    
                                    .GETSTRINGVAL;
      
        DBG('L_insuranceTransactionNo =' || L_insuranceTransactionNo);
      
        PR_UPDATE_AIA_WS_LOG(P_AIA_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'S',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
        RETURN TRUE;
      
      ELSE
      
        PR_UPDATE_AIA_WS_LOG(P_AIA_RECEIPT_REF,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'F',
                             L_IN_RESP,
                             P_ERROR_CODE,
                             P_ERROR_PARAM);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      RETURN FALSE;
  END fn_msg_upload;

  FUNCTION FN_GET_AIA_POLICY_ENQUIRY RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_AIA_POLICY_ENQUIRY');
  
    L_FORMATTED_MSG := '{"channelCode":"CBS","insuranceCode":"$L_INSURANCE_CODE","policyNumber":"$L_POLICY_NUMBER"}';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_AIA_POLICY_ENQUIRY');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AIA_POLICY_ENQUIRY');
      DBG('ERROR CODE IN FN_GET_AIA_POLICY_ENQUIRY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AIA_POLICY_ENQUIRY=' || SQLERRM);
    
  END FN_GET_AIA_POLICY_ENQUIRY;

  FUNCTION FN_GET_FMT_AIA_POLICY_ENQ(P_POLICY_NO IN VARCHAR2) RETURN CLOB IS
  
    L_INSURANCE_CODE VARCHAR2(105);
    L_POLICY_NUMBER  VARCHAR2(105);
    L_FORMATTED_MSG  CLOB; --varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_GET_FMT_AIA_POLICY_ENQ');
  
    L_FORMATTED_MSG := FN_GET_AIA_POLICY_ENQUIRY;
  
    DBG('BEFORE REPLACEMENT OF AIA ACC ENQUIRY JSON=' || L_FORMATTED_MSG);
  
    --Replace tags with actual values
    L_INSURANCE_CODE := 'AIA001'; --p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10;
  
    DBG('L_INSURANCE_CODE=' || L_INSURANCE_CODE);
  
    L_POLICY_NUMBER := P_POLICY_NO;
  
    DBG('L_POLICY_NUMBER=' || L_POLICY_NUMBER);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSURANCE_CODE',
                               L_INSURANCE_CODE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_POLICY_NUMBER',
                               L_POLICY_NUMBER);
  
    DBG('AFTER REPLACEMENT OF AIA POLICY ENQUIRY JSON=' || L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_AIA_POLICY_ENQ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_AIA_POLICY_ENQ');
      DBG('ERROR CODE IN FN_GET_FMT_AIA_POLICY_ENQ=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_AIA_POLICY_ENQ=' || SQLERRM);
  END FN_GET_FMT_AIA_POLICY_ENQ;

  FUNCTION FN_GET_AIA_PAYMENT RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_AIA_PAYMENT');
  
    L_FORMATTED_MSG := '{"channelCode":"CBS","insuranceCode":"$L_INSURANCE_CODE","transactionUniqueNo":"$L_TXN_UNIQUE_NO","policyNumber":"$L_POLICY_NUMBER"
    ,"amount":"$L_AMOUNT","currency":"$L_CCY"}';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_AIA_PAYMENT');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_AIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AIA_PAYMENT=' || SQLERRM);
    
  END FN_GET_AIA_PAYMENT;

  FUNCTION FN_GET_FMT_AIA_PAYMENT(P_TXN_UNIQUE_NO IN VARCHAR2,
                                  P_POLICY_NO     IN VARCHAR2,
                                  P_PAYMENT_AMT   IN VARCHAR2,
                                  P_CCY           IN VARCHAR2) RETURN CLOB IS
  
    L_TXN_UNIQUE_NO  IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE; --need to change to enquiry id
    L_INSURANCE_CODE VARCHAR2(105);
    L_POLICY_NUMBER  VARCHAR2(105);
    L_AMOUNT         VARCHAR2(105);
    L_CCY            VARCHAR2(3);
    L_FORMATTED_MSG  CLOB; --varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_FMT_AIA_PAYMENT');
  
    L_FORMATTED_MSG := FN_GET_AIA_PAYMENT;
  
    DBG('BEFORE REPLACEMENT OF AIA PAYMENT JSON=' || L_FORMATTED_MSG);
  
    --Replace tags with actual values
    L_TXN_UNIQUE_NO := P_TXN_UNIQUE_NO; --need to change to enquiry id
  
    DBG('L_TXN_UNIQUE_NO=' || L_TXN_UNIQUE_NO);
  
    L_INSURANCE_CODE := 'AIA001'; --p_ifdaiaft.v_cstb_ui_columns.CHAR_FIELD10;
  
    DBG('L_INSURANCE_CODE=' || L_INSURANCE_CODE);
  
    L_POLICY_NUMBER := P_POLICY_NO;
  
    DBG('L_POLICY_NUMBER=' || L_POLICY_NUMBER);
  
    L_AMOUNT := P_PAYMENT_AMT;
  
    DBG('L_AMOUNT=' || L_AMOUNT);
  
    L_CCY := P_CCY;
  
    DBG('L_CCY=' || L_CCY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_UNIQUE_NO',
                               L_TXN_UNIQUE_NO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSURANCE_CODE',
                               L_INSURANCE_CODE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_POLICY_NUMBER',
                               L_POLICY_NUMBER);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CCY', L_CCY);
  
    DBG('BEFORE REPLACEMENT OF AIA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_AIA_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_AIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_AIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_AIA_PAYMENT=' || SQLERRM);
    
  END FN_GET_FMT_AIA_PAYMENT;

END IFPKS_AIA_SI_UTILS;
