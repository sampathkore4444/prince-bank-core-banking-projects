-- Create table
create table IFTB_AIA_SI_PAYMENTS_MASTER
(
  trn_ref_no    VARCHAR2(16) not null,
  aia_policy_no VARCHAR2(25) not null,
  txn_acc       VARCHAR2(20),
  txn_ccy       VARCHAR2(3),
  txn_amount    NUMBER,
  txn_branch    VARCHAR2(3),
  txn_trn_code  VARCHAR2(3),
  ofs_acc       VARCHAR2(20),
  ofs_ccy       VARCHAR2(3),
  ofs_amount    NUMBER,
  ofs_branch    VARCHAR2(3),
  ofs_trn_code  VARCHAR2(3),
  lcy_amount    NUMBER,
  trn_dt        DATE,
  value_dt      DATE,
  partner_receipt_ref VARCHAR2(105) not null
)
/
ALTER TABLE IFTB_AIA_SI_PAYMENTS_MASTER ADD PRIMARY KEY(TRN_REF_NO,AIA_POLICY_NO,partner_receipt_ref)
/
CREATE OR REPLACE SYNONYM IFTBS_AIA_SI_PAYMENTS_MASTER FOR IFTB_AIA_SI_PAYMENTS_MASTER
/