CREATE OR REPLACE PROCEDURE PR_PROCESS_AIA_SI_PAYMENTS AS

  v_user_count            NUMBER(4);
  L_CUST_ACCOUNT          STTM_CUST_ACCOUNT%ROWTYPE;
  L_CUST                  STTM_CUSTOMER%ROWTYPE;
  pkg_detb_rtl_teller_rec detbs_rtl_teller%ROWTYPE;
  L_SERIAL_NO             VARCHAR2(16);
  L_TRN_REF_NO            Actb_Daily_Log.TRN_REF_NO%TYPE;
  L_GEN_SEQ_NO            VARCHAR2(100);

  P_ERR_CODE      VARCHAR2(255);
  P_ERR_PARAMS    VARCHAR2(255);
  l_formatted_msg CLOB;
  L_IN_RESP       CLOB;

  L_RESP_IN_XML  CLOB;
  P_DOCUMENT_XML XMLTYPE;

  L_STATUS_CODE VARCHAR2(100);
  L_STATUS_MSG  VARCHAR2(100);

  L_ARC_MAINT IFTM_ARC_MAINT%ROWTYPE;

  P_REQ_TYPE            CHAR(1);
  l_paymentDueDate      VARCHAR2(105);
  l_transactionUniqueNo VARCHAR2(105);
  l_payment_amount      VARCHAR2(105);
  l_currency            VARCHAR2(105) := 'USD';

  L_COUNT NUMBER;

  L_CCY_CODE  CYTM_CCY_DEFN_MASTER.CCY_CODE%TYPE;
  L_EXCH_RATE ACTB_DAILY_LOG.EXCH_RATE%TYPE;
  L_RATE_FLAG NUMBER;

  L_TXN_AMT IFTB_AIA_MASTER.TXN_AMOUNT%TYPE;

  l_prod     CSTM_PRODUCT%ROWTYPE;
  l_chg1_amt iftm_arc_maint.cod_chg_amt%type;

  l_rel_customer sttm_customer.customer_no%TYPE;
  l_ac_ccy       sttm_cust_account.ccy%TYPE;
  l_ib_flag      VARCHAR2(1) DEFAULT 'N';
  L_RETRY_COUNT  NUMBER := 0;

  CURSOR C1 IS
    SELECT *
      FROM IFTB_AIA_SI_MASTER
     WHERE RECORD_STAT = 'O'
       AND AUTH_STAT = 'A'
       AND AIA_POLICY_NO IN ( --'A229258A06',
                             --'A229259A03',
                             --'A229260A04',
                             --'A229261A01',
                             --'A229262A09',
                             'A229265A00');

  -- AND AIA_POLICY_NO = 'W015334A06';

  --PAYMENT_DUE_DATE = SYSDATE
  --AND STATUS = 'U'
  --AND SYSDATE <= EXPIRY_DATE;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'PR_PROCESS_AIA_SI_PAYMENTS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

BEGIN

  FOR G IN C1 LOOP
  
    BEGIN
    
      --Call AIA Api to get the due date
      GLOBAL.pr_init('001', 'AIASIUSER');
    
      L_FORMATTED_MSG := IFPKS_AIA_SI_UTILS.FN_GET_FMT_AIA_POLICY_ENQ(G.AIA_POLICY_NO);
    
      DBG('AFTER REPLACEMENT OF AIA POLICY ENQUIRY JSON=' ||
          L_FORMATTED_MSG);
    
      DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);
    
      DBG('CALLING AIA POLICY ENQUIRY WEBSERVICE');
    
      IF NOT IFPKS_AIA_SI_UTILS.FN_MSG_UPLOAD(G.AIA_RECEIPT_REF,
                                              G.AIA_POLICY_NO,
                                              'I',
                                              L_FORMATTED_MSG,
                                              'Account Enquiry Call',
                                              l_payment_amount,
                                              l_paymentDueDate,
                                              l_transactionUniqueNo,
                                              L_GEN_SEQ_NO,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
      
        DBG('FAILED IN POLICY ENQUIRY CALL');
      
        --RETURN FALSE;
        ROLLBACK TO A;
        CONTINUE;
      
      ELSE
      
        DBG('SUCCESS IN POLICY ENQUIRY CALL');
      
      END IF;
    
      DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);
      DBG('l_payment_amount=' || l_payment_amount);
      DBG('l_paymentDueDate=' || l_paymentDueDate);
      DBG('l_transactionUniqueNo=' || l_transactionUniqueNo);
    
      --check retry count before processing
      BEGIN
        SELECT RETRY_COUNT
          INTO L_RETRY_COUNT
          FROM IFTB_AIA_SI_RETRY_LOG A
         WHERE A.AIA_POLICY_NO = G.AIA_POLICY_NO;
      EXCEPTION
        WHEN OTHERS THEN
          L_RETRY_COUNT := 0;
      END;
    
      DBG('L_RETRY_COUNT=' || L_RETRY_COUNT);
      DBG('first=' || to_date(l_paymentDueDate, 'YYYY-MM-DD'));
      DBG('second=' || TO_DATE('2021-12-22', 'YYYY-MM-DD'));
    
      IF /*to_date(sysdate, 'YYYY-MM-DD') =*/
       to_date(l_paymentDueDate, 'YYYY-MM-DD') =
       TO_DATE('2021-12-22', 'YYYY-MM-DD') and l_payment_amount > 0 and
       NVL(L_RETRY_COUNT, 0) < 7 THEN
      
        SAVEPOINT A;
      
        --Get Account details
        BEGIN
          SELECT *
            INTO L_CUST_ACCOUNT
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = G.CUST_AC_NO;
        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACCOUNT := NULL;
        END;
      
        GLOBAL.PR_INIT(L_CUST_ACCOUNT.BRANCH_CODE, 'AIASIUSER');
      
        pkg_detb_rtl_teller_rec.product_code := 'AI01'; --SI PRODICT CODE
      
        --Get Product Details
        BEGIN
          SELECT *
            INTO L_PROD
            FROM CSTM_PRODUCT
           WHERE PRODUCT_CODE = pkg_detb_rtl_teller_rec.product_code
             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A';
        EXCEPTION
          WHEN OTHERS THEN
            L_PROD := null;
        END;
      
        --GET REFERENCE NO
        IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                           PKG_DETB_RTL_TELLER_REC.PRODUCT_CODE,
                                           GLOBAL.APPLICATION_DATE,
                                           L_SERIAL_NO,
                                           L_TRN_REF_NO,
                                           P_ERR_CODE) THEN
          DBG('FAILED IN GENERATION TRANSACTION REF NO');
          ROLLBACK TO A;
          CONTINUE;
        ELSE
          DBG('L_TRN_REF_NO=' || L_TRN_REF_NO);
        END IF;
      
        --GET BEN CUSTOMER DETAILS
        BEGIN
          SELECT X.*
            INTO L_CUST
            FROM STTM_CUSTOMER X
           WHERE X.CUSTOMER_NO = L_CUST_ACCOUNT.CUST_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('IF', 'FAILED IN GETTING CUSTOMER DETAILS');
        END;
      
        PKG_DETB_RTL_TELLER_REC.XREF := L_TRN_REF_NO;
      
        --Get Arc Maintenance
        SELECT *
          INTO L_ARC_MAINT
          FROM IFTM_ARC_MAINT A
         WHERE A.COD_PROD_ACC_CLS = pkg_detb_rtl_teller_rec.product_code
           AND ROWNUM = 1;
      
        PKG_DETB_RTL_TELLER_REC.BRANCH_CODE := L_CUST_ACCOUNT.BRANCH_CODE;
        PKG_DETB_RTL_TELLER_REC.TRN_REF_NO  := L_TRN_REF_NO;
      
        PKG_DETB_RTL_TELLER_REC.TXN_ACC    := '000021058'; --AIA Credit Account pls check
        PKG_DETB_RTL_TELLER_REC.TXN_CCY    := GLOBAL.LCY;
        PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := '991'; --GLOBAL.CURRENT_BRANCH;
        --PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := PKG_DETB_RTL_TELLER_REC.OFS_BRANCH;
      
        --XRATE CALCULATION STARTS
        IF L_CUST_ACCOUNT.CCY <> 'USD' THEN
        
          IF NOT CYPKSS.FN_GETRATE(L_CUST_ACCOUNT.BRANCH_CODE,
                                   L_CUST_ACCOUNT.CCY,
                                   'USD', --L_CCY_CODE, --'KHR', --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                   'COMM', --L_PROD.RATE_TYPE_PREFERRED,
                                   'B', --L_RATE_CODE1, --l_prod.rate_code_preferred,
                                   GLOBAL.APPLICATION_DATE,
                                   GLOBAL.APPLICATION_DATE,
                                   L_EXCH_RATE,
                                   L_RATE_FLAG,
                                   P_ERR_CODE) THEN
            DBG('FAILED IN FN_GETRATE');
            ROLLBACK TO A;
            CONTINUE;
          END IF;
        ELSE
          L_EXCH_RATE := 1;
        END IF;
      
        DBG('L_EXCH_RATE=' || L_EXCH_RATE);
      
        --USING ABOVE RATE..CONVERT KHR TO USD AMOUNT
        IF NOT CYPKSS.FN_AMT1_TO_AMT2('USD', --L_CCY_CODE,
                                      L_CUST_ACCOUNT.CCY,
                                      l_payment_amount, ---G.TXN_AMOUNT,
                                      L_EXCH_RATE,
                                      'Y',
                                      L_TXN_AMT,
                                      P_ERR_PARAMS) THEN
          DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
          ROLLBACK TO A;
          CONTINUE;
        END IF;
      
        DBG('FINAL L_TXN_AMT=' || L_TXN_AMT);
      
        PKG_DETB_RTL_TELLER_REC.OFS_ACC    := G.CUST_AC_NO;
        PKG_DETB_RTL_TELLER_REC.OFS_CCY    := L_CUST_ACCOUNT.CCY;
        PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT := L_TXN_AMT; -- L_AMOUNT/100;
      
        PKG_DETB_RTL_TELLER_REC.OFS_BRANCH := L_CUST_ACCOUNT.BRANCH_CODE; --GLOBAL.current_branch;
      
        PKG_DETB_RTL_TELLER_REC.TXN_AMOUNT := L_TXN_AMT;
      
        PKG_DETB_RTL_TELLER_REC.TXN_TRN_CODE     := L_ARC_MAINT.COD_MAIN_TXN_CODE; --'000'; --TRANSACION CODE
        PKG_DETB_RTL_TELLER_REC.OFS_TRN_CODE     := L_ARC_MAINT.COD_OFFSET_TXN_CODE; --'000'; --TRANSACION CODE
        PKG_DETB_RTL_TELLER_REC.EXCH_RATE        := L_EXCH_RATE;
        PKG_DETB_RTL_TELLER_REC.TRN_DT           := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.VALUE_DT         := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.REL_CUSTOMER     := L_CUST.CUSTOMER_NO;
        PKG_DETB_RTL_TELLER_REC.BENEF_NAME       := L_CUST.CUSTOMER_NAME1;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR1      := L_CUST.ADDRESS_LINE1;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR2      := L_CUST.ADDRESS_LINE2;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR3      := L_CUST.ADDRESS_LINE3;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR4      := L_CUST.ADDRESS_LINE4;
        PKG_DETB_RTL_TELLER_REC.LIQN_DT          := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.RECORD_STAT      := 'A';
        PKG_DETB_RTL_TELLER_REC.AUTH_STAT        := 'U';
        PKG_DETB_RTL_TELLER_REC.MAKER_ID         := 'SYSTEM';
        PKG_DETB_RTL_TELLER_REC.MAKER_DT_STAMP   := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.CHECKER_ID       := 'SYSTEM';
        PKG_DETB_RTL_TELLER_REC.CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.MOD_NO           := 1;
        PKG_DETB_RTL_TELLER_REC.SCODE            := 'FLEXCUBE';
        PKG_DETB_RTL_TELLER_REC.DR_ACC           := 'OFS';
        PKG_DETB_RTL_TELLER_REC.MODULE           := 'RT';
        PKG_DETB_RTL_TELLER_REC.ESN              := 1;
        PKG_DETB_RTL_TELLER_REC.EVENT_CODE       := 'INIT';
        PKG_DETB_RTL_TELLER_REC.TRACK_RECEIVABLE := 'N';
        PKG_DETB_RTL_TELLER_REC.TIME_RECEIVED    := SYSDATE;
        PKG_DETB_RTL_TELLER_REC.CONSUMER_NO      := G.AIA_POLICY_NO;
      
        --Charge Details
      
        SELECT cust_no, ccy
          INTO l_rel_customer, l_ac_ccy
          FROM sttm_cust_account
         WHERE cust_ac_no = G.CUST_AC_NO;
      
        dbg('got l_rel_customer' || l_rel_customer);
      
        IF NOT cspkss_arc.fn_charge_pickup(GLOBAL.current_branch,
                                           'AI01',
                                           'P',
                                           'AI01',
                                           '*.*',
                                           l_rel_customer,
                                           '*.*',
                                           l_payment_amount,
                                           l_prod.rate_type_preferred,
                                           l_prod.rate_code_preferred,
                                           NULL,
                                           l_rel_customer,
                                           l_ib_flag,
                                           depks_rtl_teller.pkg_arc_row,
                                           p_err_code,
                                           p_err_params,
                                           G.CUST_AC_NO,
                                           GLOBAL.current_branch) THEN
          dbg('CHARGE PICKUP failed');
          --RETURN FALSE;
          ROLLBACK TO A;
          CONTINUE;
          --RETURN;
        END IF;
      
        DBG('PKG_ARC_ROW.COD_CHG_TYPE=' ||
            DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE);
        DBG('PKG_ARC_ROW.COD_CHG_GL=' ||
            DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_GL);
        DBG('PKG_ARC_ROW.COD_CHG_CCY=' ||
            DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_CCY);
        DBG('PKG_ARC_ROW.COD_CHG_TXN_CODE=' ||
            DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TXN_CODE);
        DBG('PKG_ARC_ROW.COD_CHG_AMT=' ||
            DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT);
      
        DBG('l_arc_maint.COD_CHG_TYPE=' || l_arc_maint.COD_CHG_TYPE);
        DBG('l_arc_maint.COD_CHG_GL=' || l_arc_maint.COD_CHG_GL);
        DBG('l_arc_maint.COD_CHG_CCY=' || l_arc_maint.COD_CHG_CCY);
        DBG('l_arc_maint.COD_CHG_TXN_CODE=' ||
            l_arc_maint.COD_CHG_TXN_CODE);
        DBG('l_arc_maint.COD_CHG_AMT=' || l_arc_maint.COD_CHG_AMT);
      
        pkg_detb_rtl_teller_rec.charge_account := G.CUST_AC_NO;
      
        dbg('l_arc_maint.cod_chg_gl=' || l_arc_maint.cod_chg_gl);
        dbg('l_arc_maint.cod_chg_ccy=' || l_arc_maint.cod_chg_ccy);
        dbg('l_arc_maint.cod_chg_amt=' || l_arc_maint.cod_chg_amt);
      
        pkg_detb_rtl_teller_rec.chg_gl           := l_arc_maint.cod_chg_gl;
        pkg_detb_rtl_teller_rec.chg_ccy          := l_arc_maint.cod_chg_ccy;
        pkg_detb_rtl_teller_rec.chg_amt          := l_arc_maint.cod_chg_amt;
        depks_rtl_teller.pkg_arc_row.cod_chg_amt := l_arc_maint.cod_chg_amt;
      
        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt);
        depks_rtl_teller.pkg_arc_row.cod_chg_type := l_arc_maint.cod_chg_type;
      
        IF l_arc_maint.cod_chg_ccy <> L_CUST_ACCOUNT.CCY THEN
          IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.current_branch,
                                        l_arc_maint.cod_chg_ccy,
                                        L_CUST_ACCOUNT.CCY,
                                        l_prod.rate_type_preferred,
                                        l_prod.rate_code_preferred,
                                        l_chg1_amt,
                                        'Y',
                                        pkg_detb_rtl_teller_rec.chg_in_acy,
                                        pkg_detb_rtl_teller_rec.chg_ccy_acy_rate,
                                        p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            ROLLBACK TO A;
            CONTINUE;
            --RETURN FALSE;
          END IF;
        
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy       := l_chg1_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate := 1;
        END IF;
      
        DBG('pkg_detb_rtl_teller_rec.chg_in_acy=' ||
            pkg_detb_rtl_teller_rec.chg_in_acy);
        DBG('pkg_detb_rtl_teller_rec.chg_ccy_acy_rate=' ||
            pkg_detb_rtl_teller_rec.chg_ccy_acy_rate);
      
        DBG('l_arc_maint.cod_chg_amt=' || l_arc_maint.cod_chg_amt);
        DBG('l_arc_maint.cod_chg_rate=' || l_arc_maint.cod_chg_rate);
        DBG('l_arc_maint.cod_chg_netting=' || l_arc_maint.cod_chg_netting);
        DBG('l_arc_maint.cod_chg_txn_code=' ||
            l_arc_maint.cod_chg_txn_code);
        DBG('l_arc_maint.cod_mis_head=' || l_arc_maint.cod_mis_head);
        DBG('l_arc_maint.cod_chg_desc=' || l_arc_maint.cod_chg_desc);
        DBG('l_arc_maint.cod_chg_type=' || l_arc_maint.cod_chg_type);
        DBG('PKG_ARC_ROW.CHARGE_CODE=' || l_arc_maint.CHARGE_CODE);
      
        pkg_detb_rtl_teller_rec.chg_in_lcy   := l_arc_maint.cod_chg_amt;
        pkg_detb_rtl_teller_rec.acy_lcy_rate := l_arc_maint.cod_chg_rate; --p_ifdrftpm.v_iftbs_rft_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind  := l_arc_maint.cod_chg_netting;
        pkg_detb_rtl_teller_rec.txn_code     := l_arc_maint.cod_chg_txn_code;
        pkg_detb_rtl_teller_rec.mis_head_1   := l_arc_maint.cod_mis_head;
        pkg_detb_rtl_teller_rec.chg_desc     := l_arc_maint.cod_chg_desc;
        pkg_detb_rtl_teller_rec.chg_type     := l_arc_maint.cod_chg_type;
        pkg_detb_rtl_teller_rec.waiver       := 'N';
        pkg_detb_rtl_teller_rec.their_chgs   := l_arc_maint.cod_their_chgs;
      
        DBG('pkg_detb_rtl_teller_rec.chg_type=' ||
            pkg_detb_rtl_teller_rec.chg_type);
      
        DBG('Calling depks_rtl_teller.fn_save');
      
        IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN
          dbg('FAILED IN FN_SAVE');
        
          ROLLBACK TO A;
        
          DBG('P_ERR_CODE=' || P_ERR_CODE);
          DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);
          DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);
          DBG('l_transactionUniqueNo=' || l_transactionUniqueNo);
        
          IFPKS_AIA_SI_UTILS.PR_UPDATE_AIA_WS_LOG(G.AIA_RECEIPT_REF,
                                                  L_GEN_SEQ_NO,
                                                  l_transactionUniqueNo,
                                                  'E',
                                                  L_IN_RESP,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS);
        
          CONTINUE;
        ELSE
          DBG('SUCCESS IN FN_SAVE');
        
          DBG('CALLING DEPKS_RTL_TELLER.FN_RTL_TELLER_AUTH');
          IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(L_CUST_ACCOUNT.BRANCH_CODE,
                                                      L_TRN_REF_NO,
                                                      GLOBAL.USER_ID,
                                                      GLOBAL.LCY,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
            DBG('AUTH RETRUNED FALSE' || P_ERR_CODE);
            DBG('FAILED TO PROCESS TRANSACTION');
            DBG('ROLLINGBACK TO SAVEPOINT A');
          
            ROLLBACK TO A;
          
            IFPKS_AIA_SI_UTILS.PR_UPDATE_AIA_WS_LOG(G.AIA_RECEIPT_REF,
                                                    L_GEN_SEQ_NO,
                                                    l_transactionUniqueNo,
                                                    'E',
                                                    L_IN_RESP,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS);
            CONTINUE;
          
          ELSE
          
            DBG('SUCCESS IN FN_AUTH');
          
            IFPKS_AIA_SI_UTILS.PR_UPDATE_AIA_WS_LOG(L_GEN_SEQ_NO,
                                                    l_transactionUniqueNo,
                                                    L_TRN_REF_NO,
                                                    'S');
            --insert into
            insert into IFTB_AIA_SI_PAYMENTS_MASTER
            values
              (L_TRN_REF_NO,
               G.AIA_POLICY_NO,
               PKG_DETB_RTL_TELLER_REC.TXN_ACC,
               PKG_DETB_RTL_TELLER_REC.TXN_CCY,
               PKG_DETB_RTL_TELLER_REC.TXN_AMOUNT,
               PKG_DETB_RTL_TELLER_REC.TXN_BRANCH,
               PKG_DETB_RTL_TELLER_REC.TXN_TRN_CODE,
               PKG_DETB_RTL_TELLER_REC.OFS_ACC,
               PKG_DETB_RTL_TELLER_REC.OFS_CCY,
               PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT,
               PKG_DETB_RTL_TELLER_REC.OFS_BRANCH,
               PKG_DETB_RTL_TELLER_REC.OFS_TRN_CODE,
               PKG_DETB_RTL_TELLER_REC.LCY_AMOUNT,
               PKG_DETB_RTL_TELLER_REC.TRN_DT,
               PKG_DETB_RTL_TELLER_REC.VALUE_DT,
               G.PARTNER_RECEIPT_REF);
          
            --Get AIA CONFIRM PAYMENT
            L_FORMATTED_MSG := IFPKS_AIA_SI_UTILS.FN_GET_FMT_AIA_PAYMENT(l_transactionUniqueNo,
                                                                         G.AIA_POLICY_NO,
                                                                         l_payment_amount,
                                                                         l_currency);
          
            DBG('AFTER REPLACEMENT OF AIA PAYMENT JSON=' ||
                L_FORMATTED_MSG);
          
            DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);
          
            DBG('CALLING AIA PAYMENT WEBSERVICE');
          
            IF NOT IFPKS_AIA_SI_UTILS.FN_MSG_UPLOAD(G.AIA_RECEIPT_REF,
                                                    G.AIA_POLICY_NO,
                                                    'C',
                                                    L_FORMATTED_MSG,
                                                    'Payment Confirmation Call',
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
            
              DBG('FAILED IN AIA PAYMENT CALL');
            
              --RETURN FALSE;
              ROLLBACK TO A;
              CONTINUE;
            
              IFPKS_AIA_SI_UTILS.PR_UPDATE_AIA_WS_LOG(G.AIA_RECEIPT_REF,
                                                      L_GEN_SEQ_NO,
                                                      l_transactionUniqueNo,
                                                      'E',
                                                      L_IN_RESP,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS);
            
            ELSE
            
              DBG('SUCCESS IN AIA PAYMENT CALL');
            
              IFPKS_AIA_SI_UTILS.PR_UPDATE_AIA_WS_LOG(G.AIA_RECEIPT_REF,
                                                      L_GEN_SEQ_NO,
                                                      l_transactionUniqueNo,
                                                      'S',
                                                      L_IN_RESP,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS);
            
            END IF;
          
          END IF;
        END IF;
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
        -- DBG('FAILED IN PROCESSING CURRENT INCOMING ORDER ID=' ||
        --   L_ORDER_ID);
        DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
        DBG('ERROR CODE=' || SQLCODE);
        DBG('ERROR MESSAGE=' || SQLERRM);
        CONTINUE;
    END;
  
  END LOOP;

END PR_PROCESS_AIA_SI_PAYMENTS;
