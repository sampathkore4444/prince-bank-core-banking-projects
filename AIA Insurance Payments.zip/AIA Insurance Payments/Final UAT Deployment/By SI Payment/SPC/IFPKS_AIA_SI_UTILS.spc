CREATE OR REPLACE PACKAGE IFPKS_AIA_SI_UTILS AS

  PROCEDURE PR_INSERT_AIA_WS_LOG(P_SEQ_NO          IN VARCHAR2,
                                 P_AIA_RECEIPT_REF IN VARCHAR2,
                                 P_INVOKE_DATE     IN VARCHAR2,
                                 P_POLICY_NUMBER   IN VARCHAR2,
                                 P_REQ_TYPE        IN VARCHAR2,
                                 P_REQ_MSG         IN VARCHAR2,
                                 P_ADDL_INFO       IN VARCHAR2);

  PROCEDURE PR_UPDATE_AIA_WS_LOG(P_AIA_RECEIPT_REF IN IFTB_AIA_SI_MASTER.AIA_RECEIPT_REF%TYPE,
                                 P_SEQ_NO          IN VARCHAR2,
                                 P_TXN_UNIQUE_NO   IN IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE,
                                 P_STATUS          IN CHAR,
                                 P_RES_MSG         IN CLOB,
                                 P_ERROR_CODE      IN VARCHAR2,
                                 P_ERROR_PARAM     IN VARCHAR2);

  PROCEDURE PR_UPDATE_AIA_WS_LOG(P_SEQ_NO        IN VARCHAR2,
                                 P_TXN_UNIQUE_NO IN IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE,
                                 P_TRN_REF_NO    IN IFTB_AIA_SI_WS_LOG.TRN_REF_NO%TYPE,
                                 P_STATUS        IN CHAR);

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC;

  FUNCTION fn_msg_upload( --p_ifdaiaft   IN OUT IFPKS_IFDAIAFT_MAIN.ty_ifdaiaft,
                         P_AIA_RECEIPT_REF IN VARCHAR2,
                         P_AIA_POLICY_NO   IN VARCHAR2,
                         P_REQ_TYPE        IN VARCHAR2,
                         P_REQ_MSG         IN OUT CLOB,
                         P_ADDL_INFO       IN VARCHAR2,
                         p_err_code        IN OUT VARCHAR2,
                         p_err_params      IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION fn_msg_upload( --p_ifdaiaft   IN OUT IFPKS_IFDAIAFT_MAIN.ty_ifdaiaft,
                         P_AIA_RECEIPT_REF IN VARCHAR2,
                         P_AIA_POLICY_NO   IN VARCHAR2,
                         P_REQ_TYPE        IN VARCHAR2,
                         P_REQ_MSG         IN OUT CLOB,
                         P_ADDL_INFO       IN VARCHAR2,
                         P_PAYMENT_AMT     OUT VARCHAR2,
                         P_PAYMENT_DUEDATE OUT VARCHAR2,
                         P_TXN_UNIQUE_NO   OUT VARCHAR2,
                         P_GEN_SEQ_NO      OUT VARCHAR2,
                         
                         p_err_code   IN OUT VARCHAR2,
                         p_err_params IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_GET_AIA_POLICY_ENQUIRY RETURN CLOB;

  FUNCTION FN_GET_FMT_AIA_POLICY_ENQ(P_POLICY_NO IN VARCHAR2) RETURN CLOB;

  FUNCTION FN_GET_AIA_PAYMENT RETURN CLOB;

  FUNCTION FN_GET_FMT_AIA_PAYMENT(P_TXN_UNIQUE_NO IN VARCHAR2,
                                  P_POLICY_NO     IN VARCHAR2,
                                  P_PAYMENT_AMT   IN VARCHAR2,
                                  P_CCY           IN VARCHAR2) RETURN CLOB;

END IFPKS_AIA_SI_UTILS;
