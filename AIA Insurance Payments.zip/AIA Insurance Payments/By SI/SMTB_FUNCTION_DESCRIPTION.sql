prompt Importing table SMTB_FUNCTION_DESCRIPTION...
set feedback off
set define off
insert into SMTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'IFDAIASI', 'Insurance Payments', 'Operations', 'AIA Insurance SI Creation', null, null, null, 'AIA Insurance SI Creation', 'IFDAIASI');

insert into SMTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'IFSAIASI', 'Insurance Payments', 'View', 'AIA Insurance SI Creation', null, null, null, 'AIA Insurance SI Creation', 'IFDAIASI');

prompt Done.
