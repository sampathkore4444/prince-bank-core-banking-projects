var g_PickupClicked = 0;
var n =0;

function fn_getPolicyDetails() {
	debugs("In fn_getPolicyDtls", "A");
	g_prevAction = gAction;
	gAction = "INVOKEAIA";
	appendData();
	gAction = "INVOKEAIA";
	fcjRequestDOM = buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	
	//fnEnableElement(document.getElementById("BLK_MASTER__OFF_CCY"));
	//fnEnableElement(document.getElementById("BLK_MASTER__OFF_AMOUNT"));
	//fnEnableElement(document.getElementById("BLK_MASTER__BTN_ENRICH"));
	}
	gAction=g_prevAction;
	g_PickupClicked = 1;
	
	return true;
}