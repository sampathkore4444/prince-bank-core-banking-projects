CREATE OR REPLACE PROCEDURE PR_PROCESS_AIA_PAYMENTS AS
  v_user_count NUMBER(4);
  CURSOR C1 IS SELECT * FROM IFTB_AIA_MASTER WHERE PAYMENT_DUE_DATE = SYSDATE AND STATUS = 'U'
  AND SYSDATE <= EXPIRY_DATE;
BEGIN
 
 FOR G IN C1 LOOP
 
 BEGIN

        --Initialize Branch
        --GLOBAL.pr_init('001', 'SYSTEM');

        SAVEPOINT A;

        --Get Account details
        BEGIN
          SELECT *
            INTO L_CUST_ACCOUNT
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = L_AC_NO;
        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACCOUNT := NULL;
        END;

        --GLOBAL.PR_INIT(L_CUST_ACCOUNT.BRANCH_CODE, 'SYSTEM');

       

          pkg_detb_rtl_teller_rec.product_code := 'CCMA';

       


        --Get Acc Details
        SELECT X.*
          INTO L_CUST_AC
          FROM STTM_CUST_ACCOUNT X
         WHERE X.CUST_AC_NO = L_AC_NO;

        --GET BEN CUSTOMER DETAILS
        BEGIN
          SELECT X.*
            INTO L_CUST
            FROM STTM_CUSTOMER X
           WHERE X.CUSTOMER_NO = L_CUST_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED IN GETTING CUSTOMER DETAILS');
        END;

        GLOBAL.PR_INIT(L_CUST_AC.BRANCH_CODE,'SYSTEM');

        --GET REFERENCE NO
        IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                           PKG_DETB_RTL_TELLER_REC.PRODUCT_CODE,
                                           GLOBAL.APPLICATION_DATE,
                                           L_SERIAL_NO,
                                           L_TRN_REF_NO,
                                           P_ERR_CODE) THEN
          DBG('FAILED IN GENERATION TRANSACTION REF NO');
          ROLLBACK TO A;
          CONTINUE;
        ELSE
          DBG('L_TRN_REF_NO=' || L_TRN_REF_NO);
        END IF;

        --Log Auto Debit Accounting Entry Log
        PR_INSERT_ORDER_ID_INVOKE_LOG(L_ORDER_ID, L_TRN_REF_NO, SYSDATE);

        PKG_DETB_RTL_TELLER_REC.XREF := L_TRN_REF_NO;

        --Get Arc Maintenance
        SELECT *
          INTO L_ARC_MAINT
          FROM IFTM_ARC_MAINT A
         WHERE A.COD_PROD_ACC_CLS = pkg_detb_rtl_teller_rec.product_code
           AND ROWNUM = 1;

        --Get Count of Beneficiary Account
        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = L_AC_NO;

        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;

        IF L_COUNT = 0 THEN

          ROLLBACK TO A;
          PR_UPDATE_AUTO_DEBIT_TRACKER(L_ORDER_ID, 'E');
          PR_UPDATE_ORDER_ID_INVOKE_LOG(L_ORDER_ID,
                                        L_TRN_REF_NO,
                                        'E',
                                        'FT-MTUP100',
                                        'BEN ACC NOT FOUND',
                                        GLOBAL.application_date);

          CONTINUE;

        END IF;

        --pkg_detb_rtl_teller_rec.product_code := 'CCFT';

        PKG_DETB_RTL_TELLER_REC.BRANCH_CODE := L_CUST_AC.BRANCH_CODE;
        PKG_DETB_RTL_TELLER_REC.TRN_REF_NO  := L_TRN_REF_NO;

        PKG_DETB_RTL_TELLER_REC.TXN_ACC    := L_LMTM_TYPE_VALUES.VALUE;
        PKG_DETB_RTL_TELLER_REC.TXN_CCY    := GLOBAL.LCY;
        PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := GLOBAL.CURRENT_BRANCH;
        --PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := PKG_DETB_RTL_TELLER_REC.OFS_BRANCH;

     --XRATE CALCULATION STARTS
        IF L_CUST_ACCOUNT.CCY <> 'USD' THEN

          IF NOT CYPKSS.FN_GETRATE(L_CUST_ACCOUNT.BRANCH_CODE,
                                   L_CUST_ACCOUNT.CCY,
                                   L_CCY_CODE, --'KHR', --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                   'STANDARD', --L_PROD.RATE_TYPE_PREFERRED,
                                   'B', --L_RATE_CODE1, --l_prod.rate_code_preferred,
                                   GLOBAL.APPLICATION_DATE,
                                   GLOBAL.APPLICATION_DATE,
                                   L_EXCH_RATE,
                                   L_RATE_FLAG,
                                   L_ERROR_CODE) THEN
            DBG('FAILED IN FN_GETRATE');
            ROLLBACK;
          END IF;
        ELSE
          L_EXCH_RATE := 1;
        END IF;

        DBG('L_EXCH_RATE=' || L_EXCH_RATE);

        --USING ABOVE RATE..CONVERT KHR TO USD AMOUNT
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(L_CCY_CODE,
                                      L_CUST_ACCOUNT.CCY,
                                      G.TXN_AMOUNT,
                                      L_EXCH_RATE,
                                      'Y',
                                      L_TXN_AMT,
                                      L_ERROR_PARAMETER) THEN
          DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
          ROLLBACK;
        END IF;
        DBG('FINAL L_TXN_AMT=' || L_TXN_AMT);

        PKG_DETB_RTL_TELLER_REC.OFS_ACC    := G.CUST_AC_NO;
        PKG_DETB_RTL_TELLER_REC.OFS_CCY    := L_CUST_AC.CCY;
        PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT := L_TXN_AMT;-- L_AMOUNT/100;

        PKG_DETB_RTL_TELLER_REC.OFS_BRANCH := L_CUST_AC.BRANCH_CODE; --GLOBAL.current_branch;



        PKG_DETB_RTL_TELLER_REC.TXN_AMOUNT := G.TXN_AMOUNT;--L_TXN_AMT;

        PKG_DETB_RTL_TELLER_REC.TXN_TRN_CODE     := L_ARC_MAINT.COD_MAIN_TXN_CODE; --'000'; --TRANSACION CODE
        PKG_DETB_RTL_TELLER_REC.OFS_TRN_CODE     := L_ARC_MAINT.COD_OFFSET_TXN_CODE; --'000'; --TRANSACION CODE
        PKG_DETB_RTL_TELLER_REC.EXCH_RATE        := L_EXCH_RATE;
        PKG_DETB_RTL_TELLER_REC.TRN_DT           := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.VALUE_DT         := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.REL_CUSTOMER     := L_CUST.CUSTOMER_NO;
        PKG_DETB_RTL_TELLER_REC.BENEF_NAME       := L_CUST.CUSTOMER_NAME1;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR1      := L_CUST.ADDRESS_LINE1;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR2      := L_CUST.ADDRESS_LINE2;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR3      := L_CUST.ADDRESS_LINE3;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR4      := L_CUST.ADDRESS_LINE4;
        PKG_DETB_RTL_TELLER_REC.LIQN_DT          := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.RECORD_STAT      := 'A';
        PKG_DETB_RTL_TELLER_REC.AUTH_STAT        := 'U';
        PKG_DETB_RTL_TELLER_REC.MAKER_ID         := 'SYSTEM';
        PKG_DETB_RTL_TELLER_REC.MAKER_DT_STAMP   := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.CHECKER_ID       := 'SYSTEM';
        PKG_DETB_RTL_TELLER_REC.CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.MOD_NO           := 1;
        PKG_DETB_RTL_TELLER_REC.SCODE            := 'FLEXCUBE';
        PKG_DETB_RTL_TELLER_REC.DR_ACC           := 'OFS';
        PKG_DETB_RTL_TELLER_REC.MODULE           := 'RT';
        PKG_DETB_RTL_TELLER_REC.ESN              := 1;
        PKG_DETB_RTL_TELLER_REC.EVENT_CODE       := 'INIT';
        PKG_DETB_RTL_TELLER_REC.TRACK_RECEIVABLE := 'N';
        PKG_DETB_RTL_TELLER_REC.TIME_RECEIVED    := SYSDATE;

        DBG('Calling depks_rtl_teller.fn_save');

        IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN
          dbg('FAILED IN FN_SAVE');
          --PR_LOG_ERROR('IFDCCPFT', 'FLEXCUBE', p_err_code, p_err_params);
          ROLLBACK TO A;
          PR_UPDATE_AUTO_DEBIT_TRACKER(L_ORDER_ID, 'E');
            PR_UPDATE_ORDER_ID_INVOKE_LOG(L_ORDER_ID,
                                          L_TRN_REF_NO,
                                          'E',
                                          P_ERR_CODE,
                                          P_ERR_PARAMS,
                                          GLOBAL.application_date);
        ELSE
          DBG('SUCCESS IN FN_sAVE');
          DBG('CALLING DEPKS_RTL_TELLER.FN_RTL_TELLER_AUTH');
          IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(L_CUST_AC.BRANCH_CODE,
                                                      L_TRN_REF_NO,
                                                      GLOBAL.USER_ID,
                                                      GLOBAL.LCY,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
            DBG('AUTH RETRUNED FALSE' || P_ERR_CODE);
            DBG('FAILED TO PROCESS TRANSACTION');
            DBG('ROLLINGBACK TO SAVEPOINT A');
            ROLLBACK TO A;
            PR_UPDATE_AUTO_DEBIT_TRACKER(L_ORDER_ID, 'E');
            PR_UPDATE_ORDER_ID_INVOKE_LOG(L_ORDER_ID,
                                          L_TRN_REF_NO,
                                          'E',
                                          P_ERR_CODE,
                                          P_ERR_PARAMS,
                                          GLOBAL.application_date);
          ELSE
            DBG('SUCCESS IN FN_AUTH');
            PR_UPDATE_AUTO_DEBIT_TRACKER(L_ORDER_ID, 'P');
            PR_UPDATE_ORDER_ID_INVOKE_LOG(L_ORDER_ID,
                                          L_TRN_REF_NO,
                                          'P',
                                          NULL,
                                          NULL,
                                          GLOBAL.application_date);
          END IF;
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN PROCESSING CURRENT INCOMING ORDER ID=' ||
              L_ORDER_ID);
          DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
          CONTINUE;
      END;
 
 END LOOP;
 
END PR_PROCESS_AIA_PAYMENTS;
/

BEGIN
DBMS_SCHEDULER.CREATE_PROGRAM (
program_name      => 'PROG_PROCESS_AIA_PAYMENTS',
program_action    => 'PR_PROCESS_AIA_PAYMENTS',
program_type      => 'STORED_PROCEDURE');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_SCHEDULE (
 schedule_name   => 'SCH_DAILY_AIA_PAY_SCHEDULE',
 start_date    => '16-nov-2021 11:50:00 pm',--SYSTIMESTAMP,
 repeat_interval  => 'FREQ=DAILY; BYHOUR=5;BYMINUTE=59',--INTERVAL=5; BYDAY=SAT,SUN',
 --end_date     => SYSTIMESTAMP + INTERVAL '30' day,
 comments     => 'Daily at 5:59 AM');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_JOB (
  job_name     => 'JOB_PROCESS_AIA_PAYMENTS',
  program_name   => 'PROG_PROCESS_AIA_PAYMENTS',
  schedule_name   => 'SCH_DAILY_AIA_PAY_SCHEDULE',
  enabled            =>  true);
END;
/

BEGIN
exec dbms_scheduler.enable('JOB_PROCESS_AIA_PAYMENTS’);
END;


--enable job
begin
dbms_scheduler.enable('JOB_PROCESS_AIA_SI_PAYMENTS');
end;
--enable program
begin
DBMS_SCHEDULER.ENABLE('PROG_PROCESS_AIA_SI_PAYMENTS');
end;


--drop commands in sequence

--drop1:
begin
  dbms_scheduler.drop_job('JOB_PROCESS_AIA_SI_PAYMENTS');
end;

--drop2:
begin
 dbms_scheduler.drop
 _schedule('SCH_DAILY_AIA_PAY_SI_SCHEDULE');
end;

--drop3:
begin
  dbms_scheduler.drop_program('PROG_PROCESS_AIA_SI_PAYMENTS');
end;




*************************Final Starts*********************
BEGIN
DBMS_SCHEDULER.CREATE_PROGRAM (
program_name      => 'PROG_PROCESS_AIA_SI_PAYMENTS',
program_action    => 'PR_PROCESS_AIA_SI_PAYMENTS',
program_type      => 'STORED_PROCEDURE');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_SCHEDULE (
 schedule_name   => 'SCH_DAILY_AIA_PAY_SI_SCHEDULE',
 start_date    => '01-dec-2021 10:39:00 pm',--SYSTIMESTAMP,
 repeat_interval  => 'FREQ=MINUTELY;INTERVAL=2;', --BYHOUR=10;BYMINUTE=39,--INTERVAL=5; BYDAY=SAT,SUN',
 --end_date     => SYSTIMESTAMP + INTERVAL '30' day,
 comments     => 'Daily at 10:39 AM');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_JOB (
  job_name     => 'JOB_PROCESS_AIA_SI_PAYMENTS',
  program_name   => 'PROG_PROCESS_AIA_SI_PAYMENTS',
  schedule_name   => 'SCH_DAILY_AIA_PAY_SI_SCHEDULE',
  enabled            =>  true);
END;
/


--enable job
begin
dbms_scheduler.enable('JOB_PROCESS_AIA_SI_PAYMENTS');
end;
--enable program
begin
DBMS_SCHEDULER.ENABLE('PROG_PROCESS_AIA_SI_PAYMENTS');
end;


--drop commands in sequence

--drop1:
begin
  dbms_scheduler.drop_job('JOB_PROCESS_AIA_SI_PAYMENTS');
end;

--drop2:
begin
 dbms_scheduler.drop_schedule('SCH_DAILY_AIA_PAY_SI_SCHEDULE');
end;

--drop3:
begin
  dbms_scheduler.drop_program('PROG_PROCESS_AIA_SI_PAYMENTS');
end;
**************************Final Ends****************************

