CREATE OR REPLACE PROCEDURE PR_PROCESS_LOAN_REPAY_ALERTS AS

  L_UNIQUE_SEQ_NO VARCHAR2(105);

  CURSOR C1 IS
    SELECT a.schedule_st_date schedule_st_date,
           a.schedule_due_date schedule_due_date,
           a.account_number account_number,
           a.branch_code branch_code,
           a.component_name component_name,
           a.settlement_ccy settlement_ccy,
           NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) AMOUNT_DUE,
           a.sch_status sch_status
      FROM p1fchprfm.cltbs_account_schedules  a,
           p1fchprfm.cltms_product_components b,
           -- cltbs_account_master     c
           p1fchprfm.cltbs_account_apps_master c
     WHERE a.account_number = c.account_number
       AND a.branch_code = c.branch_code
       AND b.product_code = c.product_code
       AND a.component_name = b.component_name
       AND NVL(b.comp_reporting_type, '#') <> 'PV'
          --and a.account_number = '9000317221'
       and a.component_name in ('PRINCIPAL', 'MAIN_INT')
          --AND A.AMOUNT_DUE > 0
       AND NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) <> 0
       AND TO_DATE(SYSDATE) = A.SCHEDULE_DUE_DATE - 2
          --AND A.SCHEDULE_DUE_DATE = TO_DATE(SYSDATE) - 2
       AND A.SCH_STATUS = 'NORM'
     ORDER BY A.ACCOUNT_NUMBER, A.SCHEDULE_ST_DATE, component_name;

  PRAGMA AUTONOMOUS_TRANSACTION;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_BAKONG_UTILITIES ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN
  
    SELECT TRSQ_LOANREPAY_ALERT_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    RETURN L_REF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

BEGIN

  DEBUG.PR_DEBUG('AC', 'START OF PR_PROCESS_LOAN_REPAY_ALERTS');

  FOR G IN C1 LOOP
  
    BEGIN
    
      L_UNIQUE_SEQ_NO := FN_RETURN_SEQ_NO;
    
      INSERT INTO STTB_LOAN_REPAYMENT_ALERT
        (UNIQUE_SEQ_NO,
         ACCOUNT_NUMBER,
         BRANCH_CODE,
         COMPONENT_NAME,
         SETTLEMENT_CCY,
         AMOUNT_DUE,
         SCH_STATUS,
         SCHEDULE_ST_DATE,
         SCHEDULE_DUE_DATE,
         ALERT1_DATE,
         IS_ALERT1_SENT,
         ALERT2_DATE,
         IS_ALERT2_SENT)
      VALUES
        (L_UNIQUE_SEQ_NO,
         G.ACCOUNT_NUMBER,
         G.BRANCH_CODE,
         G.COMPONENT_NAME,
         G.SETTLEMENT_CCY,
         G.AMOUNT_DUE,
         G.SCH_STATUS,
         G.SCHEDULE_ST_DATE,
         G.SCHEDULE_DUE_DATE,
         SYSDATE,
         'N',
         SYSDATE,
         'N');
    
      COMMIT;
    
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('AC',
                       'FAILED IN PROCESSING CURRENT UNIQUE SEQ NO=' ||
                       L_UNIQUE_SEQ_NO);
        ROLLBACK;
        
        CONTINUE;
      
    END;
  
  END LOOP;

EXCEPTION
  WHEN OTHERS THEN
    DEBUG.PR_DEBUG('AC',
                   'ERROR CODE IN PR_PROCESS_LOAN_REPAY_ALERTS=' || SQLCODE);
    DEBUG.PR_DEBUG('AC',
                   'ERROR MESSAGE IN PR_PROCESS_LOAN_REPAY_ALERTS=' ||
                   SQLCODE);
  
END PR_PROCESS_LOAN_REPAY_ALERTS;
