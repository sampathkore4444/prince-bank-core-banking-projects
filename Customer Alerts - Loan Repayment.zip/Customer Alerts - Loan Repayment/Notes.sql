SELECT a.schedule_st_date schedule_st_date, --BUG#27236308 added
a.schedule_due_date schedule_due_date,
       a.account_number account_number,
       a.branch_code branch_code,
       a.component_name component_name,
       a.settlement_ccy settlement_ccy,
       NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) AMOUNT_DUE,
       a.sch_status sch_status
  FROM p1fchprfm.cltbs_account_schedules  a, -- Log #1679 changes start
       p1fchprfm.cltms_product_components b,
     -- FCUBS12.0.3->IRONVBR->19342287 starts
       -- cltbs_account_master     c
     p1fchprfm.cltbs_account_apps_master c
     -- FCUBS12.0.3->IRONVBR->19342287 ends
 WHERE a.account_number = c.account_number
   AND a.branch_code = c.branch_code
   AND b.product_code = c.product_code
   AND a.component_name = b.component_name
   AND NVL(b.comp_reporting_type, '#') <> 'PV' -- Log #1679 changes end
   --and a.account_number = '9000317221'
   and a.component_name in ('PRINCIPAL','MAIN_INT') 
   --AND A.AMOUNT_DUE > 0
   AND NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) <> 0
   AND TO_DATE(SYSDATE) = A.SCHEDULE_DUE_DATE - 2
   --AND A.SCHEDULE_DUE_DATE = TO_DATE(SYSDATE) - 2
   AND A.SCH_STATUS = 'NORM'
   ORDER BY A.ACCOUNT_NUMBER, A.SCHEDULE_ST_DATE, component_name;


CREATE TABLE STTB_LOAN_REPAYMENT_ALERT(UNIQUE_SEQ_NO VARCHAR2(105), ACCOUNT_NUMBER varchar2(35) , BRANCH_CODE varchar2(35) , COMPONENT_NAME varchar2(20) , SETTLEMENT_CCY varchar2(3) , AMOUNT_DUE number , SCH_STATUS varchar2(4) , SCHEDULE_ST_DATE date , SCHEDULE_DUE_DATE date , ALERT1_DATE date, IS_ALERT1_SENT CHAR(1) DEFAULT 'N', ALERT2_DATE date, IS_ALERT2_SENT CHAR(1) DEFAULT 'N')
ALTER TABLE STTB_LOAN_REPAYMENT_ALERT ADD PRIMARY KEY(UNIQUE_SEQ_NO, ACCOUNT_NUMBER, BRANCH_CODE, COMPONENT_NAME, SETTLEMENT_CCY)

CREATE OR REPLACE PROCEDURE PR_PROCESS_LOAN_REPAY_ALERTS AS 

-- Create sequence 
create sequence TRSQ_LOANREPAY_ALERT_SEQID
minvalue 1
maxvalue 999999999
start with 1
increment by 1
nocache
cycle;




select account_number,
       A.branch_code,
       component_name,
       (sum(nvl(amount_due, 0) - nvl(amount_settled, 0))) expected,
       0 overdue,
       0 advance,
       settlement_ccy
  from cltb_Account_Schedules A, STTM_DATES B
 WHERE
-- STARTS EUROBANK RETRO
 NVL(SCHEDULE_FLAG, '#') <> 'M'
 AND A.BRANCH_CODE = B.BRANCH_CODE
 AND SCHEDULE_DUE_DATE >= B.TODAY
 AND nvl(SCHEDULE_FLAG, 'X') <> 'M'
 --and ((nvl(amount_due, 0) - nvl(amount_settled, 0))) > 0
 and account_number = '9000135010'
 group by account_number, A.branch_code, component_name, settlement_ccy --59787.36



https://www.sender.net/blog/payment-reminder-sms-text-message/
https://www.sender.net/blog/payment-reminder-sms-text-message/
https://www.voicesage.com/blog/11-financial-service-sms-templates-for-you-to-steal/
https://www.forbes.com/advisor/banking/types-of-bank-account-alerts-to-set/


- Low Balance Alerts
- High Balance Alerts
- 