-- Create table
create table STTB_LOAN_REPAYMENT_ALERT
(
  unique_seq_no     VARCHAR2(105) not null,
  account_number    VARCHAR2(35) not null,
  branch_code       VARCHAR2(35) not null,
  component_name    VARCHAR2(20) not null,
  settlement_ccy    VARCHAR2(3) not null,
  amount_due        NUMBER,
  sch_status        VARCHAR2(4),
  schedule_st_date  DATE,
  schedule_due_date DATE,
  alert1_date       DATE,
  is_alert1_sent    CHAR(1) default 'N',
  alert2_date       DATE,
  is_alert2_sent    CHAR(1) default 'N'
)
/
alter table STTB_LOAN_REPAYMENT_ALERT add primary key (UNIQUE_SEQ_NO, ACCOUNT_NUMBER, BRANCH_CODE, COMPONENT_NAME, SETTLEMENT_CCY)
/