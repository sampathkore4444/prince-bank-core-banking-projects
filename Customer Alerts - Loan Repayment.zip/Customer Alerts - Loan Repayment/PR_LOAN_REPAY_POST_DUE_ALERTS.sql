CREATE OR REPLACE PROCEDURE PR_LOAN_REPAY_POST_DUE_ALERTS(P_PARAM_NAMES VARCHAR2,
                                                          P_PARAM_VALS  VARCHAR2) AS

  L_UNIQUE_SEQ_NO VARCHAR2(105);

  --L_MESSAGE VARCHAR2(255) := 'Dear Valued customer, As we wouldn''t want anything to impact your Good Credit Score, We''d like to remind you that a payment of $L_AMOUNT_DUE $L_SETTLEMENT_CCY for loan account $L_LOAN_ACCOUNT_NO will be due by $L_SCHDULE_DUE_DATE. Regards, Prince Bank Plc';

  L_REMINDER_ENG VARCHAR2(255) := 'Please be informed that your loan repayment is overdue! Please visit one of our nearest branches to settle your payment. The interest and penalty will be calculated based on your payment date.'; --Loan account --DD/MM/YYYY --USD/KHR --amount

  L_REMINDER_KH VARCHAR2(255) := 'ធនាគារ ព្រីនស៍ សូមជម្រាបជូនថា ការទូទាត់សងឥណទានរបស់លោកអ្នកបានហួសថ្ងៃកំណត់នៃការទូទាត់! សូមអញ្ជើញមកកាន់សាខារបស់ធនាគារ ព្រីនស៍មួយណាដែលនៅជិតលោកអ្នកបំផុត ដើម្បីធ្វើការទូទាត់ឥណទានរបស់លោកអ្នក។ សម្រាប់ការប្រាក់ និងប្រាក់ពិន័យ នឹងត្រូវបានគណនា ដោយផ្អែកលើកាលបរិច្ឆេទនៃការទូទាត់របស់លោកអ្នក។ ';

  L_REMINDER_CN VARCHAR2(255) := '太子银行谨此通知，您的贷款偿还已逾期！请亲临我们任一最近分行以进行付款。利息和罚款将根据您的付款日期计算。 ';

  CURSOR C1 IS
  /*  SELECT a.schedule_st_date schedule_st_date,
                                           a.schedule_due_date schedule_due_date,
                                           a.account_number account_number,
                                           a.branch_code branch_code,
                                           a.component_name component_name,
                                           a.settlement_ccy settlement_ccy,
                                           NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) AMOUNT_DUE,
                                           a.sch_status sch_status
                                      FROM p1fchprfm.cltbs_account_schedules  a,
                                           p1fchprfm.cltms_product_components b,
                                           -- cltbs_account_master     c
                                           p1fchprfm.cltbs_account_apps_master c
                                     WHERE a.account_number = c.account_number
                                       AND a.branch_code = c.branch_code
                                       AND b.product_code = c.product_code
                                       AND a.component_name = b.component_name
                                       AND NVL(b.comp_reporting_type, '#') <> 'PV'
                                          --and a.account_number = '9000317221'
                                       and a.component_name in ('PRINCIPAL', 'MAIN_INT')
                                          --AND A.AMOUNT_DUE > 0
                                       AND NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) > 0
                                       AND TO_DATE(SYSDATE) = A.SCHEDULE_DUE_DATE - 2
                                          --AND A.SCHEDULE_DUE_DATE = TO_DATE(SYSDATE) - 2
                                       AND A.SCH_STATUS = 'NORM'
                                     ORDER BY A.ACCOUNT_NUMBER, A.SCHEDULE_ST_DATE;--, component_name;*/
  
    SELECT a.schedule_st_date  schedule_st_date,
           a.schedule_due_date schedule_due_date,
           a.account_number    account_number,
           a.branch_code       branch_code,
           -- a.component_name component_name,
           a.settlement_ccy settlement_ccy,
           sum(NVL(a.amount_due, 0) - NVL(a.amount_settled, 0)) AMOUNT_DUE,
           a.sch_status sch_status
      FROM p1fchprfm.cltbs_account_schedules   a,
           p1fchprfm.cltms_product_components  b,
           p1fchprfm.cltbs_account_apps_master c
     WHERE a.account_number = c.account_number
       AND a.branch_code = c.branch_code
       AND b.product_code = c.product_code
       AND a.component_name = b.component_name
       AND NVL(b.comp_reporting_type, '#') <> 'PV'
          --and a.account_number = '9000317221'
          --and a.component_name in ('PRINCIPAL','MAIN_INT')
          --AND A.AMOUNT_DUE > 0
       AND NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) > 0
       AND TO_DATE(SYSDATE) = A.SCHEDULE_DUE_DATE + 1
          --AND A.SCHEDULE_DUE_DATE = TO_DATE(SYSDATE) - 2
       AND A.SCH_STATUS = 'NORM'
     GROUP BY A.schedule_st_date,
              A.schedule_due_date,
              A.ACCOUNT_NUMBER,
              A.BRANCH_CODE,
              A.SETTLEMENT_CCY,
              A.sch_status
     ORDER BY A.ACCOUNT_NUMBER, A.SCHEDULE_ST_DATE; --, component_name;

  PRAGMA AUTONOMOUS_TRANSACTION;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'PR_LOAN_REPAY_POST_DUE_ALERTS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN
  
    SELECT TRSQ_LOANREPAY_ALERT_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    RETURN L_REF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

BEGIN

  DEBUG.PR_DEBUG('AC', 'START OF PR_LOAN_REPAY_POST_DUE_ALERTS');

  FOR G IN C1 LOOP
  
    BEGIN
    
      L_UNIQUE_SEQ_NO := FN_RETURN_SEQ_NO;
    
      --ENG
      L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                '$L_AMOUNT_DUE',
                                NVL(G.AMOUNT_DUE, 0));
    
      L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                '$L_SETTLEMENT_CCY',
                                G.SETTLEMENT_CCY);
    
      L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                '$L_LOAN_ACCOUNT_NO',
                                G.ACCOUNT_NUMBER);
    
      L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                '$L_SCHDULE_DUE_DATE',
                                G.SCHEDULE_DUE_DATE);
    
      --KH
      L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                               '$L_AMOUNT_DUE',
                               NVL(G.AMOUNT_DUE, 0));
    
      L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                               '$L_SETTLEMENT_CCY',
                               G.SETTLEMENT_CCY);
    
      L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                               '$L_LOAN_ACCOUNT_NO',
                               G.ACCOUNT_NUMBER);
    
      L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                               '$L_SCHDULE_DUE_DATE',
                               G.SCHEDULE_DUE_DATE);
    
      --CN
      L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                               '$L_AMOUNT_DUE',
                               NVL(G.AMOUNT_DUE, 0));
    
      L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                               '$L_SETTLEMENT_CCY',
                               G.SETTLEMENT_CCY);
    
      L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                               '$L_LOAN_ACCOUNT_NO',
                               G.ACCOUNT_NUMBER);
    
      L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                               '$L_SCHDULE_DUE_DATE',
                               G.SCHEDULE_DUE_DATE);
    
      INSERT INTO STTB_LOAN_REPAY_POST_DUE_ALERT
        (UNIQUE_SEQ_NO,
         ACCOUNT_NUMBER,
         BRANCH_CODE,
         --  COMPONENT_NAME,
         SETTLEMENT_CCY,
         AMOUNT_DUE,
         SCH_STATUS,
         SCHEDULE_ST_DATE,
         SCHEDULE_DUE_DATE,
         ALERT_DATE,
         IS_ALERT_SENT,
         REMINDER_ENG,
         REMINDER_KH,
         REMINDER_CN)
      VALUES
        (L_UNIQUE_SEQ_NO,
         G.ACCOUNT_NUMBER,
         G.BRANCH_CODE,
         --  G.COMPONENT_NAME,
         G.SETTLEMENT_CCY,
         G.AMOUNT_DUE,
         G.SCH_STATUS,
         G.SCHEDULE_ST_DATE,
         G.SCHEDULE_DUE_DATE,
         SYSDATE,
         'N',
         
         L_REMINDER_ENG,
         L_REMINDER_KH,
         L_REMINDER_CN);
    
      COMMIT;
    
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('AC',
                       'FAILED IN PROCESSING CURRENT UNIQUE SEQ NO=' ||
                       L_UNIQUE_SEQ_NO);
        ROLLBACK;
      
        CONTINUE;
      
    END;
  
  END LOOP;

EXCEPTION
  WHEN OTHERS THEN
    DEBUG.PR_DEBUG('AC',
                   'ERROR CODE IN PR_LOAN_REPAY_POST_DUE_ALERTS=' ||
                   SQLCODE);
    DEBUG.PR_DEBUG('AC',
                   'ERROR MESSAGE IN PR_LOAN_REPAY_POST_DUE_ALERTS=' ||
                   SQLCODE);
  
END PR_LOAN_REPAY_POST_DUE_ALERTS;
