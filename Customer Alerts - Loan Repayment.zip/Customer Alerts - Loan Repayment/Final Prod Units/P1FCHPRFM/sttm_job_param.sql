prompt Importing table sttm_job_param...
set feedback off
set define off
insert into sttm_job_param (JOB_CODE, PARAM_NAME, DATA_TYPE, PARAM_VALUE)
values ('LOAN_POST_CUST_ALERT_HANDOFF', 'NAME', 'VARCHAR', 'OFSS');

insert into sttm_job_param (JOB_CODE, PARAM_NAME, DATA_TYPE, PARAM_VALUE)
values ('LOAN_PRE_CUST_ALERT_HANDOFF', 'NAME', 'VARCHAR', 'OFSS');

prompt Done.
