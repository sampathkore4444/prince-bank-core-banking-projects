prompt Importing table sttm_job_definition...
set feedback off
set define off
insert into sttm_job_definition (JOB_CODE, JOB_GROUP, JOB_DESCRIPTION, SCHEDULER, TRG_TYPE, CRON_EXPR, JOB_TYPE, JOB_CLASS_OR_PROC, SIMPLE_TRG_REPEAT, SIMPLE_TRG_FREQUENCY, TRIGGER_LISTENER, ACTIVE, JNDI_NAME, LOGGING_REQD, AUTH_STAT, CHECKER_DT_STAMP, CHECKER_ID, MAKER_DT_STAMP, MOD_NO, ONCE_AUTH, RECORD_STAT, MAKER_ID, SCHED_TYPE, VETO_BLK_TRG, PRIORITY, MSG_QUEUE, MAX_NO_INSTANCES, STARTUP_MODE)
values ('LOAN_POST_CUST_ALERT_HANDOFF', 'PLSQL', 'Loan Customer Alert after due date Handoff', 'SchedulerFactory', 'C', '0 50 09 1/1 * ? *', 'PLSQL', 'STPKS_ALERT_UTILS.PR_LOAN_REPAY_POST_DUE_ALERTS', -1, null, null, 'Y', 'jdbc/fcjdevDS', 'Y', 'A', to_date('25-01-2022 09:44:49', 'dd-mm-yyyy hh24:mi:ss'), 'OPERATOR4', to_date('25-01-2022 09:44:49', 'dd-mm-yyyy hh24:mi:ss'), 3, 'Y', 'O', 'OPERATOR4', 'QUARTZ', 'N', 5, null, 1, 'M');

insert into sttm_job_definition (JOB_CODE, JOB_GROUP, JOB_DESCRIPTION, SCHEDULER, TRG_TYPE, CRON_EXPR, JOB_TYPE, JOB_CLASS_OR_PROC, SIMPLE_TRG_REPEAT, SIMPLE_TRG_FREQUENCY, TRIGGER_LISTENER, ACTIVE, JNDI_NAME, LOGGING_REQD, AUTH_STAT, CHECKER_DT_STAMP, CHECKER_ID, MAKER_DT_STAMP, MOD_NO, ONCE_AUTH, RECORD_STAT, MAKER_ID, SCHED_TYPE, VETO_BLK_TRG, PRIORITY, MSG_QUEUE, MAX_NO_INSTANCES, STARTUP_MODE)
values ('LOAN_PRE_CUST_ALERT_HANDOFF', 'PLSQL', 'Loan Customer Alert before due date Handoff', 'SchedulerFactory', 'C', '0 50 09 1/1 * ? *', 'PLSQL', 'STPKS_ALERT_UTILS.PR_LOAN_REPAY_PRE_DUE_ALERTS', -1, null, null, 'Y', 'jdbc/fcjdevDS', 'Y', 'A', to_date('25-01-2022 09:45:47', 'dd-mm-yyyy hh24:mi:ss'), 'OPERATOR4', to_date('25-01-2022 09:45:47', 'dd-mm-yyyy hh24:mi:ss'), 3, 'Y', 'O', 'OPERATOR4', 'QUARTZ', 'N', 5, null, 1, 'M');

prompt Done.
