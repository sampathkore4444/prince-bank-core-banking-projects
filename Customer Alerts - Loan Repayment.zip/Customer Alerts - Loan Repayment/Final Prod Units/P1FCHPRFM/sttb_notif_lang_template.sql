﻿insert into sttb_notif_lang_template (LANGUAGE, TRIGGER_ALERT, MESSAGE)
values ('KH', 'PRE', 'ការទូទាត់សងឥណទានរបស់អ្នកសម្រាប់ខែ $L_DUE_MON ($L_LOAN_NO) ដោយប្រាក់ដើមមានចំនួន $L_CCY $P_AMT_DUE ការប្រាក់មានចំនួន $L_CCY $I_AMT_DUE ហើយប្រាក់សរុបត្រូវបង់មានចំនួន $L_CCY $T_AMT_DUE នឹងត្រូវទូទាត់ក្នុងថ្ងៃ $L_DUE_DATE។.');

insert into sttb_notif_lang_template (LANGUAGE, TRIGGER_ALERT, MESSAGE)
values ('EN', 'PRE', 'Your loan repayment for $L_DUE_MON ($L_LOAN_NO), the principal is $L_CCY $P_AMT_DUE, the interest is $L_CCY $I_AMT_DUE, and the total amount to be paid is $L_CCY $T_AMT_DUE will be due on $L_DUE_DATE.');

insert into sttb_notif_lang_template (LANGUAGE, TRIGGER_ALERT, MESSAGE)
values ('CH', 'PRE', '您的贷款偿还 $L_DUE_MON ($L_LOAN_NO)，本金为 $L_CCY $P_AMT_DUE，利息为 $L_CCY $I_AMT_DUE，而需支付总额为 $L_CCY $T_AMT_DUE 将于 $L_DUE_DATE 结算。 .');

insert into sttb_notif_lang_template (LANGUAGE, TRIGGER_ALERT, MESSAGE)
values ('EN', 'POST', 'Your loan repayment is overdue! Please visit one of our nearest branches to settle your payment. The interest and penalty will be calculated based on your payment date.');

insert into sttb_notif_lang_template (LANGUAGE, TRIGGER_ALERT, MESSAGE)
values ('KH', 'POST', 'ការទូទាត់សងឥណទានរបស់លោកអ្នកបានហួសថ្ងៃកំណត់នៃការទូទាត់! សូមអញ្ជើញមកកាន់សាខារបស់ធនាគារ ព្រីនស៍មួយណាដែលនៅជិតលោកអ្នកបំផុត ដើម្បីធ្វើការទូទាត់ឥណទានរបស់លោកអ្នក។ សម្រាប់ការប្រាក់ និងប្រាក់ពិន័យ នឹងត្រូវបានគណនា ដោយផ្អែកលើកាលបរិច្ឆេទនៃការទូទាត់របស់លោកអ្នក។.');

insert into sttb_notif_lang_template (LANGUAGE, TRIGGER_ALERT, MESSAGE)
values ('CH', 'POST', '您的贷款偿还已逾期！请亲临我们任一最近分行以进行付款。利息和罚款将根据您的付款日期计算。.');

commit;