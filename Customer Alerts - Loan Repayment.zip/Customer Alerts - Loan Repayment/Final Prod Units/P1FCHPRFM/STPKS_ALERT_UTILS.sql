CREATE OR REPLACE PACKAGE BODY STPKS_ALERT_UTILS AS

  FUNCTION FN_GET_REMINDER_MSG(P_LANG       IN VARCHAR2,
                               P_WHEN_ALERT IN VARCHAR2)
    RETURN STTB_NOTIF_LANG_TEMPLATE.MESSAGE%TYPE AS

    L_REMINDER_MSG STTB_NOTIF_LANG_TEMPLATE.MESSAGE%TYPE;

  BEGIN

    BEGIN
      SELECT MESSAGE
        INTO L_REMINDER_MSG
        FROM STTB_NOTIF_LANG_TEMPLATE A
       WHERE A.LANGUAGE = P_LANG
         AND A.TRIGGER_ALERT = P_WHEN_ALERT;
    EXCEPTION
      WHEN OTHERS THEN
        L_REMINDER_MSG := NULL;
    END;

    RETURN L_REMINDER_MSG;

  EXCEPTION
    WHEN OTHERS THEN

      RETURN L_REMINDER_MSG;

  END FN_GET_REMINDER_MSG;

  FUNCTION FN_GET_FORMATTED_AMOUNT(P_CCY IN VARCHAR2, P_AMOUNT IN NUMBER)
    RETURN VARCHAR2 AS

    L_FORMATTED_AMOUNT  VARCHAR2(30);

  BEGIN

    L_FORMATTED_AMOUNT := CYPKS.csfn_format_amt(P_CCY, P_AMOUNT);

    RETURN L_FORMATTED_AMOUNT;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_FORMATTED_AMOUNT;

  END FN_GET_FORMATTED_AMOUNT;

  PROCEDURE PR_LOAN_REPAY_PRE_DUE_ALERTS(P_PARAM_NAMES VARCHAR2,
                                         P_PARAM_VALS  VARCHAR2) AS

    L_UNIQUE_SEQ_NO VARCHAR2(105);
    L_REMINDER_ENG  VARCHAR2(255);
    L_REMINDER_KH   VARCHAR2(255);--VARCHAR2(255);
    L_REMINDER_CN   VARCHAR2(255);

    --L_MESSAGE VARCHAR2(255) := 'Dear Valued customer, As we wouldn''t want anything to impact your Good Credit Score, We''d like to remind you that a payment of $L_AMOUNT_DUE $L_SETTLEMENT_CCY for loan account $L_LOAN_ACCOUNT_NO will be due by $L_SCHDULE_DUE_DATE. Regards, Prince Bank Plc';

    -- L_REMINDER_ENG VARCHAR2(1000) := 'Your loan repayment for MM-YYYY ($L_LOAN_ACCOUNT_NO), the principal is $L_SETTLEMENT_CCY ($L_AMOUNT_DUE), the interest is $L_SETTLEMENT_CCY ($L_AMOUNT_DUE), and the total amount to be paid is $L_SETTLEMENT_CCY ($L_AMOUNT_DUE) will be due on $L_SCHDULE_DUE_DATE . For more info, please call 1800 20 8888.'; --Loan account --DD/MM/YYYY --USD/KHR --amount

    --L_REMINDER_KH NCHAR(1000) := '???????????????????????????????? MM-YYYY ($L_LOAN_ACCOUNT_NO) ???????????????????? ($L_AMOUNT_DUE) ???????/??? ????????????????? ($L_AMOUNT_DUE) ???????/??? ????????????????????????????? ($L_AMOUNT_DUE) ???????/??? ????????????????????? $L_SCHDULE_DUE_DATE ????????????????????? ????????? 1800 20 8888? ';

    -- L_REMINDER_KH VARCHAR2(1000) := '??????????????????????????????? MM-YYYY (Loan account) ???????????????????? (amount) ???????/??? ????????????????? (amount) ???????/??? ????????????????????????????? (amount) ???????/??? ??????????????????????? DD/MM/YYYY ????????????????????? ????????? 1800 20 8888?';

    -- L_REMINDER_CN VARCHAR2(1000) := '??????MM-YYYY ($L_LOAN_ACCOUNT_NO),???($L_AMOUNT_DUE)??/??,???($L_AMOUNT_DUE)??/??,???????($L_AMOUNT_DUE)??/????$L_SCHDULE_DUE_DATE ??? ???????,???1800 20 8888';

    CURSOR C1 IS
    /*  SELECT a.schedule_st_date schedule_st_date,
                                                                                                                                                               a.schedule_due_date schedule_due_date,
                                                                                                                                                               a.account_number account_number,
                                                                                                                                                               a.branch_code branch_code,
                                                                                                                                                               a.component_name component_name,
                                                                                                                                                               a.settlement_ccy settlement_ccy,
                                                                                                                                                               NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) AMOUNT_DUE,
                                                                                                                                                               a.sch_status sch_status
                                                                                                                                                          FROM p1fchprfm.cltbs_account_schedules  a,
                                                                                                                                                               p1fchprfm.cltms_product_components b,
                                                                                                                                                               -- cltbs_account_master     c
                                                                                                                                                               p1fchprfm.cltbs_account_apps_master c
                                                                                                                                                         WHERE a.account_number = c.account_number
                                                                                                                                                           AND a.branch_code = c.branch_code
                                                                                                                                                           AND b.product_code = c.product_code
                                                                                                                                                           AND a.component_name = b.component_name
                                                                                                                                                           AND NVL(b.comp_reporting_type, '#') <> 'PV'
                                                                                                                                                              --and a.account_number = '9000317221'
                                                                                                                                                           and a.component_name in ('PRINCIPAL', 'MAIN_INT')
                                                                                                                                                              --AND A.AMOUNT_DUE > 0
                                                                                                                                                           AND NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) > 0
                                                                                                                                                           AND TO_DATE(SYSDATE) = A.SCHEDULE_DUE_DATE - 2
                                                                                                                                                              --AND A.SCHEDULE_DUE_DATE = TO_DATE(SYSDATE) - 2
                                                                                                                                                           AND A.SCH_STATUS = 'NORM'
                                                                                                                                                         ORDER BY A.ACCOUNT_NUMBER, A.SCHEDULE_ST_DATE;--, component_name;*/

      SELECT distinct a.schedule_st_date  schedule_st_date,
             a.schedule_due_date schedule_due_date,
             a.account_number    account_number,
             a.branch_code       branch_code,
             -- a.component_name component_name,
             a.settlement_ccy settlement_ccy,
             (select NVL(SUM(NVL(b.amount_due, 0) - NVL(b.amount_settled, 0)),0)
                from p1fchprfm.cltbs_account_schedules b
               where b.account_number = a.account_number
                 and b.component_name = 'PRINCIPAL'
                 --and TO_DATE(SYSDATE) = B.SCHEDULE_DUE_DATE - 1) PRINCIPAL_AMOUNT_DUE,
                 and B.SCHEDULE_DUE_DATE = GLOBAL.application_date + 1) PRINCIPAL_AMOUNT_DUE,
             (select NVL(SUM(NVL(b.amount_due, 0) - NVL(b.amount_settled, 0)),0)
                from p1fchprfm.cltbs_account_schedules b
               where b.account_number = a.account_number
                 and b.component_name = 'MAIN_INT'
                 --and TO_DATE(SYSDATE) = B.SCHEDULE_DUE_DATE - 1) MAIN_INT_AMOUNT_DUE,
                 and B.SCHEDULE_DUE_DATE = GLOBAL.application_date + 1) MAIN_INT_AMOUNT_DUE,
             (select NVL(SUM(NVL(b.amount_due, 0) - NVL(b.amount_settled, 0)),0)
                from p1fchprfm.cltbs_account_schedules b
               where b.account_number = a.account_number
                 and b.component_name IN ('MAIN_INT','PRINCIPAL')
                  AND NVL(b.amount_due, 0) - NVL(b.amount_settled, 0) > 0
                 --and TO_DATE(SYSDATE) = B.SCHEDULE_DUE_DATE - 1) ,
                 and SCHEDULE_DUE_DATE = GLOBAL.application_date + 1) TOTAL_AMOUNT_DUE,
             --sum(NVL(a.amount_due, 0) - NVL(a.amount_settled, 0)) TOTAL_AMOUNT_DUE,
             a.sch_status sch_status,
             --c.customer_id,
             D.CUSTOMER_ID
        FROM p1fchprfm.cltbs_account_schedules   a,
             p1fchprfm.cltms_product_components  b,
             p1fchprfm.cltbs_account_apps_master c,
             p1fchprfm.cltb_account_parties d
       WHERE a.account_number = c.account_number
         AND a.branch_code = c.branch_code
         AND b.product_code = c.product_code
         AND a.component_name = b.component_name
         AND NVL(b.comp_reporting_type, '#') <> 'PV'
            --and a.account_number = '9000317221'
            --and a.component_name in ('PRINCIPAL','MAIN_INT')
            --AND A.AMOUNT_DUE > 0
         AND NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) > 0
         --AND TO_DATE(SYSDATE) = A.SCHEDULE_DUE_DATE - 1 --THIS ONE
         AND A.SCHEDULE_DUE_DATE = TO_DATE(GLOBAL.application_date) + 1
            --AND A.SCHEDULE_DUE_DATE = TO_DATE(SYSDATE) - 2
         AND A.SCH_STATUS = 'NORM'
         AND C.ACCOUNT_STATUS = 'A'
         AND A.ACCOUNT_NUMBER = D.ACCOUNT_NUMBER
		 AND D.RESPONSIBILITY IN ('CBW','BRW')
       GROUP BY A.schedule_st_date,
                A.schedule_due_date,
                A.ACCOUNT_NUMBER,
                A.BRANCH_CODE,
                A.SETTLEMENT_CCY,
                A.sch_status,
                --c.customer_id,
                d.customer_id
       ORDER BY A.ACCOUNT_NUMBER, A.SCHEDULE_ST_DATE; --, component_name;

    PRAGMA AUTONOMOUS_TRANSACTION;

    PROCEDURE DBG(P_MSG VARCHAR2) IS
      L_MSG VARCHAR2(32767);
    BEGIN
      IF DEBUG.PKG_DEBUG_ON <> 2 THEN
        L_MSG := 'PR_LOAN_REPAY_PRE_DUE_ALERTS ==>' || P_MSG;
        DEBUG.PR_DEBUG('IF', L_MSG);
      END IF;
    END DBG;

    FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
      L_SEQ NUMBER;
      L_REF VARCHAR2(100);
    BEGIN

      SELECT TRSQ_LOANREPAY_ALERT_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;

      L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

      RETURN L_REF;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN FN_RETURN_SEQ_NO');
        DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
        DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
    END FN_RETURN_SEQ_NO;

  BEGIN

    GLOBAL.PR_INIT('000', 'SYSTEM');
    DEBUG.PR_DEBUG('AC', 'START OF PR_LOAN_REPAY_PRE_DUE_ALERTS');

    FOR G IN C1 LOOP

      BEGIN

        L_UNIQUE_SEQ_NO := FN_RETURN_SEQ_NO;

        --ENG
        L_REMINDER_ENG := FN_GET_REMINDER_MSG('EN', 'PRE');

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$L_DUE_MON',
                                  TO_CHAR(G.SCHEDULE_DUE_DATE, 'MM-YYYY'));

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$L_LOAN_NO',
                                  G.ACCOUNT_NUMBER);

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$L_CCY',
                                  G.SETTLEMENT_CCY);

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$P_AMT_DUE',
                                  TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.PRINCIPAL_AMOUNT_DUE, 0))));

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$I_AMT_DUE',
                                  TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.MAIN_INT_AMOUNT_DUE, 0))));

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$T_AMT_DUE',
                                  TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.TOTAL_AMOUNT_DUE, 0))));

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$L_DUE_DATE',
                                  TO_CHAR(G.SCHEDULE_DUE_DATE, 'DD-MM-YYYY'));

        --KH
        L_REMINDER_KH := FN_GET_REMINDER_MSG('KH', 'PRE');

        L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                                 '$L_DUE_MON',
                                 TO_CHAR(G.SCHEDULE_DUE_DATE, 'MM-YYYY'));

        L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                                 '$L_LOAN_NO',
                                 G.ACCOUNT_NUMBER);

        L_REMINDER_KH := REPLACE(L_REMINDER_KH, '$L_CCY', G.SETTLEMENT_CCY);

        L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                                 '$P_AMT_DUE',
                                 TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.PRINCIPAL_AMOUNT_DUE, 0))));

        L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                                 '$I_AMT_DUE',
                                 TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.MAIN_INT_AMOUNT_DUE, 0))));

        L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                                 '$T_AMT_DUE',
                                 TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.TOTAL_AMOUNT_DUE, 0))));

        L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                                 '$L_DUE_DATE',
                                 TO_CHAR(G.SCHEDULE_DUE_DATE, 'DD-MM-YYYY'));

        --CN
        L_REMINDER_CN := FN_GET_REMINDER_MSG('CH', 'PRE');

        L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                                 '$L_DUE_MON',
                                 TO_CHAR(G.SCHEDULE_DUE_DATE, 'MM-YYYY'));

        L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                                 '$L_LOAN_NO',
                                 G.ACCOUNT_NUMBER);

        L_REMINDER_CN := REPLACE(L_REMINDER_CN, '$L_CCY', G.SETTLEMENT_CCY);

        L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                                 '$P_AMT_DUE',
                                 TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.PRINCIPAL_AMOUNT_DUE, 0))));

        L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                                 '$I_AMT_DUE',
                                 TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.MAIN_INT_AMOUNT_DUE, 0))));

        L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                                 '$T_AMT_DUE',
                                 TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.TOTAL_AMOUNT_DUE, 0))));

        L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                                 '$L_DUE_DATE',
                                 TO_CHAR(G.SCHEDULE_DUE_DATE, 'DD-MM-YYYY'));

        INSERT INTO STTB_LOAN_REPAY_PRE_DUE_ALERT
          (UNIQUE_SEQ_NO,
           ACCOUNT_NUMBER,
           BRANCH_CODE,
           --  COMPONENT_NAME,
           SETTLEMENT_CCY,
           prin_amt_due, --PRINCIPAL_AMOUNT_DUE
           int_amt_due,

           total_amount_due,
           SCH_STATUS,
           SCHEDULE_ST_DATE,
           SCHEDULE_DUE_DATE,
           ALERT_DATE,
           IS_ALERT_SENT,
           REMINDER_ENG,
           REMINDER_KH,
           REMINDER_CN,
           CUSTOMER_ID)
        VALUES
          (L_UNIQUE_SEQ_NO,
           G.ACCOUNT_NUMBER,
           G.BRANCH_CODE,
           --  G.COMPONENT_NAME,
           G.SETTLEMENT_CCY,
           G.PRINCIPAL_AMOUNT_DUE,
           G.MAIN_INT_AMOUNT_DUE,

           G.total_amount_due,
           G.SCH_STATUS,
           G.SCHEDULE_ST_DATE,
           G.SCHEDULE_DUE_DATE,
           SYSDATE,
           'N',

           L_REMINDER_ENG,
           L_REMINDER_KH,
           L_REMINDER_CN,
           G.CUSTOMER_ID);

        COMMIT;

      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('AC',
                         'FAILED IN PROCESSING CURRENT UNIQUE SEQ NO=' ||
                         L_UNIQUE_SEQ_NO);

          DEBUG.PR_DEBUG('AC',
                         'FAILED IN PROCESSING CURRENT UNIQUE SEQ NO=' ||
                         DBMS_UTILITY.format_error_backtrace);

          DEBUG.PR_DEBUG('AC',
                         'FAILED IN PROCESSING CURRENT UNIQUE SEQ NO=' ||
                         SQLERRM);
          ROLLBACK;

          CONTINUE;

      END;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC',
                     'ERROR CODE IN PR_LOAN_REPAY_PRE_DUE_ALERTS=' ||
                     SQLCODE);
      DEBUG.PR_DEBUG('AC',
                     'ERROR MESSAGE IN PR_LOAN_REPAY_PRE_DUE_ALERTS=' ||
                     SQLCODE);

  END PR_LOAN_REPAY_PRE_DUE_ALERTS;

  PROCEDURE PR_LOAN_REPAY_POST_DUE_ALERTS(P_PARAM_NAMES VARCHAR2,
                                          P_PARAM_VALS  VARCHAR2) AS

    L_UNIQUE_SEQ_NO VARCHAR2(105);

    L_REMINDER_ENG VARCHAR2(255);
    L_REMINDER_KH  VARCHAR2(255);
    L_REMINDER_CN  VARCHAR2(255);

    --L_MESSAGE VARCHAR2(255) := 'Dear Valued customer, As we wouldn''t want anything to impact your Good Credit Score, We''d like to remind you that a payment of $L_AMOUNT_DUE $L_SETTLEMENT_CCY for loan account $L_LOAN_ACCOUNT_NO will be due by $L_SCHDULE_DUE_DATE. Regards, Prince Bank Plc';

    --L_REMINDER_ENG VARCHAR2(255) := 'Please be informed that your loan repayment is overdue! Please visit one of our nearest branches to settle your payment. The interest and penalty will be calculated based on your payment date.'; --Loan account --DD/MM/YYYY --USD/KHR --amount

    --L_REMINDER_KH VARCHAR2(255) := '?????? ??????? ?????????????? ?????????????????????????????????????????????????????! ????????????????????????????? ???????????????????????????????? ???????????????????????????????????? ???????????????? ?????????????? ??????????????? ???????????????????????????????????????????? ';

    --L_REMINDER_CN VARCHAR2(255) := '????????,?????????!?????????????????????????????????? ';

    CURSOR C1 IS
    /*  SELECT a.schedule_st_date schedule_st_date,
                                                                                                                                                                   a.schedule_due_date schedule_due_date,
                                                                                                                                                                   a.account_number account_number,
                                                                                                                                                                   a.branch_code branch_code,
                                                                                                                                                                   a.component_name component_name,
                                                                                                                                                                   a.settlement_ccy settlement_ccy,
                                                                                                                                                                   NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) AMOUNT_DUE,
                                                                                                                                                                   a.sch_status sch_status
                                                                                                                                                              FROM p1fchprfm.cltbs_account_schedules  a,
                                                                                                                                                                   p1fchprfm.cltms_product_components b,
                                                                                                                                                                   -- cltbs_account_master     c
                                                                                                                                                                   p1fchprfm.cltbs_account_apps_master c
                                                                                                                                                             WHERE a.account_number = c.account_number
                                                                                                                                                               AND a.branch_code = c.branch_code
                                                                                                                                                               AND b.product_code = c.product_code
                                                                                                                                                               AND a.component_name = b.component_name
                                                                                                                                                               AND NVL(b.comp_reporting_type, '#') <> 'PV'
                                                                                                                                                                  --and a.account_number = '9000317221'
                                                                                                                                                               and a.component_name in ('PRINCIPAL', 'MAIN_INT')
                                                                                                                                                                  --AND A.AMOUNT_DUE > 0
                                                                                                                                                               AND NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) > 0
                                                                                                                                                               AND TO_DATE(SYSDATE) = A.SCHEDULE_DUE_DATE - 2
                                                                                                                                                                  --AND A.SCHEDULE_DUE_DATE = TO_DATE(SYSDATE) - 2
                                                                                                                                                               AND A.SCH_STATUS = 'NORM'
                                                                                                                                                             ORDER BY A.ACCOUNT_NUMBER, A.SCHEDULE_ST_DATE;--, component_name;*/

      SELECT distinct a.schedule_st_date  schedule_st_date,
             a.schedule_due_date schedule_due_date,
             a.account_number    account_number,
             a.branch_code       branch_code,
             -- a.component_name component_name,
             a.settlement_ccy settlement_ccy,
             (select NVL(SUM(NVL(b.amount_due, 0) - NVL(b.amount_settled, 0)),0)
                from p1fchprfm.cltbs_account_schedules b
               where b.account_number = a.account_number
                 and b.component_name = 'PRINCIPAL'
                 --and TO_DATE(SYSDATE) = B.SCHEDULE_DUE_DATE - 1
                  and TO_DATE(GLOBAL.application_date) = B.SCHEDULE_DUE_DATE + 1) PRINCIPAL_AMOUNT_DUE,
                 --and B.SCHEDULE_DUE_DATE = GLOBAL.application_date + 1) PRINCIPAL_AMOUNT_DUE,
             (select NVL(SUM(NVL(b.amount_due, 0) - NVL(b.amount_settled, 0)),0)
                from p1fchprfm.cltbs_account_schedules b
               where b.account_number = a.account_number
                 and b.component_name = 'MAIN_INT'
                 --and TO_DATE(SYSDATE) = B.SCHEDULE_DUE_DATE - 1
                  and TO_DATE(GLOBAL.application_date) = B.SCHEDULE_DUE_DATE + 1) MAIN_INT_AMOUNT_DUE,
             (select NVL(SUM(NVL(b.amount_due, 0) - NVL(b.amount_settled, 0)),0)
                from p1fchprfm.cltbs_account_schedules b
               where b.account_number = a.account_number
                 and b.component_name IN ('MAIN_INT','PRINCIPAL')
                  AND NVL(b.amount_due, 0) - NVL(b.amount_settled, 0) > 0
                 --and TO_DATE(SYSDATE) = B.SCHEDULE_DUE_DATE - 1) ,
                --and TO_DATE(SYSDATE) = B.SCHEDULE_DUE_DATE - 1
                 and TO_DATE(GLOBAL.application_date) = B.SCHEDULE_DUE_DATE + 1) TOTAL_AMOUNT_DUE,
             --sum(NVL(a.amount_due, 0) - NVL(a.amount_settled, 0)) TOTAL_AMOUNT_DUE,
             a.sch_status sch_status,
             --c.customer_id,
             D.CUSTOMER_ID
        FROM p1fchprfm.cltbs_account_schedules   a,
             p1fchprfm.cltms_product_components  b,
             p1fchprfm.cltbs_account_apps_master c,
              p1fchprfm.cltb_account_parties d
       WHERE a.account_number = c.account_number
         AND a.branch_code = c.branch_code
         AND b.product_code = c.product_code
         AND a.component_name = b.component_name
         AND NVL(b.comp_reporting_type, '#') <> 'PV'
            --and a.account_number = '9000317221'
            --and a.component_name in ('PRINCIPAL','MAIN_INT')
            --AND A.AMOUNT_DUE > 0
         AND NVL(a.amount_due, 0) - NVL(a.amount_settled, 0) > 0
         --AND TO_DATE(SYSDATE) = A.SCHEDULE_DUE_DATE + 1
          and TO_DATE(GLOBAL.application_date) = A.SCHEDULE_DUE_DATE + 1
            --AND A.SCHEDULE_DUE_DATE = TO_DATE(SYSDATE) - 2
         AND A.SCH_STATUS = 'NORM'
         AND C.ACCOUNT_STATUS = 'A'
         AND A.ACCOUNT_NUMBER = D.ACCOUNT_NUMBER
		 AND D.RESPONSIBILITY IN ('CBW','BRW')
       GROUP BY A.schedule_st_date,
                A.schedule_due_date,
                A.ACCOUNT_NUMBER,
                A.BRANCH_CODE,
                A.SETTLEMENT_CCY,
                A.sch_status,
                --c.customer_id
                d.customer_id
       ORDER BY A.ACCOUNT_NUMBER, A.SCHEDULE_ST_DATE; --, component_name;

    PRAGMA AUTONOMOUS_TRANSACTION;

    PROCEDURE DBG(P_MSG VARCHAR2) IS
      L_MSG VARCHAR2(32767);
    BEGIN
      IF DEBUG.PKG_DEBUG_ON <> 2 THEN
        L_MSG := 'PR_LOAN_REPAY_POST_DUE_ALERTS ==>' || P_MSG;
        DEBUG.PR_DEBUG('IF', L_MSG);
      END IF;
    END DBG;

    FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
      L_SEQ NUMBER;
      L_REF VARCHAR2(100);
    BEGIN

      SELECT TRSQ_LOANREPAY_ALERT_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;

      L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

      RETURN L_REF;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN FN_RETURN_SEQ_NO');
        DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
        DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
    END FN_RETURN_SEQ_NO;

  BEGIN

    GLOBAL.PR_INIT('000', 'SYSTEM');
    DEBUG.PR_DEBUG('AC', 'START OF PR_LOAN_REPAY_POST_DUE_ALERTS');

    FOR G IN C1 LOOP
      DEBUG.PR_DEBUG('AC', 'APPLE');
      BEGIN

        L_UNIQUE_SEQ_NO := FN_RETURN_SEQ_NO;

        --ENG
        L_REMINDER_ENG := FN_GET_REMINDER_MSG('EN', 'POST');

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$L_LOAN_NO',
                                  G.ACCOUNT_NUMBER);

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$L_CCY',
                                  G.SETTLEMENT_CCY);

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$P_AMT_DUE',
                                  TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.PRINCIPAL_AMOUNT_DUE, 0))));

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$I_AMT_DUE',
                                  TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.MAIN_INT_AMOUNT_DUE, 0))));

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$T_AMT_DUE',
                                  TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.TOTAL_AMOUNT_DUE, 0))));

        L_REMINDER_ENG := REPLACE(L_REMINDER_ENG,
                                  '$L_DUE_DATE',
                                  G.SCHEDULE_DUE_DATE);

        --KH
        L_REMINDER_KH := FN_GET_REMINDER_MSG('KH', 'POST');

        L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                                 '$L_LOAN_NO',
                                 G.ACCOUNT_NUMBER);

        L_REMINDER_KH := REPLACE(L_REMINDER_KH, '$L_CCY', G.SETTLEMENT_CCY);

        L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                                 '$P_AMT_DUE',
                                 TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.PRINCIPAL_AMOUNT_DUE, 0))));

        L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                                 '$I_AMT_DUE',
                                 TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.MAIN_INT_AMOUNT_DUE, 0))));

        L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                                 '$T_AMT_DUE',
                                TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.TOTAL_AMOUNT_DUE, 0))));

        L_REMINDER_KH := REPLACE(L_REMINDER_KH,
                                 '$L_DUE_DATE',
                                 G.SCHEDULE_DUE_DATE);

        --CN
        L_REMINDER_CN := FN_GET_REMINDER_MSG('CH', 'POST');

        L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                                 '$L_LOAN_NO',
                                 G.ACCOUNT_NUMBER);

        L_REMINDER_CN := REPLACE(L_REMINDER_CN, '$L_CCY', G.SETTLEMENT_CCY);

        L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                                 '$P_AMT_DUE',
                                TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.PRINCIPAL_AMOUNT_DUE, 0))));

        L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                                 '$I_AMT_DUE',
                                 TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.MAIN_INT_AMOUNT_DUE, 0))));

        L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                                 '$T_AMT_DUE',
                                 TRIM(FN_GET_FORMATTED_AMOUNT(G.SETTLEMENT_CCY, NVL(G.TOTAL_AMOUNT_DUE, 0))));

        L_REMINDER_CN := REPLACE(L_REMINDER_CN,
                                 '$L_DUE_DATE',
                                 G.SCHEDULE_DUE_DATE);

        INSERT INTO STTB_LOAN_REPAY_POST_DUE_ALERT
          (UNIQUE_SEQ_NO,
           ACCOUNT_NUMBER,
           BRANCH_CODE,
           --  COMPONENT_NAME,
           SETTLEMENT_CCY,
           prin_amt_due, --PRINCIPAL_AMOUNT_DUE
           int_amt_due,

           total_amount_due,
           SCH_STATUS,
           SCHEDULE_ST_DATE,
           SCHEDULE_DUE_DATE,
           ALERT_DATE,
           IS_ALERT_SENT,
           REMINDER_ENG,
           REMINDER_KH,
           REMINDER_CN,
           CUSTOMER_ID)
        VALUES
          (L_UNIQUE_SEQ_NO,
           G.ACCOUNT_NUMBER,
           G.BRANCH_CODE,
           --  G.COMPONENT_NAME,
           G.SETTLEMENT_CCY,
           G.PRINCIPAL_AMOUNT_DUE,
           G.MAIN_INT_AMOUNT_DUE,

           G.total_amount_due,
           G.SCH_STATUS,
           G.SCHEDULE_ST_DATE,
           G.SCHEDULE_DUE_DATE,
           SYSDATE,
           'N',

           L_REMINDER_ENG,
           L_REMINDER_KH,
           L_REMINDER_CN,
           G.CUSTOMER_ID);

        DEBUG.PR_DEBUG('AC', 'INSERTED');
        COMMIT;

      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('AC',
                         'FAILED IN PROCESSING CURRENT UNIQUE SEQ NO=' ||
                         L_UNIQUE_SEQ_NO);
          ROLLBACK;

          CONTINUE;

      END;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC',
                     'ERROR CODE IN PR_LOAN_REPAY_POST_DUE_ALERTS=' ||
                     SQLCODE);
      DEBUG.PR_DEBUG('AC',
                     'ERROR MESSAGE IN PR_LOAN_REPAY_POST_DUE_ALERTS=' ||
                     SQLCODE);

  END PR_LOAN_REPAY_POST_DUE_ALERTS;

END STPKS_ALERT_UTILS;
