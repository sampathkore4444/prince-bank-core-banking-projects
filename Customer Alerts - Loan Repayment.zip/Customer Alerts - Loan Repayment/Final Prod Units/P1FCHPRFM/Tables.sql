create table STTB_NOTIF_LANG_TEMPLATE
(
  language      VARCHAR2(3),
  trigger_alert VARCHAR2(5),
  message       NVARCHAR2(255)
)
/
alter table STTB_NOTIF_LANG_TEMPLATE add primary key (LANGUAGE, TRIGGER_ALERT)
/
-- Create table
create table STTB_LOAN_REPAY_PRE_DUE_ALERT
(
  unique_seq_no           VARCHAR2(105),
  account_number          VARCHAR2(35),
  branch_code             VARCHAR2(35),
  settlement_ccy          VARCHAR2(3),
  prin_amt_due            NUMBER,
  int_amt_due             NUMBER,
  total_amount_due        NUMBER,
  sch_status              VARCHAR2(4),
  schedule_st_date        DATE,
  schedule_due_date       DATE,
  alert_date              TIMESTAMP(6),
  is_alert_sent           CHAR(1) default 'N',
  reminder_eng            VARCHAR2(255),
  alert_sent_time_to_cust DATE,
  reminder_kh             VARCHAR2(1000),
  reminder_cn             VARCHAR2(1000),
  customer_id             VARCHAR2(35)
)
/
alter table STTB_LOAN_REPAY_PRE_DUE_ALERT add primary key (UNIQUE_SEQ_NO, ACCOUNT_NUMBER, BRANCH_CODE, SETTLEMENT_CCY, CUSTOMER_ID)
/
-- Create table
create table STTB_LOAN_REPAY_POST_DUE_ALERT
(
  unique_seq_no           VARCHAR2(105) not null,
  account_number          VARCHAR2(35) not null,
  branch_code             VARCHAR2(35) not null,
  settlement_ccy          VARCHAR2(3) not null,
  prin_amt_due            NUMBER,
  int_amt_due             NUMBER,
  total_amount_due        NUMBER,
  sch_status              VARCHAR2(4),
  schedule_st_date        DATE,
  schedule_due_date       DATE,
  alert_date              TIMESTAMP(6),
  is_alert_sent           CHAR(1) default 'N',
  reminder_eng            VARCHAR2(255),
  alert_sent_time_to_cust DATE,
  reminder_kh             VARCHAR2(1000),
  reminder_cn             VARCHAR2(1000),
  customer_id             VARCHAR2(35)
)
/
alter table STTB_LOAN_REPAY_POST_DUE_ALERT add primary key (UNIQUE_SEQ_NO, ACCOUNT_NUMBER, BRANCH_CODE, SETTLEMENT_CCY, CUSTOMER_ID)
/
--Grant below in P1
GRANT READ, SELECT, UPDATE ON STTB_LOAN_REPAY_PRE_DUE_ALERT TO FCCNDG
/
GRANT READ, SELECT, UPDATE ON STTB_LOAN_REPAY_POST_DUE_ALERT TO FCCNDG
/
--Create below views in FCCNDG
CREATE OR REPLACE VIEW STVW_LOAN_REPAY_PRE_DUE_ALERT AS SELECT * FROM P1FCHPRFM.STTB_LOAN_REPAY_PRE_DUE_ALERT;
/
CREATE OR REPLACE VIEW STVW_LOAN_REPAY_POST_DUE_ALERT AS SELECT * FROM P1FCHPRFM.STTB_LOAN_REPAY_POST_DUE_ALERT;
/