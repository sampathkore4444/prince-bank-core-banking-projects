-- Create sequence 
create sequence TRSQ_LOANREPAY_ALERT_SEQID
minvalue 1
maxvalue 999999999
start with 1
increment by 1
nocache
cycle;
