prompt Importing table lmtm_type_values...
set feedback off
set define off
insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSBLD_INS_FEE_K', 'LONG_TERM_PLAN', '200000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSBLD_INS_FEE_K', 'SHORT_TERM_PLAN', '120000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSBLD_INS_FEE_U', 'LONG_TERM_PLAN', '50');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSBLD_INS_FEE_U', 'SHORT_TERM_PLAN', '30');

prompt Done.
