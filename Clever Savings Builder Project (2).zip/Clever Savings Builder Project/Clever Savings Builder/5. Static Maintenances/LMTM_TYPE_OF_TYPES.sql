prompt Importing table LMTM_TYPE_OF_TYPES...
set feedback off
set define off
insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CSBLD_INS_FEE_K', 'Clever Savings Builder plan Insurance Fee in KHR', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 08:36:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 08:36:49', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CSBLD_INS_FEE_U', 'Clever Savings Builder plan Insurance Fee in USD', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 08:38:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 08:38:46', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

prompt Done.
