insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CSBLD_INS_FEE_U', 'Clever Savings Builder plan Insurance Fee in USD', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 08:38:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 08:38:46', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CSB_TOPUP_USD', 'Clever Savings Builder Minimum Top Up Amount in USD Amount', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 08:47:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 08:47:41', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CSB_TOPUP_KHR', 'Clever Savings Builder Minimum Top Up Amount in KHR Amount', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 08:48:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 08:48:05', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CSB_SAV_DEP_US_F', 'Clever Savings Builder Initial Deposit in USD', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 08:37:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 08:37:36', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CSB_SAV_DEP_KH_F', 'Clever Savings Builder Initial Deposit in KHR', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 08:38:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 08:38:08', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CSB_TOPUP_USD_F', 'Clever Savings Builder Minimum Top Up Amount in USD Amount', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 08:47:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 08:47:22', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CSBLD_INS_FEE_K', 'Clever Savings Builder plan Insurance Fee in KHR', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 08:36:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 08:36:49', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

COMMIT;
