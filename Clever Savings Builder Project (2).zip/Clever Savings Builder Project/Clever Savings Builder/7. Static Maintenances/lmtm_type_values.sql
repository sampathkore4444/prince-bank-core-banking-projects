insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSBLD_INS_FEE_K', 'SHORT_TERM_PLAN', '120000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSBLD_INS_FEE_K', 'LONG_TERM_PLAN', '200000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSBLD_INS_FEE_U', 'LONG_TERM_PLAN', '50');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSBLD_INS_FEE_U', 'SHORT_TERM_PLAN', '30');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSB_SAV_DEP_KH_F', '1Y_PLAN', '4800000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSB_SAV_DEP_KH_F', '2Y_PLAN', '400000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSB_SAV_DEP_US_F', '2Y_PLAN', '100');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSB_SAV_DEP_US_F', '1Y_PLAN', '1200');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSB_TOPUP_KHR', '1Y_PLAN', '400000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSB_TOPUP_KHR', '2Y_PLAN', '400000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSB_TOPUP_USD', '1Y_PLAN', '100');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSB_TOPUP_USD', '2Y_PLAN', '100');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSB_TOPUP_USD_F', '1Y_PLAN', '100');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CSB_TOPUP_USD_F', '2Y_PLAN', '100');

COMMIT;
