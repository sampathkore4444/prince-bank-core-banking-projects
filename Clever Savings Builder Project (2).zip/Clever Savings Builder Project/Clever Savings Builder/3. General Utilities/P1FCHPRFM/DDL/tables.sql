-- Create table
create table IFTB_CSB_SAV_PUSH_NOTIFICATION
(
  customer_no VARCHAR2(9) not null,
  cust_ac_no  VARCHAR2(20) not null,
  ccy         VARCHAR2(3) not null,
  branch_code VARCHAR2(3) not null,
  action_code VARCHAR2(100) not null,
  status      CHAR(1),
  timestamp   DATE
)
/
alter table IFTB_CSB_SAV_PUSH_NOTIFICATION add primary key (CUSTOMER_NO, CUST_AC_NO, CCY, BRANCH_CODE, ACTION_CODE)
/
-- Create table
create table IFTB_PUSH_NOTIF_CSB_LOG
(
  cust_no     VARCHAR2(12) not null,
  action_code VARCHAR2(25) not null,
  content     VARCHAR2(3500),
  time_sent   DATE not null,
  acc         VARCHAR2(25) not null
)
/
alter table IFTB_PUSH_NOTIF_CSB_LOG add primary key (CUST_NO, ACTION_CODE, ACC, TIME_SENT)
/
-- Create table
create table IFTB_TD_TOPUP_SCHEDULES_CSB_SAV
(
  acc                 VARCHAR2(20) not null,
  brn                 VARCHAR2(3) not null,
  ccy                 VARCHAR2(3) not null,
  due_date            DATE,
  due_date_with_grace DATE,
  auto_topup_amt      NUMBER,
  principal_bal       NUMBER
)
/
alter table IFTB_TD_TOPUP_SCHEDULES_CSB_SAV add primary key (ACC, BRN, CCY)
/