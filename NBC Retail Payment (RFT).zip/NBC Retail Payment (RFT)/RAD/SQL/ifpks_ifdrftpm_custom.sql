CREATE OR REPLACE PACKAGE BODY ifpks_ifdrftpm_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdrftpm_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdrftpm_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;

  FUNCTION fn_enrich_product(p_ifdrftpm   IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
    l_serial_no    VARCHAR2(16);
    l_trn_ref_no   iftb_rft_master.trn_ref_no%TYPE;
    l_ty_rtupld    depks_retailtellerupload.typ_retailtellerupld_rec;
    l_ret          BOOLEAN;
    l_tot_chg_amt  NUMBER(22, 3);
    l_rel_customer sttm_customer.customer_no%TYPE;
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_ib_flag      VARCHAR2(1) DEFAULT 'Y';
    l_arc_maint    iftm_arc_maint%ROWTYPE;
    l_prod         cstm_product%ROWTYPE;
    l_rate         NUMBER;
    l_charge_amt   NUMBER := 0;
    l_rate_flag    NUMBER;
    l_ccy1         iftb_rft_master.txn_ccy%TYPE;
    l_ccy2         iftb_rft_master.txn_ccy%TYPE;
  
    l_tot_chg_amount            iftb_rft_master.net_txn_amt%TYPE;
    l_txn_amt                   iftb_rft_master.txn_amt%TYPE;
    l_txn_amt1                  iftb_rft_master.txn_amt%TYPE;
    l_rate_code                 cstm_product.rate_code_preferred%Type;
    l_rate_code1                cstm_product.rate_code_preferred%Type;
    l_tot_chg_amt_in_txn_ccy    iftb_rft_master.txn_amt%TYPE;
    l_tot_chg_amt_in_lcy_ccy    iftb_rft_master.txn_amt%TYPE;
    l_arc_rate_code_type        iftm_arc_maint.cod_rate_code%Type;
    l_tot_chg_amount_in_txn_ccy iftb_rft_master.txn_amt%TYPE;
    l_tot_chg_amount_in_acc_ccy iftb_rft_master.txn_amt%TYPE;
    L_STTB_ACCOUNT              STTB_ACCOUNT%ROWTYPE;
    L_STTM_CUST_ACCOUNT         STTM_CUST_ACCOUNT%ROWTYPE;
  BEGIN
  
    dbg('In FN_ENRICH_PRODUCT');
    --dbg('p_Action_Code' || p_action_code);
  
    -- mandatory check
    IF p_ifdrftpm.v_iftbs_rft_master.msg_flow = 'O' THEN
    
      --Get Account details
      BEGIN
        SELECT *
          INTO L_STTB_ACCOUNT
          FROM STTB_ACCOUNT
         WHERE AC_GL_NO = p_ifdrftpm.v_iftbs_rft_master.rem_acc;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_STTB_ACCOUNT := NULL;
          DBG('FAILED IN GETTING ACCOUNT DETAILS');
      END;
    
      --Get Account details
      BEGIN
        SELECT *
          INTO L_STTM_CUST_ACCOUNT
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = p_ifdrftpm.v_iftbs_rft_master.rem_acc;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_STTM_CUST_ACCOUNT := NULL;
          DBG('FAILED IN GETTING ACCOUNT DETAILS');
      END;
    
      IF L_STTB_ACCOUNT.AC_STAT_DORMANT = 'Y' THEN
        dbg('Account Status is Dormant');
        p_err_code   := 'AC-VAC33';
        p_err_params := 'Status';
        RETURN FALSE;
      END IF;
    
      IF L_STTB_ACCOUNT.AC_STAT_NO_DR = 'Y' THEN
        dbg('Account Status is No Debit');
        p_err_code   := 'AC-VAC07';
        p_err_params := 'Status';
        RETURN FALSE;
      END IF;
    
      IF L_STTM_CUST_ACCOUNT.RECORD_STAT = 'C' THEN
        dbg('Account is Closed');
        p_err_code   := 'AC-VAC12';
        p_err_params := L_STTM_CUST_ACCOUNT.CUST_AC_NO;
        RETURN FALSE;
      END IF;
    
      IF L_STTB_ACCOUNT.AC_STAT_FROZEN = 'Y' THEN
        dbg('Account Status is Frozen');
        p_err_code   := 'AC-VAC04';
        p_err_params := 'Status';
        RETURN FALSE;
      END IF;
    
      IF p_ifdrftpm.v_iftbs_rft_master.product_code IS NULL THEN
        dbg('Mandatory Field Product Code cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Product Code';
        RETURN FALSE;
      END IF;
      IF p_ifdrftpm.v_iftbs_rft_master.txn_ccy IS NULL THEN
        dbg('Mandatory Fields Transaction Currency cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Transaction Currency';
        RETURN FALSE;
      END IF;
      IF p_ifdrftpm.v_iftbs_rft_master.txn_amt IS NULL THEN
        dbg('Mandatory Fields Transaction Amount cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Transaction Amount';
        RETURN FALSE;
      END IF;
      IF p_ifdrftpm.v_iftbs_rft_master.rem_acc IS NULL THEN
        dbg('Mandatory Fields Remitter Account cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Remitter Account';
        RETURN FALSE;
      END IF;
    END IF;
  
    -- reference no
    IF p_ifdrftpm.v_iftbs_rft_master.trn_ref_no IS NULL THEN
      IF NOT trpkss.fn_get_product_refno(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                         p_ifdrftpm.v_iftbs_rft_master.product_code,
                                         p_ifdrftpm.v_iftbs_rft_master.transfer_date,
                                         l_serial_no,
                                         l_trn_ref_no,
                                         p_err_code) THEN
        dbg('Failed in generation Transaction Ref No');
        RETURN FALSE;
      ELSE
        dbg('l_trn_ref_no=' || l_trn_ref_no);
        p_ifdrftpm.v_iftbs_rft_master.trn_ref_no := l_trn_ref_no;
      
      END IF;
    END IF;
  
    dbg('got l_rel_customer' || l_rel_customer);
  
    dbg('Returning Success From FN_ENRICH_PRODUCT..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.FN_ENRICH_PRODUCT ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_enrich_product;

  FUNCTION FN_SERVICE_CHARGE_PICKUP(P_SOURCE           IN VARCHAR2,
                                    P_SOURCE_OPERATION IN VARCHAR2,
                                    P_FUNCTION_ID      IN VARCHAR2,
                                    P_ACTION_CODE      IN VARCHAR2,
                                    P_POST_UPL_STAT    IN VARCHAR2,
                                    P_KEY_ID           IN VARCHAR2,
                                    p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.ty_ifdrftpm,
                                    P_ERR_CODE         IN OUT VARCHAR2,
                                    P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_ACTION         VARCHAR2(1);
    L_WRK_ARC_CHGS   IFTM_ARC_MAINT%ROWTYPE;
    L_CHG_CCY        VARCHAR2(3);
    L_CHG_AMT        NUMBER(22, 3);
    L_PROD           VARCHAR2(6);
    L_ARC_MAINT      IFTMS_ARC_MAINT%ROWTYPE;
    L_TBL_CHGDETS    TYP_TBLCHGDETS;
    L_ACTUAL_COUNT   NUMBER := 0;
    L_CUST_AC_NO     CATMS_STOP_PAYMENTS.ACCOUNT%TYPE;
    L_FLAG           VARCHAR2(30);
    L_CHARGE_APPLIED VARCHAR2(1) := 'N';
  
    L_AUTH_STAT   ACTBS_DAILY_LOG.AUTH_STAT%TYPE;
    L_DELETE_STAT ACTBS_DAILY_LOG.DELETE_STAT%TYPE;
    L_TRN_REF_NO  IFTB_RFT_MASTER.TRN_REF_NO%TYPE;
    L_TANK        SMTBS_MENU.TANK_MODIFICATIONS%TYPE;
  
  BEGIN
    DBG('Inside fn_service_charge_pickup');
    DBG('Setting Actions');
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
      L_ACTION := 'N';
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      L_ACTION := 'M';
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      L_ACTION := 'A';
    ELSIF P_ACTION_CODE = 'CHGPKUP' THEN
      DBG('p_action_code-->' || P_ACTION_CODE);
      IF NVL(p_Wrk_ifdrftpm.v_iftbs_rft_master.MOD_NO, 1) = 1 THEN
      
        L_ACTION := 'N';
      
      ELSIF NVL(p_Wrk_ifdrftpm.v_iftbs_rft_master.MOD_NO, 1) > 1 THEN
        L_ACTION := 'M';
      END IF;
    
    END IF;
  
    L_CUST_AC_NO := p_Wrk_ifdrftpm.v_iftbs_rft_master.REM_ACC;
  
    L_FLAG := GWPKSS_UTIL.G_MSGTYPE;
  
    GWPKSS_UTIL.G_MSGTYPE := 'X';
    IF P_ACTION_CODE = 'CHGPKUP' THEN
      DBG('setting act type to sc auto auth');
      CSPKS_CHARGE.G_CHARGE_PICKED := 'N';
    END IF;
  
    SELECT NVL(TANK_MODIFICATIONS, 'N')
      INTO L_TANK
      FROM SMTBS_MENU
     WHERE FUNCTION_ID = P_FUNCTION_ID;
  
    IF NOT CSPKS_CHARGE.FN_COMPUTE_CHARGE(P_SOURCE,
                                          P_FUNCTION_ID,
                                          P_ACTION_CODE,
                                          L_ACTION,
                                          
                                          P_KEY_ID,
                                          
                                          'Y',
                                          
                                          p_Wrk_ifdrftpm.v_iftbs_rft_master.BRANCH_CODE,
                                          p_Wrk_ifdrftpm.v_iftbs_rft_master.BRANCH_CODE,
                                          L_CUST_AC_NO,
                                          P_POST_UPL_STAT,
                                          p_Wrk_ifdrftpm.v_iftbs_rft_master.TRN_REF_NO,
                                          p_Wrk_ifdrftpm.TY_CSCONCHG,
                                          P_ERR_CODE,
                                          P_ERR_PARAMS) THEN
      DBG('Failed inside cspks_charge.fn_compute_charge.');
    
      DBG('p_err_code' || P_ERR_CODE);
      DBG('p_err_params' || P_ERR_PARAMS);
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    
    END IF;
  
    DBG('Returning success from fn_service_charge_pickup');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in fn_service_charge_pickup');
      P_ERR_CODE   := 'CS-CHG-003';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END;

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdrftpm         IN OUT ifpks_ifdrftpm_Main.ty_ifdrftpm,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of ifpks_ifdrftpm_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdrftpm         IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    dbg('In Fn_Pre_Check_Mandatory' || p_action_code);
    IF p_action_code = 'PICKUP' THEN
      IF NOT fn_enrich_product(p_ifdrftpm, p_err_code, p_err_params) THEN
        dbg('Failed in Fn_Enrich_Product');
        RETURN FALSE;
      END IF;
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdrftpm         IN ifpks_ifdrftpm_Main.ty_ifdrftpm,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdrftpm         IN ifpks_ifdrftpm_Main.ty_ifdrftpm,
                                       p_Prev_ifdrftpm    IN OUT ifpks_ifdrftpm_Main.ty_ifdrftpm,
                                       p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.ty_ifdrftpm,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdrftpm         IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                        p_Prev_ifdrftpm    IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                        p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdrftpm         IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                            p_Prev_ifdrftpm    IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                            p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_KEY_ID VARCHAR2(1000);
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..='||p_Action_Code);
    
    IF p_Action_Code = 'CHGPKUP' THEN
    
    L_KEY_ID := '~' || p_Wrk_ifdrftpm.v_iftbs_rft_master.TRN_REF_NO || '~';
    DBG('key_id for service charge-->' || L_KEY_ID);
  
    IF NOT FN_SERVICE_CHARGE_PICKUP(P_SOURCE,
                                    P_SOURCE_OPERATION,
                                    P_FUNCTION_ID,
                                    P_ACTION_CODE,
                                    P_POST_UPL_STAT,
                                    L_KEY_ID,
                                    p_Wrk_ifdrftpm,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
      DBG('Failed inside fn_service_chargepickup');
    
      DBG('p_err_code' || P_ERR_CODE);
      DBG('p_err_params' || P_ERR_PARAMS);
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    
    END IF;
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdrftpm         IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                             p_prev_ifdrftpm    IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                             p_wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdrftpm         IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                        p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdrftpm         IN ifpks_ifdrftpm_Main.ty_ifdrftpm,
                         p_wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.ty_ifdrftpm,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Query..');
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of ifpks_ifdrftpm_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END ifpks_ifdrftpm_custom;
