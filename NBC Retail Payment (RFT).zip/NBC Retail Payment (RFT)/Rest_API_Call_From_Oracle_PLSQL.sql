DECLARE
  req     utl_http.req;
  res     utl_http.resp;
  url     varchar2(4000) := 'http://10.80.80.120:8080/pcore/api/v1.0.0/do-retrieve-account';
  name    varchar2(4000);
  buffer  varchar2(4000);
  content varchar2(4000) := '{
"partnerId": "WNG001",
"transactionKindCode": "ACC01",
"channelCode": "01",
"accountNo": "000270620"
}';

begin
  req := utl_http.begin_request(url, 'POST', ' HTTP/1.1');
  utl_http.set_authentication( req, 'prince','prince@digitalbanking', 'Basic' );
  utl_http.set_header(req, 'user-agent', 'mozilla/4.0');
  utl_http.set_header(req, 'content-type', 'application/json');
  utl_http.set_header(req, 'Content-Length', length(content));

  utl_http.write_text(req, content);
  res := utl_http.get_response(req);
  -- process the response from the HTTP call
  begin
    loop
      utl_http.read_line(res, buffer);
      dbms_output.put_line(buffer);
    end loop;
    utl_http.end_response(res);
  exception
    when utl_http.end_of_body then
      utl_http.end_response(res);
  end;
end publish_cinema_event;
