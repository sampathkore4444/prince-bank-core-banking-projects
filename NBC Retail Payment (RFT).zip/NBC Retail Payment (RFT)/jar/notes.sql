$ export ORACLE_HOME=/scratch/oracle/app/oracle/product/11.2.0/dbhome_1

loadjava -user P1FCHPRFM/P1FCHPRFM@10.80.80.78:1521/TECHSEA PRINCE_JSON_UTILITY.jar
/
CREATE OR REPLACE AND COMPILE JAVA SOURCE NAMED "jsonToXMLUtility" AS
  import java.io.*;
  import org.json.*;
  public class jsonToXMLUtility {
	
   public static String convertJSONTOXML(String json) throws JSONException {
      JSONObject jsonObject = new JSONObject(json);
	  String root = "root";
      String xml = "<?xml version=\"1.0\" encoding=\"ISO-8859-15\"?>\n<"+root+">" + XML.toString(jsonObject) + "</"+root+">";
      return xml;
   }
}
/
CREATE OR REPLACE PACKAGE IFPKS_PRINCE_JSON_UTILITY AS

   FUNCTION jsonToXMLUtility(p_json IN STRING) RETURN VARCHAR2;

END IFPKS_PRINCE_JSON_UTILITY;
/
CREATE OR REPLACE PACKAGE BODY IFPKS_PRINCE_JSON_UTILITY AS

  FUNCTION jsonToXMLUtility(p_json IN STRING) RETURN varchar2 IS
    LANGUAGE JAVA NAME 'jsonToXMLUtility.convertJSONTOXML(java.lang.String) return CLOB';

END IFPKS_PRINCE_JSON_UTILITY;
/

https://www.akadia.com/services/java_mail_plsql.html  (Very Important)
https://vijayatech.in/loadjava-loading-java-sourcesclassesjars-into-oracle-database/


DECLARE
  req     utl_http.req;
  res     utl_http.resp;
  url     varchar2(4000) := 'http://10.80.80.11:8282/prnc-app/nbc/rft-out/crt-pass-code';
  name    varchar2(4000);
  buffer  varchar2(32767);
  buffer1  varchar2(32767);
  buffer2  clob;
  content varchar2(4000) := '{
    "sndNm": "borey",
    "sndPhone": "061440102",
    "rcvNm": "jshdhs",
    "rcvPhone": "061440102",
    "crrcy": "KHR",
    "amt": "12121"
}';

begin
  --req := utl_http.begin_request(url);
  req := utl_http.begin_request(url, 'POST', ' HTTP/1.1');
  --utl_http.set_authentication( req, '','', '' );
  utl_http.set_header(req, 'user-agent', 'mozilla/4.0');
  utl_http.set_header(req, 'content-type', 'application/json');
  utl_http.set_header(req, 'Content-Length', length(content));
  
  --UTL_HTTP.SET_BODY_CHARSET('UTF-8');

  utl_http.write_text(req, content);
  
  UTL_HTTP.WRITE_RAW (req,
                    UTL_RAW.CAST_TO_RAW(content));
                    
  res := utl_http.get_response(req);

  -- process the response from the HTTP call
  begin
    loop
      utl_http.read_line(res, buffer);
      --dbms_output.put_line(buffer);
      buffer1 := buffer1 || buffer;
    end loop;
    utl_http.end_response(res);
  exception
    when utl_http.end_of_body then
      utl_http.end_response(res);
    when others then
      dbms_output.put_line('ERROR CODE='||SQLCODE);
      dbms_output.put_line('ERROR MESSAGE='||SQLERRM);
  end;
  
  dbms_output.put_line(buffer1);
  
  buffer2 := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(buffer1);
  dbms_output.put_line('buffer2='||buffer2);
  
end;
