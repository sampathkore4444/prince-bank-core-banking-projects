import java.io.*;
import org.json.*;
public class jsonToXMLUtility {
	
   public static String convertJSONTOXML(String json) throws JSONException {
      JSONObject jsonObject = new JSONObject(json);
	  String root = "root";
      String xml = "<?xml version=\"1.0\" encoding=\"ISO-8859-15\"?>\n<"+root+">" + XML.toString(jsonObject) + "</"+root+">";
      return xml;
   }
}