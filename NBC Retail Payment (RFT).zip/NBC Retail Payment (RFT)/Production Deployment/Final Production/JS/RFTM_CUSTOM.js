function fnPopulateTXNCCY(){
console.log('currency='+document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD43").value);
document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value = document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD43").value;
document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD43").value;
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY"));
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY"));
return true;

}
function fnPopulateTXNAMT(){
console.log('Amount='+document.getElementById("BLK_TRANSACTION_DETAILS__NUM_FIELD25").value);
console.log('Amount='+document.getElementById("BLK_TRANSACTION_DETAILS__NUM_FIELD25I").value);
//document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMTI").value = document.getElementById("BLK_TRANSACTION_DETAILS__NUM_FIELD25I").value;
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMTI"));
return true;

}