function fnPostEnterQuery_CUSTOM()
{
  console.log('apple');
  fnEnableElement(document.getElementById('BLK_TXN_DETAILS__DATE_FIELD1'));
  return true;
}

function fnPostLoad_CUSTOM()
{
  console.log('mango');
  fnEnableElement(document.getElementById('BLK_TXN_DETAILS__DATE_FIELD1'));
  return true;
}
