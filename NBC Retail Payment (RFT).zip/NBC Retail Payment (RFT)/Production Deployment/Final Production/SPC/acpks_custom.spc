create or replace package acpks_custom as
   /*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © 2007 - 2016  Oracle and/or its affiliates.  All rights reserved.
**
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
**
**
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
---------------------------------------------------------------------------------------------------
  -- Author  : Anuradha.H
  -- Created : 04-Mar-2010
  -- Purpose : Extensible hooks for acpks

   CHANGE HISTORY
Changed By/Retroed By         : Revathy Vijayan/Priyanka Kukshal
    Change Description : Provided extensible layers to function fn_updatecustbal
    Search string      : Bug#16181210
   Changed By         : Revathy Vijayan
    Change Description : Provided extensible layers to function fn_achandoff
    Search string      : Bug#16326536

    Changed By         : Priyanka Kukshal
    Change Description : Provided extensible layers to function fn_acservice1 for fund management
    Modified On       : 10-May-2013
    Search string      : INTERNAL_16786447

   Changed by         : VijayRe
     Changed On         : 13-Sep-2013
     Change Description : Extensibility hooks provided againt bug#16975795
     Search String      : INTERNAL_17454753
   Retro Ref          : FC12.0.1_16975795

   Changed by          : VijayRe
     Changed On          : 13-Sep-2013
     Change Description  : Extensibility hooks provided againt bug#17204384
     Search String       : INTERNAL_17454798
   Retro Ref           : ISMEMYR_12.0.1_17204384

   Changed by          : Viba R
   Changed On          : 18-Nov-2013
     Change Description  : Hooks changes retro
   Search string       : 9NT1606_FCUBS12.0.2_RETRO_17815862  Changes

    Changed by          : Giridhar C
   Changed On          : 02-Apr_2014
     Change Description  : Extensible Hooks Provided.
   Search string       :IPTBCIDR_18495397

      Modified By           : Giridhar C
    Modified On           : 17-June-2014
    Modified Reason       : Reverted the change as apart of bug19022272 and moved the hook functions to acpks_misc
    Search String         : INTERNAL_19022272


    Modified By           : Soujanya V
    Retroed By/On         : Soujanya V/22-July-2014
    Modified On           : 28-March-2014
    Modified Reason       : Required hooks in the package acpks for the function FN_RESOLVE_IB
    Search String         : RETRO_18837039_12.0.3

      Retroed By/On         : Sharmila Sree G M/07-NOV-2014
      Modified By           : Arpita Gupta
     Modified On           : 09-Oct-2014
     Modified Reason       : Hooks provided for capturing custom accounting details
    Search String         : Retro_19434403
    Retro Ref                :19418836

    Modified By           : Arpita Gupta
    Modified On           : 17-Dec-2014
    Modified Reason       : Extensible Hooks Provided
    Search String         : Retro_20221350
    Retro Ref             : 17461665

    Modified By           : Arpita Gupta
    Modified On           : 29-May-2015
    Modified Reason       : Extensible Hooks Provided
    Search String         : Retro_21113419
    Retro Ref             : 21025733

  Modified By        : Saisudha Rathinavelu
    Modified On        : 12-Sep-2016
    Modified Reason    : Retro for hook change bug id 22763450.
    Search String      : 12.2_RETRO_Bug#23658293

  Modified By       : Karthik P
  Modified On       : 19-Sep-2016
  Modified Reason   : Retro Added overloaded function fn_acservice1 with related account and basis flag as additional parameters
  Search String     : SFR#23654876

  Modified By           : Dekyi
  Modified On           : 21-Sept-2016
  Modified Reason       : Hook Provided
  Search String         : Bug#23651516
  **
  **  Modified By       : Thiru
  **  Modified On       : 04-Aug-2016
  **  Modified Reason   : Fast Accoutning-Deferred Accounting Changes
  **  Search String     : FA-DA
  **

Modified By        : Saisudha Rathinavelu
Modified On        : 07-Oct-2016
Modified Reason    : Retro for hook change bug id 21245547.
Search String      : 12.2_RETRO_Bug#23656114

Modified By        : Saisudha Rathinavelu
Modified On        : 07-Oct-2016
Modified Reason    : Retro for hook change bug id 24813209.
Search String      : 12.2_RETRO_Bug#24814470

Modified By         : Saisudha Rathinavelu
Modified On         : 21-Dec-2016
Modified Reason     : Provided Extensible hooks.
Search String       : Bug#25296066

Modified By        : Saisudha Rathinavelu
Modified On        : 16-Mar-2017
Modified Reason    : Retro for hook change bug id 25296066.
Search String      : 12.3_RETRO_Bug#25436132

**   Modified By    : Saurabh Sarawagi
**   Changed On     : 30-Aug-2017
**   Description    : provided hook changes(Retro for Bug#26368301)
**   Search string  : Bug#26550111

Modified By    : Akshada Muneshwar
Changed On     : 10-Nov-2017
Description    : Forward Porting Done For BUG#18220684
Search string  : Bug #27081489
**
** Modified By           : Dekyi
** Modified On           : 13-Mar-2018
** Modified Reason       : EHD Ref: CITI124_12.4_10_JAN_2018_01_0000
** Search String         : 12.4_EXTN_27675980
**
** Modified By           : Dekyi
** Modified On           : 21-May-2018
** Modified Reason       : EHD Ref: UNCRBG_12.4_23_APR_2018_01_0000
** Search String         : Bug#28053371

** Modified By         : Dekyi
** Modified On           : 15-May-2019
** Modified Reason       : EHD Ref: BMOCH_12.4._15_NOV_2018_01_0000
** Search String         : 12.4_EXTN_29783125

** Modified By         : Kore Sampath Kumar
  ** Modified On           : 15-July-2020
  ** Modified Reason       : NBC RFT Changes
  ** Search String         : NBC RFT Changes
  
   -------------------------------------------------------------------------------------------------------
   */


   --sampath starts
  FUNCTION FN_ACENTRY_RETRIEVAL_CUSTOM(PTRNREFNO   IN ACVWS_ALL_AC_ENTRIES.TRN_REF_NO%TYPE,
                                PEVENTSEQNO IN ACVWS_ALL_AC_ENTRIES.EVENT_SR_NO%TYPE,
                                PACENTS     OUT ACPKS.TBL_ACHOFF)
    RETURN NUMBER;
  --sampath ends
  
  --NBC RFT Changes Starts

  FUNCTION FN_ACENTRY_RETRIEVAL_RFT(PTRNREFNO   IN ACVWS_ALL_AC_ENTRIES.TRN_REF_NO%TYPE,
                                    PEVENTSEQNO IN ACVWS_ALL_AC_ENTRIES.EVENT_SR_NO%TYPE,
                                    PACENTS     OUT ACPKS.TBL_ACHOFF)
  
   RETURN NUMBER;
  --NBC RFT Changes Ends

  FUNCTION fn_pre_updatecustbal_check(p_err_code  IN OUT VARCHAR2,
                                      p_err_param IN OUT VARCHAR2)
    RETURN NUMBER;

  FUNCTION fn_post_updatecustbal_check(p_err_code  IN OUT VARCHAR2,
                                       p_err_param IN OUT VARCHAR2)
    RETURN NUMBER;

  FUNCTION fn_pre_updatecustbal(pbranch     IN actbs_handoff.ac_branch%TYPE,
                                paccount    IN actbs_handoff.ac_no%TYPE,
                                paclass     IN sttbs_account.ac_class%TYPE,
                                ptrnrefno   IN actbs_handoff.trn_ref_no%TYPE,
                                paccccy     IN actbs_handoff.ac_ccy%TYPE,
                                plcyamt     IN actbs_handoff.lcy_amount%TYPE,
                                pfcyamt     IN actbs_handoff.fcy_amount%TYPE,
                                plcy        IN actbs_handoff.ac_ccy%TYPE,
                                pbrdate     IN DATE,
                                puncol      IN CHAR,
                                pdrcr_ind   IN CHAR,
                                pactioncode IN CHAR,
                                pupdact     IN CHAR,
                                ptrackic    IN CHAR,
                                pupdbal     IN OUT CHAR,
                                plmtcheck   IN CHAR,
                                pavl_amt    IN OUT NUMBER,
                                perrcode    IN OUT VARCHAR2,
                                pparam      IN OUT VARCHAR2) RETURN VARCHAR2;

  FUNCTION fn_post_updatecustbal(pbranch     IN actbs_handoff.ac_branch%TYPE,
                                 paccount    IN actbs_handoff.ac_no%TYPE,
                                 paclass     IN sttbs_account.ac_class%TYPE,
                                 ptrnrefno   IN actbs_handoff.trn_ref_no%TYPE,
                                 paccccy     IN actbs_handoff.ac_ccy%TYPE,
                                 plcyamt     IN actbs_handoff.lcy_amount%TYPE,
                                 pfcyamt     IN actbs_handoff.fcy_amount%TYPE,
                                 plcy        IN actbs_handoff.ac_ccy%TYPE,
                                 pbrdate     IN DATE,
                                 puncol      IN CHAR,
                                 pdrcr_ind   IN CHAR,
                                 pactioncode IN CHAR,
                                 pupdact     IN CHAR,
                                 ptrackic    IN CHAR,
                                 pupdbal     IN OUT CHAR,
                                 plmtcheck   IN CHAR,
                                 pavl_amt    IN OUT NUMBER,
                                 perrcode    IN OUT VARCHAR2,
                                 pparam      IN OUT VARCHAR2) RETURN VARCHAR2;
  --Retro_20221350 Ends


   --INTERNAL_16786447 Starts
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2);

   --INTERNAL_16786447 ends

   --Bug #27081489 starts
   FUNCTION fn_get_trcdetails(crec              IN actbs_handoff%ROWTYPE,
                             perrcode          IN OUT ertbs_msgs.err_code%TYPE,
                             pparam            IN OUT VARCHAR2,
                             p_fn_call_id      IN OUT NUMBER,
                             p_tb_custom_data IN OUT global.ty_tb_custom_data)
    RETURN BOOLEAN;
   --Bug #27081489 ends



   --INTERNAL_17454753 Starts
   FUNCTION Fn_Pre_Write_Record(Crec        IN OUT actbs_handoff%ROWTYPE --Actbs_Daily_Log%ROWTYPE --FA-DA
                               ,Pactioncode IN CHAR
                               ,Pbranchdate IN DATE
                               ,Puserid     IN Actbs_Handoff.User_Id%TYPE
                               ,Pupdact     IN CHAR
                               ,Psuspense   IN CHAR
                               ,Pdef_Reqd   IN OUT BOOLEAN
                               ,Perrcode    IN OUT VARCHAR2
                               ,Pparam      IN OUT VARCHAR2) RETURN BOOLEAN;

   FUNCTION Fn_Post_Write_Record(Crec        IN OUT actbs_handoff%ROWTYPE --Actbs_Daily_Log%ROWTYPE --FA-DA
                                ,Pactioncode IN CHAR
                                ,Pbranchdate IN DATE
                                ,Puserid     IN Actbs_Handoff.User_Id%TYPE
                                ,Pupdact     IN CHAR
                                ,Psuspense   IN CHAR
                                ,Pdef_Reqd   IN OUT BOOLEAN
                                ,Perrcode    IN OUT VARCHAR2
                                ,Pparam      IN OUT VARCHAR2) RETURN BOOLEAN;
   --INTERNAL_17454753 Ends

   -- IPTBCIDR_18495397 Starts
        FUNCTION Fn_Pre_Txn_Reval_Entries(p_Hofftbl           IN OUT Acpks.Tbl_Achoff,
                                                                  Entry_No            IN NUMBER,
                                                                  p_Txn_Reval_Details IN VARCHAR2) RETURN BOOLEAN;

         FUNCTION Fn_Post_Txn_Reval_Entries(p_Hofftbl           IN OUT Acpks.Tbl_Achoff,
                                                              Entry_No            IN NUMBER,
                                                              p_Txn_Reval_Details IN VARCHAR2) RETURN BOOLEAN;
    -- IPTBCIDR_18495397 Ends




  function Fn_pre_validate_trcode(crec     IN OUT actbs_handoff%ROWTYPE,
                                  perrcode IN OUT ertbs_msgs.err_code%TYPE,
                                  pparam   IN OUT VARCHAR2) return boolean;

  function Fn_post_validate_trcode(crec     IN OUT actbs_handoff%ROWTYPE,
                                   perrcode IN OUT ertbs_msgs.err_code%TYPE,
                                   pparam   IN OUT VARCHAR2,
                   p_tb_custom_data IN OUT global.ty_tb_custom_data   --Bug#28053371 added
                   ) return boolean;

           --INTERNAL_19022272 Starts
  /*function Fn_pre_validate_ac(pac_branch  IN actbs_daily_log.ac_branch%TYPE,
                              pacno       IN actbs_daily_log.ac_no%TYPE,
                              pperiod     IN actbs_daily_log.period_code%TYPE,
                              pcycle      IN actbs_daily_log.financial_cycle%TYPE,
                              pactioncode IN CHAR,
                              perrcode    IN OUT VARCHAR2,
                              pparam      IN OUT VARCHAR2) return boolean;

  function Fn_post_validate_ac(pac_branch  IN actbs_daily_log.ac_branch%TYPE,
                               pacno       IN actbs_daily_log.ac_no%TYPE,
                               pperiod     IN actbs_daily_log.period_code%TYPE,
                               pcycle      IN actbs_daily_log.financial_cycle%TYPE,
                               pactioncode IN CHAR,
                               perrcode    IN OUT VARCHAR2,
                               pparam      IN OUT VARCHAR2) return boolean;*/
             --INTERNAL_19022272 Ends
--Bug#16181210
   FUNCTION Fn_Updatecustbal(Pbranch     IN Actbs_Handoff.Ac_Branch%TYPE,
                            Paccount    IN Actbs_Handoff.Ac_No%TYPE,
                            Paclass     IN Sttbs_Account.Ac_Class%TYPE,
                            Ptrnrefno   IN Actbs_Handoff.Trn_Ref_No%TYPE,
                            Paccccy     IN Actbs_Handoff.Ac_Ccy%TYPE,
                            Plcyamt     IN Actbs_Handoff.Lcy_Amount%TYPE,
                            Pfcyamt     IN Actbs_Handoff.Fcy_Amount%TYPE,
                            Plcy        IN Actbs_Handoff.Ac_Ccy%TYPE,
                            Pbrdate     IN DATE,
                            Puncol      IN CHAR,
                            Pdrcr_Ind   IN CHAR,
                            Pactioncode IN CHAR,
                            Pupdact     IN CHAR,
                            Ptrackic    IN CHAR,
                            Pupdbal     IN OUT CHAR,
                            Plmtcheck   IN CHAR,
                            Pavl_Amt    IN OUT NUMBER,
                            P_fn_call_id IN OUT NUMBER,
                            P_tb_cluster_data IN OUT GLOBAL.ty_tb_cluster_data,
                            P_Balrec  IN OUT ACPKS.BALREC,
                            Perrcode    IN OUT VARCHAR2,
                            Pparam      IN OUT VARCHAR2) RETURN VARCHAR2;
  -- --Bug#16181210

   --FA-DA - Starts
   FUNCTION Fn_pre_Achandoff (pTxnBranch  IN actbs_handoff.ac_branch%type,
                        Ptrnrefno   IN Actbs_Handoff.Trn_Ref_No%TYPE,
                        Peventseqno IN Actbs_Handoff.Event_Sr_No%TYPE,
                        Pbranchdate IN DATE,
                        Phandoff    IN OUT Acpks.Tbl_Achoff,
                        Pactioncode IN CHAR,
                        Psuspense   IN CHAR,
                        Pbalancing  IN CHAR,
                        Puserid     IN CHAR,
                        Perrcode    IN OUT VARCHAR2,
                        Pparam      IN OUT VARCHAR2)RETURN BOOLEAN;

     FUNCTION Fn_post_Achandoff (pTxnBranch  IN actbs_handoff.ac_branch%type,
                        Ptrnrefno   IN Actbs_Handoff.Trn_Ref_No%TYPE,
                        Peventseqno IN Actbs_Handoff.Event_Sr_No%TYPE,
                        Pbranchdate IN DATE,
                        Phandoff    IN OUT Acpks.Tbl_Achoff,
                        Pactioncode IN CHAR,
                        Psuspense   IN CHAR,
                        Pbalancing  IN CHAR,
                        Puserid     IN CHAR,
                        Perrcode    IN OUT VARCHAR2,
                        Pparam      IN OUT VARCHAR2)RETURN BOOLEAN;
  --FA-DA - Ends

   --Bug#16326536 - Start
   FUNCTION Fn_pre_Achandoff (Ptrnrefno   IN Actbs_Handoff.Trn_Ref_No%TYPE,
                        Peventseqno IN Actbs_Handoff.Event_Sr_No%TYPE,
                        Pbranchdate IN DATE,
                        Phandoff    IN OUT Acpks.Tbl_Achoff,
                        Pactioncode IN CHAR,
                        Psuspense   IN CHAR,
                        Pbalancing  IN CHAR,
                        Puserid     IN CHAR,
                        Perrcode    IN OUT VARCHAR2,
                        Pparam      IN OUT VARCHAR2)RETURN BOOLEAN;
     FUNCTION Fn_post_Achandoff (Ptrnrefno   IN Actbs_Handoff.Trn_Ref_No%TYPE,
                        Peventseqno IN Actbs_Handoff.Event_Sr_No%TYPE,
                        Pbranchdate IN DATE,
                        Phandoff    IN OUT Acpks.Tbl_Achoff,
                        Pactioncode IN CHAR,
                        Psuspense   IN CHAR,
                        Pbalancing  IN CHAR,
                        Puserid     IN CHAR,
                        Perrcode    IN OUT VARCHAR2,
                        Pparam      IN OUT VARCHAR2)RETURN BOOLEAN;
  --Bug#16326536 - End

--INTERNAL_16786447 Starts

FUNCTION Fn_Pre_acservice1(pbranch      IN actbs_handoff.ac_branch%TYPE,
             pbranchdate  IN DATE,
             plcy         IN actbs_handoff.ac_ccy%TYPE,
             ptranrefno   IN actbs_handoff.trn_ref_no%TYPE,
             Prelacc     IN Actbs_Handoff.Related_account%TYPE, --SFR#23654876
             Pbasis      IN CHAR DEFAULT 'T',           --SFR#23654876
             peventseqno  IN actbs_handoff.event_sr_no%TYPE,
             pactioncode  IN CHAR,
             puserid      IN actbs_handoff.user_id%TYPE,
             perrcode     IN OUT VARCHAR2,
             pparam       IN OUT VARCHAR2) RETURN BOOLEAN;

FUNCTION Fn_Post_acservice1(pbranch      IN actbs_handoff.ac_branch%TYPE,
             pbranchdate  IN DATE,
             plcy         IN actbs_handoff.ac_ccy%TYPE,
             ptranrefno   IN actbs_handoff.trn_ref_no%TYPE,
             Prelacc     IN Actbs_Handoff.Related_account%TYPE,    --SFR#23654876
             Pbasis      IN CHAR DEFAULT 'T',            --SFR#23654876
             peventseqno  IN actbs_handoff.event_sr_no%TYPE,
             pactioncode  IN CHAR,
             puserid      IN actbs_handoff.user_id%TYPE,
             perrcode     IN OUT VARCHAR2,
             pparam       IN OUT VARCHAR2) RETURN BOOLEAN;


--INTERNAL_16786447 Ends

--INTERNAL_17454798 Starts
    FUNCTION Fn_Pre_Check_This_Is_An_Error(p_Calling_Function IN VARCHAR2
                                         ,Perrcode           IN OUT VARCHAR2
                                         ,Pparam             IN OUT VARCHAR2
                                         ,p_Errflag          OUT BOOLEAN) RETURN BOOLEAN;

   FUNCTION Fn_Post_Check_This_Is_An_Error(p_Calling_Function IN VARCHAR2
                                          ,Perrcode           IN OUT VARCHAR2
                                          ,Pparam             IN OUT VARCHAR2
                                          ,p_Errflag          OUT BOOLEAN) RETURN BOOLEAN;
--INTERNAL_17454798 Ends
--9NT1606_FCUBS12.0.2_RETRO_17815862  Changes starts
FUNCTION Fn_Updatecustbal(Pbranch     IN Actbs_Handoff.Ac_Branch%TYPE,
                          Paccount    IN Actbs_Handoff.Ac_No%TYPE,
                            Paclass     IN Sttbs_Account.Ac_Class%TYPE,
                            Ptrnrefno   IN Actbs_Handoff.Trn_Ref_No%TYPE,
                            Paccccy     IN Actbs_Handoff.Ac_Ccy%TYPE,
                            Plcyamt     IN Actbs_Handoff.Lcy_Amount%TYPE,
                            Pfcyamt     IN Actbs_Handoff.Fcy_Amount%TYPE,
                            Plcy        IN Actbs_Handoff.Ac_Ccy%TYPE,
                            Pbrdate     IN DATE,
                            Puncol      IN CHAR,
                            Pdrcr_Ind   IN CHAR,
                            Pactioncode IN CHAR,
                            Pupdact     IN CHAR,
                            Ptrackic    IN CHAR,
                            Pupdbal     IN OUT CHAR,
                            Plmtcheck   IN CHAR,
                            Pavl_Amt    IN OUT NUMBER,
              p_fn_call_id IN NUMBER,
              p_Tb_Custom_Data  IN OUT Global.Ty_Tb_Custom_Data,
                            Perrcode    IN OUT VARCHAR2,
                            Pparam      IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Updatecustbal_Check(p_fn_call_id IN NUMBER,
                p_Tb_Custom_Data  IN OUT Global.Ty_Tb_Custom_Data,
                p_Err_Code  IN OUT VARCHAR2,
                p_Err_Param IN OUT VARCHAR2)
RETURN BOOLEAN;
--9NT1606_FCUBS12.0.2_RETRO_17815862  Changes ends
 --Retro_19434403 Starts
  FUNCTION fn_Pre_acEntry_Retrieval(pTrnRefNo   IN ACVWS_ALL_AC_ENTRIES.trn_ref_no%TYPE,
                                    pEventSeqNo IN ACVWS_ALL_AC_ENTRIES.event_sr_no%TYPE,
                                    pAcEnts     IN OUT ACPKS.tbl_AcHoff)
    return NUMBER;

  FUNCTION fn_post_acEntry_Retrieval(pTrnRefNo   IN ACVWS_ALL_AC_ENTRIES.trn_ref_no%TYPE,
                                     pEventSeqNo IN ACVWS_ALL_AC_ENTRIES.event_sr_no%TYPE,
                                     pAcEnts     IN OUT ACPKS.tbl_AcHoff)
    return NUMBER;

  FUNCTION fn_Pre_acEntry_Retrieval(pTrnRefNo   IN ACVWS_ALL_AC_ENTRIES.trn_ref_no%TYPE,
                                    pEventSeqNo IN ACVWS_ALL_AC_ENTRIES.event_sr_no%TYPE,
                                    ptrndt      IN ACVWS_ALL_AC_ENTRIES.trn_dt%TYPE,
                                    pValdt      IN ACVWS_ALL_AC_ENTRIES.value_dt%TYPE,
                                    pAcEnts     IN OUT ACPKS.tbl_AcHoff)
    return NUMBER;

  FUNCTION fn_post_acEntry_Retrieval(pTrnRefNo   IN ACVWS_ALL_AC_ENTRIES.trn_ref_no%TYPE,
                                     pEventSeqNo IN ACVWS_ALL_AC_ENTRIES.event_sr_no%TYPE,
                                     ptrndt      IN ACVWS_ALL_AC_ENTRIES.trn_dt%TYPE,
                                     pValdt      IN ACVWS_ALL_AC_ENTRIES.value_dt%TYPE,
                                     pAcEnts     IN OUT ACPKS.tbl_AcHoff)
    return NUMBER;

  PROCEDURE Pr_pre_init_ac_obj_custom(Pacents      IN OUT acpks.tbl_achoff,
                      Pacentrysrno  IN actb_daily_log.trn_ref_no%TYPE);

  PROCEDURE Pr_post_init_ac_obj_custom(Pacents      IN OUT acpks.tbl_achoff,
                       Pacentrysrno IN actb_daily_log.trn_ref_no%TYPE);
  --Retro_19434403 Ends
--RETRO_18837039_12.0.3 STARTS
  FUNCTION Fn_Pre_Resolve_Ib(Crec        IN OUT Actbs_Handoff%ROWTYPE,
                             l_Constbl   IN OUT Acpks.Tbl_Achoff,
                             p_Tmp_Xrate IN OUT Actbs_Daily_Log.Exch_Rate%TYPE,
                             Perrcode    IN OUT VARCHAR2,
                             Pparam      IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION Fn_Post_Resolve_Ib(Crec        IN OUT Actbs_Handoff%ROWTYPE,
                              l_Constbl   IN OUT Acpks.Tbl_Achoff,
                              p_Tmp_Xrate IN OUT Actbs_Daily_Log.Exch_Rate%TYPE,
                              Perrcode    IN OUT VARCHAR2,
                              Pparam      IN OUT VARCHAR2) RETURN BOOLEAN;
--RETRO_18837039_12.0.3 ENDS

  --Retro_21113419 Starts
    Function acfn_pre_net(l_modtbl IN OUT Acpks.tbl_AcHoff) RETURN BOOLEAN;
  Function acfn_post_net(l_modtbl IN OUT Acpks.tbl_AcHoff) RETURN BOOLEAN;
  --Retro_21113419 Ends
--12.2_RETRO_Bug#23658293 Changes starts here
    FUNCTION Fn_pre_Auto_Generate(Pforautogeneration IN Acpks.Tbl_Achoff,
                            Pmismatchtype      IN CHAR,
                            Pwhattheuserwants  IN CHAR,
                            Pautogeneratedentries IN OUT Acpks.Tbl_Achoff,
                            Pmisentries           OUT Mitbs_Class_Mapping%ROWTYPE,
                            Pmisflag              OUT BOOLEAN,
                            Perrcode              IN OUT VARCHAR2,
                            Pparam                IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_post_Auto_Generate(Pforautogeneration IN Acpks.Tbl_Achoff,
                            Pmismatchtype      IN CHAR,
                            Pwhattheuserwants  IN CHAR,
                            Pautogeneratedentries IN OUT Acpks.Tbl_Achoff,
                            Pmisentries           OUT Mitbs_Class_Mapping%ROWTYPE,
                            Pmisflag              OUT BOOLEAN,
                            Perrcode              IN OUT VARCHAR2,
                            Pparam                IN OUT VARCHAR2)
    RETURN BOOLEAN;
--12.2_RETRO_Bug#23658293 Changes ends here
--Bug#23651516 starts
    FUNCTION fn_updatecustbal_new(pbranch     IN actbs_handoff.ac_branch%TYPE,
                                 paccount    IN actbs_handoff.ac_no%TYPE,
                                 paclass     IN sttbs_account.ac_class%TYPE,
                                 ptrnrefno   IN actbs_handoff.trn_ref_no%TYPE,
                                 paccccy     IN actbs_handoff.ac_ccy%TYPE,
                                 plcyamt     IN actbs_handoff.lcy_amount%TYPE,
                                 pfcyamt     IN actbs_handoff.fcy_amount%TYPE,
                                 plcy        IN actbs_handoff.ac_ccy%TYPE,
                                 pbrdate     IN DATE,
                                 puncol      IN CHAR,
                                 pdrcr_ind   IN CHAR,
                                 pactioncode IN CHAR,
                                 pupdact     IN CHAR,
                                 ptrackic    IN CHAR,
                                 pupdbal     IN OUT CHAR,
                                 plmtcheck   IN CHAR,
                                 pavl_amt    IN OUT NUMBER,
                                 perrcode    IN OUT VARCHAR2,
                                 pparam      IN OUT VARCHAR2,
                 p_SWEEP_IN  IN OUT  sttms_cust_account.sweep_required%TYPE,
                 P_REVSWEEP_IN  IN OUT  sttms_cust_account.sweep_required%TYPE,
                      p_Fn_Call_Id     IN OUT NUMBER,
                      p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
  RETURN BOOLEAN ;
  --Bug#23651516 end
--12.2_RETRO_Bug#23656114 Changes starts here
  FUNCTION fn_pre_calc_brn_profit(p_is_row          IN acpkss.ty_tb_brn_prof,
                  p_tag_ac_branch   IN VARCHAR2,
                  p_txn_amt         IN NUMBER,
                  p_drcr_ind        IN VARCHAR2,
                  p_branch_lcy      IN VARCHAR2,
                  p_reval_rate_code IN cytms_rate_type.ccy_rate_type%TYPE,
                  p_rate_type_ind   IN VARCHAR2,
                  p_reval_amt       IN OUT NUMBER,
                  p_error_code      IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION fn_post_calc_brn_profit(p_is_row          IN acpkss.ty_tb_brn_prof,
                   p_tag_ac_branch   IN VARCHAR2,
                   p_txn_amt         IN NUMBER,
                   p_drcr_ind        IN VARCHAR2,
                   p_branch_lcy      IN VARCHAR2,
                   p_reval_rate_code IN cytms_rate_type.ccy_rate_type%TYPE,
                   p_rate_type_ind   IN VARCHAR2,
                   p_reval_amt       IN OUT NUMBER,
                   p_error_code      IN OUT VARCHAR2) RETURN BOOLEAN;
--12.2_RETRO_Bug#23656114 Changes ends here
--12.2_RETRO_Bug#24814470 Changes starts here
FUNCTION fn_post_auth_batch(pbranch            IN actbs_daily_log.ac_branch%TYPE,
                         p_batchno          IN detbs_batch_master.batch_no%TYPE,
                         p_curr_userid      IN actbs_daily_log.auth_id%TYPE,
                         p_application_date IN DATE,
                         p_err_code         IN OUT VARCHAR2,
                         p_err_param        IN OUT VARCHAR2)  RETURN BOOLEAN;
--12.2_RETRO_Bug#24814470 Changes ends here
--12.2_EXTN_Bug#25296066 Changes starts here
FUNCTION fn_post_assign_dflt(crec     IN OUT actbs_handoff%ROWTYPE,
              p_Fn_Call_Id      IN OUT NUMBER,
                          p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data,
              perrcode IN OUT VARCHAR2,
                          pparam   IN OUT VARCHAR2) RETURN BOOLEAN;
--12.2_EXTN_Bug#25296066 Changes ends here
--12.3_RETRO_Bug#25436132 Changes starts here
FUNCTION fn_pre_assign_dflt(crec     IN OUT actbs_handoff%ROWTYPE,
              p_Fn_Call_Id      IN OUT NUMBER,
                          p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data,
              perrcode IN OUT VARCHAR2,
                          pparam   IN OUT VARCHAR2) RETURN BOOLEAN;
--12.3_RETRO_Bug#25436132 Changes ends here
--Bug#26550111  starts
PROCEDURE pr_pre_Set_ReversalFlag(ptrnrefno     IN actbs_handoff.trn_ref_no%TYPE,
                            peventseqno     IN actbs_handoff.event_sr_no%TYPE,
                            crec            IN actbs_handoff%ROWTYPE,
                            p_is_Reversal   IN OUT BOOLEAN);

PROCEDURE pr_post_Set_ReversalFlag(ptrnrefno     IN actbs_handoff.trn_ref_no%TYPE,
                            peventseqno     IN actbs_handoff.event_sr_no%TYPE,
                            crec            IN actbs_handoff%ROWTYPE,
                            p_is_Reversal   IN OUT BOOLEAN);
--Bug#26550111 ends
--12.4_EXTN_27675980 starts
  FUNCTION fn_validate_trcode(crec     IN OUT actbs_handoff%ROWTYPE,
                              perrcode IN OUT ertbs_msgs.err_code%TYPE,
                              pparam   IN OUT VARCHAR2,
                p_Fn_Call_Id      IN OUT NUMBER,
                p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data) RETURN BOOLEAN;

  FUNCTION fn_update_uncol(pbranch     IN sttms_branch.branch_code%TYPE,
                           paccount    IN actbs_handoff.ac_no%TYPE,
                           pavldate    IN DATE,
                           pamount     IN actbs_handoff.lcy_amount%TYPE,
                           ptrnrefno   IN actbs_handoff.trn_ref_no%TYPE,
                           peventseqno IN actbs_handoff.event_sr_no%TYPE,
                           ptrncode    IN sttms_trn_code.trn_code%TYPE,
                           pbankcode   IN actbs_handoff.bank_code%TYPE DEFAULT 'UNDEFINED',
                           pactioncode IN CHAR,
                           perrcode    IN OUT ertbs_msgs.err_code%TYPE,
                           pparam      IN OUT VARCHAR2,
                           puncolpkey    IN OUT ACTB_FUNCOL.PKEY%TYPE,
                           pacentrysrno  IN NUMBER DEFAULT NULL,
                           pprdprocessor IN VARCHAR2 DEFAULT 'FC',
                           p_Fn_Call_Id      IN OUT NUMBER,
               p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data) RETURN BOOLEAN;

  FUNCTION fn_acservice1(pbranch     IN actbs_handoff.ac_branch%TYPE,
                         pbranchdate IN DATE,
                         plcy        IN actbs_handoff.ac_ccy%TYPE,
                         ptranrefno  IN actbs_handoff.trn_ref_no%TYPE,
                         Prelacc     IN Actbs_Handoff.Related_account%TYPE,
                         Pbasis      IN CHAR DEFAULT 'T',
                         peventseqno IN actbs_handoff.event_sr_no%TYPE,
                         pactioncode IN CHAR,
                         puserid     IN actbs_handoff.user_id%TYPE,
                         perrcode    IN OUT VARCHAR2,
                         pparam      IN OUT VARCHAR2,
                         p_Fn_Call_Id      IN OUT NUMBER,
             p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data) RETURN BOOLEAN;
--12.4_EXTN_27675980 ends
--12.4_EXTN_29783125 starts
  FUNCTION Fn_Build_Mismatch_And_Pos(crec                 IN OUT NOCOPY actbs_handoff%ROWTYPE, --Remove this param
                                     tbl_pos_curr_no      IN BINARY_INTEGER,
                                     in_loop_for_autogen  IN OUT BOOLEAN,
                                     in_loop_for_position IN OUT BOOLEAN,
                                     loop_for_position    IN OUT BOOLEAN,
                                     pbalancing           IN CHAR,
                                     p_misflag            IN OUT BOOLEAN,
                                     p_misentries         IN OUT mitbs_class_mapping%ROWTYPE,
                                     p_hoff               IN OUT acpks.tbl_achoff,
                   pkg_ibposition     IN acpks.tbl_AcHoff,
                                     perrcode             IN OUT VARCHAR2,
                                     pparam               IN OUT VARCHAR2,
                   p_Fn_Call_Id         IN OUT NUMBER,
                   p_Tb_Custom_Data     IN OUT Global.Ty_Tb_Custom_Data) RETURN BOOLEAN;
--12.4_EXTN_29783125 ends
end acpks_custom;
/