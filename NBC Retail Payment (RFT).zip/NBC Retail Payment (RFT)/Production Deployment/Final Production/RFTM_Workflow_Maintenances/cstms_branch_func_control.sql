insert into cstms_branch_func_control (FUNCTION_ID, OFFLINE_SUPPORT, REVERSAL_ALLOWED, CONFIRM_SUPPORT)
values ('RFTM', 'Y', 'N', null);

commit;
