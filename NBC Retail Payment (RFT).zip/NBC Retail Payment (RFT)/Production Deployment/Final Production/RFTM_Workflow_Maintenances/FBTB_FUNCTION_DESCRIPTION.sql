insert into FBTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'RFTM', 'Teller', 'Cash Transactions', 'RFT Withdrawal Remittance', null, 'WB', '0', 'RFT Withdrawal Remittance', null);

COMMIT;
