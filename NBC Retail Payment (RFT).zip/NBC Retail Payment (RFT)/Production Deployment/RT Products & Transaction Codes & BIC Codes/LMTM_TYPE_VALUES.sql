insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'ACLEDA BANK PLC', '041');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'ADVANCED BANK OF ASIA LTD', '036');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'AMK Microfinance Institution Plc.', '089');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'AMRET Microfinance Institution', '084');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'ANZ ROYAL BANK CAMBODIA LTD', '044');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'BANK FOR INVESTMENT & DEVELOPMENT OF CAMBODIA PLC', '068');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'BANK OF CHINA LIMITED PHNOM PENH BRANCH', '071');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'BANK OF INDIA PHNOM PENH BRANCH', '065');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'BOOYOUNG KHMER BANK', '061');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'BRED Bank (Cambodia) PLC', '092');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'Bangkok Bank Co.,Ltd', '082');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'Branch of Kasikornbank Public Company Limited (Phnom Penh)', '091');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'CAMBODIA ASIA BANK LTD', '016');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'CAMBODIA MEKONG BANK PUBLIC LIMITED', '032');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'CAMBODIA POST BANK, PLC', '079');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'CAMBODIAN COMMERCIAL BANK LTD', '003');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'CAMBODIAN PUBLIC BANK LTD', '004');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'CANADIA BANK PLC', '005');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'CATHAY UNITED BANK, CAMBODIA', '080');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'CIMB Bank (Cambodia) Plc', '072');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'FIRST COMMERCIAL BANK PHNOM PENH BRANCH', '040');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'FOREIGN TRADE BANK OF CAMBODIA', '001');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'Hattha Kaksekar Limited', '085');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'Hong Leong Bank (Cambodia) Plc', '077');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'ICBC Limited Phnom Penh Branch', '069');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'KOOKMIN BANK CAMBODIA PLC', '066');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'KREDIT Microfinance Institution Plc.', '083');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'KRUNG THAI BANK PUBLIC CO,LTD PHNOM PEHN BRANCH', '009');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'LOLC (Cambodia) PLc', '090');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'MAY BANK PHNOM PENH BRANCH', '020');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'MB Bank Plc Phnom Penh Branch, Cambodia', '074');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'Mega International Commercial Bank Co.,Ltd', '073');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'NATIONAL BANK OF CAMBODIA', '100');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'PHILLIP BANK PLC', '081');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'PHNOM PENH COMMERCIAL BANK', '058');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'PRASAC Microfinance Institution', '088');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'RHB INDOCHINA BANK LIMITED', '078');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'RURAL DEVELOPMENT BANK', '038');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'SACOMBANK (CAMBODIA) PLC', '064');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'SATHAPANA BANK PLC', '056');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'SHB Plc Phnom Penh Branch, Cambodia', '075');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'SHINHAN KHMER BANK LIMITED', '053');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'Taiwan Cooperative Bank, Cambodia Branch', '076');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'UNION COMMERCIAL BANK PLC', '026');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'VATTANAC BANK', '043');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'VIETNAM BANK FOR AGRICULTURE AND RURAL DEVELOPMENT, CAMBODIA BRANCH', '070');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'Vision Fund Cambodia', '087');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RFT_MEMBERS', 'PRINCE BANK PLC', '096');

COMMIT;
