insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('RFT_MEMBERS', 'RFT Payment Bank Codes', 'SAMPATH1', 'SAMPATH2', to_date('14-01-2020 10:33:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('14-01-2020 10:34:20', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '3', 'Y');

COMMIT;
