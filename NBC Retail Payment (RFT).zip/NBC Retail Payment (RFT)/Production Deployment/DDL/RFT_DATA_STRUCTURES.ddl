-- Create table
create table IFTB_RFT_MASTER
(
  branch_code      VARCHAR2(3),
  msg_flow         VARCHAR2(1),
  trn_ref_no       VARCHAR2(20) PRIMARY KEY,
  product_code     VARCHAR2(4),
  transfer_date    DATE,
  txn_ccy          VARCHAR2(3),
  txn_amt          NUMBER(22,3),
  tot_chg_amt      NUMBER(22,3),
  net_txn_amt      NUMBER(22,3),
  exch_rate        NUMBER(24,12),
  txn_status       VARCHAR2(20),
  txn_remarks      VARCHAR2(255),
  rem_acc          VARCHAR2(100),
  rem_name         VARCHAR2(100),
  rem_add1         VARCHAR2(105),
  rem_add2         VARCHAR2(105),
  rem_add3         VARCHAR2(105),
  rem_add4         VARCHAR2(105),
  ben_acc          VARCHAR2(22),
  ben_bic          VARCHAR2(100),
  ben_name         VARCHAR2(100),
  ben_add1         VARCHAR2(105),
  ben_add2         VARCHAR2(105),
  ben_add3         VARCHAR2(105),
  ben_add4         VARCHAR2(105),
  ben_remarks      VARCHAR2(255),
  ben_phone        VARCHAR2(20),
  ben_email        VARCHAR2(105),
  channel_code     VARCHAR2(105),
  trace_no         VARCHAR2(105),
  txn_unq_no       VARCHAR2(105),
  secrete_key      VARCHAR2(105),
  maker_id         VARCHAR2(12),
  maker_dt_stamp   DATE,
  checker_id       VARCHAR2(12),
  checker_dt_stamp DATE,
  auth_stat        VARCHAR2(1),
  record_stat      VARCHAR2(1),
  once_auth        VARCHAR2(1),
  mod_no           NUMBER(4)
)
/
create or replace synonym IFTBS_RFT_MASTER for IFTB_RFT_MASTER
/
-- Create table
create table IFTB_RFT_MASTER_MOB
(
  branch_code      VARCHAR2(3),
  msg_flow         VARCHAR2(1),
  trn_ref_no       VARCHAR2(20) PRIMARY KEY,
  product_code     VARCHAR2(4),
  transfer_date    DATE,
  txn_ccy          VARCHAR2(3),
  txn_amt          NUMBER(22,3),
  tot_chg_amt      NUMBER(22,3),
  net_txn_amt      NUMBER(22,3),
  exch_rate        NUMBER(24,12),
  txn_status       VARCHAR2(20),
  txn_remarks      VARCHAR2(255),
  rem_acc          VARCHAR2(100),
  rem_name         VARCHAR2(100),
  rem_phone        VARCHAR2(20),
  ben_name         VARCHAR2(100),
  ben_phone        VARCHAR2(20),
  trace_no         VARCHAR2(105),
  txn_unq_no       VARCHAR2(105),
  pass_code        VARCHAR2(105),
  maker_id         VARCHAR2(12),
  maker_dt_stamp   DATE,
  checker_id       VARCHAR2(12),
  checker_dt_stamp DATE,
  auth_stat        VARCHAR2(1),
  record_stat      VARCHAR2(1),
  once_auth        VARCHAR2(1),
  mod_no           NUMBER(4)
)
/
create or replace synonym IFTBS_RFT_MASTER_MOB for IFTB_RFT_MASTER_MOB
/
-- Create table
create table STTB_RFT_WS_LOG_RFTM
(
  xref         VARCHAR2(35) PRIMARY KEY,
  action       VARCHAR2(20),
  passcode     VARCHAR2(8),
  ben_phone    NUMBER,
  ccy          VARCHAR2(3),
  txn_amt      NUMBER,
  ben_name     VARCHAR2(105),
  rem_phone    NUMBER,
  rem_name     VARCHAR2(105),
  ben_bic_code VARCHAR2(105),
  invoke_date  TIMESTAMP(6),
  status       VARCHAR2(10),
  wait_key     VARCHAR2(105)
)
/
-- Create table
create table IFTB_RFT_PASSCODE_INFO
(
  trn_ref_no   VARCHAR2(16) PRIMARY KEY,
  passcode     VARCHAR2(8),
  ben_phone    VARCHAR2(105),
  txn_ccy      VARCHAR2(3),
  txn_amount   NUMBER,
  ben_name     VARCHAR2(105),
  rem_phone    VARCHAR2(105),
  rem_name     VARCHAR2(105),
  ben_bic_code VARCHAR2(105)
)
/
-- Create table
create table IFTB_RFT_CHARGE
(
  trn_ref_no  VARCHAR2(20),
  chg_srno    NUMBER(1),
  chg1_desc   VARCHAR2(255),
  chg1_waiver VARCHAR2(1),
  chg1_amt    NUMBER(22,3),
  chg1_ccy    VARCHAR2(3),
  lcy_chg1    NUMBER(22,3),
  fcy_chg1    NUMBER(22,3),
  chg1_gl     VARCHAR2(20),
  chg2_desc   VARCHAR2(255),
  chg2_waiver VARCHAR2(1),
  chg2_amt    NUMBER(22,3),
  chg2_ccy    VARCHAR2(3),
  lcy_chg2    NUMBER(22,3),
  fcy_chg2    NUMBER(22,3),
  chg2_gl     VARCHAR2(20),
  chg3_desc   VARCHAR2(255),
  chg3_waiver VARCHAR2(1),
  chg3_amt    NUMBER(22,3),
  chg3_ccy    VARCHAR2(3),
  lcy_chg3    NUMBER(22,3),
  fcy_chg3    NUMBER(22,3),
  chg3_gl     VARCHAR2(20),
  netting_req CHAR(1),
  xrate       NUMBER(22,10),
  txn_code    VARCHAR2(3),
  chg1_type   VARCHAR2(1),
  chg1_in_txn NUMBER(22,3),
  chg1_in_acc NUMBER(22,3),
  chg2_type   VARCHAR2(1),
  chg2_in_txn NUMBER(22,3),
  chg2_in_acc NUMBER(22,3),
  chg3_type   VARCHAR2(1),
  chg3_in_txn NUMBER(22,3),
  chg3_in_acc NUMBER(22,3),
  oth_ccy     VARCHAR2(3),
  txn_xrate   NUMBER(22,10),
  acc_xrate   NUMBER(22,10)
)
/
alter table IFTB_RFT_CHARGE ADD primary key (TRN_REF_NO, CHG_SRNO)
/
-- Create table
create table STTB_RFT_WS_LOG
(
  seq_no      VARCHAR2(100) PRIMARY KEY,
  trn_ref_no  VARCHAR2(20),
  invoke_date DATE,
  req_type    VARCHAR2(20),
  req_msg     CLOB,
  res_msg     CLOB,
  status      VARCHAR2(10),
  addl_info   VARCHAR2(255),
  secret_key  VARCHAR2(255)
)
/
-- Create table
create table IFTB_RFT_TXN_ENQ
(
  txn_unq_no VARCHAR2(20),
  txn_date   DATE not null,
  resp_code  VARCHAR2(100),
  resp_msg   VARCHAR2(100)
)
/
alter table IFTB_RFT_TXN_ENQ add primary key (TXN_UNQ_NO, TXN_DATE)
/

-- Create sequence 
create sequence TRSQ_RFT_SEQID
minvalue 1
maxvalue 999999999
start with 1
increment by 1
nocache
cycle
/
