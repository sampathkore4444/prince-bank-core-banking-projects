DECLARE
  req     utl_http.req;
  res     utl_http.resp;
  url     varchar2(4000) := 'http://10.80.80.121:8080/api/authenticate.json';
  name    varchar2(4000);
  buffer  varchar2(4000);
  content varchar2(4000) := '{
  "username":"kyvannroath",
  "password":"P@ssw0rd",
  "rememberMe":"true"
}';

begin
  req := utl_http.begin_request(url);
  utl_http.set_authentication( req, '','', 'Basic' );
  utl_http.set_header(req, 'user-agent', 'mozilla/4.0');
  utl_http.set_header(req, 'content-type', 'application/json');
  utl_http.set_header(req, 'Content-Length', length(content));
  
  --UTL_HTTP.SET_BODY_CHARSET('UTF-8');

  utl_http.write_text(req, content);
  
  UTL_HTTP.WRITE_RAW (req,
                    UTL_RAW.CAST_TO_RAW(content));
                    
  res := utl_http.get_response(req);

  -- process the response from the HTTP call
  begin
    loop
      utl_http.read_line(res, buffer);
      dbms_output.put_line(buffer);
    end loop;
    utl_http.end_response(res);
  exception
    when utl_http.end_of_body then
      utl_http.end_response(res);
    when others then
      dbms_output.put_line('ERROR CODE='||SQLCODE);
      dbms_output.put_line('ERROR MESSAGE='||SQLERRM);
  end;
end;
