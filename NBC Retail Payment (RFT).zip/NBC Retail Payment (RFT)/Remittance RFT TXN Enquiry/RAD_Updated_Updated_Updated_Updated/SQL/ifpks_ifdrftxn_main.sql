CREATE OR REPLACE PACKAGE BODY ifpks_ifdrftxn_main AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : ifpks_ifdrftxn_main.sql
     **
     ** Module     : Interfaces
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     -------------------------------------------------------------------------------------------------------
     */
     

   g_Original_Action    VARCHAR2(100);
   g_Action_Code    VARCHAR2(100);
   g_Addl_Info       Cspks_Req_Global.Ty_Addl_Info;
   g_Ui_Name            VARCHAR2(50) := 'IFDRFTXN';
   g_Req_Key                 VARCHAR2(32767);
   g_ifdrftxn         ifpks_ifdrftxn_Main.Ty_ifdrftxn;
   --Skip Handler Variables
   g_Skip_Sys       BOOLEAN := FALSE;
   g_Skip_Custom    BOOLEAN := FALSE;
   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      IF debug.pkg_debug_on <> 2 THEN
         l_Msg := 'ifpks_ifdrftxn_Main ==>'||p_Msg;
         Debug.Pr_Debug('IF' ,l_Msg);
      END IF;
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
      l_Fid    VARCHAR2(32767) := 'IFDRFTXN';
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,l_Fid,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      ifpks_ifdrftxn_Custom.Pr_Skip_Handler (P_Stage);
   END Pr_Skip_Handler;
   PROCEDURE Pr_Set_Skip_Sys IS
   BEGIN
      g_Skip_Sys := TRUE;
   END Pr_Set_Skip_Sys;
   PROCEDURE Pr_Set_Activate_Sys IS
   BEGIN
      g_Skip_Sys := FALSE;
   END Pr_Set_Activate_Sys;
   FUNCTION  Fn_Skip_Sys RETURN BOOLEAN IS
   BEGIN
      RETURN G_Skip_Sys;
   END  Fn_Skip_Sys;
   PROCEDURE Pr_Set_Skip_Custom IS
   BEGIN
      g_Skip_Custom := TRUE;
   END Pr_Set_Skip_Custom;
   PROCEDURE Pr_Set_Activate_Custom IS
   BEGIN
      g_Skip_Custom := FALSE;
   END Pr_Set_Activate_Custom;
   FUNCTION  Fn_Skip_Custom RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type IN(Cspks_Req_Global.p_Kernel,Cspks_Req_Global.P_Cluster) THEN
         RETURN TRUE;
      ELSIF Cspks_Req_Global.g_Release_Type =Cspks_Req_Global.p_Custom THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Custom;
      END IF;
   END  Fn_Skip_Custom;
   FUNCTION  Fn_Get_Original_Action RETURN VARCHAR2 IS
   BEGIN
      RETURN G_Original_Action;
   END  Fn_Get_Original_Action;
   FUNCTION Fn_Sys_Build_Fc_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_ifdrftxn       IN   OUT ifpks_ifdrftxn_Main.ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;

   BEGIN

      dbg('In Fn_Sys_Build_Fc_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node = 'BLK_TXN_DTLS' THEN
            p_ifdrftxn.v_iftb_rft_txn_enq.TXN_UNQ_NO := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_ifdrftxn.v_iftb_rft_txn_enq.TXN_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_ifdrftxn.v_iftb_rft_txn_enq.TXN_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_ifdrftxn.v_iftb_rft_txn_enq.RESP_CODE := Cspks_Req_Global.Fn_GetVal;
            p_ifdrftxn.v_iftb_rft_txn_enq.RESP_MSG := Cspks_Req_Global.Fn_GetVal;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_ifdrftxn.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdrftxn_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Type;
   FUNCTION Fn_Sys_Build_Ws_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_ifdrftxn       IN   OUT ifpks_ifdrftxn_Main.ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      Invalid_Date        EXCEPTION;

   BEGIN

      dbg('In Fn_Sys_Build_Ws_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node IN ( 'BLK_TXN_DTLS','Txn-Dtls-Full','Txn-Dtls-IO') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'TXN_UNQ_NO' THEN
                  p_ifdrftxn.v_iftb_rft_txn_enq.TXN_UNQ_NO := l_Val;
               ELSIF l_Key IN( 'TNR_DT','TXN_DATE')  THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_ifdrftxn.v_iftb_rft_txn_enq.TXN_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_ifdrftxn.v_iftb_rft_txn_enq.TXN_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'RESP_CODE' THEN
                  p_ifdrftxn.v_iftb_rft_txn_enq.RESP_CODE := l_Val;
               ELSIF l_Key = 'RESP_MSG' THEN
                  p_ifdrftxn.v_iftb_rft_txn_enq.RESP_MSG := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_ifdrftxn.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN Invalid_Date THEN
         Pr_Log_Error(p_Source,'ST-OTHR-003',l_Key||'~'||Cspks_Req_Global.g_Date_Format) ;
         RETURN FALSE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdrftxn_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Type;
   FUNCTION Fn_Sys_Build_Fc_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_ifdrftxn          IN ifpks_ifdrftxn_Main.ty_ifdrftxn,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Fc_Ts..');

      --Dbg('Building Childs Of :..');
      l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_TXN_DTLS',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','TXN_UNQ_NO',p_ifdrftxn.v_iftb_rft_txn_enq.txn_unq_no);
      IF trunc(p_ifdrftxn.v_iftb_rft_txn_enq.txn_date) <>
            p_ifdrftxn.v_iftb_rft_txn_enq.txn_date THEN
         l_Date_Val :=  TO_CHAR( p_ifdrftxn.v_iftb_rft_txn_enq.txn_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_ifdrftxn.v_iftb_rft_txn_enq.txn_date,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','TXN_DATE',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','RESP_CODE',p_ifdrftxn.v_iftb_rft_txn_enq.resp_code);
      Cspks_Req_Global.Pr_Write('V','RESP_MSG',p_ifdrftxn.v_iftb_rft_txn_enq.resp_msg);
      Dbg('Returning Success From Fn_Sys_Build_Fc_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Ts;
   FUNCTION Fn_Sys_Build_Ws_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Exchange_Pattern IN       VARCHAR2,
      p_ifdrftxn          IN ifpks_ifdrftxn_Main.ty_ifdrftxn,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Key_Cols          VARCHAR2(32767);
      l_Key_Vals          VARCHAR2(32767);
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Ws_Ts..');
      IF SUBSTR(p_Exchange_Pattern,3,4) = 'FS' THEN
         Dbg('Building Full Screen Reply..');

         --Dbg('Building Childs Of :..');
         IF (  p_ifdrftxn.v_iftb_rft_txn_enq.txn_unq_no IS NOT NULL 
         AND  p_ifdrftxn.v_iftb_rft_txn_enq.txn_date IS NOT NULL 
          )
          THEN
            l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','Txn-Dtls-Full',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','TXN_UNQ_NO',p_ifdrftxn.v_iftb_rft_txn_enq.txn_unq_no);
            IF trunc(p_ifdrftxn.v_iftb_rft_txn_enq.txn_date) <>
                  p_ifdrftxn.v_iftb_rft_txn_enq.txn_date THEN
               l_Date_Val :=  TO_CHAR( p_ifdrftxn.v_iftb_rft_txn_enq.txn_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_ifdrftxn.v_iftb_rft_txn_enq.txn_date,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','TNR_DT',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','RESP_CODE',p_ifdrftxn.v_iftb_rft_txn_enq.resp_code);
            Cspks_Req_Global.Pr_Write('V','RESP_MSG',p_ifdrftxn.v_iftb_rft_txn_enq.resp_msg);
         END IF;
      ELSE
         Dbg('Building Primary Key Reply..');
         Cspks_Req_Global.pr_Write('P','Txn-Dtls-PK','1');
         l_Key_Cols := 'TXN_UNQ_NO~'||'TNR_DT~';
         l_Key_Vals := p_ifdrftxn.v_iftb_rft_txn_enq.txn_unq_no||'~'||TO_CHAR(p_ifdrftxn.v_iftb_rft_txn_enq.txn_date,Cspks_Req_Global.g_Date_Format)||'~';
         Cspks_Req_Global.pr_Write('V',l_Key_Cols,l_Key_Vals);
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Ws_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Ts;
   FUNCTION Fn_Sys_Check_Mandatory (p_Source    IN  VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_ifdrftxn IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000);
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
      l_Rec_Sent       BOOLEAN := TRUE;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';

   BEGIN

      Dbg('In Fn_Sys_Check_Mandatory..');

      l_Fld := 'IFTB_RFT_TXN_ENQ.TXN_UNQ_NO';
      IF p_ifdrftxn.v_iftb_rft_txn_enq.txn_unq_no IS Null THEN
         Dbg('Field txn_unq_no is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;
      l_Fld := 'IFTB_RFT_TXN_ENQ.TXN_DATE';
      IF p_ifdrftxn.v_iftb_rft_txn_enq.txn_date IS Null THEN
         Dbg('Field txn_date is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;

      IF p_Pk_Or_Full = 'FULL'  THEN
         Dbg('Full Mandatory Checks..');

         l_Blk := 'IFTB_RFT_TXN_ENQ';
      END IF;

      Dbg('Returning Success From Fn_Sys_Check_Mandatory ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Sys_Check_Mandatory ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory;
   FUNCTION Fn_Sys_Basic_Vals        (p_Source            IN VARCHAR2,
      p_ifdrftxn     IN  ifpks_ifdrftxn_Main.ty_ifdrftxn,
      p_Err_code          IN OUT VARCHAR2,
      p_Err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
   BEGIN

      Dbg('In Fn_Sys_Basic_Vals..');
      Dbg('Returning Success From Fn_Sys_Basic_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Basic_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Basic_Vals;

   FUNCTION Fn_Sys_Default_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_ifdrftxn     IN  OUT ifpks_ifdrftxn_Main.ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
   BEGIN

      Dbg('In Fn_Sys_Default_Vals..');
      Dbg('Returning Success From Fn_Sys_Default_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Default_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_Vals;

   FUNCTION Fn_Sys_Merge_Amendables        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Prev_ifdrftxn IN ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Wrk_ifdrftxn IN OUT ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Wrk_Count      NUMBER := 0 ;
      l_Deleted_Recs   NUMBER := 0;
      l_Modified_Flds  VARCHAR2(32000):= NULL;
      l_Key            VARCHAR2(5000):= NULL;
      l_Mod_Fld        VARCHAR2(100):= NULL;
      i                NUMBER := 1;
      l_Rec_Found      BOOLEAN := FALSE;
      l_Rec_Modified   BOOLEAN := FALSE;
      l_Rec_Sent       BOOLEAN := FALSE;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Pk_Or_Full     VARCHAR2(5) :='FULL';
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Mod_No         NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Amendable_Nodes Cspks_Req_Global.Ty_Amend_Nodes;
      l_Amendable_Fields Cspks_Req_Global.Ty_Amend_Fields;

      FUNCTION Fn_Amendable(p_Item IN VARCHAR2) RETURN BOOLEAN IS
      BEGIN
         IF l_Amendable_Fields.EXISTS(p_Item) THEN
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      END Fn_Amendable;
   BEGIN

      Dbg('In Fn_Sys_Merge_Amendables');

      Dbg('Calling Cspks_Req_Utils.Fn_Get_Amendable_Details..');
      IF NOT Cspks_Req_Utils.Fn_Get_Amendable_Details(p_source ,
         p_Source_Operation,
         l_Amendable_Nodes,
         l_Amendable_Fields,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_Amendable_Details..');
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      END IF;

      l_Blk := 'IFTB_RFT_TXN_ENQ';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_fld := 'IFTB_RFT_TXN_ENQ.RESP_CODE';
      IF Fn_Amendable('IFTB_RFT_TXN_ENQ.RESP_CODE') THEN
         p_Wrk_ifdrftxn.v_iftb_rft_txn_enq.resp_code := p_ifdrftxn.v_iftb_rft_txn_enq.resp_code;
      ELSE
         IF p_ifdrftxn.v_iftb_rft_txn_enq.resp_code IS NOT NULL THEN
            IF NVL(p_Wrk_ifdrftxn.v_iftb_rft_txn_enq.resp_code,'@') <>
               NVL(p_ifdrftxn.v_iftb_rft_txn_enq.resp_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTB_RFT_TXN_ENQ.RESP_MSG';
      IF Fn_Amendable('IFTB_RFT_TXN_ENQ.RESP_MSG') THEN
         p_Wrk_ifdrftxn.v_iftb_rft_txn_enq.resp_msg := p_ifdrftxn.v_iftb_rft_txn_enq.resp_msg;
      ELSE
         IF p_ifdrftxn.v_iftb_rft_txn_enq.resp_msg IS NOT NULL THEN
            IF NVL(p_Wrk_ifdrftxn.v_iftb_rft_txn_enq.resp_msg,'@') <>
               NVL(p_ifdrftxn.v_iftb_rft_txn_enq.resp_msg,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;

      l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
      IF  l_Rec_Modified THEN
         IF l_Modified_Flds IS NOT NULL THEN
            i :=  1;
            l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
            WHILE l_Mod_Fld <> 'EOPL' LOOP
               Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
               i := i +1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
            END LOOP;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Merge_Amendables..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Merge_Amendables..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Merge_Amendables;

   FUNCTION Fn_Sys_Check_Mandatory_Nodes  (p_Source            IN VARCHAR2,
      p_Wrk_ifdrftxn IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
   BEGIN

      dbg('In Fn_Gen_Sys_Node_Mand_Checks..');
      Dbg('Returning Success From Fn_Sys_Check_Mandatory_Nodes..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Check_Mandatory_Nodes..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory_Nodes;

   FUNCTION Fn_Sys_Lov_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Lov_Count      NUMBER := 0;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER  := 0;
   BEGIN

      Dbg('In Fn_Sys_Lov_Vals');
      Dbg('Returning Success From Fn_Sys_Lov_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Lov_Vals..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Lov_Vals;

   FUNCTION Fn_Sys_Default_And_Validate        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Prev_ifdrftxn IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Wrk_ifdrftxn IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Sys_Default_and_Validate..');

      Dbg('Returning Success  From Fn_Sys_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdrftxn_Main.Fn_Sys_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_And_Validate;
   FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN  VARCHAR2,
                              p_Source_operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Wrk_ifdrftxn  IN   OUT ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists     BOOLEAN := TRUE;
   BEGIN
      Dbg('In Fn_Sys_Query_Desc_Fields..');
      Dbg('Returning Success From Fn_Sys_Query_Desc_Fields..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query_Desc_Fields ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query_Desc_Fields;
   FUNCTION Fn_Sys_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_ifdrftxn         IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Wrk_ifdrftxn  IN   OUT ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Wrk_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists        BOOLEAN := TRUE;
      RECORD_LOCKED    EXCEPTION;
      PRAGMA EXCEPTION_INIT( RECORD_LOCKED, -54 );
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER := 0;
   BEGIN
      Dbg('In Fn_Sys_Query..');
      IF p_QryData_Reqd = 'Q' THEN
         Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
         IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Wrk_ifdrftxn,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
            RETURN FALSE;
         END IF;
      ELSE
         l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'IFTB_RFT_TXN_ENQ.TXN_UNQ_NO')||'-'||
         p_ifdrftxn.v_iftb_rft_txn_enq.txn_unq_no||':'||
         Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'IFTB_RFT_TXN_ENQ.TXN_DATE')||'-'||
         TO_CHAR(p_ifdrftxn.v_iftb_rft_txn_enq.txn_date,Cspks_Req_Global.g_date_format);
         Dbg('Get The Master Record...');
         IF NVL(p_With_Lock,'N') = 'Y' THEN
            BEGIN
               SELECT *
               INTO   p_wrk_ifdrftxn.v_iftb_rft_txn_enq
               FROM  IFTB_RFT_TXN_ENQ
               WHERE txn_unq_no = p_ifdrftxn.v_iftb_rft_txn_enq.txn_unq_no
                AND txn_date = p_ifdrftxn.v_iftb_rft_txn_enq.txn_date
                FOR UPDATE NOWAIT;
            EXCEPTION
               WHEN RECORD_LOCKED THEN
                  Dbg('Failed to Obtain the Lock..');
                  Pr_Log_Error(p_Source,'ST-LOCK-001',NULL);
                  RETURN FALSE;
               WHEN No_Data_Found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  l_Rec_Exists := FALSE;
            END;

         ELSE
            BEGIN
               SELECT *
               INTO   p_Wrk_ifdrftxn.v_iftb_rft_txn_enq
               FROM  IFTB_RFT_TXN_ENQ
               WHERE txn_unq_no = p_ifdrftxn.v_iftb_rft_txn_enq.txn_unq_no
                AND txn_date = p_ifdrftxn.v_iftb_rft_txn_enq.txn_date
               ;
            EXCEPTION
               WHEN no_data_found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  p_Err_Code    := 'ST-VALS-002';
                  p_Err_Params  := l_Key;
                  RETURN FALSE;
            END;

         END IF;

         IF p_QryData_Reqd = 'Y' THEN
            Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
            IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_Wrk_ifdrftxn,
               p_Err_Code  ,
               p_Err_Params ) THEN
               Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
               RETURN FALSE;
            END IF;
         END IF;

      END IF;
      Dbg('Returning Success From Fn_Sys_Query..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query;
   FUNCTION Fn_Sys_Upload_Db         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Prev_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Wrk_ifdrftxn      IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Count             NUMBER:= 0;
      l_Ins_Count         NUMBER:= 0;
      l_Upd_Count         NUMBER:= 0;
      l_Del_Count         NUMBER:= 0;
      l_Wrk_Count         NUMBER:= 0;
      l_Prev_Count        NUMBER:= 0;
      l_Rec_Found         BOOLEAN:= FALSE;
      l_Row_Id            ROWID;
      l_Key               VARCHAR2(5000):= NULL;
      l_Auth_Stat         VARCHAR2(1) := 'A';
      l_Base_Data_From_Fc VARCHAR2(1):= 'Y';
   BEGIN
      Dbg('In Fn_Sys_Upload_Db..');
      IF p_Action_Code = Cspks_Req_Global.p_new THEN

         Dbg('Inserting Into IFTB_RFT_TXN_ENQ..');
         BEGIN
            IF  p_wrk_ifdrftxn.v_iftb_rft_txn_enq.txn_unq_no IS NOT NULL AND  p_wrk_ifdrftxn.v_iftb_rft_txn_enq.txn_date IS NOT NULL THEN
               Dbg('Record Sent..');
               INSERT INTO  IFTB_RFT_TXN_ENQ
               VALUES p_wrk_ifdrftxn.v_iftb_rft_txn_enq;
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoIFTB_RFT_TXN_ENQ..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@IFTB_RFT_TXN_ENQ';
               RETURN FALSE;
         END;
      ELSIF p_Action_Code = Cspks_Req_Global.p_modify THEN

         Dbg('Updating Single Record Node :  IFTB_RFT_TXN_ENQ..');
         BEGIN
            UPDATE IFTB_RFT_TXN_ENQ
            SET
            RESP_CODE = p_Wrk_ifdrftxn.v_iftb_rft_txn_enq.RESP_CODE,
            RESP_MSG = p_Wrk_ifdrftxn.v_iftb_rft_txn_enq.RESP_MSG
WHERE txn_unq_no = p_Wrk_ifdrftxn.v_iftb_rft_txn_enq.txn_unq_no
 AND txn_date = p_Wrk_ifdrftxn.v_iftb_rft_txn_enq.txn_date
;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Insert Into IFTB_RFT_TXN_ENQ..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@IFTB_RFT_TXN_ENQ';
               RETURN FALSE;
         END;
      ELSIF p_Action_Code = Cspks_Req_Global.p_delete THEN
         Dbg('Action Code '||p_Action_Code);
         Dbg('Deleting The Data..');

         DELETE IFTB_RFT_TXN_ENQ WHERE txn_unq_no = p_Wrk_ifdrftxn.v_iftb_rft_txn_enq.txn_unq_no
          AND txn_date = p_Wrk_ifdrftxn.v_iftb_rft_txn_enq.txn_date
         ;



      END IF;

      Dbg('Returning Success From Fn_Sys_Upload_Db');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Upload_Db;
   FUNCTION Fn_Build_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_ifdrftxn       IN   OUT ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Child_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;

   BEGIN

      Dbg('In Fn_Build_Ws_Type..');

      IF Cspks_Req_Utils.Fn_Is_Req_Fc_Format(p_Source,p_Function_Id) THEN
         IF NOT Fn_Sys_Build_Fc_Type(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_IFDRFTXN,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Fc_Type..');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT Fn_Sys_Build_Ws_Type(p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_IFDRFTXN,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Ws_Type..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTTYPE');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Post_Build_Type_Structure(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Child_Function,
            p_Addl_Info ,
            p_IFDRFTXN,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Post_Build_Type_Structure..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Build_Type..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdrftxn_Main.Fn_Build_Type ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Build_Type;
   FUNCTION Fn_Build_Ts_List (p_source    IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
      p_exchange_pattern   IN  VARCHAR2,
      p_ifdrftxn          IN ifpks_ifdrftxn_Main.ty_ifdrftxn,
      p_err_code        IN OUT VARCHAR2,
      p_err_params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Main_Function smtb_menu.function_id%TYPE := p_Function_id;

   BEGIN

      dbg('In Fn_Build_Ts_List..');

      IF Cspks_Req_Utils.Fn_Is_Res_Fc_Format(p_source,p_Function_id) THEN
         IF NOT  Fn_Sys_Build_Fc_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_ifdrftxn,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Fc_Ts');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT  Fn_Sys_Build_Ws_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_exchange_pattern,
            p_ifdrftxn,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Ws_Ts');
            RETURN FALSE;
         END IF;
      END IF;

      dbg('Returning from Fn_Build_Ts_List');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of ifpks_ifdrftxn_Main.Fn_Build_Ts_List ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := NULL;
         RETURN FALSE;
   END Fn_Build_Ts_List;
   FUNCTION Fn_Get_Key_Information (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_ifdrftxn       IN  OUT ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Key_Cols        VARCHAR2(32767);
      l_Key_Vals        VARCHAR2(32767);
      l_Func_Type       VARCHAR2(32767);
   BEGIN

      Dbg('In Fn_Get_Key_Information..');
      l_Key_Cols := 'TXN_UNQ_NO~'||'TXN_DATE~';
      l_Key_Vals := p_ifdrftxn.v_iftb_rft_txn_enq.txn_unq_no||'~'||TO_CHAR(p_ifdrftxn.v_iftb_rft_txn_enq.txn_date,Cspks_Req_Global.g_Date_Format)||'~';
      Dbg('Calling Cspks_Req_Utils.Fn_Get_Key_Information..');
      IF NOT Cspks_Req_Utils.Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code ,
         'TRANSACTION',
         'IFTB_RFT_TXN_ENQ',
         'BLK_TXN_DTLS',
         'Txn-Dtls',
         l_Key_Cols,
         l_Key_Vals,
         p_ifdrftxn.Addl_Info,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in  Cspks_Req_Utils.Fn_Get_Key_Information..');
         RETURN FALSE;
      END IF;
      IF p_ifdrftxn.Addl_Info.EXISTS('RECORD_KEY') THEN
         G_Req_Key :=  p_ifdrftxn.Addl_Info('RECORD_KEY');
      END IF;
      Dbg('Returning Succsess From Fn_Get_Key_Information..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdrftxn_Main.Fn_Get_Key_Information..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Key_Information;
   FUNCTION Fn_Check_Mandatory (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_ifdrftxn IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
     RETURN BOOLEAN IS

      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;

   BEGIN

      Dbg('In Fn_Check_Mandatory..');

      Pr_Skip_Handler('PREMAND');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Pre_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Pk_Or_Full,
            p_Function_Id  ,
            p_ifdrftxn,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  ifpks_ifdrftxn_Custom.Fn_Pre_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTMAND');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Post_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Pk_Or_Full,
            p_ifdrftxn,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Post_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Check_Mandatory..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdrftxn_Main.Fn_Check_Mandatory ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Check_Mandatory;
   FUNCTION Fn_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_ifdrftxn         IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Wrk_ifdrftxn  IN   OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);

   BEGIN

      Dbg('In Fn_Query..');

      Pr_Skip_Handler('PREQRY');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_pre_Query (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_action_code,
            p_Function_Id  ,
            p_Full_Data  ,
            p_with_lock,
            p_QryData_Reqd,
            p_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Pre_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('SYSDESC');
      IF p_QryData_Reqd = 'Y' THEN
         Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
         IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Wrk_ifdrftxn,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
            RETURN FALSE;
         END IF;
      END IF;

      Pr_Skip_Handler('POSTQRY');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Post_Query (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Function_Id  ,
            p_Full_Data  ,
            p_with_lock ,
            p_QryData_Reqd,
            p_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Post_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Query..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Query;
   FUNCTION Fn_Resolve_Ref_Numbers         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_ifdrftxn     IN OUT ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

   BEGIN

      Dbg('In Fn_Resolve_Ref_Numbers..');

      Pr_Skip_Handler('PREMAND');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Pre_Resolve_Ref_Numbers (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_ifdrftxn,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Pre_Resolve_Ref_Numbers..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTMAND');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Post_Resolve_Ref_Numbers (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_ifdrftxn,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Post_Resolve_Ref_Numbers..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Resolve_Ref_Numbers..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Resolve_Ref_Numbers ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Resolve_Ref_Numbers;
   FUNCTION Fn_Product_Default         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Wrk_ifdrftxn      IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'IFDRFTXN';
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Row_Id            ROWID;
      l_Key  VARCHAR2(32767);
      l_Key_Id  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Product_Default..');

      Pr_Skip_Handler('PREPRDDFLT');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Pre_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Pre_Product_Default..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
      IF NOT Fn_Sys_Query_Desc_Fields(p_Source,
         p_Source_Operation,
         p_Function_Id,
         Cspks_Req_Global.p_prddflt,
         p_Wrk_ifdrftxn,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('POSTPRDDFLT');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Post_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Post_Product_Default..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Product_Default..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdrftxn_Main.Fn_Product_Default ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Product_Default;
   FUNCTION Fn_Unlock         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN  OUT  VARCHAR2,
      p_ifdrftxn     IN  ifpks_ifdrftxn_Main.ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'IFDRFTXN';


   BEGIN

      Dbg('In Fn_Unlock..');

      Pr_Skip_Handler('PREUNLOCK');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Pre_Unlock (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code ,
            p_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Pre_Unlock..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTUNLOCK');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Post_Unlock (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code ,
            p_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Post_Unlock..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Unlock..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdrftxn_Main.Fn_Unlock ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Unlock;
   FUNCTION Fn_Subsys_Pickup         (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Prev_ifdrftxn IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Wrk_ifdrftxn      IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'IFDRFTXN';


   BEGIN

      Dbg('In Fn_Subsys_Pickup..');

      Pr_Skip_Handler('PRESUBSYSPKP');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Pre_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_ifdrftxn,
            p_Prev_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Pre_Subsys_Pickup..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTSUBSYSPKP');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Post_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_ifdrftxn,
            p_prev_ifdrftxn,
            p_wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Post_Subsys_Pickup ..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Subsys_Pickup..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdrftxn_Main.Fn_Subsys_Pickup ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Subsys_Pickup;
   FUNCTION Fn_Enrich         (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Prev_ifdrftxn IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Wrk_ifdrftxn      IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'IFDRFTXN';


   BEGIN

      Dbg('In Fn_Enrich..');

      Pr_Skip_Handler('PREENRICH');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Pre_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_ifdrftxn,
            p_Prev_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom. Fn_Pre_Enrich..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Calling in Fn_Sys_Query_Desc_Field..');
      IF NOT Fn_Sys_Query_Desc_Fields(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Wrk_ifdrftxn,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Sys_Query_Desc_Field..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('POSTENRICH');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Post_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_ifdrftxn,
            p_Prev_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Post_Enrich..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning  Success From Fn_Enrich..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of ifpks_ifdrftxn_Main.Fn_Enrich ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Enrich;
   FUNCTION Fn_Default_And_Validate        (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN OUT    VARCHAR2,
      p_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Prev_ifdrftxn IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Wrk_ifdrftxn IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Source_Operation       VARCHAR2(100) := p_source_Operation;
      l_Full_Data    VARCHAR2(1) := 'N';
      l_With_Lock    VARCHAR2(1) := 'Y';
      l_Qrydata_Reqd    VARCHAR2(1) := 'N';
      l_Pk_Or_Full      VARCHAR2(10) := 'FULL';


   BEGIN

      Dbg('In Fn_Default_And_Validate..');

      l_Full_data   := 'Y';
      Dbg('Calling  Fn_Query..');
      IF NOT Fn_Query(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         l_Full_data,
         l_With_Lock,
         l_Qrydata_Reqd,
         p_ifdrftxn,
         p_Prev_ifdrftxn,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Query..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('PREDFLT');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Pre_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_ifdrftxn,
            p_Prev_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Pre_Default_And_Validate');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTDFLT');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Post_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_ifdrftxn,
            p_Prev_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in  ifpks_ifdrftxn_Custom.Fn_Post_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_Modify THEN
         Dbg('Calling  Fn_Check_Mandatory..');
         IF NOT Fn_Check_Mandatory(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Pk_Or_Full,
            p_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Check_Mandatory..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdrftxn_Main.Fn_default_and_validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Default_And_Validate;
   FUNCTION Fn_Upload_Db  (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Prev_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Wrk_ifdrftxn      IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_id;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Row_Id            ROWID;
      l_Key  VARCHAR2(32767);
      l_Key_Id  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Upload_Db..');

      Pr_Skip_Handler('PREUPLD');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Pre_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_ifdrftxn,
            p_Prev_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTUPLD');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Post_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_action_code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_ifdrftxn,
            p_Prev_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Post_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success  From Fn_Upload_Db..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdrftxn_Main.Fn_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Upload_Db;
   FUNCTION Fn_Process         (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Prev_ifdrftxn     IN  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Wrk_ifdrftxn      IN OUT  ifpks_ifdrftxn_Main.Ty_ifdrftxn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'IFDRFTXN';
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;


   BEGIN

      Dbg('In Fn_Process..');

      Pr_Skip_Handler('PREPROCESS');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Pre_Process (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_multi_trip_id,
            p_ifdrftxn,
            p_Prev_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in  ifpks_ifdrftxn_Custom.Fn_Pre_Process..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTPROCESS');
      IF NOT ifpks_ifdrftxn_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdrftxn_Custom.Fn_Post_Process (p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_ifdrftxn,
            p_Prev_ifdrftxn,
            p_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdrftxn_Custom.Fn_Post_Process..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Process..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdrftxn_Main.Fn_Process ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Process;
   FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;

   BEGIN

      Dbg('In Fn_Rebuild_Ts_List..');
      IF NOT  Fn_Build_Ts_List(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Exchange_Pattern,
         g_ifdrftxn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List..');
         p_Status      := 'F';
         RETURN FALSE;
      END IF;
      Dbg('Returning Success From Fn_Rebuild_Ts_List..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Rebuild_Ts_List..');
         p_Status        := 'F';
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Rebuild_Ts_List..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Rebuild_Ts_List;

   FUNCTION Fn_Get_Node_Data (
      p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Cntr NUMBER := 0;
   BEGIN

      Dbg('In Fn_Get_Node_Data..');
      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_TXN_DTLS';
      p_Node_Data(l_Cntr).Xsd_Node := 'Txn-Dtls';
      p_Node_Data(l_Cntr).Node_Parent := '';
      p_Node_Data(l_Cntr).Node_Relation_Type := '1';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'TXN_UNQ_NO~TXN_DATE~RESP_CODE~RESP_MSG~';
      p_Node_Data(l_Cntr).Node_Tags := 'TXN_UNQ_NO~TNR_DT~RESP_CODE~RESP_MSG~';

      Dbg('Returning From Fn_Get_Node_Data.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of ifpks_ifdrftxn_Main.Fn_Get_Node_Data..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Node_Data;
   FUNCTION Fn_Main       (p_Source            IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_ifdrftxn          IN OUT ifpks_ifdrftxn_Main.Ty_ifdrftxn,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      E_Override_Exception    EXCEPTION;
      E_Hold_Exception        EXCEPTION;
      l_Post_Upl_Stat    VARCHAR2(1) :='A';
      l_Resultant_Error_Type  VARCHAR2(32767):= 'I';
      l_action_code           VARCHAR2(100) := p_Action_Code;
      l_Wrk_ifdrftxn     ifpks_ifdrftxn_Main.Ty_ifdrftxn;
      l_Prev_ifdrftxn    ifpks_ifdrftxn_Main.Ty_ifdrftxn;
      l_Dmy_ifdrftxn    ifpks_ifdrftxn_Main.Ty_ifdrftxn;
      l_Pk_Or_Full    VARCHAR2(5) :='PK';
      l_Full_Data    VARCHAR2(1) := 'Y';
      l_With_Lock    VARCHAR2(1) := 'N';
      l_Qrydata_Reqd    VARCHAR2(1) := 'Y';
      l_Count         NUMBER;
      l_Rollback_Reqd    VARCHAR2(1) := 'N';
      l_Prev_Auth_Stat        VARCHAR2(1) :='U';

   BEGIN

      Dbg('In Fn_Main');

      SAVEPOINT Sp_Main_Ifdrftxn;
      p_Status := 'S';
      g_Addl_Info.DELETE;
      g_ifdrftxn := p_ifdrftxn;
      g_Original_Action := p_Action_Code ;
      g_Action_Code :=  p_Action_Code ;

      Dbg('Calling  Fn_Resolve_Ref_Numbers..');
      IF NOT Fn_Resolve_Ref_Numbers(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_ifdrftxn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Resolve_Ref_Numbers..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      Dbg('Calling in Fn_Unlock..');
      IF NOT Fn_Unlock(p_Source,
         p_Source_Operation,
         p_Function_Id,
         l_Action_Code,
         p_ifdrftxn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Unlock..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      Dbg('Calling  Fn_Check_Mandatory..');
      IF NOT Fn_Check_Mandatory(p_Source,
         p_Source_Operation,
         p_Function_Id,
         l_Action_Code,
         l_Pk_Or_Full,
         p_ifdrftxn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      Dbg('Calling  Fn_Get_Key_Information..');
      IF NOT  Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_ifdrftxn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Get_Key_Information..');
         RAISE e_Failure_Exception;
      END IF;
      IF p_Action_Code  = Cspks_Req_Global.p_Query THEN
         Dbg('Calling Fn_Query..');
         IF NOT Fn_Query(p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            l_Full_data,
            l_With_Lock,
            l_Qrydata_Reqd,
            p_ifdrftxn,
            l_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Query..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;
      ELSIF p_Action_code  = Cspks_Req_Global.p_Prddflt THEN
         Dbg('Calling  Fn_Product_Default..');
         Dbg('Failed in Fn_Product_Default..');
         IF NOT Fn_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_ifdrftxn,
            l_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Product_Default..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

      ELSIF SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_SubsysPickup))  = Cspks_Req_Global.p_SubsysPickup THEN
         Dbg('Calling  Fn_Subsys_Pickup..');
         IF NOT Fn_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_ifdrftxn,
            l_Prev_ifdrftxn,
            l_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Subsys_Pickup..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

      ELSIF SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_Enrich))  = Cspks_Req_Global.p_Enrich THEN
         Dbg('Calling  Fn_Enrich..');
         IF NOT Fn_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_ifdrftxn,
            l_Prev_ifdrftxn,
            l_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Enrich..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

      ELSE
         IF NOT Fn_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_ifdrftxn,
            l_Prev_ifdrftxn,
            l_Wrk_ifdrftxn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Default_And_Validate..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

         -- Get Resultant Error Type
         g_autoauth := 'U';
         l_Resultant_Error_Type := Cspks_Req_Utils.Fn_Get_Resultant_Error_Type;
         IF l_Resultant_Error_Type <> 'E' THEN
            Dbg('Calling  Fn_Upload_Db..');
            IF NOT Fn_Upload_Db (p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               p_Multi_Trip_Id,
               p_ifdrftxn,
               l_Prev_ifdrftxn,
               l_Wrk_ifdrftxn,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Upload_Db..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
            Dbg('Calling  Fn_Process..');
            IF NOT Fn_Process (p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               p_Multi_Trip_Id,
               p_ifdrftxn,
               l_Prev_ifdrftxn,
               l_Wrk_ifdrftxn,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Process..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
            IF  l_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen,Cspks_Req_Global.p_Reverse,Cspks_Req_Global.p_Rollover,Cspks_Req_Global.p_Confirm,Cspks_Req_Global.p_Liquidate ) THEN
               l_Prev_Auth_Stat := 'A';
               --Get Upload Status
               Dbg('Calling Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
               IF NOT Cspks_Req_Utils.Fn_Get_Auto_Auth_Status (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  l_Action_Code,
                  l_Prev_Auth_Stat,
                  p_Multi_Trip_Id,
                  P_Request_No,
                  l_Post_Upl_Stat,
                  p_Err_Code,
                  p_Err_Params) THEN
                  Dbg('Failed in Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
                  Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                  RAISE E_Failure_Exception;
               END IF;

               IF l_Post_Upl_Stat = 'A'THEN
                  Dbg('Calling Fn_Process With Auth as Action Code..');
                  IF NOT Fn_Process (p_Source,
                     p_Source_Operation,
                     p_Function_Id,
                     Cspks_Req_Global.p_Auth,
                     p_Multi_Trip_Id,
                     l_Wrk_ifdrftxn,
                     l_Prev_ifdrftxn,
                     l_Wrk_ifdrftxn,
                     p_Err_Code,
                     p_Err_Params) THEN
                     Dbg('Failed in Fn_Process..');
                     Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                     RAISE E_Failure_Exception;
                  END IF;
               END IF;
            END IF;
         END IF;
      END IF;
      --Get Upload Status
      Dbg('Calling Cspks_Req_Utils.Fn_Get_Upload_Status..');
      IF NOT Cspks_Req_Utils.Fn_Get_Upload_Status (p_Source,
         p_Source_Operation,
         p_Function_Id,
         l_Action_Code,
         p_Multi_Trip_Id,
         P_Request_No,
         l_Post_Upl_Stat,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_Upload_Status..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      IF l_Post_Upl_Stat IN('A','U') THEN
         p_status := 'S';
         IF p_Action_code  <> Cspks_Req_Global.p_Prddflt AND
            SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_Enrich))  <> Cspks_Req_Global.p_Enrich THEN
            Dbg('Calling  Fn_Query..');
            IF NOT Fn_Query(p_source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               l_Full_Data,
               l_With_Lock,
               l_Qrydata_Reqd,
               p_ifdrftxn,
               l_Wrk_ifdrftxn,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Query..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
         END IF;
      ELSIF l_Post_Upl_Stat ='O' THEN
         Dbg('New/First time Overides..');
         p_Status := 'O';
         RAISE E_Override_Exception;
      ELSIF l_Post_Upl_Stat = 'H'    THEN
         Dbg('Keeping on Hold..');
         RAISE E_Hold_Exception;
      ELSE
         Dbg('Not Feasible to Upload The Data...');
         RAISE E_Failure_Exception;
      END IF;
      IF p_Action_Code  = Cspks_Req_Global.p_Prddflt OR
         p_Action_Code  = Cspks_Req_Global.p_Copy OR
         SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_Enrich))  = Cspks_Req_Global.p_Enrich OR
         SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_SubsysPickup))  = Cspks_Req_Global.p_SubsysPickup THEN
         ROLLBACK TO Sp_Main_Ifdrftxn;
      END IF;

      p_ifdrftxn := l_Wrk_ifdrftxn;
      g_ifdrftxn := l_Wrk_ifdrftxn;
      Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
      Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
      Dbg('Errors     :'||p_Err_Code);
      Dbg('Parameters :'||p_Err_Params);

      Dbg('Returning Success From Fn_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Main');
         p_Status        := 'F';
         l_Post_Upl_Stat := 'F';
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN E_Override_Exception THEN
         Dbg('From E_Override_Exception of Fn_Main..');
         p_Status        := 'O';
         l_Post_Upl_Stat := 'O';
         IF NOT Cspks_Req_Utils.Fn_Log_Overrides(p_Multi_Trip_Id, p_Request_No, p_Err_Code, p_Err_Params) THEN
            Dbg('Failed inCspks_Req_Utils.Fn_Log_Overrides..');
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
         END IF;
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN E_Hold_Exception THEN
         Dbg('From E_Hold_Exception of Fn_Main..');
         l_Post_Upl_Stat := 'H';
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         ROLLBACK TO Sp_Main_Ifdrftxn;
         IF NOT  Fn_main(p_Source,
            p_Source_operation,
            p_Function_Id,
            Cspks_Req_Global.p_Hold,
            p_Multi_Trip_Id,
            p_Request_No,
            p_ifdrftxn,
            p_Status,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_main..');
            RETURN FALSE;
         END IF;

         RETURN TRUE;

      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Main ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Main;

   FUNCTION Fn_Process_Request (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_ifdrftxn     ifpks_ifdrftxn_Main.ty_ifdrftxn;

   BEGIN

      Dbg('In Fn_Process_Request ..');
      IF NOT  Fn_Build_Type(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_Addl_Info,
         l_ifdrftxn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Type..');
         p_Status      := 'F';
         RETURN FALSE;
      END IF;
      IF NOT  Fn_Main(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Multi_Trip_Id,
         p_Request_No,
         l_ifdrftxn,
         p_Status,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_main..');
         RETURN FALSE;
      END IF;

      p_Addl_Info := l_ifdrftxn.Addl_Info;
      Cspks_Req_Global.Pr_Reset;
      Dbg('Calling  Fn_Build_Ts_List..');
      IF NOT  Fn_Build_Ts_List(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Exchange_Pattern,
         l_ifdrftxn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List..');
         p_Status      := 'F';
         RETURN FALSE;
      END IF;
      Cspks_Req_Global.Pr_Close_Ts;
      Dbg('Returning Success From Fn_Process_Request ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Process_Request..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Process_Request;

END ifpks_ifdrftxn_main;
/