CREATE OR REPLACE PACKAGE BODY ifpks_ifdrftxn_custom AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : ifpks_ifdrftxn_custom.sql
     **
     ** Module     : Interfaces
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     -------------------------------------------------------------------------------------------------------
     */
     

   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      IF debug.pkg_debug_on <> 2 THEN
         l_Msg := 'ifpks_ifdrftxn_Custom ==>'||p_Msg;
         Debug.Pr_Debug('IF' ,l_Msg);
      END IF;
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,p_Function_Id,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      Dbg('In Pr_Skip_Handler');
   END Pr_Skip_Handler;
   FUNCTION fn_Post_build_type_structure (p_source    IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_addl_info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_ifdrftxn     IN  OUT ifpks_ifdrftxn_Main.ty_ifdrftxn,
      p_err_code          IN OUT VARCHAR2,
      p_err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      dbg('In fn_Post_build_type_structure');

      dbg('Returning Success from fn_Post_build_type_structure');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of ifpks_ifdrftxn_Custom.fn_Post_build_type_structure ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := NULL;
         RETURN FALSE;
   END fn_Post_build_type_structure;

   FUNCTION Fn_main       (p_source            IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
                              p_Child_Function    IN     VARCHAR2,
                              p_multi_trip_id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_ifdrftxn          IN OUT  ifpks_ifdrftxn_Main.ty_ifdrftxn,
                              p_status            IN OUT VARCHAR2 ,
                              p_err_code          IN OUT VARCHAR2,
                              p_err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      E_Failure_Exception    EXCEPTION;
      E_Override_Exception   EXCEPTION;

   BEGIN

      dbg('In Fn_main');

      SAVEPOINT Sp_Main_Ifdrftxn_custom;
      dbg('Returning Success From Fn_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         dbg('From E_Failure_Exception of Fn_Main');
         ROLLBACK TO Sp_Main_Ifdrftxn_custom;
         p_status        := 'F';
         dbg('Errors     :'||p_err_code);
         dbg('Parameters :'||p_err_params);
         RETURN FALSE;

      WHEN E_Override_Exception THEN
         dbg('From E_Override_Exception of Fn_Main');
         p_status        := 'O';
         dbg('Errors     :'||p_err_code);
         dbg('Parameters :'||p_err_params);
         RETURN FALSE;

      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of ifpks_ifdrftxn_Custom.Fn_Main ..');
         debug.pr_debug('**',SQLERRM);
         p_status      := 'F';
         ROLLBACK TO Sp_Main_Ifdrftxn_custom;
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := NULL;
         RETURN FALSE;
   END Fn_Main;


END ifpks_ifdrftxn_custom;
/