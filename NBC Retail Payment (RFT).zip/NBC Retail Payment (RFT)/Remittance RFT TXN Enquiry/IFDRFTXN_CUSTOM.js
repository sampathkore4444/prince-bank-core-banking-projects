function fnPostEnterQuery_CUSTOM()
{
  document.getElementById("BLK_TXN_DETAILS__DATE_FIELD1").enabled = true;
  return true;
}