CREATE OR REPLACE PACKAGE BODY IFPKS_RFT_TXN_UTLS IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_RFT_TXN_UTLS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;
  
  PROCEDURE FN_GET_RFT_MOB_TRN_NO(P_RFTPASSCODE IN VARCHAR2,
                                 P_TXN_UNQ_NO  IN VARCHAR2,
                                 P_TRN_REF_NO  OUT VARCHAR2,
                                 P_XREF_NO     OUT VARCHAR2) IS -- RETURN BOOLEAN IS
  
    L_TRN_REF_NO IFTB_RFT_MASTER_MOB.TRN_REF_NO%TYPE;
  
    L_XREFNO DETB_RTL_TELLER.XREF%TYPE;
  
  BEGIN
  
    DEBUG.PR_DEBUG('IF', 'START OF FN_GET_RFT_MOB_TRN_NO');
  
    BEGIN
      SELECT TRN_REF_NO
        INTO L_TRN_REF_NO
        FROM IFTB_RFT_MASTER_MOB A
       WHERE A.PASS_CODE = P_RFTPASSCODE
         AND A.TXN_UNQ_NO = P_TXN_UNQ_NO
         AND A.AUTH_STAT = 'A'
         AND A.RECORD_STAT = 'O';
    
    EXCEPTION
      WHEN OTHERS THEN
        L_TRN_REF_NO := NULL;
    END;
  
    DEBUG.PR_DEBUG('IF', 'L_TRN_REF_NO=' || L_TRN_REF_NO);
  
    P_TRN_REF_NO := L_TRN_REF_NO;
  
    BEGIN
      SELECT XREF
        INTO L_XREFNO
        FROM DETB_RTL_TELLER A
       WHERE A.TRN_REF_NO = P_TRN_REF_NO;
    
    EXCEPTION
      WHEN OTHERS THEN
        L_XREFNO := NULL;
    END;
  
    DEBUG.PR_DEBUG('IF', 'L_XREFNO=' || L_XREFNO);
  
    P_XREF_NO := L_XREFNO;
  
    /*IF P_TRN_REF_NO IS NOT NULL AND P_XREF_NO IS NOT NULL THEN
    
      RETURN TRUE;
    
    ELSE
    
      RETURN FALSE;
    
    END IF;*/
  
    DEBUG.PR_DEBUG('IF', 'END OF FN_GET_RFT_MOB_TRN_NO');
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF', 'FAILED IN FN_GET_RFT_MOB_TRN_NO');
      DEBUG.PR_DEBUG('IF', 'ERROR CODE=' || SQLCODE);
      DEBUG.PR_DEBUG('IF', 'ERROR MESSAGE=' || SQLERRM);
    
  END FN_GET_RFT_MOB_TRN_NO;
  
  
/*
  FUNCTION FN_GET_RFT_MOB_TRN_NO(P_RFTPASSCODE IN VARCHAR2,
                                 P_TXN_UNQ_NO  IN VARCHAR2)
    RETURN IFTB_RFT_MASTER_MOB.TRN_REF_NO%TYPE IS

    L_TRN_REF_NO IFTB_RFT_MASTER_MOB.TRN_REF_NO%TYPE;

  BEGIN

    DEBUG.PR_DEBUG('IF', 'START OF FN_GET_RFT_MOB_TRN_NO');

    BEGIN
      SELECT TRN_REF_NO
        INTO L_TRN_REF_NO
        FROM IFTB_RFT_MASTER_MOB A
       WHERE A.PASS_CODE = P_RFTPASSCODE
         AND A.TXN_UNQ_NO = P_TXN_UNQ_NO
         AND A.AUTH_STAT = 'A'
         AND A.RECORD_STAT = 'O';

    EXCEPTION
      WHEN OTHERS THEN
        L_TRN_REF_NO := NULL;
    END;

    DEBUG.PR_DEBUG('IF', 'L_TRN_REF_NO=' || L_TRN_REF_NO);

    DEBUG.PR_DEBUG('IF', 'END OF FN_GET_RFT_MOB_TRN_NO');

    RETURN L_TRN_REF_NO;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF', 'FAILED IN FN_GET_RFT_MOB_TRN_NO');
      DEBUG.PR_DEBUG('IF', 'ERROR CODE=' || SQLCODE);
      DEBUG.PR_DEBUG('IF', 'ERROR MESSAGE=' || SQLERRM);

  END FN_GET_RFT_MOB_TRN_NO;
  */

  PROCEDURE PR_PRINT_ACCTNG_TABLE(P_ACC_HAND IN ACPKS.TBL_ACHOFF) IS
    I      NUMBER;
    L_ROW  VARCHAR2(500);
    L_LINE VARCHAR2(500);
  BEGIN

    SELECT RPAD('-',
                20 + 15 + 15 + 15 + 15 + 1 + 1 + 3 + 3 + 3 + 6 + 3,
                '-')
      INTO L_LINE
      FROM DUAL;
    DBG(L_LINE);
    SELECT '|' || RPAD('Tag', 10, '.') || '|' || RPAD('Brn', 3, '.') || '|' ||
           RPAD('Acc', 20, '.') || '|' || RPAD('Lcy Amt', 15, '.') || '|' ||
           RPAD('Fcy Amt', 15, '.') || '|' || RPAD('Exch Rate', 15, '.') || '|' ||
           RPAD('D/C', 1, '.') || '|' || RPAD('Netting', 1, '.') || '|' ||
           RPAD('Ccy', 3, '.') || '|' || RPAD('TrnCode', 3, '.') || '|' ||
           RPAD('Brn', 3, '.') || '|'
      INTO L_ROW
      FROM DUAL;
    DBG(L_ROW);
    DBG(L_LINE);

    FOR I IN 1 .. P_ACC_HAND.COUNT LOOP
      IF P_ACC_HAND.EXISTS(I) THEN
        SELECT '|' || RPAD(P_ACC_HAND(I).AMOUNT_TAG, 10, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_BRANCH, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_NO, 20, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).LCY_AMOUNT, -1111), 15, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).FCY_AMOUNT, -1111), 15, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).EXCH_RATE, -1111), 15, '.') || '|' ||
               RPAD(P_ACC_HAND(I).DRCR_IND, 1, '.') || '|' ||
               RPAD(P_ACC_HAND(I).NETTING_IND, 1, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_CCY, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).TRN_CODE, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_BRANCH, 3, '.') || '|'
          INTO L_ROW
          FROM DUAL;
        DBG(L_ROW);
        DBG(L_LINE);
      END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN;
  END PR_PRINT_ACCTNG_TABLE;

  PROCEDURE PR_CHARGE_REVERSAL(P_AC_ENTS IN OUT NOCOPY ACPKS.TBL_ACHOFF) IS

    L_INDEX       NUMBER;
    L_REV_REQD    VARCHAR2(1);
    L_NET_CHARGES VARCHAR2(1);
    L_CHG_FROM    VARCHAR2(3);
    L_AMT_SUM     NUMBER;
    L_CONTRA_LEG  NUMBER;
    L_PROD        VARCHAR2(4);

    L_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM VARCHAR2(250);

  BEGIN

    DBG('inside pr_chrge_reversal with product as ');

    BEGIN
      SELECT PRODUCT_CODE
        INTO L_PROD
        FROM DETB_RTL_TELLER
       WHERE TRN_REF_NO = P_AC_ENTS(1).TRN_REF_NO;

      DBG('Calling Fn_Get_Detm_Rt_Pref_Rec_Wrp...for the product...' ||
          L_PROD);
      IF NOT
          CSPKSS_FUNCTION_CACHE.FN_GET_DETM_RT_PREF_REC_WRP(L_PROD,
                                                            L_ERR_CODE,
                                                            L_ERR_PARAM) THEN
        IF L_ERR_CODE = 'CS-FRC-001' THEN
          DBG('No data Found exception so assignin value as Y ..');
          L_REV_REQD  := 'Y';
          L_ERR_CODE  := NULL;
          L_ERR_PARAM := NULL;
        ELSE
          DBG('In others exception..');
          L_ERR_CODE  := NULL;
          L_ERR_PARAM := NULL;
          DBG('Proceed..');
        END IF;
      ELSE
        L_REV_REQD := NVL(CSPKSS_FUNCTION_CACHE.G_TBL_DETM_RT_PREF_REC.REVERSAL_INCLUDES_CHARGES,
                          'N');
        DBG('Value of l_rev_reqd is - ' || L_REV_REQD);
      END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_REV_REQD := 'Y';
      WHEN OTHERS THEN
        DBG('Failed while checking if charge reversal is required');

    END;

    DBG('GWPKS_UTIL.G_REJECTFLAG => ' || GWPKS_UTIL.G_REJECTFLAG);

    IF L_REV_REQD = 'N' OR NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' THEN
      BEGIN
        SELECT NVL(COD_NET_CHARGES, 'Y')
          INTO L_NET_CHARGES
          FROM IFTMS_ARC_MAINT
         WHERE COD_PROD_ACC_CLS = L_PROD;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_NET_CHARGES := 'N';
        WHEN OTHERS THEN
          DBG('Failed while checking if charge netting is required');

      END;
      DBG('l_net_charges => ' || L_NET_CHARGES);
      IF L_NET_CHARGES = 'Y' THEN
        BEGIN

          SELECT CHG_CONTRA_LEG
            INTO L_CHG_FROM
            FROM DETBS_RTL_TELLER
           WHERE TRN_REF_NO = P_AC_ENTS(1).TRN_REF_NO;

        END;
        L_AMT_SUM := 0;

        IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
          DBG('INSIDE THE LOOP TO FETCH THE CHARGES');
          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF P_AC_ENTS(L_INDEX)
             .AMOUNT_TAG IN
                ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
              DBG('l_index ' || L_INDEX);
              DBG('p_ac_ents(l_index).AMOUNT_TAG => ' || P_AC_ENTS(L_INDEX)
                  .AMOUNT_TAG);
              L_AMT_SUM := L_AMT_SUM + P_AC_ENTS(L_INDEX).LCY_AMOUNT;
            END IF;

          END LOOP;
          DBG('OUT OF THE LOOP WITH l_amt_sum :- ' || L_AMT_SUM);

        ELSE

          DBG('INSIDE THE ELSE PART');
          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF P_AC_ENTS(L_INDEX)
             .AMOUNT_TAG IN ('CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
              L_AMT_SUM := L_AMT_SUM + P_AC_ENTS(L_INDEX).LCY_AMOUNT;
            END IF;

          END LOOP;

        END IF;

        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
          IF P_AC_ENTS(L_INDEX).AMOUNT_TAG = (L_CHG_FROM || '_AMT') THEN
            P_AC_ENTS(L_INDEX).LCY_AMOUNT := P_AC_ENTS(L_INDEX)
                                             .LCY_AMOUNT - L_AMT_SUM;
          END IF;
        END LOOP;

      END IF;

      IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
        DBG('GOING FOR THE LOOP TO DLETE THE CHARGE ENTRIES');

        BEGIN
          DBG('pr_print_acctng_table is cmd in begin.....');
          PR_PRINT_ACCTNG_TABLE(P_AC_ENTS);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In OTHERS with line tracking  ::::: ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        END;

        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
          IF P_AC_ENTS(L_INDEX)
           .AMOUNT_TAG IN
              ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
            DBG('l_index ' || L_INDEX);
            DBG('p_ac_ents(l_index).AMOUNT_TAG => ' || P_AC_ENTS(L_INDEX)
                .AMOUNT_TAG);
            P_AC_ENTS.DELETE(L_INDEX);
          END IF;
        END LOOP;
        DBG('OUT OF LOOP');

        IF (P_AC_ENTS.COUNT > 2) AND GWPKS_UTIL.PKG_FUNC = 'LOCH' THEN

          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF L_INDEX > 2 THEN
              DBG('Removing the other entries when l_index for reject is ' ||
                  L_INDEX);
              P_AC_ENTS.DELETE(L_INDEX);
            END IF;
          END LOOP;
        END IF;

      ELSE

        /*--sampath starts
        dbg('before deleting charge entries=' || P_AC_ENTS.COUNT);
        dbg('before deleting charge FIRST=' || P_AC_ENTS.FIRST);
        dbg('before deleting charge LAST=' || P_AC_ENTS.LAST);

        FOR L_RECNO1 IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP

          DBG('P_AC_ENTS(L_RECNO1).AC_ENTRY_SR_NO=' || P_AC_ENTS(L_RECNO1)
              .AC_ENTRY_SR_NO);

          DBG('P_AC_ENTS(L_RECNO1).EVENT_SR_NO=' || P_AC_ENTS(L_RECNO1)
              .EVENT_SR_NO);

          DBG('P_AC_ENTS(L_RECNO1).EVENT=' || P_AC_ENTS(L_RECNO1).EVENT);
          DBG('P_AC_ENTS(L_RECNO1).FCY_AMOUNT=' || P_AC_ENTS(L_RECNO1)
              .FCY_AMOUNT);
          DBG('P_AC_ENTS(L_RECNO1).LCY_AMOUNT=' || P_AC_ENTS(L_RECNO1)
              .LCY_AMOUNT);
          DBG('P_AC_ENTS(L_RECNO1).TRN_DT=' || P_AC_ENTS(L_RECNO1).TRN_DT);
          DBG('P_AC_ENTS(L_RECNO1).USER_ID=' || P_AC_ENTS(L_RECNO1)
              .USER_ID);

          DBG('P_AC_ENTS(L_RECNO1).AMOUNT_TAG=' || P_AC_ENTS(L_RECNO1)
              .AMOUNT_TAG);

          DBG('P_AC_ENTS(L_RECNO1).AC_BRANCH=' || P_AC_ENTS(L_RECNO1)
              .AC_BRANCH);

        END LOOP;
        --sampath ends*/

        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP

          IF P_AC_ENTS(L_INDEX)
           .AMOUNT_TAG IN ('CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
            P_AC_ENTS.DELETE(L_INDEX);

          END IF;
        END LOOP;

        /*--sampath starts
        dbg('after deleting charge entries=' || P_AC_ENTS.COUNT);
        dbg('after deleting charge FIRST=' || P_AC_ENTS.FIRST);
        dbg('after deleting charge LAST=' || P_AC_ENTS.LAST);

        FOR L_RECNO1 IN P_AC_ENTS.FIRST .. P_AC_ENTS.COUNT LOOP
          DBG('L_RECNO1='||L_RECNO1);
          DBG('P_AC_ENTS(L_RECNO1).EVENT=' || P_AC_ENTS(L_RECNO1).EVENT);

          DBG('P_AC_ENTS(L_RECNO1).LCY_AMOUNT=' || P_AC_ENTS(L_RECNO1)
              .LCY_AMOUNT);
          DBG('P_AC_ENTS(L_RECNO1).TRN_DT=' || P_AC_ENTS(L_RECNO1).TRN_DT);

          DBG('P_AC_ENTS(L_RECNO1).AMOUNT_TAG=' || P_AC_ENTS(L_RECNO1)
              .AMOUNT_TAG);

          DBG('P_AC_ENTS(L_RECNO1).AC_BRANCH=' || P_AC_ENTS(L_RECNO1)
              .AC_BRANCH);

        END LOOP;
        --sampath ends*/

      END IF;
    END IF;

  END PR_CHARGE_REVERSAL;

  PROCEDURE PR_UPDATE_TRACKED_BALANCES(P_CONTRACT_REF_NO IN CSTB_CONTRACT.CONTRACT_REF_NO%TYPE) IS

    CURSOR CR_UPDATE_BALANCES IS
      SELECT *
        FROM CSTB_AUTO_SETTLE_BLOCK
       WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO
         AND AMOUNT_DUE != AMOUNT_PAID;
    L_AMOUNT_TO_BE_RELEASED NUMBER(22, 3) := 0;

  BEGIN

    FOR REC IN CR_UPDATE_BALANCES LOOP

      L_AMOUNT_TO_BE_RELEASED := REC.AMOUNT_AVAILABLE;

      DBG('account is :::: ' || REC.ACCOUNT_NO);

      DBG('L_AMOUNT_TO_BE_RELEASED is :::: ' || L_AMOUNT_TO_BE_RELEASED);

      ACPKS_CUSTBAL_PROCESS.PR_UPDATE_RECEIVABLE_AMT(REC.ACCOUNT_NO,
                                                     REC.ACCOUNT_BR,
                                                     'D',
                                                     L_AMOUNT_TO_BE_RELEASED);
      DEBUG.PR_DEBUG('LD', 'after updating recievable');

    END LOOP;

    INSERT INTO CSTB_AUTO_SETTLE_BLOCK_TEMP
      (SELECT *
         FROM CSTB_AUTO_SETTLE_BLOCK
        WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO);

    DBG('umber of rows iserted IN TEMP are :::: ' || SQL%ROWCOUNT);
    DELETE CSTB_AUTO_SETTLE_BLOCK
     WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO;

  END PR_UPDATE_TRACKED_BALANCES;

  FUNCTION FN_REVERSE(P_TRN_REF_NO IN VARCHAR2,
                      P_ERR_CODE   IN OUT VARCHAR2,
                      P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_AUTH_STAT        DETBS_RTL_TELLER.AUTH_STAT%TYPE;
    L_AC_ENTS          ACPKS.TBL_ACHOFF;
    L_ROWID            ROWID;
    L_AUTHORISE        VARCHAR2(1);
    L_CHECKER_DT_STAMP DATE;
    L_TRACK_RECEIVABLE VARCHAR2(1);
    L_SCODE            DETBS_RTL_TELLER.SCODE%TYPE;
    L_CHECK_ENTRIES    BOOLEAN := TRUE;
    L_SETTLE_COUNT     NUMBER := 0;
    L_ON_ERROR         BOOLEAN := FALSE;
    L_BOOK_DATE        DATE;

    L_ACC_TYPE_1   VARCHAR2(20);
    L_ACC_TYPE_2   VARCHAR2(20);
    L_BRANCH       DETBS_RTL_TELLER.BRANCH_CODE%TYPE;
    L_PRODUCT_CODE DETBS_RTL_TELLER.PRODUCT_CODE%TYPE;
    L_MODULE       CSTM_PRODUCT.MODULE%TYPE;
    V_TBL_RESTR    STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR;
    L_EVENT_CODE   DETB_RTL_TELLER.EVENT_CODE%TYPE;
    L_TRN_DATE     DETB_RTL_TELLER.TRN_DT%TYPE;
    L_PRDGRP       CSTM_PRODUCT.PRODUCT_GROUP%TYPE;
    L_DETB_ROW     DETB_RTL_TELLER%ROWTYPE;
    L_REV_UTIL     NUMBER := 0;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DBG('Inside the fn_reverse OF Depks_Rtl_Teller PACKAGE...');
    SAVEPOINT RTL_REVERSE;
    DBG('Issued savepoint rtl reverse');
    BEGIN
      SELECT AUTH_STAT, ROWID, NVL(SCODE, '*')
        INTO L_AUTH_STAT, L_ROWID, L_SCODE
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
            P_TRN_REF_NO || '~' || SQLERRM);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;

    BEGIN
      SELECT NVL(TRACK_RECEIVABLE, 'N')
        INTO L_TRACK_RECEIVABLE
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed while selecting track_receivable from detb_rtl_teller with -->' ||
            SQLERRM);
        DBG('Txn Ref No is --->' || P_TRN_REF_NO);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;

    BEGIN
      DBG('Initial value of l_settle_count ' || L_SETTLE_COUNT);
      DBG('Query to get record count from cstb_auto_settle_block');
      SELECT COUNT(*)
        INTO L_SETTLE_COUNT
        FROM CSTB_AUTO_SETTLE_BLOCK
       WHERE CONTRACT_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found for the record.. cstb_auto_settle_block ');
        L_SETTLE_COUNT := 0;
      WHEN OTHERS THEN
        DBG('Failed while selecting entries from cstb_auto_settle_block with -->' ||
            SQLERRM);
        DBG('contract_ref_no --->' || P_TRN_REF_NO);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;
    DBG('l_settle_count ' || L_SETTLE_COUNT);

    IF L_AUTH_STAT = 'A' OR L_AUTH_STAT IS NULL THEN
      DBG('Proceeding for Reversal with l_auth_stat  ' || L_AUTH_STAT ||
          ' and l_settle_count ' || L_SETTLE_COUNT);

      DBG('Cspks_Req_Global.g_Release_Type :::: ' ||
          CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('p_trn_ref_no while calling depks_rtl_teller_cluster.fn_reverse ::::: ' ||
            P_TRN_REF_NO);
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 1;

        IF L_CHECK_ENTRIES THEN
          L_TB_CLUSTER_DATA('l_check_entries') := 'T';
        ELSE
          L_TB_CLUSTER_DATA('l_check_entries') := 'F';
        END IF;

        IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_REVERSE(P_TRN_REF_NO,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM,
                                                   L_FN_CALL_ID,
                                                   L_TB_CLUSTER_DATA) THEN
          DBG('Failed inside depks_rtl_teller_cluster.Fn_Save');
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          RETURN FALSE;
        END IF;

        IF L_TB_CLUSTER_DATA.EXISTS('l_check_entries') THEN
          IF L_TB_CLUSTER_DATA('l_check_entries') = 'T' THEN
            L_CHECK_ENTRIES := TRUE;
          ELSE
            L_CHECK_ENTRIES := FALSE;
          END IF;
        END IF;

      END IF;

      IF L_SETTLE_COUNT > 0 THEN
        DBG('Before Validation For Same Day Reversal ');
        BEGIN
          SELECT BOOK_DATE
            INTO L_BOOK_DATE
            FROM CSTB_AUTO_SETTLE_BLOCK
           WHERE CONTRACT_REF_NO = P_TRN_REF_NO
             AND ROWNUM = 1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found for the record.. cstb_auto_settle_block ');
            L_BOOK_DATE := NULL;
          WHEN OTHERS THEN
            DBG('Failed while selecting BOOK_DATE from cstb_auto_settle_block with -->' ||
                SQLERRM);
            DBG('contract_ref_no --->' || P_TRN_REF_NO);
            P_ERR_CODE := 'DE-TUD-002';
            ROLLBACK TO RTL_REVERSE;
            RETURN FALSE;
        END;
        DBG('l_BOOK_DATE ' || L_BOOK_DATE);

        IF L_BOOK_DATE <> GLOBAL.APPLICATION_DATE THEN
          DBG('For Tracked Transaction Only same date Reversal is Allwoed.');
          P_ERR_CODE := 'DE-TUD-946';
          ROLLBACK TO RTL_REVERSE;
          RETURN FALSE;
        END IF;
      END IF;

      IF GWPKS_UTIL.G_FROM_BEAN OR L_SCODE = 'FLEXSWITCH' THEN
        DEPKS_RTL_TELLER.PR_AUTH_REVERSAL_REQD(TRUE);
      END IF;
      IF DEPKS_RTL_TELLER.PKG_AUTH_REVERSAL_REQD THEN

        L_AUTHORISE := 'B';
      ELSE
        L_AUTHORISE := 'U';
      END IF;
      DBG('Getting a/c entries BY calling Acpks.fn_acEntry_Retrieval...');

      IF NVL(GWPKS_UTIL.G_TWOSTEPPROCESS, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.G_BRNNEWFLOW, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.G_FIRSTSTEPDONE, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1401' AND
         NVL(GWPKS_UTIL.G_TWOSTEPPROCESSNO, '1') = '1' THEN
        L_CHECK_ENTRIES := FALSE;
      END IF;
      DBG('after setting check entries.');
      IF L_CHECK_ENTRIES THEN
        DBG(' going to check for entries .');

        IF ACPKS_CUSTOM.FN_ACENTRY_RETRIEVAL_CUSTOM(P_TRN_REF_NO,
                                                    1,
                                                    L_AC_ENTS) > 0 THEN
          DBG('Doing the actual reversal...');

          IF L_TRACK_RECEIVABLE = 'Y' OR L_SETTLE_COUNT > 0 THEN

            IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'N' THEN
              DBG(' Before Call to pr_update_tracked_balances ');
              PR_UPDATE_TRACKED_BALANCES(P_TRN_REF_NO);
            END IF;
            DBG('After Call to pr_update_tracked_balances ');
          END IF;

          PR_CHARGE_REVERSAL(L_AC_ENTS);

          DBG('L_AC_ENTS.COUNT=' || L_AC_ENTS.COUNT);

          FOR L_RECNO IN L_AC_ENTS.FIRST .. L_AC_ENTS.LAST LOOP
            L_AC_ENTS(L_RECNO).EVENT_SR_NO := 2;
            L_AC_ENTS(L_RECNO).EVENT := 'REVR';
            L_AC_ENTS(L_RECNO).FCY_AMOUNT := L_AC_ENTS(L_RECNO)
                                             .FCY_AMOUNT * -1;
            L_AC_ENTS(L_RECNO).LCY_AMOUNT := L_AC_ENTS(L_RECNO)
                                             .LCY_AMOUNT * -1;

            DBG('gwpks_util.g_branch_date:::' || GWPKS_UTIL.G_BRANCH_DATE);
            DBG('global.application_date:::' || GLOBAL.APPLICATION_DATE);
            IF GWPKS_UTIL.G_BRANCH_DATE > GLOBAL.APPLICATION_DATE AND
               GWPKS_UTIL.G_FROM_BEAN THEN
              L_AC_ENTS(L_RECNO).TRN_DT := GWPKS_UTIL.G_BRANCH_DATE;
            ELSE
              L_AC_ENTS(L_RECNO).TRN_DT := GLOBAL.APPLICATION_DATE;
            END IF;

            L_AC_ENTS(L_RECNO).USER_ID := NVL(L_AC_ENTS(L_RECNO).USER_ID,
                                              GLOBAL.USER_ID);

            IF NOT GWPKS_UTIL.G_FROM_BEAN THEN

              L_AC_ENTS(L_RECNO).TRN_DT := GLOBAL.APPLICATION_DATE;
            END IF;

            L_AC_ENTS(L_RECNO).USER_ID := NVL(L_AC_ENTS(L_RECNO).USER_ID,
                                              GLOBAL.USER_ID);
          END LOOP;
          IF CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
            DBG('Setting l_auth_stat as B since g_auto_ac_closure is true ...');
            L_AUTH_STAT := 'B';
          END IF;
          DBG('Putting back the reversal entries BY calling Acpks.fn_achandoff...');

          IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
            L_AUTHORISE := 'B';
            DBG('THE ACTION CODE FLAG IS FORCEFULLY SET TO B ' ||
                L_AUTHORISE);
          END IF;

          IF NOT ACPKS.FN_ACHANDOFF(P_TRN_REF_NO,
                                    2,
                                    GLOBAL.APPLICATION_DATE,
                                    L_AC_ENTS,
                                    L_AUTHORISE,
                                    'N',
                                    'Y',
                                    GLOBAL.USER_ID,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
            DBG('Failed IN Acpks.fn_achandoff OF fn_reversal IN Depks_Rtl_Teller...');
            DBG('Rolling back to savepoint rtl reverse');
            ROLLBACK TO RTL_REVERSE;
            RETURN FALSE;
          END IF;

          DBG('Cspks_Req_Global.g_Release_Type :::: ' ||
              CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            DBG('p_trn_ref_no while calling depks_rtl_teller_cluster.fn_reverse ::::: ' ||
                P_TRN_REF_NO);
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_FN_CALL_ID      := 1;
            IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_REVERSE(P_TRN_REF_NO,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
              DBG('Failed inside depks_rtl_teller_cluster.Fn_Save');
              DBG('Rolling back to savepoint rtl reverse');
              ROLLBACK TO RTL_REVERSE;
              RETURN FALSE;
            END IF;
          END IF;

        ELSE
          DBG('No entries corresponding TO this p_trn_ref_no IN actb_daily_log...');
          DBG('Rolling back to savepoint rtl reverse');
          ROLLBACK TO RTL_REVERSE;
          RETURN FALSE;
        END IF;

        BEGIN
          SELECT COUNT(*)
            INTO L_REV_UTIL
            FROM STTB_CUST_LIMIT_TRACKING
           WHERE CONTRACT_REF_NO = P_TRN_REF_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
                P_TRN_REF_NO || '~' || SQLERRM);
        END;

        IF L_REV_UTIL > 0 THEN
          BEGIN
            SELECT BRANCH_CODE, PRODUCT_CODE
              INTO L_BRANCH, L_PRODUCT_CODE
              FROM DETBS_RTL_TELLER
             WHERE TRN_REF_NO = P_TRN_REF_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
                  P_TRN_REF_NO || '~' || SQLERRM);
              P_ERR_CODE := 'DE-TUD-002';
              ROLLBACK TO RTL_REVERSE;
              RETURN FALSE;
          END;

          SELECT MODULE, PRODUCT_GROUP
            INTO L_MODULE, L_PRDGRP
            FROM CSTM_PRODUCT
           WHERE PRODUCT_CODE = L_PRODUCT_CODE;

          DBG('l_module' || L_MODULE);

          IF NOT
              STPKS_CUST_RESTR_UTIL_TRACK.FN_PROCESS_CHK_LIMIT(L_SCODE,
                                                               L_MODULE,
                                                               L_BRANCH,
                                                               P_TRN_REF_NO,
                                                               NULL,
                                                               NULL,
                                                               L_EVENT_CODE,
                                                               1,
                                                               L_PRDGRP,
                                                               L_TRN_DATE,
                                                               NULL,
                                                               '',
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               'D',
                                                               V_TBL_RESTR,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAM) THEN
            DBG('error Code' || P_ERR_CODE);
            DBG('error params' || P_ERR_PARAM);
          ELSE
            DBG('NTHNG');
          END IF;
        END IF;

      END IF;
    ELSE

      IF L_SETTLE_COUNT > 0 THEN
        DBG('Cannot proceed to reversal with l_settle_count ' ||
            L_SETTLE_COUNT);
        DBG('This TRANSACTION is NSF tracked Hence cannot be reversed...');
        L_ON_ERROR := TRUE;
      ELSE
        DBG('This TRANSACTION IS unauthorised AND can NOT be reversed...');
        L_ON_ERROR := TRUE;
      END IF;

    END IF;

    IF L_ON_ERROR THEN
      DBG('Reversal cannot be processed ');
      DBG('contract_ref_no --->' || P_TRN_REF_NO);
      P_ERR_CODE := 'DE-TUD-945';
      DBG('Rolling back to savepoint rtl reverse');
      ROLLBACK TO RTL_REVERSE;
      RETURN FALSE;
    END IF;

    DBG('Now UPDATING the Record_stat OF detbs_rtl_teller FOR the trn_ref_no...' ||
        P_TRN_REF_NO);

    IF L_AUTHORISE = 'B' THEN
      L_CHECKER_DT_STAMP := FN_SYSDATE;
      L_CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE +
                            (L_CHECKER_DT_STAMP - TRUNC(L_CHECKER_DT_STAMP));
      DBG('Checker date stamp is' || L_CHECKER_DT_STAMP);
      UPDATE DETBS_RTL_TELLER
         SET RECORD_STAT      = 'V',
             AUTH_STAT        = 'A',
             CHECKER_ID       = NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID),
             CHECKER_DT_STAMP = L_CHECKER_DT_STAMP,

             REVR_DT = GLOBAL.APPLICATION_DATE

       WHERE ROWID = L_ROWID;
    ELSE

      UPDATE DETBS_RTL_TELLER
         SET RECORD_STAT      = 'V',
             AUTH_STAT        = 'U',
             CHECKER_ID       = NULL,
             CHECKER_DT_STAMP = NULL

            ,
             REVR_DT = GLOBAL.APPLICATION_DATE

       WHERE ROWID = L_ROWID;

    END IF;
    DBG('RECORD stat IS updated FOR the trn_ref_no IN detbs_rtl_teller...' ||
        P_TRN_REF_NO);
    RETURN TRUE;
  END FN_REVERSE;

  PROCEDURE PR_PROCESS_RFT_REVERSE_TXN IS

    -- CURSOR C1 IS

    -- SELECT * FROM IFTB_RFT_MASTER_MOB A WHERE TXN_STATUS = 'SUCCESS'
    -- AND AUTH_STAT = 'A';

    CURSOR C1 IS
      /*SELECT A.TRN_REF_NO, A.EVENT_SR_NO, A.AC_CCY, A.AC_BRANCH, A.USER_ID
        FROM ACVW_ALL_AC_ENTRIES A, IFTB_RFT_MASTER_MOB B
       WHERE A.TRN_REF_NO = B.TRN_REF_NO
            --AND T.TRN_REF_NO = P_IFDOFAST.V_IFTBS_FAST_MASTER.TRN_REF_NO
         AND SYSDATE - TO_DATE(TRANSFER_DATE, 'DD-MON-YY') > 14
         AND A.EVENT_SR_NO = 1
         AND A.AUTH_STAT = 'A'
         AND B.RECORD_STAT = 'O';*/


SELECT A.TRN_REF_NO, A.BRANCH_CODE
        FROM IFTB_RFT_MASTER_MOB A
       WHERE A.TRN_REF_NO IN (SELECT B.TRN_REF_NO FROM ACVW_ALL_AC_ENTRIES B
            --AND T.TRN_REF_NO = P_IFDOFAST.V_IFTBS_FAST_MASTER.TRN_REF_NO
         --AND SYSDATE - TO_DATE(TRANSFER_DATE, 'DD-MON-YY') > 14
         WHERE B.TRN_REF_NO = '012RFTM202464501'
         AND B.EVENT_SR_NO = 1
         AND A.AUTH_STAT = 'A')
         AND A.RECORD_STAT = 'O';

    P_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    P_ERR_PARAM ERTB_MSGS.MESSAGE%TYPE;

  BEGIN

    FOR G IN C1 LOOP

      BEGIN

      GLOBAL.pr_init(G.BRANCH_CODE,'SYSTEM');

        IF G.TRN_REF_NO IS NOT NULL THEN

          SAVEPOINT REVERSE_POINT;

          IF NOT FN_REVERSE(G.TRN_REF_NO, P_ERR_CODE, P_ERR_PARAM) THEN

            DBG('FAILED IN REVERSING THE FAST OUTGOING TRANSACTION');
            DBG('P_ERR_CODE=' || P_ERR_CODE);
            DBG('P_ERR_PARAM=' || P_ERR_PARAM);

            ROLLBACK TO REVERSE_POINT;

          ELSE
            DBG('SUCCESS IN REVERSING THE FAST OUTGOING TRANSACTION');
            IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(GLOBAL.CURRENT_BRANCH,
                                                        G.TRN_REF_NO,
                                                        GLOBAL.USER_ID,
                                                        GLOBAL.LCY,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAM) THEN
              DBG('AUTH RETURNED FALSE ' || P_ERR_CODE);
              ROLLBACK TO REVERSE_POINT;
              --RETURN FALSE;

            ELSE

              DBG('AUTH RETURNED TRUE ' || P_ERR_CODE);

              COMMIT;

            END IF;
          END IF;

        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN PROCESSING CURRENT RFT TXN REFERENCE NO=' ||
              G.TRN_REF_NO);
          CONTINUE;
      END;

    END LOOP;

    DBG('END OF PR_REVERSE_FAST_OUT_TXN');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_RFT_REVERSE_TXN');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_RFT_REVERSE_TXN=' || SQLERRM);

  END PR_PROCESS_RFT_REVERSE_TXN;

  --Simple Job to process rft reverse transaction
  PROCEDURE PR_PROCESS_RFT_REVERSE(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2) AS

  BEGIN

    DEBUG.PR_DEBUG('IF', 'INSIDE PR_PROCESS_RFT_REVERSE');

    DEBUG.PR_DEBUG('IF', 'PARAM NAME = ' || PARAMNAME);
    DEBUG.PR_DEBUG('IF', 'PARAM VALUE = ' || PARAMVALUE);

    PR_PROCESS_RFT_REVERSE_TXN;

    DEBUG.PR_DEBUG('IF', 'SUCCESSFUL RETURN FROM PR_PROCESS_RFT_REVERSE');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'EXCEPTION DURING PR_PROCESS_RFT_REVERSE' || SQLERRM);
  END PR_PROCESS_RFT_REVERSE;

END IFPKS_RFT_TXN_UTLS;
