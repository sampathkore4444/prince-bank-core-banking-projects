import java.io.*;
import org.json.*;
public class JSONtoXMLTest1 {
   public static void main(String[] args) throws JSONException {
      String json = "{respCd:SUCCESS,respMsg:SUCCESS,data:{tracNo:3800,txnUnqNo:09620200624000001416,passCd:9NYFKL,amt:12121,crrcy:KHR,fee:{sndFee:1800.0,rcvFee:200.0,cntFee:1000.0}}}";
      //Convert JSON to XML
      String xml = convert(json, "root"); // This method converts json object to xml string
      System.out.println(xml);
   }
   public static String convert(String json, String root) throws JSONException {
      JSONObject jsonObject = new JSONObject(json);
      String xml = "<?xml version=\"1.0\" encoding=\"ISO-8859-15\"?>\n<"+root+">" + XML.toString(jsonObject) + "</"+root+">";
      return xml;
   }
}