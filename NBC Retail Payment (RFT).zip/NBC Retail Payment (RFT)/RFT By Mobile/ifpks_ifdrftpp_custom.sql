CREATE OR REPLACE PACKAGE BODY ifpks_ifdrftpp_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdrftpp_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdrftpp_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN
  
    SELECT TRSQ_FAST_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    RETURN L_REF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  FUNCTION FN_GEN_OUT_MSG_PAY_ID(p_ifdrftpp IN OUT ifpks_ifdrftpp_Main.ty_ifdrftpp,
                                 p_msgid    OUT VARCHAR2,
                                 p_payid    OUT VARCHAR2,
                                 p_instrid  OUT VARCHAR2) RETURN BOOLEAN IS
    l_bank_code        cstm_arc_settle.route_code%TYPE;
    l_seq              NUMBER;
    L_PARTICIPANT_CODE LMTM_TYPE_VALUES.VALUE%TYPE;
  BEGIN
    dbg('In FN_GEN_OUT_MSG_PAY_ID');
  
    --Get Bic Code
    BEGIN
      SELECT route_code
        INTO l_bank_code
        FROM cstm_arc_settle
       WHERE product_code = p_ifdrftpp.v_iftbs_rft_master_mob.product_code
         AND auth_stat = 'A'
         AND record_stat = 'O';
    EXCEPTION
      WHEN no_data_found THEN
        dbg('query fail with ' || SQLERRM);
        l_bank_code := 'PINCKHPPXXXX';
        --RETURN FALSE;
    END;
  
    DBG('l_bank_code=' || l_bank_code);
  
    --Get Beneficiary participant Code
    BEGIN
    
      SELECT VALUE
        INTO L_PARTICIPANT_CODE
        FROM LMTM_TYPE_VALUES
       WHERE TYPE = 'FAST_MEMBERS';
      --AND CODE = p_ifdrftpp.v_iftbs_rft_master_mob.BEN_BIC;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('query fail with ' || SQLERRM);
        pr_log_error('IFDOFAST',
                     p_ifdrftpp.v_iftbs_rft_master_mob.source_code,
                     'IF-FST001',
                     NULL);
        RETURN FALSE;
    END;
  
    DBG('L_PARTICIPANT_CODE=' || L_PARTICIPANT_CODE);
  
    SELECT trsq_msgid.nextval INTO l_seq FROM dual;
    -- msg id
    p_msgid := l_bank_code || lpad(TRIM(to_char(l_seq)), 5, '0');
    dbg('Returns p_msgid as ' || p_msgid);
  
    p_payid := l_bank_code || '/' || L_PARTICIPANT_CODE || '/' ||
               lpad(TRIM(to_char(l_seq)), 5, '0');
  
    dbg('Returns p_payid as ' || p_payid);
    -- instr id
    p_instrid := l_bank_code || '/' || lpad(TRIM(to_char(l_seq)), 5, '0');
    dbg('Returns p_instrid as ' || p_instrid);
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('bombed with ' || SQLERRM);
      RETURN FALSE;
  END FN_GEN_OUT_MSG_PAY_ID;

  FUNCTION FN_RETURN_RFT_CREATE_PASSCODE RETURN CLOB IS
    L_FORMATTED_MSG varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_RETURN_RFT_CREATE_PASSCODE');
  
    L_FORMATTED_MSG := '{
    "sndPhone": "$L_REM_PHONE",
    "rcvPhone": "$L_BEN_PHONE",
    "crrcy": "$L_TXN_CCY",
    "amt": "$L_TXN_AMT"
}';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_RETURN_RFT_CREATE_PASSCODE');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_RFT_CREATE_PASSCODE');
      DBG('ERROR CODE IN FN_RETURN_RFT_CREATE_PASSCODE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_RFT_CREATE_PASSCODE=' || SQLERRM);
  END FN_RETURN_RFT_CREATE_PASSCODE;

  FUNCTION FN_GET_FORMATTED_PASSCODE(P_IFDRFTPP IN ifpks_ifdrftpp_Main.Ty_ifdrftpp)
    RETURN CLOB IS
  
    L_FORMATTED_MSG CLOB;
    L_SENDER_PHONE  IFTB_RFT_MASTER_MOB.REM_PHONE%TYPE;
    L_BEN_PHONE     IFTB_RFT_MASTER_MOB.BEN_PHONE%TYPE;
    L_TXN_CCY       IFTB_RFT_MASTER_MOB.TXN_CCY%TYPE;
    L_TXN_AMT       IFTB_RFT_MASTER_MOB.TXN_AMT%TYPE;
  
  BEGIN
  
    DBG('SATRT OF FN_GET_FORMATTED_PASSCODE');
  
    L_FORMATTED_MSG := FN_RETURN_RFT_CREATE_PASSCODE;
  
    DBG('BEFORE REPLACEMENT OF RFT CREATE PASSCODE JSON=' ||
        L_FORMATTED_MSG);
  
    L_SENDER_PHONE := p_ifdrftpp.v_iftbs_rft_master_mob.rem_phone;
  
    DBG('L_SENDER_PHONE=' || L_SENDER_PHONE);
  
    L_BEN_PHONE := p_ifdrftpp.v_iftbs_rft_master_mob.ben_phone;
  
    DBG('L_BEN_PHONE=' || L_BEN_PHONE);
  
    L_TXN_CCY := p_ifdrftpp.v_iftbs_rft_master_mob.TXN_CCY;
  
    DBG('L_TXN_CCY=' || L_TXN_CCY);
  
    L_TXN_AMT := p_ifdrftpp.v_iftbs_rft_master_mob.TXN_AMT;
  
    DBG('L_TXN_AMT=' || L_TXN_AMT);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REM_PHONE',
                               L_SENDER_PHONE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_PHONE', L_BEN_PHONE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_CCY', L_TXN_CCY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_AMT', L_TXN_AMT);
  
    DBG('AFTER REPLACEMENT OF RFT CREATE PASSCODE JSON=' ||
        L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FORMATTED_PASSCODE');
      DBG('ERROR CODE IN FN_GET_FORMATTED_PASSCODE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FORMATTED_PASSCODE=' || SQLERRM);
  END FN_GET_FORMATTED_PASSCODE;

  FUNCTION FN_MOBILE_VALIDATE(P_NUMBER IN VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    IF P_NUMBER IS NOT NULL THEN
    
      IF LENGTH(P_NUMBER) NOT IN (9, 10) THEN
        RETURN FALSE;
      
      END IF;
    
      IF REGEXP_LIKE(P_NUMBER, '^[0-9_\(\)]+$') THEN
        RETURN TRUE;
      ELSE
        RETURN FALSE;
      END IF;
    ELSE
      RETURN TRUE;
    END IF;
  END FN_MOBILE_VALIDATE;

  FUNCTION fn_process_entries(p_ifdrftpp  IN OUT ifpks_ifdrftpp_Main.ty_ifdrftpp,
                              p_action    CHAR,
                              p_errcode   IN OUT VARCHAR2,
                              p_errparams IN OUT VARCHAR2) RETURN BOOLEAN IS
    CURSOR cur_acc IS
      SELECT t.trn_ref_no, t.event_sr_no, t.ac_ccy, t.ac_branch, t.user_id
        FROM actb_daily_log t, iftb_rft_master_mob t1
       WHERE t.trn_ref_no = t1.trn_ref_no
         AND t.trn_ref_no = p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no
         AND t.event_sr_no = 1
         AND t.auth_stat <> 'A';
    i           NUMBER := 0;
    l_terminate BOOLEAN := FALSE;
  BEGIN
    dbg('In fn_process_entries with ' ||
        p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no || '~~~' || p_action);
    IF p_action NOT IN ('D', 'A') THEN
      dbg('Action code not in Delete or Auth...Return TRUE now');
      RETURN TRUE;
    END IF;
    FOR c1 IN cur_acc LOOP
      i := 0;
      IF acpkss.fn_acservice(c1.ac_branch,
                             global.application_date,
                             global.lcy,
                             c1.trn_ref_no,
                             c1.event_sr_no,
                             p_action,
                             global.user_id, --c1.user_id,
                             p_errcode,
                             p_errparams) THEN
        dbg('SUCCESS - ' || c1.trn_ref_no);
      ELSE
        dbg('ERROR - ' || c1.trn_ref_no || SQLERRM);
        dbg('ERROR - ' || p_errcode || '~~~' || p_errparams);
        l_terminate := TRUE;
        dbg('After setting l_terminate to TRUE and leave the LOOP');
        EXIT;
      END IF;
      UPDATE detbs_rtl_teller
         SET auth_stat        = 'A',
             checker_id       = global.user_id,
             checker_dt_stamp = csfn_timestamp,
             record_stat      = decode(record_stat, 'O', 'A', record_stat),
             mod_no           = 1
       WHERE trn_ref_no = c1.trn_ref_no;
    
      i := i + 1;
      dbg('COUNT-->' || i);
    END LOOP;
    IF NOT l_terminate THEN
      dbg('AUTH is fine...Return TRUE now ');
      RETURN TRUE;
    ELSE
      dbg('AUTH is NOT fine...Return FALSE now ');
      RETURN FALSE;
    END IF;
    dbg('Leaving fn_process_entries now....');
  END fn_process_entries;

  FUNCTION fn_rft_out_msg_gen(p_ifdrftpp   IN OUT ifpks_ifdrftpp_Main.ty_ifdrftpp,
                              p_msg        IN OUT CLOB,
                              p_err_code   IN OUT VARCHAR2,
                              p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
    dbg('In fn_rft_out_msg_gen..');
  
    dbg('Returning Success From fn_rft_out_msg_gen..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.FN_FAST_OUT_MSG_GEN ..');
      debug.pr_debug('**', SQLERRM);
    
      p_err_code   := 'IF-FAST-009';
      p_err_params := 'Can not generate pain_001.001.05';
      RETURN FALSE;
  END fn_rft_out_msg_gen;

  FUNCTION fn_enrich_product(p_ifdrftpp   IN OUT ifpks_ifdrftpp_Main.ty_ifdrftpp,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
    l_serial_no    VARCHAR2(16);
    l_trn_ref_no   iftb_rft_master.trn_ref_no%TYPE;
    l_ty_rtupld    depks_retailtellerupload.typ_retailtellerupld_rec;
    l_ret          BOOLEAN;
    l_tot_chg_amt  NUMBER(22, 3);
    l_rel_customer sttm_customer.customer_no%TYPE;
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_ib_flag      VARCHAR2(1) DEFAULT 'Y';
    l_arc_maint    iftm_arc_maint%ROWTYPE;
    l_prod         cstm_product%ROWTYPE;
    l_rate         NUMBER;
    l_charge_amt   NUMBER := 0;
    l_rate_flag    NUMBER;
    l_ccy1         iftb_rft_master.txn_ccy%TYPE;
    l_ccy2         iftb_rft_master.txn_ccy%TYPE;
  
    l_tot_chg_amount            iftb_rft_master.net_txn_amt%TYPE;
    l_txn_amt                   iftb_rft_master.txn_amt%TYPE;
    l_txn_amt1                  iftb_rft_master.txn_amt%TYPE;
    l_rate_code                 cstm_product.rate_code_preferred%Type;
    l_rate_code1                cstm_product.rate_code_preferred%Type;
    l_tot_chg_amt_in_txn_ccy    iftb_rft_master.txn_amt%TYPE;
    l_tot_chg_amt_in_lcy_ccy    iftb_rft_master.txn_amt%TYPE;
    l_arc_rate_code_type        iftm_arc_maint.cod_rate_code%Type;
    l_tot_chg_amount_in_txn_ccy iftb_rft_master.txn_amt%TYPE;
    l_tot_chg_amount_in_acc_ccy iftb_rft_master.txn_amt%TYPE;
    L_STTB_ACCOUNT              STTB_ACCOUNT%ROWTYPE;
    L_STTM_CUST_ACCOUNT         STTM_CUST_ACCOUNT%ROWTYPE;
  BEGIN
  
    dbg('In FN_ENRICH_PRODUCT');
    --dbg('p_Action_Code' || p_action_code);
  
    p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow := 'O';
    -- mandatory check
    IF p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow = 'O' THEN
    
      --Get Account details
      BEGIN
        SELECT *
          INTO L_STTB_ACCOUNT
          FROM STTB_ACCOUNT
         WHERE AC_GL_NO = p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_STTB_ACCOUNT := NULL;
          DBG('FAILED IN GETTING ACCOUNT DETAILS');
      END;
    
      --Get Account details
      BEGIN
        SELECT *
          INTO L_STTM_CUST_ACCOUNT
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_STTM_CUST_ACCOUNT := NULL;
          DBG('FAILED IN GETTING ACCOUNT DETAILS');
      END;
    
      IF P_IFDRFTPP.V_IFTBS_RFT_MASTER_MOB.TXN_CCY <>
         L_STTM_CUST_ACCOUNT.CCY THEN
      
        dbg('Transaction Currency must be same as Account Currency');
        p_err_code := 'IF-RFT-005';
      
        pr_log_error('IFDRFTPP', 'FLEXCUBE', p_err_code, NULL);
      
        RETURN FALSE;
      END IF;
    
      IF L_STTB_ACCOUNT.AC_STAT_DORMANT = 'Y' THEN
        dbg('Account Status is Dormant');
        p_err_code   := 'AC-VAC33';
        p_err_params := 'Status';
        RETURN FALSE;
      END IF;
    
      IF L_STTB_ACCOUNT.AC_STAT_NO_DR = 'Y' THEN
        dbg('Account Status is No Debit');
        p_err_code   := 'AC-VAC07';
        p_err_params := 'Status';
        RETURN FALSE;
      END IF;
    
      IF L_STTM_CUST_ACCOUNT.RECORD_STAT = 'C' THEN
        dbg('Account is Closed');
        p_err_code   := 'AC-VAC12';
        p_err_params := L_STTM_CUST_ACCOUNT.CUST_AC_NO;
        RETURN FALSE;
      END IF;
    
      IF L_STTB_ACCOUNT.AC_STAT_FROZEN = 'Y' THEN
        dbg('Account Status is Frozen');
        p_err_code   := 'AC-VAC04';
        p_err_params := 'Status';
        RETURN FALSE;
      END IF;
    
      IF p_ifdrftpp.v_iftbs_rft_master_mob.product_code IS NULL THEN
        dbg('Mandatory Field Product Code cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Product Code';
        RETURN FALSE;
      END IF;
      IF p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy IS NULL THEN
        dbg('Mandatory Fields Transaction Currency cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Transaction Currency';
        RETURN FALSE;
      END IF;
      IF p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt IS NULL THEN
        dbg('Mandatory Fields Transaction Amount cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Transaction Amount';
        RETURN FALSE;
      END IF;
      IF p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc IS NULL THEN
        dbg('Mandatory Fields Remitter Account cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Remitter Account';
        RETURN FALSE;
      END IF;
    END IF;
  
    -- reference no
    IF p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no IS NULL THEN
      IF NOT trpkss.fn_get_product_refno(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                         p_ifdrftpp.v_iftbs_rft_master_mob.product_code,
                                         p_ifdrftpp.v_iftbs_rft_master_mob.transfer_date,
                                         l_serial_no,
                                         l_trn_ref_no,
                                         p_err_code) THEN
        dbg('Failed in generation Transaction Ref No');
        RETURN FALSE;
      ELSE
        dbg('l_trn_ref_no=' || l_trn_ref_no);
        p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no := l_trn_ref_no;
      
      END IF;
    END IF;
  
    -- charge pickup
    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdrftpp.v_iftbs_rft_master_mob.product_code;
  
    DBG('p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow =' ||
        p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow);
  
    p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow := 'O'; --sampath
  
    IF p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow = 'O' THEN
      SELECT cust_no, ccy
        INTO l_rel_customer, l_ac_ccy
        FROM sttm_cust_account
       WHERE cust_ac_no = p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc;
    
    END IF;
  
    dbg('got l_rel_customer' || l_rel_customer);
  
    IF NOT
        cspkss_arc.fn_charge_pickup(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                    p_ifdrftpp.v_iftbs_rft_master_mob.product_code,
                                    'P',
                                    p_ifdrftpp.v_iftbs_rft_master_mob.product_code,
                                    p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                    l_rel_customer,
                                    p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                    p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt,
                                    l_prod.rate_type_preferred,
                                    l_prod.rate_code_preferred,
                                    NULL,
                                    l_rel_customer,
                                    l_ib_flag,
                                    l_arc_maint,
                                    p_err_code,
                                    p_err_params,
                                    p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc,
                                    p_ifdrftpp.v_iftbs_rft_master_mob.branch_code) THEN
      dbg('CHARGE PICKUP failed');
      RETURN FALSE;
    END IF;
  
    DBG('l_arc_maint.cod_chg_amt =' || l_arc_maint.cod_chg_amt);
  
    --Charge1
    IF l_arc_maint.cod_chg_amt IS NOT NULL THEN
      DBG('Populating Charge 1');
      p_ifdrftpp.v_iftbs_rft_charge(1).trn_ref_no := p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no;
      p_ifdrftpp.v_iftbs_rft_charge(1).chg_srno := 1;
      p_ifdrftpp.v_iftbs_rft_charge(1).chg1_desc := l_arc_maint.cod_chg_desc;
      p_ifdrftpp.v_iftbs_rft_charge(1).chg1_waiver := 'N';
      p_ifdrftpp.v_iftbs_rft_charge(1).chg1_amt := l_arc_maint.cod_chg_amt;
      p_ifdrftpp.v_iftbs_rft_charge(1).chg1_ccy := l_arc_maint.cod_chg_ccy;
    
      DBG('p_ifdrftpp.v_iftbs_rft_charge(1).trn_ref_no=' || p_ifdrftpp.v_iftbs_rft_charge(1)
          .trn_ref_no);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(1).chg_srno=' || p_ifdrftpp.v_iftbs_rft_charge(1)
          .chg_srno);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(1).chg1_desc=' || p_ifdrftpp.v_iftbs_rft_charge(1)
          .chg1_desc);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(1).chg1_waiver=' || p_ifdrftpp.v_iftbs_rft_charge(1)
          .chg1_waiver);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(1).chg1_amt=' || p_ifdrftpp.v_iftbs_rft_charge(1)
          .chg1_amt);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(1).chg1_ccy=' || p_ifdrftpp.v_iftbs_rft_charge(1)
          .chg1_ccy);
    
      DBG('p_ifdrftpp.v_iftbs_rft_charge.count=' ||
          p_ifdrftpp.v_iftbs_rft_charge.count);
    
      DBG('global.lcy=' || global.lcy);
      DBG('l_arc_maint.cod_chg_ccy=' || l_arc_maint.cod_chg_ccy);
    
      -- Converting charge into local ccy for display in charge tab
      IF l_arc_maint.cod_chg_ccy <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                      l_arc_maint.cod_chg_ccy,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpp.v_iftbs_rft_charge(1).lcy_chg1 := l_charge_amt;
        p_ifdrftpp.v_iftbs_rft_charge(1).xrate := l_rate;
      ELSE
        p_ifdrftpp.v_iftbs_rft_charge(1).lcy_chg1 := l_arc_maint.cod_chg_amt;
        p_ifdrftpp.v_iftbs_rft_charge(1).xrate := 1;
      END IF;
      dbg('Amount 1 in Local ccy->' || p_ifdrftpp.v_iftbs_rft_charge(1)
          .lcy_chg1);
    
      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy <>
         p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                      l_arc_maint.cod_chg_ccy,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                      l_prod.rate_type_preferred,
                                      NVL(l_arc_maint.cod_rate_code_Type, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                      l_arc_maint.cod_chg_amt,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpp.v_iftbs_rft_charge(1).chg1_in_txn := l_charge_amt;
        p_ifdrftpp.v_iftbs_rft_charge(1).txn_xrate := l_rate;
        dbg(' * Amount 1 in TXN ccy->' || p_ifdrftpp.v_iftbs_rft_charge(1)
            .chg1_in_txn);
      ELSE
        p_ifdrftpp.v_iftbs_rft_charge(1).chg1_in_txn := l_arc_maint.cod_chg_amt;
        p_ifdrftpp.v_iftbs_rft_charge(1).txn_xrate := 1;
        dbg('** Amount 1 in TXN ccy->' || p_ifdrftpp.v_iftbs_rft_charge(1)
            .chg1_in_txn);
      END IF;
    
      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                      l_arc_maint.cod_chg_ccy,
                                      l_ac_ccy,
                                      l_prod.rate_type_preferred,
                                      NVL(l_arc_maint.cod_rate_code_Type, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                      l_arc_maint.cod_chg_amt,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpp.v_iftbs_rft_charge(1).chg1_in_acc := l_charge_amt;
        p_ifdrftpp.v_iftbs_rft_charge(1).acc_xrate := l_rate;
        dbg('* Amount 1 in acc ccy->' || p_ifdrftpp.v_iftbs_rft_charge(1)
            .chg1_in_acc);
      ELSE
        p_ifdrftpp.v_iftbs_rft_charge(1).chg1_in_acc := l_arc_maint.cod_chg_amt;
        p_ifdrftpp.v_iftbs_rft_charge(1).acc_xrate := 1;
        dbg('** Amount 1 in acc ccy->' || p_ifdrftpp.v_iftbs_rft_charge(1)
            .chg1_in_acc);
      END IF;
    END IF;
  
    --Charge2
    IF l_arc_maint.cod_chg_amt1 IS NOT NULL THEN
      DBG('Populating Charge 2');
      p_ifdrftpp.v_iftbs_rft_charge(2).trn_ref_no := p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no;
      p_ifdrftpp.v_iftbs_rft_charge(2).chg_srno := 2;
      p_ifdrftpp.v_iftbs_rft_charge(2).chg2_desc := l_arc_maint.cod_chg_desc1;
      p_ifdrftpp.v_iftbs_rft_charge(2).chg2_waiver := 'N';
      p_ifdrftpp.v_iftbs_rft_charge(2).chg2_amt := l_arc_maint.cod_chg_amt1;
      p_ifdrftpp.v_iftbs_rft_charge(2).chg2_ccy := l_arc_maint.cod_chg_ccy1;
    
      DBG('p_ifdrftpp.v_iftbs_rft_charge(2).trn_ref_no=' || p_ifdrftpp.v_iftbs_rft_charge(2)
          .trn_ref_no);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(2).chg_srno=' || p_ifdrftpp.v_iftbs_rft_charge(2)
          .chg_srno);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(2).chg2_desc=' || p_ifdrftpp.v_iftbs_rft_charge(2)
          .chg2_desc);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(2).chg2_waiver=' || p_ifdrftpp.v_iftbs_rft_charge(2)
          .chg2_waiver);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(2).chg2_amt=' || p_ifdrftpp.v_iftbs_rft_charge(2)
          .chg2_amt);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(2).chg2_ccy=' || p_ifdrftpp.v_iftbs_rft_charge(2)
          .chg2_ccy);
    
      IF l_arc_maint.cod_chg_ccy1 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                      l_arc_maint.cod_chg_ccy1,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt1,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpp.v_iftbs_rft_charge(2).lcy_chg2 := l_charge_amt;
        p_ifdrftpp.v_iftbs_rft_charge(2).xrate := l_rate;
      ELSE
        p_ifdrftpp.v_iftbs_rft_charge(2).lcy_chg2 := l_arc_maint.cod_chg_amt1;
        p_ifdrftpp.v_iftbs_rft_charge(2).xrate := 1;
      END IF;
    
      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy1 <>
         p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                   l_arc_maint.cod_chg_ccy1,
                                   p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type1, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt1,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpp.v_iftbs_rft_charge(2).chg2_in_txn := l_charge_amt;
        p_ifdrftpp.v_iftbs_rft_charge(2).txn_xrate := l_rate;
        dbg('* Amount 2 in TXN ccy->' || p_ifdrftpp.v_iftbs_rft_charge(2)
            .chg2_in_txn);
      ELSE
        p_ifdrftpp.v_iftbs_rft_charge(2).chg2_in_txn := l_arc_maint.cod_chg_amt1;
        p_ifdrftpp.v_iftbs_rft_charge(2).txn_xrate := 1;
        dbg('** Amount 2 in TXN ccy->' || p_ifdrftpp.v_iftbs_rft_charge(2)
            .chg2_in_txn);
      END IF;
    
      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy1 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                   l_arc_maint.cod_chg_ccy1,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type1, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt1,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpp.v_iftbs_rft_charge(2).chg2_in_acc := l_charge_amt;
        p_ifdrftpp.v_iftbs_rft_charge(2).acc_xrate := l_rate;
        dbg('* Amount 2 in acc ccy->' || p_ifdrftpp.v_iftbs_rft_charge(2)
            .chg2_in_acc);
      ELSE
        p_ifdrftpp.v_iftbs_rft_charge(2).chg2_in_acc := l_arc_maint.cod_chg_amt1;
        p_ifdrftpp.v_iftbs_rft_charge(2).acc_xrate := 1;
        dbg('** Amount 2 in acc ccy->' || p_ifdrftpp.v_iftbs_rft_charge(2)
            .chg2_in_acc);
      END IF;
      p_ifdrftpp.v_iftbs_rft_charge(2).oth_ccy := l_arc_maint.cod_chg_ccy1;
    
    END IF;
  
    --Charge3
    /*IF l_arc_maint.cod_chg_amt2 IS NOT NULL THEN
      DBG('Populating Charge 3');
      p_ifdrftpp.v_iftbs_rft_charge(3).trn_ref_no := p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no;
      p_ifdrftpp.v_iftbs_rft_charge(3).chg_srno := 3;
      p_ifdrftpp.v_iftbs_rft_charge(3).chg3_desc := l_arc_maint.cod_chg_desc2;
      p_ifdrftpp.v_iftbs_rft_charge(3).chg3_waiver := 'N';
      p_ifdrftpp.v_iftbs_rft_charge(3).chg3_amt := l_arc_maint.cod_chg_amt2;
      p_ifdrftpp.v_iftbs_rft_charge(3).chg3_ccy := l_arc_maint.cod_chg_ccy2;
    
      DBG('p_ifdrftpp.v_iftbs_rft_charge(3).trn_ref_no=' || p_ifdrftpp.v_iftbs_rft_charge(3)
          .trn_ref_no);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(3).chg_srno=' || p_ifdrftpp.v_iftbs_rft_charge(3)
          .chg_srno);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(3).chg3_desc=' || p_ifdrftpp.v_iftbs_rft_charge(3)
          .chg3_desc);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(3).chg3_waiver=' || p_ifdrftpp.v_iftbs_rft_charge(3)
          .chg3_waiver);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(3).chg3_amt=' || p_ifdrftpp.v_iftbs_rft_charge(3)
          .chg3_amt);
      DBG('p_ifdrftpp.v_iftbs_rft_charge(3).chg3_ccy=' || p_ifdrftpp.v_iftbs_rft_charge(3)
          .chg3_ccy);
    
      IF l_arc_maint.cod_chg_ccy2 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                      l_arc_maint.cod_chg_ccy2,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt2,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpp.v_iftbs_rft_charge(3).lcy_chg3 := l_charge_amt;
        p_ifdrftpp.v_iftbs_rft_charge(3).xrate := l_rate;
      ELSE
        p_ifdrftpp.v_iftbs_rft_charge(3).lcy_chg3 := l_arc_maint.cod_chg_amt2;
        p_ifdrftpp.v_iftbs_rft_charge(3).xrate := 1;
      END IF;
    
      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy2 <>
         p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                   l_arc_maint.cod_chg_ccy2,
                                   p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type2, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt2,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpp.v_iftbs_rft_charge(3).chg3_in_txn := l_charge_amt;
        p_ifdrftpp.v_iftbs_rft_charge(3).txn_xrate := l_rate;
        dbg('* Amount 3 in TXN ccy->' || p_ifdrftpp.v_iftbs_rft_charge(3)
            .chg3_in_txn);
      ELSE
        p_ifdrftpp.v_iftbs_rft_charge(3).chg3_in_txn := l_arc_maint.cod_chg_amt2;
        p_ifdrftpp.v_iftbs_rft_charge(3).txn_xrate := 1;
        dbg('** Amount 3 in TXN ccy->' || p_ifdrftpp.v_iftbs_rft_charge(3)
            .chg3_in_txn);
      END IF;
    
      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy2 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                   l_arc_maint.cod_chg_ccy2,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type2, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt2,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpp.v_iftbs_rft_charge(3).chg3_in_acc := l_charge_amt;
        p_ifdrftpp.v_iftbs_rft_charge(3).acc_xrate := l_rate;
        dbg('* Amount 3 in ACC ccy->' || p_ifdrftpp.v_iftbs_rft_charge(3)
            .chg3_in_acc);
      ELSE
        p_ifdrftpp.v_iftbs_rft_charge(3).chg3_in_acc := l_arc_maint.cod_chg_amt2;
        p_ifdrftpp.v_iftbs_rft_charge(3).acc_xrate := 1;
        dbg('** Amount 3 in ACC ccy->' || p_ifdrftpp.v_iftbs_rft_charge(3)
            .chg3_in_acc);
      END IF;
      p_ifdrftpp.v_iftbs_rft_charge(3).oth_ccy := l_arc_maint.cod_chg_ccy2;
    END IF;*/
  
    l_tot_chg_amt_in_txn_ccy := nvl(l_tot_chg_amt_in_txn_ccy, 0) +
                                nvl(p_ifdrftpp.v_iftbs_rft_charge(1)
                                    .chg1_in_txn,
                                    0) + nvl(p_ifdrftpp.v_iftbs_rft_charge(2)
                                             .chg2_in_txn,
                                             0) /* + nvl(p_ifdrftpp.v_iftbs_rft_charge(3)
                                                                                              .chg3_in_txn,
                                                                                              0)*/
     ;
  
    dbg('L_TOT_CHG_AMT~p_ifdrftpp.v_iftbs_pgw_master_custom.TXN_CCY~GLOBAL.LCY' ||
        l_tot_chg_amt || '~' || p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy || '~' ||
        global.lcy);
  
    dbg('Total charge to be paid in TXN CCY ->' ||
        l_tot_chg_amt_in_txn_ccy);
    p_ifdrftpp.v_iftbs_rft_master_mob.tot_chg_amt := l_tot_chg_amt_in_txn_ccy; -- We are displaying total charge in txn amount only --Tuning of code in charge calculation
  
    -- Total Charge amount in local and remitter/account ccy
    /*FOR J IN 1 .. p_ifdrftpp.v_iftbs_rft_charge.count LOOP
      dbg('1 l_tot_chg_amt_in_lcy_ccy->' || l_tot_chg_amt_in_lcy_ccy ||
          'p_ifdrftpp.v_iftbs_rft_charge(j).lcy_chg' || p_ifdrftpp.v_iftbs_rft_charge(j)
          .lcy_chg);
      dbg('1 l_tot_chg_amount_in_acc_ccy->' || l_tot_chg_amount_in_acc_ccy ||
          'p_ifdrftpp.v_iftbs_rft_charge(j).chg_in_acc' || p_ifdrftpp.v_iftbs_rft_charge(j)
          .chg_in_acc);
      l_tot_chg_amt_in_lcy_ccy    := nvl(l_tot_chg_amt_in_lcy_ccy, 0) +
                                     nvl(p_ifdrftpp.v_iftbs_rft_charge(j)
                                         .lcy_chg,
                                         0);
      l_tot_chg_amount_in_acc_ccy := nvl(l_tot_chg_amount_in_acc_ccy, 0) +
                                     nvl(p_ifdrftpp.v_iftbs_rft_charge(j)
                                         .chg_in_acc,
                                         0);
    
      dbg('2 l_tot_chg_amt_in_lcy_ccy->' || l_tot_chg_amt_in_lcy_ccy);
      dbg('2 l_tot_chg_amount_in_acc_ccy->' || l_tot_chg_amount_in_acc_ccy);
    End Loop;*/
  
    l_tot_chg_amt_in_lcy_ccy    := nvl(l_tot_chg_amt_in_lcy_ccy, 0) +
                                   nvl(p_ifdrftpp.v_iftbs_rft_charge(1)
                                       .lcy_chg1,
                                       0) + nvl(p_ifdrftpp.v_iftbs_rft_charge(2)
                                                .lcy_chg2,
                                                0) /* +
                                                                           nvl(p_ifdrftpp.v_iftbs_rft_charge(3)
                                                                               .lcy_chg3,
                                                                               0)*/
     ;
    l_tot_chg_amount_in_acc_ccy := nvl(l_tot_chg_amount_in_acc_ccy, 0) +
                                   nvl(p_ifdrftpp.v_iftbs_rft_charge(1)
                                       .chg1_in_acc,
                                       0) + nvl(p_ifdrftpp.v_iftbs_rft_charge(2)
                                                .chg2_in_acc,
                                                0) /* +
                                                                           nvl(p_ifdrftpp.v_iftbs_rft_charge(3)
                                                                               .chg3_in_acc,
                                                                               0)*/
     ;
  
    dbg('chgs calculated ->');
  
    If l_prod.rate_code_preferred = 'B' Then
      l_rate_code := Null;
      If (p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy = global.lcy and
         l_ac_ccy != global.lcy) OR
         (p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy != global.lcy and
         l_ac_ccy <> global.lcy and
         p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy <> l_ac_ccy) Then
        l_rate_code := 'B';
      
      Else
        l_rate_code := l_prod.rate_code_preferred;
      End If;
    Else
      l_rate_code := l_prod.rate_code_preferred;
    End If;
    dbg('p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt->' ||
        p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt);
  
    dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
        l_rate_code1);
  
    If l_ac_ccy <> global.lcy Then
      begin
        select decode(l_rate_code,
                      'B',
                      'S',
                      'S',
                      'B',
                      'M',
                      'M',
                      l_rate_code)
          Into l_rate_code1
          from dual;
      exception
        when others then
          dbg('Exception found l_rate_code-> ' || l_rate_code);
      end;
    End If;
    dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
        l_rate_code1);
    dbg('l_txn_amt l_txn_amt l_txn_amt=' || l_txn_amt);
    -- Total Txn amount in remitter currency
    IF p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy <> l_ac_ccy THEN
      l_rate := NULL;
      --l_charge_amt := NULL;
      l_txn_amt1 := p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt;
      /*IF NOT cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                    p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                    l_ac_ccy,
                                    l_prod.rate_type_preferred,
                                    nvl(l_rate_code1, l_rate_code),
                                    l_txn_amt1,
                                    'Y',
                                    l_txn_amt,
                                    l_rate,
                                    p_err_params) THEN
        debug.pr_debug('**', '');
        debug.pr_debug('**', SQLERRM);
        p_err_code   := 'ST-OTHR-001';
        p_err_params := NULL;
        RETURN FALSE;
      END IF;*/
    
      -- xrate
      IF p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy <> l_ac_ccy THEN
      
        IF p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy = global.lcy THEN
          l_ccy1 := l_ac_ccy;
          l_ccy2 := p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy;
        ELSE
          l_ccy1 := p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy;
          l_ccy2 := l_ac_ccy;
        END IF;
        dbg('l_rate_code->' || l_rate_code || 'l_prod.rate_type_preferred' ||
            l_prod.rate_type_preferred);
        dbg('Before p_ifdrftpp.v_iftbs_pgw_master_custom.exch_rate->' ||
            p_ifdrftpp.v_iftbs_rft_master_mob.exch_rate);
      
        If (p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy != global.lcy and
           l_ac_ccy <> global.lcy and
           p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy <> l_ac_ccy) and
           l_prod.rate_code_preferred = 'B' Then
          l_rate_code := 'S';
        End If;
      
        dbg('l_rate_code->' || l_rate_code);
      
        dbg('l_prod.rate_type_preferred=' || l_prod.rate_type_preferred);
      
        IF NOT cypkss.fn_getrate(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                 l_ccy2,
                                 l_ccy1, --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                 l_prod.rate_type_preferred,
                                 l_rate_code, --l_prod.rate_code_preferred,
                                 p_ifdrftpp.v_iftbs_rft_master_mob.transfer_date,
                                 p_ifdrftpp.v_iftbs_rft_master_mob.transfer_date,
                                 p_ifdrftpp.v_iftbs_rft_master_mob.exch_rate,
                                 l_rate_flag,
                                 p_err_code) THEN
          dbg('Failed in Fn_GetRate');
          RETURN FALSE;
        END IF;
      ELSE
        p_ifdrftpp.v_iftbs_rft_master_mob.exch_rate := 1;
      END IF;
    
      DBG('p_ifdrftpp.v_iftbs_rft_master_mob.exch_rate==' ||
          p_ifdrftpp.v_iftbs_rft_master_mob.exch_rate);
    
      --Using above rate..convert khr to usd amount
      IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                    l_ac_ccy,
                                    l_txn_amt1,
                                    p_ifdrftpp.v_iftbs_rft_master_mob.exch_rate,
                                    'Y',
                                    l_txn_amt,
                                    p_err_params) THEN
        RETURN FALSE;
      END IF;
    END IF;
    dbg('Final txn_amt->' || l_txn_amt || 'Final chg_amount->' ||
        l_tot_chg_amount);
    dbg('Total Charges in local ccy->' || l_tot_chg_amt_in_lcy_ccy);
    dbg('Total Charges in txn ccy->' || l_tot_chg_amount_in_txn_ccy);
    dbg('Total Charges in acc ccy->' || l_tot_chg_amount_in_acc_ccy);
  
    -- Net DB Amount (Charges + Txn amount)
    If p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy <> l_ac_ccy Then
      dbg('apple');
      p_ifdrftpp.v_iftbs_rft_master_mob.net_txn_amt := nvl(l_txn_amt, 0) +
                                                       (Nvl(l_tot_chg_amount_in_acc_ccy,
                                                            0));
    
    Elsif p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy = l_ac_ccy Then
      dbg('mango');
      p_ifdrftpp.v_iftbs_rft_master_mob.net_txn_amt := nvl(p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt,
                                                           0) +
                                                       (Nvl(l_tot_chg_amount_in_acc_ccy,
                                                            0));
    
    End If;
    dbg('p_ifdrftpp.v_iftbs_rft_master_mob.net_txn_amt->' ||
        p_ifdrftpp.v_iftbs_rft_master_mob.net_txn_amt);
  
    dbg('got l_rel_customer' || l_rel_customer);
  
    dbg('Returning Success From FN_ENRICH_PRODUCT..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.FN_ENRICH_PRODUCT ..');
      debug.pr_debug('**', SQLERRM);
      debug.pr_debug('AC',
                     'ERROR LINE NUMBER=' ||
                     DBMS_UTILITY.format_error_backtrace);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_enrich_product;

  FUNCTION FN_RFT_TXN_SAVE(p_ifdrftpp              IN OUT ifpks_ifdrftpp_Main.ty_ifdrftpp,
                           pkg_detb_rtl_teller_rec IN OUT detbs_rtl_teller%ROWTYPE,
                           p_err_code              IN OUT VARCHAR2,
                           p_err_params            IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    l_cust_ac    sttm_cust_account%ROWTYPE;
    l_arc_maint  iftms_arc_maint%ROWTYPE;
    l_cust       sttm_customer%ROWTYPE;
    l_prod       cstm_product%ROWTYPE;
    l_ib_flag    VARCHAR2(1) DEFAULT 'Y';
    l_txn_amt    iftbs_fast_master.txn_amt%TYPE;
    l_txn_amt1   iftbs_fast_master.txn_amt%TYPE;
    l_rate       NUMBER;
    l_rate_code  cstm_product.rate_code_preferred%Type;
    l_rate_code1 cstm_product.rate_code_preferred%Type;
  
  BEGIN
    dbg('INSIDE FN_RFT_TXN_SAVE');
  
    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdrftpp.v_iftbs_rft_master_mob.product_code;
  
    p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow := 'O';
  
    IF p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow = 'O' THEN
    
      SELECT x.*
        INTO l_cust_ac
        FROM sttm_cust_account x
       WHERE x.cust_ac_no = p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc;
    
      -- msg id
      --IF p_ifdrftpp.v_iftbs_rft_master_mob.transfer_mode = 'F' THEN
      /*IF NOT
          fn_gen_out_msg_pay_id(p_ifdrftpp,
                                p_ifdrftpp.v_iftbs_rft_master_mob.msg_id,
                                p_ifdrftpp.v_iftbs_rft_master_mob.pay_id,
                                p_ifdrftpp.v_iftbs_rft_master_mob.instr_id) THEN
        dbg('Failed in generation Msg id');
        RETURN FALSE;
      END IF;*/
    
      -- end to end id
      p_ifdrftpp.v_iftbs_rft_master_mob.etend_id := p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc || '-' ||
                                                    p_ifdrftpp.v_iftbs_rft_master_mob.ben_acc;
    
      --END IF;
    ELSE
    
      SELECT x.*
        INTO l_cust_ac
        FROM sttm_cust_account x
       WHERE x.cust_ac_no = p_ifdrftpp.v_iftbs_rft_master_mob.ben_acc;
    
    END IF;
  
    SELECT x.*
      INTO l_cust
      FROM sttm_customer x
     WHERE x.customer_no = l_cust_ac.cust_no;
  
    IF p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow = 'O' THEN
      cspkss_arc.pr_get_arc_row(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                p_ifdrftpp.v_iftbs_rft_master_mob.product_code,
                                'P',
                                '*.*', -- trans_type
                                p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                l_ib_flag,
                                l_arc_maint,
                                p_err_code,
                                p_err_params,
                                p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc,
                                p_ifdrftpp.v_iftbs_rft_master_mob.branch_code);
    ELSE
      cspkss_arc.pr_get_arc_row(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                p_ifdrftpp.v_iftbs_rft_master_mob.product_code,
                                'P',
                                '*.*', -- trans_type
                                p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                l_ib_flag,
                                l_arc_maint,
                                p_err_code,
                                p_err_params,
                                p_ifdrftpp.v_iftbs_rft_master_mob.ben_acc,
                                p_ifdrftpp.v_iftbs_rft_master_mob.branch_code);
    END IF;
  
    IF p_err_code IS NOT NULL THEN
      dbg('CSPKSS_ARC.PR_GET_ARC_ROW returned false');
      RETURN FALSE;
    END IF;
  
    p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow := 'O'; --sampath
  
    IF p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow = 'O' THEN
      IF NOT
          cspkss_arc.fn_charge_pickup(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.product_code,
                                      'P',
                                      p_ifdrftpp.v_iftbs_rft_master_mob.product_code,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                      l_cust_ac.cust_no,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      NULL,
                                      l_cust_ac.cust_no,
                                      l_ib_flag,
                                      depks_rtl_teller.pkg_arc_row,
                                      p_err_code,
                                      p_err_params,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.branch_code) THEN
        dbg('CHARGE PICKUP failed');
        RETURN FALSE;
      END IF;
    ELSE
      IF NOT
          cspkss_arc.fn_charge_pickup(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.product_code,
                                      'P',
                                      p_ifdrftpp.v_iftbs_rft_master_mob.product_code,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                      l_cust_ac.cust_no,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      NULL,
                                      l_cust_ac.cust_no,
                                      l_ib_flag,
                                      depks_rtl_teller.pkg_arc_row,
                                      p_err_code,
                                      p_err_params,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.ben_acc,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.branch_code) THEN
        dbg('CHARGE PICKUP failed');
        RETURN FALSE;
      END IF;
    END IF;
  
    pkg_detb_rtl_teller_rec.xref         := p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no;
    pkg_detb_rtl_teller_rec.product_code := p_ifdrftpp.v_iftbs_rft_master_mob.product_code;
    pkg_detb_rtl_teller_rec.branch_code  := p_ifdrftpp.v_iftbs_rft_master_mob.branch_code;
    pkg_detb_rtl_teller_rec.trn_ref_no   := p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no;
  
    IF p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow = 'O' THEN
      pkg_detb_rtl_teller_rec.txn_acc := p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc;
      pkg_detb_rtl_teller_rec.txn_ccy := l_cust_ac.ccy;
      --pkg_detb_rtl_teller_rec.txn_branch := p_ifdrftpp.v_iftbs_rft_master_mob.branch_code;
      pkg_detb_rtl_teller_rec.txn_branch := l_cust_ac.branch_code;
    
      pkg_detb_rtl_teller_rec.ofs_acc    := l_arc_maint.cod_offset_acc;
      pkg_detb_rtl_teller_rec.ofs_ccy    := p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy;
      pkg_detb_rtl_teller_rec.ofs_amount := p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt;
      /* pkg_detb_rtl_teller_rec.ofs_branch := REPLACE(l_arc_maint.cod_offset_brn,
                                                      '*.*',
                                                      p_ifdrftpp.v_iftbs_rft_master_mob.branch_code);
      */
      --Get Nostro Account Branch for the offset leg
      BEGIN
        SELECT BRANCH_CODE
          INTO pkg_detb_rtl_teller_rec.ofs_branch
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = pkg_detb_rtl_teller_rec.ofs_acc;
      EXCEPTION
        WHEN OTHERS THEN
          pkg_detb_rtl_teller_rec.ofs_branch := '991';
      END;
    
      -- Begin ACCOUNTING ENTRIES Display and fix for Wrong Exch calculation
      IF p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy <> l_cust_ac.ccy THEN
        l_rate     := NULL;
        l_txn_amt1 := p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt;
      
        If l_prod.rate_code_preferred = 'B' --and p_ifdrftpp.v_iftbs_rft_master_mob.transfer_mode in ('F')
         Then
          l_rate_code := Null;
          If (p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy = global.lcy and
             l_cust_ac.ccy != global.lcy) Or
             (p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy != global.lcy and
             l_cust_ac.ccy <> global.lcy and
             p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy <> l_cust_ac.ccy) Then
            l_rate_code := 'B';
          Elsif p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy != global.lcy and
                l_cust_ac.ccy = global.lcy --and p_ifdrftpp.v_iftbs_rft_master_mob.transfer_mode = 'L' 
           Then
            l_rate_code := 'S';
          Else
            l_rate_code := l_prod.rate_code_preferred;
          End If;
        Else
          l_rate_code := l_prod.rate_code_preferred;
        End If;
      
        dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
            l_rate_code1);
        If l_cust_ac.ccy <> global.lcy Then
          begin
            select decode(l_rate_code,
                          'B',
                          'S',
                          'S',
                          'B',
                          'M',
                          'M',
                          l_rate_code)
              Into l_rate_code1
              from dual;
          exception
            when others then
              dbg('Exception found l_rate_code-> ' || l_rate_code);
          end;
        End If;
        dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
            l_rate_code1);
      
        IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy,
                                      l_cust_ac.ccy,
                                      l_txn_amt1,
                                      p_ifdrftpp.v_iftbs_rft_master_mob.exch_rate,
                                      'Y',
                                      l_txn_amt,
                                      p_err_params) THEN
          RETURN FALSE;
        END IF;
      END IF;
      dbg('l_txn_amt1->' || l_txn_amt1);
      dbg('l_txn_amt1->' || l_txn_amt);
      pkg_detb_rtl_teller_rec.txn_amount := l_txn_amt;
      -- END
    
    END IF;
    pkg_detb_rtl_teller_rec.txn_trn_code     := l_arc_maint.cod_main_txn_code;
    pkg_detb_rtl_teller_rec.ofs_trn_code     := l_arc_maint.cod_offset_txn_code;
    pkg_detb_rtl_teller_rec.exch_rate        := p_ifdrftpp.v_iftbs_rft_master_mob.exch_rate;
    pkg_detb_rtl_teller_rec.trn_dt           := p_ifdrftpp.v_iftbs_rft_master_mob.transfer_date;
    pkg_detb_rtl_teller_rec.value_dt         := p_ifdrftpp.v_iftbs_rft_master_mob.transfer_date;
    pkg_detb_rtl_teller_rec.rel_customer     := l_cust_ac.cust_no;
    pkg_detb_rtl_teller_rec.benef_name       := l_cust.customer_name1;
    pkg_detb_rtl_teller_rec.benef_addr1      := l_cust.address_line1;
    pkg_detb_rtl_teller_rec.benef_addr2      := l_cust.address_line2;
    pkg_detb_rtl_teller_rec.benef_addr3      := l_cust.address_line3;
    pkg_detb_rtl_teller_rec.benef_addr4      := l_cust.address_line4;
    pkg_detb_rtl_teller_rec.liqn_dt          := p_ifdrftpp.v_iftbs_rft_master_mob.transfer_date;
    pkg_detb_rtl_teller_rec.record_stat      := 'A';
    pkg_detb_rtl_teller_rec.auth_stat        := 'U';
    pkg_detb_rtl_teller_rec.maker_id         := GLOBAL.USER_ID; --p_ifdrftpp.v_iftbs_rft_master_mob.maker_id;
    pkg_detb_rtl_teller_rec.maker_dt_stamp   := p_ifdrftpp.v_iftbs_rft_master_mob.maker_dt_stamp;
    pkg_detb_rtl_teller_rec.checker_id       := p_ifdrftpp.v_iftbs_rft_master_mob.checker_id;
    pkg_detb_rtl_teller_rec.checker_dt_stamp := p_ifdrftpp.v_iftbs_rft_master_mob.checker_dt_stamp;
    pkg_detb_rtl_teller_rec.mod_no           := p_ifdrftpp.v_iftbs_rft_master_mob.mod_no;
    pkg_detb_rtl_teller_rec.scode            := p_ifdrftpp.v_iftbs_rft_master_mob.source_code;
    pkg_detb_rtl_teller_rec.dr_acc           := l_arc_maint.dr_acc;
    pkg_detb_rtl_teller_rec.module           := 'RT';
    pkg_detb_rtl_teller_rec.esn              := 1;
    pkg_detb_rtl_teller_rec.event_code       := 'INIT';
    pkg_detb_rtl_teller_rec.track_receivable := 'N';
    pkg_detb_rtl_teller_rec.time_received    := SYSDATE;
  
    -- 1
    FOR k IN 1 .. p_ifdrftpp.v_iftbs_rft_charge.count LOOP
      IF k = 1 THEN
        dbg('CHG AMT' || p_ifdrftpp.v_iftbs_rft_charge(k).chg1_amt);
        IF p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow = 'O' THEN
          pkg_detb_rtl_teller_rec.charge_account := p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc;
        ELSE
          pkg_detb_rtl_teller_rec.charge_account := p_ifdrftpp.v_iftbs_rft_master_mob.ben_acc;
        END IF;
        pkg_detb_rtl_teller_rec.chg_gl           := l_arc_maint.cod_chg_gl;
        pkg_detb_rtl_teller_rec.chg_ccy          := l_arc_maint.cod_chg_ccy;
        pkg_detb_rtl_teller_rec.chg_amt          := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                    .chg1_amt;
        depks_rtl_teller.pkg_arc_row.cod_chg_amt := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                    .chg1_amt;
      
        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt);
        depks_rtl_teller.pkg_arc_row.cod_chg_type := l_arc_maint.cod_chg_type;
      
        IF l_arc_maint.cod_chg_ccy <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                     l_arc_maint.cod_chg_ccy,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdrftpp.v_iftbs_rft_charge(k).chg1_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy       := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                      .chg1_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate := 1;
        END IF;
      
        DBG('pkg_detb_rtl_teller_rec.chg_in_acy=' ||
            pkg_detb_rtl_teller_rec.chg_in_acy);
        DBG('pkg_detb_rtl_teller_rec.chg_ccy_acy_rate=' ||
            pkg_detb_rtl_teller_rec.chg_ccy_acy_rate);
      
        pkg_detb_rtl_teller_rec.chg_in_lcy   := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                .lcy_chg1;
        pkg_detb_rtl_teller_rec.acy_lcy_rate := p_ifdrftpp.v_iftbs_rft_master_mob.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind  := l_arc_maint.cod_chg_netting;
        pkg_detb_rtl_teller_rec.txn_code     := l_arc_maint.cod_chg_txn_code;
        pkg_detb_rtl_teller_rec.mis_head_1   := l_arc_maint.cod_mis_head;
        pkg_detb_rtl_teller_rec.chg_desc     := l_arc_maint.cod_chg_desc;
        pkg_detb_rtl_teller_rec.chg_type     := l_arc_maint.cod_chg_type;
        pkg_detb_rtl_teller_rec.waiver       := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                .chg1_waiver;
        pkg_detb_rtl_teller_rec.their_chgs   := l_arc_maint.cod_their_chgs;
      END IF;
      -- 2
      IF k = 2 THEN
        pkg_detb_rtl_teller_rec.chg_gl_1  := l_arc_maint.cod_chg_gl1;
        pkg_detb_rtl_teller_rec.chg_ccy_1 := l_arc_maint.cod_chg_ccy1;
        pkg_detb_rtl_teller_rec.chg_amt_1 := p_ifdrftpp.v_iftbs_rft_charge(k)
                                             .chg2_amt;
      
        depks_rtl_teller.pkg_arc_row.cod_chg_amt1 := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                     .chg2_amt;
      
        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT1' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt1);
        depks_rtl_teller.pkg_arc_row.cod_chg_type1 := l_arc_maint.cod_chg_type1;
      
        IF l_arc_maint.cod_chg_ccy1 <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                     l_arc_maint.cod_chg_ccy1,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdrftpp.v_iftbs_rft_charge(k).chg2_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy_1,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_1       := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                        .chg2_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1 := 1;
        END IF;
      
        pkg_detb_rtl_teller_rec.chg_in_lcy_1   := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                  .lcy_chg2;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_1 := p_ifdrftpp.v_iftbs_rft_master_mob.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_1  := l_arc_maint.cod_chg_netting1;
        pkg_detb_rtl_teller_rec.txn_code_1     := l_arc_maint.cod_chg_txn_code1;
        pkg_detb_rtl_teller_rec.mis_head_2     := l_arc_maint.cod_mis_head1;
        pkg_detb_rtl_teller_rec.chg_desc1      := l_arc_maint.cod_chg_desc1;
        pkg_detb_rtl_teller_rec.chg_type1      := l_arc_maint.cod_chg_type1;
        pkg_detb_rtl_teller_rec.waiver1        := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                  .chg2_waiver;
        pkg_detb_rtl_teller_rec.their_chgs1    := l_arc_maint.cod_their_chgs1;
      END IF;
      /*-- 3
      IF k = 3 THEN
        pkg_detb_rtl_teller_rec.chg_gl_2  := l_arc_maint.cod_chg_gl2;
        pkg_detb_rtl_teller_rec.chg_ccy_2 := l_arc_maint.cod_chg_ccy2;
        pkg_detb_rtl_teller_rec.chg_amt_2 := p_ifdrftpp.v_iftbs_rft_charge(k)
                                             .chg3_amt;
      
        depks_rtl_teller.pkg_arc_row.cod_chg_amt2 := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                     .chg3_amt;
      
        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT2' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt2);
        depks_rtl_teller.pkg_arc_row.cod_chg_type2 := l_arc_maint.cod_chg_type2;
      
        IF l_arc_maint.cod_chg_ccy2 <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdrftpp.v_iftbs_rft_master_mob.branch_code,
                                     l_arc_maint.cod_chg_ccy2,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdrftpp.v_iftbs_rft_charge(k).chg3_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy_2,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_2,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_2       := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                        .chg3_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_2 := 1;
        END IF;
      
        pkg_detb_rtl_teller_rec.chg_in_lcy_2   := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                  .lcy_chg3;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_2 := p_ifdrftpp.v_iftbs_rft_master_mob.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_2  := l_arc_maint.cod_chg_netting2;
        pkg_detb_rtl_teller_rec.txn_code_2     := l_arc_maint.cod_chg_txn_code2;
        pkg_detb_rtl_teller_rec.mis_head_3     := l_arc_maint.cod_mis_head2;
        pkg_detb_rtl_teller_rec.chg_desc2      := l_arc_maint.cod_chg_desc2;
        pkg_detb_rtl_teller_rec.chg_type2      := l_arc_maint.cod_chg_type2;
        pkg_detb_rtl_teller_rec.waiver2        := p_ifdrftpp.v_iftbs_rft_charge(k)
                                                  .chg3_waiver;
        pkg_detb_rtl_teller_rec.their_chgs2    := l_arc_maint.cod_their_chgs2;
      END IF;*/
    
    END LOOP;
  
    dbg('Calling depks_rtl_teller.fn_save');
  
    IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                    p_err_code,
                                    p_err_params) THEN
      dbg('Failed in Fn_Save');
      RETURN FALSE;
    END IF;
    dbg('Calling depks_rtl_teller.pr_messaging');
    --depks_rtl_teller.pr_messaging;
  
    dbg('Returning Success From FN_RFT_TXN_SAVE..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.FN_RFT_TXN_SAVE ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END FN_RFT_TXN_SAVE;

  FUNCTION FN_RFT_MSG_GEN(p_ifdrftpp   IN OUT ifpks_ifdrftpp_Main.ty_ifdrftpp,
                          p_msg        IN OUT CLOB,
                          p_err_code   IN OUT VARCHAR2,
                          p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_xml_hdr_comp VARCHAR2(1000) := '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
                                     <Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.05"
                                     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="xsd/pain.001.001.05.xsd"> ';
  
    l_xml_tag     CLOB;
    l_date        VARCHAR2(23);
    l_reqdexctndt VARCHAR2(23);
    l_gl_walkin   VARCHAR2(35);
    l_str1        VARCHAR2(10);
    l_date_ins    DATE;
    l_instr_id    VARCHAR2(35);
    l_etend_id    VARCHAR2(35);
  BEGIN
    dbg('In FN_RFT_MSG_GEN..');
    dbg('Start of pr_gen_pain_001_001_05');
    dbg('Message Identfication' ||
        p_ifdrftpp.v_iftbs_rft_master_mob.msg_id);
    l_date        := to_char(SYSDATE, 'YYYY-MM-DD') || 'T' ||
                     to_char(SYSDATE, 'hh24:MM:SS');
    l_reqdexctndt := to_char(SYSDATE, 'YYYY-MM-DD');
    l_str1        := substr(l_date, 1, 10);
    l_date_ins    := to_date(l_str1, 'YYYY-MM-DD');
    dbg('Date-->' || l_date);
    dbg('Date_INS-->' || l_date_ins);
  
    dbms_lob.createtemporary(l_xml_tag, cache => TRUE);
  
    /*SELECT cod_txn_account
      INTO l_gl_walkin
      FROM iftm_arc_maint
     WHERE cod_prod_acc_cls = p_ifdrftpp.v_iftbs_rft_master_mob.product_code;
    
    dbg('l_GL_Walkin-->' || l_gl_walkin);*/
  
    l_xml_hdr_comp := l_xml_hdr_comp || chr(10) || '<CstmrCdtTrfInitn>' ||
                      chr(10);
    l_xml_hdr_comp := l_xml_hdr_comp || '<GrpHdr>' || chr(10);
  
    dbms_lob.append(l_xml_tag, l_xml_hdr_comp);
  
    dbg('Going to for loop');
  
    dbg('Msg_id-->' || p_ifdrftpp.v_iftbs_rft_master_mob.msg_id);
    dbms_lob.append(l_xml_tag,
                    '<MsgId>' || p_ifdrftpp.v_iftbs_rft_master_mob.msg_id ||
                    '</MsgId>' || chr(10));
  
    dbms_lob.append(l_xml_tag,
                    '<CreDtTm>' || l_date || '</CreDtTm>' || chr(10));
    dbms_lob.append(l_xml_tag,
                    '<NbOfTxs>' || '1' || '</NbOfTxs>' || chr(10));
  
    dbg('Total transfer amount-->' ||
        p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt);
    dbms_lob.append(l_xml_tag,
                    '<CtrlSum>' ||
                    p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt ||
                    '</CtrlSum>' || chr(10));
    dbms_lob.append(l_xml_tag,
                    '<InitgPty>' || chr(10) || '<Nm>' || 'Prince Bank PLC' ||
                    '</Nm>' || chr(10) || '</InitgPty>' || chr(10));
  
    dbms_lob.append(l_xml_tag, '</GrpHdr>' || chr(10));
  
    dbg('PAYMNT_IDENT_CODE -->' ||
        p_ifdrftpp.v_iftbs_rft_master_mob.pay_id); -- PAY_ID
  
    dbg('REQ_EXEC_DATE -->' || l_date);
  
    dbms_lob.append(l_xml_tag,
                    '<PmtInf>' || chr(10) || '<PmtInfId>' ||
                    p_ifdrftpp.v_iftbs_rft_master_mob.pay_id ||
                    '</PmtInfId>' || -- PAY_ID
                    chr(10) || '<PmtMtd>' || 'TRF' || '</PmtMtd>' ||
                    chr(10) || '<BtchBookg>' || 'false' || '</BtchBookg>' ||
                    chr(10) || '<ReqdExctnDt>' || l_reqdexctndt ||
                    '</ReqdExctnDt>' || chr(10));
  
    dbms_lob.append(l_xml_tag,
                    '<Dbtr>' || chr(10) || '<Nm>' ||
                    p_ifdrftpp.v_iftbs_rft_master_mob.rem_name || '</Nm>' ||
                    chr(10) || '</Dbtr>' || chr(10));
  
    dbg('Account number  -->' || p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc);
  
    dbms_lob.append(l_xml_tag,
                    '<DbtrAcct>' || chr(10) || '<Id>' || chr(10) ||
                    '<Othr>' || chr(10) || '<Id>' ||
                    p_ifdrftpp.v_iftbs_rft_master_mob.rem_acc || '</Id>' ||
                    chr(10) || '</Othr>' || chr(10) || '</Id>' || chr(10) ||
                    '<Ccy>' || p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy ||
                    '</Ccy>' || chr(10) || '</DbtrAcct>' || chr(10));
  
    dbms_lob.append(l_xml_tag,
                    '<DbtrAgt>' || chr(10) || '<FinInstnId>' || chr(10) ||
                    '<BICFI>' || 'PINCXXXX' || '</BICFI>' || chr(10) ||
                    '</FinInstnId>' || chr(10) || '</DbtrAgt>' || chr(10));
  
    dbg('p_ifdrftpp.v_iftbs_rft_master_mob.etend_id' ||
        p_ifdrftpp.v_iftbs_rft_master_mob.etend_id);
    dbg('p_ifdrftpp.v_iftbs_rft_master_mob.instr_id' ||
        p_ifdrftpp.v_iftbs_rft_master_mob.instr_id);
  
    SELECT instr_id, etend_id
      INTO l_instr_id, l_etend_id
      FROM iftb_rft_master
     WHERE trn_ref_no = p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no;
  
    dbms_lob.append(l_xml_tag,
                    '<CdtTrfTxInf>' || chr(10) || '<PmtId>' || chr(10) ||
                    '<InstrId>' || nvl(p_ifdrftpp.v_iftbs_rft_master_mob.instr_id,
                                       l_instr_id) || '</InstrId>' ||
                    chr(10) || '<EndToEndId>' ||
                    nvl(p_ifdrftpp.v_iftbs_rft_master_mob.etend_id,
                        l_etend_id) || '</EndToEndId>' || chr(10) ||
                    '</PmtId>' || chr(10) || '<Amt>' || chr(10) ||
                    '<InstdAmt Ccy = "' ||
                    p_ifdrftpp.v_iftbs_rft_master_mob.txn_ccy || '">' ||
                    p_ifdrftpp.v_iftbs_rft_master_mob.txn_amt ||
                    '</InstdAmt>' || chr(10) || '</Amt>' || chr(10) ||
                    '<ChrgBr>' || 'CRED' || '</ChrgBr>' || chr(10));
  
    dbg('BEN_BIC  -->' || p_ifdrftpp.v_iftbs_rft_master_mob.ben_bic);
  
    /*dbms_lob.append(l_xml_tag,
    '<CdtrAgt>' || chr(10) || '<FinInstnId>' || chr(10) ||
    '<BICFI>' || 'ACLB' || 'XXXX' || '</BICFI>' || chr(10) ||
    '</FinInstnId>' || chr(10) || '</CdtrAgt>' || chr(10));*/
  
    dbms_lob.append(l_xml_tag,
                    '<CdtrAgt>' || chr(10) || '<FinInstnId>' || chr(10) ||
                    '<BICFI>' ||
                    SUBSTR(p_ifdrftpp.v_iftbs_rft_master_mob.BEN_BIC, 1, 4) ||
                    'XXXX' || '</BICFI>' || chr(10) || '</FinInstnId>' ||
                    chr(10) || '</CdtrAgt>' || chr(10));
  
    dbg('BENEF_NAME  -->' || p_ifdrftpp.v_iftbs_rft_master_mob.ben_name);
  
    dbms_lob.append(l_xml_tag,
                    '<Cdtr>' || chr(10) || '<Nm>' ||
                    p_ifdrftpp.v_iftbs_rft_master_mob.ben_name || '</Nm>' ||
                    chr(10) || '</Cdtr>' || chr(10));
  
    dbg('BEN_ACCOUNT  -->' || p_ifdrftpp.v_iftbs_rft_master_mob.ben_acc);
  
    dbms_lob.append(l_xml_tag,
                    '<CdtrAcct>' || chr(10) || '<Id>' || chr(10) ||
                    '<Othr>' || chr(10) || '<Id>' ||
                    p_ifdrftpp.v_iftbs_rft_master_mob.ben_acc || '</Id>' ||
                    chr(10) || '</Othr>' || chr(10) || '</Id>' || chr(10) ||
                    '</CdtrAcct>' || chr(10));
  
    dbms_lob.append(l_xml_tag,
                    '<Purp>' || chr(10) || '<Cd>' || 'GDDS' || '</Cd>' ||
                    chr(10) || '</Purp>' || chr(10));
  
    dbg('DESCRIPTION  -->' ||
        p_ifdrftpp.v_iftbs_rft_master_mob.ben_remarks);
  
    dbms_lob.append(l_xml_tag,
                    '<RmtInf>' || chr(10) || '<Ustrd>' ||
                    p_ifdrftpp.v_iftbs_rft_master_mob.ben_remarks || '/' ||
                    substr(p_ifdrftpp.v_iftbs_rft_master_mob.pay_id, -8) ||
                    '</Ustrd>' || chr(10) || '<Strd>' || chr(10) ||
                    '<RfrdDocInf>' || chr(10) || '<Tp>' || chr(10) ||
                    '<CdOrPrtry>' || chr(10) || '<Cd>' || 'CINV' || '</Cd>' ||
                    chr(10) || '</CdOrPrtry>' || chr(10) || '</Tp>' ||
                    chr(10) || '<Nb>' || '987-AC' || '</Nb>' || chr(10) ||
                    '<RltdDt>' || to_char(SYSDATE, 'YYYY-MM-DD') ||
                    '</RltdDt>' || chr(10) || '</RfrdDocInf>' || chr(10) ||
                    '</Strd>' || chr(10) || '</RmtInf>' || chr(10));
  
    dbms_lob.append(l_xml_tag,
                    '</CdtTrfTxInf>' || chr(10) || '</PmtInf>' || chr(10));
    l_xml_tag := l_xml_tag || '</CstmrCdtTrfInitn>' || chr(10);
    l_xml_tag := l_xml_tag || '</Document>' || chr(10);
    dbg('Final message-->' || dbms_lob.substr(l_xml_tag, 32767, 1));
    p_msg := l_xml_tag;
    dbms_lob.freetemporary(l_xml_tag);
    dbg('Returning Success From FN_FAST_OUT_MSG_GEN..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.FN_RFT_MSG_GEN ..');
      debug.pr_debug('**', SQLERRM);
      dbms_lob.freetemporary(l_xml_tag);
      p_err_code   := 'IF-FAST-009';
      p_err_params := 'Can not generate pain_001.001.05';
      RETURN FALSE;
  END FN_RFT_MSG_GEN;

  FUNCTION FN_CLOBREPLACE(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;
  
    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END FN_CLOBREPLACE;

  FUNCTION FN_RFT_PHONEBASE_HTTP_CALL(p_out_msg VARCHAR2,
                                      p_in_resp IN OUT CLOB) RETURN BOOLEAN IS
  
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255); -- := 'http://10.80.80.11:8282/prnc-app/nbc/rft-out/rcpt-acct-inq';
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);
  
    /*content varchar2(4000) := '{
        "chnlCd": "01",
        "sndAcctNo": "000162694",
        "sndNm": "borey1111111111111111111111111111111",
        "rcvBkCd": "001",
        "rcvAcctNo": "11111111111111111",
        "crrcy": "KHR",
        "amt": "2000"
    }';*/
  
    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;
  
  BEGIN
    dbg('START OF FN_RFT_HTTP_CALL');
  
    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));
  
    L_URL := FN_GET_PARAM_VAL('PGW_NBC_RFT_CREATE_PASSCD_URL');
  
    DBG('l_url-->' || L_URL);
  
    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');
    --utl_http.set_authentication( req, '','', '' );
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
  
    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
  
    utl_http.write_text(l_http_request, p_out_msg);
  
    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));
  
    l_http_response := utl_http.get_response(l_http_request);
  
    dbg('Response> status_code: "' || l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;
    
      p_in_resp := buffer1;
    
      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    dbms_lob.freetemporary(buffer1); --buffer2 may be check
  
    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('error line number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_RFT_PHONEBASE_HTTP_CALL;

  FUNCTION fn_msg_upload(p_source      IN VARCHAR2,
                         p_function_id IN VARCHAR2,
                         p_ifdrftpp    IN OUT ifpks_ifdrftpp_Main.ty_ifdrftpp,
                         p_msg         IN OUT CLOB,
                         p_err_code    IN OUT VARCHAR2,
                         p_err_params  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
    l_in_resp       CLOB;
    e_update_error EXCEPTION;
    L_TXNSTATUS_CODE iftb_rft_master_mob.txn_status%TYPE := fn_get_param_val('PGW_TEMP_TXN_STAT');
    L_TXNSTATUS_MSG  iftb_rft_master_mob.txn_remarks%TYPE := fn_get_param_val('PGW_TEMP_TXN_REMARKS');
    l_pos            NUMBER := 0;
    r_pos            NUMBER := 0;
    L_RESP_IN_XML    clob;
    P_DOCUMENT_XML   XMLTYPE;
    L_RFT_PASSCODE   iftb_rft_master_mob.rft_passcode%type;
  
  BEGIN
    dbg('Inside fn_msg_upload - inserting to iftbs_pgw_msgs');
  
    /*INSERT INTO iftbs_pgw_msgs
    VALUES
      (p_ifdrftpp.v_iftbs_rft_master_mob.msg_id,
       p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no,
       p_ifdrftpp.v_iftbs_rft_master_mob.transfer_mode,
       p_msg,
       NULL,
       csfn_timestamp,
       p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow,
       'G');*/
  
    dbg('Insert done');
    --dbg('transfer mode' || p_ifdrftpp.v_iftbs_rft_master_mob.transfer_mode);
  
    IF NOT FN_RFT_PHONEBASE_HTTP_CALL(p_msg, L_IN_RESP) THEN
      DBG('FAILED TO CALL CREATE PASSCODE WEBSERVICE');
      RAISE E_UPDATE_ERROR;
    END IF;
  
    DBG('Sent and response in json is ' || L_IN_RESP);
  
    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    debug.pr_debug('IF', 'L_RESP_IN_XML=' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('One step done-->' || L_RESP_IN_XML);
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('Two step done and after UNESCAPE, it is ' || L_RESP_IN_XML);
  
    DBG('After cutting other irrelevant parts , it is ' || L_RESP_IN_XML);
  
    --Update the table
    --PR_MSG_UPDATE(p_ifdrftpp.v_iftbs_rft_master.msg_id, L_IN_RESP);
  
    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
  
    --check if it is already refunded by other bank since message id is different
    L_TXNSTATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                        .GETSTRINGVAL;
  
    L_TXNSTATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                        .GETSTRINGVAL;
  
    L_TXNSTATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                       .GETSTRINGVAL;
  
    DBG('L_TXNSTATUS_CODE=' || L_TXNSTATUS_CODE);
    DBG('L_TXNSTATUS_MSG=' || L_TXNSTATUS_MSG); -- COMMENTED TEMPORARILY FOR OFFSHORE TESTING - ALL TXN TO GO AS ACCEPTED
  
    L_RFT_PASSCODE := P_DOCUMENT_XML.EXTRACT('/root/data/passCd/text()')
                      .GETSTRINGVAL;
  
    DBG('L_RFT_PASSCODE=' || L_RFT_PASSCODE);
  
    p_ifdrftpp.v_iftbs_rft_master_mob.rft_passcode := L_RFT_PASSCODE;
  
    IF L_TXNSTATUS_CODE = 'RJCT' THEN
      dbg('Transaction Rejected. Cannot procede further.');
      p_err_code   := 'GI-FST-013';
      p_err_params := NULL; --l_rejreason || '~'; Pls check
    
      dbg('Need to DELETE any accounting entries fired UNAUTH since it is REJT from NBC-->' ||
          p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no || '~' ||
          p_ifdrftpp.v_iftbs_rft_master_mob.msg_id);
    
      IF NOT depks_rtl_teller.fn_delete(p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
      
        dbg('Fail in DELETE accounting entries');
        RAISE e_update_error;
      END IF;
    
      --PR_UPDATE_STATUS_FAST_OUTGOING(p_ifdrftpp.v_iftbs_rft_master.TRN_REF_NO,
      --                           L_TXNSTATUS);
    
      pr_log_error(p_function_id,
                   p_source,
                   'IF-FST006',
                   L_TXNSTATUS_CODE || '~' || null); --l_rejreason);
    
    ELSE
    
      --Post Accounting Entries only for A and 
      --Call getOutgoingTransaction API call
      IF NOT fn_process_entries(p_ifdrftpp, 'A', p_err_code, p_err_params) THEN
        dbg('Fail in AUTH accounting entries');
        RAISE e_update_error;
      END IF;
    
    END IF;
  
    dbg('updated the status and reject reason to ALL transactions in the BATCH');
  
    --PR_UPDATE_STATUS_FAST_OUTGOING(p_ifdrftpp.v_iftbs_rft_master.TRN_REF_NO,
    --                 L_TXNSTATUS);
  
    pr_log_error(p_function_id,
                 p_source,
                 'IF-FST005',
                 L_TXNSTATUS_CODE || '~' || null); --l_rejreason);
  
    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      RETURN FALSE;
  END fn_msg_upload;

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdrftpp         IN OUT ifpks_ifdrftpp_Main.ty_ifdrftpp,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    l_detb_rtl_teller_rec detb_rtl_teller%ROWTYPE;
    l_out_msg             CLOB;
    L_FORMATTED_MSG       CLOB;
  
  BEGIN
  
    dbg('In Fn_Pre_Check_Mandatory' || p_action_code);
    IF p_action_code = 'PICKUP' THEN
      IF NOT fn_enrich_product(p_ifdrftpp, p_err_code, p_err_params) THEN
        dbg('Failed in Fn_Enrich_Product');
        RETURN FALSE;
      END IF;
    END IF;
  
    --Save Transaction
    IF p_action_code = cspks_req_global.p_new THEN
      --GLOBAL.PR_INIT('002','SAMPATH2');
      --DBG('MAKER_ID='||p_ifdrftpp.v_iftbs_rft_master_mob.MAKER_ID);
      IF NOT FN_RFT_TXN_SAVE(p_ifdrftpp,
                             l_detb_rtl_teller_rec,
                             p_err_code,
                             p_err_params) THEN
        dbg('Failed in FN_SAVE');
        RETURN FALSE;
      END IF;
    END IF;
  
    --Modify Transaction
    IF p_action_code = cspks_req_global.p_modify THEN
      dbg('Voila 2');
    
      IF NOT depks_rtl_teller.fn_delete(p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in modify fn_delete');
        RETURN FALSE;
      END IF;
    
      IF NOT FN_RFT_TXN_SAVE(p_ifdrftpp,
                             l_detb_rtl_teller_rec,
                             p_err_code,
                             p_err_params) THEN
        dbg('Failed in modify fn_save');
        RETURN FALSE;
      END IF;
    END IF;
  
    --Delete Transaction
    IF p_action_code = cspks_req_global.p_delete THEN
      IF NOT depks_rtl_teller.fn_delete(p_ifdrftpp.v_iftbs_rft_master_mob.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in FN_DELETE');
        RETURN FALSE;
      END IF;
    END IF;
  
    --Auth Transaction
    IF p_action_code = cspks_req_global.p_auth THEN
    
      p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow := 'O';
    
      IF p_ifdrftpp.v_iftbs_rft_master_mob.msg_flow = 'O' THEN
        --IF p_ifdrftpp.v_iftbs_rft_master_mob.transfer_mode = 'F' THEN
        DBG('p_ifdrftpp.v_iftbs_rft_master_mob.MAKER_ID=' ||
            p_ifdrftpp.v_iftbs_rft_master_mob.MAKER_ID);
        DBG('p_ifdrftpp.v_iftbs_rft_master_mob.CHECKER_ID=' ||
            p_ifdrftpp.v_iftbs_rft_master_mob.CHECKER_ID);
        DBG('GLOBAL.USER_ID' || GLOBAL.USER_ID);
        --Maker Can not authorize
        IF p_ifdrftpp.v_iftbs_rft_master_mob.MAKER_ID = GLOBAL.USER_ID THEN
          pr_log_error(p_function_id, p_source, 'CF-AUT-002', NULL);
          RETURN FALSE;
        END IF;
        --Generate Fast Outgoing message
        /*IF NOT fn_rft_out_msg_gen(p_ifdrftpp,
                                  l_out_msg,
                                  p_err_code,
                                  p_err_params) THEN
          dbg('Failed in fn_rft_out_msg_gen');
          RETURN FALSE;
        END IF;*/
      
        --END IF;
      
        --Get RFT Out Payment Account Enquiry      
        L_FORMATTED_MSG := FN_GET_FORMATTED_PASSCODE(P_IFDRFTPP);
      
        DBG('AFTER REPLACEMENT OF RFT CREATE PASSCODE JSON=' ||
            L_FORMATTED_MSG);
      
        DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);
      
        dbg(' Message generation success, going to upload now');
      
        IF NOT fn_msg_upload(p_source,
                             p_function_id,
                             p_ifdrftpp,
                             L_FORMATTED_MSG,
                             p_err_code,
                             p_err_params) THEN
          dbg('Failed in fn_msg_upload');
          RETURN FALSE;
        
        ELSE
        
          DBG('SUCCESS IN RFT CREATE PASSCODE CALL');
        
        END IF;
        dbg('fn_msg_upload successful');
      END IF;
      dbg('Done with upload process, going to generate advice');
      --depks_rtl_teller.pr_gen_adv_for_contract(p_ifdrftpp.v_iftbs_rft_charge.trn_ref_no);
      dbg('Done with advice generation ');
    END IF;
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of ifpks_ifdrftpp_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdrftpp         IN OUT ifpks_ifdrftpp_Main.Ty_ifdrftpp,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory');
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW) THEN
    
      IF P_IFDRFTPP.V_IFTBS_RFT_MASTER_MOB.REM_PHONE IS NULL THEN
      
        DBG('REMITTER PHONE NUMBER SHOULD NOT BE NULL');
      
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IF-RFT-002', NULL);
      
        RETURN FALSE;
      
      END IF;
    
      --MOBILE NUMBER VALIDATION
      IF NOT FN_MOBILE_VALIDATE(P_IFDRFTPP.V_IFTBS_RFT_MASTER_MOB.REM_PHONE) THEN
      
        DBG('Invalid Phone Number ');
        P_ERR_CODE := 'IF-RFT-003';
        RETURN FALSE;
      
      END IF;
    
      IF P_IFDRFTPP.V_IFTBS_RFT_MASTER_MOB.BEN_PHONE IS NULL THEN
      
        DBG('BENEFICIARY PHONE NUMBER SHOULD NOT BE NULL');
      
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IF-RFT-001', NULL);
      
        RETURN FALSE;
      
      END IF;
    
      --MOBILE NUMBER VALIDATION
      IF NOT FN_MOBILE_VALIDATE(P_IFDRFTPP.V_IFTBS_RFT_MASTER_MOB.BEN_PHONE) THEN
        DBG('Invalid Phone Number ');
        P_ERR_CODE := 'IF-RFT-004';
        RETURN FALSE;
      
      END IF;
    
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpp_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdrftpp         IN ifpks_ifdrftpp_Main.ty_ifdrftpp,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpp_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdrftpp         IN ifpks_ifdrftpp_Main.ty_ifdrftpp,
                                       p_Prev_ifdrftpp    IN OUT ifpks_ifdrftpp_Main.ty_ifdrftpp,
                                       p_Wrk_ifdrftpp     IN OUT ifpks_ifdrftpp_Main.ty_ifdrftpp,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpp_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdrftpp         IN ifpks_ifdrftpp_Main.Ty_ifdrftpp,
                                        p_Prev_ifdrftpp    IN OUT ifpks_ifdrftpp_Main.Ty_ifdrftpp,
                                        p_Wrk_ifdrftpp     IN OUT ifpks_ifdrftpp_Main.Ty_ifdrftpp,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpp_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdrftpp         IN ifpks_ifdrftpp_Main.Ty_ifdrftpp,
                            p_Prev_ifdrftpp    IN ifpks_ifdrftpp_Main.Ty_ifdrftpp,
                            p_Wrk_ifdrftpp     IN OUT ifpks_ifdrftpp_Main.Ty_ifdrftpp,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpp_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdrftpp         IN ifpks_ifdrftpp_Main.Ty_ifdrftpp,
                             p_prev_ifdrftpp    IN ifpks_ifdrftpp_Main.Ty_ifdrftpp,
                             p_wrk_ifdrftpp     IN OUT ifpks_ifdrftpp_Main.Ty_ifdrftpp,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpp_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdrftpp         IN ifpks_ifdrftpp_Main.Ty_ifdrftpp,
                        p_Wrk_ifdrftpp     IN OUT ifpks_ifdrftpp_Main.Ty_ifdrftpp,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpp_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdrftpp         IN ifpks_ifdrftpp_Main.ty_ifdrftpp,
                         p_wrk_ifdrftpp     IN OUT ifpks_ifdrftpp_Main.ty_ifdrftpp,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Query..');
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of ifpks_ifdrftpp_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END ifpks_ifdrftpp_custom;
/