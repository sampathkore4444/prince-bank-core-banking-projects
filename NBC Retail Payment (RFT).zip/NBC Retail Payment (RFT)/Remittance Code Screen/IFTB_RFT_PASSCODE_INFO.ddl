-- Create table
create table IFTB_RFT_PASSCODE_INFO
(
  trn_ref_no VARCHAR2(16) PRIMARY KEY,
  passcode   VARCHAR2(8),
  ben_phone  VARCHAR2(105),
  txn_ccy    VARCHAR2(3),
  txn_amount NUMBER
)
/