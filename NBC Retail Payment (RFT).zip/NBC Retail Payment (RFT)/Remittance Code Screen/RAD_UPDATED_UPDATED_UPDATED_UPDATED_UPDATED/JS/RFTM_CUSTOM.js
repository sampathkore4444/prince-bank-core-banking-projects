function fnPopulateTXNCCY(){

document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value = document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD43").value;


return true;

}
function fnPopulateTXNAMT(){

document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMTI").value = document.getElementById("BLK_TRANSACTION_DETAILS__NUM_FIELD25").value;

return true;

}