CREATE OR REPLACE PACKAGE BODY rfpks_rftm_main AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : rfpks_rftm_main.sql
     **
     ** Module     : RF
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     -------------------------------------------------------------------------------------------------------
     */
     

   g_Ui_Name            VARCHAR2(50) := 'RFTM';
   g_rftm         rfpks_rftm_Main.ty_rftm;
   g_Req_Key                 VARCHAR2(32767);
   --Skip Handler Variables
   g_Skip_Sys       BOOLEAN := FALSE;
   g_Skip_Kernel    BOOLEAN := FALSE;
   g_Skip_Custom    BOOLEAN := FALSE;
   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      IF debug.pkg_debug_on <> 2 THEN
         l_Msg := 'rfpks_rftm_Main ==>'||p_Msg;
         Debug.Pr_Debug('RF' ,l_Msg);
      END IF;
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
      l_Fid    VARCHAR2(32767) := 'RFTM';
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,l_Fid,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      rfpks_rftm_Kernel.Pr_Skip_Handler (P_Stage);
      rfpks_rftm_Custom.Pr_Skip_Handler (P_Stage);
   END Pr_Skip_Handler;
   PROCEDURE Pr_Set_Skip_Sys IS
   BEGIN
      g_Skip_Sys := TRUE;
   END Pr_Set_Skip_Sys;
   PROCEDURE Pr_Set_Activate_Sys IS
   BEGIN
      g_Skip_Sys := FALSE;
   END Pr_Set_Activate_Sys;
   FUNCTION  Fn_Skip_Sys RETURN BOOLEAN IS
   BEGIN
      RETURN G_Skip_Sys;
   END  Fn_Skip_Sys;
   PROCEDURE Pr_Set_Skip_Kernel IS
   BEGIN
      g_Skip_Kernel := TRUE;
   END Pr_Set_Skip_Kernel;
   PROCEDURE Pr_Set_Activate_Kernel IS
   BEGIN
      g_Skip_Kernel := FALSE;
   END Pr_Set_Activate_Kernel;
   FUNCTION  Fn_Skip_Kernel RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type = Cspks_Req_Global.p_Kernel THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Kernel;
      END IF;
   END  Fn_Skip_Kernel;
   PROCEDURE Pr_Set_Skip_Custom IS
   BEGIN
      g_Skip_Custom := TRUE;
   END Pr_Set_Skip_Custom;
   PROCEDURE Pr_Set_Activate_Custom IS
   BEGIN
      g_Skip_Custom := FALSE;
   END Pr_Set_Activate_Custom;
   FUNCTION  Fn_Skip_Custom RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type IN(Cspks_Req_Global.p_Kernel,Cspks_Req_Global.P_Cluster) THEN
         RETURN TRUE;
      ELSIF Cspks_Req_Global.g_Release_Type =Cspks_Req_Global.p_Custom THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Custom;
      END IF;
   END  Fn_Skip_Custom;
   FUNCTION Fn_Sys_Build_Fc_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_rftm       IN   OUT rfpks_rftm_Main.ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;

   BEGIN

      dbg('In Fn_Sys_Build_Fc_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node = 'BLK_TRANSACTION_DETAILS' THEN
            p_rftm.v_detbs_rtl_teller.XREF := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.PRODUCT_CODE := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.EXCH_RATE := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.NARRATIVE := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.BRANCH_CODE := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_rftm.v_detbs_rtl_teller.TRN_DT := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_rftm.v_detbs_rtl_teller.TRN_DT := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_rftm.v_detbs_rtl_teller.TRN_REF_NO := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.MODULE := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.TXN_CCY := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.OFS_CCY := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.OFS_AMOUNT := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.TXN_ACC := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.DR_INSTRUMENT_CODE := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.NUM_FIELD1 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.NUM_FIELD2 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.CHAR_FIELD2 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.NUM_FIELD3 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.TXN_BRANCH := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.REL_CUSTOMER := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.TXN_AMOUNT := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.TXN_TRN_CODE := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.OFS_ACC := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.OFS_BRANCH := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.OFS_TRN_CODE := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.LCY_AMOUNT := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.CHAR_FIELD1 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.NEGOTIATED_RATE := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_detbs_rtl_teller.NEGOTIATION_REF_NO := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.CHAR_FIELD3 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.NUM_FIELD4 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.CHAR_FIELD41 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.CHAR_FIELD42 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.CHAR_FIELD43 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.NUM_FIELD25 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.CHAR_FIELD44 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.CHAR_FIELD45 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.CHAR_FIELD46 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.CHAR_FIELD47 := Cspks_Req_Global.Fn_GetVal;
            p_rftm.v_cstbs_ui_columns.char_field1 :=p_rftm.v_detbs_rtl_teller.xref;
         ELSIF  l_Node = '' THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='CHCD_'||p_Action_Code;
            END IF;
            p_rftm.Ty_chcd := NULL;
            l_key_vals :='XREF'||'>'||p_rftm.v_detbs_rtl_teller.XREF;
            Dbg('Calling Chpks_Chcd_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Chpks_Chcd_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'CHCD',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_rftm.Ty_chcd,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Chpks_Chcd_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         ELSIF  l_Node = '' THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='MDCD_'||p_Action_Code;
            END IF;
            p_rftm.Ty_mdcd := NULL;
            l_key_vals :='XREF'||'>'||p_rftm.v_detbs_rtl_teller.XREF;
            Dbg('Calling Mdpks_Mdcd_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Mdpks_Mdcd_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'MDCD',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_rftm.Ty_mdcd,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Mdpks_Mdcd_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         ELSIF  l_Node = '' THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='UDCD_'||p_Action_Code;
            END IF;
            p_rftm.Ty_udcd := NULL;
            l_key_vals :='XREF'||'>'||p_rftm.v_detbs_rtl_teller.XREF;
            Dbg('Calling Udpks_Udcd_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Udpks_Udcd_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'UDCD',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_rftm.Ty_udcd,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Udpks_Udcd_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         ELSIF  l_Node = '' THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='DMCD_'||p_Action_Code;
            END IF;
            p_rftm.Ty_dmcd := NULL;
            l_key_vals :='XREF'||'>'||p_rftm.v_detbs_rtl_teller.XREF;
            Dbg('Calling Dmpks_Dmcd_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Dmpks_Dmcd_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'DMCD',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_rftm.Ty_dmcd,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Dmpks_Dmcd_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_rftm.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of rfpks_rftm_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Type;
   FUNCTION Fn_Sys_Build_Ws_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_rftm       IN   OUT rfpks_rftm_Main.ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      Invalid_Date        EXCEPTION;

   BEGIN

      dbg('In Fn_Sys_Build_Ws_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node IN ( 'BLK_TRANSACTION_DETAILS','Transaction-Details-Full','Transaction-Details-IO') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key IN( 'EXREFNO','XREF')  THEN
                  p_rftm.v_detbs_rtl_teller.XREF := l_Val;
               ELSIF l_Key = 'PRD' THEN
                  p_rftm.v_detbs_rtl_teller.PRODUCT_CODE := l_Val;
               ELSIF l_Key = 'XRATE' THEN
                  p_rftm.v_detbs_rtl_teller.EXCH_RATE := l_Val;
               ELSIF l_Key = 'NARRATIVE' THEN
                  p_rftm.v_detbs_rtl_teller.NARRATIVE := l_Val;
               ELSIF l_Key = 'BRN' THEN
                  p_rftm.v_detbs_rtl_teller.BRANCH_CODE := l_Val;
               ELSIF l_Key = 'TXNDATE' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_rftm.v_detbs_rtl_teller.TRN_DT := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_rftm.v_detbs_rtl_teller.TRN_DT := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'FCCREF' THEN
                  p_rftm.v_detbs_rtl_teller.TRN_REF_NO := l_Val;
               ELSIF l_Key = 'MODULE' THEN
                  p_rftm.v_detbs_rtl_teller.MODULE := l_Val;
               ELSIF l_Key = 'TXNCCY' THEN
                  p_rftm.v_detbs_rtl_teller.TXN_CCY := l_Val;
               ELSIF l_Key = 'OFFSETCCY' THEN
                  p_rftm.v_detbs_rtl_teller.OFS_CCY := l_Val;
               ELSIF l_Key = 'OFFSETAMT' THEN
                  p_rftm.v_detbs_rtl_teller.OFS_AMOUNT := l_Val;
               ELSIF l_Key IN( 'GL_AC_NO','TXNACC')  THEN
                  p_rftm.v_detbs_rtl_teller.TXN_ACC := l_Val;
               ELSIF l_Key IN( 'REFNO','DRINSTCD')  THEN
                  p_rftm.v_detbs_rtl_teller.DR_INSTRUMENT_CODE := l_Val;
               ELSIF l_Key IN( 'GL_AMT','ACTAMT')  THEN
                  p_rftm.v_cstbs_ui_columns.NUM_FIELD1 := l_Val;
               ELSIF l_Key IN( 'SC_CHG','TCYTOTCHGAMT')  THEN
                  p_rftm.v_cstbs_ui_columns.NUM_FIELD2 := l_Val;
               ELSIF l_Key = 'FT' THEN
                  p_rftm.v_cstbs_ui_columns.CHAR_FIELD2 := l_Val;
               ELSIF l_Key = 'TRANCOUNT' THEN
                  p_rftm.v_cstbs_ui_columns.NUM_FIELD3 := l_Val;
               ELSIF l_Key = 'TXNBRN' THEN
                  p_rftm.v_detbs_rtl_teller.TXN_BRANCH := l_Val;
               ELSIF l_Key = 'RELCUST' THEN
                  p_rftm.v_detbs_rtl_teller.REL_CUSTOMER := l_Val;
               ELSIF l_Key = 'TXNAMT' THEN
                  p_rftm.v_detbs_rtl_teller.TXN_AMOUNT := l_Val;
               ELSIF l_Key = 'TXNTRN' THEN
                  p_rftm.v_detbs_rtl_teller.TXN_TRN_CODE := l_Val;
               ELSIF l_Key = 'OFFSETACC' THEN
                  p_rftm.v_detbs_rtl_teller.OFS_ACC := l_Val;
               ELSIF l_Key = 'OFFSETBRN' THEN
                  p_rftm.v_detbs_rtl_teller.OFS_BRANCH := l_Val;
               ELSIF l_Key = 'OFFSETTRN' THEN
                  p_rftm.v_detbs_rtl_teller.OFS_TRN_CODE := l_Val;
               ELSIF l_Key = 'LCYAMT' THEN
                  p_rftm.v_detbs_rtl_teller.LCY_AMOUNT := l_Val;
               ELSIF l_Key IN( 'GLDESC','ACCTITLE1')  THEN
                  p_rftm.v_cstbs_ui_columns.CHAR_FIELD1 := l_Val;
               ELSIF l_Key = 'NEGOTRATE' THEN
                  p_rftm.v_detbs_rtl_teller.NEGOTIATED_RATE := l_Val;
               ELSIF l_Key = 'NEGOTREFNO' THEN
                  p_rftm.v_detbs_rtl_teller.NEGOTIATION_REF_NO := l_Val;
               ELSIF l_Key IN( 'GLDESC','ACCTITLE2')  THEN
                  p_rftm.v_cstbs_ui_columns.CHAR_FIELD3 := l_Val;
               ELSIF l_Key = 'DENMAMT2' THEN
                  p_rftm.v_cstbs_ui_columns.NUM_FIELD4 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD41' THEN
                  p_rftm.v_cstbs_ui_columns.CHAR_FIELD41 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD42' THEN
                  p_rftm.v_cstbs_ui_columns.CHAR_FIELD42 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD43' THEN
                  p_rftm.v_cstbs_ui_columns.CHAR_FIELD43 := l_Val;
               ELSIF l_Key = 'NUM_FIELD25' THEN
                  p_rftm.v_cstbs_ui_columns.NUM_FIELD25 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD44' THEN
                  p_rftm.v_cstbs_ui_columns.CHAR_FIELD44 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD45' THEN
                  p_rftm.v_cstbs_ui_columns.CHAR_FIELD45 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD46' THEN
                  p_rftm.v_cstbs_ui_columns.CHAR_FIELD46 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD47' THEN
                  p_rftm.v_cstbs_ui_columns.CHAR_FIELD47 := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
            p_rftm.v_cstbs_ui_columns.char_field1 :=p_rftm.v_detbs_rtl_teller.xref;
         ELSIF  l_Node IN ( '','') THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='CHCD_'||p_Action_Code;
            END IF;
            p_rftm.Ty_chcd := NULL;
            l_key_vals :='XREF'||'>'||p_rftm.v_detbs_rtl_teller.XREF;
            Dbg('Calling Chpks_Chcd_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Chpks_Chcd_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'CHCD',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_rftm.Ty_chcd,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Chpks_Chcd_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         ELSIF  l_Node IN ( '','') THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='MDCD_'||p_Action_Code;
            END IF;
            p_rftm.Ty_mdcd := NULL;
            l_key_vals :='XREF'||'>'||p_rftm.v_detbs_rtl_teller.XREF;
            Dbg('Calling Mdpks_Mdcd_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Mdpks_Mdcd_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'MDCD',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_rftm.Ty_mdcd,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Mdpks_Mdcd_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         ELSIF  l_Node IN ( '','') THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='UDCD_'||p_Action_Code;
            END IF;
            p_rftm.Ty_udcd := NULL;
            l_key_vals :='XREF'||'>'||p_rftm.v_detbs_rtl_teller.XREF;
            Dbg('Calling Udpks_Udcd_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Udpks_Udcd_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'UDCD',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_rftm.Ty_udcd,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Udpks_Udcd_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         ELSIF  l_Node IN ( '','') THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='DMCD_'||p_Action_Code;
            END IF;
            p_rftm.Ty_dmcd := NULL;
            l_key_vals :='XREF'||'>'||p_rftm.v_detbs_rtl_teller.XREF;
            Dbg('Calling Dmpks_Dmcd_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Dmpks_Dmcd_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'DMCD',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_rftm.Ty_dmcd,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Dmpks_Dmcd_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_rftm.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN Invalid_Date THEN
         Pr_Log_Error(p_Source,'ST-OTHR-003',l_Key||'~'||Cspks_Req_Global.g_Date_Format) ;
         RETURN FALSE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of rfpks_rftm_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Type;
   FUNCTION Fn_Sys_Build_Fc_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_rftm          IN rfpks_rftm_Main.ty_rftm,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Fc_Ts..');

      --Dbg('Building Childs Of :..');
      l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_TRANSACTION_DETAILS',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','XREF',p_rftm.v_detbs_rtl_teller.xref);
      Cspks_Req_Global.Pr_Write('V','PRD',p_rftm.v_detbs_rtl_teller.product_code);
      Cspks_Req_Global.Pr_Write('V','XRATE',p_rftm.v_detbs_rtl_teller.exch_rate);
      Cspks_Req_Global.Pr_Write('V','NARRATIVE',p_rftm.v_detbs_rtl_teller.narrative);
      Cspks_Req_Global.Pr_Write('V','BRN',p_rftm.v_detbs_rtl_teller.branch_code);
      IF trunc(p_rftm.v_detbs_rtl_teller.trn_dt) <>
            p_rftm.v_detbs_rtl_teller.trn_dt THEN
         l_Date_Val :=  TO_CHAR( p_rftm.v_detbs_rtl_teller.trn_dt,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_rftm.v_detbs_rtl_teller.trn_dt,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','TXNDATE',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','FCCREF',p_rftm.v_detbs_rtl_teller.trn_ref_no);
      Cspks_Req_Global.Pr_Write('V','MODULE',p_rftm.v_detbs_rtl_teller.module);
      Cspks_Req_Global.Pr_Write('V','TXNCCY',p_rftm.v_detbs_rtl_teller.txn_ccy);
      Cspks_Req_Global.Pr_Write('V','OFFSETCCY',p_rftm.v_detbs_rtl_teller.ofs_ccy);
      Cspks_Req_Global.Pr_Write('V','OFFSETAMT',p_rftm.v_detbs_rtl_teller.ofs_amount);
      Cspks_Req_Global.Pr_Write('V','TXNACC',p_rftm.v_detbs_rtl_teller.txn_acc);
      Cspks_Req_Global.Pr_Write('V','DRINSTCD',p_rftm.v_detbs_rtl_teller.dr_instrument_code);
      Cspks_Req_Global.Pr_Write('V','ACTAMT',p_rftm.v_cstbs_ui_columns.num_field1);
      Cspks_Req_Global.Pr_Write('V','TCYTOTCHGAMT',p_rftm.v_cstbs_ui_columns.num_field2);
      Cspks_Req_Global.Pr_Write('V','FT',p_rftm.v_cstbs_ui_columns.char_field2);
      Cspks_Req_Global.Pr_Write('V','TRANCOUNT',p_rftm.v_cstbs_ui_columns.num_field3);
      Cspks_Req_Global.Pr_Write('V','TXNBRN',p_rftm.v_detbs_rtl_teller.txn_branch);
      Cspks_Req_Global.Pr_Write('V','RELCUST',p_rftm.v_detbs_rtl_teller.rel_customer);
      Cspks_Req_Global.Pr_Write('V','TXNAMT',p_rftm.v_detbs_rtl_teller.txn_amount);
      Cspks_Req_Global.Pr_Write('V','TXNTRN',p_rftm.v_detbs_rtl_teller.txn_trn_code);
      Cspks_Req_Global.Pr_Write('V','OFFSETACC',p_rftm.v_detbs_rtl_teller.ofs_acc);
      Cspks_Req_Global.Pr_Write('V','OFFSETBRN',p_rftm.v_detbs_rtl_teller.ofs_branch);
      Cspks_Req_Global.Pr_Write('V','OFFSETTRN',p_rftm.v_detbs_rtl_teller.ofs_trn_code);
      Cspks_Req_Global.Pr_Write('V','LCYAMT',p_rftm.v_detbs_rtl_teller.lcy_amount);
      Cspks_Req_Global.Pr_Write('V','ACCTITLE1',p_rftm.v_cstbs_ui_columns.char_field1);
      Cspks_Req_Global.Pr_Write('V','NEGOTRATE',p_rftm.v_detbs_rtl_teller.negotiated_rate);
      Cspks_Req_Global.Pr_Write('V','NEGOTREFNO',p_rftm.v_detbs_rtl_teller.negotiation_ref_no);
      Cspks_Req_Global.Pr_Write('V','ACCTITLE2',p_rftm.v_cstbs_ui_columns.char_field3);
      Cspks_Req_Global.Pr_Write('V','DENMAMT2',p_rftm.v_cstbs_ui_columns.num_field4);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD41',p_rftm.v_cstbs_ui_columns.char_field41);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD42',p_rftm.v_cstbs_ui_columns.char_field42);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD43',p_rftm.v_cstbs_ui_columns.char_field43);
      Cspks_Req_Global.Pr_Write('V','NUM_FIELD25',p_rftm.v_cstbs_ui_columns.num_field25);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD44',p_rftm.v_cstbs_ui_columns.char_field44);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD45',p_rftm.v_cstbs_ui_columns.char_field45);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD46',p_rftm.v_cstbs_ui_columns.char_field46);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD47',p_rftm.v_cstbs_ui_columns.char_field47);
      l_Level_Format      := l_0_Lvl_Counter;
      l_Cntr_Before := l_Master_Childs;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='CHCD_'||p_Action_Code;
      END IF;
      IF NOT Chpks_Chcd_Main.Fn_Build_Ts_List(p_source,
         l_Source_Operation,
         'CHCD',
         p_Action_Code,
         p_Function_Id,
         p_rftm.ty_chcd,
         l_Level_Format,
         l_1_Lvl_Counter,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List');
         RETURN FALSE;
      END IF;
      l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

      l_Level_Format      := l_0_Lvl_Counter;
      l_Cntr_Before := l_Master_Childs;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='MDCD_'||p_Action_Code;
      END IF;
      IF NOT Mdpks_Mdcd_Main.Fn_Build_Ts_List(p_source,
         l_Source_Operation,
         'MDCD',
         p_Action_Code,
         p_Function_Id,
         p_rftm.ty_mdcd,
         l_Level_Format,
         l_1_Lvl_Counter,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List');
         RETURN FALSE;
      END IF;
      l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

      l_Level_Format      := l_0_Lvl_Counter;
      l_Cntr_Before := l_Master_Childs;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='UDCD_'||p_Action_Code;
      END IF;
      IF NOT Udpks_Udcd_Main.Fn_Build_Ts_List(p_source,
         l_Source_Operation,
         'UDCD',
         p_Action_Code,
         p_Function_Id,
         p_rftm.ty_udcd,
         l_Level_Format,
         l_1_Lvl_Counter,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List');
         RETURN FALSE;
      END IF;
      l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

      l_Level_Format      := l_0_Lvl_Counter;
      l_Cntr_Before := l_Master_Childs;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='DMCD_'||p_Action_Code;
      END IF;
      IF NOT Dmpks_Dmcd_Main.Fn_Build_Ts_List(p_source,
         l_Source_Operation,
         'DMCD',
         p_Action_Code,
         p_Function_Id,
         p_rftm.ty_dmcd,
         l_Level_Format,
         l_1_Lvl_Counter,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List');
         RETURN FALSE;
      END IF;
      l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

      Dbg('Returning Success From Fn_Sys_Build_Fc_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Ts;
   FUNCTION Fn_Sys_Build_Ws_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Exchange_Pattern IN       VARCHAR2,
      p_rftm          IN rfpks_rftm_Main.ty_rftm,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Key_Cols          VARCHAR2(32767);
      l_Key_Vals          VARCHAR2(32767);
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Ws_Ts..');
      IF SUBSTR(p_Exchange_Pattern,3,4) = 'FS' THEN
         Dbg('Building Full Screen Reply..');

         --Dbg('Building Childs Of :..');
         IF ( (  p_rftm.v_detbs_rtl_teller.xref IS NOT NULL 
          ) OR(  p_rftm.v_cstbs_ui_columns.char_field1 IS NOT NULL 
          ) )
          THEN
            l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','Transaction-Details-Full',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','EXREFNO',p_rftm.v_detbs_rtl_teller.xref);
            Cspks_Req_Global.Pr_Write('V','XRATE',p_rftm.v_detbs_rtl_teller.exch_rate);
            Cspks_Req_Global.Pr_Write('V','NARRATIVE',p_rftm.v_detbs_rtl_teller.narrative);
            Cspks_Req_Global.Pr_Write('V','TXNCCY',p_rftm.v_detbs_rtl_teller.txn_ccy);
            Cspks_Req_Global.Pr_Write('V','OFFSETCCY',p_rftm.v_detbs_rtl_teller.ofs_ccy);
            Cspks_Req_Global.Pr_Write('V','OFFSETAMT',p_rftm.v_detbs_rtl_teller.ofs_amount);
            Cspks_Req_Global.Pr_Write('V','GL_AC_NO',p_rftm.v_detbs_rtl_teller.txn_acc);
            Cspks_Req_Global.Pr_Write('V','REFNO',p_rftm.v_detbs_rtl_teller.dr_instrument_code);
            Cspks_Req_Global.Pr_Write('V','GL_AMT',p_rftm.v_cstbs_ui_columns.num_field1);
            Cspks_Req_Global.Pr_Write('V','SC_CHG',p_rftm.v_cstbs_ui_columns.num_field2);
            Cspks_Req_Global.Pr_Write('V','GLDESC',p_rftm.v_cstbs_ui_columns.char_field1);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD41',p_rftm.v_cstbs_ui_columns.char_field41);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD42',p_rftm.v_cstbs_ui_columns.char_field42);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD43',p_rftm.v_cstbs_ui_columns.char_field43);
            Cspks_Req_Global.Pr_Write('V','NUM_FIELD25',p_rftm.v_cstbs_ui_columns.num_field25);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD44',p_rftm.v_cstbs_ui_columns.char_field44);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD45',p_rftm.v_cstbs_ui_columns.char_field45);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD46',p_rftm.v_cstbs_ui_columns.char_field46);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD47',p_rftm.v_cstbs_ui_columns.char_field47);
            l_Level_Format      := l_0_Lvl_Counter;
            l_Cntr_Before := l_Master_Childs;
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='CHCD_'||p_Action_Code;
            END IF;
            IF NOT Chpks_Chcd_Main.Fn_Build_Ts_List(p_source,
               l_Source_Operation,
               'CHCD',
               p_Action_Code,
               p_Function_Id,
               p_rftm.ty_chcd,
               l_Level_Format,
               l_1_Lvl_Counter,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Build_Ts_List');
               RETURN FALSE;
            END IF;
            l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

            l_Level_Format      := l_0_Lvl_Counter;
            l_Cntr_Before := l_Master_Childs;
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='MDCD_'||p_Action_Code;
            END IF;
            IF NOT Mdpks_Mdcd_Main.Fn_Build_Ts_List(p_source,
               l_Source_Operation,
               'MDCD',
               p_Action_Code,
               p_Function_Id,
               p_rftm.ty_mdcd,
               l_Level_Format,
               l_1_Lvl_Counter,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Build_Ts_List');
               RETURN FALSE;
            END IF;
            l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

            l_Level_Format      := l_0_Lvl_Counter;
            l_Cntr_Before := l_Master_Childs;
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='UDCD_'||p_Action_Code;
            END IF;
            IF NOT Udpks_Udcd_Main.Fn_Build_Ts_List(p_source,
               l_Source_Operation,
               'UDCD',
               p_Action_Code,
               p_Function_Id,
               p_rftm.ty_udcd,
               l_Level_Format,
               l_1_Lvl_Counter,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Build_Ts_List');
               RETURN FALSE;
            END IF;
            l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

            l_Level_Format      := l_0_Lvl_Counter;
            l_Cntr_Before := l_Master_Childs;
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='DMCD_'||p_Action_Code;
            END IF;
            IF NOT Dmpks_Dmcd_Main.Fn_Build_Ts_List(p_source,
               l_Source_Operation,
               'DMCD',
               p_Action_Code,
               p_Function_Id,
               p_rftm.ty_dmcd,
               l_Level_Format,
               l_1_Lvl_Counter,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Build_Ts_List');
               RETURN FALSE;
            END IF;
            l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

         END IF;
      ELSE
         Dbg('Building Primary Key Reply..');
         Cspks_Req_Global.pr_Write('P','Transaction-Details-PK','1');
         l_Key_Cols := 'EXREFNO~';
         l_Key_Vals := p_rftm.v_detbs_rtl_teller.xref||'~';
         Cspks_Req_Global.pr_Write('V',l_Key_Cols,l_Key_Vals);
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Ws_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Ts;
   FUNCTION Fn_Sys_Check_Mandatory (p_Source    IN  VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_rftm IN  rfpks_rftm_Main.Ty_rftm,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000);
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
      l_Rec_Sent       BOOLEAN := TRUE;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';

   BEGIN

      Dbg('In Fn_Sys_Check_Mandatory..');

      l_Fld := 'DETBS_RTL_TELLER.XREF';
      IF p_rftm.v_detbs_rtl_teller.xref IS Null THEN
         Dbg('Field xref is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;

      IF p_Pk_Or_Full = 'FULL'  THEN
         Dbg('Full Mandatory Checks..');

         l_Blk := 'DETBS_RTL_TELLER';
         l_Fld := 'DETBS_RTL_TELLER.NARRATIVE';
         IF p_rftm.v_detbs_rtl_teller.narrative IS Null THEN
            Dbg('Mandatory Key Column narrative Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;
         l_Fld := 'DETBS_RTL_TELLER.OFS_CCY';
         IF p_rftm.v_detbs_rtl_teller.ofs_ccy IS Null THEN
            Dbg('Mandatory Key Column ofs_ccy Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;
         l_Fld := 'DETBS_RTL_TELLER.TXN_ACC';
         IF p_rftm.v_detbs_rtl_teller.txn_acc IS Null THEN
            Dbg('Mandatory Key Column txn_acc Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;
         l_Fld := 'DETBS_RTL_TELLER.TXN_CCY';
         IF p_rftm.v_detbs_rtl_teller.txn_ccy IS Null THEN
            Dbg('Mandatory Key Column txn_ccy Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;

         l_Blk := 'CSTBS_UI_COLUMNS';
         l_Rec_Sent  := FALSE;
         l_Fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD1';
         IF p_rftm.v_cstbs_ui_columns.char_field1 IS Null THEN
            IF l_Rec_Sent  THEN
               Dbg('Primary key Column char_field1 Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-002','@'||l_Fld||'~@'||l_Blk) ;
            END IF;
         ELSE
            l_Rec_Sent  := TRUE;
         END IF;
         IF l_Rec_Sent  THEN
            Dbg('Record has been Sent.. ');
            l_Fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD41';
            IF p_rftm.v_cstbs_ui_columns.char_field41 IS Null THEN
               Dbg('Mandatory Key Column char_field41 Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-005','@'||l_Fld||'~@'||l_Blk );
            END IF;
            l_Fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD42';
            IF p_rftm.v_cstbs_ui_columns.char_field42 IS Null THEN
               Dbg('Mandatory Key Column char_field42 Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-005','@'||l_Fld||'~@'||l_Blk );
            END IF;
            l_Fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD43';
            IF p_rftm.v_cstbs_ui_columns.char_field43 IS Null THEN
               Dbg('Mandatory Key Column char_field43 Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-005','@'||l_Fld||'~@'||l_Blk );
            END IF;
            l_Fld := 'CSTBS_UI_COLUMNS.NUM_FIELD25';
            IF p_rftm.v_cstbs_ui_columns.num_field25 IS Null THEN
               Dbg('Mandatory Key Column num_field25 Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-005','@'||l_Fld||'~@'||l_Blk );
            END IF;
            l_Fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD46';
            IF p_rftm.v_cstbs_ui_columns.char_field46 IS Null THEN
               Dbg('Mandatory Key Column char_field46 Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-005','@'||l_Fld||'~@'||l_Blk );
            END IF;
            l_Fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD47';
            IF p_rftm.v_cstbs_ui_columns.char_field47 IS Null THEN
               Dbg('Mandatory Key Column char_field47 Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-005','@'||l_Fld||'~@'||l_Blk );
            END IF;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Check_Mandatory ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Sys_Check_Mandatory ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory;
   FUNCTION Fn_Sys_Basic_Vals        (p_Source            IN VARCHAR2,
      p_rftm     IN  rfpks_rftm_Main.ty_rftm,
      p_Err_code          IN OUT VARCHAR2,
      p_Err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
   BEGIN

      Dbg('In Fn_Sys_Basic_Vals..');
      Dbg('Returning Success From Fn_Sys_Basic_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Basic_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Basic_Vals;

   FUNCTION Fn_Sys_Default_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_rftm     IN  OUT rfpks_rftm_Main.ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
   BEGIN

      Dbg('In Fn_Sys_Default_Vals..');
      Dbg('Returning Success From Fn_Sys_Default_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Default_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_Vals;

   FUNCTION Fn_Sys_Merge_Amendables        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_rftm     IN  rfpks_rftm_Main.Ty_rftm,
      p_Prev_rftm IN rfpks_rftm_Main.Ty_rftm,
      p_Wrk_rftm IN OUT rfpks_rftm_Main.Ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Wrk_Count      NUMBER := 0 ;
      l_Deleted_Recs   NUMBER := 0;
      l_Modified_Flds  VARCHAR2(32000):= NULL;
      l_Key            VARCHAR2(5000):= NULL;
      l_Mod_Fld        VARCHAR2(100):= NULL;
      i                NUMBER := 1;
      l_Rec_Found      BOOLEAN := FALSE;
      l_Rec_Modified   BOOLEAN := FALSE;
      l_Rec_Sent       BOOLEAN := FALSE;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Pk_Or_Full     VARCHAR2(5) :='FULL';
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Mod_No         NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Amendable_Nodes Cspks_Req_Global.Ty_Amend_Nodes;
      l_Amendable_Fields Cspks_Req_Global.Ty_Amend_Fields;

      FUNCTION Fn_Amendable(p_Item IN VARCHAR2) RETURN BOOLEAN IS
      BEGIN
         IF l_Amendable_Fields.EXISTS(p_Item) THEN
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      END Fn_Amendable;
   BEGIN

      Dbg('In Fn_Sys_Merge_Amendables');

      Dbg('Calling Cspks_Req_Utils.Fn_Get_Amendable_Details..');
      IF NOT Cspks_Req_Utils.Fn_Get_Amendable_Details(p_source ,
         p_Source_Operation,
         l_Amendable_Nodes,
         l_Amendable_Fields,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_Amendable_Details..');
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      END IF;

      l_Blk := 'DETBS_RTL_TELLER';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_fld := 'DETBS_RTL_TELLER.BRANCH_CODE';
      IF Fn_Amendable('DETBS_RTL_TELLER.BRANCH_CODE') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.branch_code := p_rftm.v_detbs_rtl_teller.branch_code;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.branch_code IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.branch_code,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.branch_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.DR_INSTRUMENT_CODE';
      IF Fn_Amendable('DETBS_RTL_TELLER.DR_INSTRUMENT_CODE') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.dr_instrument_code := p_rftm.v_detbs_rtl_teller.dr_instrument_code;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.dr_instrument_code IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.dr_instrument_code,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.dr_instrument_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.EXCH_RATE';
      IF Fn_Amendable('DETBS_RTL_TELLER.EXCH_RATE') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.exch_rate := p_rftm.v_detbs_rtl_teller.exch_rate;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.exch_rate IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.exch_rate,-1) <>
               NVL(p_rftm.v_detbs_rtl_teller.exch_rate,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.MODULE';
      IF Fn_Amendable('DETBS_RTL_TELLER.MODULE') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.module := p_rftm.v_detbs_rtl_teller.module;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.module IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.module,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.module,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.NARRATIVE';
      IF Fn_Amendable('DETBS_RTL_TELLER.NARRATIVE') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.narrative := p_rftm.v_detbs_rtl_teller.narrative;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.narrative IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.narrative,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.narrative,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.OFS_AMOUNT';
      IF Fn_Amendable('DETBS_RTL_TELLER.OFS_AMOUNT') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.ofs_amount := p_rftm.v_detbs_rtl_teller.ofs_amount;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.ofs_amount IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.ofs_amount,-1) <>
               NVL(p_rftm.v_detbs_rtl_teller.ofs_amount,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.OFS_CCY';
      IF Fn_Amendable('DETBS_RTL_TELLER.OFS_CCY') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.ofs_ccy := p_rftm.v_detbs_rtl_teller.ofs_ccy;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.ofs_ccy IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.ofs_ccy,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.ofs_ccy,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.PRODUCT_CODE';
      IF Fn_Amendable('DETBS_RTL_TELLER.PRODUCT_CODE') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.product_code := p_rftm.v_detbs_rtl_teller.product_code;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.product_code IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.product_code,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.product_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.TRN_DT';
      IF Fn_Amendable('DETBS_RTL_TELLER.TRN_DT') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.trn_dt := p_rftm.v_detbs_rtl_teller.trn_dt;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.trn_dt IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.trn_dt,global.min_date) <>
               NVL(p_rftm.v_detbs_rtl_teller.trn_dt,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.TRN_REF_NO';
      IF Fn_Amendable('DETBS_RTL_TELLER.TRN_REF_NO') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.trn_ref_no := p_rftm.v_detbs_rtl_teller.trn_ref_no;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.trn_ref_no IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.trn_ref_no,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.trn_ref_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.TXN_ACC';
      IF Fn_Amendable('DETBS_RTL_TELLER.TXN_ACC') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.txn_acc := p_rftm.v_detbs_rtl_teller.txn_acc;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.txn_acc IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.txn_acc,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.txn_acc,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.TXN_CCY';
      IF Fn_Amendable('DETBS_RTL_TELLER.TXN_CCY') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.txn_ccy := p_rftm.v_detbs_rtl_teller.txn_ccy;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.txn_ccy IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.txn_ccy,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.txn_ccy,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.TXN_BRANCH';
      IF Fn_Amendable('DETBS_RTL_TELLER.TXN_BRANCH') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.txn_branch := p_rftm.v_detbs_rtl_teller.txn_branch;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.txn_branch IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.txn_branch,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.txn_branch,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.REL_CUSTOMER';
      IF Fn_Amendable('DETBS_RTL_TELLER.REL_CUSTOMER') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.rel_customer := p_rftm.v_detbs_rtl_teller.rel_customer;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.rel_customer IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.rel_customer,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.rel_customer,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.TXN_AMOUNT';
      IF Fn_Amendable('DETBS_RTL_TELLER.TXN_AMOUNT') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.txn_amount := p_rftm.v_detbs_rtl_teller.txn_amount;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.txn_amount IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.txn_amount,-1) <>
               NVL(p_rftm.v_detbs_rtl_teller.txn_amount,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.TXN_TRN_CODE';
      IF Fn_Amendable('DETBS_RTL_TELLER.TXN_TRN_CODE') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.txn_trn_code := p_rftm.v_detbs_rtl_teller.txn_trn_code;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.txn_trn_code IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.txn_trn_code,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.txn_trn_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.OFS_ACC';
      IF Fn_Amendable('DETBS_RTL_TELLER.OFS_ACC') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.ofs_acc := p_rftm.v_detbs_rtl_teller.ofs_acc;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.ofs_acc IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.ofs_acc,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.ofs_acc,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.OFS_BRANCH';
      IF Fn_Amendable('DETBS_RTL_TELLER.OFS_BRANCH') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.ofs_branch := p_rftm.v_detbs_rtl_teller.ofs_branch;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.ofs_branch IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.ofs_branch,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.ofs_branch,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.OFS_TRN_CODE';
      IF Fn_Amendable('DETBS_RTL_TELLER.OFS_TRN_CODE') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.ofs_trn_code := p_rftm.v_detbs_rtl_teller.ofs_trn_code;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.ofs_trn_code IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.ofs_trn_code,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.ofs_trn_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.LCY_AMOUNT';
      IF Fn_Amendable('DETBS_RTL_TELLER.LCY_AMOUNT') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.lcy_amount := p_rftm.v_detbs_rtl_teller.lcy_amount;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.lcy_amount IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.lcy_amount,-1) <>
               NVL(p_rftm.v_detbs_rtl_teller.lcy_amount,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.NEGOTIATED_RATE';
      IF Fn_Amendable('DETBS_RTL_TELLER.NEGOTIATED_RATE') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.negotiated_rate := p_rftm.v_detbs_rtl_teller.negotiated_rate;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.negotiated_rate IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.negotiated_rate,-1) <>
               NVL(p_rftm.v_detbs_rtl_teller.negotiated_rate,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_RTL_TELLER.NEGOTIATION_REF_NO';
      IF Fn_Amendable('DETBS_RTL_TELLER.NEGOTIATION_REF_NO') THEN
         p_Wrk_rftm.v_detbs_rtl_teller.negotiation_ref_no := p_rftm.v_detbs_rtl_teller.negotiation_ref_no;
      ELSE
         IF p_rftm.v_detbs_rtl_teller.negotiation_ref_no IS NOT NULL THEN
            IF NVL(p_Wrk_rftm.v_detbs_rtl_teller.negotiation_ref_no,'@') <>
               NVL(p_rftm.v_detbs_rtl_teller.negotiation_ref_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;

      l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
      IF  l_Rec_Modified THEN
         IF l_Modified_Flds IS NOT NULL THEN
            i :=  1;
            l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
            WHILE l_Mod_Fld <> 'EOPL' LOOP
               Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
               i := i +1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
            END LOOP;
         END IF;
      END IF;

      l_Blk := 'CSTBS_UI_COLUMNS';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_Rec_Sent := FALSE;
      IF p_rftm.v_cstbs_ui_columns.char_field1 IS NOT NULL THEN
         dbg('Record Has Been Sent..');
         p_Wrk_rftm.v_cstbs_ui_columns.char_field1 := p_rftm.v_cstbs_ui_columns.char_field1;
         l_Rec_Sent := TRUE;
      END IF;
      IF l_Rec_Sent THEN
         l_fld := 'CSTBS_UI_COLUMNS.NUM_FIELD1';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.NUM_FIELD1') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.num_field1 := p_rftm.v_cstbs_ui_columns.num_field1;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.num_field1 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.num_field1,-1) <>
                  NVL(p_rftm.v_cstbs_ui_columns.num_field1,-1)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.NUM_FIELD2';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.NUM_FIELD2') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.num_field2 := p_rftm.v_cstbs_ui_columns.num_field2;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.num_field2 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.num_field2,-1) <>
                  NVL(p_rftm.v_cstbs_ui_columns.num_field2,-1)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.NUM_FIELD3';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.NUM_FIELD3') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.num_field3 := p_rftm.v_cstbs_ui_columns.num_field3;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.num_field3 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.num_field3,-1) <>
                  NVL(p_rftm.v_cstbs_ui_columns.num_field3,-1)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD2';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD2') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.char_field2 := p_rftm.v_cstbs_ui_columns.char_field2;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.char_field2 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.char_field2,'@') <>
                  NVL(p_rftm.v_cstbs_ui_columns.char_field2,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD3';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD3') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.char_field3 := p_rftm.v_cstbs_ui_columns.char_field3;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.char_field3 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.char_field3,'@') <>
                  NVL(p_rftm.v_cstbs_ui_columns.char_field3,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.NUM_FIELD4';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.NUM_FIELD4') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.num_field4 := p_rftm.v_cstbs_ui_columns.num_field4;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.num_field4 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.num_field4,-1) <>
                  NVL(p_rftm.v_cstbs_ui_columns.num_field4,-1)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD41';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD41') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.char_field41 := p_rftm.v_cstbs_ui_columns.char_field41;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.char_field41 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.char_field41,'@') <>
                  NVL(p_rftm.v_cstbs_ui_columns.char_field41,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD42';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD42') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.char_field42 := p_rftm.v_cstbs_ui_columns.char_field42;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.char_field42 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.char_field42,'@') <>
                  NVL(p_rftm.v_cstbs_ui_columns.char_field42,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD43';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD43') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.char_field43 := p_rftm.v_cstbs_ui_columns.char_field43;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.char_field43 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.char_field43,'@') <>
                  NVL(p_rftm.v_cstbs_ui_columns.char_field43,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.NUM_FIELD25';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.NUM_FIELD25') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.num_field25 := p_rftm.v_cstbs_ui_columns.num_field25;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.num_field25 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.num_field25,-1) <>
                  NVL(p_rftm.v_cstbs_ui_columns.num_field25,-1)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD44';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD44') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.char_field44 := p_rftm.v_cstbs_ui_columns.char_field44;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.char_field44 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.char_field44,'@') <>
                  NVL(p_rftm.v_cstbs_ui_columns.char_field44,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD45';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD45') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.char_field45 := p_rftm.v_cstbs_ui_columns.char_field45;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.char_field45 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.char_field45,'@') <>
                  NVL(p_rftm.v_cstbs_ui_columns.char_field45,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD46';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD46') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.char_field46 := p_rftm.v_cstbs_ui_columns.char_field46;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.char_field46 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.char_field46,'@') <>
                  NVL(p_rftm.v_cstbs_ui_columns.char_field46,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD47';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD47') THEN
            p_Wrk_rftm.v_cstbs_ui_columns.char_field47 := p_rftm.v_cstbs_ui_columns.char_field47;
         ELSE
            IF p_rftm.v_cstbs_ui_columns.char_field47 IS NOT NULL THEN
               IF NVL(p_Wrk_rftm.v_cstbs_ui_columns.char_field47,'@') <>
                  NVL(p_rftm.v_cstbs_ui_columns.char_field47,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;

         l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
         IF  l_Rec_Modified THEN
            IF l_Modified_Flds IS NOT NULL THEN
               i :=  1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
               WHILE l_Mod_Fld <> 'EOPL' LOOP
                  Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
                  i := i +1;
                  l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
               END LOOP;
            END IF;
         END IF;
      ELSE

         IF l_Amendable_Nodes.EXISTS('CSTBS_UI_COLUMNS') THEN
            IF l_Amendable_Nodes('CSTBS_UI_COLUMNS').All_Records = 'Y' THEN
               p_Wrk_rftm.v_cstbs_ui_columns :=NULL;
            END IF;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Merge_Amendables..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Merge_Amendables..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Merge_Amendables;

   FUNCTION Fn_Sys_Check_Mandatory_Nodes  (p_Source            IN VARCHAR2,
      p_Wrk_rftm IN  rfpks_rftm_Main.Ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
   BEGIN

      dbg('In Fn_Gen_Sys_Node_Mand_Checks..');
      Dbg('Returning Success From Fn_Sys_Check_Mandatory_Nodes..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Check_Mandatory_Nodes..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory_Nodes;

   FUNCTION Fn_Sys_Lov_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_rftm     IN  rfpks_rftm_Main.Ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Lov_Count      NUMBER := 0;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER  := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER  := 0;
   BEGIN

      Dbg('In Fn_Sys_Lov_Vals');
      l_Blk := 'DETBS_RTL_TELLER';
      l_Fld := 'DETBS_RTL_TELLER.TXN_ACC';
      IF p_wrk_rftm.v_detbs_rtl_teller.TXN_ACC IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT AC_GL_NO, AC_GL_DESC  FROM STTBS_ACCOUNT WHERE AC_GL_REC_STATUS = 'O'   AND AC_OR_GL = 'G'   AND AUTH_STAT = 'A'   and gl_Aclass_type <> '4'   and GL_STAT_BLOCKED <> 'Y'   and (GL_STAT_DE_POST <> 'N' OR GL_ACLASS_TYPE = '5')   AND AC_GL_NO IN       (SELECT PARAM_VAL          FROM CSTB_PARAM_CUSTOM         WHERE PARAM_NAME = 'PGW_NBC_RFT_WITHDRAWAL_GL') ORDER BY AC_GL_NO) WHERE AC_GL_NO = P_wrk_rftm.v_detbs_rtl_teller.TXN_ACC;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :TXN_ACC:'||p_Wrk_rftm.v_detbs_rtl_teller.TXN_ACC);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_rftm.v_detbs_rtl_teller.TXN_ACC||'~@DETBS_RTL_TELLER.TXN_ACC~@DETBS_RTL_TELLER') ;
         END IF;
      END IF;
      l_Blk := 'CSTBS_UI_COLUMNS';
      l_Fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD43';
      IF p_wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD43 IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT CCY_CODE, CCY_NAME FROM CYTM_CCY_DEFN_MASTER WHERE CCY_CODE IN (SELECT PARAM_VAL FROM CSTB_PARAM_CUSTOM WHERE PARAM_NAME IN ('PGW_NBC_RFT_OUT_KHR', 'PGW_NBC_RFT_OUT_USD')) AND RECORD_STAT = 'O' AND AUTH_STAT = 'A') WHERE CCY_CODE = P_wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD43;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :CHAR_FIELD43:'||p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD43);
            Pr_Log_Error(p_Source,'ST-VALS-012',p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD43||'~@CSTBS_UI_COLUMNS.CHAR_FIELD43~@CSTBS_UI_COLUMNS') ;
         END IF;
      END IF;
      l_Fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD46';
      IF p_wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD46 IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT B.VALUE, B.CODE FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B WHERE A.TYPE = B.TYPE AND A.TYPE = 'RFT_MEMBERS' AND A.RECORD_STAT = 'O' AND A.AUTH_STAT = 'A' ORDER BY B.CODE) WHERE CODE = P_wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD46;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :CHAR_FIELD46:'||p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD46);
            Pr_Log_Error(p_Source,'ST-VALS-012',p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD46||'~@CSTBS_UI_COLUMNS.CHAR_FIELD46~@CSTBS_UI_COLUMNS') ;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Sys_Lov_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Lov_Vals..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Lov_Vals;

   FUNCTION Fn_Sys_Default_And_Validate        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_rftm     IN  rfpks_rftm_Main.Ty_rftm,
      p_Prev_rftm IN OUT  rfpks_rftm_Main.Ty_rftm,
      p_Wrk_rftm IN OUT  rfpks_rftm_Main.Ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Sys_Default_and_Validate..');

      IF p_Source <> 'FLEXCUBE'  THEN
         BEGIN
            SELECT Base_Data_From_Fc
            INTO   l_Base_Data_From_Fc
            FROM   Cotms_Source
            WHERE  Source_Code = p_Source;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               Dbg('Failed in Selecting Source '||p_Source);
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-VALS-002';
               p_Err_Params  := p_Source;
               RETURN FALSE;
         END;
      END IF;
      l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_RTL_TELLER.XREF')||'-'||
      p_rftm.v_detbs_rtl_teller.xref;
      IF p_Action_Code = Cspks_Req_Global.p_New THEN
         IF p_Prev_rftm.v_detbs_rtl_teller.xref IS NOT NULL THEN
            Dbg('Record Already Exists..');
            Pr_Log_Error(p_Source,'ST-VALS-001',l_Key) ;
         END IF;
      ELSIF p_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Auth,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen,Cspks_Req_Global.p_Query,Cspks_Req_Global.p_Delete) THEN
         IF p_Prev_rftm.v_detbs_rtl_teller.xref IS NULL THEN
            Dbg('Record Does not Exist..');
            pr_log_error(p_source,'ST-VALS-002',l_key) ;
         END IF;
      END IF;
      p_Wrk_rftm := p_rftm;
      IF p_Action_Code in  (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify) THEN
         Dbg('Calling .Fn_Sys_Basic_Vals..');
         IF NOT Fn_Sys_Basic_Vals(p_Source,
            p_rftm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Basic_Vals..');
            RETURN FALSE;
         END IF;

         IF p_Action_Code = Cspks_Req_Global.p_New  THEN
            Dbg('Calling .Fn_Sys_Default_Vals..');
            IF NOT Fn_Sys_Default_Vals(p_Source,
               p_Wrk_rftm,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in .Fn_Sys_Default_Vals..');
               RETURN FALSE;
            END IF;

         END IF;
         Dbg('Calling .Fn_Sys_Check_Mandatory_Nodes..');
         IF NOT Fn_Sys_Check_Mandatory_Nodes(p_source,
            p_Wrk_rftm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Check_Mandatory_Nodes..');
            RETURN FALSE;
         END IF;

         Dbg('Calling  .Fn_Sys_Lov_Vals..');
         IF NOT Fn_Sys_Lov_Vals(p_source,
            p_Wrk_rftm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Lov_Vals..');
            RETURN FALSE;
         END IF;

      END IF;
      Dbg('Returning Success  From Fn_Sys_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of rfpks_rftm_Main.Fn_Sys_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_And_Validate;
   FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN  VARCHAR2,
                              p_Source_operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Wrk_rftm  IN   OUT rfpks_rftm_Main.Ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists     BOOLEAN := TRUE;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
   BEGIN
      Dbg('In Fn_Sys_Query_Desc_Fields..');
      Dbg('Returning Success From Fn_Sys_Query_Desc_Fields..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query_Desc_Fields ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query_Desc_Fields;
   FUNCTION Fn_Sys_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_rftm         IN  rfpks_rftm_Main.Ty_rftm,
      p_Wrk_rftm  IN   OUT rfpks_rftm_Main.Ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Wrk_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists        BOOLEAN := TRUE;
      RECORD_LOCKED    EXCEPTION;
      PRAGMA EXCEPTION_INIT( RECORD_LOCKED, -54 );
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
   BEGIN
      Dbg('In Fn_Sys_Query..');
      IF p_QryData_Reqd = 'Q' THEN
         Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
         IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Wrk_rftm,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
            RETURN FALSE;
         END IF;
      ELSE
         l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_RTL_TELLER.XREF')||'-'||
         p_rftm.v_detbs_rtl_teller.xref;
         Dbg('Get The Master Record...');
         IF NVL(p_With_Lock,'N') = 'Y' THEN
            BEGIN
               SELECT *
               INTO   p_wrk_rftm.v_detbs_rtl_teller
               FROM  DETB_RTL_TELLER
               WHERE xref = p_rftm.v_detbs_rtl_teller.xref
                FOR UPDATE NOWAIT;
            EXCEPTION
               WHEN RECORD_LOCKED THEN
                  Dbg('Failed to Obtain the Lock..');
                  Pr_Log_Error(p_Source,'ST-LOCK-001',NULL);
                  RETURN FALSE;
               WHEN No_Data_Found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  l_Rec_Exists := FALSE;
            END;

         ELSE
            BEGIN
               SELECT *
               INTO   p_Wrk_rftm.v_detbs_rtl_teller
               FROM  DETB_RTL_TELLER
               WHERE xref = p_rftm.v_detbs_rtl_teller.xref
               ;
            EXCEPTION
               WHEN no_data_found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  p_Err_Code    := 'ST-VALS-002';
                  p_Err_Params  := l_Key;
                  RETURN FALSE;
            END;

         END IF;
         IF p_Full_Data = 'Y' AND l_Rec_Exists THEN
            Dbg('Get the Record For :DETBS_RTL_TELLER');
            BEGIN
               SELECT *
               INTO p_Wrk_rftm.v_detbs_rtl_teller
               FROM   DETB_RTL_TELLER
               WHERE xref = p_wrk_rftm.v_detbs_rtl_teller.xref
               ;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Selecting The Record For :DETBS_RTL_TELLER');
            END;
            Dbg('Get the Record For :CSTBS_UI_COLUMNS');
            BEGIN
               SELECT *
               INTO p_Wrk_rftm.v_cstbs_ui_columns
               FROM   CSTB_UI_COLUMNS
               WHERE char_field1 = p_Wrk_rftm.v_detbs_rtl_teller.xref
               ;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Selecting The Record For :CSTBS_UI_COLUMNS');
            END;

         END IF;
         IF p_QryData_Reqd = 'Y' THEN
            Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
            IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_Wrk_rftm,
               p_Err_Code  ,
               p_Err_Params ) THEN
               Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
               RETURN FALSE;
            END IF;
         END IF;

      END IF;
      Dbg('Returning Success From Fn_Sys_Query..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query;
   FUNCTION Fn_Sys_Upload_Db         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_rftm     IN  rfpks_rftm_Main.Ty_rftm,
      p_Prev_rftm     IN  rfpks_rftm_Main.Ty_rftm,
      p_Wrk_rftm      IN OUT  rfpks_rftm_Main.Ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Count             NUMBER:= 0;
      l_Ins_Count         NUMBER:= 0;
      l_Upd_Count         NUMBER:= 0;
      l_Del_Count         NUMBER:= 0;
      l_Wrk_Count         NUMBER:= 0;
      l_Prev_Count        NUMBER:= 0;
      l_Rec_Found         BOOLEAN:= FALSE;
      l_Row_Id            ROWID;
      l_Key               VARCHAR2(5000):= NULL;
      l_Auth_Stat         VARCHAR2(1) := 'A';
      l_Base_Data_From_Fc VARCHAR2(1):= 'Y';
   BEGIN
      Dbg('In Fn_Sys_Upload_Db..');
      IF p_Action_Code = Cspks_Req_Global.p_new THEN

         Dbg('Inserting Into DETBS_RTL_TELLER..');
         BEGIN
            IF  p_wrk_rftm.v_detbs_rtl_teller.xref IS NOT NULL THEN
               Dbg('Record Sent..');
               INSERT INTO  DETB_RTL_TELLER
               VALUES p_wrk_rftm.v_detbs_rtl_teller;
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoDETBS_RTL_TELLER..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@DETBS_RTL_TELLER';
               RETURN FALSE;
         END;

         Dbg('Inserting Into CSTBS_UI_COLUMNS..');
         BEGIN
            IF  p_wrk_rftm.v_cstbs_ui_columns.char_field1 IS NOT NULL THEN
               Dbg('Record Sent..');
               INSERT INTO  CSTB_UI_COLUMNS
               VALUES p_wrk_rftm.v_cstbs_ui_columns;
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoCSTBS_UI_COLUMNS..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@CSTBS_UI_COLUMNS';
               RETURN FALSE;
         END;
      ELSIF p_Action_Code = Cspks_Req_Global.p_modify THEN

         Dbg('Updating Single Record Node :  DETBS_RTL_TELLER..');
         BEGIN
            UPDATE DETB_RTL_TELLER
            SET
            BRANCH_CODE = p_Wrk_rftm.v_detbs_rtl_teller.BRANCH_CODE,
            DR_INSTRUMENT_CODE = p_Wrk_rftm.v_detbs_rtl_teller.DR_INSTRUMENT_CODE,
            EXCH_RATE = p_Wrk_rftm.v_detbs_rtl_teller.EXCH_RATE,
            MODULE = p_Wrk_rftm.v_detbs_rtl_teller.MODULE,
            NARRATIVE = p_Wrk_rftm.v_detbs_rtl_teller.NARRATIVE,
            OFS_AMOUNT = p_Wrk_rftm.v_detbs_rtl_teller.OFS_AMOUNT,
            OFS_CCY = p_Wrk_rftm.v_detbs_rtl_teller.OFS_CCY,
            PRODUCT_CODE = p_Wrk_rftm.v_detbs_rtl_teller.PRODUCT_CODE,
            TRN_DT = p_Wrk_rftm.v_detbs_rtl_teller.TRN_DT,
            TRN_REF_NO = p_Wrk_rftm.v_detbs_rtl_teller.TRN_REF_NO,
            TXN_ACC = p_Wrk_rftm.v_detbs_rtl_teller.TXN_ACC,
            TXN_CCY = p_Wrk_rftm.v_detbs_rtl_teller.TXN_CCY,
            TXN_BRANCH = p_Wrk_rftm.v_detbs_rtl_teller.TXN_BRANCH,
            REL_CUSTOMER = p_Wrk_rftm.v_detbs_rtl_teller.REL_CUSTOMER,
            TXN_AMOUNT = p_Wrk_rftm.v_detbs_rtl_teller.TXN_AMOUNT,
            TXN_TRN_CODE = p_Wrk_rftm.v_detbs_rtl_teller.TXN_TRN_CODE,
            OFS_ACC = p_Wrk_rftm.v_detbs_rtl_teller.OFS_ACC,
            OFS_BRANCH = p_Wrk_rftm.v_detbs_rtl_teller.OFS_BRANCH,
            OFS_TRN_CODE = p_Wrk_rftm.v_detbs_rtl_teller.OFS_TRN_CODE,
            LCY_AMOUNT = p_Wrk_rftm.v_detbs_rtl_teller.LCY_AMOUNT,
            NEGOTIATED_RATE = p_Wrk_rftm.v_detbs_rtl_teller.NEGOTIATED_RATE,
            NEGOTIATION_REF_NO = p_Wrk_rftm.v_detbs_rtl_teller.NEGOTIATION_REF_NO
WHERE xref = p_Wrk_rftm.v_detbs_rtl_teller.xref
;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Insert Into DETBS_RTL_TELLER..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@DETBS_RTL_TELLER';
               RETURN FALSE;
         END;

         IF  p_Wrk_rftm.v_cstbs_ui_columns.char_field1 IS NOT NULL THEN
            Dbg('Record Sent..');
            Dbg('Updating Single Record Node :  CSTBS_UI_COLUMNS..');
            BEGIN
               UPDATE CSTB_UI_COLUMNS
               SET
               NUM_FIELD1 = p_Wrk_rftm.v_cstbs_ui_columns.NUM_FIELD1,
               NUM_FIELD2 = p_Wrk_rftm.v_cstbs_ui_columns.NUM_FIELD2,
               NUM_FIELD3 = p_Wrk_rftm.v_cstbs_ui_columns.NUM_FIELD3,
               CHAR_FIELD2 = p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD2,
               CHAR_FIELD3 = p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD3,
               NUM_FIELD4 = p_Wrk_rftm.v_cstbs_ui_columns.NUM_FIELD4,
               CHAR_FIELD41 = p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD41,
               CHAR_FIELD42 = p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD42,
               CHAR_FIELD43 = p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD43,
               NUM_FIELD25 = p_Wrk_rftm.v_cstbs_ui_columns.NUM_FIELD25,
               CHAR_FIELD44 = p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD44,
               CHAR_FIELD45 = p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD45,
               CHAR_FIELD46 = p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD46,
               CHAR_FIELD47 = p_Wrk_rftm.v_cstbs_ui_columns.CHAR_FIELD47
WHERE char_field1 = p_Wrk_rftm.v_cstbs_ui_columns.char_field1
;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg('Failed in Insert Into CSTBS_UI_COLUMNS..');
                  Dbg(SQLERRM);
                  p_Err_Code    := 'ST-UPLD-001';
                  p_Err_Params  := '@CSTBS_UI_COLUMNS';
                  RETURN FALSE;
            END;
            IF SQL%ROWCOUNT = 0 THEN
               BEGIN
                  INSERT INTO  CSTB_UI_COLUMNS
                  VALUES p_Wrk_rftm.v_cstbs_ui_columns;
               EXCEPTION
                  WHEN OTHERS THEN
                     Dbg('Failed in Insert Into CSTBS_UI_COLUMNS..');
                     Dbg(SQLERRM);
                     p_Err_Code    := 'ST-UPLD-001';
                     p_Err_Params  := '@CSTBS_UI_COLUMNS';
                     RETURN FALSE;
               END;
            END IF;
         ELSE
            dbg('Check If The Record Is Already Present for  CSTBS_UI_COLUMNS. .');
            IF  p_prev_rftm.v_cstbs_ui_columns.char_field1 IS NOT NULL THEN
               Dbg('Prev Data Exists And Not Sent For  CSTBS_UI_COLUMNS. Delete the Existing Record.');
               DELETE CSTB_UI_COLUMNS
               WHERE char_field1 = p_Prev_rftm.v_cstbs_ui_columns.char_field1
               ;
            END IF;
         END IF;
      ELSIF p_Action_Code = Cspks_Req_Global.p_delete THEN
         Dbg('Action Code '||p_Action_Code);
         Dbg('Deleting The Data..');

         
         DELETE CSTB_UI_COLUMNS
         WHERE char_field1 = p_Wrk_rftm.v_detbs_rtl_teller.xref
         ;

         DELETE DETB_RTL_TELLER WHERE xref = p_Wrk_rftm.v_detbs_rtl_teller.xref
         ;



      END IF;

      Dbg('Returning Success From Fn_Sys_Upload_Db');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Upload_Db;
   FUNCTION Fn_Build_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_rftm       IN   OUT rfpks_rftm_Main.Ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Child_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;

   BEGIN

      Dbg('In Fn_Build_Ws_Type..');

      IF Cspks_Req_Utils.Fn_Is_Req_Fc_Format(p_Source,p_Function_Id) THEN
         IF NOT Fn_Sys_Build_Fc_Type(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_RFTM,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Fc_Type..');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT Fn_Sys_Build_Ws_Type(p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_RFTM,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Ws_Type..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTTYPE');
      IF NOT rfpks_rftm_Main.Fn_Skip_kernel  THEN
         IF NOT rfpks_rftm_Kernel.Fn_Post_Build_Type_Structure(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Child_Function,
            p_Addl_Info ,
            p_RFTM,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in rfpks_rftm_Kernel.Fn_Post_Build_Type_Structure..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT rfpks_rftm_Main.Fn_Skip_custom  THEN
         IF NOT rfpks_rftm_Custom.Fn_Post_Build_Type_Structure(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Child_Function,
            p_Addl_Info ,
            p_RFTM,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in rfpks_rftm_Custom.Fn_Post_Build_Type_Structure..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Build_Type..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of rfpks_rftm_Main.Fn_Build_Type ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Build_Type;
   FUNCTION Fn_Build_Ts_List (p_source    IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
      p_exchange_pattern   IN  VARCHAR2,
      p_rftm          IN rfpks_rftm_Main.ty_rftm,
      p_err_code        IN OUT VARCHAR2,
      p_err_params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Main_Function smtb_menu.function_id%TYPE := p_Function_id;

   BEGIN

      dbg('In Fn_Build_Ts_List..');

      IF Cspks_Req_Utils.Fn_Is_Res_Fc_Format(p_source,p_Function_id) THEN
         IF NOT  Fn_Sys_Build_Fc_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_rftm,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Fc_Ts');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT  Fn_Sys_Build_Ws_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_exchange_pattern,
            p_rftm,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Ws_Ts');
            RETURN FALSE;
         END IF;
      END IF;

      dbg('Returning from Fn_Build_Ts_List');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of rfpks_rftm_Main.Fn_Build_Ts_List ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := NULL;
         RETURN FALSE;
   END Fn_Build_Ts_List;
   FUNCTION Fn_Get_Key_Information (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_rftm       IN  OUT rfpks_rftm_Main.Ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Key_Cols        VARCHAR2(32767);
      l_Key_Vals        VARCHAR2(32767);
      l_Func_Type       VARCHAR2(32767);
   BEGIN

      Dbg('In Fn_Get_Key_Information..');
      l_Key_Cols := 'XREF~';
      l_Key_Vals := p_rftm.v_detbs_rtl_teller.xref||'~';
      Dbg('Calling Cspks_Req_Utils.Fn_Get_Key_Information..');
      IF NOT Cspks_Req_Utils.Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code ,
         'MAINTENANCE',
         'DETBS_RTL_TELLER',
         'BLK_TRANSACTION_DETAILS',
         'Transaction-Details',
         l_Key_Cols,
         l_Key_Vals,
         p_rftm.Addl_Info,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in  Cspks_Req_Utils.Fn_Get_Key_Information..');
         RETURN FALSE;
      END IF;
      IF p_rftm.Addl_Info.EXISTS('RECORD_KEY') THEN
         G_Req_Key :=  p_rftm.Addl_Info('RECORD_KEY');
      END IF;
      Dbg('Returning Succsess From Fn_Get_Key_Information..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of rfpks_rftm_Main.Fn_Get_Key_Information..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Key_Information;
   FUNCTION Fn_Check_Mandatory (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_rftm IN OUT  rfpks_rftm_Main.Ty_rftm,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
     RETURN BOOLEAN IS

      l_Pk_Or_Full      VARCHAR2(10) :=  'FULL';
      l_Blk      VARCHAR2(100) ;
      l_Fld      VARCHAR2(100) ;
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Source_Operation      VARCHAR2(100) := p_Source_Operation;
      l_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_mdcd    Mdpks_Mdcd_Main.Ty_mdcd;
      l_udcd    Udpks_Udcd_Main.Ty_udcd;
      l_dmcd    Dmpks_Dmcd_Main.Ty_dmcd;

   BEGIN

      Dbg('In Fn_Check_Mandatory..');

      IF p_Pk_Or_Full = 'FULL' OR p_Action_Code = Cspks_Req_Global.p_New THEN
         l_Pk_Or_Full := 'FULL';
      ELSE
         l_Pk_Or_Full := p_Pk_Or_Full;
      END IF;
      Pr_Skip_Handler('PREMAND');
      IF NOT rfpks_rftm_Main.Fn_Skip_custom  THEN
         IF NOT rfpks_rftm_Custom.Fn_Pre_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_rftm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  rfpks_rftm_Custom.Fn_Pre_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT rfpks_rftm_Main.Fn_Skip_kernel  THEN
         IF NOT rfpks_rftm_Kernel.Fn_Pre_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_rftm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  rfpks_rftm_Kernel.Fn_Pre_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;

      IF NOT rfpks_rftm_Main.Fn_Skip_Sys THEN
         Dbg('Calling   Fn_Sys_Check_Mandatory..');
         IF NOT Fn_Sys_Check_Mandatory(p_Source,
            l_Pk_Or_Full,
            p_rftm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;

      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='CHCD_'||p_Action_Code;
      END IF;
      l_chcd := p_rftm.ty_chcd;
      Dbg('Calling Chpks_Chcd_Main.Fn_Check_Mandatory..');
      IF NOT Chpks_Chcd_Main.Fn_Check_Mandatory(p_Source,
         l_Source_Operation,
         'CHCD',
         p_Action_Code,
         p_Function_Id,
         l_Pk_Or_Full,
         l_chcd,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Chpks_Chcd_Main.Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RETURN FALSE;
      END IF;

      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='MDCD_'||p_Action_Code;
      END IF;
      l_mdcd := p_rftm.ty_mdcd;
      Dbg('Calling Mdpks_Mdcd_Main.Fn_Check_Mandatory..');
      IF NOT Mdpks_Mdcd_Main.Fn_Check_Mandatory(p_Source,
         l_Source_Operation,
         'MDCD',
         p_Action_Code,
         p_Function_Id,
         l_Pk_Or_Full,
         l_mdcd,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Mdpks_Mdcd_Main.Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RETURN FALSE;
      END IF;

      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='UDCD_'||p_Action_Code;
      END IF;
      l_udcd := p_rftm.ty_udcd;
      Dbg('Calling Udpks_Udcd_Main.Fn_Check_Mandatory..');
      IF NOT Udpks_Udcd_Main.Fn_Check_Mandatory(p_Source,
         l_Source_Operation,
         'UDCD',
         p_Action_Code,
         p_Function_Id,
         l_Pk_Or_Full,
         l_udcd,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Udpks_Udcd_Main.Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RETURN FALSE;
      END IF;

      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='DMCD_'||p_Action_Code;
      END IF;
      l_dmcd := p_rftm.ty_dmcd;
      Dbg('Calling Dmpks_Dmcd_Main.Fn_Check_Mandatory..');
      IF NOT Dmpks_Dmcd_Main.Fn_Check_Mandatory(p_Source,
         l_Source_Operation,
         'DMCD',
         p_Action_Code,
         p_Function_Id,
         l_Pk_Or_Full,
         l_dmcd,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Dmpks_Dmcd_Main.Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RETURN FALSE;
      END IF;

      Pr_Skip_Handler('POSTMAND');
      IF NOT rfpks_rftm_Main.Fn_Skip_kernel  THEN
         IF NOT rfpks_rftm_Kernel.Fn_Post_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            l_Pk_Or_Full,
            p_rftm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  rfpks_rftm_Kernel.Fn_Post_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT rfpks_rftm_Main.Fn_Skip_custom  THEN
         IF NOT rfpks_rftm_Custom.Fn_Post_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            l_Pk_Or_Full,
            p_rftm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  rfpks_rftm_Custom.Fn_Post_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Check_Mandatory..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of rfpks_rftm_Main.Fn_Check_Mandatory ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Check_Mandatory;
   FUNCTION Fn_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_rftm         IN  rfpks_rftm_Main.Ty_rftm,
      p_Wrk_rftm  IN   OUT  rfpks_rftm_Main.Ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_Wrk_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_mdcd    Mdpks_Mdcd_Main.Ty_mdcd;
      l_Wrk_mdcd    Mdpks_Mdcd_Main.Ty_mdcd;
      l_udcd    Udpks_Udcd_Main.Ty_udcd;
      l_Wrk_udcd    Udpks_Udcd_Main.Ty_udcd;
      l_dmcd    Dmpks_Dmcd_Main.Ty_dmcd;
      l_Wrk_dmcd    Dmpks_Dmcd_Main.Ty_dmcd;
      l_Key_Vals VARCHAR2(32767);
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;

   BEGIN

      Dbg('In Fn_Query..');

      Pr_Skip_Handler('PREQRY');
      IF NOT rfpks_rftm_Main.Fn_Skip_custom  THEN
         IF NOT rfpks_rftm_Custom.Fn_Pre_Query (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_Full_Data  ,
            p_With_Lock,
            p_QryData_Reqd,
            p_rftm,
            p_Wrk_rftm,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in rfpks_rftm_Custom.Fn_Pre_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT rfpks_rftm_Main.Fn_Skip_kernel  THEN
         IF NOT rfpks_rftm_Kernel.Fn_Pre_Query (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_Full_Data  ,
            p_With_Lock,
            p_QryData_Reqd,
            p_rftm,
            p_Wrk_rftm,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in rfpks_rftm_Kernel.Fn_Pre_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT rfpks_rftm_Main.Fn_Skip_Sys THEN
         IF NOT Fn_Sys_Query (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Full_Data  ,
            p_With_Lock,
            p_QryData_Reqd,
            p_rftm,
            p_Wrk_rftm,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Full_Data = 'Y' THEN
         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='CHCD_'||p_Action_Code;
         END IF;
         l_chcd := p_rftm.Ty_chcd;
         l_Key_Vals :='XREF'||'>'||p_wrk_rftm.v_detbs_rtl_teller.XREF;
         Dbg('Calling Chpks_Chcd_Main. Fn_Query..');
         IF NOT Chpks_Chcd_Main.Fn_Query (p_Source,
            l_Source_Operation,
            'CHCD',
            p_Action_Code,
            p_Function_Id,
            l_Key_Vals,
            p_QryData_Reqd,
            l_chcd,
            l_Wrk_chcd,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Chpks_Chcd_Main. Fn_Query..');
            RETURN FALSE;
         END IF;

          p_Wrk_rftm.Ty_chcd := l_Wrk_chcd;

         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='MDCD_'||p_Action_Code;
         END IF;
         l_mdcd := p_rftm.Ty_mdcd;
         l_Key_Vals :='XREF'||'>'||p_wrk_rftm.v_detbs_rtl_teller.XREF;
         Dbg('Calling Mdpks_Mdcd_Main. Fn_Query..');
         IF NOT Mdpks_Mdcd_Main.Fn_Query (p_Source,
            l_Source_Operation,
            'MDCD',
            p_Action_Code,
            p_Function_Id,
            l_Key_Vals,
            p_QryData_Reqd,
            l_mdcd,
            l_Wrk_mdcd,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Mdpks_Mdcd_Main. Fn_Query..');
            RETURN FALSE;
         END IF;

          p_Wrk_rftm.Ty_mdcd := l_Wrk_mdcd;

         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='UDCD_'||p_Action_Code;
         END IF;
         l_udcd := p_rftm.Ty_udcd;
         l_Key_Vals :='XREF'||'>'||p_wrk_rftm.v_detbs_rtl_teller.XREF;
         Dbg('Calling Udpks_Udcd_Main. Fn_Query..');
         IF NOT Udpks_Udcd_Main.Fn_Query (p_Source,
            l_Source_Operation,
            'UDCD',
            p_Action_Code,
            p_Function_Id,
            l_Key_Vals,
            p_QryData_Reqd,
            l_udcd,
            l_Wrk_udcd,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Udpks_Udcd_Main. Fn_Query..');
            RETURN FALSE;
         END IF;

          p_Wrk_rftm.Ty_udcd := l_Wrk_udcd;

         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='DMCD_'||p_Action_Code;
         END IF;
         l_dmcd := p_rftm.Ty_dmcd;
         l_Key_Vals :='XREF'||'>'||p_wrk_rftm.v_detbs_rtl_teller.XREF;
         Dbg('Calling Dmpks_Dmcd_Main. Fn_Query..');
         IF NOT Dmpks_Dmcd_Main.Fn_Query (p_Source,
            l_Source_Operation,
            'DMCD',
            p_Action_Code,
            p_Function_Id,
            l_Key_Vals,
            p_QryData_Reqd,
            l_dmcd,
            l_Wrk_dmcd,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Dmpks_Dmcd_Main. Fn_Query..');
            RETURN FALSE;
         END IF;

          p_Wrk_rftm.Ty_dmcd := l_Wrk_dmcd;

      END IF;
      Pr_Skip_Handler('POSTQRY');
      IF NOT rfpks_rftm_Main.Fn_Skip_kernel  THEN
         IF NOT rfpks_rftm_Kernel.Fn_Post_Query (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_Full_Data  ,
            p_With_Lock,
            p_QryData_Reqd,
            p_rftm,
            p_Wrk_rftm,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in rfpks_rftm_Kernel.Fn_Post_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT rfpks_rftm_Main.Fn_Skip_custom  THEN
         IF NOT rfpks_rftm_Custom.Fn_Post_Query (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_Full_Data  ,
            p_With_Lock,
            p_QryData_Reqd,
            p_rftm,
            p_Wrk_rftm,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in rfpks_rftm_Custom.Fn_Post_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Query..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Query;
   FUNCTION Fn_Default_And_Validate        (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_rftm     IN  rfpks_rftm_Main.Ty_rftm,
      p_Prev_rftm IN OUT  rfpks_rftm_Main.Ty_rftm,
      p_Wrk_rftm IN OUT  rfpks_rftm_Main.Ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Check_Amendables  VARCHAR2(1) := 'N';
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Full_data    VARCHAR2(1) := 'N';
      l_With_Lock    VARCHAR2(1) := 'Y';
      l_Qrydata_Reqd    VARCHAR2(1) := 'N';
      l_Pk_Or_Full      VARCHAR2(10) := 'FULL';

      l_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_Prev_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_Wrk_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_mdcd    Mdpks_Mdcd_Main.Ty_mdcd;
      l_Prev_mdcd    Mdpks_Mdcd_Main.Ty_mdcd;
      l_Wrk_mdcd    Mdpks_Mdcd_Main.Ty_mdcd;
      l_udcd    Udpks_Udcd_Main.Ty_udcd;
      l_Prev_udcd    Udpks_Udcd_Main.Ty_udcd;
      l_Wrk_udcd    Udpks_Udcd_Main.Ty_udcd;
      l_dmcd    Dmpks_Dmcd_Main.Ty_dmcd;
      l_Prev_dmcd    Dmpks_Dmcd_Main.Ty_dmcd;
      l_Wrk_dmcd    Dmpks_Dmcd_Main.Ty_dmcd;

   BEGIN

      Dbg('In Fn_Default_And_Validate..');

      l_Full_data   := 'Y';
      Dbg('Calling  Fn_Query..');
      IF NOT Fn_Query(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         l_Full_data,
         l_With_Lock,
         l_Qrydata_Reqd,
         p_rftm,
         p_Prev_rftm,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Query..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('PREDFLT');
      IF NOT rfpks_rftm_Main.Fn_Skip_custom  THEN
         IF NOT rfpks_rftm_Custom.Fn_Pre_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_rftm,
            p_Prev_rftm,
            p_Wrk_rftm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in rfpks_rftm_Custom.Fn_Pre_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT rfpks_rftm_Main.Fn_Skip_kernel  THEN
         IF NOT rfpks_rftm_Kernel.Fn_Pre_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_rftm,
            p_Prev_rftm,
            p_Wrk_rftm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in rfpks_rftm_Kernel.Fn_Pre_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT rfpks_rftm_Main.Fn_Skip_Sys THEN
         Dbg('Calling in Fn_Sys_Default_and_Validate..');
         IF NOT Fn_Sys_Default_and_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_rftm,
            p_Prev_rftm,
            p_Wrk_rftm,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Default_and_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='CHCD_'||p_Action_Code;
      END IF;
      l_chcd := p_rftm.ty_chcd;
      l_prev_chcd := p_Prev_rftm.ty_chcd;
      l_wrk_chcd := p_Wrk_rftm.ty_chcd;
      Dbg('Calling  Chpks_Chcd_Main.Fn_Default_And_Validate..');
      IF NOT Chpks_Chcd_Main.Fn_Default_And_Validate (p_Source,
         l_Source_Operation,
         'CHCD',
         p_Action_Code,
         p_Function_Id,
         l_Check_Amendables,
         l_chcd,
         l_Prev_chcd,
         l_Wrk_chcd,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Chpks_Chcd_Main.Fn_Default_And_Validate..');
         RETURN FALSE;
      END IF;
      p_Prev_rftm.ty_chcd:= l_prev_chcd;
      p_Wrk_rftm.ty_chcd:= l_wrk_chcd;


      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='MDCD_'||p_Action_Code;
      END IF;
      l_mdcd := p_rftm.ty_mdcd;
      l_prev_mdcd := p_Prev_rftm.ty_mdcd;
      l_wrk_mdcd := p_Wrk_rftm.ty_mdcd;
      Dbg('Calling  Mdpks_Mdcd_Main.Fn_Default_And_Validate..');
      IF NOT Mdpks_Mdcd_Main.Fn_Default_And_Validate (p_Source,
         l_Source_Operation,
         'MDCD',
         p_Action_Code,
         p_Function_Id,
         l_Check_Amendables,
         l_mdcd,
         l_Prev_mdcd,
         l_Wrk_mdcd,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Mdpks_Mdcd_Main.Fn_Default_And_Validate..');
         RETURN FALSE;
      END IF;
      p_Prev_rftm.ty_mdcd:= l_prev_mdcd;
      p_Wrk_rftm.ty_mdcd:= l_wrk_mdcd;


      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='UDCD_'||p_Action_Code;
      END IF;
      l_udcd := p_rftm.ty_udcd;
      l_prev_udcd := p_Prev_rftm.ty_udcd;
      l_wrk_udcd := p_Wrk_rftm.ty_udcd;
      Dbg('Calling  Udpks_Udcd_Main.Fn_Default_And_Validate..');
      IF NOT Udpks_Udcd_Main.Fn_Default_And_Validate (p_Source,
         l_Source_Operation,
         'UDCD',
         p_Action_Code,
         p_Function_Id,
         l_Check_Amendables,
         l_udcd,
         l_Prev_udcd,
         l_Wrk_udcd,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Udpks_Udcd_Main.Fn_Default_And_Validate..');
         RETURN FALSE;
      END IF;
      p_Prev_rftm.ty_udcd:= l_prev_udcd;
      p_Wrk_rftm.ty_udcd:= l_wrk_udcd;


      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='DMCD_'||p_Action_Code;
      END IF;
      l_dmcd := p_rftm.ty_dmcd;
      l_prev_dmcd := p_Prev_rftm.ty_dmcd;
      l_wrk_dmcd := p_Wrk_rftm.ty_dmcd;
      Dbg('Calling  Dmpks_Dmcd_Main.Fn_Default_And_Validate..');
      IF NOT Dmpks_Dmcd_Main.Fn_Default_And_Validate (p_Source,
         l_Source_Operation,
         'DMCD',
         p_Action_Code,
         p_Function_Id,
         l_Check_Amendables,
         l_dmcd,
         l_Prev_dmcd,
         l_Wrk_dmcd,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Dmpks_Dmcd_Main.Fn_Default_And_Validate..');
         RETURN FALSE;
      END IF;
      p_Prev_rftm.ty_dmcd:= l_prev_dmcd;
      p_Wrk_rftm.ty_dmcd:= l_wrk_dmcd;


      Pr_Skip_Handler('POSTDFLT');
      IF NOT rfpks_rftm_Main.Fn_Skip_kernel  THEN
         IF NOT rfpks_rftm_Kernel.Fn_Post_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_rftm,
            p_Prev_rftm,
            p_Wrk_rftm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in rfpks_rftm_Kernel.Fn_Post_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT rfpks_rftm_Main.Fn_Skip_custom  THEN
         IF NOT rfpks_rftm_Custom.Fn_Post_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_rftm,
            p_Prev_rftm,
            p_Wrk_rftm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in rfpks_rftm_Custom.Fn_Post_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_Modify THEN
         Dbg('Calling  Fn_Check_Mandatory..');
         IF NOT Fn_Check_Mandatory(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Pk_Or_Full,
            p_Wrk_rftm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of rfpks_rftm_Main.Fn_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Default_And_Validate;
   FUNCTION Fn_Upload_Db  (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Post_Upl_Stat    IN     VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_rftm     IN  rfpks_rftm_Main.Ty_rftm,
      p_Prev_rftm     IN  rfpks_rftm_Main.Ty_rftm,
      p_Wrk_rftm      IN OUT  rfpks_rftm_Main.Ty_rftm,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_id;
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Row_Id            ROWID;
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);

      l_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_Prev_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_Wrk_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_mdcd    Mdpks_Mdcd_Main.Ty_mdcd;
      l_Prev_mdcd    Mdpks_Mdcd_Main.Ty_mdcd;
      l_Wrk_mdcd    Mdpks_Mdcd_Main.Ty_mdcd;
      l_udcd    Udpks_Udcd_Main.Ty_udcd;
      l_Prev_udcd    Udpks_Udcd_Main.Ty_udcd;
      l_Wrk_udcd    Udpks_Udcd_Main.Ty_udcd;
      l_dmcd    Dmpks_Dmcd_Main.Ty_dmcd;
      l_Prev_dmcd    Dmpks_Dmcd_Main.Ty_dmcd;
      l_Wrk_dmcd    Dmpks_Dmcd_Main.Ty_dmcd;

   BEGIN

      Dbg('In Fn_Upload_Db..');

      IF p_Action_Code = Cspks_Req_Global.p_delete THEN
         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='CHCD_'||p_Action_Code;
         END IF;
         l_chcd := p_rftm.ty_chcd;
         l_prev_chcd := p_Prev_rftm.ty_chcd;
         l_wrk_chcd := p_Wrk_rftm.ty_chcd;
         Dbg('Calling Chpks_Chcd_Main.Fn_Upload_Db');
         IF NOT Chpks_Chcd_Main.Fn_Upload_Db (p_Source,
            l_Source_Operation,
            'CHCD',
            p_Action_Code,
            p_Function_Id,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            l_chcd,
            l_Prev_chcd,
            l_Wrk_chcd,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Chpks_Chcd_Main.Fn_Upload_Db');
            RETURN FALSE;
         END IF;
         p_Wrk_rftm.Ty_chcd:= l_Wrk_chcd;


         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='MDCD_'||p_Action_Code;
         END IF;
         l_mdcd := p_rftm.ty_mdcd;
         l_prev_mdcd := p_Prev_rftm.ty_mdcd;
         l_wrk_mdcd := p_Wrk_rftm.ty_mdcd;
         Dbg('Calling Mdpks_Mdcd_Main.Fn_Upload_Db');
         IF NOT Mdpks_Mdcd_Main.Fn_Upload_Db (p_Source,
            l_Source_Operation,
            'MDCD',
            p_Action_Code,
            p_Function_Id,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            l_mdcd,
            l_Prev_mdcd,
            l_Wrk_mdcd,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Mdpks_Mdcd_Main.Fn_Upload_Db');
            RETURN FALSE;
         END IF;
         p_Wrk_rftm.Ty_mdcd:= l_Wrk_mdcd;


         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='UDCD_'||p_Action_Code;
         END IF;
         l_udcd := p_rftm.ty_udcd;
         l_prev_udcd := p_Prev_rftm.ty_udcd;
         l_wrk_udcd := p_Wrk_rftm.ty_udcd;
         Dbg('Calling Udpks_Udcd_Main.Fn_Upload_Db');
         IF NOT Udpks_Udcd_Main.Fn_Upload_Db (p_Source,
            l_Source_Operation,
            'UDCD',
            p_Action_Code,
            p_Function_Id,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            l_udcd,
            l_Prev_udcd,
            l_Wrk_udcd,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Udpks_Udcd_Main.Fn_Upload_Db');
            RETURN FALSE;
         END IF;
         p_Wrk_rftm.Ty_udcd:= l_Wrk_udcd;


         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='DMCD_'||p_Action_Code;
         END IF;
         l_dmcd := p_rftm.ty_dmcd;
         l_prev_dmcd := p_Prev_rftm.ty_dmcd;
         l_wrk_dmcd := p_Wrk_rftm.ty_dmcd;
         Dbg('Calling Dmpks_Dmcd_Main.Fn_Upload_Db');
         IF NOT Dmpks_Dmcd_Main.Fn_Upload_Db (p_Source,
            l_Source_Operation,
            'DMCD',
            p_Action_Code,
            p_Function_Id,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            l_dmcd,
            l_Prev_dmcd,
            l_Wrk_dmcd,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Dmpks_Dmcd_Main.Fn_Upload_Db');
            RETURN FALSE;
         END IF;
         p_Wrk_rftm.Ty_dmcd:= l_Wrk_dmcd;


      END IF;
      Pr_Skip_Handler('PREUPLD');
      IF NOT rfpks_rftm_Main.Fn_Skip_custom  THEN
         IF NOT rfpks_rftm_Custom.Fn_Pre_Upload_Db (p_Source,
            p_Source_operation,
            p_Function_id,
            p_Action_Code,
            p_function_Id  ,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_rftm,
            p_Prev_rftm,
            p_Wrk_rftm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in rfpks_rftm_Custom.Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT rfpks_rftm_Main.Fn_Skip_kernel  THEN
         IF NOT rfpks_rftm_Kernel.Fn_Pre_Upload_Db (p_Source,
            p_Source_operation,
            p_Function_id,
            p_Action_Code,
            p_function_Id  ,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_rftm,
            p_Prev_rftm,
            p_Wrk_rftm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in rfpks_rftm_Kernel.Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT rfpks_rftm_Main.Fn_Skip_Sys THEN
         IF NOT Fn_Sys_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_rftm,
            p_Prev_rftm,
            p_Wrk_rftm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;

      IF p_Action_Code <> Cspks_Req_Global.p_delete THEN
         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='CHCD_'||p_Action_Code;
         END IF;
         l_chcd := p_rftm.ty_chcd;
         l_prev_chcd := p_Prev_rftm.ty_chcd;
         l_wrk_chcd := p_Wrk_rftm.ty_chcd;
         Dbg('Calling Chpks_Chcd_Main.Fn_Upload_Db..');
         IF NOT Chpks_Chcd_Main.Fn_Upload_Db (p_Source,
            l_Source_Operation,
            'CHCD',
            p_Action_Code,
            p_Function_Id,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            l_chcd,
            l_Prev_chcd,
            l_Wrk_chcd,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Chpks_Chcd_Main.Fn_Upload_Db..');
            RETURN FALSE;
         END IF;
         p_Wrk_rftm.Ty_chcd:= l_Wrk_chcd;


         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='MDCD_'||p_Action_Code;
         END IF;
         l_mdcd := p_rftm.ty_mdcd;
         l_prev_mdcd := p_Prev_rftm.ty_mdcd;
         l_wrk_mdcd := p_Wrk_rftm.ty_mdcd;
         Dbg('Calling Mdpks_Mdcd_Main.Fn_Upload_Db..');
         IF NOT Mdpks_Mdcd_Main.Fn_Upload_Db (p_Source,
            l_Source_Operation,
            'MDCD',
            p_Action_Code,
            p_Function_Id,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            l_mdcd,
            l_Prev_mdcd,
            l_Wrk_mdcd,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Mdpks_Mdcd_Main.Fn_Upload_Db..');
            RETURN FALSE;
         END IF;
         p_Wrk_rftm.Ty_mdcd:= l_Wrk_mdcd;


         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='UDCD_'||p_Action_Code;
         END IF;
         l_udcd := p_rftm.ty_udcd;
         l_prev_udcd := p_Prev_rftm.ty_udcd;
         l_wrk_udcd := p_Wrk_rftm.ty_udcd;
         Dbg('Calling Udpks_Udcd_Main.Fn_Upload_Db..');
         IF NOT Udpks_Udcd_Main.Fn_Upload_Db (p_Source,
            l_Source_Operation,
            'UDCD',
            p_Action_Code,
            p_Function_Id,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            l_udcd,
            l_Prev_udcd,
            l_Wrk_udcd,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Udpks_Udcd_Main.Fn_Upload_Db..');
            RETURN FALSE;
         END IF;
         p_Wrk_rftm.Ty_udcd:= l_Wrk_udcd;


         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='DMCD_'||p_Action_Code;
         END IF;
         l_dmcd := p_rftm.ty_dmcd;
         l_prev_dmcd := p_Prev_rftm.ty_dmcd;
         l_wrk_dmcd := p_Wrk_rftm.ty_dmcd;
         Dbg('Calling Dmpks_Dmcd_Main.Fn_Upload_Db..');
         IF NOT Dmpks_Dmcd_Main.Fn_Upload_Db (p_Source,
            l_Source_Operation,
            'DMCD',
            p_Action_Code,
            p_Function_Id,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            l_dmcd,
            l_Prev_dmcd,
            l_Wrk_dmcd,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Dmpks_Dmcd_Main.Fn_Upload_Db..');
            RETURN FALSE;
         END IF;
         p_Wrk_rftm.Ty_dmcd:= l_Wrk_dmcd;


      END IF;
      Pr_Skip_Handler('POSTUPLD');
      IF NOT rfpks_rftm_Main.Fn_Skip_kernel  THEN
         IF NOT rfpks_rftm_Kernel.Fn_Post_Upload_Db (p_Source,
            p_Source_operation,
            p_Function_id,
            p_Action_Code,
            p_function_Id  ,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_rftm,
            p_Prev_rftm,
            p_Wrk_rftm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in rfpks_rftm_Kernel.Fn_Post_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT rfpks_rftm_Main.Fn_Skip_custom  THEN
         IF NOT rfpks_rftm_Custom.Fn_Post_Upload_Db (p_Source,
            p_Source_operation,
            p_Function_id,
            p_Action_Code,
            p_function_Id  ,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_rftm,
            p_Prev_rftm,
            p_Wrk_rftm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in rfpks_rftm_Custom.Fn_Post_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success  From Fn_Upload_Db..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of rfpks_rftm_Main.Fn_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Upload_Db;
   FUNCTION Fn_Extract_Custom_Data (p_Source   IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      l_rftm     rfpks_rftm_Main.Ty_rftm;

   BEGIN

      Dbg('In Fn_Extract_Custom_Data.. ');
      IF NOT  Fn_Build_Type(p_source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Addl_Info,
         l_rftm,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Type..');
         p_Status      := 'F';
         RAISE e_Failure_Exception;
      END IF;
      Dbg('Calling  Fn_Get_Key_Information..');
      IF NOT  Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         l_rftm,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Get_Key_Information..');
         RAISE e_Failure_Exception;
      END IF;
      p_Addl_Info := l_rftm.Addl_Info;
      Dbg('Returning from Fn_Extract_Custom_Data..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Extract_Custom_Data..');
         p_Status        := 'F';
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Extract_Custom_Data..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Extract_Custom_Data;

   FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;

   BEGIN

      Dbg('In Fn_Rebuild_Ts_List ');
      IF NOT  Fn_Build_Ts_List(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Exchange_Pattern,
         g_rftm,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List');
         p_Status      := 'F';
         RETURN FALSE;
      END IF;
      Dbg('Returning Success From Fn_Rebuild_Ts_List..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Rebuild_Ts_List');
         p_Status        := 'F';
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Rebuild_Ts_List..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Rebuild_Ts_List;

   FUNCTION Fn_Get_Node_Data (
      p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Cntr NUMBER := 0;
   BEGIN

      Dbg('In Fn_Get_Node_Data..');
      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_TRANSACTION_DETAILS';
      p_Node_Data(l_Cntr).Xsd_Node := 'Transaction-Details';
      p_Node_Data(l_Cntr).Node_Parent := '';
      p_Node_Data(l_Cntr).Node_Relation_Type := '1';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'XREF~PRD~XRATE~NARRATIVE~BRN~TXNDATE~FCCREF~MODULE~TXNCCY~OFFSETCCY~OFFSETAMT~TXNACC~DRINSTCD~ACTAMT~TCYTOTCHGAMT~FT~TRANCOUNT~TXNBRN~RELCUST~TXNAMT~TXNTRN~OFFSETACC~OFFSETBRN~OFFSETTRN~LCYAMT~ACCTITL';
      p_Node_Data(l_Cntr).Node_Fields := p_Node_Data(l_Cntr).Node_Fields||'E1~NEGOTRATE~NEGOTREFNO~ACCTITLE2~DENMAMT2~CHAR_FIELD41~CHAR_FIELD42~CHAR_FIELD43~NUM_FIELD25~CHAR_FIELD44~CHAR_FIELD45~CHAR_FIELD46~CHAR_FIELD47~';
      p_Node_Data(l_Cntr).Node_Tags := 'EXREFNO~PRD~XRATE~NARRATIVE~BRN~TXNDATE~FCCREF~MODULE~TXNCCY~OFFSETCCY~OFFSETAMT~GL_AC_NO~REFNO~GL_AMT~SC_CHG~FT~TRANCOUNT~TXNBRN~RELCUST~TXNAMT~TXNTRN~OFFSETACC~OFFSETBRN~OFFSETTRN~LCYAMT~GLDESC~NEGO';
      p_Node_Data(l_Cntr).Node_Tags := p_Node_Data(l_Cntr).Node_Tags||'TRATE~NEGOTREFNO~GLDESC~DENMAMT2~CHAR_FIELD41~CHAR_FIELD42~CHAR_FIELD43~NUM_FIELD25~CHAR_FIELD44~CHAR_FIELD45~CHAR_FIELD46~CHAR_FIELD47~';

      IF NOT Chpks_Chcd_Main.Fn_Get_Node_Data(
         p_Node_Data,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Chpks_Chcd_Main.Fn_Get_Node_Data..');
         RETURN FALSE;
      END IF;
      IF NOT Mdpks_Mdcd_Main.Fn_Get_Node_Data(
         p_Node_Data,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Mdpks_Mdcd_Main.Fn_Get_Node_Data..');
         RETURN FALSE;
      END IF;
      IF NOT Udpks_Udcd_Main.Fn_Get_Node_Data(
         p_Node_Data,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Udpks_Udcd_Main.Fn_Get_Node_Data..');
         RETURN FALSE;
      END IF;
      IF NOT Dmpks_Dmcd_Main.Fn_Get_Node_Data(
         p_Node_Data,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Dmpks_Dmcd_Main.Fn_Get_Node_Data..');
         RETURN FALSE;
      END IF;
      Dbg('Returning From Fn_Get_Node_Data.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of rfpks_rftm_Main.Fn_Get_Node_Data..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Node_Data;
   FUNCTION Fn_Int_Main   (p_Source            IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_action_Code       IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_rftm          IN OUT rfpks_rftm_Main.ty_rftm,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      E_Override_Exception    EXCEPTION;
      l_Resultant_Error_Type  VARCHAR2(32767):= 'I';
      l_Post_Upl_Stat         VARCHAR2(1) :='A';
      l_Prev_Auth_Stat        VARCHAR2(1) :='U';
      l_Wrk_rftm    rfpks_rftm_Main.Ty_rftm;
      l_Prev_rftm    rfpks_rftm_Main.Ty_rftm;
      l_Dmy_rftm    rfpks_rftm_Main.Ty_rftm;
      l_Pk_Or_Full    VARCHAR2(5) :='PK';
      l_Full_Data    VARCHAR2(1) := 'Y';
      l_With_Lock    VARCHAR2(1) := 'N';
      l_Qrydata_Reqd    VARCHAR2(1) := 'Y';
      l_Count         NUMBER;
      l_Action_Code       VARCHAR2(100):= p_Action_Code;

   BEGIN

      Dbg('In Fn_Int_Main..');

      SAVEPOINT Sp_Int_Main_Rftm;
      p_Status := 'S';
      g_rftm := p_rftm;
      l_Wrk_rftm := p_rftm;

      Dbg('Calling  Fn_Check_Mandatory..');
      IF NOT Fn_Check_Mandatory(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         l_Pk_Or_Full,
         p_rftm,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      IF NOT  Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_rftm,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Get_Key_Information..');
         RAISE e_Failure_Exception;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_query THEN
         Dbg('Calling in Fn_Query..');
         IF NOT Fn_Query(p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            l_Full_data,
            l_with_lock,
            l_Qrydata_Reqd,
            p_rftm,
            l_Wrk_rftm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Query..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;
      ELSE
         Dbg('Calling  Fn_Default_And_Validate..');
         IF NOT Fn_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_rftm,
            l_Prev_rftm,
            l_Wrk_rftm,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Default_And_Validate..');
            pr_log_error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

         -- Get Resultant Error Type
         l_Resultant_Error_Type := Cspks_Req_Utils.Fn_Get_Resultant_Error_Type;
         IF l_Resultant_Error_Type <> 'E' THEN
            Dbg('Calling  Fn_Upload_Db..');
            IF NOT Fn_Upload_Db (p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               l_Post_Upl_Stat,
               p_Multi_Trip_Id,
               p_rftm,
               l_Prev_rftm,
               l_Wrk_rftm,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Upload_Db..');
               pr_log_error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
            IF  l_Action_Code <> Cspks_Req_Global.p_Auth THEN
               l_Prev_Auth_Stat := 'A';
               --Get Upload Status
               Dbg('Calling Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
               IF NOT Cspks_Req_Utils.Fn_Get_Auto_Auth_Status (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  l_Action_Code,
                  l_Prev_Auth_Stat,
                  p_Multi_Trip_Id,
                  P_Request_No,
                  l_Post_Upl_Stat,
                  p_Err_Code,
                  p_Err_Params) THEN
                  Dbg('Failed in Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
                  Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
                  RAISE E_Failure_Exception;
               END IF;

               IF l_Post_Upl_Stat NOT IN ('A','U','O') THEN
                  Dbg('Cannot Proceed Further..');
                  RAISE E_Failure_Exception;
               ELSE
                  IF l_post_upl_stat = 'A'THEN
                     Dbg('Calling  Fn_Upload_Db..');
                     IF NOT Fn_Upload_Db (p_Source,
                        p_Source_Operation,
                        p_Function_Id,
                        Cspks_Req_Global.p_auth,
                        l_Post_Upl_Stat,
                        p_Multi_Trip_Id,
                        p_rftm,
                        l_Prev_rftm,
                        l_Wrk_rftm,
                        p_Err_Code,
                        p_Err_Params) THEN
                        Dbg('Failed in Fn_Upload_Db..');
                        Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                        RAISE E_Failure_Exception;
                     END IF;
                  END IF;
               END IF;
            END IF;
            --Get Upload Status
            Dbg('Calling  Cspks_Req_Utils.Fn_Get_Upload_Status..');
            IF NOT Cspks_Req_Utils.Fn_Get_Upload_Status (p_Source,
               p_source_operation,
               p_Function_Id,
               l_Action_Code,
               p_Multi_Trip_Id,
               P_Request_No,
               l_Post_Upl_Stat,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Cspks_Req_Utils.Fn_Get_Upload_Status..');
               Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;

            IF l_Post_Upl_Stat IN ('A','U') THEN
               Dbg('Success Case...');
               IF l_Action_Code <> Cspks_Req_Global.p_Delete THEN
                  IF NOT Fn_Query(p_Source,
                     p_Source_Operation,
                     p_Function_Id,
                     l_Action_Code,
                     l_Full_Data,
                     l_With_Lock,
                     l_Qrydata_Reqd,
                     l_Wrk_rftm,
                     l_Wrk_rftm,
                     p_Err_Code,
                     p_Err_Params) THEN
                     Dbg('Failed in Fn_Query..');
                     Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                     RAISE E_Failure_Exception;
                  END IF;
               END IF;
            ELSIF l_Post_Upl_Stat ='O' THEN
               Dbg('Raising Override Exception..');
               RAISE E_Override_Exception;
            ELSE
               Dbg('Not Feasible to Proceed..');
               RAISE E_Failure_Exception;
            END IF;
         ELSE
            Dbg('Encountered Errros..');
            RAISE E_Failure_Exception;
         END IF;
      END IF; -- Action Code

      Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
      Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      g_rftm := l_wrk_rftm;
      IF l_Action_Code = Cspks_Req_Global.p_Delete AND p_Source = 'FLEXCUBE'  THEN
         l_Wrk_rftm := l_Dmy_rftm;
      END IF;
      p_rftm := l_wrk_rftm;
      Dbg('Errors     :'||p_Err_Code);
      Dbg('Parameters :'||p_Err_Params);

      Dbg('Returning Success From Fn_Int_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Int_Main..');
         ROLLBACK TO Sp_Int_Main_Rftm;
         p_Status        := 'F';
         l_Post_Upl_Stat := 'F';
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN E_Override_Exception THEN
         Dbg('From E_Override_Exception of Fn_Int_Main');
         p_Status        := 'O';
         l_post_upl_stat := 'O';
         IF NOT Cspks_Req_Utils.Fn_Log_Overrides(p_Multi_Trip_Id, p_Request_No, p_Err_Code, p_Err_Params) THEN
            Dbg('Failed inCspks_Req_Utils.Fn_Log_Overrides..');
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
         END IF;
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Int_Main ..');
         Debug.Pr_Debug('**',SQLERRM);
         ROLLBACK TO Sp_Int_Main_Rftm;
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Int_Main;

   FUNCTION Fn_Main   (p_Source            IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_rftm          IN OUT rfpks_rftm_Main.ty_rftm,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      E_Override_Exception    EXCEPTION;

   BEGIN

      Dbg('In Fn_Main..');
      SAVEPOINT Sp_Main_Rftm;
      Dbg('Calling  Fn_Int_Main..');
      IF NOT  Fn_Int_Main(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_Multi_Trip_Id,
         p_Request_No,
         p_rftm,
         p_Status,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Int_Main..');
         RAISE E_Failure_Exception;
      END IF;
      IF p_Status = 'F' THEN
         RAISE E_Failure_Exception;
      ELSIF p_Status = 'O' THEN
         RAISE E_Override_Exception;
      END IF;
      Dbg('Returning Success From Fn_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Main');
         ROLLBACK TO Sp_Main_Rftm;
         p_Status      := 'F';
         RETURN TRUE;

      WHEN E_Override_Exception THEN
         Dbg('From E_Override_Exception of Fn_Main..');
         p_Status      := 'O';
         RETURN TRUE;

      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Main ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         ROLLBACK TO Sp_Main_Rftm;
         RETURN FALSE;
   END Fn_Main;

   FUNCTION Fn_Process_Request (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_rftm     rfpks_rftm_Main.ty_rftm;

   BEGIN

      Dbg('In Fn_Process_Request ');
      IF NOT  Fn_Build_Type(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_Addl_Info,
         l_rftm,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Type..');
         p_status      := 'F';
         RETURN FALSE;
      END IF;
      IF Cspks_Req_Global.Fn_UnTanking THEN
         IF NOT  Fn_Int_Main(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Multi_Trip_Id,
            p_Request_No,
            l_rftm,
            p_Status,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_main..');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT  Fn_Main(p_source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Multi_Trip_Id,
            p_Request_No,
            l_rftm,
            p_Status,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_main..');
            RETURN FALSE;
         END IF;
      END IF;

      p_addl_info := l_rftm.Addl_Info;
      IF Cspks_Req_Global.Fn_Build_Resp THEN
         Cspks_Req_Global.Pr_Reset;
         IF NOT  Fn_Build_Ts_List(p_Source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Exchange_Pattern,
            l_rftm,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Build_Ts_List..');
            p_Status      := 'F';
            RETURN FALSE;
         END IF;
         Cspks_Req_Global.Pr_Close_Ts;
      END IF;
      Dbg('Returning Success From Fn_Process_Request..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Process_Request..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Process_Request;

END rfpks_rftm_main;
/