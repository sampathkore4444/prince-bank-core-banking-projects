/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2020, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : RFTM_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"XREF~PRD~XRATE~NARRATIVE~BRN~TXNDATE~FCCREF~MODULE~TXNCCY~OFFSETCCY~OFFSETAMT~TXNACC~DRINSTCD~ACTAMT~TCYTOTCHGAMT~FT~TRANCOUNT~TXNBRN~RELCUST~TXNAMT~TXNTRN~OFFSETACC~OFFSETBRN~OFFSETTRN~LCYAMT~ACCTITLE1~NEGOTRATE~NEGOTREFNO~ACCTITLE2~DENMAMT2~CHAR_FIELD41"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">XREF~PRD~XRATE~NARRATIVE~BRN~TXNDATE~FCCREF~MODULE~TXNCCY~OFFSETCCY~OFFSETAMT~TXNACC~DRINSTCD~ACTAMT~TCYTOTCHGAMT~FT~TRANCOUNT~TXNBRN~RELCUST~TXNAMT~TXNTRN~OFFSETACC~OFFSETBRN~OFFSETTRN~LCYAMT~ACCTITLE1~NEGOTRATE~NEGOTREFNO~ACCTITLE2~DENMAMT2~CHAR_FIELD41</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : ""}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside RFTM.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside RFTM.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__XREF";
pkFields[0] = "BLK_TRANSACTION_DETAILS__XREF";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
//***** Fields Amendable while Modification *****
var modifyAmendArr = {"BLK_TRANSACTION_DETAILS":["ACTAMT","BRN","DRINSTCD","FCCREF","FT","MODULE","NARRATIVE","OFFSETAMT","OFFSETCCY","PRD","TCYTOTCHGAMT","TRANCOUNT","TXNACC","TXNCCY","TXNDATE","XRATE","XREF"]};
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TRANSACTION_DETAILS__TXNACC__LOV_GL_ACC":["BLK_TRANSACTION_DETAILS__TXNACC~BLK_TRANSACTION_DETAILS__ACCTITLE1~","","N~N",""]};
var offlineLovInfoFlds = {"BLK_TRANSACTION_DETAILS__TXNCCY__LOV_CURRENCY_LOCAL":["BLK_TRANSACTION_DETAILS__TXNCCY~",""],"BLK_TRANSACTION_DETAILS__OFFSETCCY__LOV_CURRENCY_LOCAL":["BLK_TRANSACTION_DETAILS__OFFSETCCY~",""]};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_BODY';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CHCD~BLK_TRANSACTION_DETAILS","MDCD~BLK_TRANSACTION_DETAILS","UDCD~BLK_TRANSACTION_DETAILS","DMCD~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("DETBS_RTL_TELLER.XREF=CSTBS_WBCHARGE_DETAILS.XREF","DETBS_RTL_TELLER.XREF=MIVWS_MIS_DETAILS.XREF","DETBS_RTL_TELLER.XREF=UDVWS_UDF_DETAILS.XREF","DETBS_RTL_TELLER.XREF=CSTBS_WBDENOM_MASTER.XREF"); 

 var CallRelatType= new Array("N","1","N","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["RFTM"]="KERNEL";
ArrPrntFunc["RFTM"]="";
ArrPrntOrigin["RFTM"]="";
ArrRoutingType["RFTM"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["RFTM"]="N";
ArrCustomModified["RFTM"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CHCD":"","MDCD":"","UDCD":"","DMCD":""};
var scrArgSource = {"CHCD":"","MDCD":"","UDCD":"","DMCD":""};
var scrArgVals = {"CHCD":"","MDCD":"","UDCD":"","DMCD":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CHCD":"","MDCD":"","UDCD":"","DMCD":""};
var dpndntOnSrvs = {"CHCD":"","MDCD":"","UDCD":"","DMCD":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"","DELETE":"","CLOSE":"","REOPEN":"","REVERSE":"","ROLLOVER":"","CONFIRM":"","LIQUIDATE":"","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------