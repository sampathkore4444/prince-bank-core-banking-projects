-- Create table
create table IFTB_MG_OUT_INFO
(
  trn_ref_no       VARCHAR2(16) PRIMARY KEY,
  sender_cif       VARCHAR2(105),
  sender_name      VARCHAR2(105),
  sender_mobile    VARCHAR2(35),
  purpose_of_trf   VARCHAR2(105),
  source_of_funds  VARCHAR2(105),
  ben_name         VARCHAR2(105),
  ben_country      VARCHAR2(5),
  ben_relationship VARCHAR2(105),
  ben_dob          DATE,
  ben_addr1        VARCHAR2(105),
  ben_addr2        VARCHAR2(105),
  ben_addr3        VARCHAR2(105),
  ben_addr4        VARCHAR2(105),
  passcode         VARCHAR2(105),
  ben_mob          VARCHAR2(105)
)
/
alter table IFTB_MG_OUT_INFO add primary key (TRN_REF_NO)
/