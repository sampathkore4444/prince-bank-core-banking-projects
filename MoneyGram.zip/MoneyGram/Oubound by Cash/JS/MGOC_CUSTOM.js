function fnPostLoad_CUSTOM() {

	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD40").nextSibling.nextSibling.style.visibility = "hidden";
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD34").nextSibling.nextSibling.style.visibility = "hidden";
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD35").nextSibling.nextSibling.style.visibility = "hidden";
	document.getElementById("BLK_TRANSACTION_DETAILS__CUSTNAME").nextSibling.style.visibility = "hidden";
    document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD42").nextSibling.nextSibling.style.visibility = "hidden";
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD43").nextSibling.nextSibling.style.visibility = "hidden";
 	document.getElementById("BLK_TRANSACTION_DETAILS__BENFADDR4").nextSibling.nextSibling.style.visibility = "hidden";
    
	return true;
    	
}


function fnPostNew_CUSTOM() {

	
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD40").nextSibling.nextSibling.style.visibility = "hidden";
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD34").nextSibling.nextSibling.style.visibility = "hidden";
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD35").nextSibling.nextSibling.style.visibility = "hidden";
	document.getElementById("BLK_TRANSACTION_DETAILS__CUSTNAME").nextSibling.style.visibility = "hidden";
    document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD42").nextSibling.nextSibling.style.visibility = "hidden";
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD43").nextSibling.nextSibling.style.visibility = "hidden";
	document.getElementById("BLK_TRANSACTION_DETAILS__BENFADDR4").nextSibling.nextSibling.style.visibility = "hidden";
    
	return true;
    	
}
