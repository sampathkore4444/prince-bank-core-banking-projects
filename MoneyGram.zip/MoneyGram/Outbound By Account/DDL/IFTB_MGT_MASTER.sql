-- Create table
create table IFTB_MGT_MASTER
(
  branch_code      VARCHAR2(3),
  trn_ref_no       VARCHAR2(20) not null,
  product_code     VARCHAR2(4),
  transfer_date    DATE,
  txn_ccy          VARCHAR2(3),
  txn_amt          NUMBER(22,3),
  tot_chg_amt      NUMBER(22,3),
  net_txn_amt      NUMBER(22,3),
  exch_rate        NUMBER(24,12),
  txn_remarks      VARCHAR2(255),
  rem_acc          VARCHAR2(100),
  rem_name         VARCHAR2(100),
  rem_add1         VARCHAR2(105),
  rem_add2         VARCHAR2(105),
  rem_add3         VARCHAR2(105),
  rem_add4         VARCHAR2(105),
  ben_name         VARCHAR2(100),
  ben_add1         VARCHAR2(105),
  ben_add2         VARCHAR2(105),
  ben_add3         VARCHAR2(105),
  ben_add4         VARCHAR2(105),
  ben_remarks      VARCHAR2(255),
  pass_code        VARCHAR2(105),
  maker_id         VARCHAR2(12),
  maker_dt_stamp   DATE,
  checker_id       VARCHAR2(12),
  checker_dt_stamp DATE,
  auth_stat        VARCHAR2(1),
  record_stat      VARCHAR2(1),
  once_auth        VARCHAR2(1),
  mod_no           NUMBER(4),
  ben_relationship VARCHAR2(255),
  ben_dob          DATE,
  source_of_funds  VARCHAR2(105),
  purpose_of_trf   VARCHAR2(105),
  ben_mob          VARCHAR2(105)
)
/
alter table IFTB_MGT_MASTER add primary key (TRN_REF_NO)
/