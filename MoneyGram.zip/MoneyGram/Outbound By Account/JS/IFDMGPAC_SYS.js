/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2024, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : IFDMGPAC_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = 'N';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_MGT_MASTER":"BRANCH_CODE~TRN_REF_NO~TRANSFER_DATE~TXN_AMT~TOT_CHG_AMT~NET_TXN_AMT~EXCH_RATE~TXN_REMARKS~REM_ACC~REM_NAME~REM_ADD1~REM_ADD2~REM_ADD3~REM_ADD4~BEN_NAME~BEN_ADD1~BEN_ADD2~BEN_ADD3~BEN_ADD4~BEN_REMARKS~PRODUCT_CODE~TXN_CCY~PASS_CODE~BEN_RELATIONSHIP~BEN_DOB~SOURCE_OF_FUNDS~PURPOSE_OF_TRF~BEN_MOB~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH","BLK_MGT_CHARGE":"CHG1_TYPE~CHG1_IN_TXN~CHG1_IN_ACC~CHG2_TYPE~CHG2_IN_TXN~CHG2_IN_ACC~CHG3_TYPE~CHG3_IN_TXN~CHG3_IN_ACC~OTH_CCY~TXN_XRATE~ACC_XRATE~TRN_REF_NO~CHG_SRNO~CHG1_DESC~CHG1_WAIVER~CHG1_AMT~CHG1_CCY~LCY_CHG1~FCY_CHG1~CHG1_GL~CHG2_DESC~CHG2_WAIVER~CHG2_AMT~CHG2_CCY~LCY_CHG2~FCY_CHG2~CHG2_GL~CHG3_DESC~CHG3_WAIVER~CHG3_AMT~CHG3_CCY~LCY_CHG3~FCY_CHG3~CHG3_GL~NETTING_REQ~XRATE~TXN_CODE"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_MGT_MASTER">BRANCH_CODE~TRN_REF_NO~TRANSFER_DATE~TXN_AMT~TOT_CHG_AMT~NET_TXN_AMT~EXCH_RATE~TXN_REMARKS~REM_ACC~REM_NAME~REM_ADD1~REM_ADD2~REM_ADD3~REM_ADD4~BEN_NAME~BEN_ADD1~BEN_ADD2~BEN_ADD3~BEN_ADD4~BEN_REMARKS~PRODUCT_CODE~TXN_CCY~PASS_CODE~BEN_RELATIONSHIP~BEN_DOB~SOURCE_OF_FUNDS~PURPOSE_OF_TRF~BEN_MOB~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH</FN>'; 
msgxml += '      <FN PARENT="BLK_MGT_MASTER" RELATION_TYPE="N" TYPE="BLK_MGT_CHARGE">CHG1_TYPE~CHG1_IN_TXN~CHG1_IN_ACC~CHG2_TYPE~CHG2_IN_TXN~CHG2_IN_ACC~CHG3_TYPE~CHG3_IN_TXN~CHG3_IN_ACC~OTH_CCY~TXN_XRATE~ACC_XRATE~TRN_REF_NO~CHG_SRNO~CHG1_DESC~CHG1_WAIVER~CHG1_AMT~CHG1_CCY~LCY_CHG1~FCY_CHG1~CHG1_GL~CHG2_DESC~CHG2_WAIVER~CHG2_AMT~CHG2_CCY~LCY_CHG2~FCY_CHG2~CHG2_GL~CHG3_DESC~CHG3_WAIVER~CHG3_AMT~CHG3_CCY~LCY_CHG3~FCY_CHG3~CHG3_GL~NETTING_REQ~XRATE~TXN_CODE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR SUMMARY SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var msgxml_sum=""; 
msgxml_sum += '    <FLD>'; 
msgxml_sum += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_MGT_MASTER">AUTHSTAT~TXNSTAT~TRN_REF_NO~REM_ACC~REM_NAME~BEN_NAME~TXN_AMT~BRANCH_CODE~TRANSFER_DATE</FN>'; 
msgxml_sum += '    </FLD>'; 

var detailFuncId = "IFDMGPAC";
var defaultWhereClause = "";
var defaultOrderByClause ="";
var multiBrnWhereClause ="";
var g_SummaryType ="S";
var g_SummaryBtnCount =0;
var g_SummaryBlock ="BLK_MGT_MASTER";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_MGT_MASTER" : "","BLK_MGT_CHARGE" : "BLK_MGT_MASTER~N"}; 

 var dataSrcLocationArray = new Array("BLK_MGT_MASTER","BLK_MGT_CHARGE"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside IFDMGPAC.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside IFDMGPAC.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_MGT_MASTER__TRN_REF_NO";
pkFields[0] = "BLK_MGT_MASTER__TRN_REF_NO";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
//***** Fields Amendable while Modification *****
var modifyAmendArr = {"BLK_MGT_MASTER":["BEN_ADD1","BEN_ADD2","BEN_ADD3","BEN_ADD4","BEN_NAME","BEN_REMARKS","REM_ACC","REM_ADD1","REM_ADD2","REM_ADD3","REM_ADD4","REM_NAME"]};
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_MGT_MASTER__REM_ACC__LOV_ACCNO":["~BLK_MGT_MASTER__REM_ACC~BLK_MGT_MASTER__REM_NAME~~~~~~BLK_MGT_MASTER__REM_ADD1~BLK_MGT_MASTER__REM_ADD2~BLK_MGT_MASTER__REM_ADD3~BLK_MGT_MASTER__REM_ADD4~","","N~N~N~N~N~N~N~N~N~N~N~N",""],"BLK_MGT_MASTER__BEN_ADD4__LOV_BEN_CNT":["BLK_MGT_MASTER__BEN_ADD4~~","","N~N",""],"BLK_MGT_MASTER__BEN_RELATIONSHIP__LOV_RELATIONSHIP":["BLK_MGT_MASTER__BEN_RELATIONSHIP~","","N",""],"BLK_MGT_MASTER__SOURCE_OF_FUNDS__LOV_SOURCE_OF_FUNDS":["BLK_MGT_MASTER__SOURCE_OF_FUNDS~","","N",""],"BLK_MGT_MASTER__PURPOSE_OF_TRF__LOV_PURPOSE_OF_TRF":["BLK_MGT_MASTER__PURPOSE_OF_TRF~","","N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array(); 

 var CallFormRelat=new Array(); 

 var CallRelatType= new Array(); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["IFDMGPAC"]="CUSTOM";
ArrPrntFunc["IFDMGPAC"]="";
ArrPrntOrigin["IFDMGPAC"]="";
ArrRoutingType["IFDMGPAC"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["IFDMGPAC"]="N";
ArrCustomModified["IFDMGPAC"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CSDMSGVW":""};
var scrArgSource = {"CSDMSGVW":""};
var scrArgVals = {"CSDMSGVW":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {};
var dpndntOnSrvs = {};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------