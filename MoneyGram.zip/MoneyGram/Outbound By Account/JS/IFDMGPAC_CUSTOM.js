/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2019, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : IFDMGPAC_CUSTOM.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**    Modified By      : KORE SAMPATH KUMAR
**    Modified Reason  : MoneyGram Changes 
**    Modified On      : 21-Feb-2024
****************************************************************************************************************************/

var g_PickupClicked = 0;
var n =0;


function fnPostNew_CUSTOM(){
	debugs("In fnPostNew_CUSTOM", "A");
	document.getElementById("BLK_MGT_MASTER__BRANCH_CODE").value = mainWin.CurrentBranch;
	document.getElementById("BLK_MGT_MASTER__TRANSFER_DATE").value = mainWin.AppDate;
	document.getElementById("BLK_MGT_MASTER__BEN_RELATIONSHIP").nextSibling.nextSibling.style.visibility = "hidden";
	return true;	
}

function fnPostLoad_CUSTOM(){
	debugs("In fnPostLoad_CUSTOM");
	
	var authStatNode = document.getElementsByName("AUTHSTAT");
    var l_AuthVal = getAuthTxnNodeValue(authStatNode);
	debugs("In fnPostLoad_CUSTOM"+l_AuthVal);
	if (l_AuthVal == "A"){		
		document.getElementById("Unlock").disabled = true;
		document.getElementById("Unlock").style.display = "none";
		EnableToolbar_buttons("Reverse");
	}
	
	if (l_AuthVal != "A"){
		DisableToolbar_buttons("Reverse");
	}
	
	
	return true;
}

function fnPostCopy_CUSTOM() {
	debugs("In fnPostCopy_CUSTOM", "A");
	document.getElementById("BLK_MGT_MASTER__BRANCH_CODE").value = mainWin.CurrentBranch;
	document.getElementById("BLK_MGT_MASTER__TRANSFER_DATE").value = mainWin.AppDate;
	document.getElementById("BLK_MGT_MASTER__SOURCE_CODE").value = 'FLEXCUBE';
	document.getElementById("BLK_MGT_MASTER__TXN_REMARKS").value = "";
	return true;
}

function fnPickup() {
	debugs("In fnPickup", "A");
	g_prevAction = gAction;
	gAction = "PICKUP";
	appendData();
	gAction = "PICKUP";
	fcjRequestDOM = buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	fnDisableElement(document.getElementById("BLK_MGT_MASTER__PRODUCT_CODE"));
	fnDisableElement(document.getElementById("BLK_MGT_MASTER__TXN_CCY"));
	}
	gAction=g_prevAction;
	g_PickupClicked = 1;
	
	return true;
}

function fnPostAuthorize_CUSTOM(){
	debugs("In fnPostAuthorize_CUSTOM");
	var authStatNode = document.getElementsByName("AUTHSTAT");
    var l_AuthVal = getAuthTxnNodeValue(authStatNode);
	debugs("In fnPostAuthorize_CUSTOM"+l_AuthVal);
	
	var modNo = document.getElementsByName("MODNO");
	var modNoValue = getAuthTxnNodeValue(modNo);

	
	if (l_AuthVal == "A"){
		document.getElementById("Unlock").disabled = true;
		document.getElementById("Unlock").style.display = "none";
		EnableToolbar_buttons("Reverse");
	}
	
	if (l_AuthVal == "A" && modNoValue == "2")	
	{
		debugs("IFDMGPAC", "Record already reversed");
		DisableToolbar_buttons("Reverse");
	}


	return true;
}


function fnPostReverse_CUSTOM() {
debugs("IFDMGPAC", "fnPostReverse");	
if (document.getElementById("BLK_MGT_MASTER__RECORD_STAT").value === "V")	
{
	debugs("IFDMGPAC", "Record already reversed");
	DisableToolbar_buttons("Reverse");
	debugs("IFDMGPAC", "Reverse button disabled");
}
if (document.getElementById("BLK_MGT_MASTER__AUTH_STAT").value === "A")	
{
	debugs("IFDMGPAC", "Record already auth");
	DisableToolbar_buttons("Authorize");
	debugs("IFDMGPAC", "auth button disabled");
}

if ((document.getElementById("BLK_MGT_MASTER__RECORD_STAT").value === "V") &&(document.getElementById("BLK_MGT_MASTER__AUTH_STAT").value === "U") )
{
	debugs("IFDMGPAC", "Disabling Delete");
	DisableToolbar_buttons("Delete");
}

return true;
}

function fnPostExecuteQuery_CUSTOM(){
	debugs("In fnPostExecuteQuery_CUSTOM");
	var authStatNode = document.getElementsByName("AUTHSTAT");
    var l_AuthVal = getAuthTxnNodeValue(authStatNode);
	debugs("In fnPostExecuteQuery_CUSTOM"+l_AuthVal);
	if (l_AuthVal == "A"){
		document.getElementById("Unlock").disabled = true;
		document.getElementById("Unlock").style.display = "none";
		EnableToolbar_buttons("Reverse");
	}
	if (l_AuthVal != "A"){
		DisableToolbar_buttons("Reverse");
	}
	return true;
}


function fnPreSave_CUSTOM(){
	debugs("In fnPreSave_CUSTOM", "A");
	
	if (document.getElementById("BLK_MGT_MASTER__TRN_REF_NO").value == "" || g_PickupClicked != 1) {			
		debugs("In Please click on Pick up before save", "A");
		alert("Please click on Pick up before save");
		return false;
	}
	return true;	
}