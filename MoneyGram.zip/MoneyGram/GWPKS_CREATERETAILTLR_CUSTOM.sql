CREATE OR REPLACE PACKAGE BODY GWPKS_CREATERETAILTLR_CUSTOM AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : gwpks_createretailtlr_custom.sql
  **
  ** Module     : RT
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2018 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  SFR Number         :
  Changed By         : Kore Sampath Kumar
  Change Description : Prince Bank AML Changes


  Changed By         : Kore Sampath Kumar
  Change Description : Prince Bank Credit Card Payment by Cash GL Changes

  Changed By         : Kore Sampath Kumar
  Change Description : Transaction Amount should be multiples of 100 to avoid humman error and EODM Issue

  Changed By         : Kore Sampath Kumar
  Change Description : AML Participant Enhancements Changes

   **    Changed By         : Kore Sampath Kumar
   **    Changed on         : 15-July-2020
   **    Description        : NBC RFT Changes
   **    Change Tag         : NBC RFT Changes

   ** Modified By         : Kore Sampath Kumar
   ** Modified On         : 15-Nov-2021
   ** Modified Reason     : AIA Payment
   ** Search String       : AIA Payment

  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE DBG(P_DBG IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('IF',
                   '[DEBUG] ' || 'Gwpks_CreateRetailTlr_Custom :' || P_DBG);
  END DBG;
  PROCEDURE DBG(P_DBG_IND IN VARCHAR2, P_DBG IN VARCHAR2) IS
  BEGIN
    IF P_DBG_IND = 'E' THEN
      DEBUG.PR_DEBUG('IF',
                     '[ERROR] ' || 'Gwpks_CreateRetailTlr_Custom :' ||
                     P_DBG);
    ELSE
      DEBUG.PR_DEBUG('IF',
                     '[DEBUG] ' || 'Gwpks_CreateRetailTlr_Custom :' ||
                     P_DBG);
    END IF;
  END DBG;

  --NBC RFT Changes Starts

  --RIA Phase2 Changes Starts
  --RIAC starts
  FUNCTION FN_GET_RISK_LEVEL_CNT(P_COUNTRY_CODE IN VARCHAR2) RETURN NUMBER IS
    L_VALUE NUMBER;
  BEGIN
    SELECT DECODE(CODE, 'P', 5, 'V', 4, 'H', 3, 'M', '2', 'L', 1, 5)
      INTO L_VALUE
      FROM LMTM_TYPE_VALUES
     WHERE TYPE = 'RISK_LEVEL_CNT'
       AND VALUE = P_COUNTRY_CODE;

    RETURN L_VALUE;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_VALUE;
  END FN_GET_RISK_LEVEL_CNT;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  --RIAC ends
  --RIA Phase2 Changes Ends

  --AML New Payment Flow Starts
  FUNCTION FN_GET_BEN_BANK_NAME(P_CODE IN LMTM_TYPE_VALUES.CODE%TYPE)
    RETURN LMTM_TYPE_VALUES.VALUE%TYPE AS
    L_BEN_BANK_NAME LMTM_TYPE_VALUES.VALUE%TYPE;
  BEGIN

    SELECT B.VALUE
      INTO L_BEN_BANK_NAME
      FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
     WHERE A.TYPE = B.TYPE
       AND A.TYPE = 'RFT_MEMBERS'
       AND B.CODE = P_CODE
       AND B.CODE NOT IN ('100')
       AND A.RECORD_STAT = 'O'
       AND A.AUTH_STAT = 'A';

    RETURN L_BEN_BANK_NAME;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_BEN_BANK_NAME');
      DBG('ERROR CODE IN FN_GET_BEN_BANK_NAME=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_BEN_BANK_NAME=' || SQLERRM);

      RETURN L_BEN_BANK_NAME;

  END FN_GET_BEN_BANK_NAME;
  --AML New Payment Flow Ends

  PROCEDURE PR_INSERT_RFT_WS_LOG_RFTM(P_XREF         IN VARCHAR2,
                                      P_ACTION       IN VARCHAR2,
                                      P_PASSCODE     IN VARCHAR2,
                                      P_BEN_PHONE    IN VARCHAR2,
                                      P_CCY          IN VARCHAR2,
                                      P_TXNAMT       IN VARCHAR2,
                                      P_BEN_NAME     IN VARCHAR2,
                                      P_REM_NAME     IN VARCHAR2,
                                      P_REM_PHONE    IN VARCHAR2,
                                      P_BEN_BIC_CODE IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('INSIDE PR_INSERT_RFT_WS_LOG_RFTM');

    INSERT INTO STTB_RFT_WS_LOG_RFTM
      (XREF,
       ACTION,
       PASSCODE,
       BEN_PHONE,
       CCY,
       TXN_AMT,
       BEN_NAME,
       REM_PHONE,
       REM_NAME,
       BEN_BIC_CODE,
       INVOKE_DATE)
    VALUES
      (P_XREF,
       P_ACTION,
       P_PASSCODE,
       P_BEN_PHONE,
       P_CCY,
       P_TXNAMT,
       P_BEN_NAME,
       P_REM_PHONE,
       P_REM_NAME,
       P_BEN_BIC_CODE,
       SYSDATE);

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_RFT_WS_LOG_RFTM');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);

  END PR_INSERT_RFT_WS_LOG_RFTM;

  PROCEDURE PR_UPDATE_RFT_WS_LOG_RFTM(P_XREF IN VARCHAR2,

                                      P_PASSCODE IN VARCHAR2,
                                      P_STATUS   IN VARCHAR2,
                                      P_WAIT_KEY IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('INSIDE PR_UPDATE_RFT_WS_LOG_RFTM');

    UPDATE STTB_RFT_WS_LOG_RFTM
       SET STATUS = P_STATUS, WAIT_KEY = P_WAIT_KEY
     WHERE XREF = P_XREF
       AND PASSCODE = P_PASSCODE;

    COMMIT;

  EXCEPTION

    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_RFT_WS_LOG_RFTM');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);

  END PR_UPDATE_RFT_WS_LOG_RFTM;

  FUNCTION FN_MOBILE_VALIDATE(P_NUMBER IN VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    IF P_NUMBER IS NOT NULL THEN

      IF LENGTH(P_NUMBER) NOT IN (9, 10) THEN
        RETURN FALSE;

      END IF;

      IF REGEXP_LIKE(P_NUMBER, '^[0-9_\(\)]+$') THEN
        RETURN TRUE;
      ELSE
        RETURN FALSE;
      END IF;
    ELSE
      RETURN TRUE;
    END IF;
  END FN_MOBILE_VALIDATE;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;

    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  --AIA Payment Starts
  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN

    SELECT TRSQ_AIA_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;

    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

    RETURN L_REF;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  FUNCTION FN_GET_AIA_POLICY_ENQUIRY RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_AIA_POLICY_ENQUIRY');

    L_FORMATTED_MSG := '{"channelCode":"MB","insuranceCode":"$L_INSURANCE_CODE","policyNumber":"$L_POLICY_NUMBER"}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_AIA_POLICY_ENQUIRY');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AIA_POLICY_ENQUIRY');
      DBG('ERROR CODE IN FN_GET_AIA_POLICY_ENQUIRY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AIA_POLICY_ENQUIRY=' || SQLERRM);

  END FN_GET_AIA_POLICY_ENQUIRY;

  FUNCTION FN_GET_FMT_AIA_POLICY_ENQ(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC)
    RETURN CLOB IS

    L_INSURANCE_CODE VARCHAR2(105);
    L_POLICY_NUMBER  VARCHAR2(105);
    L_FORMATTED_MSG  CLOB; --varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_GET_FMT_AIA_POLICY_ENQ');

    L_FORMATTED_MSG := FN_GET_AIA_POLICY_ENQUIRY;

    DBG('BEFORE REPLACEMENT OF AIA ACC ENQUIRY JSON=' || L_FORMATTED_MSG);

    --Replace tags with actual values
    L_INSURANCE_CODE := 'AIA001'; --P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD36;

    DBG('L_INSURANCE_CODE=' || L_INSURANCE_CODE);

    L_POLICY_NUMBER := P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD3;

    DBG('L_POLICY_NUMBER=' || L_POLICY_NUMBER);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSURANCE_CODE',
                               L_INSURANCE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_POLICY_NUMBER',
                               L_POLICY_NUMBER);

    DBG('AFTER REPLACEMENT OF AIA POLICY ENQUIRY JSON=' || L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_AIA_POLICY_ENQ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_AIA_POLICY_ENQ');
      DBG('ERROR CODE IN FN_GET_FMT_AIA_POLICY_ENQ=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_AIA_POLICY_ENQ=' || SQLERRM);
  END FN_GET_FMT_AIA_POLICY_ENQ;

  FUNCTION FN_GET_AIA_PAYMENT RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_AIA_PAYMENT');

    L_FORMATTED_MSG := '{"channelCode":"MB","insuranceCode":"$L_INSURANCE_CODE","transactionUniqueNo":"$L_TXN_UNIQUE_NO","policyNumber":"$L_POLICY_NUMBER"
    ,"amount":"$L_AMOUNT","currency":"$L_CCY"}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_AIA_PAYMENT');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_AIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AIA_PAYMENT=' || SQLERRM);

  END FN_GET_AIA_PAYMENT;

  FUNCTION FN_GET_FMT_AIA_PAYMENT(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC)
    RETURN CLOB IS

    L_TXN_UNIQUE_NO  IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE; --need to change to enquiry id
    L_INSURANCE_CODE VARCHAR2(105);
    L_POLICY_NUMBER  VARCHAR2(105);
    L_AMOUNT         VARCHAR2(105);
    L_CCY            VARCHAR2(3);
    L_FORMATTED_MSG  CLOB; --varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_FMT_AIA_PAYMENT');

    L_FORMATTED_MSG := FN_GET_AIA_PAYMENT;

    DBG('BEFORE REPLACEMENT OF AIA PAYMENT JSON=' || L_FORMATTED_MSG);

    --Replace tags with actual values
    L_TXN_UNIQUE_NO := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD11;

    DBG('L_TXN_UNIQUE_NO=' || L_TXN_UNIQUE_NO);

    L_INSURANCE_CODE := P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD36;

    L_INSURANCE_CODE := 'AIA001';

    DBG('L_INSURANCE_CODE=' || L_INSURANCE_CODE);

    L_POLICY_NUMBER := P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD3;

    DBG('L_POLICY_NUMBER=' || L_POLICY_NUMBER);

    L_AMOUNT := P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT;--P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD9;

    DBG('L_AMOUNT=' || L_AMOUNT);

    L_CCY := P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD10;

    DBG('L_CCY=' || L_CCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_UNIQUE_NO',
                               L_TXN_UNIQUE_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSURANCE_CODE',
                               L_INSURANCE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_POLICY_NUMBER',
                               L_POLICY_NUMBER);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CCY', L_CCY);

    DBG('BEFORE REPLACEMENT OF AIA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_AIA_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_AIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_AIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_AIA_PAYMENT=' || SQLERRM);

  END FN_GET_FMT_AIA_PAYMENT;

  PROCEDURE PR_INSERT_AIA_WS_LOG(P_SEQ_NO        IN VARCHAR2,
                                 P_XREF          IN VARCHAR2,
                                 P_INVOKE_DATE   IN VARCHAR2,
                                 P_POLICY_NUMBER IN VARCHAR2,
                                 P_REQ_TYPE      IN VARCHAR2,
                                 P_REQ_MSG       IN VARCHAR2,
                                 P_ADDL_INFO     IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN
    DBG('START OF PR_INSERT_AIA_WS_LOG');

    INSERT INTO IFTB_AIA_WS_LOG
      (SEQ_NO,
       TRN_REF_NO,
       INVOKE_DATE,
       POLICY_NUMBER,
       REQ_TYPE,
       REQ_MSG,
       ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_XREF,
       P_INVOKE_DATE,
       P_POLICY_NUMBER,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ADDL_INFO);

    COMMIT;

    DBG('END OF PR_INSERT_AIA_WS_LOG');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_AIA_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_AIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_AIA_WS_LOG=' || SQLERRM);

  END PR_INSERT_AIA_WS_LOG;

  PROCEDURE PR_UPDATE_AIA_WS_LOG(P_XREF          IN IFTB_AIA_MASTER.TRN_REF_NO%TYPE,
                                 P_SEQ_NO        IN VARCHAR2,
                                 P_TXN_UNIQUE_NO IN IFTB_AIA_MASTER.TXN_UNIQUE_NO%TYPE,
                                 P_STATUS        IN CHAR,
                                 P_RES_MSG       IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_AIA_WS_LOG');

    UPDATE IFTB_AIA_WS_LOG
       SET TXN_UNIQUE_NO = P_TXN_UNIQUE_NO,

           RES_MSG = P_RES_MSG,
           STATUS  = P_STATUS
     WHERE TRN_REF_NO = P_XREF
       AND SEQ_NO = P_SEQ_NO;

    COMMIT;

    DBG('END OF PR_UPDATE_AIA_WS_LOG');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_AIA_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_AIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_AIA_WS_LOG=' || SQLERRM);
  END PR_UPDATE_AIA_WS_LOG;

  FUNCTION FN_AIA_WS_CALL(p_AIA_call in varchar2,
                          p_out_msg  VARCHAR2,
                          p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS

    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255);
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);

    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;

  BEGIN
    dbg('START OF FN_AIA_WS_CALL');

    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));

    IF p_AIA_call = 'I' THEN

      L_URL := FN_GET_PARAM_VAL('PGW_AIA_POLICY_ENQ_URL');

    ELSIF p_AIA_call = 'C' THEN

      L_URL := FN_GET_PARAM_VAL('PGW_AIA_PAYCONFIRM_URL');

    END IF;

    DBG('l_url-->' || L_URL);

    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');

    utl_http.set_authentication(l_http_request,
                                FN_GET_PARAM_VAL('PGW_AIA_AUTH_UID'),
                                FN_GET_PARAM_VAL('PGW_AIA_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
    utl_http.set_header(l_http_request,
                        'content-type',
                        'application/x-www-form-urlencoded');
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));

    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');

    utl_http.set_transfer_timeout(300);

    utl_http.write_text(l_http_request, p_out_msg);

    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));

    l_http_response := utl_http.get_response(l_http_request);

    dbg('Response> status_code: "' || l_http_response.status_code || '"');

    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;

    DBG('l_resp_num=' || l_resp_num);

    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;

    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;

      p_in_resp := buffer1;

      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);

    END IF;

    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;

    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;

    --    dbms_lob.freetemporary(buffer1); --buffer2 may be check

    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('Error Line Number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_AIA_WS_CALL;

  FUNCTION fn_msg_upload(P_TY_RTUPLD  IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                         P_REQ_TYPE   IN VARCHAR2,
                         P_REQ_MSG    IN OUT CLOB,
                         P_ADDL_INFO  IN VARCHAR2,
                         p_err_code   IN OUT VARCHAR2,
                         p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS

    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;

    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);

    L_CLIENT_NAME          VARCHAR2(105);
    L_email                VARCHAR2(105);
    L_phone                VARCHAR2(105);
    l_paymentDueDate       VARCHAR2(105);
    l_allowPartialPayment  VARCHAR2(105);
    l_allowSchedulePayment VARCHAR2(105);
    l_frequency            VARCHAR2(105);
    l_maturityDate         VARCHAR2(105);
    l_amount               VARCHAR2(105);
    l_currency             VARCHAR2(105);
    l_transactionUniqueNo  VARCHAR2(105);

    L_insuranceTransactionNo VARCHAR2(105);

    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);

  BEGIN

    dbg('Inside fn_msg_upload');

    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);

    --Log Webservice Call
    PR_INSERT_AIA_WS_LOG(L_GEN_SEQ_NO,
                         P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                         SYSDATE,
                         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD3,
                         P_REQ_TYPE,
                         P_REQ_MSG,
                         P_ADDL_INFO);

    IF NOT FN_AIA_WS_CALL(P_REQ_TYPE, P_REQ_MSG, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;

    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);

    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);

    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);

    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);

    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;

    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;

    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);

    IF L_STATUS_CODE <> '000' THEN

      p_err_code := 'IF-AIA-000';

      OVPKSS.PR_APPENDTBL(p_err_code, L_STATUS_MSG || '~');

      RETURN FALSE;

    END IF;

    --Handle All Errro Codes ad return false

    IF P_REQ_TYPE = 'I' THEN

      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN

        L_CLIENT_NAME := P_DOCUMENT_XML.EXTRACT('/root/data/clientName/text()')
                         .GETSTRINGVAL;

        DBG('L_CLIENT_NAME =' || L_CLIENT_NAME);

        P_TY_RTUPLD.ty_cstbs_ui_columns.char_field4 := L_CLIENT_NAME;

        IF INSTR(L_RESP_IN_XML, '<email>') >0 THEN

        L_email := P_DOCUMENT_XML.EXTRACT('/root/data/email/text()')
                   .GETSTRINGVAL;

        DBG('L_email =' || L_email);

        END IF;

        P_TY_RTUPLD.ty_cstbs_ui_columns.char_field5 := L_email;

        L_phone := P_DOCUMENT_XML.EXTRACT('/root/data/phone/text()')

                   .GETSTRINGVAL;

        DBG('L_phone =' || L_phone);

        P_TY_RTUPLD.ty_cstbs_ui_columns.char_field6 := L_phone;

        l_paymentDueDate := P_DOCUMENT_XML.EXTRACT('/root/data/paymentDueDate/text()')

                            .GETSTRINGVAL;

        DBG('l_paymentDueDate =' || l_paymentDueDate);

        P_TY_RTUPLD.ty_cstbs_ui_columns.char_field7 := l_paymentDueDate;

        l_allowPartialPayment := P_DOCUMENT_XML.EXTRACT('/root/data/allowPartialPayment/text()')

                                 .GETSTRINGVAL;

        DBG('l_allowPartialPayment =' || l_allowPartialPayment);

        P_TY_RTUPLD.ty_cstbs_ui_columns.char_field8 := l_allowPartialPayment;

        l_allowSchedulePayment := P_DOCUMENT_XML.EXTRACT('/root/data/allowSchedulePayment/text()')

                                  .GETSTRINGVAL;

        DBG('l_allowSchedulePayment =' || l_allowSchedulePayment);

        P_TY_RTUPLD.ty_cstbs_ui_columns.char_field42 := l_allowSchedulePayment;

        l_frequency := P_DOCUMENT_XML.EXTRACT('/root/data/frequency/text()')

                       .GETSTRINGVAL;

        DBG('l_frequency =' || l_frequency);

        P_TY_RTUPLD.ty_cstbs_ui_columns.char_field42 := l_frequency;

        l_maturityDate := P_DOCUMENT_XML.EXTRACT('/root/data/maturityDate/text()')

                          .GETSTRINGVAL;

        DBG('l_maturityDate =' || l_maturityDate);

        P_TY_RTUPLD.ty_cstbs_ui_columns.char_field42 := l_maturityDate;

        l_amount := P_DOCUMENT_XML.EXTRACT('/root/data/amount/text()')

                    .GETSTRINGVAL;

        DBG('l_amount =' || l_amount);

        P_TY_RTUPLD.ty_cstbs_ui_columns.char_field9 := l_amount;

        l_currency := P_DOCUMENT_XML.EXTRACT('/root/data/currency/text()')

                      .GETSTRINGVAL;

        DBG('l_currency =' || l_currency);

        P_TY_RTUPLD.ty_cstbs_ui_columns.char_field10 := l_currency;

        l_transactionUniqueNo := P_DOCUMENT_XML.EXTRACT('/root/data/transactionUniqueNo/text()')

                                 .GETSTRINGVAL;

        DBG('l_transactionUniqueNo =' || l_transactionUniqueNo);

        P_TY_RTUPLD.ty_cstbs_ui_columns.char_field11 := l_transactionUniqueNo;

        PR_UPDATE_AIA_WS_LOG(P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'S',
                             L_IN_RESP);

      ELSE

        PR_UPDATE_AIA_WS_LOG(P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'F',
                             L_IN_RESP);

        RETURN FALSE;

      END IF;
    END IF;

    IF P_REQ_TYPE = 'C' THEN

      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN


        l_transactionUniqueNo := P_DOCUMENT_XML.EXTRACT('/root/data/transactionUniqueNo/text()')

                                 .GETSTRINGVAL;

        DBG('l_transactionUniqueNo =' || l_transactionUniqueNo);

        L_insuranceTransactionNo := P_DOCUMENT_XML.EXTRACT('/root/data/insuranceTransactionNo/text()')

                                    .GETSTRINGVAL;

        DBG('L_insuranceTransactionNo =' || L_insuranceTransactionNo);

        PR_UPDATE_AIA_WS_LOG(P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,--NULL, --L_ENQUIRY_ID,
                             'S',
                             L_IN_RESP);

        RETURN TRUE;

      ELSE

        PR_UPDATE_AIA_WS_LOG(P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'F',
                             L_IN_RESP);

        IF L_STATUS_CODE = 'ERROR_402' AND
           L_STATUS_MSG = 'Transfer is expired' THEN

          dbg('AIA TRANSFER IS EXPIRED');

          p_err_code := 'IF-BNG-002';

          OVPKSS.PR_APPENDTBL(P_ERR_CODE, L_STATUS_MSG);

          RETURN FALSE;

        END IF;

        RETURN FALSE;

      END IF;
    END IF;

    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      RETURN FALSE;
  END fn_msg_upload;
  --AIA Payment Ends

  --RIA Phase2 Changes Starts
  --RIA Cashwithdrawal Remittance Starts
  FUNCTION FN_GET_RIA_PIN_ENQUIRY RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_RIA_PIN_ENQUIRY');

    L_FORMATTED_MSG := '{"pin":"$L_RIA_PIN","amount":"$L_RIA_AMT","channelCode":"cbs","correspLocID":"$L_BRN"}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_RIA_PIN_ENQUIRY');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_RIA_PIN_ENQUIRY');
      DBG('ERROR CODE IN FN_GET_RIA_PIN_ENQUIRY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_RIA_PIN_ENQUIRY=' || SQLERRM);

  END FN_GET_RIA_PIN_ENQUIRY;

  FUNCTION FN_GET_FMT_RIA_PIN_ENQUIRY(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC)
    RETURN CLOB IS

    L_RIA_PIN       IFTB_RIA_WS_IN_LOG.RIA_PIN%TYPE;
    L_RIA_AMT       CSTB_UI_COLUMNS.NUM_FIELD11%TYPE;
    L_FORMATTED_MSG CLOB;

  BEGIN
    DBG('SATRT OF FN_GET_FMT_RIA_PIN_ENQUIRY');

    L_FORMATTED_MSG := FN_GET_RIA_PIN_ENQUIRY;

    DBG('BEFORE REPLACEMENT OF RIA PIN ENQUIRY JSON=' || L_FORMATTED_MSG);

    --Replace tags with actual values
    L_RIA_PIN := P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD70;

    DBG('L_RIA_PIN=' || L_RIA_PIN);

    L_RIA_AMT := P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.NUM_FIELD11;

    DBG('L_RIA_AMT=' || L_RIA_AMT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_RIA_PIN', L_RIA_PIN);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_RIA_AMT', L_RIA_AMT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BRN',
                               GLOBAL.current_branch);

    DBG('AFTER REPLACEMENT OF RIA PIN ENQUIRY JSON=' || L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_RIA_PIN_ENQUIRY');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_RIA_PIN_ENQUIRY');
      DBG('ERROR CODE IN FN_GET_FMT_RIA_PIN_ENQUIRY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_RIA_PIN_ENQUIRY=' || SQLERRM);
  END FN_GET_FMT_RIA_PIN_ENQUIRY;

  FUNCTION FN_GET_RIA_PAYMENT RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_RIA_PAYMENT');

    L_FORMATTED_MSG := '{"transactionUniqueNo":"$L_TXN_UNIQUE_NO", "riaReferenceNo":"$L_RIA_REFERENCE_NO", "orderNo":"$L_ORDER_NO", "pin":"$L_RIA_PIN", "channelCode":"cbs",
"currency":"$L_RIA_CCY", "amount":"$L_RIA_AMOUNT", "receiverIDType":"$L_BEN_ID_TYPE", "receiverIDNumber":"$L_BEN_ID_VALUE", "receiverIDExpirationDate":"$L_BEN_ID_EXPIRY_DATE", "receiverIDIssuedByCountry":"$L_BEN_ID_ISS_BY_COUNTRY", "correspLocID":"$L_CORR_LOC_ID",
"receiverAddress":"$L_RECEIVER_ADDR", "receiverCity":"$L_RECEIVER_CITY"}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_RIA_PAYMENT');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_RIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_RIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_RIA_PAYMENT=' || SQLERRM);

  END FN_GET_RIA_PAYMENT;

  --RIA Withdrawal Remittance Confirmation Starts for Digital
  FUNCTION FN_GET_RIA_PAYMENT_DIG RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_RIA_PAYMENT_DIG');

    L_FORMATTED_MSG := '{"transactionUniqueNo":"$L_TXN_UNIQUE_NO", "riaReferenceNo":"$L_RIA_REFERENCE_NO", "orderNo":"$L_ORDER_NO", "pin":"$L_RIA_PIN", "channelCode":"mb",
"currency":"$L_RIA_CCY", "amount":"$L_RIA_AMOUNT", "receiverIDType":"$L_BEN_ID_TYPE", "receiverIDNumber":"$L_BEN_ID_VALUE", "receiverIDExpirationDate":"$L_BEN_ID_EXPIRY_DATE", "receiverIDIssuedByCountry":"$L_BEN_ID_ISS_BY_COUNTRY", "correspLocID":"$L_CORR_LOC_ID",
"receiverAddress":"$L_RECEIVER_ADDR", "receiverCity":"$L_RECEIVER_CITY"}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_RIA_PAYMENT_DIG');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_RIA_PAYMENT_DIG');
      DBG('ERROR CODE IN FN_GET_RIA_PAYMENT_DIG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_RIA_PAYMENT_DIG=' || SQLERRM);

  END FN_GET_RIA_PAYMENT_DIG;

  FUNCTION FN_GET_FMT_RIA_PAYMENT_DIG(P_TXN_UNIQUE_NO    IN VARCHAR2,
                                      P_RIA_REFERENCE_NO IN VARCHAR2,
                                      P_ORDER_NO         IN VARCHAR2,
                                      P_RIA_PIN          IN VARCHAR2,
                                      P_TY_RTUPLD        IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC)
    RETURN CLOB IS

    L_TXN_UNIQUE_NO         IFTB_RIA_MASTER.TXN_UNIQUE_NO%TYPE; --need to change to enquiry id
    L_RIA_REFERENCE_NO      IFTB_RIA_MASTER.RIA_REFERENCE_NO%TYPE;
    L_ORDER_NO              IFTB_RIA_MASTER.ORDER_NO%TYPE;
    L_RIA_PIN               IFTB_RIA_MASTER.RIA_PIN%TYPE;
    L_RIA_CCY               IFTB_RIA_MASTER.CR_ACC_CCY%TYPE;
    L_RIA_AMOUNT            IFTB_RIA_MASTER.CR_AMOUNT%TYPE;
    L_BEN_ID_TYPE           VARCHAR2(255);
    L_BEN_ID_VALUE          VARCHAR2(255);
    L_BEN_ID_EXPIRY_DATE    VARCHAR2(105);
    L_BEN_ID_ISS_BY_COUNTRY VARCHAR2(10);
    L_CORR_LOC_ID           STTM_BRANCH.BRANCH_CODE%TYPE;
    L_RECEIVER_ADDR         VARCHAR2(255);
    L_RECEIVER_CITY         VARCHAR2(255);
    L_FORMATTED_MSG         CLOB; --varchar2(4000);

    L_ADDRESS_LINE1    STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_ADDRESS_LINE2    STTM_CUSTOMER.ADDRESS_LINE2%TYPE;
    L_ADDRESS_LINE3    STTM_CUSTOMER.ADDRESS_LINE3%TYPE;
    L_ADDRESS_LINE4    STTM_CUSTOMER.ADDRESS_LINE4%TYPE;
    L_UNIQUE_ID_NAME   STTM_CUSTOMER.UNIQUE_ID_NAME%TYPE;
    L_UNIQUE_ID_VALUE  STTM_CUSTOMER.UNIQUE_ID_VALUE%TYPE;
    L_UNIQUE_ID_EXP_DT STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT%TYPE;

  BEGIN

    DBG('SATRT OF FN_GET_FMT_RIA_PAYMENT_DIG');

    L_FORMATTED_MSG := FN_GET_RIA_PAYMENT_DIG;

    DBG('BEFORE REPLACEMENT OF RIA PAYMENT JSON=' || L_FORMATTED_MSG);

    --Replace tags with actual values
    L_TXN_UNIQUE_NO := P_TXN_UNIQUE_NO;

    DBG('L_TXN_UNIQUE_NO=' || L_TXN_UNIQUE_NO);

    L_RIA_REFERENCE_NO := P_RIA_REFERENCE_NO;

    DBG('L_RIA_REFERENCE_NO=' || L_RIA_REFERENCE_NO);

    L_ORDER_NO := P_ORDER_NO;

    DBG('L_ORDER_NO=' || L_ORDER_NO);

    L_RIA_PIN := P_RIA_PIN;

    DBG('L_RIA_PIN=' || L_RIA_PIN);

    L_RIA_CCY := 'USD';

    DBG('L_RIA_CCY=' || L_RIA_CCY);

    L_RIA_AMOUNT := P_TY_RTUPLD.ty_upld_rtl_teller.txn_amount;

    DBG('L_RIA_AMOUNT=' || L_RIA_AMOUNT);

    --Get Beneficiary Details
    BEGIN

      SELECT A.ADDRESS_LINE1,
             A.ADDRESS_LINE2,
             A.ADDRESS_LINE3,
             A.ADDRESS_LINE4,
             A.UNIQUE_ID_NAME,
             A.UNIQUE_ID_VALUE,

             C.UNIQUE_ID_EXP_DT

        INTO L_ADDRESS_LINE1,
             L_ADDRESS_LINE2,
             L_ADDRESS_LINE3,
             L_ADDRESS_LINE4,
             L_UNIQUE_ID_NAME,
             L_UNIQUE_ID_VALUE,
             L_UNIQUE_ID_EXP_DT

        FROM STTM_CUSTOMER A, sttm_cust_personal B, STTM_CUSTOMER_CUSTOM C
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO = C.CUSTOMER_NO
         AND A.customer_no in
             (select cust_no
                from sttm_cust_account
               where cust_ac_no = P_TY_RTUPLD.ty_upld_rtl_teller.ofs_acc
                 AND RECORD_STAT = 'O'
                 AND AUTH_STAT = 'A');

    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    L_BEN_ID_TYPE := L_UNIQUE_ID_NAME;

    DBG('L_BEN_ID_TYPE=' || L_BEN_ID_TYPE);

    L_BEN_ID_VALUE := L_UNIQUE_ID_VALUE;

    DBG('L_BEN_ID_VALUE=' || L_BEN_ID_VALUE);

    -- L_BEN_ID_EXPIRY_DATE := L_UNIQUE_ID_EXP_DT;

    DBG('L_BEN_ID_EXPIRY_DATE=' || L_BEN_ID_EXPIRY_DATE);

    L_BEN_ID_EXPIRY_DATE := TO_CHAR(L_UNIQUE_ID_EXP_DT, 'YYYYMMDD');

    L_BEN_ID_ISS_BY_COUNTRY := 'KH'; --pls check

    DBG('L_BEN_ID_ISS_BY_COUNTRY=' || L_BEN_ID_ISS_BY_COUNTRY);

    L_CORR_LOC_ID := GLOBAL.current_branch;

    DBG('L_CORR_LOC_ID=' || L_CORR_LOC_ID);

    L_RECEIVER_ADDR := L_ADDRESS_LINE1 || ',' || L_ADDRESS_LINE2 || ',' ||
                       L_ADDRESS_LINE3 || ',' || L_ADDRESS_LINE4;

    DBG('L_RECEIVER_ADDR=' || L_RECEIVER_ADDR);

    L_RECEIVER_CITY := L_ADDRESS_LINE3; --pls check

    DBG('L_RECEIVER_CITY=' || L_RECEIVER_CITY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_UNIQUE_NO',
                               L_TXN_UNIQUE_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RIA_REFERENCE_NO',
                               L_RIA_REFERENCE_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_ORDER_NO', L_ORDER_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_RIA_PIN', L_RIA_PIN);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_RIA_CCY', L_RIA_CCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RIA_AMOUNT',
                               L_RIA_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ID_TYPE',
                               L_BEN_ID_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ID_VALUE',
                               L_BEN_ID_VALUE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ID_EXPIRY_DATE',
                               L_BEN_ID_EXPIRY_DATE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ID_ISS_BY_COUNTRY',
                               L_BEN_ID_ISS_BY_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CORR_LOC_ID',
                               L_CORR_LOC_ID);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RECEIVER_ADDR',
                               L_RECEIVER_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RECEIVER_CITY',
                               L_RECEIVER_CITY);

    DBG('BEFORE REPLACEMENT OF RIA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_RIA_PAYMENT_DIG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_RIA_PAYMENT_DIG');
      DBG('ERROR CODE IN FN_GET_FMT_RIA_PAYMENT_DIG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_RIA_PAYMENT_DIG=' || SQLERRM);

  END FN_GET_FMT_RIA_PAYMENT_DIG;
  --RIA Withdrawal Remittance Confirmation Ends for Digital

  FUNCTION FN_GET_FMT_RIA_PAYMENT(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC)
    RETURN CLOB IS

    L_TXN_UNIQUE_NO         IFTB_RIA_MASTER.TXN_UNIQUE_NO%TYPE; --need to change to enquiry id
    L_RIA_REFERENCE_NO      IFTB_RIA_MASTER.RIA_REFERENCE_NO%TYPE;
    L_ORDER_NO              IFTB_RIA_MASTER.ORDER_NO%TYPE;
    L_RIA_PIN               IFTB_RIA_MASTER.RIA_PIN%TYPE;
    L_RIA_CCY               IFTB_RIA_MASTER.CR_ACC_CCY%TYPE;
    L_RIA_AMOUNT            IFTB_RIA_MASTER.CR_AMOUNT%TYPE;
    L_BEN_ID_TYPE           VARCHAR2(255);
    L_BEN_ID_VALUE          VARCHAR2(255);
    L_BEN_ID_EXPIRY_DATE    VARCHAR2(105);
    L_BEN_ID_ISS_BY_COUNTRY VARCHAR2(10);
    L_CORR_LOC_ID           STTM_BRANCH.BRANCH_CODE%TYPE;
    L_RECEIVER_ADDR         VARCHAR2(255);
    L_RECEIVER_CITY         VARCHAR2(255);
    L_FORMATTED_MSG         CLOB; --varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_FMT_RIA_PAYMENT');

    L_FORMATTED_MSG := FN_GET_RIA_PAYMENT;

    DBG('BEFORE REPLACEMENT OF RIA PAYMENT JSON=' || L_FORMATTED_MSG);

    --Replace tags with actual values
    L_TXN_UNIQUE_NO := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD71;

    DBG('L_TXN_UNIQUE_NO=' || L_TXN_UNIQUE_NO);

    L_RIA_REFERENCE_NO := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD72;

    DBG('L_RIA_REFERENCE_NO=' || L_RIA_REFERENCE_NO);

    L_ORDER_NO := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD73;

    DBG('L_ORDER_NO=' || L_ORDER_NO);

    L_RIA_PIN := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD70;

    DBG('L_RIA_PIN=' || L_RIA_PIN);

    L_RIA_CCY := 'USD';

    DBG('L_RIA_CCY=' || L_RIA_CCY);

    L_RIA_AMOUNT := P_TY_RTUPLD.ty_cstbs_ui_columns.num_field11;

    DBG('L_RIA_AMOUNT=' || L_RIA_AMOUNT);

    L_BEN_ID_TYPE := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD80;

    DBG('L_BEN_ID_TYPE=' || L_BEN_ID_TYPE);

    L_BEN_ID_VALUE := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD81;

    DBG('L_BEN_ID_VALUE=' || L_BEN_ID_VALUE);

    DBG('DATE1=' || P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD82);

    L_BEN_ID_EXPIRY_DATE := SUBSTR(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD82,
                                   1,
                                   4) || SUBSTR(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD82,
                                                6,
                                                2) ||
                            SUBSTR(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD82,
                                   9,
                                   2);

    DBG('L_BEN_ID_EXPIRY_DATE=' || L_BEN_ID_EXPIRY_DATE);

    DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD83=' ||
        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD83);

    --L_BEN_ID_ISS_BY_COUNTRY := 'KH';--P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD83;

    L_BEN_ID_ISS_BY_COUNTRY := NVL(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD83,
                                   'KH');

    DBG('L_BEN_ID_ISS_BY_COUNTRY=' || L_BEN_ID_ISS_BY_COUNTRY);

    L_CORR_LOC_ID := GLOBAL.current_branch;

    DBG('L_CORR_LOC_ID=' || L_CORR_LOC_ID);

    L_RECEIVER_ADDR := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD92 || ',' ||
                       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD93 || ',' ||
                       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD94 || ',' ||
                       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD95;

    --P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD86;

    DBG('L_RECEIVER_ADDR=' || L_RECEIVER_ADDR);

    L_RECEIVER_CITY := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD92; --P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD87;

    DBG('L_RECEIVER_CITY=' || L_RECEIVER_CITY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_UNIQUE_NO',
                               L_TXN_UNIQUE_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RIA_REFERENCE_NO',
                               L_RIA_REFERENCE_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_ORDER_NO', L_ORDER_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_RIA_PIN', L_RIA_PIN);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_RIA_CCY', L_RIA_CCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RIA_AMOUNT',
                               L_RIA_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ID_TYPE',
                               L_BEN_ID_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ID_VALUE',
                               L_BEN_ID_VALUE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ID_EXPIRY_DATE',
                               L_BEN_ID_EXPIRY_DATE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ID_ISS_BY_COUNTRY',
                               L_BEN_ID_ISS_BY_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CORR_LOC_ID',
                               L_CORR_LOC_ID);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RECEIVER_ADDR',
                               L_RECEIVER_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RECEIVER_CITY',
                               L_RECEIVER_CITY);

    DBG('BEFORE REPLACEMENT OF RIA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_RIA_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_RIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_RIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_RIA_PAYMENT=' || SQLERRM);

  END FN_GET_FMT_RIA_PAYMENT;

  PROCEDURE PR_INSERT_RIA_WS_IN_LOG(P_SEQ_NO      IN VARCHAR2,
                                    P_XREF        IN VARCHAR2,
                                    P_INVOKE_DATE IN VARCHAR2,
                                    P_RIA_PIN     IN VARCHAR2,
                                    P_REQ_TYPE    IN VARCHAR2,
                                    P_REQ_MSG     IN VARCHAR2,
                                    P_ADDL_INFO   IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN
    DBG('START OF PR_INSERT_RIA_WS_IN_LOG');

    INSERT INTO IFTB_RIA_WS_IN_LOG
      (SEQ_NO,
       TRN_REF_NO,
       INVOKE_DATE,
       RIA_PIN,
       REQ_TYPE,
       REQ_MSG,
       ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_XREF,
       P_INVOKE_DATE,
       P_RIA_PIN,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ADDL_INFO);

    COMMIT;

    DBG('END OF PR_INSERT_RIA_WS_IN_LOG');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_RIA_WS_IN_LOG');
      DBG('ERROR CODE IN PR_INSERT_RIA_WS_IN_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_RIA_WS_IN_LOG=' || SQLERRM);

  END PR_INSERT_RIA_WS_IN_LOG;

  PROCEDURE PR_UPDATE_RIA_WS_IN_LOG(P_XREF          IN IFTB_RIA_MASTER.TRN_REF_NO%TYPE,
                                    P_SEQ_NO        IN VARCHAR2,
                                    P_TXN_UNIQUE_NO IN IFTB_RIA_MASTER.TXN_UNIQUE_NO%TYPE,
                                    P_STATUS        IN CHAR,
                                    P_RES_MSG       IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_RIA_WS_IN_LOG');

    UPDATE IFTB_RIA_WS_IN_LOG
       SET TXN_UNIQUE_NO = P_TXN_UNIQUE_NO,

           RES_MSG = P_RES_MSG,
           STATUS  = P_STATUS
     WHERE TRN_REF_NO = P_XREF
       AND SEQ_NO = P_SEQ_NO;

    COMMIT;

    DBG('END OF PR_UPDATE_RIA_WS_IN_LOG');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_RIA_WS_IN_LOG');
      DBG('ERROR CODE IN PR_UPDATE_RIA_WS_IN_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_RIA_WS_IN_LOG=' || SQLERRM);
  END PR_UPDATE_RIA_WS_IN_LOG;

  FUNCTION FN_RIA_IN_WS_CALL(p_ria_call in varchar2,
                             p_out_msg  VARCHAR2,
                             p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS

    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255);
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);

    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;

  BEGIN
    dbg('START OF FN_RIA_IN_WS_CALL');

    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));

    IF p_ria_call = 'I' THEN

      L_URL := FN_GET_PARAM_VAL('PGW_RIA_IN_ENQ_URL');

    ELSIF p_ria_call = 'C' THEN

      L_URL := FN_GET_PARAM_VAL('PGW_RIA_PAYCONFIRM_IN_URL');

    END IF;

    DBG('l_url-->' || L_URL);

    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');

    utl_http.set_authentication(l_http_request,
                                FN_GET_PARAM_VAL('PGW_RIA_AUTH_UID'),
                                FN_GET_PARAM_VAL('PGW_RIA_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
    utl_http.set_header(l_http_request,
                        'content-type',
                        'application/x-www-form-urlencoded');
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));

    UTL_HTTP.set_header(l_http_request, 'USER-REQUEST-ID', global.user_id);

    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');

    utl_http.set_transfer_timeout(300);

    utl_http.write_text(l_http_request, p_out_msg);

    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));

    l_http_response := utl_http.get_response(l_http_request);

    UTL_HTTP.SET_BODY_CHARSET(l_http_response, 'UTF-8');

    dbg('Response> status_code: "' || l_http_response.status_code || '"');

    IF l_http_response.status_code = '400' THEN

      PR_LOG_ERROR('RIAC', 'FLEXCUBE', 'IF-RIA-028', '');

      RETURN FALSE;

    END IF;

    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;

    DBG('l_resp_num=' || l_resp_num);

    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;

    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;

      p_in_resp := buffer1;

      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);

    END IF;

    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;

    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;

    --    dbms_lob.freetemporary(buffer1); --buffer2 may be check

    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('Error Line Number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_RIA_IN_WS_CALL;

  FUNCTION FN_MSG_UPLOAD_RIA(P_TY_RTUPLD  IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                             P_REQ_TYPE   IN VARCHAR2,
                             P_REQ_MSG    IN OUT CLOB,
                             P_ADDL_INFO  IN VARCHAR2,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS

    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;

    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);

    L_RIA_REFERENCE_NO        CSTB_UI_COLUMNS.CHAR_FIELD72%TYPE;
    l_transactionUniqueNo     CSTB_UI_COLUMNS.CHAR_FIELD71%TYPE;
    L_ORDER_NO                CSTB_UI_COLUMNS.CHAR_FIELD73%TYPE;
    L_CURRENCY                CSTB_UI_COLUMNS.CHAR_FIELD74%TYPE;
    L_ORDER_DATE              CSTB_UI_COLUMNS.CHAR_FIELD75%TYPE;
    L_TXN_REMARKS             CSTB_UI_COLUMNS.CHAR_FIELD76%TYPE;
    L_COUNTRY_FROM            CSTB_UI_COLUMNS.CHAR_FIELD88%TYPE;
    L_SENDER_RIAC_NATIONALITY CSTB_UI_COLUMNS.CHAR_FIELD88%TYPE;
    L_SENDER_FIRST_NAME_RIAC  VARCHAR2(105);
    L_SENDER_LAST_NAME_RIAC   VARCHAR2(105);

    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);

    l_reference_no VARCHAR2(105);
    l_pc_comm_amt  VARCHAR2(105);
    l_pc_comm_ccy  VARCHAR2(105);

  BEGIN


    dbg('Inside FN_MSG_UPLOAD_RIA');

    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);

    --Log Webservice Call
    PR_INSERT_RIA_WS_IN_LOG(L_GEN_SEQ_NO,
                            P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                            SYSDATE,
                            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD70,
                            P_REQ_TYPE,
                            P_REQ_MSG,
                            P_ADDL_INFO);

    IF NOT FN_RIA_IN_WS_CALL(P_REQ_TYPE, P_REQ_MSG, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;

    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);

    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);

    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);

    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);

    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;

    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;

    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);

    IF L_STATUS_CODE <> '000' THEN

      p_err_code := 'IF-RIA-000';

      OVPKSS.PR_APPENDTBL(p_err_code, L_STATUS_MSG || '~');

      RETURN FALSE;

    END IF;

    --Handle All Errro Codes ad return false
    IF P_REQ_TYPE = 'I' THEN

      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN

        l_transactionUniqueNo := P_DOCUMENT_XML.EXTRACT('/root/data/transactionUniqueNo/text()')

                                 .GETSTRINGVAL;

        DBG('l_transactionUniqueNo =' || l_transactionUniqueNo);

        P_TY_RTUPLD.ty_cstbs_ui_columns.char_field71 := l_transactionUniqueNo;

        L_RIA_REFERENCE_NO := P_DOCUMENT_XML.EXTRACT('/root/data/riaReferenceNo/text()')

                              .GETSTRINGVAL;

        DBG('L_RIA_REFERENCE_NO =' || L_RIA_REFERENCE_NO);

        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD72 := L_RIA_REFERENCE_NO;

        L_ORDER_NO := P_DOCUMENT_XML.EXTRACT('/root/data/orderNo/text()')

                      .GETSTRINGVAL;

        DBG('L_ORDER_NO =' || L_ORDER_NO);

        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD73 := L_ORDER_NO;

        L_COUNTRY_FROM := P_DOCUMENT_XML.EXTRACT('/root/data/countryFrom/text()')

                          .GETSTRINGVAL;

        DBG('L_COUNTRY_FROM =' || L_COUNTRY_FROM);

        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD88 := L_COUNTRY_FROM;

        IF INSTR(L_RESP_IN_XML, '<senderNationality>') > 0 THEN

          L_SENDER_RIAC_NATIONALITY := P_DOCUMENT_XML.EXTRACT('/root/data/senderNationality/text()')

                                       .GETSTRINGVAL;

          DBG('L_SENDER_RIAC_NATIONALITY =' || L_SENDER_RIAC_NATIONALITY);

          P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD100 := L_SENDER_RIAC_NATIONALITY;

        END IF;

        L_SENDER_FIRST_NAME_RIAC := P_DOCUMENT_XML.EXTRACT('/root/data/senderFirstName/text()')

                                    .GETSTRINGVAL;

        DBG('L_SENDER_FIRST_NAME_RIAC =' || L_SENDER_FIRST_NAME_RIAC);

        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 := L_SENDER_FIRST_NAME_RIAC;

        L_SENDER_LAST_NAME_RIAC := P_DOCUMENT_XML.EXTRACT('/root/data/senderLastName/text()')

                                   .GETSTRINGVAL;

        DBG('L_SENDER_LAST_NAME_RIAC =' || L_SENDER_LAST_NAME_RIAC);

        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99 := L_SENDER_LAST_NAME_RIAC;

        L_CURRENCY := P_DOCUMENT_XML.EXTRACT('/root/data/currency/text()')

                      .GETSTRINGVAL;

        DBG('L_CURRENCY =' || L_CURRENCY);

        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD74 := L_CURRENCY;

        L_ORDER_DATE := P_DOCUMENT_XML.EXTRACT('/root/data/orderDate/text()')

                        .GETSTRINGVAL;

        DBG('L_ORDER_DATE =' || L_ORDER_DATE);

        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD75 := L_ORDER_DATE;

        IF INSTR(L_RESP_IN_XML, '<txnRemark>') > 0 THEN

          L_TXN_REMARKS := P_DOCUMENT_XML.EXTRACT('/root/data/txnRemark/text()')

                           .GETSTRINGVAL;

          DBG('L_TXN_REMARKS =' || L_TXN_REMARKS);

        END IF;

        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD76 := L_TXN_REMARKS;

        PR_UPDATE_RIA_WS_IN_LOG(P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                                L_GEN_SEQ_NO,
                                l_transactionUniqueNo,
                                'S',
                                L_IN_RESP);

      ELSE

        PR_UPDATE_RIA_WS_IN_LOG(P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                                L_GEN_SEQ_NO,
                                l_transactionUniqueNo,
                                'F',
                                L_IN_RESP);

        RETURN FALSE;

      END IF;
    END IF;

    IF P_REQ_TYPE = 'C' THEN

      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN

        l_reference_no := P_DOCUMENT_XML.EXTRACT('/root/data/referenceNumber/text()')

                          .GETSTRINGVAL;

        DBG('l_reference_no =' || l_reference_no);

        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD77 := L_TXN_REMARKS;

        IF INSTR(L_RESP_IN_XML, '<PCCommissionAmount>') > 0 THEN

          l_pc_comm_amt := P_DOCUMENT_XML.EXTRACT('/root/data/PCCommissionAmount/text()')

                           .GETSTRINGVAL;

          DBG('l_pc_comm_amt =' || l_pc_comm_amt);

          P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD79 := L_TXN_REMARKS;

        END IF;

        DBG('l_pc_comm_amt =' || l_pc_comm_amt);

        IF INSTR(L_RESP_IN_XML, '<PCCommissionCurrency>') > 0 THEN

          l_pc_comm_ccy := P_DOCUMENT_XML.EXTRACT('/root/data/PCCommissionCurrency/text()')

                           .GETSTRINGVAL;

          DBG('l_pc_comm_ccy =' || l_pc_comm_ccy);

          P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD78 := L_TXN_REMARKS;

        END IF;

        PR_UPDATE_RIA_WS_IN_LOG(P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                                L_GEN_SEQ_NO,
                                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD71,
                                'S',
                                L_IN_RESP);

        RETURN TRUE;

      ELSE

        PR_UPDATE_RIA_WS_IN_LOG(P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                                L_GEN_SEQ_NO,
                                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD71,
                                'F',
                                L_IN_RESP);

        IF L_STATUS_CODE = 'ERROR_402' AND
           L_STATUS_MSG = 'Transfer is expired' THEN

          dbg('RIA TRANSFER IS EXPIRED');

          p_err_code := 'IF-BNG-002';

          OVPKSS.PR_APPENDTBL(P_ERR_CODE, L_STATUS_MSG);

          RETURN FALSE;

        END IF;

        RETURN FALSE;

      END IF;
    END IF;

    dbg('Successfully processed FN_MSG_UPLOAD_RIA');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in FN_MSG_UPLOAD_RIA' ||
          SQLERRM);
      RETURN FALSE;
  END FN_MSG_UPLOAD_RIA;
  --RIA Cashwithdrawal Remittance Ends

  --RIA Phase2 Changes Ends

  FUNCTION FN_RETURN_PASSCODE_ENQUIRY RETURN CLOB IS
    L_FORMATTED_MSG varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_RETURN_PASSCODE_ENQUIRY');

    L_FORMATTED_MSG := '{
    "rcvPhone": "$L_BEN_PHONE",
    "rcvNm": "$L_BEN_NAME",
    "sndPhone": "$L_REM_PHONE",
    "sndNm": "$L_REM_NAME",
    "passCd": "$L_PASSCODE",
    "crrcy": "$L_TXN_CCY",
    "amt": "$L_TXN_AMT",
    "rcvBkCd": "$L_BEN_BIC_CODE"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_PASSCODE_ENQUIRY');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_PASSCODE_ENQUIRY');
      DBG('ERROR CODE IN FN_RETURN_PASSCODE_ENQUIRY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_PASSCODE_ENQUIRY=' || SQLERRM);
  END FN_RETURN_PASSCODE_ENQUIRY;

  FUNCTION FN_RETURN_PASSCODE_ENQUIRY_OVD RETURN CLOB IS
    L_FORMATTED_MSG varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_RETURN_PASSCODE_ENQUIRY_OVD');

    L_FORMATTED_MSG := '{
    "rcvPhone": "$L_BEN_PHONE",
    "rcvNm": "$L_BEN_NAME",
    "sndPhone": "$L_REM_PHONE",
    "sndNm": "$L_REM_NAME",
    "passCd": "$L_PASSCODE",
    "crrcy": "$L_TXN_CCY",
    "amt": "$L_TXN_AMT",
    "rcvBkCd": "$L_BEN_BIC_CODE",
    "waitKey": "$L_WAIT_KEY"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_PASSCODE_ENQUIRY_OVD');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_PASSCODE_ENQUIRY_OVD');
      DBG('ERROR CODE IN FN_RETURN_PASSCODE_ENQUIRY_OVD=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_PASSCODE_ENQUIRY_OVD=' || SQLERRM);
  END FN_RETURN_PASSCODE_ENQUIRY_OVD;

  FUNCTION FN_RETURN_FORMATTED_PASSCD_ENQ(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC)
    RETURN CLOB IS

    L_PASSCODE      VARCHAR2(100);
    L_BEN_PHONE     VARCHAR2(100);
    L_TXN_CCY       VARCHAR2(100);
    L_TXN_AMT       VARCHAR2(100);
    L_BEN_NAME      VARCHAR2(105);
    L_REM_PHONE     VARCHAR2(100);
    L_REM_NAME      VARCHAR2(105);
    L_BEN_BIC_CODE  VARCHAR2(105);
    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_RETURN_FORMATTED_PASSCD_ENQ');

    L_FORMATTED_MSG := FN_RETURN_PASSCODE_ENQUIRY;

    DBG('BEFORE REPLACEMENT OF RFT OUT PASSCODE ENQUIRY JSON=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values
    L_PASSCODE := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD41;

    DBG('L_PASSCODE=' || L_PASSCODE);

    L_BEN_PHONE := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD42;

    DBG('L_BEN_PHONE=' || L_BEN_PHONE);

    L_TXN_CCY := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD43;

    DBG('L_TXN_CCY=' || L_TXN_CCY);

    L_TXN_AMT := P_TY_RTUPLD.ty_cstbs_ui_columns.NUM_FIELD25;

    DBG('L_TXN_AMT=' || L_TXN_AMT);

    L_BEN_NAME := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44;

    DBG('L_BEN_NAME=' || L_BEN_NAME);

    L_REM_PHONE := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD47;

    DBG('L_REM_PHONE=' || L_REM_PHONE);

    L_REM_NAME := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45;

    DBG('L_REM_NAME=' || L_REM_NAME);

    L_BEN_BIC_CODE := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46;

    DBG('L_BEN_BIC_CODE=' || L_BEN_BIC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_PASSCODE', L_PASSCODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_PHONE', L_BEN_PHONE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_CCY', L_TXN_CCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_AMT', L_TXN_AMT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_NAME', L_BEN_NAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_PHONE', L_REM_PHONE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_NAME', L_REM_NAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BIC_CODE',
                               L_BEN_BIC_CODE);

    DBG('AFTER REPLACEMENT OF RFT OUT PASSCODE ENQUIRY JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_FORMATTED_PASSCD_ENQ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_FORMATTED_PASSCD_ENQ');
      DBG('ERROR CODE IN FN_RETURN_FORMATTED_PASSCD_ENQ=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_FORMATTED_PASSCD_ENQ=' || SQLERRM);
  END FN_RETURN_FORMATTED_PASSCD_ENQ;

  FUNCTION FN_RETURN_FMT_PASSCD_ENQ_OVD(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC)
    RETURN CLOB IS

    L_PASSCODE      VARCHAR2(100);
    L_BEN_PHONE     VARCHAR2(100);
    L_TXN_CCY       VARCHAR2(100);
    L_TXN_AMT       VARCHAR2(100);
    L_BEN_NAME      VARCHAR2(105);
    L_REM_PHONE     VARCHAR2(100);
    L_REM_NAME      VARCHAR2(105);
    L_BEN_BIC_CODE  VARCHAR2(105);
    L_WAIT_KEY      VARCHAR2(105);
    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_RETURN_FMT_PASSCD_ENQ_OVD');

    L_FORMATTED_MSG := FN_RETURN_PASSCODE_ENQUIRY_OVD;

    DBG('BEFORE REPLACEMENT OF RFT OUT PASSCODE ENQUIRY JSON=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values
    L_PASSCODE := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD41;

    DBG('L_PASSCODE=' || L_PASSCODE);

    L_BEN_PHONE := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD42;

    DBG('L_BEN_PHONE=' || L_BEN_PHONE);

    L_TXN_CCY := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD43;

    DBG('L_TXN_CCY=' || L_TXN_CCY);

    L_TXN_AMT := P_TY_RTUPLD.ty_cstbs_ui_columns.NUM_FIELD25;

    DBG('L_TXN_AMT=' || L_TXN_AMT);

    L_BEN_NAME := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44;

    DBG('L_BEN_NAME=' || L_BEN_NAME);

    L_REM_PHONE := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD47;

    DBG('L_REM_PHONE=' || L_REM_PHONE);

    L_REM_NAME := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45;

    DBG('L_REM_NAME=' || L_REM_NAME);

    L_BEN_BIC_CODE := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46;

    DBG('L_BEN_BIC_CODE=' || L_BEN_BIC_CODE);

    --GET WAIT KEY
    BEGIN

      SELECT A.WAIT_KEY
        INTO L_WAIT_KEY
        FROM STTB_RFT_WS_LOG_RFTM A
       WHERE XREF = P_TY_RTUPLD.ty_upld_rtl_teller.XREF
         AND PASSCODE = L_PASSCODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_WAIT_KEY := NULL;
    END;

    DBG('L_WAIT_KEY=' || L_WAIT_KEY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_PASSCODE', L_PASSCODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_PHONE', L_BEN_PHONE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_CCY', L_TXN_CCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_AMT', L_TXN_AMT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_NAME', L_BEN_NAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_PHONE', L_REM_PHONE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_NAME', L_REM_NAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BIC_CODE',
                               L_BEN_BIC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_WAIT_KEY', L_WAIT_KEY);

    DBG('AFTER REPLACEMENT OF RFT OUT PASSCODE ENQUIRY JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_FMT_PASSCD_ENQ_OVD');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_FMT_PASSCD_ENQ_OVD');
      DBG('ERROR CODE IN FN_RETURN_FMT_PASSCD_ENQ_OVD=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_FMT_PASSCD_ENQ_OVD=' || SQLERRM);
  END FN_RETURN_FMT_PASSCD_ENQ_OVD;

  FUNCTION FN_RFT_HTTP_CALL(p_rft_call in varchar2,
                            p_out_msg  VARCHAR2,
                            p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS

    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255); -- := 'http://10.80.80.11:8282/prnc-app/nbc/rft-out/rcpt-acct-inq';
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);

    /*content varchar2(4000) := '{
        "chnlCd": "01",
        "sndAcctNo": "000162694",
        "sndNm": "borey1111111111111111111111111111111",
        "rcvBkCd": "001",
        "rcvAcctNo": "11111111111111111",
        "crrcy": "KHR",
        "amt": "2000"
    }';*/

    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;

  BEGIN
    dbg('START OF FN_RFT_HTTP_CALL');

    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));

    IF P_RFT_CALL = 'PI' THEN
      L_URL := FN_GET_PARAM_VAL('PGW_NBC_RFT_PASSCD_ENQ_URL');
    ELSIF P_RFT_CALL = 'PTOWN' THEN
      L_URL := FN_GET_PARAM_VAL('PGW_NBC_RFT_PASSCD_OWNBNK_URL');
    ELSIF P_RFT_CALL = 'PTOTH' THEN
      L_URL := FN_GET_PARAM_VAL('PGW_NBC_RFT_PASSCD_OTHBNK_URL');
    END IF;

    DBG('l_url-->' || L_URL);

    UTL_HTTP.set_transfer_timeout(120);

    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');
    utl_http.set_authentication(l_http_request,
                                FN_GET_PARAM_VAL('PGW_NBC_RFT_AUTH_UID'),
                                FN_GET_PARAM_VAL('PGW_NBC_RFT_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));

    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');

    utl_http.write_text(l_http_request, p_out_msg);

    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));

    l_http_response := utl_http.get_response(l_http_request);

    dbg('Response> status_code: "' || l_http_response.status_code || '"');

    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;

    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;

    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;

      p_in_resp := buffer1;

      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);

    END IF;

    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;

    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;

    dbms_lob.freetemporary(buffer1); --buffer2 may be check

    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('error line number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_RFT_HTTP_CALL;

  FUNCTION fn_msg_upload(p_msg        IN OUT CLOB,
                         p_rft_call   IN VARCHAR2,
                         p_err_code   IN OUT VARCHAR2,
                         p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS

    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
    l_in_resp       CLOB;
    e_update_error EXCEPTION;
    L_TXNSTATUS_CODE IFTBS_RFT_MASTER.txn_status%TYPE := fn_get_param_val('PGW_TEMP_TXN_STAT');
    L_TXNSTATUS_MSG  IFTBS_RFT_MASTER.txn_remarks%TYPE := fn_get_param_val('PGW_TEMP_TXN_REMARKS');
    l_pos            NUMBER := 0;
    r_pos            NUMBER := 0;
    L_RESP_IN_XML    clob;
    P_DOCUMENT_XML   XMLTYPE;
    L_TXNUNIQUE_NO   VARCHAR2(100);
    L_TRACE_NO       VARCHAR2(100);
    L_BANKCODE       VARCHAR2(100);

  BEGIN

    dbg('lp_msg=' || p_msg);

    IF NOT FN_RFT_HTTP_CALL(p_rft_call, p_msg, L_IN_RESP) THEN
      DBG('failed to send pain_001_001_05');
      RAISE E_UPDATE_ERROR;
    END IF;

    DBG('Sent and response in json is ' || L_IN_RESP);

    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    debug.pr_debug('IF', 'L_RESP_IN_XML=' || L_RESP_IN_XML);

    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('One step done-->' || L_RESP_IN_XML);
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('Two step done and after UNESCAPE, it is ' || L_RESP_IN_XML);

    DBG('After cutting other irrelevant parts , it is ' || L_RESP_IN_XML);

    --Update the table
    --PR_MSG_UPDATE(p_ifdrftpm.v_iftbs_rft_master.msg_id, L_IN_RESP);

    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

    --check if it is already refunded by other bank since message id is different
    L_TXNSTATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                        .GETSTRINGVAL;

    L_TXNSTATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                       .GETSTRINGVAL;

    L_BANKCODE := P_DOCUMENT_XML.EXTRACT('/root/bankTp/text()').GETSTRINGVAL;

    L_TXNUNIQUE_NO := P_DOCUMENT_XML.EXTRACT('/root/data/txnUnqNo/text()')
                      .GETSTRINGVAL;

    L_TRACE_NO := P_DOCUMENT_XML.EXTRACT('/root/data/tracNo/text()')
                  .GETSTRINGVAL;

    DBG('L_TXNSTATUS_CODE is ' || L_TXNSTATUS_CODE);
    DBG('L_TXNSTATUS_MSG is ' || L_TXNSTATUS_MSG); -- COMMENTED TEMPORARILY FOR OFFSHORE TESTING - ALL TXN TO GO AS ACCEPTED

    IF L_TXNSTATUS_CODE = 'SUCCESS' THEN

      --PR_UPDATE_STATUS_FAST_OUTGOING(p_ifdrftpm.v_iftbs_rft_master.TRN_REF_NO,
      --                           L_TXNSTATUS);

      DBG('SUCCESS');

    ELSE
      DBG('FAILED');

    END IF;

    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      RETURN FALSE;
  END fn_msg_upload;

  --NBC RFT Changes Ends

  --Prince Bank Credit Card Payment by Cash GL starts
  FUNCTION FN_GET_MASVISUPIGL_CREDIT_CARD(P_CARD_TYPE IN VARCHAR2)
    RETURN LMTM_TYPE_VALUES.VALUE%TYPE IS
    L_MAS_VIS_CARD_GL LMTM_TYPE_VALUES.VALUE%TYPE;
  BEGIN
    DBG('P_CARD_TYPE=' || P_CARD_TYPE);
    BEGIN
      SELECT B.VALUE
        INTO L_MAS_VIS_CARD_GL
        FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
       WHERE A.TYPE = B.TYPE
         AND A.TYPE = 'CREDIT_CARD_ACCS'
         AND B.CODE = P_CARD_TYPE
         AND A.RECORD_STAT = 'O'
         AND A.AUTH_STAT = 'A';
    EXCEPTION
      WHEN OTHERS THEN
        L_MAS_VIS_CARD_GL := NULL;
    END;
    DBG('L_MAS_VIS_CARD_GL=' || L_MAS_VIS_CARD_GL);
    RETURN L_MAS_VIS_CARD_GL;
  EXCEPTION
    WHEN OTHERS THEN
      L_MAS_VIS_CARD_GL := NULL;

      RETURN L_MAS_VIS_CARD_GL;
  END FN_GET_MASVISUPIGL_CREDIT_CARD;

  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2) IS

    --P_COSMETIC_XML VARCHAR2(32000);

  BEGIN

    P_COSMETIC_XML := P_XML;

    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body>',
                              NULL);
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xmlns:ns4="http://sv.bpc.in/SVAP/iss" xmlns:ns3="http://bpc.ru/SVIS/ewallet/v1.0/" xmlns:ns2="http://bpc.ru/common/types/v0.1/" xmlns="http://bpc.ru/SVIS/cmsSvng/v1.1/"',
                              NULL);

    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML, 'ns2:', NULL);

    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '</soap:Body></soap:Envelope>',
                              NULL);

  END PR_RETURN_COSMETIC_XML;

  FUNCTION get_param_val(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END get_param_val;

  FUNCTION FN_GET_ISO_CURRENCY_CODE(P_ISO_CCY IN VARCHAR2)
    RETURN CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE AS
    L_CCY_CODE CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE;
  BEGIN
    BEGIN
      SELECT CCY_CODE
        INTO L_CCY_CODE
        FROM CYTMS_CCY_DEFN_MASTER
       WHERE ISO_NUM_CCY_CODE = P_ISO_CCY
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      RETURN L_CCY_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN L_CCY_CODE;
    END;
    RETURN L_CCY_CODE;
  END FN_GET_ISO_CURRENCY_CODE;

  FUNCTION FN_CREDIT_CARD_HTTP_CALL(p_out_msg VARCHAR2,
                                    p_in_resp IN OUT CLOB) RETURN BOOLEAN IS

    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_buffer_size   NUMBER(10) := 512;
    l_substring_msg VARCHAR2(32767);
    l_raw_data      RAW(2000);
    l_clob_response CLOB;
    l_url           cstb_param.param_val%TYPE;
    l_resp_ok       BOOLEAN;
    l_resp_num      NUMBER;

  BEGIN

    debug.pr_DebuG('IF', 'In FN_FAST_HTTP_CALL');
    dbms_lob.createtemporary(lob_loc => l_clob_response, cache => TRUE);

    --Get URL of Smart Vista
    l_url := get_param_val('PGW_SMART_VISTA_WS');

    --l_url := 'http://10.80.80.68:7026/svis/CmsSvng';

    debug.pr_DebuG('IF', 'l_url-->' || l_url);
    l_http_request := utl_http.begin_request(url          => l_url,
                                             method       => 'POST',
                                             http_version => 'HTTP/1.1');
    utl_http.set_header(l_http_request, 'User-Agent', 'Mozilla/4.0');
    utl_http.set_header(l_http_request, 'Connection', 'close');
    utl_http.set_header(l_http_request,
                        'Content-Type',
                        'text/xml; charset=utf-8');
    -- UTL_HTTP.set_header (l_http_request, 'Content-Length', lengthb(CONVERT(p_out_msg, 'UTF8')));

    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
    <<request_loop>>

    FOR i IN 0 .. ceil(length(p_out_msg) / l_buffer_size) - 1 LOOP
      l_substring_msg := substr(p_out_msg,
                                i * l_buffer_size + 1,
                                l_buffer_size);
      BEGIN
        l_raw_data := utl_raw.cast_to_raw(l_substring_msg);
        utl_http.write_raw(r => l_http_request, data => l_raw_data);
      EXCEPTION
        WHEN no_data_found THEN
          debug.pr_DebuG('IF', 'Request Loop NDF');
          EXIT request_loop;
      END;
    END LOOP request_loop;
    l_http_response := utl_http.get_response(l_http_request);
    debug.pr_DebuG('IF',
                   'Response> status_code: "' ||
                   l_http_response.status_code || '"');

    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;

    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;

    IF l_resp_ok THEN
      BEGIN
        <<response_loop>>
        LOOP
          utl_http.read_raw(l_http_response, l_raw_data, l_buffer_size);
          l_clob_response := l_clob_response ||
                             utl_raw.cast_to_varchar2(l_raw_data);
        END LOOP response_loop;
      EXCEPTION
        WHEN utl_http.end_of_body THEN
          utl_http.end_response(l_http_response);
        WHEN OTHERS THEN
          debug.pr_DebuG('IF', 'Inside Exception others in response');
          debug.pr_DebuG('IF', SQLERRM);
          debug.pr_DebuG('IF', dbms_utility.format_error_backtrace);
          utl_http.end_response(l_http_response);
      END;
      debug.pr_DebuG('IF', 'Out of Loop');

      p_in_resp := l_clob_response;

    END IF;

    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;

    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;

    dbms_lob.freetemporary(l_clob_response);

    IF l_resp_ok THEN
      debug.pr_DebuG('IF', 'OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      debug.pr_DebuG('IF', 'PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_DebuG('IF', 'In WOT...Return false now...' || SQLERRM);
      RETURN FALSE;
  END FN_CREDIT_CARD_HTTP_CALL;
  --Prince Bank Credit Card Payment by Cash GL ends

  FUNCTION FN_POP_PLSQL_TBL(P_NODE_NAME         IN VARCHAR2,
                            P_DTF               IN VARCHAR2,
                            P_TBL_NAME_VAL_PAIR IN OUT NOCOPY GWPKS_CREATERETAILTLR.TY_RECS_TBL,
                            P_TY_RTUPLD         IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                            P_ERR_CODE          IN OUT VARCHAR2,
                            P_ERR_PARAM         IN OUT VARCHAR2,
                            P_FN_CALL_ID        IN OUT NUMBER,
                            P_TB_CUSTOM_DATA    IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
    --Prince Bank AML Changes Starts
    ERROR_EXCEPTION EXCEPTION;
    L_RATE_FLAG NUMBER;
    L_RATE      NUMBER;
    l_txn_amt   DETB_RTL_TELLER.TXN_AMOUNT%TYPE;
    l_txn_amt1  DETB_RTL_TELLER.TXN_AMOUNT%TYPE;
    L_PROD      CSTM_PRODUCT%ROWTYPE;
    --Prince Bank AML Changes Ends

    --Prince Bank Credit Card Payment by Cash GL starts
    l_formatted_msg    CLOB;
    L_FORMATTED_MSG1   CLOB;
    l_in_resp          CLOB;
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_CARD_ID          VARCHAR2(100);
    L_CARD_TYPE        VARCHAR2(100);
    L_CARD_STATUS      VARCHAR2(100);
    L_NAME_ON_CARD     VARCHAR2(100);
    L_TOTAL_AMOUNT_DUE VARCHAR2(100);
    L_PAYMENT_CCY      VARCHAR2(100);

    L_CREDIT_ACC_NO VARCHAR2(20);
    L_ERROR_CODE    VARCHAR2(255);
    L_ERROR_DESC    VARCHAR2(255);
    L_CARD_GL       LMTM_TYPE_VALUES.VALUE%TYPE;
    --Prince Bank for credit card payment by cash gl ends

  --NBC RFT changes Starts
    L_RFT_CALL      VARCHAR2(10);
    L_RESP_IN_XML   clob;
    L_RESPONSE_CODE VARCHAR2(100);
    L_RESPONSE_MSG  VARCHAR2(100);
    L_BANKCODE      VARCHAR2(100);
    L_TXNUNIQUE_NO  VARCHAR2(100);
    L_TRACE_NO      VARCHAR2(100);
    L_COUNT         NUMBER;
    L_DATA          VARCHAR2(100);
    L_WAIT_KEY      VARCHAR2(100);
    --NBC RFT changes Ends

  --RIA Phase2 Changes Starts

  --RIA Cashwithdrawal Remittance Starts
    l_ofs_amt DETB_RTL_TELLER.OFS_AMOUNT%TYPE;

    L_CUST_FULLNAME      VARCHAR2(105);
    L_CUST_BIRTH_COUNTRY VARCHAR2(100);
    L_CUST_NATIONALITY   VARCHAR2(100);
    L_CUST_ADDRLINE1     VARCHAR2(100);
    L_CUST_ADDRLINE2     VARCHAR2(100);
    L_CUST_ADDRLINE3     VARCHAR2(100);
    L_CUST_ADDRLINE4     VARCHAR2(100);
    L_CUST_ADDR_COUNTRY  VARCHAR2(100);
    L_CUST_OCCUPATION    VARCHAR2(100);
    L_CUST_UID_EXPDATE   DATE;

    TYPE TYPE_RISK_SCORE IS VARRAY(5) OF INTEGER;
    L_RISK_SCORE            TYPE_RISK_SCORE;
    L_MAX_INDEX             NUMBER;
    L_MAX_VALUE             NUMBER;
    L_HIGH_SEN_CNT          STTM_CUSTOMER.NATIONALITY%TYPE;
    L_HIGH_BEN_CNT          STTM_CUSTOMER.NATIONALITY%TYPE;
    P_HIT_STATUS            VARCHAR2(100);
    P_WHO_HIT               CHAR(1);
    P_SCAN_ID               VARCHAR2(100);
    L_AML_FLOW_COUNT        NUMBER := 0;
    L_STTB_CORAL_RIA_WS_LOG STTB_CORAL_RIA_WS_LOG%ROWTYPE;

    L_CORAL_HIT_EXCEPTION EXCEPTION;
    PRAGMA exception_init(L_CORAL_HIT_EXCEPTION, -20111);
    --RIA Cashwithdrawal Remittance Ends

  --RIA Phase2 Changes Ends

  --AML New Payment Flow Starts
    L_REF VARCHAR2(16);
    --AML New Payment Flow Ends


  BEGIN
    IF P_FN_CALL_ID = 1 THEN

      DBG('IF', 'Inside fn_pop_plsql_tbl ...');

      --Prince Bank AML Changes Starts

      DBG('GWPKS_UTIL.PKG_ACTTYPE=' || GWPKS_UTIL.PKG_ACTTYPE);

      DBG('GWPKS_UTIL.PKG_FUNC=' || GWPKS_UTIL.PKG_FUNC);

       --Prince Bank for credit card payment by cash gl starts
      IF GWPKS_UTIL.PKG_FUNC IN ('CCCG') THEN
        IF GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH') THEN

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD3') THEN
            DBG('CREDIT CARD NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                                                           .TYP_VAR_VALUE;

          END IF;

          DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3=' ||
              P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3);
          IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3 IS NULL THEN
            --DBG('Participant Name Should not be null');
            P_ERR_CODE := '';
            OVPKSS.PR_APPENDTBL('IF-SVCC002', null);
            --Pr_Log_Error(p_Function_id, p_Source, 'IF-SVCC002', NULL);
            RETURN FALSE;
          END IF;

          --IF GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH') THEN

          L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v1="http://bpc.ru/SVIS/cmsSvng/v1.1/">
   <soapenv:Header>
      <wsse:Security  xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
         <wsse:UsernameToken wsu:Id="UsernameToken-1">
            <wsse:Username>' ||
                             get_param_val('PGW_SMART_VISTA_WS_UID') ||
                             '</wsse:Username>
            <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">' ||
                             get_param_val('PGW_SMART_VISTA_WS_PWD') ||
                             '</wsse:Password>
         </wsse:UsernameToken>
      </wsse:Security>
 </soapenv:Header>
   <soapenv:Body>
      <v1:getCardInfoRequest>
          <v1:cardNumber>' ||
                             P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3 ||
                             '</v1:cardNumber>
      </v1:getCardInfoRequest>
   </soapenv:Body>
</soapenv:Envelope>';

          dbg('l_formatted_msg for fast' || L_FORMATTED_MSG);

          --Invoke SV Credit Card System
          IF NOT FN_CREDIT_CARD_HTTP_CALL(L_FORMATTED_MSG, L_IN_RESP) THEN
            DBG('failed to invoke Smart vista call');
            --RAISE E_UPDATE_ERROR;
            P_ERR_CODE := '';
            OVPKSS.PR_APPENDTBL('IF-SVCC003', null);
            RETURN FALSE;
          END IF;

          DBG('RESPONSE=' || L_IN_RESP);

          --Get Cosmetic XML
          PR_RETURN_COSMETIC_XML(L_IN_RESP, L_COSMETIC_RES_MSG);

          DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);

          P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);

          --Check if returned error or success
          L_ERROR_CODE := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/errorCode/text()')
                          .GETSTRINGVAL;

          IF L_ERROR_CODE <> 'SUCCESS' THEN
            L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/errorDesc/text()')
                            .GETSTRINGVAL;

            P_ERR_CODE := '';
            OVPKSS.PR_APPENDTBL('IF-SVCC003', null);
            --Pr_Log_Error(p_Function_id, p_Source, 'IF-SVCC003',    L_ERROR_DESC);
            RETURN FALSE;
          END IF;

          L_CREDIT_ACC_NO := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/cardAccounts/account/text()')
                             .GETSTRINGVAL;

          DBG('L_CREDIT_ACC_NO=' || L_CREDIT_ACC_NO);

          L_CARD_ID := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/cardId/text()')
                       .GETSTRINGVAL;

          DBG('L_CARD_ID=' || L_CARD_ID);

          L_CARD_TYPE := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/cardType/text()')
                         .GETSTRINGVAL;

          DBG('L_CARD_TYPE=' || L_CARD_TYPE);

          L_CARD_STATUS := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/cardStatusDesc/text()')
                           .GETSTRINGVAL;

          DBG('L_CARD_STATUS=' || L_CARD_STATUS);

          L_NAME_ON_CARD := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/embossName/text()')
                            .GETSTRINGVAL;

          DBG('L_NAME_ON_CARD=' || L_NAME_ON_CARD);

          --Call Second API to get Amount Due
          L_FORMATTED_MSG1 := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v1="http://bpc.ru/SVIS/cmsSvng/v1.1/">
   <soapenv:Header>
      <wsse:Security  xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
         <wsse:UsernameToken wsu:Id="UsernameToken-1">
            <wsse:Username>svwi</wsse:Username>
            <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">svwiadmin</wsse:Password>
         </wsse:UsernameToken>
      </wsse:Security>
 </soapenv:Header>
   <soapenv:Body>
      <v1:getCreditCardInfoRequest>
         <v1:cardId>' || L_CARD_ID ||
                              '</v1:cardId>
      </v1:getCreditCardInfoRequest>
   </soapenv:Body>
</soapenv:Envelope>';

          dbg('l_formatted_msg1' || L_FORMATTED_MSG1);

          --Invoke SV Credit Card System
          IF NOT FN_CREDIT_CARD_HTTP_CALL(L_FORMATTED_MSG1, L_IN_RESP) THEN
            DBG('failed to invoke Smart vista call');
            --RAISE E_UPDATE_ERROR;
            P_ERR_CODE := '';
            OVPKSS.PR_APPENDTBL('IF-SVCC003', null);
            RETURN FALSE;
          END IF;

          DBG('RESPONSE=' || L_IN_RESP);

          --Get Cosmetic XML
          PR_RETURN_COSMETIC_XML(L_IN_RESP, L_COSMETIC_RES_MSG);
          DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);

          P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);

          --check if it is already refunded by other bank since message id is different
          L_TOTAL_AMOUNT_DUE := P_DOCUMENT_XML.EXTRACT('/getCreditCardInfoResponse/totalAmountDue/text()')
                                .GETSTRINGVAL;

          L_PAYMENT_CCY := P_DOCUMENT_XML.EXTRACT('/getCreditCardInfoResponse/accountCurrency/text()')
                           .GETSTRINGVAL;

          --END IF;
          --Default Values
          P_TY_RTUPLD.ty_cstbs_ui_columns.char_field4 := L_CREDIT_ACC_NO;
          --p_ifdcccas.v_credit_card_pymnt_by_cash.credit_card_ac_no := L_CREDIT_ACC_NO;
          P_TY_RTUPLD.ty_cstbs_ui_columns.char_field5 := CASE
                                                           WHEN L_CARD_TYPE = '31' OR
                                                                L_CARD_TYPE = '33' THEN
                                                            'M'
                                                           WHEN L_CARD_TYPE = '51' OR
                                                                L_CARD_TYPE = '53' THEN
                                                            'V'
                                                           WHEN L_CARD_TYPE = '62' OR  --UPI Starts
                                                                L_CARD_TYPE = '63' THEN
                                                            'U'  --UPI Ends
                                                           ELSE
                                                            NULL
                                                         END;
          P_TY_RTUPLD.ty_cstbs_ui_columns.char_field6 := L_CARD_STATUS;
          P_TY_RTUPLD.ty_cstbs_ui_columns.char_field7 := L_NAME_ON_CARD;
          P_TY_RTUPLD.ty_cstbs_ui_columns.char_field8 := L_TOTAL_AMOUNT_DUE / 100;
          P_TY_RTUPLD.ty_cstbs_ui_columns.char_field9 := FN_GET_ISO_CURRENCY_CODE(L_PAYMENT_CCY);

          --Default Product Code
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE := CASE
                                                           WHEN L_CARD_TYPE = '31' OR
                                                                L_CARD_TYPE = '33' THEN
                                                            'CCCH'
                                                           WHEN L_CARD_TYPE = '51' OR
                                                                L_CARD_TYPE = '53' THEN
                                                            'CCCV'
                                                           WHEN L_CARD_TYPE = '62' OR  --UPI Starts
                                                                L_CARD_TYPE = '63' THEN
                                                            'CCCU'  --UPI Ends
                                                           ELSE
                                                            NULL
                                                         END;
          P_TBL_NAME_VAL_PAIR('PRD').TYP_VAR_VALUE := P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE;

          --Validation against Master Card Type and GL that we use while paying payment
          IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field5 = 'M' THEN
            L_CARD_GL := FN_GET_MASVISUPIGL_CREDIT_CARD('MCCP');
            dbg('L_CARD_GL=' || L_CARD_GL);
            dbg('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
            IF L_CARD_GL <> P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC THEN
              OVPKSS.PR_APPENDTBL('IF-SVCC004', null);
              RETURN FALSE;
            END IF;
          END IF;
          IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field5 = 'V' THEN
            L_CARD_GL := FN_GET_MASVISUPIGL_CREDIT_CARD('VCCP');
            dbg('L_CARD_GL=' || L_CARD_GL);
            dbg('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
            IF L_CARD_GL <> P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC THEN
              OVPKSS.PR_APPENDTBL('IF-SVCC005', null);
              RETURN FALSE;
            END IF;

          END IF;

      --UPI Starts
          IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field5 = 'U' THEN
            L_CARD_GL := FN_GET_MASVISUPIGL_CREDIT_CARD('UCCP');
            dbg('L_CARD_GL=' || L_CARD_GL);
            dbg('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
            IF L_CARD_GL <> P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC THEN
              OVPKSS.PR_APPENDTBL('IF-SVCC005', null);
              RETURN FALSE;
            END IF;

          END IF;
          --UPI Ends

        END IF;

        IF GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH','REVERSE') THEN

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD3') THEN
            DBG('CREDIT CARD NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD4') THEN
            DBG('CREDIT CARD NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field4 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD4')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD5') THEN
            DBG('CREDIT CARD NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field5 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD5')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD6') THEN
            DBG('CREDIT CARD NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field6 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD6')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD7') THEN
            DBG('CREDIT CARD NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field7 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD7')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD8') THEN
            DBG('CREDIT CARD NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field8 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD8')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD9') THEN
            DBG('CREDIT CARD NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field9 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD9')
                                                           .TYP_VAR_VALUE;

          END IF;

          --authAction

        END IF;

      END IF;
      --Prince Bank Credit Card Payment by Cash GL ends

      IF GWPKS_UTIL.PKG_FUNC IN ('1001', '1401', '8203', '8004', '1013') THEN

        IF GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH', 'SAVEAUTOAUTH') THEN

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD31') THEN

            DBG('SAME AS ACCOUNT OWNER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD31')
                .TYP_VAR_VALUE);

            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field31 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD31')
                                                            .TYP_VAR_VALUE;

            IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field31 = 'Y' THEN
              DBG('Depks_RetailTellerUpload.g_ui_txn_acc=' ||
                  Depks_RetailTellerUpload.g_ui_txn_acc);


        IF GWPKS_UTIL.PKG_FUNC IN ('1013') THEN
                --AML Participant Enhancements Changes

                --participant cif no changes starts
                BEGIN
                  SELECT A.CUSTOMER_NO,
                         A.CUSTOMER_NAME1,
                         B.MOBILE_NUMBER,
                         A.UNIQUE_ID_NAME,
                         A.UNIQUE_ID_VALUE
                    into P_TBL_NAME_VAL_PAIR('CHAR_FIELD40').TYP_VAR_VALUE, --AML Participant Enhancements Changes

                         P_TBL_NAME_VAL_PAIR('CHAR_FIELD32').TYP_VAR_VALUE,
                         P_TBL_NAME_VAL_PAIR('CHAR_FIELD33').TYP_VAR_VALUE,
                         P_TBL_NAME_VAL_PAIR('CHAR_FIELD36').TYP_VAR_VALUE,
                         P_TBL_NAME_VAL_PAIR('CHAR_FIELD37').TYP_VAR_VALUE
                    FROM STTM_CUSTOMER      A,
                         STTM_CUST_PERSONAL B,
                         STTM_CUST_ACCOUNT  C
                   WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                     AND A.CUSTOMER_NO = C.CUST_NO
                     AND C.CUST_AC_NO =
                         NVL(Depks_RetailTellerUpload.g_ui_txn_acc,
                             P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC)
                     AND A.RECORD_STAT = 'O'
                     AND A.AUTH_STAT = 'A';
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('ERROR CODE=' || SQLCODE);
                    DBG('ERROR MESSAGE=' || SQLCODE);
                END;
                --AML Participant Enhancements Changes ends

              ELSE
                --AML Participant Enhancements Changes


        --Derive Customer Name and Mobile No
              BEGIN
                SELECT A.CUSTOMER_NO,A.CUSTOMER_NAME1, B.MOBILE_NUMBER
                                      into P_TBL_NAME_VAL_PAIR('CHAR_FIELD40').TYP_VAR_VALUE, --AML Participant Enhancements Changes

          P_TBL_NAME_VAL_PAIR('CHAR_FIELD32').TYP_VAR_VALUE,
                       P_TBL_NAME_VAL_PAIR('CHAR_FIELD33').TYP_VAR_VALUE
                  FROM STTM_CUSTOMER      A,
                       STTM_CUST_PERSONAL B,
                       STTM_CUST_ACCOUNT  C
                 WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                   AND A.CUSTOMER_NO = C.CUST_NO
                   AND C.CUST_AC_NO =
                       NVL(Depks_RetailTellerUpload.g_ui_txn_acc,
                           P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC)
                   AND A.RECORD_STAT = 'O'
                   --AND A.AUTH_STAT = 'A'; --sampath comment
                   AND (A.AUTH_STAT = 'A' OR A.CUSTOMER_NO = '00001601');  -- sampath added
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('ERROR CODE=' || SQLCODE);
                  DBG('ERROR MESSAGE=' || SQLCODE);
              END;
         END IF; --AML Participant Enhancements Changes

            END IF;

          END IF;

       --AML Participant Enhancements Changes starts
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD40') THEN
            DBG('PARTICIPANT NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD40')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD40 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD40')
                                                            .TYP_VAR_VALUE;

          END IF;
          --AML Participant Enhancements Changes ends

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD32') THEN
            DBG('PARTICIPANT NAME=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD32')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field32 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD32')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD33') THEN
            DBG('MOBILE NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD33')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD33')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD34') THEN
            DBG('PURPOSE OF TRANSACTION=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD34')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD34')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD35') THEN
            DBG('SOURCE OF FUNDS=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD35')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD35 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD35')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF GWPKS_UTIL.PKG_FUNC IN ('1013') THEN
            --field 36
            IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD36') THEN
              DBG('UNIQUE IDENTIFIER NAME=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD36')
                  .TYP_VAR_VALUE);
              P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD36 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD36')
                                                              .TYP_VAR_VALUE;

            END IF;

            --field 37
            IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD37') THEN
              DBG('UNIQUE IDENTIFIER VALUE=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD37')
                  .TYP_VAR_VALUE);
              P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD37 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD37')
                                                              .TYP_VAR_VALUE;

            END IF;
          END IF;

      --AML Participant Enhancements Changes starts
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD40') THEN
            IF P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD40 IS NULL THEN
              DBG('Participant cif no Should not be null');
              P_ERR_CODE := '';
              OVPKSS.PR_APPENDTBL('DE-PRIN-006', null);
              RETURN FALSE;
            END IF;
          END IF;
          --AML Participant Enhancements Changes ends

          --Validations on field 32, field 33
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD32') THEN
            IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field32 IS NULL THEN
              DBG('Participant Name Should not be null');
              P_ERR_CODE := '';
              OVPKSS.PR_APPENDTBL('DE-PRIN-001', null);
              RETURN FALSE;
            END IF;
          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD33') THEN

            IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field33 IS NULL THEN
              DBG('Mobile Number should not be null');
              OVPKSS.PR_APPENDTBL('DE-PRIN-002', null);
              RETURN FALSE;
            END IF;
          END IF;

          --Validation on field 34, 35
          IF GWPKS_UTIL.PKG_FUNC IN ('1001', '1401', '1013') THEN

            IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY <>
               P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY THEN

              IF GWPKS_UTIL.PKG_FUNC IN ('1001', '1013') THEN
                DBG('INSIDE 1001 and 1013');
                DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY=' ||
                    P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY);
                DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY=' ||
                    P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);
                --for cash withdrawal

                IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY = GLOBAL.lcy THEN
                  IF NOT cypkss.fn_amt1_to_amt2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                                GLOBAL.LCY,
                                                'COMM', --depks_rtl_teller.PKG_PROD.RATE_TYPE_PREFERRED, --AML Participant Enhancements Changes
                                                'S',
                                                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                                'Y',
                                                l_txn_amt,
                                                l_rate,
                                                P_ERR_PARAM) THEN
                    debug.pr_debug('**', '');
                    debug.pr_debug('**', SQLERRM);
                    p_err_code  := 'ST-OTHR-001';
                    P_ERR_PARAM := NULL;
                    RETURN FALSE;
                  END IF;
                ELSE
                  IF NOT cypkss.fn_amt1_to_amt2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY,
                                                'COMM',--depks_rtl_teller.PKG_PROD.RATE_TYPE_PREFERRED, --AML Participant Enhancements Changes
                                                'S',
                                                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                                'Y',
                                                l_txn_amt,
                                                l_rate,
                                                P_ERR_PARAM) THEN
                    debug.pr_debug('**', '');
                    debug.pr_debug('**', SQLERRM);
                    p_err_code  := 'ST-OTHR-001';
                    P_ERR_PARAM := NULL;
                    RETURN FALSE;
                  END IF;
                END IF;

              ELSIF GWPKS_UTIL.PKG_FUNC IN ('1401') THEN
                DBG('INSIDE 1401');
                DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY=' ||
                    P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY);
                DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY=' ||
                    P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);

                IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY = GLOBAL.LCY THEN
                  IF NOT cypkss.fn_amt1_to_amt2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                                GLOBAL.LCY,
                                                'COMM',--depks_rtl_teller.PKG_PROD.RATE_TYPE_PREFERRED,
                                                'B',
                                                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                                'Y',
                                                l_txn_amt,
                                                l_rate,
                                                P_ERR_PARAM) THEN
                    debug.pr_debug('**', '');
                    debug.pr_debug('**', SQLERRM);
                    p_err_code  := 'ST-OTHR-001';
                    P_ERR_PARAM := NULL;
                    RETURN FALSE;
                  END IF;
                ELSE
                  IF NOT cypkss.fn_amt1_to_amt2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY,
                                                'COMM',--depks_rtl_teller.PKG_PROD.RATE_TYPE_PREFERRED,
                                                'B',
                                                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                                'Y',
                                                l_txn_amt,
                                                l_rate,
                                                P_ERR_PARAM) THEN
                    debug.pr_debug('**', '');
                    debug.pr_debug('**', SQLERRM);
                    p_err_code  := 'ST-OTHR-001';
                    P_ERR_PARAM := NULL;
                    RETURN FALSE;
                  END IF;
                END IF;

              END IF;
              dbg('l_txn_amt->' || l_txn_amt);

            ELSE

              IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                            GLOBAL.lcy,
                                            'STANDARD',  -- Change RATE from STANDARD to COMM
                                            'M',
                                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                            'Y',
                                            l_txn_amt,
                                            l_rate,
                                            P_ERR_CODE) THEN
                RETURN FALSE;
              END IF;

              -- l_txn_amt := P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT;
            END IF;

            dbg('l_txn_amt->' || l_txn_amt);

            --if transaction amount >=10K then purpose of txn and source of funds mandatory
            IF GWPKS_UTIL.PKG_FUNC IN ('1001', '1013') THEN
              IF l_txn_amt >= 10000 THEN

                IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34 IS NULL THEN
                  DBG('Purpose of Transaction should not be null if USD Amount >10K');
                  OVPKSS.PR_APPENDTBL('DE-PRIN-005', null);
                  RETURN FALSE;
                END IF;
              END IF;
            ELSE
              IF l_txn_amt >= 10000 THEN
                IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34 IS NULL OR
                   P_TY_RTUPLD.ty_cstbs_ui_columns.char_field35 IS NULL THEN
                  DBG('Purpose of Transaction or Source of Funds should not be null if USD Amount >10K');
                  OVPKSS.PR_APPENDTBL('DE-PRIN-003', null);
                  RETURN FALSE;
                END IF;
              END IF;
            END IF;

          ELSIF GWPKS_UTIL.PKG_FUNC IN ('8203', '8004') THEN
            DBG('INSIDE 8203');

            IF P_TBL_NAME_VAL_PAIR.EXISTS('RELCUST') THEN

              DBG('RELCUST RELCUST=' || P_TBL_NAME_VAL_PAIR('RELCUST')
                  .TYP_VAR_VALUE);
              DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER :==' ||
                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER);

              IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER IS NULL THEN
                DBG('Participant id Should not be null');
                P_ERR_CODE := '';
                OVPKSS.PR_APPENDTBL('DE-PRIN-004', null);
                RETURN FALSE;
              END IF;

            END IF;

            IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD1') THEN
              DBG('PARTICIPANT NAME=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD1')
                  .TYP_VAR_VALUE);

              IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field1 IS NULL THEN
                DBG('Participant Name Should not be null');
                P_ERR_CODE := '';
                OVPKSS.PR_APPENDTBL('DE-PRIN-001', null);
                RETURN FALSE;
              END IF;

            END IF;

      --AML Participant No Changes Starts
      IF P_TBL_NAME_VAL_PAIR.EXISTS('BENFNAME') THEN
              DBG('PARTICIPANT NAME=' || P_TBL_NAME_VAL_PAIR('BENFNAME')
                  .TYP_VAR_VALUE);

            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field1 := P_TBL_NAME_VAL_PAIR('BENFNAME')
                                                            .TYP_VAR_VALUE;



            END IF;

            IF P_TBL_NAME_VAL_PAIR.EXISTS('OTHERDETLS1') THEN
              DBG('MOBILE NO=' || P_TBL_NAME_VAL_PAIR('OTHERDETLS1')
                  .TYP_VAR_VALUE);

            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field6 := P_TBL_NAME_VAL_PAIR('OTHERDETLS1')
                                                            .TYP_VAR_VALUE;



            END IF;
      --AML Participant No Changes Ends

            IF GWPKS_UTIL.PKG_FUNC IN ('8203') THEN
              IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY <>
                 P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY THEN
                IF NOT cypkss.fn_amt1_to_amt2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY,
                                              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                              'COMM',--depks_rtl_teller.PKG_PROD.RATE_TYPE_PREFERRED,
                                              'S',
                                              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT,
                                              'Y',
                                              l_txn_amt,
                                              l_rate,
                                              P_ERR_PARAM) THEN
                  debug.pr_debug('**', '');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code  := 'ST-OTHR-001';
                  P_ERR_PARAM := NULL;
                  RETURN FALSE;
                END IF;
              END IF;
            ELSIF GWPKS_UTIL.PKG_FUNC IN ('8004') THEN
              IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY <>
                 P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY THEN
                IF NOT cypkss.fn_amt1_to_amt2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY,
                                              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                              'COMM',--depks_rtl_teller.PKG_PROD.RATE_TYPE_PREFERRED,
                                              'B',
                                              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT,
                                              'Y',
                                              l_txn_amt,
                                              l_rate,
                                              P_ERR_PARAM) THEN
                  debug.pr_debug('**', '');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code  := 'ST-OTHR-001';
                  P_ERR_PARAM := NULL;
                  RETURN FALSE;
                END IF;
              END IF;
            END IF;
            dbg('l_txn_amt->' || l_txn_amt);
            IF l_txn_amt >= 10000 THEN
              DBG('INSIDE  1');
              IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34 IS NULL OR
                 P_TY_RTUPLD.ty_cstbs_ui_columns.char_field35 IS NULL THEN
                DBG('Purpose of Transaction or Source of Funds should not be null if USD Amount >10K');
                OVPKSS.PR_APPENDTBL('DE-PRIN-003', null);
                RETURN FALSE;
              END IF;
            END IF;

          END IF;

        END IF;
      END IF;

      --Prince Bank AML Changes Ends

    --Transaction Amount should be multiples of 100 to avoid humman error and EODM Issue Starts
      IF GWPKS_UTIL.PKG_FUNC IN ('SCTT') AND P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY = 'KHR' THEN
        IF MOD(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT, 100) <> 0 THEN

          DBG('SCTT Amount Should be multiples of 100');
          OVPKSS.PR_APPENDTBL('DE-PRI-SC01', P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);
          RETURN FALSE;
        END IF;
      END IF;
      --Transaction Amount should be multiples of 100 to avoid humman error and EODM Issue Ends

    --NBC RFT changes Starts
      IF GWPKS_UTIL.PKG_FUNC IN ('RFTM') THEN

        IF GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH', 'SAVEAUTOAUTH') THEN

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD41') THEN
            DBG('RFT PASSCODE=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD41')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD41 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD41')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD42') THEN
            DBG('RFT MOBILE NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD42')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD42 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD42')
                                                            .TYP_VAR_VALUE;

            --Validate Phone Number

            IF NOT
                FN_MOBILE_VALIDATE(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD42) THEN

              DBG('Invalid Phone Number ');
              P_ERR_CODE := 'IF-RFT-003';
              RETURN FALSE;

            END IF;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD43') THEN
            DBG('RFT TRANSACTION CURRENCY=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD43')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD43 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD43')
                                                            .TYP_VAR_VALUE;

            IF P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD43 NOT IN
               ('USD', 'KHR') THEN

              DBG('Currency Should be KHR or USD');
              P_ERR_CODE := '';
              OVPKSS.PR_APPENDTBL('IF-RFT-009', null);
              RETURN FALSE;

            END IF;

            P_TY_RTUPLD.ty_upld_rtl_teller.OFS_CCY := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD43;

            P_TY_RTUPLD.ty_upld_rtl_teller.TXN_CCY := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD43;

            DBG('RFT OFFSET CURRENCY=' ||
                P_TY_RTUPLD.ty_upld_rtl_teller.OFS_CCY);

            DBG('RFT TRANSACTION CURRENCY=' ||
                P_TY_RTUPLD.ty_upld_rtl_teller.TXN_CCY);

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD44') THEN
            DBG('RFT RECEIVER NAME=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD44')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD44')
                                                            .TYP_VAR_VALUE;

            DBG('RFT RECEIVER NAME=' ||
                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44);

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD45') THEN
            DBG('RFT SENDER NAME=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD45')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD45')
                                                            .TYP_VAR_VALUE;

            DBG('RFT SENDER NAME=' ||
                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45);

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('NUM_FIELD25') THEN
            DBG('RFT TRANSACTION AMOUNT=' || P_TBL_NAME_VAL_PAIR('NUM_FIELD25')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.NUM_FIELD25 := P_TBL_NAME_VAL_PAIR('NUM_FIELD25')
                                                           .TYP_VAR_VALUE;

            P_TY_RTUPLD.ty_upld_rtl_teller.OFS_AMOUNT := P_TY_RTUPLD.ty_cstbs_ui_columns.NUM_FIELD25;

            DBG('RFT TRANSACTION AMOUNT=' ||
                P_TY_RTUPLD.ty_upld_rtl_teller.OFS_AMOUNT);

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD47') THEN
            DBG('RFT SENDER MOBILE NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD47')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD47 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD47')
                                                            .TYP_VAR_VALUE;

            --Validate Phone Number

            IF NOT
                FN_MOBILE_VALIDATE(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD47) THEN

              DBG('Invalid Phone Number ');
              P_ERR_CODE := 'IF-RFT-003';
              RETURN FALSE;

            END IF;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD46') THEN
            DBG('BEN BIC CODE=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD46')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD46')
                                                            .TYP_VAR_VALUE;

            BEGIN
              SELECT COUNT(1)
                INTO L_COUNT
                FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
               WHERE A.TYPE = B.TYPE
                 AND A.TYPE = 'RFT_MEMBERS'
                 AND A.RECORD_STAT = 'O'
                 AND A.AUTH_STAT = 'A'
                 AND B.CODE = P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46;
            EXCEPTION
              WHEN OTHERS THEN
                L_COUNT := 0;
            END;

            IF L_COUNT = 0 THEN

              DBG('BENEFICIARY BIC CODE IS NOT CORRECT');
              P_ERR_CODE := '';
              OVPKSS.PR_APPENDTBL('IF-RFT-022', null);
              RETURN FALSE;

            END IF;

          END IF;

          --check the count for not to call multiple times

          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF);

          DBG('GWPKS_UTIL.PKG_ACTTYPE=' || GWPKS_UTIL.PKG_ACTTYPE);

          IF GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
            --Insert ws call
            PR_INSERT_RFT_WS_LOG_RFTM(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF,
                                      GWPKS_UTIL.PKG_ACTTYPE,
                                      P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD41,
                                      P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD42,
                                      P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD43,
                                      P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.NUM_FIELD25,
                                      P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD44,
                                      P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD45,
                                      P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD47,
                                      P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD46);

            BEGIN
              SELECT COUNT(1)
                INTO L_COUNT
                FROM STTB_RFT_WS_LOG_RFTM
               WHERE ACTION = GWPKS_UTIL.PKG_ACTTYPE
                 AND XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
                 AND PASSCODE =
                     P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD41
                 AND BEN_PHONE =
                     P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD42
                 AND CCY = P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD43
                 AND TXN_AMT = P_TY_RTUPLD.ty_cstbs_ui_columns.NUM_FIELD25
                 AND REM_PHONE =
                     P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD47
                 AND BEN_BIC_CODE =
                     P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46;

            EXCEPTION
              WHEN OTHERS THEN
                L_COUNT := 0;
            END;

            DBG('L_COUNT=' || L_COUNT);

          END IF;

          /*IF GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN

            BEGIN
              SELECT COUNT(1)
                INTO L_COUNT
                FROM STTB_RFT_WS_LOG_RFTM
               WHERE ACTION = 'SAVEAUTOAUTH'
                 AND XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
                 AND PASSCODE =
                     P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD41
                 AND BEN_PHONE =
                     P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD42
                 AND CCY = P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD43
                 AND TXN_AMT = P_TY_RTUPLD.ty_cstbs_ui_columns.NUM_FIELD25
                 AND REM_PHONE =
                     P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD47
                 AND BEN_BIC_CODE =
                     P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46;

            EXCEPTION
              WHEN OTHERS THEN
                L_COUNT := 0;
            END;

            dbg('L_COUNT of SAVEAUTOAUTH=' || L_COUNT);

            IF L_COUNT = 0 THEN

              DBG('RESPONSE MESSAGE HAS ERRORS FOR NBC RFT PASSCODE CONFIRMATION');
              P_ERR_CODE     := '';
              L_RESPONSE_MSG := 'The requested passcode ' ||
                                P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD41 ||
                                ' and Sender Phone number ' ||
                                P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD47 ||
                                'is not exist';

              OVPKSS.PR_APPENDTBL('IF-RFT-010', L_RESPONSE_MSG);
              RETURN FALSE;

            END IF;

          END IF;*/

          IF L_COUNT = 1 AND GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN

            --Get Passcode Enquiry Message

            DBG('GWPKS_UTIL.G_MAKER_ID=' || GWPKS_UTIL.G_MAKERID);
            DBG('GWPKS_UTIL.G_CHECKERID=' || GWPKS_UTIL.G_CHECKERID);

            IF GWPKS_UTIL.G_MAKERID IS NOT NULL AND
               GWPKS_UTIL.G_CHECKERID IS NULL THEN

               --AML New Payment Flow Starts
              IF NOT
                  IFPKS_SANCTION_UTILS.FN_AML_PAYMENT_CALL_B(GLOBAL.user_id,
                                                             GLOBAL.current_branch,
                                                             'OTC',

                                                             L_REF,
                                                             P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45 || '|' ||
                                                             TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44), --Sen Name
                                                             'KH' || '|' || 'KH', --Sen Country,
                                                             'PINCKHPPXXX' || '|' ||
                                                             FN_GET_BEN_BANK_NAME(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46),
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL,
                                                             NULL,
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.narrative,
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.OFS_AMOUNT, --100,
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.TXN_CCY,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             'RFT',
                                                             'RFTD',
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL, --L_CUSTOMER.Customer_No,
                                                             P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45, --Sender Name
                                                             'KH', --Sender Country
                                                             P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44, --Ben Name
                                                             'KH', --Ben Country
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                                                             P_SCAN_ID,
                                                             P_HIT_STATUS,
                                                             L_IN_RESP) THEN

                DBG('FAILED IN FN_AML_PAYMENT_CALL_B');

                PR_LOG_ERROR('RFTM', 'FLEXCUBE', 'IF-AML-001', NULL);

                RETURN FALSE;

              ELSE

                --Get JSON in XML
                L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
                DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

                L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                     '&lt;',
                                                                     '<');
                DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' ||
                    L_RESP_IN_XML);

                L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                     '&gt;',
                                                                     '>');
                DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' ||
                    L_RESP_IN_XML);

                DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
                    L_RESP_IN_XML);

                P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

                P_HIT_STATUS := P_DOCUMENT_XML.EXTRACT('/root/RtnHit/text()')
                                .GETSTRINGVAL;

                P_SCAN_ID := P_DOCUMENT_XML.EXTRACT('/root/RtnScanID/text()')
                             .GETSTRINGVAL;

                DBG('P_HIT_STATUS OF API-B =' || P_HIT_STATUS);

                DBG('P_SCAN_ID OF API-B=' || P_SCAN_ID);

                IF P_HIT_STATUS = 'X' THEN

                  DBG('INSIDE IF CONFITION');

                  PR_LOG_ERROR('IFDRIAFT',
                               'FLEXCUBE',
                               'IF-RFT-030',
                               P_SCAN_ID);

                  --OVPKSS.PR_APPENDTBL('IF-RIA-030',
                  --                          P_SCAN_ID);

                  RETURN FALSE; --AUTO REJECT

                ELSIF P_HIT_STATUS = 'Y' THEN

                  DBG('INSIDE ELSE CONFITION');

                  PR_LOG_ERROR('IFDRIAFT',
                               'FLEXCUBE',
                               'IF-RIA-030',
                               P_SCAN_ID);

                END IF;

              END IF;
              --AML New Payment Flow Ends

              L_FORMATTED_MSG := FN_RETURN_FORMATTED_PASSCD_ENQ(P_TY_RTUPLD);

              DBG('AFTER REPLACEMENT OF RFT OUT PASSCODE ENQUIRY MSG=' ||
                  L_FORMATTED_MSG);

              DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

              DBG('CALLING PASSCODE ENQUIRY WEBSERVICE');

              --L_RFT_CALL := 'PI';

              IF P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46 = '096' THEN

                L_RFT_CALL := 'PTOWN';

              ELSE

                L_RFT_CALL := 'PTOTH';

              END IF;

              IF NOT
                  FN_RFT_HTTP_CALL(L_RFT_CALL, L_FORMATTED_MSG, L_IN_RESP) THEN
                DBG('FAILED TO INVOKE PASSCODE ENQUIRY CALL TO RFT');
                P_ERR_CODE := '';
                OVPKSS.PR_APPENDTBL('IF-RFT-011', null);
                RETURN FALSE;
              END IF;

              DBG('Sent and response in json is ' || L_IN_RESP);

              --Get JSON in XML
              L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
              DEBUG.PR_DEBUG('IF', 'L_RESP_IN_XML=' || L_RESP_IN_XML);

              L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
              DBG('One step done-->' || L_RESP_IN_XML);

              L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
              DBG('Two step done and after UNESCAPE, it is ' ||
                  L_RESP_IN_XML);

              DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS ' ||
                  L_RESP_IN_XML);

              P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

              L_RESPONSE_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                                 .GETSTRINGVAL;

              DBG('L_RESPONSE_CODE=' || L_RESPONSE_CODE);

              L_RESPONSE_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                                .GETSTRINGVAL;

              DBG('L_RESPONSE_MSG= ' || L_RESPONSE_MSG);

              L_DATA := P_DOCUMENT_XML.EXTRACT('/root/data/cbsReq/text()')
                        .GETSTRINGVAL;

              DBG('L_DATA=' || L_DATA);

              L_WAIT_KEY := P_DOCUMENT_XML.EXTRACT('/root/data/waitKey/text()')
                            .GETSTRINGVAL;

              DBG('L_WAIT_KEY= ' || L_WAIT_KEY);

            ELSIF GWPKS_UTIL.G_CHECKERID IS NOT NULL AND
                  GWPKS_UTIL.G_MAKERID <> GWPKS_UTIL.G_CHECKERID THEN

                    --AML New Payment Flow Starts
          IF
               GWPKS_UTIL.G_MAKERID IS NOT NULL AND
               GWPKS_UTIL.G_CHECKERID IS NOT NULL THEN

          DBG('Inside Auth...');

                BEGIN
                  SELECT *
                    INTO L_STTB_CORAL_RIA_WS_LOG
                    FROM STTB_CORAL_RFT_WS_LOG A
                   WHERE A.UNIQUE_REFERENCE_NO IN
                         (SELECT MAX(UNIQUE_REFERENCE_NO)
                            FROM STTB_CORAL_RFT_WS_LOG A
                           WHERE A.FC_REF_NO =
                                 P_TY_RTUPLD.ty_upld_rtl_teller.XREF
                                --AND STATUS IN ('HIT', 'NO HIT')  --AML New Payment Flow Changes
                                --AND ACTION = 'DOSCAN_AUTH' --AML New Payment Flow Changes
                             AND REQ_TYPE = 'ONLINE_SCAN'
                             AND ACTION IN
                                 ('DOSCAN_AUTH_A', 'DOSCAN_AUTH_B')) --AML New Payment Flow Changes

                     AND FC_REF_NO = P_TY_RTUPLD.ty_upld_rtl_teller.XREF
                     AND STATUS IN ('Y'); --AML New Payment Flow Changes
                EXCEPTION

                  WHEN OTHERS THEN

                    DBG('FAILED IN GETTING THE RECORD');
                    DBG('ERROR CODE IN GETTING THE RECORD=' || SQLCODE);
                    DBG('ERROR MESSAGE IN GETTING THE RECORD=' || SQLERRM);

                    L_STTB_CORAL_RIA_WS_LOG := NULL;

                END;

                DBG('L_STTB_CORAL_RIA_WS_LOG.SCAN_ID='||L_STTB_CORAL_RIA_WS_LOG.SCAN_ID);

                --check status for scan id
                IF L_STTB_CORAL_RIA_WS_LOG.SCAN_ID IS NOT NULL THEN
                  /*IF NOT
                      IFPKS_SANCTION_UTILS.FN_GET_AML_STATUS_RIA_OUT(L_STTB_CORAL_RIA_WS_LOG.SCAN_ID,
                                                                     L_STTB_CORAL_RIA_WS_LOG.CUSTOMER_NO,
                                                                     L_STTB_CORAL_RIA_WS_LOG.FC_REF_NO,
                                                                     p_Err_Code,
                                                                     P_ERR_PARAM) THEN

                    RETURN FALSE;

                  END IF;*/

                  DBG('Calling AML Payment Status API');

                  --AML New Payment Flow Starts
                  IF NOT
                      IFPKS_SANCTION_UTILS.FN_GET_AML_PAYMENT_STATUS('OTC',
                                                                     L_STTB_CORAL_RIA_WS_LOG.UNIQUE_REFERENCE_NO,
                                                                     L_STTB_CORAL_RIA_WS_LOG.SCAN_ID,
                                                                     L_STTB_CORAL_RIA_WS_LOG.CUSTOMER_NO,
                                                                     L_STTB_CORAL_RIA_WS_LOG.FC_REF_NO,
                                                                     'RFT',
                                                                     'RFTD',
                                                                     L_RESP_IN_XML) THEN

                    RETURN FALSE;

                  ELSE

                    DBG('SUCCESS IN GETTING AML STATUS');

                    --Get JSON in XML
                    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_RESP_IN_XML);
                    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

                    L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                         '&lt;',
                                                                         '<');
                    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' ||
                        L_RESP_IN_XML);

                    L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                         '&gt;',
                                                                         '>');
                    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' ||
                        L_RESP_IN_XML);

                    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
                        L_RESP_IN_XML);

                    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

                    P_HIT_STATUS := P_DOCUMENT_XML.EXTRACT('/root/RtnResult/text()')
                                    .GETSTRINGVAL;

                    DBG('P_HIT_STATUS=' || P_HIT_STATUS);

                    IF P_HIT_STATUS IN ('R', 'REJECTED') THEN
                      P_ERR_CODE := 'ST-PRIN-010';
                      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                      RETURN FALSE;
                    END IF;

                    IF P_HIT_STATUS IN ('P', 'PENDING') THEN
                      P_ERR_CODE := 'ST-PRIN-011';
                      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                      RETURN FALSE;
                    END IF;

                  END IF;
                  --AML New Payment Flow Ends

                END IF;

              END IF;
          --AML New Payment Flow Ends


              L_FORMATTED_MSG := FN_RETURN_FMT_PASSCD_ENQ_OVD(P_TY_RTUPLD);

              DBG('AFTER REPLACEMENT OF RFT OUT PASSCODE ENQUIRY MSG=' ||
                  L_FORMATTED_MSG);

              DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

              DBG('CALLING PASSCODE ENQUIRY WEBSERVICE');

              --L_RFT_CALL := 'PI';

              IF P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46 = '096' THEN

                L_RFT_CALL := 'PTOWN';

              ELSE

                L_RFT_CALL := 'PTOTH';

              END IF;

              IF NOT
                  FN_RFT_HTTP_CALL(L_RFT_CALL, L_FORMATTED_MSG, L_IN_RESP) THEN
                DBG('FAILED TO INVOKE PASSCODE ENQUIRY CALL TO RFT');
                P_ERR_CODE := '';
                OVPKSS.PR_APPENDTBL('IF-RFT-011', null);
                RETURN FALSE;
              END IF;

              DBG('Sent and response in json is ' || L_IN_RESP);

              --Get JSON in XML
              L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
              DEBUG.PR_DEBUG('IF', 'L_RESP_IN_XML=' || L_RESP_IN_XML);

              L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
              DBG('One step done-->' || L_RESP_IN_XML);

              L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
              DBG('Two step done and after UNESCAPE, it is ' ||
                  L_RESP_IN_XML);

              DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS ' ||
                  L_RESP_IN_XML);

              P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

              L_RESPONSE_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                                 .GETSTRINGVAL;

              DBG('L_RESPONSE_CODE=' || L_RESPONSE_CODE);

              L_RESPONSE_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                                .GETSTRINGVAL;

              DBG('L_RESPONSE_MSG= ' || L_RESPONSE_MSG);

            END IF;

            IF L_RESPONSE_CODE = 'SUCCESS' AND L_DATA = 'RCV' THEN

              PR_UPDATE_RFT_WS_LOG_RFTM(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF,
                                        P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD41,
                                        L_DATA,
                                        L_WAIT_KEY);

            ELSIF L_RESPONSE_CODE = 'SUCCESS' AND
                  L_RESPONSE_MSG = 'Normal Complete.' THEN

              dbg('SUCCESS');

            ELSIF L_RESPONSE_CODE = 'ERROR_104' THEN

              DBG('ERROR IN RFT PASSCODE CONFIRMATION');
              -- P_ERR_CODE := '';
              --OVPKSS.PR_APPENDTBL('IF-RFT-010', L_RESPONSE_MSG);
              --RETURN FALSE;

              p_err_code  := 'IF-RFT-010';
              P_ERR_PARAM := L_RESPONSE_MSG;
              RETURN FALSE;

            ELSIF L_RESPONSE_CODE = 'SUCCESS_999' THEN

              DBG('RFT PASSCODE HAS BEEN EXPIRED');
              P_ERR_CODE := '';
              OVPKSS.PR_APPENDTBL('IF-RFT-025', L_RESPONSE_MSG);
              RETURN FALSE;

            ELSIF L_RESPONSE_CODE = 'SUCCESS_998' THEN

              DBG('RFT PASSCODE HAS BEEN CANCELLED');
              P_ERR_CODE := '';
              OVPKSS.PR_APPENDTBL('IF-RFT-024', L_RESPONSE_MSG);
              RETURN FALSE;

            ELSE

              DBG('ERROR IN RFT PASSCODE CONFIRMATION');

              --P_ERR_CODE := '';
              --OVPKSS.PR_APPENDTBL('IF-RFT-010', L_RESPONSE_MSG);
              --RETURN FALSE;

              p_err_code  := 'IF-RFT-010';
              P_ERR_PARAM := L_RESPONSE_MSG;
              RETURN FALSE;

            END IF;

          END IF;

          /*IF L_COUNT = 0 AND GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH') THEN

            --Get Passcode Enquiry Message

            L_FORMATTED_MSG := FN_RETURN_FORMATTED_PASSCD_ENQ(P_TY_RTUPLD);

            DBG('AFTER REPLACEMENT OF RFT OUT PASSCODE ENQUIRY MSG=' ||
                L_FORMATTED_MSG);

            DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

            DBG('CALLING PASSCODE ENQUIRY WEBSERVICE');

            L_RFT_CALL := 'PI';

            IF NOT FN_RFT_HTTP_CALL(L_RFT_CALL, L_FORMATTED_MSG, L_IN_RESP) THEN
              DBG('FAILED TO INVOKE PASSCODE ENQUIRY CALL TO RFT');
              P_ERR_CODE := '';
              OVPKSS.PR_APPENDTBL('IF-RFT-011', null);
              RETURN FALSE;
            END IF;

            DBG('Sent and response in json is ' || L_IN_RESP);

            --Get JSON in XML
            L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
            DEBUG.PR_DEBUG('IF', 'L_RESP_IN_XML=' || L_RESP_IN_XML);

            L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
            DBG('One step done-->' || L_RESP_IN_XML);
            L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
            DBG('Two step done and after UNESCAPE, it is ' ||
                L_RESP_IN_XML);

            DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS ' ||
                L_RESP_IN_XML);

            P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

            L_RESPONSE_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                               .GETSTRINGVAL;

            DBG('L_RESPONSE_CODE=' || L_RESPONSE_CODE);

            L_RESPONSE_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                              .GETSTRINGVAL;

            DBG('L_RESPONSE_MSG= ' || L_RESPONSE_MSG);

            IF L_RESPONSE_CODE = 'SUCCESS' THEN

              L_BANKCODE := P_DOCUMENT_XML.EXTRACT('/root/data//bankTp/text()')
                            .GETSTRINGVAL;

              DBG('L_BANKCODE=' || L_BANKCODE);

              --L_TXNUNIQUE_NO := P_DOCUMENT_XML.EXTRACT('/root/data/txnUnqNo/text()')
              --                 .GETSTRINGVAL;

              -- DBG('L_TXNUNIQUE_NO=' || L_TXNUNIQUE_NO);

              --L_TRACE_NO := P_DOCUMENT_XML.EXTRACT('/root/data/tracNo/text()')
              --              .GETSTRINGVAL;

              --DBG('L_TRACE_NO=' || L_TRACE_NO);

              IF L_BANKCODE = 'PRINCE' THEN

                L_RFT_CALL := 'PTOWN';

              ELSE

                L_RFT_CALL := 'PTOTH';

              END IF;

              DBG('CALLING PASSCODE TRANSFER WEBSERVICE');

              IF NOT
                  FN_RFT_HTTP_CALL(L_RFT_CALL, L_FORMATTED_MSG, L_IN_RESP) THEN
                DBG('FAILED TO INVOKE PASSCODE TRANSFER CALL TO RFT');
                P_ERR_CODE := '';
                OVPKSS.PR_APPENDTBL('IF-RFT-011', null);
                RETURN FALSE;

              ELSE

                DBG('Sent and response in json is ' || L_IN_RESP);

                --Get JSON in XML
                L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);

                DEBUG.PR_DEBUG('IF', 'L_RESP_IN_XML=' || L_RESP_IN_XML);

                L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');

                DBG('One step done-->' || L_RESP_IN_XML);

                L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');

                DBG('Two step done and after UNESCAPE, it is ' ||
                    L_RESP_IN_XML);

                DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS ' ||
                    L_RESP_IN_XML);

                P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

                L_RESPONSE_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                                   .GETSTRINGVAL;

                DBG('L_RESPONSE_CODE=' || L_RESPONSE_CODE);

                L_RESPONSE_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                                  .GETSTRINGVAL;

                DBG('L_RESPONSE_MSG= ' || L_RESPONSE_MSG);

                IF L_RESPONSE_CODE = 'SUCCESS' THEN

                  L_RESPONSE_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                                    .GETSTRINGVAL;

                  DBG('L_RESPONSE_MSG=' || L_RESPONSE_MSG);

                  L_TXNUNIQUE_NO := P_DOCUMENT_XML.EXTRACT('/root/data/txnUnqNo/text()')
                                    .GETSTRINGVAL;

                  DBG('L_TXNUNIQUE_NO=' || L_TXNUNIQUE_NO);

                  L_TRACE_NO := P_DOCUMENT_XML.EXTRACT('/root/data/tracNo/text()')
                                .GETSTRINGVAL;

                  DBG('L_TRACE_NO=' || L_TRACE_NO);

                  --Insert ws call
                  PR_INSERT_RFT_WS_LOG_RFTM(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF,
                                            GWPKS_UTIL.PKG_ACTTYPE,
                                            P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD41,
                                            P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD42,
                                            P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD43,
                                            P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.NUM_FIELD25,
                                            P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD44,
                                            P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.NUM_FIELD24,
                                            P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD45);

                ELSE

                  DBG('RESPONSE MESSAGE HAS ERRORS FOR NBC RFT PASSCODE CONFIRMATION');
                  P_ERR_CODE := '';
                  OVPKSS.PR_APPENDTBL('IF-RFT-010', L_RESPONSE_MSG);
                  RETURN FALSE;

                END IF;

              END IF;

            ELSE

              DBG('RESPONSE MESSAGE HAS ERRORS FOR NBC RFT PASSCODE ENQUIRY');
              P_ERR_CODE := '';
              OVPKSS.PR_APPENDTBL('IF-RFT-010', L_RESPONSE_MSG);
              RETURN FALSE;

            END IF;

            DBG('fn_msg_upload successful');

          END IF;*/

        END IF;

        DBG('fn_msg_upload successful');

      END IF;
      --NBC RFT changes Ends

    --AIA Payment Starts

      IF GWPKS_UTIL.PKG_FUNC IN ('AIAC') THEN

        IF GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH', 'SAVEAUTOAUTH') THEN

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD3') THEN
            DBG('AIA POLICY NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD3 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD4') THEN
            DBG('AIA CLIENT NAME=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD4')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD4 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD4')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD5') THEN
            DBG('AIA EMAIL ID=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD5')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD5 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD5')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD6') THEN
            DBG('AIA MOBILE NO=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD6')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD6 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD6')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD8') THEN
            DBG('AIA PREMIUM ADJUSTABLE=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD8')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD8 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD8')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD7') THEN
            DBG('AIA PAYMENT DUE DATE=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD7')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD7 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD7')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD9') THEN
            DBG('AIA PAYMENT AMOUNT=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD9')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD9 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD9')
                                                           .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD10') THEN
            DBG('AIA PAYMENT CURRENCY=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD10')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD10 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD10')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD11') THEN
            DBG('AIA TRANASACTION UNIQUE NO=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD11')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD11 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD11')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
            IF P_TBL_NAME_VAL_PAIR('CHAR_FIELD11').TYP_VAR_VALUE IS NULL THEN

              DBG('Please click on pikcup button');
              P_ERR_CODE := 'IF-AIA-007';
              RETURN FALSE;

            END IF;
          END IF;

          /*  P_TBL_NAME_VAL_PAIR('TXNACC').TYP_VAR_VALUE := '000030693';

          IF P_TBL_NAME_VAL_PAIR.EXISTS('TXNACC') THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC := P_TBL_NAME_VAL_PAIR('TXNACC')
                                                      .TYP_VAR_VALUE;
          END IF;

          DBG('[txn_acc]=>' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);

          Depks_RetailTellerUpload.g_ui_txn_acc := '000030693';

          P_TBL_NAME_VAL_PAIR('ACCTITLE1').TYP_VAR_VALUE := 'CUSTOMER_00005756';

          IF P_TBL_NAME_VAL_PAIR.EXISTS('ACCTITLE1') THEN
            DEPKSS_RETAILTELLERUPLOAD.G_ACCTITLE1 := P_TBL_NAME_VAL_PAIR('ACCTITLE1')
                                                     .TYP_VAR_VALUE;
          END IF;
          DBG('[ACCTITLE1 stored in global]=>' ||
              DEPKSS_RETAILTELLERUPLOAD.G_ACCTITLE1);

          DEPKSS_RETAILTELLERUPLOAD.G_ACCTITLE1 := P_TBL_NAME_VAL_PAIR('ACCTITLE1')
                                                   .TYP_VAR_VALUE;

          P_TBL_NAME_VAL_PAIR('TXNCCY').TYP_VAR_VALUE := 'USD';

          IF P_TBL_NAME_VAL_PAIR.EXISTS('TXNCCY') THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := P_TBL_NAME_VAL_PAIR('TXNCCY')
                                                      .TYP_VAR_VALUE;
          END IF;
          DBG('[txn_ccy]=>' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);*/

          --P_TBL_NAME_VAL_PAIR('TXNBRN').TYP_VAR_VALUE := '012';
          IF P_TBL_NAME_VAL_PAIR.EXISTS('TXNBRN') THEN
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH := P_TBL_NAME_VAL_PAIR('TXNBRN')
                                                         .TYP_VAR_VALUE;
          END IF;
          DBG('[txn_branch]=>' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH);

          IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY <>
             P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY THEN

            DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY);
            DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);
            DBG('l_rate=' || l_rate);
            DBG('depks_rtl_teller.pkg_prod.rate_code_preferred=' ||
                depks_rtl_teller.pkg_prod.rate_code_preferred);

            /*--Get Rate AML Participant Changes
            IF NOT CYPKSS.FN_GETRATE(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                     P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY, --KHR currency coming in switch
                                     P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY, --USD account ccy
                                     'COMM',
                                     depks_rtl_teller.pkg_prod.rate_code_preferred,
                                     P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT,
                                     P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT,
                                     l_rate,
                                     L_RATE_FLAG,
                                     P_ERR_CODE) THEN
              RETURN FALSE;
            END IF;*/

            IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY = GLOBAL.LCY THEN
              IF NOT cypkss.fn_amt1_to_amt2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                            GLOBAL.LCY,
                                            'COMM', --depks_rtl_teller.PKG_PROD.RATE_TYPE_PREFERRED,
                                            'B',
                                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                            'Y',
                                            l_txn_amt,
                                            l_rate,
                                            P_ERR_PARAM) THEN
                debug.pr_debug('**', '');
                debug.pr_debug('**', SQLERRM);
                p_err_code  := 'ST-OTHR-001';
                P_ERR_PARAM := NULL;
                RETURN FALSE;
              END IF;
            ELSE
              DBG('i am inside Buy Rate');
              IF NOT cypkss.fn_amt1_to_amt2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY,
                                            'COMM', --depks_rtl_teller.PKG_PROD.RATE_TYPE_PREFERRED,
                                            'B',
                                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                            'Y',
                                            l_txn_amt,
                                            l_rate,
                                            P_ERR_PARAM) THEN
                debug.pr_debug('**', '');
                debug.pr_debug('**', SQLERRM);
                p_err_code  := 'ST-OTHR-001';
                P_ERR_PARAM := NULL;
                RETURN FALSE;
              END IF;
            END IF;

            dbg('l_txn_amt->' || l_txn_amt);

          ELSE

            IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                          GLOBAL.lcy,
                                          'STANDARD',
                                          'M',
                                          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                          'Y',
                                          l_txn_amt,
                                          l_rate,
                                          P_ERR_CODE) THEN
              RETURN FALSE;
            END IF;

            -- l_txn_amt := P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT;
          END IF;

          dbg('l_txn_amt->' || l_txn_amt);

          DBG('GWPKS_UTIL.PKG_ACTTYPE=' || GWPKS_UTIL.PKG_ACTTYPE);

          P_TY_RTUPLD.ty_cstbs_ui_columns.NUM_FIELD14 := l_txn_amt;

          IF GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH') THEN

            --Get AIA Account Enquiry
            L_FORMATTED_MSG := FN_GET_FMT_AIA_POLICY_ENQ(P_TY_RTUPLD);

            DBG('AFTER REPLACEMENT OF AIA ACC ENQUIRY JSON=' ||
                L_FORMATTED_MSG);

            DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

            DBG('CALLING AIA ACCOUNT ENQUIRY WEBSERVICE');

            IF NOT FN_MSG_UPLOAD(P_TY_RTUPLD,
                                 'I',
                                 L_FORMATTED_MSG,
                                 'Account Enquiry Call',
                                 P_ERR_CODE,
                                 P_ERR_PARAM) THEN

              DBG('FAILED IN ACCOUNT ENQUIRY CALL');

              RETURN FALSE;

            ELSE

              DBG('SUCCESS IN ACCOUNT ENQUIRY CALL');

            END IF;

          END IF;

          DBG('GWPKS_UTIL.G_MAKER_ID=' || GWPKS_UTIL.G_MAKERID);
          DBG('GWPKS_UTIL.G_CHECKERID=' || GWPKS_UTIL.G_CHECKERID);

          IF GWPKS_UTIL.G_MAKERID IS NOT NULL AND
             GWPKS_UTIL.G_CHECKERID IS NOT NULL AND
             GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') AND
             P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD3 IS NOT NULL AND --POLICY NO
             P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD11 IS NOT NULL THEN
            --TXN_UNIQUE_NO
            --AIA PAYMENT ID

            --Get AIA CONFIRM PAYMENT
            L_FORMATTED_MSG := FN_GET_FMT_AIA_PAYMENT(P_TY_RTUPLD);

            DBG('AFTER REPLACEMENT OF AIA PAYMENT JSON=' ||
                L_FORMATTED_MSG);

            DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

            DBG('CALLING AIA PAYMENT WEBSERVICE');

            IF NOT FN_MSG_UPLOAD(P_TY_RTUPLD,
                                 'C',
                                 L_FORMATTED_MSG,
                                 'Payment Confirmation Call',
                                 P_ERR_CODE,
                                 P_ERR_PARAM) THEN

              DBG('FAILED IN AIA PAYMENT CALL');

              RETURN FALSE;

            ELSE

              DBG('SUCCESS IN AIA PAYMENT CALL');

            END IF;

          END IF;

        END IF;
      END IF;
      --AIA Payment Ends

    --RIA Phase2 Changes Starts

    --RIA Cashwithdrawal Remittance Starts

      IF GWPKS_UTIL.PKG_FUNC IN ('RIAC') THEN

        IF GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH', 'SAVEAUTOAUTH') THEN

          IF P_TBL_NAME_VAL_PAIR.EXISTS('RIA_PIN') THEN
            DBG('RIA PIN=' || P_TBL_NAME_VAL_PAIR('RIA_PIN').TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field70 := P_TBL_NAME_VAL_PAIR('RIA_PIN')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('RIA_AMOUNT') THEN
            DBG('RIA RIA_AMOUNT=' || P_TBL_NAME_VAL_PAIR('RIA_AMOUNT')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.num_field11 := P_TBL_NAME_VAL_PAIR('RIA_AMOUNT')
                                                           .TYP_VAR_VALUE;

            DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.num_field11=' ||
                P_TY_RTUPLD.ty_cstbs_ui_columns.num_field11);

            P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT := P_TY_RTUPLD.ty_cstbs_ui_columns.num_field11;

            DBG('RIA TRANSACTION AMOUNT=' ||
                P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT);

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('TXN_UNIQUE_NO') THEN
            DBG('RIA TXN_UNIQUE_NO=' || P_TBL_NAME_VAL_PAIR('TXN_UNIQUE_NO')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD71 := P_TBL_NAME_VAL_PAIR('TXN_UNIQUE_NO')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('RIA_REFERENCE_NO') THEN
            DBG('RIA RIA_REFERENCE_NO=' || P_TBL_NAME_VAL_PAIR('RIA_REFERENCE_NO')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field72 := P_TBL_NAME_VAL_PAIR('RIA_REFERENCE_NO')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('ORDER_NO') THEN
            DBG('RIA ORDER_NO=' || P_TBL_NAME_VAL_PAIR('ORDER_NO')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field73 := P_TBL_NAME_VAL_PAIR('ORDER_NO')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('CURRENCY') THEN
            DBG('RIA CURRENCY=' || P_TBL_NAME_VAL_PAIR('CURRENCY')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field74 := P_TBL_NAME_VAL_PAIR('CURRENCY')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('ORDER_DATE') THEN
            DBG('RIA ORDER_DATE=' || P_TBL_NAME_VAL_PAIR('ORDER_DATE')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field75 := P_TBL_NAME_VAL_PAIR('ORDER_DATE')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('SENDER_FIRST_NAME') THEN
            DBG('RIA SENDER_FIRST_NAME=' || P_TBL_NAME_VAL_PAIR('SENDER_FIRST_NAME')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field98 := P_TBL_NAME_VAL_PAIR('SENDER_FIRST_NAME')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('SENDER_LAST_NAME') THEN
            DBG('RIA SENDER_LAST_NAME=' || P_TBL_NAME_VAL_PAIR('SENDER_LAST_NAME')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field99 := P_TBL_NAME_VAL_PAIR('SENDER_LAST_NAME')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('SENDER_COUNTRY') THEN
            DBG('RIA SENDER_COUNTRY=' || P_TBL_NAME_VAL_PAIR('SENDER_COUNTRY')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field88 := P_TBL_NAME_VAL_PAIR('SENDER_COUNTRY')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('SENDER_NATIONALITY') THEN
            DBG('RIA SENDER_NATIONALITY=' || P_TBL_NAME_VAL_PAIR('SENDER_NATIONALITY')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field100 := P_TBL_NAME_VAL_PAIR('SENDER_NATIONALITY')
                                                             .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('TXN_REMARKS') THEN
            DBG('RIA TXN_REMARKS=' || P_TBL_NAME_VAL_PAIR('TXN_REMARKS')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field76 := P_TBL_NAME_VAL_PAIR('TXN_REMARKS')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('REFERENCE_NO') THEN
            DBG('RIA REFERENCE_NO=' || P_TBL_NAME_VAL_PAIR('REFERENCE_NO')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field77 := P_TBL_NAME_VAL_PAIR('REFERENCE_NO')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('COMM_CURRENCY') THEN
            DBG('RIA COMM_CURRENCY=' || P_TBL_NAME_VAL_PAIR('COMM_CURRENCY')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field78 := P_TBL_NAME_VAL_PAIR('COMM_CURRENCY')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('COMM_AMOUNT') THEN
            DBG('RIA COMM_AMOUNT=' || P_TBL_NAME_VAL_PAIR('COMM_AMOUNT')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field79 := P_TBL_NAME_VAL_PAIR('COMM_AMOUNT')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('UNIQUE_ID_NAME') THEN
            DBG('RIA UNIQUE_ID_NAME=' || P_TBL_NAME_VAL_PAIR('UNIQUE_ID_NAME')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field80 := P_TBL_NAME_VAL_PAIR('UNIQUE_ID_NAME')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('UNIQUE_ID_VALUE') THEN
            DBG('RIA UNIQUE_ID_VALUE=' || P_TBL_NAME_VAL_PAIR('UNIQUE_ID_VALUE')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field81 := P_TBL_NAME_VAL_PAIR('UNIQUE_ID_VALUE')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('UID_EXPIRY_DATE') THEN
            DBG('RIA UID_EXPIRY_DATE=' || P_TBL_NAME_VAL_PAIR('UID_EXPIRY_DATE')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field82 := P_TBL_NAME_VAL_PAIR('UID_EXPIRY_DATE')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('UID_ISSUED_COUNTRY') THEN
            DBG('RIA UID_ISSUED_COUNTRY=' || P_TBL_NAME_VAL_PAIR('UID_ISSUED_COUNTRY')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field83 := P_TBL_NAME_VAL_PAIR('UID_ISSUED_COUNTRY')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('PRINCE_CUSTOMER') THEN
            DBG('RIA PRINCE_CUSTOMER=' || P_TBL_NAME_VAL_PAIR('PRINCE_CUSTOMER')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field84 := P_TBL_NAME_VAL_PAIR('PRINCE_CUSTOMER')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('BENEF_NAME') THEN
            DBG('RIA BENEF_NAME=' || P_TBL_NAME_VAL_PAIR('BENEF_NAME')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field85 := P_TBL_NAME_VAL_PAIR('BENEF_NAME')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('BENEF_ADDRESS') THEN
            DBG('RIA BENEF_ADDRESS=' || P_TBL_NAME_VAL_PAIR('BENEF_ADDRESS')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field86 := P_TBL_NAME_VAL_PAIR('BENEF_ADDRESS')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('BENEF_CITY') THEN
            DBG('RIA BENEF_CITY=' || P_TBL_NAME_VAL_PAIR('BENEF_CITY')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field87 := P_TBL_NAME_VAL_PAIR('BENEF_CITY')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('BENEF_BIRTH_COUNTRY') THEN
            DBG('RIA BENEF_BIRTH_COUNTRY=' || P_TBL_NAME_VAL_PAIR('BENEF_BIRTH_COUNTRY')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD89 := P_TBL_NAME_VAL_PAIR('BENEF_BIRTH_COUNTRY')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('BENEF_NATIONALITY') THEN
            DBG('RIA BENEF_NATIONALITY=' || P_TBL_NAME_VAL_PAIR('BENEF_NATIONALITY')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD90 := P_TBL_NAME_VAL_PAIR('BENEF_NATIONALITY')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('BENEF_PROVINCE') THEN
            DBG('RIA BENEF_PROVINCE=' || P_TBL_NAME_VAL_PAIR('BENEF_PROVINCE')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD92 := P_TBL_NAME_VAL_PAIR('BENEF_PROVINCE')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('BENEF_DISTRICT') THEN
            DBG('RIA BENEF_DISTRICT=' || P_TBL_NAME_VAL_PAIR('BENEF_DISTRICT')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD93 := P_TBL_NAME_VAL_PAIR('BENEF_DISTRICT')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('BENEF_VILLAGE_COMM') THEN
            DBG('RIA BENEF_VILLAGE_COMM=' || P_TBL_NAME_VAL_PAIR('BENEF_VILLAGE_COMM')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD94 := P_TBL_NAME_VAL_PAIR('BENEF_VILLAGE_COMM')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('BENEF_ADDR_4') THEN
            DBG('RIA BENEF_ADDR_4=' || P_TBL_NAME_VAL_PAIR('BENEF_ADDR_4')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD95 := P_TBL_NAME_VAL_PAIR('BENEF_ADDR_4')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('BENEF_ADDR_COUNTRY') THEN
            DBG('RIA BENEF_ADDR_COUNTRY=' || P_TBL_NAME_VAL_PAIR('BENEF_ADDR_COUNTRY')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD96 := P_TBL_NAME_VAL_PAIR('BENEF_ADDR_COUNTRY')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF P_TBL_NAME_VAL_PAIR.EXISTS('BENEF_OCCUPATION') THEN
            DBG('RIA BENEF_OCCUPATION=' || P_TBL_NAME_VAL_PAIR('BENEF_OCCUPATION')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD97 := P_TBL_NAME_VAL_PAIR('BENEF_OCCUPATION')
                                                            .TYP_VAR_VALUE;

          END IF;

          IF GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN

            -- IF P_TBL_NAME_VAL_PAIR('CHAR_FIELD72').TYP_VAR_VALUE IS NULL THEN
            IF P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD72 IS NULL THEN
              DBG('Please click on pikcup button');
            --  P_ERR_CODE := 'IF-RIA-007';
            --  RETURN FALSE;

            END IF;

            IF P_TBL_NAME_VAL_PAIR('UID_EXPIRY_DATE').TYP_VAR_VALUE IS NULL THEN

              DBG('BENEFICIARY UNIQUE ID EXPIRY DATE SHOULD NOT BE NULL');

              P_ERR_CODE := 'IF-RIA-027';

              RETURN FALSE;

            END IF;

            IF P_TBL_NAME_VAL_PAIR('UID_ISSUED_COUNTRY')
             .TYP_VAR_VALUE IS NULL THEN

              DBG('BENEFICIARY UNIQUE ID ISSUED COUNTRY SHOULD NOT BE NULL');

              P_ERR_CODE := 'IF-RIA-026';

              RETURN FALSE;

            END IF;

            IF P_TBL_NAME_VAL_PAIR('BENEF_BIRTH_COUNTRY')
             .TYP_VAR_VALUE IS NULL THEN

              DBG('BENEFICIARY BIRTH COUNTRY SHOULD NOT BE NULL');

              P_ERR_CODE := 'IF-RIA-018';

              RETURN FALSE;

            END IF;

            IF P_TBL_NAME_VAL_PAIR('BENEF_NATIONALITY')
             .TYP_VAR_VALUE IS NULL THEN

              DBG('BENEFICIARY NATIONALITY SHOULD NOT BE NULL');

              P_ERR_CODE := 'IF-RIA-019';

              RETURN FALSE;

            END IF;

            IF P_TBL_NAME_VAL_PAIR('BENEF_PROVINCE').TYP_VAR_VALUE IS NULL THEN

              DBG('BENEFICIARY PROVINCE SHOULD NOT BE NULL');

              P_ERR_CODE := 'IF-RIA-020';

              RETURN FALSE;

            END IF;

            IF P_TBL_NAME_VAL_PAIR('BENEF_DISTRICT').TYP_VAR_VALUE IS NULL THEN

              DBG('BENEFICIARY DISTRICT SHOULD NOT BE NULL');

              P_ERR_CODE := 'IF-RIA-021';

              RETURN FALSE;

            END IF;

            IF P_TBL_NAME_VAL_PAIR('BENEF_VILLAGE_COMM')
             .TYP_VAR_VALUE IS NULL THEN

              DBG('BENEFICIARY VILLAGE/COMMUNE SHOULD NOT BE NULL');

              P_ERR_CODE := 'IF-RIA-022';

              RETURN FALSE;

            END IF;

            IF P_TBL_NAME_VAL_PAIR('BENEF_ADDR_4').TYP_VAR_VALUE IS NULL THEN

              DBG('BENEFICIARY ADDRESS4 SHOULD NOT BE NULL');

              P_ERR_CODE := 'IF-RIA-023';

              RETURN FALSE;

            END IF;

            IF P_TBL_NAME_VAL_PAIR('BENEF_ADDR_COUNTRY')
             .TYP_VAR_VALUE IS NULL THEN

              DBG('BENEFICIARY ADDRESS COUNTRY SHOULD NOT BE NULL');

              P_ERR_CODE := 'IF-RIA-024';

              RETURN FALSE;

            END IF;

            IF P_TBL_NAME_VAL_PAIR('BENEF_OCCUPATION').TYP_VAR_VALUE IS NULL THEN

              DBG('BENEFICIARY OCCUPATION SHOULD NOT BE NULL');

              P_ERR_CODE := 'IF-RIA-025';

              RETURN FALSE;

            END IF;

            --Getting the count if first time or not
            BEGIN
              SELECT COUNT(1)
                INTO L_AML_FLOW_COUNT
                FROM sttb_coral_ria_ws_log
               WHERE FC_REF_NO = P_TY_RTUPLD.ty_upld_rtl_teller.XREF
                 AND ACTION = 'DOSCAN_AUTH'
                 AND SCAN_ID IS NOT NULL;
            EXCEPTION
              WHEN OTHERS THEN
                L_AML_FLOW_COUNT := 0;
            END;

            DBG('L_AML_FLOW_COUNT=' || L_AML_FLOW_COUNT);

            IF L_AML_FLOW_COUNT = 0 AND GWPKS_UTIL.G_MAKERID IS NOT NULL AND
               GWPKS_UTIL.G_CHECKERID IS NULL THEN

              --AML Validation Starts
              IF P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD84 = 'Y' THEN
                --IF PRINCE CUSTOMER

                IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field100 IS NOT NULL THEN
                  --Sender Highest Country
                  L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD100),
                                                  FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD88));

                  L_MAX_INDEX := 1;
                  L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

                  FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

                    IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
                      L_MAX_VALUE := L_RISK_SCORE(G);
                      L_MAX_INDEX := G;
                    END IF;
                  END LOOP;

                  IF L_MAX_INDEX = 1 THEN
                    L_HIGH_SEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD100; --L_SENDER_RIAC_NATIONALITY;
                  ELSE
                    --ELSIF L_MAX_INDEX = 2 THEN
                    L_HIGH_SEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD88;

                  END IF;

                ELSE

                  L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD88));

                  L_HIGH_SEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD88;

                END IF;

                --AML New Payment Flow Starts
                --Beneficiary Highest Country
                L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD89),
                                                FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD90),
                                                FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD83),
                                                FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD96));

                L_MAX_INDEX := 1;
                L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

                FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

                  IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
                    L_MAX_VALUE := L_RISK_SCORE(G);
                    L_MAX_INDEX := G;
                  END IF;
                END LOOP;

                IF L_MAX_INDEX = 1 THEN
                  L_HIGH_BEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD89;
                ELSIF L_MAX_INDEX = 2 THEN
                  L_HIGH_BEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD90;
                ELSIF L_MAX_INDEX = 3 THEN
                  L_HIGH_BEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD83;
                ELSE
                  L_HIGH_BEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD96;
                END IF;

                DBG('L_HIGH_SEN_CNT=' || L_HIGH_SEN_CNT);

                DBG('L_HIGH_BEN_CNT=' || L_HIGH_BEN_CNT);

                DBG('SENDER NAME=' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || ' ' ||
                    TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99));

                DBG('BENEFICIARY NAME=' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD85);
                --AML New Paymenr Flow Ends

                --Call AML only for Sender

                /*IF NOT
                    IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_RIA_OUT(L_HIGH_SEN_CNT,
                                                                    --L_HIGH_BEN_CNT,
                                                                    NULL, --L_CUSTOMER.CUSTOMER_NO,
                                                                    P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || ' ' ||
                                                                    TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99),
                                                                    --P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD85, --BENEFICIARY NAME
                                                                    'DOSCAN_AUTH',
                                                                    P_TY_RTUPLD.ty_upld_rtl_teller.XREF, --p_ifdriaft.v_iftb_ria_master.TRN_REF_NO,
                                                                    P_HIT_STATUS,
                                                                    P_WHO_HIT,
                                                                    P_SCAN_ID,
                                                                    P_ERR_CODE,
                                                                    P_ERR_PARAM) THEN

                  DBG('P_HIT_STATUS=' || P_HIT_STATUS);

                  DBG('P_WHO_HIT=' || P_WHO_HIT);

                  --PR_LOG_ERROR('IFDMTAPA', 'FLEXCUBE', 'IF-RIA-013', P_SCAN_ID);

                  PR_LOG_ERROR('IFDRIAPA',
                               'FLEXCUBE',
                               'IF-RIA-013',
                               P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN
                               ' For Sender' WHEN 'R' THEN ' For Beneficiary' WHEN 'B' THEN
                               ' For Both Sender and Beneficiary' END);

                  RETURN FALSE;

                  -- ELSE
                  --   RETURN TRUE;
                END IF;*/

                DBG('CALLING AML NEW FLOW IF CONDITION');

                --AML New Payment Flow Commented Starts
                /*IF NOT
                    IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_RIA_OUT_NEW(L_HIGH_SEN_CNT,
                                                                        --L_HIGH_BEN_CNT,
                                                                        NULL, --L_CUSTOMER.CUSTOMER_NO,
                                                                        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || ' ' ||
                                                                        TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99),
                                                                        --P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD85, --BENEFICIARY NAME
                                                                        'DOSCAN_AUTH',
                                                                        P_TY_RTUPLD.ty_upld_rtl_teller.XREF, --p_ifdriaft.v_iftb_ria_master.TRN_REF_NO,
                                                                        P_HIT_STATUS,
                                                                        P_WHO_HIT,
                                                                        P_SCAN_ID,
                                                                        P_ERR_CODE,
                                                                        P_ERR_PARAM) THEN

                  DBG('P_HIT_STATUS=' || P_HIT_STATUS);

                  DBG('P_WHO_HIT=' || P_WHO_HIT);

                  --PR_LOG_ERROR('IFDMTAPA', 'FLEXCUBE', 'IF-RIA-013', P_SCAN_ID);

                  \*PR_LOG_ERROR('IFDRIAPA',
                  'FLEXCUBE',
                  'IF-RIA-030',
                  P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN
                  ' For Sender' WHEN 'R' THEN
                  ' For Beneficiary' WHEN 'B' THEN
                  ' For Both Sender and Beneficiary' END);*\

                  OVPKSS.PR_APPENDTBL('IF-RIA-030',
                                      P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN
                                      ' For Sender' WHEN 'R' THEN
                                      ' For Beneficiary' WHEN 'B' THEN
                                      ' For Both Sender and Beneficiary' END);

                  -- RETURN FALSE;

                  -- ELSE
                  --   RETURN TRUE;
                END IF;*/

                --AML New Payment Flow Commented Ends

                --AML New Payment Flow Commented Starts
                IF NOT
                    IFPKS_SANCTION_UTILS.FN_AML_PAYMENT_CALL_B(GLOBAL.user_id,
                                                               GLOBAL.current_branch,
                                                               'OTC',

                                                               L_REF,
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || ' ' ||
                                                               TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99), --Sen Name
                                                               L_HIGH_SEN_CNT, --Sen Country,
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD92 || ' ' ||
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD93 || ' ' ||
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD94 || ' ' ||
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD95,
                                                               NULL,
                                                               P_TY_RTUPLD.ty_upld_rtl_teller.narrative,
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.num_field11, --100,
                                                               P_TY_RTUPLD.ty_upld_rtl_teller.TXN_CCY,
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               'RIA',
                                                               'RIAC',
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               NULL, --L_CUSTOMER.Customer_No,
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || ' ' ||
                                                               TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99), --Sender Name
                                                               L_HIGH_BEN_CNT, --Sender Country
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD85, --Ben Name
                                                               L_HIGH_BEN_CNT, --Ben Country
                                                               P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                                                               P_SCAN_ID,
                                                               P_HIT_STATUS,
                                                               L_IN_RESP) THEN

                  DBG('FAILED IN FN_AML_PAYMENT_CALL_A');

                  PR_LOG_ERROR('RIAC', 'FLEXCUBE', 'IF-AML-001', NULL);

                  RETURN FALSE;

                ELSE

                  --Get JSON in XML
                  L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
                  DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

                  L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                       '&lt;',
                                                                       '<');
                  DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' ||
                      L_RESP_IN_XML);

                  L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                       '&gt;',
                                                                       '>');
                  DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' ||
                      L_RESP_IN_XML);

                  DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
                      L_RESP_IN_XML);

                  P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

                  P_HIT_STATUS := P_DOCUMENT_XML.EXTRACT('/root/RtnHit/text()')
                                  .GETSTRINGVAL;

                  P_SCAN_ID := P_DOCUMENT_XML.EXTRACT('/root/RtnScanID/text()')
                               .GETSTRINGVAL;

                  DBG('P_HIT_STATUS OF API-A =' || P_HIT_STATUS);

                  DBG('P_SCAN_ID OF API-A=' || P_SCAN_ID);

                  IF P_HIT_STATUS = 'X' THEN

                    DBG('INSIDE IF CONFITION');

                    PR_LOG_ERROR('IFDRIAFT',
                                 'FLEXCUBE',
                                 'IF-RFT-030',
                                 P_SCAN_ID);

                    --OVPKSS.PR_APPENDTBL('IF-RIA-030',
                    --                          P_SCAN_ID);

                    RETURN FALSE; --AUTO REJECT

                    /*ELSE

                      --call api B

                      IF NOT
                          IFPKS_SANCTION_UTILS.FN_AML_PAYMENT_CALL_B(GLOBAL.user_id,
                                                                     GLOBAL.current_branch,
                                                                     'OTC',

                                                                     L_REF,
                                                                     P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || ' ' ||
                                                                     TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99), --Sender Name
                                                                     L_HIGH_SEN_CNT, --Sender Country,
                                                                     NULL || '|' ||
                                                                     'PINCKHPPXXX',
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     P_TY_RTUPLD.ty_upld_rtl_teller.narrative,
                                                                     P_TY_RTUPLD.ty_cstbs_ui_columns.num_field11, --100,
                                                                     P_TY_RTUPLD.ty_upld_rtl_teller.TXN_CCY,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     'RIA',
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL, --L_CUSTOMER.Customer_No,
                                                                     NULL, --L_SENDER_NAME
                                                                     NULL, --L_SENDER_COUNTRY
                                                                     P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || ' ' ||
                                                                     TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99), --L_SENDER_NAME
                                                                     L_HIGH_SEN_CNT, --L_SENDER_COUNTRY
                                                                     P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                                                                     P_SCAN_ID,
                                                                     P_HIT_STATUS,
                                                                     L_IN_RESP) THEN

                        RETURN FALSE;

                      ELSE

                        DBG('P_HIT_STATUS OF API-B =' || P_HIT_STATUS);

                        DBG('P_SCAN_ID OF API-B=' || P_SCAN_ID);

                        IF P_HIT_STATUS = 'Y' THEN

                          PR_LOG_ERROR('IFDOFAST',
                                       'FLEXCUBE',
                                       'IF-RIA-030',
                                       P_SCAN_ID \*|| CASE P_WHO_HIT WHEN 'S' THEN
                                                                                                                                                                                                                                                                                                                                                            'For Sender' WHEN 'R' THEN 'For Beneficiary' WHEN 'B' THEN
                                                                                                                                                                                                                                                                                                                                                            'For Both Sender and Beneficiary' END*\);

                        END IF;

                      END IF;

                    END IF;*/

                  ELSIF P_HIT_STATUS = 'Y' THEN

                    DBG('INSIDE ELSE CONFITION');

                    PR_LOG_ERROR('IFDRIAFT',
                                 'FLEXCUBE',
                                 'IF-RIA-030',
                                 P_SCAN_ID);

                  END IF;

                END IF;

                --AML New Payment Flow Commented Ends

                --RETURN FALSE;

              ELSE

              DBG('NON PRINCE BANK CUSTOMER');

                IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field100 IS NOT NULL THEN
                  --Sender Highest Country
                  L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD100),
                                                  FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD88));

                  L_MAX_INDEX := 1;
                  L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

                  FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

                    IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
                      L_MAX_VALUE := L_RISK_SCORE(G);
                      L_MAX_INDEX := G;
                    END IF;
                  END LOOP;

                  IF L_MAX_INDEX = 1 THEN
                    L_HIGH_SEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD100; --L_SENDER_RIAC_NATIONALITY;
                  ELSE
                    --ELSIF L_MAX_INDEX = 2 THEN
                    L_HIGH_SEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD88;

                  END IF;

                ELSE

                  L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD88));

                  L_HIGH_SEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD88;

                END IF;

                --Beneficiary Highest Country
                L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD89),
                                                FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD90),
                                                FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD83),
                                                FN_GET_RISK_LEVEL_CNT(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD96));

                L_MAX_INDEX := 1;
                L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

                FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

                  IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
                    L_MAX_VALUE := L_RISK_SCORE(G);
                    L_MAX_INDEX := G;
                  END IF;
                END LOOP;

                IF L_MAX_INDEX = 1 THEN
                  L_HIGH_BEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD89;
                ELSIF L_MAX_INDEX = 2 THEN
                  L_HIGH_BEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD90;
                ELSIF L_MAX_INDEX = 3 THEN
                  L_HIGH_BEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD83;
                ELSE
                  L_HIGH_BEN_CNT := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD96;
                END IF;

                --Call AML for both Sender and Beneficiary for individual

                /*IF NOT
                    IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_RIA(L_HIGH_SEN_CNT,
                                                                L_HIGH_BEN_CNT,
                                                                NULL, --L_CUSTOMER.CUSTOMER_NO,
                                                                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || ' ' ||
                                                                TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99),
                                                                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD85, --BENEFICIARY NAME
                                                                'DOSCAN_AUTH',
                                                                P_TY_RTUPLD.ty_upld_rtl_teller.XREF, --p_ifdriaft.v_iftb_ria_master.TRN_REF_NO,
                                                                P_HIT_STATUS,
                                                                P_WHO_HIT,
                                                                P_SCAN_ID,
                                                                P_ERR_CODE,
                                                                P_ERR_PARAM) THEN

                  DBG('P_HIT_STATUS=' || P_HIT_STATUS);

                  DBG('P_WHO_HIT=' || P_WHO_HIT);

                  --PR_LOG_ERROR('IFDMTAPA', 'FLEXCUBE', 'IF-RIA-013', P_SCAN_ID);

                  PR_LOG_ERROR('IFDRIAPA',
                               'FLEXCUBE',
                               'IF-RIA-013',
                               P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN
                               ' For Sender' WHEN 'R' THEN ' For Beneficiary' WHEN 'B' THEN
                               ' For Both Sender and Beneficiary' END);



                  RETURN FALSE;

                  --ELSE
                  --  RETURN TRUE;
                END IF;*/

                DBG('CALLING AML NEW FLOW ELSE CONDITION');

                --Name screening starts
               /* IF NOT
                    IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_RIA_CASHREM(null, --L_HIGH_SEN_CNT,
                                                                        null, --L_HIGH_BEN_CNT,
                                                                        NULL, --L_CUSTOMER.CUSTOMER_NO,
                                                                        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || ' ' ||
                                                                        TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99),
                                                                        P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD85, --BENEFICIARY NAME
                                                                        'DOSCAN_AUTH',
                                                                        P_TY_RTUPLD.ty_upld_rtl_teller.XREF, --p_ifdriaft.v_iftb_ria_master.TRN_REF_NO,
                                                                        P_HIT_STATUS,
                                                                        P_WHO_HIT,
                                                                        P_SCAN_ID,
                                                                        P_ERR_CODE,
                                                                        P_ERR_PARAM) THEN

                  DBG('P_HIT_STATUS=' || P_HIT_STATUS);

                  DBG('P_WHO_HIT=' || P_WHO_HIT);

                  --PR_LOG_ERROR('IFDMTAPA', 'FLEXCUBE', 'IF-RIA-013', P_SCAN_ID);

                  \*PR_LOG_ERROR('IFDRIAPA',
                  'FLEXCUBE',
                  'IF-RIA-030',
                  P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN
                  ' For Sender' WHEN 'R' THEN
                  ' For Beneficiary' WHEN 'B' THEN
                  ' For Both Sender and Beneficiary' END);*\

                  OVPKSS.PR_APPENDTBL('IF-RIA-030',
                                      P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN
                                      ' For Sender' WHEN 'R' THEN
                                      ' For Beneficiary' WHEN 'B' THEN
                                      ' For Both Sender and Beneficiary' END);

                  --  RETURN FALSE;
                  --Name screening ends

                ELSE*/

                  --Country Screening Starts

                  /*IF NOT
                      IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_RIA_CASHREM(L_HIGH_SEN_CNT,
                                                                          L_HIGH_BEN_CNT,
                                                                          NULL, --L_CUSTOMER.CUSTOMER_NO,
                                                                          P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || ' ' ||
                                                                          TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99),
                                                                          P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD85, --BENEFICIARY NAME
                                                                          'DOSCAN_AUTH',
                                                                          P_TY_RTUPLD.ty_upld_rtl_teller.XREF, --p_ifdriaft.v_iftb_ria_master.TRN_REF_NO,
                                                                          P_HIT_STATUS,
                                                                          P_WHO_HIT,
                                                                          P_SCAN_ID,
                                                                          P_ERR_CODE,
                                                                          P_ERR_PARAM) THEN

                    DBG('P_HIT_STATUS=' || P_HIT_STATUS);

                    DBG('P_WHO_HIT=' || P_WHO_HIT);

                    --PR_LOG_ERROR('IFDMTAPA', 'FLEXCUBE', 'IF-RIA-013', P_SCAN_ID);

                    \*PR_LOG_ERROR('IFDRIAPA',
                    'FLEXCUBE',
                    'IF-RIA-030',
                    P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN
                    ' For Sender Country' WHEN 'R' THEN
                    ' For Beneficiary Country' WHEN 'B' THEN
                    ' For Both Sender and Beneficiary Countries' END);*\

                    OVPKSS.PR_APPENDTBL('IF-RIA-030',
                                        P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN
                                        ' For Sender' WHEN 'R' THEN
                                        ' For Beneficiary' WHEN 'B' THEN
                                        ' For Both Sender and Beneficiary' END);

                    -- RETURN FALSE;

                  END IF;*/ --Country Screening Ends

                  --AML New Payment Flow Starts
                  IF NOT
                    IFPKS_SANCTION_UTILS.FN_AML_PAYMENT_CALL_B(GLOBAL.user_id,
                                                               GLOBAL.current_branch,
                                                               'OTC',

                                                               L_REF,
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || ' ' ||
                                                               TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99) || '|' ||
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD85, --Sender Name
                                                               L_HIGH_SEN_CNT || '|' ||
                                                               L_HIGH_BEN_CNT,
                                                               NULL || '|' ||
                                                               'PINCKHPPXXX',
                                                               NULL || '|' || NULL,
                                                               NULL || '|' || NULL,
                                                               NULL || '|' || NULL,
                                                               NULL || '|' || NULL,
                                                               NULL || '|' || NULL,
                                                               NULL || '|' || NULL,
                                                               NULL || '|' || NULL,
                                                               NULL || '|' ||
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD92 || ' ' ||
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD93 || ' ' ||
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD94 || ' ' ||
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD95,
                                                               NULL,
                                                               P_TY_RTUPLD.ty_upld_rtl_teller.narrative,
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.num_field11, --100,
                                                               P_TY_RTUPLD.ty_upld_rtl_teller.TXN_CCY,
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               'RIA',
                                                               'RIAC',
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               NULL, --L_CUSTOMER.Customer_No,
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || ' ' ||
                                                               TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99), --Sender Name
                                                               L_HIGH_SEN_CNT, --Sender Country
                                                               P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD85, --Ben Name
                                                               L_HIGH_BEN_CNT, --Ben Country
                                                               P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                                                               P_SCAN_ID,
                                                               P_HIT_STATUS,
                                                               L_IN_RESP) THEN

                  DBG('FAILED IN FN_AML_PAYMENT_CALL_A');

                  PR_LOG_ERROR('RIAC', 'FLEXCUBE', 'IF-AML-001', NULL);

                  RETURN FALSE;

                ELSE

                  --Get JSON in XML
                  L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
                  DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

                  L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                       '&lt;',
                                                                       '<');
                  DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' ||
                      L_RESP_IN_XML);

                  L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                       '&gt;',
                                                                       '>');
                  DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' ||
                      L_RESP_IN_XML);

                  DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
                      L_RESP_IN_XML);

                  P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

                  P_HIT_STATUS := P_DOCUMENT_XML.EXTRACT('/root/RtnHit/text()')
                                  .GETSTRINGVAL;

                  P_SCAN_ID := P_DOCUMENT_XML.EXTRACT('/root/RtnScanID/text()')
                               .GETSTRINGVAL;

                  DBG('P_HIT_STATUS OF API-A =' || P_HIT_STATUS);

                  DBG('P_SCAN_ID OF API-A=' || P_SCAN_ID);

                  IF P_HIT_STATUS = 'X' THEN

                    DBG('INSIDE IF CONFITION');

                    PR_LOG_ERROR('IFDRIAFT',
                                 'FLEXCUBE',
                                 'IF-RFT-030',
                                 P_SCAN_ID);

                    --OVPKSS.PR_APPENDTBL('IF-RIA-030',
                    --                          P_SCAN_ID);

                    RETURN FALSE; --AUTO REJECT

                  ELSIF P_HIT_STATUS = 'Y' THEN

                    DBG('INSIDE ELSE CONFITION');

                    PR_LOG_ERROR('IFDRIAFT',
                                 'FLEXCUBE',
                                 'IF-RIA-030',
                                 P_SCAN_ID);

                  END IF;

                END IF;
                  --AML New Payment Flow Ends

                --END IF;

              END IF;

              --AML Validation Ends

            ELSE

              IF /*L_AML_FLOW_COUNT > 0 AND */
               GWPKS_UTIL.G_MAKERID IS NOT NULL AND
               GWPKS_UTIL.G_CHECKERID IS NOT NULL THEN

                BEGIN
                  SELECT *
                    INTO L_STTB_CORAL_RIA_WS_LOG
                    FROM STTB_CORAL_RIA_WS_LOG A
                   WHERE A.UNIQUE_REFERENCE_NO IN
                         (SELECT MAX(UNIQUE_REFERENCE_NO)
                            FROM STTB_CORAL_RIA_WS_LOG A
                           WHERE A.FC_REF_NO =
                                 P_TY_RTUPLD.ty_upld_rtl_teller.XREF
                             --AND STATUS IN ('HIT', 'NO HIT') --AML New Payment Flow Changes
                             --AND ACTION = 'DOSCAN_AUTH') --AML New Payment Flow Changes
                              AND REQ_TYPE = 'ONLINE_SCAN'
                             AND ACTION IN
                                 ('DOSCAN_AUTH_A', 'DOSCAN_AUTH_B')) --AML New Payment Flow Changes
                     AND FC_REF_NO = P_TY_RTUPLD.ty_upld_rtl_teller.XREF
                     AND STATUS IN ('Y'); --AML New Payment Flow Changes;
                EXCEPTION

                  WHEN OTHERS THEN

                    DBG('FAILED IN GETTING THE RECORD');
                    DBG('ERROR CODE IN GETTING THE RECORD=' || SQLCODE);
                    DBG('ERROR MESSAGE IN GETTING THE RECORD=' || SQLERRM);

                    L_STTB_CORAL_RIA_WS_LOG := NULL;

                END;

                --check status for scan id
                IF L_STTB_CORAL_RIA_WS_LOG.SCAN_ID IS NOT NULL THEN

                --AML New Payment Flow Commented Starts
                  /*IF NOT
                      IFPKS_SANCTION_UTILS.FN_GET_AML_STATUS_RIA_OUT(L_STTB_CORAL_RIA_WS_LOG.SCAN_ID,
                                                                     L_STTB_CORAL_RIA_WS_LOG.CUSTOMER_NO,
                                                                     L_STTB_CORAL_RIA_WS_LOG.FC_REF_NO,
                                                                     p_Err_Code,
                                                                     P_ERR_PARAM) THEN

                    RETURN FALSE;

                  END IF;*/
                  --AML New Payment Flow Commented Ends

                  --AML New Payment Flow Starts
                  IF NOT
                      IFPKS_SANCTION_UTILS.FN_GET_AML_PAYMENT_STATUS('OTC',
                                                                     L_STTB_CORAL_RIA_WS_LOG.UNIQUE_REFERENCE_NO,
                                                                     L_STTB_CORAL_RIA_WS_LOG.SCAN_ID,
                                                                     L_STTB_CORAL_RIA_WS_LOG.CUSTOMER_NO,
                                                                     L_STTB_CORAL_RIA_WS_LOG.FC_REF_NO,
                                                                     'RIA',
                                                                     'RIAC',
                                                                     L_RESP_IN_XML) THEN

                    RETURN FALSE;

                  ELSE

                    DBG('SUCCESS IN GETTING AML STATUS');

                    --Get JSON in XML
                    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_RESP_IN_XML);
                    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

                    L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                         '&lt;',
                                                                         '<');
                    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' ||
                        L_RESP_IN_XML);

                    L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                         '&gt;',
                                                                         '>');
                    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' ||
                        L_RESP_IN_XML);

                    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
                        L_RESP_IN_XML);

                    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

                    P_HIT_STATUS := P_DOCUMENT_XML.EXTRACT('/root/RtnResult/text()')
                                    .GETSTRINGVAL;

                    DBG('P_HIT_STATUS=' || P_HIT_STATUS);

                    IF P_HIT_STATUS IN ('R', 'REJECTED') THEN
                      P_ERR_CODE := 'ST-PRIN-010';
                      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                      RETURN FALSE;
                    END IF;

                    IF P_HIT_STATUS IN ('P', 'PENDING') THEN
                      P_ERR_CODE := 'ST-PRIN-011';
                      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                      RETURN FALSE;
                    END IF;

                  END IF;
                  --AML New Payment Flow Ends

                END IF;

              END IF;

            END IF;

            IF NVL(P_TBL_NAME_VAL_PAIR('SENDER_COUNTRY').TYP_VAR_VALUE,
                   '**') = 'US' THEN
              IF P_TBL_NAME_VAL_PAIR('BENEF_ADDR_4').TYP_VAR_VALUE IS NULL THEN

                DBG('BENEFICIARY ADDRESS SHOULD NOT BE NULL FOR SENDER COUNTRY - US ');

                P_ERR_CODE := 'IF-RIA-011';

                RETURN FALSE;

              END IF;

              IF P_TBL_NAME_VAL_PAIR('BENEF_PROVINCE').TYP_VAR_VALUE IS NULL THEN

                DBG('BENEFICIARY CITY SHOULD NOT BE NULL FOR SENDER COUNTRY - US');

                P_ERR_CODE := 'IF-RIA-012';

                RETURN FALSE;

              END IF;
            END IF;

          END IF;

          IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY <>
             P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY THEN

            DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY);
            DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);
            DBG('l_rate=' || l_rate);
            DBG('depks_rtl_teller.pkg_prod.rate_code_preferred=' ||
                depks_rtl_teller.pkg_prod.rate_code_preferred);

            dbg('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT);
            dbg('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT=' ||
                P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT);

            IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY = GLOBAL.LCY THEN
              IF NOT cypkss.fn_amt1_to_amt2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                            GLOBAL.LCY,
                                            'COMM', --depks_rtl_teller.PKG_PROD.RATE_TYPE_PREFERRED,
                                            'B',
                                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                            'Y',
                                            l_txn_amt,
                                            l_rate,
                                            P_ERR_PARAM) THEN
                debug.pr_debug('**', '');
                debug.pr_debug('**', SQLERRM);
                p_err_code  := 'ST-OTHR-001';
                P_ERR_PARAM := NULL;
                RETURN FALSE;
              END IF;
            ELSE
              DBG('i am inside Buy Rate');
              IF NOT cypkss.fn_amt1_to_amt2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY,
                                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,

                                            'COMM', --depks_rtl_teller.PKG_PROD.RATE_TYPE_PREFERRED,
                                            'B',
                                            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT,
                                            'Y',
                                            l_ofs_amt,
                                            l_rate,
                                            P_ERR_PARAM) THEN
                debug.pr_debug('**', '');
                debug.pr_debug('**', SQLERRM);
                p_err_code  := 'ST-OTHR-001';
                P_ERR_PARAM := NULL;
                RETURN FALSE;
              END IF;
            END IF;

            dbg('l_ofs_amt->' || l_ofs_amt);

            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := l_ofs_amt;

          ELSE

            dbg('INSIDE ELSE CONDITION=' ||
                P_TY_RTUPLD.ty_cstbs_ui_columns.num_field11);

            l_ofs_amt := TO_NUMBER(P_TY_RTUPLD.ty_cstbs_ui_columns.num_field11);

            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := l_ofs_amt;

            --P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := 100;

            /*IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                                          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY,
                                          GLOBAL.lcy,
                                          'STANDARD',
                                          'M',
                                          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                          'Y',
                                          l_txn_amt,
                                          l_rate,
                                          P_ERR_CODE) THEN
              RETURN FALSE;
            END IF;*/

            -- l_txn_amt := P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT;
          END IF;

          dbg('l_ofs_amt->' || l_ofs_amt);

          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := l_ofs_amt;

          DBG('GWPKS_UTIL.PKG_ACTTYPE=' || GWPKS_UTIL.PKG_ACTTYPE);

          DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT=' ||
              P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT);

          IF GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH') THEN

            --Get RIA PIN Enquiry
            L_FORMATTED_MSG := FN_GET_FMT_RIA_PIN_ENQUIRY(P_TY_RTUPLD);

            DBG('AFTER REPLACEMENT OF RIA PIN ENQUIRY JSON=' ||
                L_FORMATTED_MSG);

            DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

            DBG('CALLING RIA PIN ENQUIRY WEBSERVICE');

            IF NOT FN_MSG_UPLOAD_RIA(P_TY_RTUPLD,
                                     'I',
                                     L_FORMATTED_MSG,
                                     'RIA PIN Enquiry Call',
                                     P_ERR_CODE,
                                     P_ERR_PARAM) THEN

              DBG('FAILED IN RIA PIN ENQUIRY CALL');

              RETURN FALSE;

            ELSE

              DBG('SUCCESS IN RIA PIN ENQUIRY CALL');

              --default values
              BEGIN

                SELECT COUNT(1)
                  INTO L_COUNT

                  FROM STTM_CUSTOMER        A,
                       STTM_CUSTOMER_CUSTOM B,
                       STTM_CUST_PERSONAL   C
                 WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                   AND A.CUSTOMER_NO = C.CUSTOMER_NO
                   AND A.RECORD_STAT = 'O'
                   AND A.AUTH_STAT = 'A'
                   AND A.ONCE_AUTH = 'Y'
                   AND A.UNIQUE_ID_NAME =
                       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD80
                   AND A.UNIQUE_ID_VALUE =
                       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD81;

              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;

              IF L_COUNT > 0 THEN
                BEGIN
                  SELECT A.FULL_NAME,
                         C.BIRTH_COUNTRY,
                         A.NATIONALITY,
                         A.ADDRESS_LINE1,
                         A.ADDRESS_LINE3,
                         A.ADDRESS_LINE2,
                         A.ADDRESS_LINE4,
                         A.COUNTRY,
                         B.OCCUPATION,

                         B.UNIQUE_ID_EXP_DT
                    INTO L_CUST_FULLNAME,
                         L_CUST_BIRTH_COUNTRY,
                         L_CUST_NATIONALITY,
                         L_CUST_ADDRLINE1,
                         L_CUST_ADDRLINE2,
                         L_CUST_ADDRLINE3,
                         L_CUST_ADDRLINE4,
                         L_CUST_ADDR_COUNTRY,
                         L_CUST_OCCUPATION,
                         L_CUST_UID_EXPDATE

                    FROM STTM_CUSTOMER        A,
                         STTM_CUSTOMER_CUSTOM B,
                         STTM_CUST_PERSONAL   C
                   WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                     AND A.CUSTOMER_NO = C.CUSTOMER_NO
                     AND A.RECORD_STAT = 'O'
                     AND A.AUTH_STAT = 'A'
                     AND A.ONCE_AUTH = 'Y'
                     AND A.UNIQUE_ID_NAME =
                         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD80
                     AND A.UNIQUE_ID_VALUE =
                         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD81;

                EXCEPTION
                  WHEN OTHERS THEN
                    NULL;
                END;

                DBG('L_CUST_UID_EXPDATE=' || L_CUST_UID_EXPDATE);
                DBG('L_CUST_ADDR_COUNTRY=' || L_CUST_ADDR_COUNTRY);
                DBG('L_CUST_ADDRLINE1=' || L_CUST_ADDRLINE1);
                DBG('L_CUST_ADDRLINE2=' || L_CUST_ADDRLINE2);
                DBG('L_CUST_ADDRLINE3=' || L_CUST_ADDRLINE3);
                DBG('L_CUST_ADDRLINE4=' || L_CUST_ADDRLINE4);

                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD84 := 'Y';

                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD85 := L_CUST_FULLNAME;
                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD89 := L_CUST_BIRTH_COUNTRY;
                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD90 := L_CUST_NATIONALITY;
                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD92 := L_CUST_ADDRLINE1;
                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD93 := L_CUST_ADDRLINE2;
                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD94 := L_CUST_ADDRLINE3;
                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD95 := L_CUST_ADDRLINE4;
                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD96 := L_CUST_ADDR_COUNTRY;
                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD97 := L_CUST_OCCUPATION;

                DBG('L_CUST_UID_EXPDATE=' ||
                    TO_CHAR(L_CUST_UID_EXPDATE, 'DD-MM-YY'));
                DBG('L_CUST_UID_EXPDATE=' ||
                    TO_CHAR(L_CUST_UID_EXPDATE, 'DD-MM-YYYY'));
                DBG('L_CUST_UID_EXPDATE=' ||
                    TO_date(L_CUST_UID_EXPDATE, 'DD-MM-YYYY'));

                P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD82 := TO_CHAR(L_CUST_UID_EXPDATE,
                                                                        'YYYY-MM-DD');

              END IF;

            END IF;

          END IF;

          DBG('GWPKS_UTIL.G_MAKER_ID=' || GWPKS_UTIL.G_MAKERID);
          DBG('GWPKS_UTIL.G_CHECKERID=' || GWPKS_UTIL.G_CHECKERID);

          IF GWPKS_UTIL.G_MAKERID IS NOT NULL AND
             GWPKS_UTIL.G_CHECKERID IS NOT NULL AND
             GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') --AND
          -- P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD3 IS NOT NULL AND
          --  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD11 IS NOT NULL
           THEN

            --Get RIA CONFIRM PAYMENT
            L_FORMATTED_MSG := FN_GET_FMT_RIA_PAYMENT(P_TY_RTUPLD);

            DBG('AFTER REPLACEMENT OF RIA PAYMENT JSON=' ||
                L_FORMATTED_MSG);

            DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

            DBG('CALLING RIA PAYMENT WEBSERVICE');

            IF NOT FN_MSG_UPLOAD_RIA(P_TY_RTUPLD,
                                     'C',
                                     L_FORMATTED_MSG,
                                     'RIA Payment Confirmation Call',
                                     P_ERR_CODE,
                                     P_ERR_PARAM) THEN

              DBG('FAILED IN RIA PAYMENT CALL');

              RETURN FALSE;

            ELSE

              DBG('SUCCESS IN RIA PAYMENT CALL');

            END IF;

          END IF;

        END IF;
      END IF;
      --RIA Cashwithdrawal Remittance Ends

    --RIA Phase2 Changes Ends
	
	IF GWPKS_UTIL.PKG_FUNC IN ('MGIC') THEN
      
        IF GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH', 'SAVEAUTOAUTH') THEN
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD31') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD31 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD31')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD32') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD32 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD32')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD33') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD33')
                                                            .TYP_VAR_VALUE;
            
            DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33='||P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33);
            DBG('DATE='||to_date(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33, 'YYYY-MM-DD'));
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD34') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD34')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD35') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD35 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD35')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD36') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD36 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD36')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD37') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD37 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD37')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD38') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD38 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD38')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD39') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD39 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD39')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD40') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD40 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD40')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD41') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD41 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD41')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD42') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD42 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD42')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD43') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD43 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD43')
                                                            .TYP_VAR_VALUE;
          
          END IF;
          
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD44') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD44')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          DBG('GWPKS_UTIL.PKG_ACTTYPE=' || GWPKS_UTIL.PKG_ACTTYPE);
        
          IF GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
          
            --Get Passcode Enquiry Message
          
            DBG('GWPKS_UTIL.G_MAKER_ID=' || GWPKS_UTIL.G_MAKERID);
            DBG('GWPKS_UTIL.G_CHECKERID=' || GWPKS_UTIL.G_CHECKERID);
          
            IF GWPKS_UTIL.G_MAKERID IS NOT NULL AND
               GWPKS_UTIL.G_CHECKERID IS NULL THEN
            
              null;
              --AML New Payment Flow Starts
              /*IF NOT
                  IFPKS_SANCTION_UTILS.FN_AML_PAYMENT_CALL_B(GLOBAL.user_id,
                                                             GLOBAL.current_branch,
                                                             'OTC',
                                                             
                                                             L_REF,
                                                             P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45 || '|' ||
                                                             TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44), --Sen Name
                                                             'KH' || '|' || 'KH', --Sen Country,
                                                             'PINCKHPPXXX' || '|' ||
                                                             FN_GET_BEN_BANK_NAME(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46),
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL,
                                                             NULL,
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.narrative,
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.OFS_AMOUNT, --100,
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.TXN_CCY,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             'RFT',
                                                             'RFTD',
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL, --L_CUSTOMER.Customer_No,
                                                             P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45, --Sender Name
                                                             'KH', --Sender Country
                                                             P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44, --Ben Name
                                                             'KH', --Ben Country
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                                                             P_SCAN_ID,
                                                             P_HIT_STATUS,
                                                             L_IN_RESP) THEN
              
                DBG('FAILED IN FN_AML_PAYMENT_CALL_B');
              
                PR_LOG_ERROR('RFTM', 'FLEXCUBE', 'IF-AML-001', NULL);
              
                RETURN FALSE;
              
              ELSE
              
                --Get JSON in XML
                L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
                DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
              
                L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                     '&lt;',
                                                                     '<');
                DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' ||
                    L_RESP_IN_XML);
              
                L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                     '&gt;',
                                                                     '>');
                DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' ||
                    L_RESP_IN_XML);
              
                DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
                    L_RESP_IN_XML);
              
                P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
              
                P_HIT_STATUS := P_DOCUMENT_XML.EXTRACT('/root/RtnHit/text()')
                                .GETSTRINGVAL;
              
                P_SCAN_ID := P_DOCUMENT_XML.EXTRACT('/root/RtnScanID/text()')
                             .GETSTRINGVAL;
              
                DBG('P_HIT_STATUS OF API-B =' || P_HIT_STATUS);
              
                DBG('P_SCAN_ID OF API-B=' || P_SCAN_ID);
              
                IF P_HIT_STATUS = 'X' THEN
                
                  DBG('INSIDE IF CONFITION');
                
                  PR_LOG_ERROR('IFDRIAFT',
                               'FLEXCUBE',
                               'IF-RFT-030',
                               P_SCAN_ID);
                
                  --OVPKSS.PR_APPENDTBL('IF-RIA-030',
                  --                          P_SCAN_ID);
                
                  RETURN FALSE; --AUTO REJECT
                
                ELSIF P_HIT_STATUS = 'Y' THEN
                
                  DBG('INSIDE ELSE CONFITION');
                
                  PR_LOG_ERROR('IFDRIAFT',
                               'FLEXCUBE',
                               'IF-RIA-030',
                               P_SCAN_ID);
                
                END IF;
              
              END IF;*/
              --AML New Payment Flow Ends
            
            ELSIF GWPKS_UTIL.G_CHECKERID IS NOT NULL AND
                  GWPKS_UTIL.G_MAKERID <> GWPKS_UTIL.G_CHECKERID THEN
            
              dbg('new');
            
              --AML New Payment Flow Starts
              /*IF GWPKS_UTIL.G_MAKERID IS NOT NULL AND
                 GWPKS_UTIL.G_CHECKERID IS NOT NULL THEN
              
                DBG('Inside Auth...');
              
                BEGIN
                  SELECT *
                    INTO L_STTB_CORAL_RIA_WS_LOG
                    FROM STTB_CORAL_RFT_WS_LOG A
                   WHERE A.UNIQUE_REFERENCE_NO IN
                         (SELECT MAX(UNIQUE_REFERENCE_NO)
                            FROM STTB_CORAL_RFT_WS_LOG A
                           WHERE A.FC_REF_NO =
                                 P_TY_RTUPLD.ty_upld_rtl_teller.XREF
                                --AND STATUS IN ('HIT', 'NO HIT')  --AML New Payment Flow Changes
                                --AND ACTION = 'DOSCAN_AUTH' --AML New Payment Flow Changes
                             AND REQ_TYPE = 'ONLINE_SCAN'
                             AND ACTION IN
                                 ('DOSCAN_AUTH_A', 'DOSCAN_AUTH_B')) --AML New Payment Flow Changes
                        
                     AND FC_REF_NO = P_TY_RTUPLD.ty_upld_rtl_teller.XREF
                     AND STATUS IN ('Y'); --AML New Payment Flow Changes
                EXCEPTION
                
                  WHEN OTHERS THEN
                  
                    DBG('FAILED IN GETTING THE RECORD');
                    DBG('ERROR CODE IN GETTING THE RECORD=' || SQLCODE);
                    DBG('ERROR MESSAGE IN GETTING THE RECORD=' || SQLERRM);
                  
                    L_STTB_CORAL_RIA_WS_LOG := NULL;
                  
                END;
              
                DBG('L_STTB_CORAL_RIA_WS_LOG.SCAN_ID=' ||
                    L_STTB_CORAL_RIA_WS_LOG.SCAN_ID);
              
                --check status for scan id
                IF L_STTB_CORAL_RIA_WS_LOG.SCAN_ID IS NOT NULL THEN
                  \*IF NOT
                      IFPKS_SANCTION_UTILS.FN_GET_AML_STATUS_RIA_OUT(L_STTB_CORAL_RIA_WS_LOG.SCAN_ID,
                                                                     L_STTB_CORAL_RIA_WS_LOG.CUSTOMER_NO,
                                                                     L_STTB_CORAL_RIA_WS_LOG.FC_REF_NO,
                                                                     p_Err_Code,
                                                                     P_ERR_PARAM) THEN
                  
                    RETURN FALSE;
                  
                  END IF;*\
                
                  DBG('Calling AML Payment Status API');
                
                  --AML New Payment Flow Starts
                  IF NOT
                      IFPKS_SANCTION_UTILS.FN_GET_AML_PAYMENT_STATUS('OTC',
                                                                     L_STTB_CORAL_RIA_WS_LOG.UNIQUE_REFERENCE_NO,
                                                                     L_STTB_CORAL_RIA_WS_LOG.SCAN_ID,
                                                                     L_STTB_CORAL_RIA_WS_LOG.CUSTOMER_NO,
                                                                     L_STTB_CORAL_RIA_WS_LOG.FC_REF_NO,
                                                                     'RFT',
                                                                     'RFTD',
                                                                     L_RESP_IN_XML) THEN
                  
                    RETURN FALSE;
                  
                  ELSE
                  
                    DBG('SUCCESS IN GETTING AML STATUS');
                  
                    --Get JSON in XML
                    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_RESP_IN_XML);
                    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
                  
                    L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                         '&lt;',
                                                                         '<');
                    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' ||
                        L_RESP_IN_XML);
                  
                    L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                         '&gt;',
                                                                         '>');
                    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' ||
                        L_RESP_IN_XML);
                  
                    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
                        L_RESP_IN_XML);
                  
                    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
                  
                    P_HIT_STATUS := P_DOCUMENT_XML.EXTRACT('/root/RtnResult/text()')
                                    .GETSTRINGVAL;
                  
                    DBG('P_HIT_STATUS=' || P_HIT_STATUS);
                  
                    IF P_HIT_STATUS IN ('R', 'REJECTED') THEN
                      P_ERR_CODE := 'ST-PRIN-010';
                      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                      RETURN FALSE;
                    END IF;
                  
                    IF P_HIT_STATUS IN ('P', 'PENDING') THEN
                      P_ERR_CODE := 'ST-PRIN-011';
                      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                      RETURN FALSE;
                    END IF;
                  
                  END IF;
                  --AML New Payment Flow Ends
                
                END IF;
              
              END IF;*/
              --AML New Payment Flow Ends
            
            END IF;
          
          END IF;
        
        END IF;
      
      END IF;
    
      IF GWPKS_UTIL.PKG_FUNC IN ('MGOC') THEN
      
        IF GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH', 'SAVEAUTOAUTH') THEN
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD32') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD32 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD32')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD33') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD33')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD34') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD34')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD35') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD35 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD35')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD35') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD35 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD35')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD40') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD40 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD40')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD42') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD42 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD42')
                                                            .TYP_VAR_VALUE;
          
            G_BEN_CON := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD42;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD43') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD43 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD43')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD44') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD44')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD45') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD45')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD3') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD3 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                                                           .TYP_VAR_VALUE;
          
          END IF;
        
          dbg('P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD3=' ||
              P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD3);
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD46') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD46')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD47') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD47 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD47')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD48') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD48 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD48')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD49') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD49 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD49')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD50') THEN
          
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD50 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD50')
                                                            .TYP_VAR_VALUE;
          
          END IF;
        
          DBG('GWPKS_UTIL.PKG_ACTTYPE=' || GWPKS_UTIL.PKG_ACTTYPE);
        
          IF GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
          
            --Get Passcode Enquiry Message
          
            DBG('GWPKS_UTIL.G_MAKER_ID=' || GWPKS_UTIL.G_MAKERID);
            DBG('GWPKS_UTIL.G_CHECKERID=' || GWPKS_UTIL.G_CHECKERID);
          
            IF GWPKS_UTIL.G_MAKERID IS NOT NULL AND
               GWPKS_UTIL.G_CHECKERID IS NULL THEN
            
              null;
              --AML New Payment Flow Starts
              /*IF NOT
                  IFPKS_SANCTION_UTILS.FN_AML_PAYMENT_CALL_B(GLOBAL.user_id,
                                                             GLOBAL.current_branch,
                                                             'OTC',
                                                             
                                                             L_REF,
                                                             P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45 || '|' ||
                                                             TRIM(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44), --Sen Name
                                                             'KH' || '|' || 'KH', --Sen Country,
                                                             'PINCKHPPXXX' || '|' ||
                                                             FN_GET_BEN_BANK_NAME(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46),
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL || '|' || NULL,
                                                             NULL,
                                                             NULL,
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.narrative,
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.OFS_AMOUNT, --100,
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.TXN_CCY,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             'RFT',
                                                             'RFTD',
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL, --L_CUSTOMER.Customer_No,
                                                             P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45, --Sender Name
                                                             'KH', --Sender Country
                                                             P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44, --Ben Name
                                                             'KH', --Ben Country
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
                                                             P_SCAN_ID,
                                                             P_HIT_STATUS,
                                                             L_IN_RESP) THEN
              
                DBG('FAILED IN FN_AML_PAYMENT_CALL_B');
              
                PR_LOG_ERROR('RFTM', 'FLEXCUBE', 'IF-AML-001', NULL);
              
                RETURN FALSE;
              
              ELSE
              
                --Get JSON in XML
                L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
                DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
              
                L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                     '&lt;',
                                                                     '<');
                DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' ||
                    L_RESP_IN_XML);
              
                L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                     '&gt;',
                                                                     '>');
                DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' ||
                    L_RESP_IN_XML);
              
                DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
                    L_RESP_IN_XML);
              
                P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
              
                P_HIT_STATUS := P_DOCUMENT_XML.EXTRACT('/root/RtnHit/text()')
                                .GETSTRINGVAL;
              
                P_SCAN_ID := P_DOCUMENT_XML.EXTRACT('/root/RtnScanID/text()')
                             .GETSTRINGVAL;
              
                DBG('P_HIT_STATUS OF API-B =' || P_HIT_STATUS);
              
                DBG('P_SCAN_ID OF API-B=' || P_SCAN_ID);
              
                IF P_HIT_STATUS = 'X' THEN
                
                  DBG('INSIDE IF CONFITION');
                
                  PR_LOG_ERROR('IFDRIAFT',
                               'FLEXCUBE',
                               'IF-RFT-030',
                               P_SCAN_ID);
                
                  --OVPKSS.PR_APPENDTBL('IF-RIA-030',
                  --                          P_SCAN_ID);
                
                  RETURN FALSE; --AUTO REJECT
                
                ELSIF P_HIT_STATUS = 'Y' THEN
                
                  DBG('INSIDE ELSE CONFITION');
                
                  PR_LOG_ERROR('IFDRIAFT',
                               'FLEXCUBE',
                               'IF-RIA-030',
                               P_SCAN_ID);
                
                END IF;
              
              END IF;*/
              --AML New Payment Flow Ends
            
            ELSIF GWPKS_UTIL.G_CHECKERID IS NOT NULL AND
                  GWPKS_UTIL.G_MAKERID <> GWPKS_UTIL.G_CHECKERID THEN
            
              dbg('new');
            
              --AML New Payment Flow Starts
              /*IF GWPKS_UTIL.G_MAKERID IS NOT NULL AND
                 GWPKS_UTIL.G_CHECKERID IS NOT NULL THEN
              
                DBG('Inside Auth...');
              
                BEGIN
                  SELECT *
                    INTO L_STTB_CORAL_RIA_WS_LOG
                    FROM STTB_CORAL_RFT_WS_LOG A
                   WHERE A.UNIQUE_REFERENCE_NO IN
                         (SELECT MAX(UNIQUE_REFERENCE_NO)
                            FROM STTB_CORAL_RFT_WS_LOG A
                           WHERE A.FC_REF_NO =
                                 P_TY_RTUPLD.ty_upld_rtl_teller.XREF
                                --AND STATUS IN ('HIT', 'NO HIT')  --AML New Payment Flow Changes
                                --AND ACTION = 'DOSCAN_AUTH' --AML New Payment Flow Changes
                             AND REQ_TYPE = 'ONLINE_SCAN'
                             AND ACTION IN
                                 ('DOSCAN_AUTH_A', 'DOSCAN_AUTH_B')) --AML New Payment Flow Changes
                        
                     AND FC_REF_NO = P_TY_RTUPLD.ty_upld_rtl_teller.XREF
                     AND STATUS IN ('Y'); --AML New Payment Flow Changes
                EXCEPTION
                
                  WHEN OTHERS THEN
                  
                    DBG('FAILED IN GETTING THE RECORD');
                    DBG('ERROR CODE IN GETTING THE RECORD=' || SQLCODE);
                    DBG('ERROR MESSAGE IN GETTING THE RECORD=' || SQLERRM);
                  
                    L_STTB_CORAL_RIA_WS_LOG := NULL;
                  
                END;
              
                DBG('L_STTB_CORAL_RIA_WS_LOG.SCAN_ID=' ||
                    L_STTB_CORAL_RIA_WS_LOG.SCAN_ID);
              
                --check status for scan id
                IF L_STTB_CORAL_RIA_WS_LOG.SCAN_ID IS NOT NULL THEN
                  \*IF NOT
                      IFPKS_SANCTION_UTILS.FN_GET_AML_STATUS_RIA_OUT(L_STTB_CORAL_RIA_WS_LOG.SCAN_ID,
                                                                     L_STTB_CORAL_RIA_WS_LOG.CUSTOMER_NO,
                                                                     L_STTB_CORAL_RIA_WS_LOG.FC_REF_NO,
                                                                     p_Err_Code,
                                                                     P_ERR_PARAM) THEN
                  
                    RETURN FALSE;
                  
                  END IF;*\
                
                  DBG('Calling AML Payment Status API');
                
                  --AML New Payment Flow Starts
                  IF NOT
                      IFPKS_SANCTION_UTILS.FN_GET_AML_PAYMENT_STATUS('OTC',
                                                                     L_STTB_CORAL_RIA_WS_LOG.UNIQUE_REFERENCE_NO,
                                                                     L_STTB_CORAL_RIA_WS_LOG.SCAN_ID,
                                                                     L_STTB_CORAL_RIA_WS_LOG.CUSTOMER_NO,
                                                                     L_STTB_CORAL_RIA_WS_LOG.FC_REF_NO,
                                                                     'RFT',
                                                                     'RFTD',
                                                                     L_RESP_IN_XML) THEN
                  
                    RETURN FALSE;
                  
                  ELSE
                  
                    DBG('SUCCESS IN GETTING AML STATUS');
                  
                    --Get JSON in XML
                    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_RESP_IN_XML);
                    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
                  
                    L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                         '&lt;',
                                                                         '<');
                    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' ||
                        L_RESP_IN_XML);
                  
                    L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                                         '&gt;',
                                                                         '>');
                    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' ||
                        L_RESP_IN_XML);
                  
                    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
                        L_RESP_IN_XML);
                  
                    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
                  
                    P_HIT_STATUS := P_DOCUMENT_XML.EXTRACT('/root/RtnResult/text()')
                                    .GETSTRINGVAL;
                  
                    DBG('P_HIT_STATUS=' || P_HIT_STATUS);
                  
                    IF P_HIT_STATUS IN ('R', 'REJECTED') THEN
                      P_ERR_CODE := 'ST-PRIN-010';
                      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                      RETURN FALSE;
                    END IF;
                  
                    IF P_HIT_STATUS IN ('P', 'PENDING') THEN
                      P_ERR_CODE := 'ST-PRIN-011';
                      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                      RETURN FALSE;
                    END IF;
                  
                  END IF;
                  --AML New Payment Flow Ends
                
                END IF;
              
              END IF;*/
              --AML New Payment Flow Ends
            
            END IF;
          
          END IF;
        
        END IF;
      
      END IF;
      --MoneyGram Remittance CashWithdrawal By Cash Sampath Ends

    END IF;

    IF P_FN_CALL_ID = 2 THEN

      DBG('IF', 'Inside fn_pop_plsql_tbl ...');

    END IF;

    DBG('IF', 'Returning Successfully from fn_pop_plsql_tbl..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('IF',
          'In When Others of Gwpks_CreateRetailTlr_Custom.fn_pop_plsql_tbl ..='||dbms_utility.format_error_backtrace
         );
      DBG('IF', SQLERRM);
      RETURN FALSE;
  END FN_POP_PLSQL_TBL;

  PROCEDURE PR_PROCESS_MSG(P_IS_IN_MSG_CLOB  IN VARCHAR2,
                           P_REC_MSG_HEADER  IN GWPKSS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                           P_IS_OUT_MSG_CLOB IN OUT VARCHAR2,
                           P_INSTR_REC       IN OUT NOCOPY GWPKSS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS,
                           P_TY_RTUPLD       IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                           P_FLAG            IN OUT NUMBER,
                           P_ERR_CODE        IN OUT VARCHAR2,
                           P_ERR_PARAM       IN OUT VARCHAR2,
                           P_FN_CALL_ID      IN OUT NUMBER,
                           P_TBL_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Inside the procedure gwpks_createretailtlr_custom.Pr_Process_Msg..');

    DBG('Returning successfully from the procedure gwpks_createretailtlr_custom.Pr_Process_Msg..');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of the procedure gwpks_createretailtlr_custom.Pr_Process_Msg..');
  END PR_PROCESS_MSG;

  FUNCTION FN_TS_TO_TYPE(P_NODES_LIST         IN VARCHAR2,
                         P_TS_TAG_NAMES       IN VARCHAR2,
                         P_TS_TAG_VALUES      IN VARCHAR2,
                         P_TS_CLOB_TAG_NAMES  IN CLOB,
                         P_TS_CLOB_TAG_VALUES IN CLOB,
                         P_IS_IN_MSG_CLOB     IN VARCHAR2,
                         P_TY_RTUPLD          IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                         P_DTF                IN VARCHAR2,
                         P_FN_CALL_ID         IN OUT NUMBER,
                         P_TB_CUSTOM_DATA     IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                         P_ERR_CODE           IN OUT VARCHAR2,
                         P_ERR_PARAM          IN OUT VARCHAR2) RETURN BOOLEAN IS

  BEGIN
    DEBUG.PR_DEBUG('IF',
                   'Inside gwpks_createretailtlr_custom.fn_ts_to_type ...');
    IF P_FN_CALL_ID = 1 THEN

      DBG('IF', 'Inside fn_ts_to_type ...');

    END IF;
    DBG('IF', 'Returning Successfully from fn_ts_to_type..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('IF',
          'In When Others of gwpks_createretailtlr_custom.fn_ts_to_type ..');
      DBG('IF', SQLERRM);
      RETURN FALSE;
  END FN_TS_TO_TYPE;

  FUNCTION FN_BUILD_CONTRACT_PCDETAILS(PKEY             IN VARCHAR2,
                                       PDATA            IN VARCHAR2,
                                       P_TBL_PC_DET     IN OUT NOCOPY DETB_PCTRN%ROWTYPE,
                                       P_FN_CALL_ID     IN OUT NUMBER,
                                       P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                       P_ERR_CODE       IN OUT VARCHAR2,
                                       P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN
    DEBUG.PR_DEBUG('IF',
                   'Inside gwpks_createretailtlr_custom.fn_build_contract_pcdetails ...');

    DBG('IF', 'Returning Successfully from fn_build_contract_pcdetails..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('IF',
          'In When Others of gwpks_createretailtlr_custom.fn_build_contract_pcdetails ..');
      DBG('IF', SQLERRM);
      RETURN FALSE;
  END FN_BUILD_CONTRACT_PCDETAILS;

END GWPKS_CREATERETAILTLR_CUSTOM;
