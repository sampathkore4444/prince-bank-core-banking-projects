-- Create table
create table IFTB_MGT_IN_MASTER
(
  branch_code      VARCHAR2(3),
  trn_ref_no       VARCHAR2(20) not null,
  product_code     VARCHAR2(4),
  transfer_date    DATE,
  txn_ccy          VARCHAR2(3),
  txn_amt          NUMBER(22,3),
  net_txn_amt      NUMBER(22,3),
  exch_rate        NUMBER(24,12),
  txn_remarks      VARCHAR2(255),
  sender_name      VARCHAR2(255),
  sender_addr1     VARCHAR2(105),
  sender_addr2     VARCHAR2(105),
  sender_addr3     VARCHAR2(105),
  sender_addr4     VARCHAR2(105),
  sender_dob       DATE,
  ben_acc          VARCHAR2(100),
  ben_name         VARCHAR2(100),
  ben_acc_ccy      VARCHAR2(3),
  ben_acc_brn      VARCHAR2(3),
  ben_remarks      VARCHAR2(255),
  pass_code        VARCHAR2(105),
  maker_id         VARCHAR2(12),
  maker_dt_stamp   DATE,
  checker_id       VARCHAR2(12),
  checker_dt_stamp DATE,
  auth_stat        VARCHAR2(1),
  record_stat      VARCHAR2(1),
  once_auth        VARCHAR2(1),
  mod_no           NUMBER(4),
  source_of_funds  VARCHAR2(105),
  purpose_of_trf   VARCHAR2(105)
)
/
alter table IFTB_MGT_IN_MASTER add primary key (TRN_REF_NO)
/
