create or replace package gwpks_createretailtlr_custom as
/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © © 2008 - 2016  Oracle and/or its affiliates.  All rights reserved.
**
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
**
**
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
  CHANGE HISTORY

     ** Changed By              : Ankit Tiwari
     ** Changed On              : 06/09/2013
     ** Change Description      : New function has been added for providing a hook.
     ** Search string           : 9NT1525_1201_IALIZZ_17421599

     ** Changed By              : Sriraam S
     ** Changed On              : 10-Oct-2013
     ** Change Description      : Hooks Added To capture agent details
     ** Search string           : 9NT1525_1202_IDTKEKEF_17646902

  **  Modified By         : Nidhi Verma
  **  Modified On         : 30-Mar-2017
  **  Modified Reason     : Parameter p_ty_rtupld changed to IN OUT for FUNCTION fn_pop_plsql_tbl
  **  Search String       : Bug#25748600
 ** Modified By         : Dekyi
  ** Modified On         : 14-Aug-2017
  ** Modified Reason     : Hooks given. EHD Ref: 20960745_12.3_08_AUG_2017_01_0000.Retro of 12.3_EXTN_26612732
  ** Search String       : 26658827

  ------------------------------------------------------------------------------------------------------
*/
---  9NT1525_1201_IALIZZ_17421599 starts
FUNCTION fn_pop_plsql_tbl(p_node_name   IN VARCHAR2
                   ,p_dtf               IN VARCHAR2
                   ,p_tbl_name_val_pair IN OUT NOCOPY Gwpks_CreateRetailTlr.ty_recs_tbl
                   ,p_ty_rtupld         IN OUT Depks_RetailTellerUpload.typ_retailTellerUpld_rec  --Bug#25748600
                   ,p_err_code          IN OUT VARCHAR2
                   ,p_err_param         IN OUT VARCHAR2
                   ,p_Fn_Call_Id        IN OUT NUMBER
                   ,p_Tb_Custom_Data    IN OUT NOCOPY Global.Ty_Tb_Custom_Data)
          RETURN BOOLEAN;

PROCEDURE Pr_Process_Msg(p_Is_In_Msg_Clob     IN VARCHAR2
                           ,p_Rec_Msg_Header  IN Gwpkss_Service_Router.Ty_Biz_Process_Header
                           ,p_Is_Out_Msg_Clob IN OUT VARCHAR2
                           ,p_Instr_Rec       IN OUT NOCOPY Gwpkss_Service_Router.Ty_Processing_Instructions
                     ,p_ty_rtupld       IN OUT NOCOPY Depks_RetailTellerUpload.typ_retailTellerUpld_rec
                           ,p_Flag            IN OUT NUMBER
                           ,p_Err_Code        IN OUT VARCHAR2
                           ,p_Err_Param       IN OUT VARCHAR2
                     ,p_Fn_Call_Id      IN OUT NUMBER
                           ,p_tbl_custom_data IN OUT NOCOPY Global.ty_tb_custom_data);
-- 9NT1525_1201_IALIZZ_17421599 ends

--9NT1525_1202_IDTKEKEF_17646902 Starts
  FUNCTION fn_ts_to_type(p_nodes_list    IN VARCHAR2
                        ,p_ts_tag_names  IN VARCHAR2
                        ,p_ts_tag_values IN VARCHAR2
                        ,p_ts_clob_tag_names IN CLOB
                        ,p_ts_clob_tag_values IN CLOB
                        ,p_is_in_msg_clob IN VARCHAR2
                        ,p_ty_rtupld     IN Depks_RetailTellerUpload.typ_retailTellerUpld_rec
                        ,p_dtf           IN VARCHAR2
            ,p_Fn_Call_Id        IN OUT NUMBER
            ,p_tb_custom_data IN OUT NOCOPY global.ty_tb_custom_data
                        ,p_err_code      IN OUT VARCHAR2
                        ,p_err_param     IN OUT VARCHAR2) RETURN BOOLEAN ;
--9NT1525_1202_IDTKEKEF_17646902 Ends
--26658827 starts
FUNCTION fn_build_contract_pcdetails(pkey               IN VARCHAR2
                                     ,pdata             IN VARCHAR2
                                     ,p_tbl_pc_det      IN OUT NOCOPY DETB_PCTRN%ROWTYPE
                   ,p_Fn_Call_Id      IN OUT NUMBER
                   ,p_tb_custom_data  IN OUT NOCOPY Global.ty_tb_custom_data
                                     ,p_err_code        IN OUT VARCHAR2
                                     ,p_err_param       IN OUT VARCHAR2)
RETURN BOOLEAN;
--26658827 ends

--RIA Phase2 Changes Starts
--RIA Withdrawal Remittance Confirmation Ends for Digital
  FUNCTION FN_GET_FMT_RIA_PAYMENT_DIG(P_TXN_UNIQUE_NO    IN VARCHAR2,
                                      P_RIA_REFERENCE_NO IN VARCHAR2,
                                      P_ORDER_NO         IN VARCHAR2,
                                      P_RIA_PIN          IN VARCHAR2,
                                      P_TY_RTUPLD        IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC)
    RETURN CLOB;

  FUNCTION FN_MSG_UPLOAD_RIA(P_TY_RTUPLD  IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                             P_REQ_TYPE   IN VARCHAR2,
                             P_REQ_MSG    IN OUT CLOB,
                             P_ADDL_INFO  IN VARCHAR2,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2) RETURN BOOLEAN;
  --RIA Withdrawal Remittance Confirmation Ends for Digital
--RIA Phase2 Changes Ends

--MoneyGram Outbound By Cash Sampath Starts
  G_BEN_CON STTM_COUNTRY.COUNTRY_CODE%TYPE;
  --MoneyGram Outbound By Cash Sampath Ends

end gwpks_createretailtlr_custom;
