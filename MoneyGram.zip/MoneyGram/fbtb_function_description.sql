prompt Importing table fbtb_function_description...
set feedback off
set define off
insert into fbtb_function_description (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'MGIC', 'Teller', 'Cash Transactions', 'MoneyGram Remittance Withdrawal By Cash', null, 'WB', '100', 'MoneyGram Remittance Withdrawal By Cash', null);

insert into fbtb_function_description (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'MGOC', 'Teller', 'Cash Transactions', 'MoneyGram Outgoing Payment By Cash', null, 'WB', '100', 'MoneyGram Outgoing Payment By Cash', null);

prompt Done.
