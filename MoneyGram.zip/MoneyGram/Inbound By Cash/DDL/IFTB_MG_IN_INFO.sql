-- Create table
create table IFTB_MG_IN_INFO
(
  trn_ref_no     VARCHAR2(16) PRIMARY KEY,
  ben_cif        VARCHAR2(105),
  ben_name       VARCHAR2(105),
  ben_dob        DATE,
  ben_country    VARCHAR2(105),
  ben_mobile     VARCHAR2(35),
  ben_uid        VARCHAR2(35),
  ben_uvalue     VARCHAR2(35),
  sender_name    VARCHAR2(105),
  sender_addr1   VARCHAR2(105),
  sender_addr2   VARCHAR2(105),
  sender_addr3   VARCHAR2(105),
  sender_country VARCHAR2(105),
  sender_dob     DATE,
  purpose_of_trf VARCHAR2(105)
)
/
alter table IFTB_MG_IN_INFO add primary key (TRN_REF_NO)
/