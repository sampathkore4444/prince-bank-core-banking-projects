function fnPostLoad_CUSTOM() {
	
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD31").nextSibling.nextSibling.style.visibility = "hidden";	
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD32").nextSibling.style.visibility = "hidden";	
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD33").nextSibling.style.visibility = "hidden";	
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD34").nextSibling.style.visibility = "hidden";
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD35").nextSibling.style.visibility = "hidden";
    document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD36").nextSibling.style.visibility = "hidden";	
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD37").nextSibling.style.visibility = "hidden";	
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD42").nextSibling.nextSibling.style.visibility = "hidden";
	return true;
    	
}


function fnPostNew_CUSTOM() {
	
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD31").nextSibling.nextSibling.style.visibility = "hidden";
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD32").nextSibling.style.visibility = "hidden";	
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD33").nextSibling.style.visibility = "hidden";	
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD34").nextSibling.style.visibility = "hidden";
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD35").nextSibling.style.visibility = "hidden";
    document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD36").nextSibling.style.visibility = "hidden";	
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD37").nextSibling.style.visibility = "hidden";	
	document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD42").nextSibling.nextSibling.style.visibility = "hidden";
    
	return true;
    	
}
