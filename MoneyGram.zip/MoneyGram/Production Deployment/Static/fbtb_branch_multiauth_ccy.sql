insert into fbtb_branch_multiauth_ccy (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE)
values ('ALL', 'MGIC', 'KHR');

insert into fbtb_branch_multiauth_ccy (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE)
values ('ALL', 'MGIC', 'USD');

insert into fbtb_branch_multiauth_ccy (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE)
values ('ALL', 'MGOC', 'KHR');

insert into fbtb_branch_multiauth_ccy (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE)
values ('ALL', 'MGOC', 'USD');

COMMIT;
