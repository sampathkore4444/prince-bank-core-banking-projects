insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RELATIONSHIP_MG', 'Business Partner', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RELATIONSHIP_MG', 'Clients', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RELATIONSHIP_MG', 'Contractor', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RELATIONSHIP_MG', 'Family Member', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RELATIONSHIP_MG', 'Friends', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RELATIONSHIP_MG', 'Other', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RELATIONSHIP_MG', 'Third Party', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RELATIONSHIP_MG', 'Vendor', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SOURCE_FUNDS_MG', 'Income from deposit', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SOURCE_FUNDS_MG', 'Investment', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SOURCE_FUNDS_MG', 'Other', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SOURCE_FUNDS_MG', 'Salary income', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SOURCE_FUNDS_MG', 'Sales good or services', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SOURCE_FUNDS_MG', 'Saving', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('TRF_PURPOSE_MG', 'Family Support', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('TRF_PURPOSE_MG', 'Other', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('TRF_PURPOSE_MG', 'Payment for Consultancy services', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('TRF_PURPOSE_MG', 'Payment of living expense', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('TRF_PURPOSE_MG', 'Payment of travel', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('TRF_PURPOSE_MG', 'Purchasing good or service', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('TRF_PURPOSE_MG', 'School fee', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('TRF_PURPOSE_MG', 'Service of Transportation and Import', null);

COMMIT;
