insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('RELATIONSHIP_MG', 'Relationship - MoneyGram Transfer', 'SAMPATH2', 'SAMPATH2', to_date('09-03-2023 10:12:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('09-03-2023 10:12:32', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('SOURCE_FUNDS_MG', 'Source of Funds - MoneyGram Transfer', 'SAMPATH2', 'SAMPATH2', to_date('09-03-2023 10:13:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('09-03-2023 10:13:46', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('TRF_PURPOSE_MG', 'Purpose of Transfer - MoneyGram', 'SAMPATH2', 'SAMPATH2', to_date('09-03-2023 10:10:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('09-03-2023 10:10:54', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

COMMIT;
