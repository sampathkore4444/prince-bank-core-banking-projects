insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGOC', 'KHR', 400000000.000, 'P', 'SUPERVISOR', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGOC', 'KHR', 400000000.000, 'S', 'SUPERVISOR', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGOC', 'KHR', 10000000000000000.000, 'P', 'MANAGER', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGOC', 'KHR', 10000000000000000.000, 'S', 'MANAGER', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGOC', 'USD', 100000.000, 'P', 'SUPERVISOR', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGOC', 'USD', 100000.000, 'S', 'SUPERVISOR', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGOC', 'USD', 999999999999.000, 'P', 'MANAGER', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGOC', 'USD', 999999999999.000, 'S', 'MANAGER', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGIC', 'KHR', 400000000.000, 'P', 'SUPERVISOR', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGIC', 'KHR', 400000000.000, 'S', 'SUPERVISOR', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGIC', 'KHR', 10000000000000000.000, 'P', 'MANAGER', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGIC', 'KHR', 10000000000000000.000, 'S', 'MANAGER', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGIC', 'USD', 100000.000, 'P', 'SUPERVISOR', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGIC', 'USD', 100000.000, 'S', 'SUPERVISOR', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGIC', 'USD', 999999999999.000, 'P', 'MANAGER', null, null, null, null);

insert into fbtb_branch_multiauth_map (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, AUTH_RULE, ROLE1, ROLE2, ROLE3, ROLE4, ROLE5)
values ('ALL', 'MGIC', 'USD', 999999999999.000, 'S', 'MANAGER', null, null, null, null);

COMMIT;
