insert into SMTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'MGIC', 'MoneyGram Payment', 'Operations', 'MoneyGram Remittance Withdrawal By Cash', null, 'WB', null, 'MoneyGram Remittance Withdrawal By Cash', 'MGIC');

insert into SMTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'MGOC', 'MoneyGram Payment', 'Operations', 'MoneyGram Outgoing Payment By Cash', null, 'WB', '100', 'MoneyGram Outgoing Payment By Cash', 'MGOC');

COMMIT;
