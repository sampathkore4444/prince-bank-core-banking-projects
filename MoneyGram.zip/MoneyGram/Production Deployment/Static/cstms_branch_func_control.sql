insert into cstms_branch_func_control (FUNCTION_ID, OFFLINE_SUPPORT, REVERSAL_ALLOWED, CONFIRM_SUPPORT)
values ('MGIC', 'Y', 'Y', null);

insert into cstms_branch_func_control (FUNCTION_ID, OFFLINE_SUPPORT, REVERSAL_ALLOWED, CONFIRM_SUPPORT)
values ('MGOC', 'Y', 'Y', null);

COMMIT;
