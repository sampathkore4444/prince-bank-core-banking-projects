insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'MGOC', 'KHR', 400000000.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'MGOC', 'KHR', 10000000000000000.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'MGOC', 'USD', 100000.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'MGOC', 'USD', 999999999999.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'MGIC', 'KHR', 400000000.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'MGIC', 'KHR', 10000000000000000.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'MGIC', 'USD', 100000.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'MGIC', 'USD', 999999999999.000, null, null);

COMMIT;
