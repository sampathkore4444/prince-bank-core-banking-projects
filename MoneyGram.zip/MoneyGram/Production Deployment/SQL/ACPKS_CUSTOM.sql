CREATE OR REPLACE PACKAGE BODY acpks_custom AS

/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © 2007 - 2016  Oracle and/or its affiliates.  All rights reserved.
**
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
**
**
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
---------------------------------------------------------------------------------------------------
** Modified By           : Kore Sampath Kumar
** Modified On           : 01-August-2019
** Modified Reason       : NBC FAST Changes
** Search String         : NBC FAST Changes

** Modified By         : Kore Sampath Kumar
** Modified On           : 15-July-2020
** Modified Reason       : NBC RFT Changes
** Search String         : NBC RFT Changes
   -------------------------------------------------------------------------------------------------------
   */
  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'acpks_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('AE', L_MSG);
  END DBG;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  --NBC FAST Changes Starts
  FUNCTION FN_ACENTRY_RETRIEVAL_CUSTOM(PTRNREFNO   IN ACVWS_ALL_AC_ENTRIES.TRN_REF_NO%TYPE,
                                PEVENTSEQNO IN ACVWS_ALL_AC_ENTRIES.EVENT_SR_NO%TYPE,
                                PACENTS     OUT ACPKS.TBL_ACHOFF)
    RETURN NUMBER AS
    L_EMPTY_HAND ACTBS_HANDOFF%ROWTYPE;
    CURSOR CR_ENTRIES(PTRNREFNO IN VARCHAR2, PEVENTSEQNO IN VARCHAR2) IS
      SELECT *
        FROM ACVWS_ALL_AC_ENTRIES
       WHERE TRN_REF_NO = PTRNREFNO
         AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
         AND EVENT != 'RPOS'
         AND AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2','CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5');
    L_CNT      NUMBER(4) := 1;
    PAC_NATIVE STTBS_ACCOUNT.AC_NATIVE%TYPE;
    LAC_NO     ACTBS_DAILY_LOG.AC_NO%TYPE;

    NUM_ACCT NUMBER;

    CURSOR CR_NET_ENTRIES(PTRNREFNO IN VARCHAR2, PEVENTSEQNO IN VARCHAR2) IS
      SELECT *
        FROM ACTBS_NETTING_TRANSACTION
       WHERE TRN_REF_NO = PTRNREFNO
         AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
         AND EVENT != 'RPOS';

    CURSOR CR_DEF_ENTRIES(PTRNREFNO IN VARCHAR2, PEVENTSEQNO IN VARCHAR2) IS
      SELECT *
        FROM ACTB_ENTRIES_HANDOFF
       WHERE TRN_REF_NO = PTRNREFNO
         AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
         AND EVENT != 'RPOS';

    LERR   ERTB_MSGS.ERR_CODE%TYPE;
    LPARAM ERTB_MSGS.MESSAGE%TYPE;

    L_CURR_USER SMTB_CURRENT_USERS.USER_ID%TYPE;
    L_CURR_BRN  STTM_BRANCH.BRANCH_CODE%TYPE;

  BEGIN

    IF NOT ACPKS.FN_SKIP_CUSTOM THEN
      DBG('Calling Acpks_Custom.fn_pre_acEntry_Retrieval');
      NUM_ACCT := ACPKS_CUSTOM.FN_PRE_ACENTRY_RETRIEVAL(PTRNREFNO,
                                                        PEVENTSEQNO,
                                                        PACENTS);

    END IF;

    IF NOT ACPKS.FN_SKIP_CLUSTER THEN
      DBG('Acpks_Cluster.fn_pre_acEntry_Retrieval');
      NUM_ACCT := ACPKS_CLUSTER.FN_PRE_ACENTRY_RETRIEVAL(PTRNREFNO,
                                                         PEVENTSEQNO,
                                                         PACENTS);

    END IF;

    IF NOT ACPKS.FN_SKIP_KERNEL THEN

      L_CURR_USER := GLOBAL.USER_ID;
      L_CURR_BRN  := GLOBAL.CURRENT_BRANCH;
      DBG('current user ' || L_CURR_USER);
      DBG('current brn ' || L_CURR_BRN);

      IF NOT ACPKS_UTILS.FN_DEFERREDHANDOFF('T',
                                            NULL,
                                            NULL,
                                            PTRNREFNO,
                                            PEVENTSEQNO,
                                            NULL,
                                            LERR,
                                            LPARAM) THEN
        DBG('Failed in  fn_DeferredHandoff Trn: ' || LERR || '~' ||
             LPARAM);
        OVPKSS.PR_APPENDTBL(LERR, LPARAM);
        RETURN 0;
      END IF;

      DBG('current user ' || L_CURR_USER);
      DBG('current brn ' || L_CURR_BRN);
      GLOBAL.PR_INIT(L_CURR_BRN, L_CURR_USER);

      FOR CREC IN CR_ENTRIES(PTRNREFNO, PEVENTSEQNO) LOOP
        LAC_NO := LTRIM(RTRIM(CREC.AC_NO));
        BEGIN

          IF GLOBALS_ADDON.INTERFACE_ID = 'FINWARE' OR
             GLOBALS_ADDON.INTERFACE_ID = 'BANCS' OR
             GLOBALS_ADDON.INTERFACE_ID = 'FLEXML'

           THEN
            BEGIN
              SELECT AC_NO
                INTO LAC_NO
                FROM ACTB_DAILY_GHOST_LOG
               WHERE TRN_REF_NO = PTRNREFNO
                 AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
                 AND AC_ENTRY_SR_NO = CREC.AC_ENTRY_SR_NO;
            EXCEPTION

              WHEN NO_DATA_FOUND THEN
                BEGIN
                  SELECT AC_NO
                    INTO LAC_NO
                    FROM ACTB_GHOST_HISTORY
                   WHERE TRN_REF_NO = PTRNREFNO
                     AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
                     AND AC_ENTRY_SR_NO = CREC.AC_ENTRY_SR_NO;
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('In WOT for Actb_Ghost_HISTORY : Not a Intersystem Bridge Gl account so not calling fn_ghost_entries');
                END;

              WHEN OTHERS THEN
                DBG('Not a Intersystem Bridge Gl account so not calling fn_ghost_entries');
                NULL;
            END;
          END IF;
        END;
        PACENTS(L_CNT) := L_EMPTY_HAND;
        PACENTS(L_CNT).TRN_REF_NO := CREC.TRN_REF_NO;
        PACENTS(L_CNT).EVENT_SR_NO := CREC.EVENT_SR_NO;
        PACENTS(L_CNT).EVENT := CREC.EVENT;
        PACENTS(L_CNT).AC_BRANCH := CREC.AC_BRANCH;
        PACENTS(L_CNT).AC_NO := LAC_NO;
        PACENTS(L_CNT).AC_CCY := CREC.AC_CCY;
        PACENTS(L_CNT).DRCR_IND := CREC.DRCR_IND;
        PACENTS(L_CNT).TRN_CODE := CREC.TRN_CODE;
        PACENTS(L_CNT).FCY_AMOUNT := CREC.FCY_AMOUNT;
        PACENTS(L_CNT).EXCH_RATE := CREC.EXCH_RATE;
        PACENTS(L_CNT).LCY_AMOUNT := CREC.LCY_AMOUNT;
        PACENTS(L_CNT).TRN_DT := CREC.TRN_DT;
        PACENTS(L_CNT).VALUE_DT := CREC.VALUE_DT;
        PACENTS(L_CNT).TXN_INIT_DATE := CREC.TXN_INIT_DATE;
        PACENTS(L_CNT).AMOUNT_TAG := CREC.AMOUNT_TAG;
        PACENTS(L_CNT).RELATED_CUSTOMER := CREC.RELATED_CUSTOMER;
        PACENTS(L_CNT).INSTRUMENT_CODE := CREC.INSTRUMENT_CODE;
        PACENTS(L_CNT).BANK_CODE := CREC.BANK_CODE;
        PACENTS(L_CNT).MIS_HEAD := CREC.MIS_HEAD;
        PACENTS(L_CNT).MODULE := CREC.MODULE;
        PACENTS(L_CNT).AUTH_STAT := CREC.AUTH_STAT;
        PACENTS(L_CNT).NETTING_IND := 'N';
        PACENTS(L_CNT).ORIG_PNL_GL := CREC.ORIG_PNL_GL;

        PACENTS(L_CNT).RELATED_ACCOUNT := CREC.RELATED_ACCOUNT;

        PACENTS(L_CNT).CUST_GL := CREC.CUST_GL;
        PACENTS(L_CNT).IB := CREC.IB;
        PACENTS(L_CNT).VIRTUAL_AC_NO := CREC.VIRTUAL_AC_NO;

        --PR_INIT_AC_OBJ_CUSTOM(PACENTS, CREC.AC_ENTRY_SR_NO);

        L_CNT := L_CNT + 1;
      END LOOP;

      IF PACENTS.COUNT = 0 THEN
        DBG('no row present in actb_daily_log as entries may not have been posted');
        FOR CREC IN CR_DEF_ENTRIES(PTRNREFNO, PEVENTSEQNO) LOOP
          LAC_NO := LTRIM(RTRIM(CREC.AC_NO));
          BEGIN

            IF GLOBAL_ADDON.INTERFACE_ID = 'FINWARE' OR
               GLOBAL_ADDON.INTERFACE_ID = 'BANCS' OR
               GLOBAL_ADDON.INTERFACE_ID = 'FLEXML'

             THEN
              BEGIN
                SELECT AC_NO
                  INTO LAC_NO
                  FROM ACTB_DAILY_GHOST_LOG
                 WHERE TRN_REF_NO = PTRNREFNO
                   AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
                   AND AC_ENTRY_SR_NO = CREC.AC_ENTRY_SR_NO;
              EXCEPTION

                WHEN NO_DATA_FOUND THEN
                  BEGIN
                    SELECT AC_NO
                      INTO LAC_NO
                      FROM ACTB_GHOST_HISTORY
                     WHERE TRN_REF_NO = PTRNREFNO
                       AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
                       AND AC_ENTRY_SR_NO = CREC.AC_ENTRY_SR_NO;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('In WOT for Actb_Ghost_HISTORY : Not a Intersystem Bridge Gl account so not calling fn_ghost_entries');
                  END;

                WHEN OTHERS THEN
                  DBG('Not a Intersystem Bridge Gl account so not calling fn_ghost_entries');
                  NULL;
              END;
            END IF;
          END;
          PACENTS(L_CNT) := L_EMPTY_HAND;
          PACENTS(L_CNT).TRN_REF_NO := CREC.TRN_REF_NO;
          PACENTS(L_CNT).EVENT_SR_NO := CREC.EVENT_SR_NO;
          PACENTS(L_CNT).EVENT := CREC.EVENT;
          PACENTS(L_CNT).AC_BRANCH := CREC.AC_BRANCH;
          PACENTS(L_CNT).AC_NO := LAC_NO;
          PACENTS(L_CNT).AC_CCY := CREC.AC_CCY;
          PACENTS(L_CNT).DRCR_IND := CREC.DRCR_IND;
          PACENTS(L_CNT).TRN_CODE := CREC.TRN_CODE;
          PACENTS(L_CNT).FCY_AMOUNT := CREC.FCY_AMOUNT;
          PACENTS(L_CNT).EXCH_RATE := CREC.EXCH_RATE;
          PACENTS(L_CNT).LCY_AMOUNT := CREC.LCY_AMOUNT;
          PACENTS(L_CNT).TRN_DT := CREC.TRN_DT;
          PACENTS(L_CNT).VALUE_DT := CREC.VALUE_DT;
          PACENTS(L_CNT).TXN_INIT_DATE := CREC.TXN_INIT_DATE;
          PACENTS(L_CNT).AMOUNT_TAG := CREC.AMOUNT_TAG;
          PACENTS(L_CNT).RELATED_CUSTOMER := CREC.RELATED_CUSTOMER;
          PACENTS(L_CNT).INSTRUMENT_CODE := CREC.INSTRUMENT_CODE;

          PACENTS(L_CNT).MIS_HEAD := CREC.MIS_HEAD;
          PACENTS(L_CNT).MODULE := CREC.MODULE;
          PACENTS(L_CNT).AUTH_STAT := CREC.AUTH_STAT;
          PACENTS(L_CNT).NETTING_IND := 'N';

          PACENTS(L_CNT).RELATED_ACCOUNT := CREC.RELATED_ACCOUNT;

          PACENTS(L_CNT).CUST_GL := CREC.CUST_GL;
          PACENTS(L_CNT).IB := CREC.IB;
          PACENTS(L_CNT).VIRTUAL_AC_NO := CREC.VIRTUAL_AC_NO;

          --PR_INIT_AC_OBJ_CUSTOM(PACENTS, CREC.AC_ENTRY_SR_NO);

          L_CNT := L_CNT + 1;
        END LOOP;
      END IF;

      DBG('before retrieving from actbs_netting_transaction : count:' ||
           PACENTS.COUNT);
      L_CNT := PACENTS.COUNT + 1;
      FOR CREC IN CR_NET_ENTRIES(PTRNREFNO, PEVENTSEQNO) LOOP
        LAC_NO := LTRIM(RTRIM(CREC.AC_NO));
        PACENTS(L_CNT) := L_EMPTY_HAND;
        PACENTS(L_CNT).TRN_REF_NO := CREC.TRN_REF_NO;
        PACENTS(L_CNT).EVENT_SR_NO := CREC.EVENT_SR_NO;
        PACENTS(L_CNT).EVENT := CREC.EVENT;
        PACENTS(L_CNT).AC_BRANCH := CREC.AC_BRANCH;
        PACENTS(L_CNT).AC_NO := LAC_NO;
        PACENTS(L_CNT).AC_CCY := CREC.AC_CCY;
        PACENTS(L_CNT).DRCR_IND := CREC.DRCR_IND;
        PACENTS(L_CNT).TRN_CODE := CREC.TRN_CODE;
        PACENTS(L_CNT).FCY_AMOUNT := CREC.FCY_AMOUNT;
        PACENTS(L_CNT).EXCH_RATE := CREC.EXCH_RATE;
        PACENTS(L_CNT).LCY_AMOUNT := CREC.LCY_AMOUNT;
        PACENTS(L_CNT).TRN_DT := CREC.TRN_DT;
        PACENTS(L_CNT).VALUE_DT := CREC.VALUE_DT;
        PACENTS(L_CNT).TXN_INIT_DATE := CREC.TXN_INIT_DATE;
        PACENTS(L_CNT).AMOUNT_TAG := CREC.AMOUNT_TAG;
        PACENTS(L_CNT).RELATED_CUSTOMER := CREC.RELATED_CUSTOMER;
        PACENTS(L_CNT).INSTRUMENT_CODE := CREC.INSTRUMENT_CODE;
        PACENTS(L_CNT).BANK_CODE := CREC.BANK_CODE;
        PACENTS(L_CNT).MIS_HEAD := CREC.MIS_HEAD;
        PACENTS(L_CNT).MODULE := CREC.MODULE;
        PACENTS(L_CNT).NETTING_IND := 'N';
        PACENTS(L_CNT).ORIG_PNL_GL := CREC.ORIG_PNL_GL;
        PACENTS(L_CNT).RELATED_ACCOUNT := CREC.RELATED_ACCOUNT;
        PACENTS(L_CNT).CUST_GL := CREC.CUST_GL;
        PACENTS(L_CNT).IB := CREC.IB;

        --PR_INIT_AC_OBJ_CUSTOM(PACENTS, CREC.AC_ENTRY_SR_NO);

        L_CNT := L_CNT + 1;
      END LOOP;
      DBG('after retrieving from actbs_netting_transaction : count:' ||
           PACENTS.COUNT);

    END IF;

    IF NOT ACPKS.FN_SKIP_CLUSTER THEN
      DBG('Acpks_Cluster.fn_post_acEntry_Retrieval');
      NUM_ACCT := ACPKS_CLUSTER.FN_POST_ACENTRY_RETRIEVAL(PTRNREFNO,
                                                          PEVENTSEQNO,
                                                          PACENTS);

    END IF;

    IF NOT ACPKS.FN_SKIP_CUSTOM THEN
      DBG('Calling Acpks_Custom.fn_post_acEntry_Retrieval');
      NUM_ACCT := ACPKS_CUSTOM.FN_POST_ACENTRY_RETRIEVAL(PTRNREFNO,
                                                         PEVENTSEQNO,
                                                         PACENTS);

    END IF;

    RETURN(PACENTS.COUNT);
  END FN_ACENTRY_RETRIEVAL_CUSTOM;
  --NBC FAST Changes Ends

  --NBC RFT Changes Starts
  FUNCTION FN_ACENTRY_RETRIEVAL_RFT(PTRNREFNO   IN ACVWS_ALL_AC_ENTRIES.TRN_REF_NO%TYPE,
                                PEVENTSEQNO IN ACVWS_ALL_AC_ENTRIES.EVENT_SR_NO%TYPE,
                                PACENTS     OUT ACPKS.TBL_ACHOFF)
    RETURN NUMBER AS
    L_EMPTY_HAND ACTBS_HANDOFF%ROWTYPE;
    CURSOR CR_ENTRIES(PTRNREFNO IN VARCHAR2, PEVENTSEQNO IN VARCHAR2) IS
      SELECT *
        FROM ACVWS_ALL_AC_ENTRIES
       WHERE TRN_REF_NO = PTRNREFNO
         AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
         AND EVENT != 'RPOS';
        -- AND AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2','CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5');
    L_CNT      NUMBER(4) := 1;
    PAC_NATIVE STTBS_ACCOUNT.AC_NATIVE%TYPE;
    LAC_NO     ACTBS_DAILY_LOG.AC_NO%TYPE;

    NUM_ACCT NUMBER;

    CURSOR CR_NET_ENTRIES(PTRNREFNO IN VARCHAR2, PEVENTSEQNO IN VARCHAR2) IS
      SELECT *
        FROM ACTBS_NETTING_TRANSACTION
       WHERE TRN_REF_NO = PTRNREFNO
         AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
         AND EVENT != 'RPOS';

    CURSOR CR_DEF_ENTRIES(PTRNREFNO IN VARCHAR2, PEVENTSEQNO IN VARCHAR2) IS
      SELECT *
        FROM ACTB_ENTRIES_HANDOFF
       WHERE TRN_REF_NO = PTRNREFNO
         AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
         AND EVENT != 'RPOS';

    LERR   ERTB_MSGS.ERR_CODE%TYPE;
    LPARAM ERTB_MSGS.MESSAGE%TYPE;

    L_CURR_USER SMTB_CURRENT_USERS.USER_ID%TYPE;
    L_CURR_BRN  STTM_BRANCH.BRANCH_CODE%TYPE;

  BEGIN

    IF NOT ACPKS.FN_SKIP_CUSTOM THEN
      DBG('Calling Acpks_Custom.fn_pre_acEntry_Retrieval');
      NUM_ACCT := ACPKS_CUSTOM.FN_PRE_ACENTRY_RETRIEVAL(PTRNREFNO,
                                                        PEVENTSEQNO,
                                                        PACENTS);

    END IF;

    IF NOT ACPKS.FN_SKIP_CLUSTER THEN
      DBG('Acpks_Cluster.fn_pre_acEntry_Retrieval');
      NUM_ACCT := ACPKS_CLUSTER.FN_PRE_ACENTRY_RETRIEVAL(PTRNREFNO,
                                                         PEVENTSEQNO,
                                                         PACENTS);

    END IF;

    IF NOT ACPKS.FN_SKIP_KERNEL THEN

      L_CURR_USER := GLOBAL.USER_ID;
      L_CURR_BRN  := GLOBAL.CURRENT_BRANCH;
      DBG('current user ' || L_CURR_USER);
      DBG('current brn ' || L_CURR_BRN);

      IF NOT ACPKS_UTILS.FN_DEFERREDHANDOFF('T',
                                            NULL,
                                            NULL,
                                            PTRNREFNO,
                                            PEVENTSEQNO,
                                            NULL,
                                            LERR,
                                            LPARAM) THEN
        DBG('Failed in  fn_DeferredHandoff Trn: ' || LERR || '~' ||
             LPARAM);
        OVPKSS.PR_APPENDTBL(LERR, LPARAM);
        RETURN 0;
      END IF;

      DBG('current user ' || L_CURR_USER);
      DBG('current brn ' || L_CURR_BRN);
      GLOBAL.PR_INIT(L_CURR_BRN, L_CURR_USER);

      FOR CREC IN CR_ENTRIES(PTRNREFNO, PEVENTSEQNO) LOOP
        LAC_NO := LTRIM(RTRIM(CREC.AC_NO));
        BEGIN

          IF GLOBALS_ADDON.INTERFACE_ID = 'FINWARE' OR
             GLOBALS_ADDON.INTERFACE_ID = 'BANCS' OR
             GLOBALS_ADDON.INTERFACE_ID = 'FLEXML'

           THEN
            BEGIN
              SELECT AC_NO
                INTO LAC_NO
                FROM ACTB_DAILY_GHOST_LOG
               WHERE TRN_REF_NO = PTRNREFNO
                 AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
                 AND AC_ENTRY_SR_NO = CREC.AC_ENTRY_SR_NO;
            EXCEPTION

              WHEN NO_DATA_FOUND THEN
                BEGIN
                  SELECT AC_NO
                    INTO LAC_NO
                    FROM ACTB_GHOST_HISTORY
                   WHERE TRN_REF_NO = PTRNREFNO
                     AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
                     AND AC_ENTRY_SR_NO = CREC.AC_ENTRY_SR_NO;
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('In WOT for Actb_Ghost_HISTORY : Not a Intersystem Bridge Gl account so not calling fn_ghost_entries');
                END;

              WHEN OTHERS THEN
                DBG('Not a Intersystem Bridge Gl account so not calling fn_ghost_entries');
                NULL;
            END;
          END IF;
        END;
        PACENTS(L_CNT) := L_EMPTY_HAND;
        PACENTS(L_CNT).TRN_REF_NO := CREC.TRN_REF_NO;
        PACENTS(L_CNT).EVENT_SR_NO := CREC.EVENT_SR_NO;
        PACENTS(L_CNT).EVENT := CREC.EVENT;
        PACENTS(L_CNT).AC_BRANCH := CREC.AC_BRANCH;
        PACENTS(L_CNT).AC_NO := LAC_NO;
        PACENTS(L_CNT).AC_CCY := CREC.AC_CCY;
        PACENTS(L_CNT).DRCR_IND := CREC.DRCR_IND;
        PACENTS(L_CNT).TRN_CODE := CREC.TRN_CODE;
        PACENTS(L_CNT).FCY_AMOUNT := CREC.FCY_AMOUNT;
        PACENTS(L_CNT).EXCH_RATE := CREC.EXCH_RATE;
        PACENTS(L_CNT).LCY_AMOUNT := CREC.LCY_AMOUNT;
        PACENTS(L_CNT).TRN_DT := CREC.TRN_DT;
        PACENTS(L_CNT).VALUE_DT := CREC.VALUE_DT;
        PACENTS(L_CNT).TXN_INIT_DATE := CREC.TXN_INIT_DATE;
        PACENTS(L_CNT).AMOUNT_TAG := CREC.AMOUNT_TAG;
        PACENTS(L_CNT).RELATED_CUSTOMER := CREC.RELATED_CUSTOMER;
        PACENTS(L_CNT).INSTRUMENT_CODE := CREC.INSTRUMENT_CODE;
        PACENTS(L_CNT).BANK_CODE := CREC.BANK_CODE;
        PACENTS(L_CNT).MIS_HEAD := CREC.MIS_HEAD;
        PACENTS(L_CNT).MODULE := CREC.MODULE;
        PACENTS(L_CNT).AUTH_STAT := CREC.AUTH_STAT;
        PACENTS(L_CNT).NETTING_IND := 'N';
        PACENTS(L_CNT).ORIG_PNL_GL := CREC.ORIG_PNL_GL;

        PACENTS(L_CNT).RELATED_ACCOUNT := CREC.RELATED_ACCOUNT;

        PACENTS(L_CNT).CUST_GL := CREC.CUST_GL;
        PACENTS(L_CNT).IB := CREC.IB;
        PACENTS(L_CNT).VIRTUAL_AC_NO := CREC.VIRTUAL_AC_NO;

        --PR_INIT_AC_OBJ_CUSTOM(PACENTS, CREC.AC_ENTRY_SR_NO);

        L_CNT := L_CNT + 1;
      END LOOP;

      IF PACENTS.COUNT = 0 THEN
        DBG('no row present in actb_daily_log as entries may not have been posted');
        FOR CREC IN CR_DEF_ENTRIES(PTRNREFNO, PEVENTSEQNO) LOOP
          LAC_NO := LTRIM(RTRIM(CREC.AC_NO));
          BEGIN

            IF GLOBAL_ADDON.INTERFACE_ID = 'FINWARE' OR
               GLOBAL_ADDON.INTERFACE_ID = 'BANCS' OR
               GLOBAL_ADDON.INTERFACE_ID = 'FLEXML'

             THEN
              BEGIN
                SELECT AC_NO
                  INTO LAC_NO
                  FROM ACTB_DAILY_GHOST_LOG
                 WHERE TRN_REF_NO = PTRNREFNO
                   AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
                   AND AC_ENTRY_SR_NO = CREC.AC_ENTRY_SR_NO;
              EXCEPTION

                WHEN NO_DATA_FOUND THEN
                  BEGIN
                    SELECT AC_NO
                      INTO LAC_NO
                      FROM ACTB_GHOST_HISTORY
                     WHERE TRN_REF_NO = PTRNREFNO
                       AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
                       AND AC_ENTRY_SR_NO = CREC.AC_ENTRY_SR_NO;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('In WOT for Actb_Ghost_HISTORY : Not a Intersystem Bridge Gl account so not calling fn_ghost_entries');
                  END;

                WHEN OTHERS THEN
                  DBG('Not a Intersystem Bridge Gl account so not calling fn_ghost_entries');
                  NULL;
              END;
            END IF;
          END;
          PACENTS(L_CNT) := L_EMPTY_HAND;
          PACENTS(L_CNT).TRN_REF_NO := CREC.TRN_REF_NO;
          PACENTS(L_CNT).EVENT_SR_NO := CREC.EVENT_SR_NO;
          PACENTS(L_CNT).EVENT := CREC.EVENT;
          PACENTS(L_CNT).AC_BRANCH := CREC.AC_BRANCH;
          PACENTS(L_CNT).AC_NO := LAC_NO;
          PACENTS(L_CNT).AC_CCY := CREC.AC_CCY;
          PACENTS(L_CNT).DRCR_IND := CREC.DRCR_IND;
          PACENTS(L_CNT).TRN_CODE := CREC.TRN_CODE;
          PACENTS(L_CNT).FCY_AMOUNT := CREC.FCY_AMOUNT;
          PACENTS(L_CNT).EXCH_RATE := CREC.EXCH_RATE;
          PACENTS(L_CNT).LCY_AMOUNT := CREC.LCY_AMOUNT;
          PACENTS(L_CNT).TRN_DT := CREC.TRN_DT;
          PACENTS(L_CNT).VALUE_DT := CREC.VALUE_DT;
          PACENTS(L_CNT).TXN_INIT_DATE := CREC.TXN_INIT_DATE;
          PACENTS(L_CNT).AMOUNT_TAG := CREC.AMOUNT_TAG;
          PACENTS(L_CNT).RELATED_CUSTOMER := CREC.RELATED_CUSTOMER;
          PACENTS(L_CNT).INSTRUMENT_CODE := CREC.INSTRUMENT_CODE;

          PACENTS(L_CNT).MIS_HEAD := CREC.MIS_HEAD;
          PACENTS(L_CNT).MODULE := CREC.MODULE;
          PACENTS(L_CNT).AUTH_STAT := CREC.AUTH_STAT;
          PACENTS(L_CNT).NETTING_IND := 'N';

          PACENTS(L_CNT).RELATED_ACCOUNT := CREC.RELATED_ACCOUNT;

          PACENTS(L_CNT).CUST_GL := CREC.CUST_GL;
          PACENTS(L_CNT).IB := CREC.IB;
          PACENTS(L_CNT).VIRTUAL_AC_NO := CREC.VIRTUAL_AC_NO;

          --PR_INIT_AC_OBJ_CUSTOM(PACENTS, CREC.AC_ENTRY_SR_NO);

          L_CNT := L_CNT + 1;
        END LOOP;
      END IF;

      DBG('before retrieving from actbs_netting_transaction : count:' ||
           PACENTS.COUNT);
      L_CNT := PACENTS.COUNT + 1;
      FOR CREC IN CR_NET_ENTRIES(PTRNREFNO, PEVENTSEQNO) LOOP
        LAC_NO := LTRIM(RTRIM(CREC.AC_NO));
        PACENTS(L_CNT) := L_EMPTY_HAND;
        PACENTS(L_CNT).TRN_REF_NO := CREC.TRN_REF_NO;
        PACENTS(L_CNT).EVENT_SR_NO := CREC.EVENT_SR_NO;
        PACENTS(L_CNT).EVENT := CREC.EVENT;
        PACENTS(L_CNT).AC_BRANCH := CREC.AC_BRANCH;
        PACENTS(L_CNT).AC_NO := LAC_NO;
        PACENTS(L_CNT).AC_CCY := CREC.AC_CCY;
        PACENTS(L_CNT).DRCR_IND := CREC.DRCR_IND;
        PACENTS(L_CNT).TRN_CODE := CREC.TRN_CODE;
        PACENTS(L_CNT).FCY_AMOUNT := CREC.FCY_AMOUNT;
        PACENTS(L_CNT).EXCH_RATE := CREC.EXCH_RATE;
        PACENTS(L_CNT).LCY_AMOUNT := CREC.LCY_AMOUNT;
        PACENTS(L_CNT).TRN_DT := CREC.TRN_DT;
        PACENTS(L_CNT).VALUE_DT := CREC.VALUE_DT;
        PACENTS(L_CNT).TXN_INIT_DATE := CREC.TXN_INIT_DATE;
        PACENTS(L_CNT).AMOUNT_TAG := CREC.AMOUNT_TAG;
        PACENTS(L_CNT).RELATED_CUSTOMER := CREC.RELATED_CUSTOMER;
        PACENTS(L_CNT).INSTRUMENT_CODE := CREC.INSTRUMENT_CODE;
        PACENTS(L_CNT).BANK_CODE := CREC.BANK_CODE;
        PACENTS(L_CNT).MIS_HEAD := CREC.MIS_HEAD;
        PACENTS(L_CNT).MODULE := CREC.MODULE;
        PACENTS(L_CNT).NETTING_IND := 'N';
        PACENTS(L_CNT).ORIG_PNL_GL := CREC.ORIG_PNL_GL;
        PACENTS(L_CNT).RELATED_ACCOUNT := CREC.RELATED_ACCOUNT;
        PACENTS(L_CNT).CUST_GL := CREC.CUST_GL;
        PACENTS(L_CNT).IB := CREC.IB;

        --PR_INIT_AC_OBJ_CUSTOM(PACENTS, CREC.AC_ENTRY_SR_NO);

        L_CNT := L_CNT + 1;
      END LOOP;
      DBG('after retrieving from actbs_netting_transaction : count:' ||
           PACENTS.COUNT);

    END IF;

    IF NOT ACPKS.FN_SKIP_CLUSTER THEN
      DBG('Acpks_Cluster.fn_post_acEntry_Retrieval');
      NUM_ACCT := ACPKS_CLUSTER.FN_POST_ACENTRY_RETRIEVAL(PTRNREFNO,
                                                          PEVENTSEQNO,
                                                          PACENTS);

    END IF;

    IF NOT ACPKS.FN_SKIP_CUSTOM THEN
      DBG('Calling Acpks_Custom.fn_post_acEntry_Retrieval');
      NUM_ACCT := ACPKS_CUSTOM.FN_POST_ACENTRY_RETRIEVAL(PTRNREFNO,
                                                         PEVENTSEQNO,
                                                         PACENTS);

    END IF;

    RETURN(PACENTS.COUNT);
  END FN_ACENTRY_RETRIEVAL_RFT;
  --NBC RFT Changes Ends
  
  --MoneyGram Changes Starts
  FUNCTION FN_ACENTRY_RETRIEVAL_MGT(PTRNREFNO   IN ACVWS_ALL_AC_ENTRIES.TRN_REF_NO%TYPE,
                                PEVENTSEQNO IN ACVWS_ALL_AC_ENTRIES.EVENT_SR_NO%TYPE,
                                PACENTS     OUT ACPKS.TBL_ACHOFF)
    RETURN NUMBER AS
    L_EMPTY_HAND ACTBS_HANDOFF%ROWTYPE;
    CURSOR CR_ENTRIES(PTRNREFNO IN VARCHAR2, PEVENTSEQNO IN VARCHAR2) IS
      SELECT *
        FROM ACVWS_ALL_AC_ENTRIES
       WHERE TRN_REF_NO = PTRNREFNO
         AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
         AND EVENT != 'RPOS';
        -- AND AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2','CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5');
    L_CNT      NUMBER(4) := 1;
    PAC_NATIVE STTBS_ACCOUNT.AC_NATIVE%TYPE;
    LAC_NO     ACTBS_DAILY_LOG.AC_NO%TYPE;

    NUM_ACCT NUMBER;

    CURSOR CR_NET_ENTRIES(PTRNREFNO IN VARCHAR2, PEVENTSEQNO IN VARCHAR2) IS
      SELECT *
        FROM ACTBS_NETTING_TRANSACTION
       WHERE TRN_REF_NO = PTRNREFNO
         AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
         AND EVENT != 'RPOS';

    CURSOR CR_DEF_ENTRIES(PTRNREFNO IN VARCHAR2, PEVENTSEQNO IN VARCHAR2) IS
      SELECT *
        FROM ACTB_ENTRIES_HANDOFF
       WHERE TRN_REF_NO = PTRNREFNO
         AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
         AND EVENT != 'RPOS';

    LERR   ERTB_MSGS.ERR_CODE%TYPE;
    LPARAM ERTB_MSGS.MESSAGE%TYPE;

    L_CURR_USER SMTB_CURRENT_USERS.USER_ID%TYPE;
    L_CURR_BRN  STTM_BRANCH.BRANCH_CODE%TYPE;

  BEGIN

    IF NOT ACPKS.FN_SKIP_CUSTOM THEN
      DBG('Calling Acpks_Custom.fn_pre_acEntry_Retrieval');
      NUM_ACCT := ACPKS_CUSTOM.FN_PRE_ACENTRY_RETRIEVAL(PTRNREFNO,
                                                        PEVENTSEQNO,
                                                        PACENTS);

    END IF;

    IF NOT ACPKS.FN_SKIP_CLUSTER THEN
      DBG('Acpks_Cluster.fn_pre_acEntry_Retrieval');
      NUM_ACCT := ACPKS_CLUSTER.FN_PRE_ACENTRY_RETRIEVAL(PTRNREFNO,
                                                         PEVENTSEQNO,
                                                         PACENTS);

    END IF;

    IF NOT ACPKS.FN_SKIP_KERNEL THEN

      L_CURR_USER := GLOBAL.USER_ID;
      L_CURR_BRN  := GLOBAL.CURRENT_BRANCH;
      DBG('current user ' || L_CURR_USER);
      DBG('current brn ' || L_CURR_BRN);

      IF NOT ACPKS_UTILS.FN_DEFERREDHANDOFF('T',
                                            NULL,
                                            NULL,
                                            PTRNREFNO,
                                            PEVENTSEQNO,
                                            NULL,
                                            LERR,
                                            LPARAM) THEN
        DBG('Failed in  fn_DeferredHandoff Trn: ' || LERR || '~' ||
             LPARAM);
        OVPKSS.PR_APPENDTBL(LERR, LPARAM);
        RETURN 0;
      END IF;

      DBG('current user ' || L_CURR_USER);
      DBG('current brn ' || L_CURR_BRN);
      GLOBAL.PR_INIT(L_CURR_BRN, L_CURR_USER);

      FOR CREC IN CR_ENTRIES(PTRNREFNO, PEVENTSEQNO) LOOP
        LAC_NO := LTRIM(RTRIM(CREC.AC_NO));
        BEGIN

          IF GLOBALS_ADDON.INTERFACE_ID = 'FINWARE' OR
             GLOBALS_ADDON.INTERFACE_ID = 'BANCS' OR
             GLOBALS_ADDON.INTERFACE_ID = 'FLEXML'

           THEN
            BEGIN
              SELECT AC_NO
                INTO LAC_NO
                FROM ACTB_DAILY_GHOST_LOG
               WHERE TRN_REF_NO = PTRNREFNO
                 AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
                 AND AC_ENTRY_SR_NO = CREC.AC_ENTRY_SR_NO;
            EXCEPTION

              WHEN NO_DATA_FOUND THEN
                BEGIN
                  SELECT AC_NO
                    INTO LAC_NO
                    FROM ACTB_GHOST_HISTORY
                   WHERE TRN_REF_NO = PTRNREFNO
                     AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
                     AND AC_ENTRY_SR_NO = CREC.AC_ENTRY_SR_NO;
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('In WOT for Actb_Ghost_HISTORY : Not a Intersystem Bridge Gl account so not calling fn_ghost_entries');
                END;

              WHEN OTHERS THEN
                DBG('Not a Intersystem Bridge Gl account so not calling fn_ghost_entries');
                NULL;
            END;
          END IF;
        END;
        PACENTS(L_CNT) := L_EMPTY_HAND;
        PACENTS(L_CNT).TRN_REF_NO := CREC.TRN_REF_NO;
        PACENTS(L_CNT).EVENT_SR_NO := CREC.EVENT_SR_NO;
        PACENTS(L_CNT).EVENT := CREC.EVENT;
        PACENTS(L_CNT).AC_BRANCH := CREC.AC_BRANCH;
        PACENTS(L_CNT).AC_NO := LAC_NO;
        PACENTS(L_CNT).AC_CCY := CREC.AC_CCY;
        PACENTS(L_CNT).DRCR_IND := CREC.DRCR_IND;
        PACENTS(L_CNT).TRN_CODE := CREC.TRN_CODE;
        PACENTS(L_CNT).FCY_AMOUNT := CREC.FCY_AMOUNT;
        PACENTS(L_CNT).EXCH_RATE := CREC.EXCH_RATE;
        PACENTS(L_CNT).LCY_AMOUNT := CREC.LCY_AMOUNT;
        PACENTS(L_CNT).TRN_DT := CREC.TRN_DT;
        PACENTS(L_CNT).VALUE_DT := CREC.VALUE_DT;
        PACENTS(L_CNT).TXN_INIT_DATE := CREC.TXN_INIT_DATE;
        PACENTS(L_CNT).AMOUNT_TAG := CREC.AMOUNT_TAG;
        PACENTS(L_CNT).RELATED_CUSTOMER := CREC.RELATED_CUSTOMER;
        PACENTS(L_CNT).INSTRUMENT_CODE := CREC.INSTRUMENT_CODE;
        PACENTS(L_CNT).BANK_CODE := CREC.BANK_CODE;
        PACENTS(L_CNT).MIS_HEAD := CREC.MIS_HEAD;
        PACENTS(L_CNT).MODULE := CREC.MODULE;
        PACENTS(L_CNT).AUTH_STAT := CREC.AUTH_STAT;
        PACENTS(L_CNT).NETTING_IND := 'N';
        PACENTS(L_CNT).ORIG_PNL_GL := CREC.ORIG_PNL_GL;

        PACENTS(L_CNT).RELATED_ACCOUNT := CREC.RELATED_ACCOUNT;

        PACENTS(L_CNT).CUST_GL := CREC.CUST_GL;
        PACENTS(L_CNT).IB := CREC.IB;
        PACENTS(L_CNT).VIRTUAL_AC_NO := CREC.VIRTUAL_AC_NO;

        --PR_INIT_AC_OBJ_CUSTOM(PACENTS, CREC.AC_ENTRY_SR_NO);

        L_CNT := L_CNT + 1;
      END LOOP;

      IF PACENTS.COUNT = 0 THEN
        DBG('no row present in actb_daily_log as entries may not have been posted');
        FOR CREC IN CR_DEF_ENTRIES(PTRNREFNO, PEVENTSEQNO) LOOP
          LAC_NO := LTRIM(RTRIM(CREC.AC_NO));
          BEGIN

            IF GLOBAL_ADDON.INTERFACE_ID = 'FINWARE' OR
               GLOBAL_ADDON.INTERFACE_ID = 'BANCS' OR
               GLOBAL_ADDON.INTERFACE_ID = 'FLEXML'

             THEN
              BEGIN
                SELECT AC_NO
                  INTO LAC_NO
                  FROM ACTB_DAILY_GHOST_LOG
                 WHERE TRN_REF_NO = PTRNREFNO
                   AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
                   AND AC_ENTRY_SR_NO = CREC.AC_ENTRY_SR_NO;
              EXCEPTION

                WHEN NO_DATA_FOUND THEN
                  BEGIN
                    SELECT AC_NO
                      INTO LAC_NO
                      FROM ACTB_GHOST_HISTORY
                     WHERE TRN_REF_NO = PTRNREFNO
                       AND EVENT_SR_NO = NVL(PEVENTSEQNO, EVENT_SR_NO)
                       AND AC_ENTRY_SR_NO = CREC.AC_ENTRY_SR_NO;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('In WOT for Actb_Ghost_HISTORY : Not a Intersystem Bridge Gl account so not calling fn_ghost_entries');
                  END;

                WHEN OTHERS THEN
                  DBG('Not a Intersystem Bridge Gl account so not calling fn_ghost_entries');
                  NULL;
              END;
            END IF;
          END;
          PACENTS(L_CNT) := L_EMPTY_HAND;
          PACENTS(L_CNT).TRN_REF_NO := CREC.TRN_REF_NO;
          PACENTS(L_CNT).EVENT_SR_NO := CREC.EVENT_SR_NO;
          PACENTS(L_CNT).EVENT := CREC.EVENT;
          PACENTS(L_CNT).AC_BRANCH := CREC.AC_BRANCH;
          PACENTS(L_CNT).AC_NO := LAC_NO;
          PACENTS(L_CNT).AC_CCY := CREC.AC_CCY;
          PACENTS(L_CNT).DRCR_IND := CREC.DRCR_IND;
          PACENTS(L_CNT).TRN_CODE := CREC.TRN_CODE;
          PACENTS(L_CNT).FCY_AMOUNT := CREC.FCY_AMOUNT;
          PACENTS(L_CNT).EXCH_RATE := CREC.EXCH_RATE;
          PACENTS(L_CNT).LCY_AMOUNT := CREC.LCY_AMOUNT;
          PACENTS(L_CNT).TRN_DT := CREC.TRN_DT;
          PACENTS(L_CNT).VALUE_DT := CREC.VALUE_DT;
          PACENTS(L_CNT).TXN_INIT_DATE := CREC.TXN_INIT_DATE;
          PACENTS(L_CNT).AMOUNT_TAG := CREC.AMOUNT_TAG;
          PACENTS(L_CNT).RELATED_CUSTOMER := CREC.RELATED_CUSTOMER;
          PACENTS(L_CNT).INSTRUMENT_CODE := CREC.INSTRUMENT_CODE;

          PACENTS(L_CNT).MIS_HEAD := CREC.MIS_HEAD;
          PACENTS(L_CNT).MODULE := CREC.MODULE;
          PACENTS(L_CNT).AUTH_STAT := CREC.AUTH_STAT;
          PACENTS(L_CNT).NETTING_IND := 'N';

          PACENTS(L_CNT).RELATED_ACCOUNT := CREC.RELATED_ACCOUNT;

          PACENTS(L_CNT).CUST_GL := CREC.CUST_GL;
          PACENTS(L_CNT).IB := CREC.IB;
          PACENTS(L_CNT).VIRTUAL_AC_NO := CREC.VIRTUAL_AC_NO;

          --PR_INIT_AC_OBJ_CUSTOM(PACENTS, CREC.AC_ENTRY_SR_NO);

          L_CNT := L_CNT + 1;
        END LOOP;
      END IF;

      DBG('before retrieving from actbs_netting_transaction : count:' ||
           PACENTS.COUNT);
      L_CNT := PACENTS.COUNT + 1;
      FOR CREC IN CR_NET_ENTRIES(PTRNREFNO, PEVENTSEQNO) LOOP
        LAC_NO := LTRIM(RTRIM(CREC.AC_NO));
        PACENTS(L_CNT) := L_EMPTY_HAND;
        PACENTS(L_CNT).TRN_REF_NO := CREC.TRN_REF_NO;
        PACENTS(L_CNT).EVENT_SR_NO := CREC.EVENT_SR_NO;
        PACENTS(L_CNT).EVENT := CREC.EVENT;
        PACENTS(L_CNT).AC_BRANCH := CREC.AC_BRANCH;
        PACENTS(L_CNT).AC_NO := LAC_NO;
        PACENTS(L_CNT).AC_CCY := CREC.AC_CCY;
        PACENTS(L_CNT).DRCR_IND := CREC.DRCR_IND;
        PACENTS(L_CNT).TRN_CODE := CREC.TRN_CODE;
        PACENTS(L_CNT).FCY_AMOUNT := CREC.FCY_AMOUNT;
        PACENTS(L_CNT).EXCH_RATE := CREC.EXCH_RATE;
        PACENTS(L_CNT).LCY_AMOUNT := CREC.LCY_AMOUNT;
        PACENTS(L_CNT).TRN_DT := CREC.TRN_DT;
        PACENTS(L_CNT).VALUE_DT := CREC.VALUE_DT;
        PACENTS(L_CNT).TXN_INIT_DATE := CREC.TXN_INIT_DATE;
        PACENTS(L_CNT).AMOUNT_TAG := CREC.AMOUNT_TAG;
        PACENTS(L_CNT).RELATED_CUSTOMER := CREC.RELATED_CUSTOMER;
        PACENTS(L_CNT).INSTRUMENT_CODE := CREC.INSTRUMENT_CODE;
        PACENTS(L_CNT).BANK_CODE := CREC.BANK_CODE;
        PACENTS(L_CNT).MIS_HEAD := CREC.MIS_HEAD;
        PACENTS(L_CNT).MODULE := CREC.MODULE;
        PACENTS(L_CNT).NETTING_IND := 'N';
        PACENTS(L_CNT).ORIG_PNL_GL := CREC.ORIG_PNL_GL;
        PACENTS(L_CNT).RELATED_ACCOUNT := CREC.RELATED_ACCOUNT;
        PACENTS(L_CNT).CUST_GL := CREC.CUST_GL;
        PACENTS(L_CNT).IB := CREC.IB;

        --PR_INIT_AC_OBJ_CUSTOM(PACENTS, CREC.AC_ENTRY_SR_NO);

        L_CNT := L_CNT + 1;
      END LOOP;
      DBG('after retrieving from actbs_netting_transaction : count:' ||
           PACENTS.COUNT);

    END IF;

    IF NOT ACPKS.FN_SKIP_CLUSTER THEN
      DBG('Acpks_Cluster.fn_post_acEntry_Retrieval');
      NUM_ACCT := ACPKS_CLUSTER.FN_POST_ACENTRY_RETRIEVAL(PTRNREFNO,
                                                          PEVENTSEQNO,
                                                          PACENTS);

    END IF;

    IF NOT ACPKS.FN_SKIP_CUSTOM THEN
      DBG('Calling Acpks_Custom.fn_post_acEntry_Retrieval');
      NUM_ACCT := ACPKS_CUSTOM.FN_POST_ACENTRY_RETRIEVAL(PTRNREFNO,
                                                         PEVENTSEQNO,
                                                         PACENTS);

    END IF;

    RETURN(PACENTS.COUNT);
  END FN_ACENTRY_RETRIEVAL_MGT;
  --MoneyGram Changes Ends
  
  FUNCTION FN_GET_TRCDETAILS(CREC             IN ACTBS_HANDOFF%ROWTYPE,
                             PERRCODE         IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                             PPARAM           IN OUT VARCHAR2,
                             P_FN_CALL_ID     IN OUT NUMBER,
                             P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside acpks_custom.fn_get_trcdetails');

    DBG('Returning Success From acpks_custom.fn_get_trcdetails');
    RETURN TRUE;
  END FN_GET_TRCDETAILS;

  FUNCTION FN_PRE_TXN_REVAL_ENTRIES(P_HOFFTBL           IN OUT ACPKS.TBL_ACHOFF,
                                    ENTRY_NO            IN NUMBER,
                                    P_TXN_REVAL_DETAILS IN VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Pre_Txn_Reval_Entries');
    DBG('Returning sucess Fn_Pre_Txn_Reval_Entries');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.Fn_Pre_Txn_Reval_Entriesd..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_TXN_REVAL_ENTRIES;

  FUNCTION FN_POST_TXN_REVAL_ENTRIES(P_HOFFTBL           IN OUT ACPKS.TBL_ACHOFF,
                                     ENTRY_NO            IN NUMBER,
                                     P_TXN_REVAL_DETAILS IN VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Post_Txn_Reval_Entries');
    DBG('Returning sucess Fn_Txn_Reval_Entries');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.Fn_Post_Txn_Reval_Entries.');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_POST_TXN_REVAL_ENTRIES;

  FUNCTION FN_PRE_WRITE_RECORD(CREC        IN OUT ACTBS_HANDOFF%ROWTYPE,
                               PACTIONCODE IN CHAR,
                               PBRANCHDATE IN DATE,
                               PUSERID     IN ACTBS_HANDOFF.USER_ID%TYPE,
                               PUPDACT     IN CHAR,
                               PSUSPENSE   IN CHAR,
                               PDEF_REQD   IN OUT BOOLEAN,
                               PERRCODE    IN OUT VARCHAR2,
                               PPARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Pre_Write_Record');
    DBG('Returning sucess Fn_Pre_Write_Record');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.Fn_Pre_Write_Record..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_WRITE_RECORD;

  FUNCTION FN_POST_WRITE_RECORD(CREC        IN OUT ACTBS_HANDOFF%ROWTYPE,
                                PACTIONCODE IN CHAR,
                                PBRANCHDATE IN DATE,
                                PUSERID     IN ACTBS_HANDOFF.USER_ID%TYPE,
                                PUPDACT     IN CHAR,
                                PSUSPENSE   IN CHAR,
                                PDEF_REQD   IN OUT BOOLEAN,
                                PERRCODE    IN OUT VARCHAR2,
                                PPARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Post_Write_Record');
    DBG('Returning sucess Fn_Post_Write_Record');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.Fn_Post_Write_Record..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_POST_WRITE_RECORD;

  FUNCTION FN_PRE_CHECK_THIS_IS_AN_ERROR(P_CALLING_FUNCTION IN VARCHAR2,
                                         PERRCODE           IN OUT VARCHAR2,
                                         PPARAM             IN OUT VARCHAR2,
                                         P_ERRFLAG          OUT BOOLEAN)
    RETURN BOOLEAN IS

  BEGIN
    DBG('Inside Fn_Pre_Check_This_Is_An_Error');
    DBG('Returning sucess Fn_Pre_Check_This_Is_An_Error');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.Fn_Pre_Check_This_Is_An_Error..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_CHECK_THIS_IS_AN_ERROR;

  FUNCTION FN_POST_CHECK_THIS_IS_AN_ERROR(P_CALLING_FUNCTION IN VARCHAR2,
                                          PERRCODE           IN OUT VARCHAR2,
                                          PPARAM             IN OUT VARCHAR2,
                                          P_ERRFLAG          OUT BOOLEAN)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Post_Check_This_Is_An_Error');
    DBG('Returning sucess Fn_Post_Check_This_Is_An_Error');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.Fn_Post_Check_This_Is_An_Error..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_POST_CHECK_THIS_IS_AN_ERROR;

  FUNCTION FN_PRE_VALIDATE_TRCODE(CREC     IN OUT ACTBS_HANDOFF%ROWTYPE,
                                  PERRCODE IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                  PPARAM   IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('inside Fn_pre_validate_trcode');
    RETURN TRUE;
  END FN_PRE_VALIDATE_TRCODE;

  FUNCTION FN_POST_VALIDATE_TRCODE(CREC             IN OUT ACTBS_HANDOFF%ROWTYPE,
                                   PERRCODE         IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                   PPARAM           IN OUT VARCHAR2,
                                   P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('inside Fn_post_validate_trcode');
    RETURN TRUE;
  END FN_POST_VALIDATE_TRCODE;

  FUNCTION FN_UPDATECUSTBAL(PBRANCH           IN ACTBS_HANDOFF.AC_BRANCH%TYPE,
                            PACCOUNT          IN ACTBS_HANDOFF.AC_NO%TYPE,
                            PACLASS           IN STTBS_ACCOUNT.AC_CLASS%TYPE,
                            PTRNREFNO         IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                            PACCCCY           IN ACTBS_HANDOFF.AC_CCY%TYPE,
                            PLCYAMT           IN ACTBS_HANDOFF.LCY_AMOUNT%TYPE,
                            PFCYAMT           IN ACTBS_HANDOFF.FCY_AMOUNT%TYPE,
                            PLCY              IN ACTBS_HANDOFF.AC_CCY%TYPE,
                            PBRDATE           IN DATE,
                            PUNCOL            IN CHAR,
                            PDRCR_IND         IN CHAR,
                            PACTIONCODE       IN CHAR,
                            PUPDACT           IN CHAR,
                            PTRACKIC          IN CHAR,
                            PUPDBAL           IN OUT CHAR,
                            PLMTCHECK         IN CHAR,
                            PAVL_AMT          IN OUT NUMBER,
                            P_FN_CALL_ID      IN OUT NUMBER,
                            P_TB_CLUSTER_DATA IN OUT GLOBAL.TY_TB_CLUSTER_DATA,
                            P_BALREC          IN OUT ACPKS.BALREC,
                            PERRCODE          IN OUT VARCHAR2,
                            PPARAM            IN OUT VARCHAR2)
    RETURN VARCHAR2 IS

  BEGIN
    RETURN 'S';
  END FN_UPDATECUSTBAL;

  FUNCTION FN_PRE_ACHANDOFF(PTXNBRANCH  IN ACTBS_HANDOFF.AC_BRANCH%TYPE,
                            PTRNREFNO   IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                            PEVENTSEQNO IN ACTBS_HANDOFF.EVENT_SR_NO%TYPE,
                            PBRANCHDATE IN DATE,
                            PHANDOFF    IN OUT ACPKS.TBL_ACHOFF,
                            PACTIONCODE IN CHAR,
                            PSUSPENSE   IN CHAR,
                            PBALANCING  IN CHAR,
                            PUSERID     IN CHAR,
                            PERRCODE    IN OUT VARCHAR2,
                            PPARAM      IN OUT VARCHAR2) RETURN BOOLEAN AS
  BEGIN
    DBG('In acpks_custom.Fn_pre_Achandoff..B');

    DBG('Returning Success From acpks_custom.Fn_pre_Achandoff B');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.Fn_pre_Achandoff ..B');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_ACHANDOFF;

  FUNCTION FN_POST_ACHANDOFF(PTXNBRANCH  IN ACTBS_HANDOFF.AC_BRANCH%TYPE,
                             PTRNREFNO   IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                             PEVENTSEQNO IN ACTBS_HANDOFF.EVENT_SR_NO%TYPE,
                             PBRANCHDATE IN DATE,
                             PHANDOFF    IN OUT ACPKS.TBL_ACHOFF,
                             PACTIONCODE IN CHAR,
                             PSUSPENSE   IN CHAR,
                             PBALANCING  IN CHAR,
                             PUSERID     IN CHAR,
                             PERRCODE    IN OUT VARCHAR2,
                             PPARAM      IN OUT VARCHAR2) RETURN BOOLEAN AS
  BEGIN
    DBG('In acpks_custom.Fn_post_Achandoff..B');

    DBG('Returning Success From acpks_custom.Fn_post_Achandoff B');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.Fn_post_Achandoff ..B');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_POST_ACHANDOFF;

  FUNCTION FN_PRE_ACHANDOFF(PTRNREFNO   IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                            PEVENTSEQNO IN ACTBS_HANDOFF.EVENT_SR_NO%TYPE,
                            PBRANCHDATE IN DATE,
                            PHANDOFF    IN OUT ACPKS.TBL_ACHOFF,
                            PACTIONCODE IN CHAR,
                            PSUSPENSE   IN CHAR,
                            PBALANCING  IN CHAR,
                            PUSERID     IN CHAR,
                            PERRCODE    IN OUT VARCHAR2,
                            PPARAM      IN OUT VARCHAR2) RETURN BOOLEAN AS
  BEGIN

    DBG('In acpks_custom.Fn_pre_Achandoff..');

    DBG('Returning Success From acpks_custom.Fn_pre_Achandoff');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.Fn_pre_Achandoff ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_ACHANDOFF;

  FUNCTION FN_POST_ACHANDOFF(PTRNREFNO   IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                             PEVENTSEQNO IN ACTBS_HANDOFF.EVENT_SR_NO%TYPE,
                             PBRANCHDATE IN DATE,
                             PHANDOFF    IN OUT ACPKS.TBL_ACHOFF,
                             PACTIONCODE IN CHAR,
                             PSUSPENSE   IN CHAR,
                             PBALANCING  IN CHAR,
                             PUSERID     IN CHAR,
                             PERRCODE    IN OUT VARCHAR2,
                             PPARAM      IN OUT VARCHAR2) RETURN BOOLEAN AS
  BEGIN

    DBG('In acpks_custom.Fn_post_Achandoff..');

    DBG('Returning Success From acpks_custom.Fn_post_Achandoff');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.Fn_post_Achandoff ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_POST_ACHANDOFF;

  FUNCTION FN_PRE_ACSERVICE1(PBRANCH     IN ACTBS_HANDOFF.AC_BRANCH%TYPE,
                             PBRANCHDATE IN DATE,
                             PLCY        IN ACTBS_HANDOFF.AC_CCY%TYPE,
                             PTRANREFNO  IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                             PRELACC     IN ACTBS_HANDOFF.RELATED_ACCOUNT%TYPE,
                             PBASIS      IN CHAR DEFAULT 'T',
                             PEVENTSEQNO IN ACTBS_HANDOFF.EVENT_SR_NO%TYPE,
                             PACTIONCODE IN CHAR,
                             PUSERID     IN ACTBS_HANDOFF.USER_ID%TYPE,
                             PERRCODE    IN OUT VARCHAR2,
                             PPARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_Pre_acservice1');
    DBG('Returning sucess fn_Pre_acservice1');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.Fn_Pre_acservice1..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_ACSERVICE1;

  FUNCTION FN_POST_ACSERVICE1(PBRANCH     IN ACTBS_HANDOFF.AC_BRANCH%TYPE,
                              PBRANCHDATE IN DATE,
                              PLCY        IN ACTBS_HANDOFF.AC_CCY%TYPE,
                              PTRANREFNO  IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                              PRELACC     IN ACTBS_HANDOFF.RELATED_ACCOUNT%TYPE,
                              PBASIS      IN CHAR DEFAULT 'T',
                              PEVENTSEQNO IN ACTBS_HANDOFF.EVENT_SR_NO%TYPE,
                              PACTIONCODE IN CHAR,
                              PUSERID     IN ACTBS_HANDOFF.USER_ID%TYPE,
                              PERRCODE    IN OUT VARCHAR2,
                              PPARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Post_acservice1');
    DBG('Returning sucess Fn_Post_acservice1');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.Fn_Post_acservice1..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_POST_ACSERVICE1;

  FUNCTION FN_UPDATECUSTBAL(PBRANCH          IN ACTBS_HANDOFF.AC_BRANCH%TYPE,
                            PACCOUNT         IN ACTBS_HANDOFF.AC_NO%TYPE,
                            PACLASS          IN STTBS_ACCOUNT.AC_CLASS%TYPE,
                            PTRNREFNO        IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                            PACCCCY          IN ACTBS_HANDOFF.AC_CCY%TYPE,
                            PLCYAMT          IN ACTBS_HANDOFF.LCY_AMOUNT%TYPE,
                            PFCYAMT          IN ACTBS_HANDOFF.FCY_AMOUNT%TYPE,
                            PLCY             IN ACTBS_HANDOFF.AC_CCY%TYPE,
                            PBRDATE          IN DATE,
                            PUNCOL           IN CHAR,
                            PDRCR_IND        IN CHAR,
                            PACTIONCODE      IN CHAR,
                            PUPDACT          IN CHAR,
                            PTRACKIC         IN CHAR,
                            PUPDBAL          IN OUT CHAR,
                            PLMTCHECK        IN CHAR,
                            PAVL_AMT         IN OUT NUMBER,
                            P_FN_CALL_ID     IN NUMBER,
                            P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                            PERRCODE         IN OUT VARCHAR2,
                            PPARAM           IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Start of acpks_custom.Fn_Updatecustbal');

    DBG('End  of acpks_custom.Fn_Updatecustbal');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in acpks_custom.Fn_Updatecustbal');
      RETURN FALSE;
  END FN_UPDATECUSTBAL;

  FUNCTION FN_UPDATECUSTBAL_CHECK(P_FN_CALL_ID     IN NUMBER,
                                  P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                                  P_ERR_CODE       IN OUT VARCHAR2,
                                  P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start  of acpks_custom.Fn_Updatecustbal_Check');

    DBG('End  of acpks_custom.Fn_Updatecustbal_Check');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in acpks_custom.Fn_Updatecustbal_Check');
      RETURN FALSE;
  END FN_UPDATECUSTBAL_CHECK;

  FUNCTION FN_PRE_ACENTRY_RETRIEVAL(PTRNREFNO   IN ACVWS_ALL_AC_ENTRIES.TRN_REF_NO%TYPE,
                                    PEVENTSEQNO IN ACVWS_ALL_AC_ENTRIES.EVENT_SR_NO%TYPE,
                                    PACENTS     IN OUT ACPKS.TBL_ACHOFF)
    RETURN NUMBER IS
  BEGIN
    DBG('Inside fn_Pre_acEntry_Retrieval');
    RETURN(PACENTS.COUNT);
  END FN_PRE_ACENTRY_RETRIEVAL;

  FUNCTION FN_POST_ACENTRY_RETRIEVAL(PTRNREFNO   IN ACVWS_ALL_AC_ENTRIES.TRN_REF_NO%TYPE,
                                     PEVENTSEQNO IN ACVWS_ALL_AC_ENTRIES.EVENT_SR_NO%TYPE,
                                     PACENTS     IN OUT ACPKS.TBL_ACHOFF)
    RETURN NUMBER IS
  BEGIN
    DBG('Inside fn_Post_acEntry_Retrieval');
    RETURN(PACENTS.COUNT);
  END FN_POST_ACENTRY_RETRIEVAL;

  FUNCTION FN_PRE_ACENTRY_RETRIEVAL(PTRNREFNO   IN ACVWS_ALL_AC_ENTRIES.TRN_REF_NO%TYPE,
                                    PEVENTSEQNO IN ACVWS_ALL_AC_ENTRIES.EVENT_SR_NO%TYPE,
                                    PTRNDT      IN ACVWS_ALL_AC_ENTRIES.TRN_DT%TYPE,
                                    PVALDT      IN ACVWS_ALL_AC_ENTRIES.VALUE_DT%TYPE,
                                    PACENTS     IN OUT ACPKS.TBL_ACHOFF)
    RETURN NUMBER IS
  BEGIN
    DBG('Inside fn_Pre_acEntry_Retrieval');
    RETURN(PACENTS.COUNT);
  END FN_PRE_ACENTRY_RETRIEVAL;

  FUNCTION FN_POST_ACENTRY_RETRIEVAL(PTRNREFNO   IN ACVWS_ALL_AC_ENTRIES.TRN_REF_NO%TYPE,
                                     PEVENTSEQNO IN ACVWS_ALL_AC_ENTRIES.EVENT_SR_NO%TYPE,
                                     PTRNDT      IN ACVWS_ALL_AC_ENTRIES.TRN_DT%TYPE,
                                     PVALDT      IN ACVWS_ALL_AC_ENTRIES.VALUE_DT%TYPE,
                                     PACENTS     IN OUT ACPKS.TBL_ACHOFF)
    RETURN NUMBER IS
  BEGIN
    DBG('Inside fn_Post_acEntry_Retrieval');
    RETURN(PACENTS.COUNT);
  END FN_POST_ACENTRY_RETRIEVAL;

  PROCEDURE PR_PRE_INIT_AC_OBJ_CUSTOM(PACENTS      IN OUT ACPKS.TBL_ACHOFF,
                                      PACENTRYSRNO IN ACTB_DAILY_LOG.TRN_REF_NO%TYPE) IS
  BEGIN
    DBG('Inside Pr_pre_init_ac_obj_custom');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of Pr_pre_init_ac_obj_custom');
      DBG('Error :' || SQLERRM);
  END PR_PRE_INIT_AC_OBJ_CUSTOM;

  PROCEDURE PR_POST_INIT_AC_OBJ_CUSTOM(PACENTS      IN OUT ACPKS.TBL_ACHOFF,
                                       PACENTRYSRNO IN ACTB_DAILY_LOG.TRN_REF_NO%TYPE) IS
  BEGIN
    DBG('Inside Pr_post_init_ac_obj_custom');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of Pr_post_init_ac_obj_custom');
      DBG('Error :' || SQLERRM);
  END PR_POST_INIT_AC_OBJ_CUSTOM;

  FUNCTION FN_PRE_RESOLVE_IB(CREC        IN OUT ACTBS_HANDOFF%ROWTYPE,
                             L_CONSTBL   IN OUT ACPKS.TBL_ACHOFF,
                             P_TMP_XRATE IN OUT ACTBS_DAILY_LOG.EXCH_RATE%TYPE,
                             PERRCODE    IN OUT VARCHAR2,
                             PPARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Start  of acpks_custom.Fn_Pre_Resolve_Ib');
    DBG('End  of acpks_custom.Fn_Pre_Resolve_Ib');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in acpks_custom.Fn_Pre_Resolve_Ib');
      RETURN FALSE;
  END FN_PRE_RESOLVE_IB;

  FUNCTION FN_POST_RESOLVE_IB(CREC        IN OUT ACTBS_HANDOFF%ROWTYPE,
                              L_CONSTBL   IN OUT ACPKS.TBL_ACHOFF,
                              P_TMP_XRATE IN OUT ACTBS_DAILY_LOG.EXCH_RATE%TYPE,
                              PERRCODE    IN OUT VARCHAR2,
                              PPARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Start  of acpks_custom.Fn_Post_Resolve_Ib');
    DBG('End  of acpks_custom.Fn_Post_Resolve_Ib');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in acpks_custom.Fn_Post_Resolve_Ib');
      RETURN FALSE;
  END FN_POST_RESOLVE_IB;

  FUNCTION FN_PRE_UPDATECUSTBAL_CHECK(P_ERR_CODE  IN OUT VARCHAR2,
                                      P_ERR_PARAM IN OUT VARCHAR2)
    RETURN NUMBER IS
  BEGIN
    DBG('Inside Fn_Pre_Updatecustbal_Check');
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in Fn_Pre_Updatecustbal_Check ' || SQLERRM);
      RETURN - 1;
  END FN_PRE_UPDATECUSTBAL_CHECK;

  FUNCTION FN_POST_UPDATECUSTBAL_CHECK(P_ERR_CODE  IN OUT VARCHAR2,
                                       P_ERR_PARAM IN OUT VARCHAR2)
    RETURN NUMBER IS
  BEGIN
    DBG('Inside Fn_Post_Updatecustbal_Check');
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in Fn_Post_Updatecustbal_Check ' || SQLERRM);
      RETURN - 1;
  END FN_POST_UPDATECUSTBAL_CHECK;

  FUNCTION FN_PRE_UPDATECUSTBAL(PBRANCH     IN ACTBS_HANDOFF.AC_BRANCH%TYPE,
                                PACCOUNT    IN ACTBS_HANDOFF.AC_NO%TYPE,
                                PACLASS     IN STTBS_ACCOUNT.AC_CLASS%TYPE,
                                PTRNREFNO   IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                                PACCCCY     IN ACTBS_HANDOFF.AC_CCY%TYPE,
                                PLCYAMT     IN ACTBS_HANDOFF.LCY_AMOUNT%TYPE,
                                PFCYAMT     IN ACTBS_HANDOFF.FCY_AMOUNT%TYPE,
                                PLCY        IN ACTBS_HANDOFF.AC_CCY%TYPE,
                                PBRDATE     IN DATE,
                                PUNCOL      IN CHAR,
                                PDRCR_IND   IN CHAR,
                                PACTIONCODE IN CHAR,
                                PUPDACT     IN CHAR,
                                PTRACKIC    IN CHAR,
                                PUPDBAL     IN OUT CHAR,
                                PLMTCHECK   IN CHAR,
                                PAVL_AMT    IN OUT NUMBER,
                                PERRCODE    IN OUT VARCHAR2,
                                PPARAM      IN OUT VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    DBG('Inside Fn_Pre_updatecustbal');
    RETURN 'S';
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in Fn_Pre_updatecustbal ' || SQLERRM);
      RETURN 'F';
  END FN_PRE_UPDATECUSTBAL;

  FUNCTION FN_POST_UPDATECUSTBAL(PBRANCH     IN ACTBS_HANDOFF.AC_BRANCH%TYPE,
                                 PACCOUNT    IN ACTBS_HANDOFF.AC_NO%TYPE,
                                 PACLASS     IN STTBS_ACCOUNT.AC_CLASS%TYPE,
                                 PTRNREFNO   IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                                 PACCCCY     IN ACTBS_HANDOFF.AC_CCY%TYPE,
                                 PLCYAMT     IN ACTBS_HANDOFF.LCY_AMOUNT%TYPE,
                                 PFCYAMT     IN ACTBS_HANDOFF.FCY_AMOUNT%TYPE,
                                 PLCY        IN ACTBS_HANDOFF.AC_CCY%TYPE,
                                 PBRDATE     IN DATE,
                                 PUNCOL      IN CHAR,
                                 PDRCR_IND   IN CHAR,
                                 PACTIONCODE IN CHAR,
                                 PUPDACT     IN CHAR,
                                 PTRACKIC    IN CHAR,
                                 PUPDBAL     IN OUT CHAR,
                                 PLMTCHECK   IN CHAR,
                                 PAVL_AMT    IN OUT NUMBER,
                                 PERRCODE    IN OUT VARCHAR2,
                                 PPARAM      IN OUT VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    DBG('Inside Fn_Post_updatecustbal');
    RETURN 'S';
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in Fn_Post_updatecustbal ' || SQLERRM);
      RETURN 'F';
  END FN_POST_UPDATECUSTBAL;

  FUNCTION ACFN_PRE_NET(L_MODTBL IN OUT ACPKS.TBL_ACHOFF) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside acfn_pre_net');
    DBG('End  of acpks_custom.acfn_pre_net');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in acpks_clustom.acfn_pre_net');
      RETURN FALSE;
  END ACFN_PRE_NET;

  FUNCTION ACFN_POST_NET(L_MODTBL IN OUT ACPKS.TBL_ACHOFF) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside acfn_post_net');
    DBG('End  of acpks_custom.acfn_post_net');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in acpks_custom.acfn_post_net');
      RETURN FALSE;
  END ACFN_POST_NET;

  FUNCTION FN_PRE_AUTO_GENERATE(PFORAUTOGENERATION    IN ACPKS.TBL_ACHOFF,
                                PMISMATCHTYPE         IN CHAR,
                                PWHATTHEUSERWANTS     IN CHAR,
                                PAUTOGENERATEDENTRIES IN OUT ACPKS.TBL_ACHOFF,
                                PMISENTRIES           OUT MITBS_CLASS_MAPPING%ROWTYPE,
                                PMISFLAG              OUT BOOLEAN,
                                PERRCODE              IN OUT VARCHAR2,
                                PPARAM                IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_pre_Auto_Generate');
    DBG('End  of acpks_custom.Fn_pre_Auto_Generate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in acpks_custom.Fn_pre_Auto_Generate');
      RETURN FALSE;
  END FN_PRE_AUTO_GENERATE;

  FUNCTION FN_POST_AUTO_GENERATE(PFORAUTOGENERATION    IN ACPKS.TBL_ACHOFF,
                                 PMISMATCHTYPE         IN CHAR,
                                 PWHATTHEUSERWANTS     IN CHAR,
                                 PAUTOGENERATEDENTRIES IN OUT ACPKS.TBL_ACHOFF,
                                 PMISENTRIES           OUT MITBS_CLASS_MAPPING%ROWTYPE,
                                 PMISFLAG              OUT BOOLEAN,
                                 PERRCODE              IN OUT VARCHAR2,
                                 PPARAM                IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_post_Auto_Generate');
    DBG('End  of acpks_custom.Fn_post_Auto_Generate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in acpks_cluster.Fn_post_Auto_Generate');
      RETURN FALSE;
  END FN_POST_AUTO_GENERATE;

  FUNCTION FN_UPDATECUSTBAL_NEW(PBRANCH          IN ACTBS_HANDOFF.AC_BRANCH%TYPE,
                                PACCOUNT         IN ACTBS_HANDOFF.AC_NO%TYPE,
                                PACLASS          IN STTBS_ACCOUNT.AC_CLASS%TYPE,
                                PTRNREFNO        IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                                PACCCCY          IN ACTBS_HANDOFF.AC_CCY%TYPE,
                                PLCYAMT          IN ACTBS_HANDOFF.LCY_AMOUNT%TYPE,
                                PFCYAMT          IN ACTBS_HANDOFF.FCY_AMOUNT%TYPE,
                                PLCY             IN ACTBS_HANDOFF.AC_CCY%TYPE,
                                PBRDATE          IN DATE,
                                PUNCOL           IN CHAR,
                                PDRCR_IND        IN CHAR,
                                PACTIONCODE      IN CHAR,
                                PUPDACT          IN CHAR,
                                PTRACKIC         IN CHAR,
                                PUPDBAL          IN OUT CHAR,
                                PLMTCHECK        IN CHAR,
                                PAVL_AMT         IN OUT NUMBER,
                                PERRCODE         IN OUT VARCHAR2,
                                PPARAM           IN OUT VARCHAR2,
                                P_SWEEP_IN       IN OUT STTMS_CUST_ACCOUNT.SWEEP_REQUIRED%TYPE,
                                P_REVSWEEP_IN    IN OUT STTMS_CUST_ACCOUNT.SWEEP_REQUIRED%TYPE,
                                P_FN_CALL_ID     IN OUT NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside acpks_Custom.fn_updatecustbal...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of acpks_custom.fn_updatecustbal..' || SQLERRM);
      RETURN FALSE;
  END FN_UPDATECUSTBAL_NEW;

  FUNCTION FN_PRE_CALC_BRN_PROFIT(P_IS_ROW          IN ACPKSS.TY_TB_BRN_PROF,
                                  P_TAG_AC_BRANCH   IN VARCHAR2,
                                  P_TXN_AMT         IN NUMBER,
                                  P_DRCR_IND        IN VARCHAR2,
                                  P_BRANCH_LCY      IN VARCHAR2,
                                  P_REVAL_RATE_CODE IN CYTMS_RATE_TYPE.CCY_RATE_TYPE%TYPE,
                                  P_RATE_TYPE_IND   IN VARCHAR2,
                                  P_REVAL_AMT       IN OUT NUMBER,
                                  P_ERROR_CODE      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_pre_calc_brn_profit');
    DBG('Returning true from fn_pre_calc_brn_profit');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when other of fn_pre_calc_brn_profit due to ' || SQLERRM);
      RETURN FALSE;
  END FN_PRE_CALC_BRN_PROFIT;

  FUNCTION FN_POST_CALC_BRN_PROFIT(P_IS_ROW          IN ACPKSS.TY_TB_BRN_PROF,
                                   P_TAG_AC_BRANCH   IN VARCHAR2,
                                   P_TXN_AMT         IN NUMBER,
                                   P_DRCR_IND        IN VARCHAR2,
                                   P_BRANCH_LCY      IN VARCHAR2,
                                   P_REVAL_RATE_CODE IN CYTMS_RATE_TYPE.CCY_RATE_TYPE%TYPE,
                                   P_RATE_TYPE_IND   IN VARCHAR2,
                                   P_REVAL_AMT       IN OUT NUMBER,
                                   P_ERROR_CODE      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_post_calc_brn_profit');
    DBG('Returning true from fn_post_calc_brn_profit');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when other of fn_post_calc_brn_profit due to ' || SQLERRM);
      RETURN FALSE;
  END FN_POST_CALC_BRN_PROFIT;

  FUNCTION FN_POST_AUTH_BATCH(PBRANCH            IN ACTBS_DAILY_LOG.AC_BRANCH%TYPE,
                              P_BATCHNO          IN DETBS_BATCH_MASTER.BATCH_NO%TYPE,
                              P_CURR_USERID      IN ACTBS_DAILY_LOG.AUTH_ID%TYPE,
                              P_APPLICATION_DATE IN DATE,
                              P_ERR_CODE         IN OUT VARCHAR2,
                              P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_post_auth_batch');
    DBG('Returning sucess fn_post_auth_batch');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of acpks_custom.fn_post_auth_batch.');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_POST_AUTH_BATCH;

  FUNCTION FN_POST_ASSIGN_DFLT(CREC             IN OUT ACTBS_HANDOFF%ROWTYPE,
                               P_FN_CALL_ID     IN OUT NUMBER,
                               P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                               PERRCODE         IN OUT VARCHAR2,
                               PPARAM           IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_post_assign_dflt');
    DBG('Returning true from fn_post_assign_dflt');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when other of fn_post_assign_dflt due to ' || SQLERRM);
      RETURN FALSE;
  END FN_POST_ASSIGN_DFLT;

  FUNCTION FN_PRE_ASSIGN_DFLT(CREC             IN OUT ACTBS_HANDOFF%ROWTYPE,
                              P_FN_CALL_ID     IN OUT NUMBER,
                              P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                              PERRCODE         IN OUT VARCHAR2,
                              PPARAM           IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_pre_assign_dflt');
    DBG('Returning true from fn_pre_assign_dflt');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when other of fn_pre_assign_dflt due to ' || SQLERRM);
      RETURN FALSE;
  END FN_PRE_ASSIGN_DFLT;

  PROCEDURE PR_PRE_SET_REVERSALFLAG(PTRNREFNO     IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                                    PEVENTSEQNO   IN ACTBS_HANDOFF.EVENT_SR_NO%TYPE,
                                    CREC          IN ACTBS_HANDOFF%ROWTYPE,
                                    P_IS_REVERSAL IN OUT BOOLEAN) IS
  BEGIN
    DBG('Inside pr_pre_Set_ReversalFlag');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of pr_pre_Set_ReversalFlag');
      DBG('Error :' || SQLERRM);
  END PR_PRE_SET_REVERSALFLAG;

  PROCEDURE PR_POST_SET_REVERSALFLAG(PTRNREFNO     IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                                     PEVENTSEQNO   IN ACTBS_HANDOFF.EVENT_SR_NO%TYPE,
                                     CREC          IN ACTBS_HANDOFF%ROWTYPE,
                                     P_IS_REVERSAL IN OUT BOOLEAN) IS
  BEGIN
    DBG('Inside pr_post_Set_ReversalFlag');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of pr_post_Set_ReversalFlag');
      DBG('Error :' || SQLERRM);
  END PR_POST_SET_REVERSALFLAG;

  FUNCTION FN_VALIDATE_TRCODE(CREC             IN OUT ACTBS_HANDOFF%ROWTYPE,
                              PERRCODE         IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                              PPARAM           IN OUT VARCHAR2,
                              P_FN_CALL_ID     IN OUT NUMBER,
                              P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_validate_trcode');
    DBG('Returning true from fn_validate_trcode');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when other of fn_validate_trcode due to ' || SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE_TRCODE;

  FUNCTION FN_UPDATE_UNCOL(PBRANCH          IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                           PACCOUNT         IN ACTBS_HANDOFF.AC_NO%TYPE,
                           PAVLDATE         IN DATE,
                           PAMOUNT          IN ACTBS_HANDOFF.LCY_AMOUNT%TYPE,
                           PTRNREFNO        IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                           PEVENTSEQNO      IN ACTBS_HANDOFF.EVENT_SR_NO%TYPE,
                           PTRNCODE         IN STTMS_TRN_CODE.TRN_CODE%TYPE,
                           PBANKCODE        IN ACTBS_HANDOFF.BANK_CODE%TYPE DEFAULT 'UNDEFINED',
                           PACTIONCODE      IN CHAR,
                           PERRCODE         IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                           PPARAM           IN OUT VARCHAR2,
                           PUNCOLPKEY       IN OUT ACTB_FUNCOL.PKEY%TYPE,
                           PACENTRYSRNO     IN NUMBER DEFAULT NULL,
                           PPRDPROCESSOR    IN VARCHAR2 DEFAULT 'FC',
                           P_FN_CALL_ID     IN OUT NUMBER,
                           P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_update_uncol');
    DBG('Returning true from fn_update_uncol');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when other of fn_update_uncol due to ' || SQLERRM);
      RETURN FALSE;
  END FN_UPDATE_UNCOL;

  FUNCTION FN_ACSERVICE1(PBRANCH          IN ACTBS_HANDOFF.AC_BRANCH%TYPE,
                         PBRANCHDATE      IN DATE,
                         PLCY             IN ACTBS_HANDOFF.AC_CCY%TYPE,
                         PTRANREFNO       IN ACTBS_HANDOFF.TRN_REF_NO%TYPE,
                         PRELACC          IN ACTBS_HANDOFF.RELATED_ACCOUNT%TYPE,
                         PBASIS           IN CHAR DEFAULT 'T',
                         PEVENTSEQNO      IN ACTBS_HANDOFF.EVENT_SR_NO%TYPE,
                         PACTIONCODE      IN CHAR,
                         PUSERID          IN ACTBS_HANDOFF.USER_ID%TYPE,
                         PERRCODE         IN OUT VARCHAR2,
                         PPARAM           IN OUT VARCHAR2,
                         P_FN_CALL_ID     IN OUT NUMBER,
                         P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_acservice1');
    DBG('Returning true from fn_acservice1');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when other of fn_acservice1 due to ' || SQLERRM);
      RETURN FALSE;
  END FN_ACSERVICE1;

  FUNCTION FN_BUILD_MISMATCH_AND_POS(CREC                 IN OUT NOCOPY ACTBS_HANDOFF%ROWTYPE,
                                     TBL_POS_CURR_NO      IN BINARY_INTEGER,
                                     IN_LOOP_FOR_AUTOGEN  IN OUT BOOLEAN,
                                     IN_LOOP_FOR_POSITION IN OUT BOOLEAN,
                                     LOOP_FOR_POSITION    IN OUT BOOLEAN,
                                     PBALANCING           IN CHAR,
                                     P_MISFLAG            IN OUT BOOLEAN,
                                     P_MISENTRIES         IN OUT MITBS_CLASS_MAPPING%ROWTYPE,
                                     P_HOFF               IN OUT ACPKS.TBL_ACHOFF,
                                     PKG_IBPOSITION       IN ACPKS.TBL_ACHOFF,
                                     PERRCODE             IN OUT VARCHAR2,
                                     PPARAM               IN OUT VARCHAR2,
                                     P_FN_CALL_ID         IN OUT NUMBER,
                                     P_TB_CUSTOM_DATA     IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In Fn_Build_Mismatch_And_Pos');
    DBG('Returning true from Fn_Build_Mismatch_And_Pos');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when other of Fn_Build_Mismatch_And_Pos due to ' || SQLERRM);
      RETURN FALSE;
  END FN_BUILD_MISMATCH_AND_POS;

  FUNCTION FN_PRE_DEFAULT_AND_VALIDATE(CREC        IN OUT NOCOPY ACTBS_HANDOFF%ROWTYPE,
                                       P_TMP_XRATE IN OUT ACTBS_DAILY_LOG.EXCH_RATE%TYPE,
                                       PERRCODE    IN OUT VARCHAR2,
                                       PPARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In Fn_Pre_Default_And_Validate');
    DBG('Returning true from Fn_Pre_Default_And_Validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when other of Fn_Pre_Default_And_Validate due to ' ||
          SQLERRM);
      RETURN FALSE;
  END FN_PRE_DEFAULT_AND_VALIDATE;

END ACPKS_CUSTOM;
