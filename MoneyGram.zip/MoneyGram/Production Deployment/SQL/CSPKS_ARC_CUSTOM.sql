CREATE OR REPLACE

PACKAGE BODY cspks_arc_custom IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'cspks_arc_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('IF', L_MSG);
  END DBG;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  PROCEDURE PR_NET_CHARGES_PRE(P_ACC_HAND    IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                               P_CHG_WHOM    IN VARCHAR2,
                               P_DR_WHOM     IN VARCHAR2,
                               P_TXN_AMT_TAG IN VARCHAR2,
                               P_OFS_AMT_TAG IN VARCHAR2,
                               P_RET         IN OUT NUMBER) IS
  BEGIN
    DBG('Inside pr_net_charges_Pre');
  
    DBG('Returning success from pr_net_charges_Pre');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of cspks_arc_custom.pr_net_charges_Pre..');
      DEBUG.PR_DEBUG('IF', SQLERRM);
      P_RET := -1;
      RETURN;
  END PR_NET_CHARGES_PRE;

  PROCEDURE PR_NET_CHARGES_POST(P_ACC_HAND    IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                P_CHG_WHOM    IN VARCHAR2,
                                P_DR_WHOM     IN VARCHAR2,
                                P_TXN_AMT_TAG IN VARCHAR2,
                                P_OFS_AMT_TAG IN VARCHAR2,
                                P_RET         IN OUT NUMBER) IS
  BEGIN
    DBG('Inside pr_net_charges_Post');
  
    DBG('Returning success from pr_net_charges_Post');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of cspks_arc_custom.pr_net_charges_Post ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_RET := -1;
      RETURN;
  END PR_NET_CHARGES_POST;

  PROCEDURE PR_GET_ARC_ROW(P_COD_BRANCH     IN VARCHAR2,
                           P_COD_PROD       IN VARCHAR2,
                           P_PROD_ACC_FLG   IN VARCHAR2,
                           P_COD_TRANS_TYPE IN VARCHAR2,
                           P_COD_CCY        IN VARCHAR2,
                           P_IB_FLAG        IN VARCHAR2 DEFAULT 'N',
                           P_ARC_ROW        IN OUT NOCOPY IFTMS_ARC_MAINT%ROWTYPE,
                           P_FN_CALL_ID     IN OUT NUMBER,
                           P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                           P_ERR_CD         OUT VARCHAR2,
                           P_ERR_PARM       OUT VARCHAR2,
                           P_AC_NO          IN VARCHAR2,
                           P_AC_BRN         IN VARCHAR2) IS
  BEGIN
    DBG('Start of pr_get_arc_row');
  
    DBG('Returning Successfuly from pr_get_arc_row');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed inside when others of pr_get_arc_row' || SQLERRM);
      P_ERR_CD := SQLERRM;
      RETURN;
  END PR_GET_ARC_ROW;

  FUNCTION FN_CALC_CHG(P_BRN            VARCHAR2,
                       P_TXN_CCY        VARCHAR2,
                       P_TXN_AMT        NUMBER,
                       P_CHG_TAB        IN OUT NOCOPY CSPKS_ARC.TB_CHG_AMT,
                       P_ERR_CODE       IN OUT VARCHAR2,
                       P_FN_CALL_ID     IN OUT NUMBER,
                       P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Start of cspks_arc_custom.fn_calc_chg');
	
	--MoneyGram Outgoing By CashPickup Sampath Starts
  
    IF Depks_rtl_teller.pkg_rtl_teller_rec.PRODUCT_CODE = 'MGOC' THEN
    
      FOR G IN 1 .. P_CHG_TAB.COUNT LOOP
      
        P_CHG_TAB(G).chg_amt := depks_ret_telr_upld_custom.FN_GET_MONEY_GRAM_CHARGE(Depks_rtl_teller.pkg_rtl_teller_rec.PRODUCT_CODE,
                                                                                    Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT,
                                                                                    Depks_rtl_teller.pkg_rtl_teller_rec.TXN_CCY,
                                                                                    gwpks_createretailtlr_custom.G_BEN_CON,
                                                                                    Depks_rtl_teller.pkg_rtl_teller_rec.EXCH_RATE); --1;
      
      END LOOP;
    
    END IF;
    --MoneyGram Outgoing By CashPickup Sampath Ends
  
    DBG('Returning Successfuly from cspks_arc_custom.fn_calc_chg');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed inside when others of cspks_arc_custom.fn_calc_chg' ||
          SQLERRM);
      P_ERR_CODE := SQLERRM;
      RETURN FALSE;
    
  END FN_CALC_CHG;

  FUNCTION FN_GETVAL_PARAM(L_PARM           IN OUT NOCOPY VARCHAR2,
                           P_BRN            IN VARCHAR2,
                           P_TXN_CCY        IN VARCHAR2,
                           P_TXN_AMT        IN NUMBER,
                           P_AC_NO          IN VARCHAR2,
                           P_AC_BRN         IN VARCHAR2,
                           P_FN_CALL_ID     IN OUT NOCOPY NUMBER,
                           P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('Inside fn_getval_param ...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Cspks_arc_custom.fn_getval_param ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_GETVAL_PARAM;

  FUNCTION FN_GET_ACCLS_GRP_PRE(P_AC_NO     IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                P_AC_BRN    IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                P_ERR_CODE  IN OUT VARCHAR2,
                                P_ERR_PARM  IN OUT VARCHAR2,
                                P_ACCLS_GRP IN OUT NOCOPY STTMS_ACC_CLASS_GRP_DTL.ACC_CLASS_GROUP%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_get_accls_grp_pre ...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Cspks_arc_custom.fn_get_accls_grp_pre ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_GET_ACCLS_GRP_PRE;

  FUNCTION FN_GET_ACCLS_GRP_POST(P_AC_NO     IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                 P_AC_BRN    IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                 P_ERR_CODE  IN OUT VARCHAR2,
                                 P_ERR_PARM  IN OUT VARCHAR2,
                                 P_ACCLS_GRP IN OUT NOCOPY STTMS_ACC_CLASS_GRP_DTL.ACC_CLASS_GROUP%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_get_accls_grp_post ...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Cspks_arc_custom.fn_get_accls_grp_post ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_GET_ACCLS_GRP_POST;

  FUNCTION FN_CHARGE_PICKUP_PRE(P_COD_BRANCH        IN VARCHAR2,
                                P_COD_PROD_ACC_CLS  IN VARCHAR2,
                                P_COD_PROD_ACC_FLAG IN VARCHAR2,
                                P_COD_PROD_BRN      IN VARCHAR2,
                                P_COD_CCY           IN VARCHAR2,
                                P_COD_TRANS_TYPE    IN VARCHAR2,
                                P_BILL_CCY          IN VARCHAR2,
                                P_BILL_AMT          IN NUMBER,
                                P_RATE_CODE         IN VARCHAR2,
                                P_RATE_TYPE         IN VARCHAR2,
                                P_PERIOD            IN NUMBER,
                                P_CUSTOMER          IN VARCHAR2,
                                P_IB_FLAG           IN VARCHAR2,
                                P_ARC_CHGS          IN OUT NOCOPY IFTMS_ARC_MAINT%ROWTYPE,
                                P_ERRCODE           IN OUT VARCHAR2,
                                P_ERRPARAM          IN OUT VARCHAR2,
                                P_AC_NO             IN VARCHAR2,
                                P_AC_BRN            IN VARCHAR2,
                                P_TBL_RESTR         IN STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_charge_pickup_Pre ...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Cspks_arc_custom.fn_charge_pickup_Pre ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_CHARGE_PICKUP_PRE;

  FUNCTION FN_CHARGE_PICKUP_POST(P_COD_BRANCH        IN VARCHAR2,
                                 P_COD_PROD_ACC_CLS  IN VARCHAR2,
                                 P_COD_PROD_ACC_FLAG IN VARCHAR2,
                                 P_COD_PROD_BRN      IN VARCHAR2,
                                 P_COD_CCY           IN VARCHAR2,
                                 P_COD_TRANS_TYPE    IN VARCHAR2,
                                 P_BILL_CCY          IN VARCHAR2,
                                 P_BILL_AMT          IN NUMBER,
                                 P_RATE_CODE         IN VARCHAR2,
                                 P_RATE_TYPE         IN VARCHAR2,
                                 P_PERIOD            IN NUMBER,
                                 P_CUSTOMER          IN VARCHAR2,
                                 P_IB_FLAG           IN VARCHAR2,
                                 P_ARC_CHGS          IN OUT NOCOPY IFTMS_ARC_MAINT%ROWTYPE,
                                 P_ERRCODE           IN OUT VARCHAR2,
                                 P_ERRPARAM          IN OUT VARCHAR2,
                                 P_AC_NO             IN VARCHAR2,
                                 P_AC_BRN            IN VARCHAR2,
                                 P_TBL_RESTR         IN STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_charge_pickup_Post ...');
	
	 --MoneyGram Outgoing By CashPickup Sampath Starts
  
    IF Depks_rtl_teller.pkg_rtl_teller_rec.PRODUCT_CODE = 'MGOC' THEN
    
    
      P_ARC_CHGS.COD_CHG_AMT := depks_ret_telr_upld_custom.FN_GET_MONEY_GRAM_CHARGE(Depks_rtl_teller.pkg_rtl_teller_rec.PRODUCT_CODE,
                                                                                    Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT,
                                                                                    Depks_rtl_teller.pkg_rtl_teller_rec.TXN_CCY,
                                                                                    gwpks_createretailtlr_custom.G_BEN_CON,
                                                                                    Depks_rtl_teller.pkg_rtl_teller_rec.EXCH_RATE); -- 1;
    
    
    END IF;
    DBG(P_ARC_CHGS.COD_CHG_AMT);
    --MoneyGram Outgoing By CashPickup Sampath Ends
	
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Cspks_arc_custom.fn_charge_pickup_Post ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_CHARGE_PICKUP_POST;

  FUNCTION FN_CHARGE_PICKUP_PRE(P_COD_BRANCH        IN VARCHAR2,
                                P_COD_PROD_ACC_CLS  IN VARCHAR2,
                                P_COD_PROD_ACC_FLAG IN VARCHAR2,
                                P_COD_PROD_BRN      IN VARCHAR2,
                                P_COD_CCY           IN VARCHAR2,
                                P_COD_TRANS_TYPE    IN VARCHAR2,
                                P_BILL_CCY          IN VARCHAR2,
                                P_BILL_AMT          IN NUMBER,
                                P_RATE_CODE         IN VARCHAR2,
                                P_RATE_TYPE         IN VARCHAR2,
                                P_PERIOD            IN NUMBER,
                                P_CUSTOMER          IN VARCHAR2,
                                P_IB_FLAG           IN VARCHAR2,
                                P_ARC_CHGS          IN OUT NOCOPY IFTMS_ARC_MAINT%ROWTYPE,
                                P_ERRCODE           IN OUT VARCHAR2,
                                P_ERRPARAM          IN OUT VARCHAR2,
                                P_AC_NO             IN VARCHAR2,
                                P_AC_BRN            IN VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_charge_pickup_Pre ...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Cspks_arc_custom.fn_charge_pickup_Pre ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_CHARGE_PICKUP_PRE;

  FUNCTION FN_CHARGE_PICKUP_POST(P_COD_BRANCH        IN VARCHAR2,
                                 P_COD_PROD_ACC_CLS  IN VARCHAR2,
                                 P_COD_PROD_ACC_FLAG IN VARCHAR2,
                                 P_COD_PROD_BRN      IN VARCHAR2,
                                 P_COD_CCY           IN VARCHAR2,
                                 P_COD_TRANS_TYPE    IN VARCHAR2,
                                 P_BILL_CCY          IN VARCHAR2,
                                 P_BILL_AMT          IN NUMBER,
                                 P_RATE_CODE         IN VARCHAR2,
                                 P_RATE_TYPE         IN VARCHAR2,
                                 P_PERIOD            IN NUMBER,
                                 P_CUSTOMER          IN VARCHAR2,
                                 P_IB_FLAG           IN VARCHAR2,
                                 P_ARC_CHGS          IN OUT NOCOPY IFTMS_ARC_MAINT%ROWTYPE,
                                 P_ERRCODE           IN OUT VARCHAR2,
                                 P_ERRPARAM          IN OUT VARCHAR2,
                                 P_AC_NO             IN VARCHAR2,
                                 P_AC_BRN            IN VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_charge_pickup_Post ...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Cspks_arc_custom.fn_charge_pickup_Post ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_CHARGE_PICKUP_POST;

  FUNCTION FN_CHARGE_PICKUP_PRE(P_COD_BRANCH        IN VARCHAR2,
                                P_COD_PROD_ACC_CLS  IN VARCHAR2,
                                P_COD_PROD_ACC_FLAG IN VARCHAR2,
                                P_COD_PROD_BRN      IN VARCHAR2,
                                P_COD_CCY           IN VARCHAR2,
                                P_COD_TRANS_TYPE    IN VARCHAR2,
                                P_BILL_CCY          IN VARCHAR2,
                                P_BILL_AMT          IN NUMBER,
                                P_RATE_CODE         IN VARCHAR2,
                                P_RATE_TYPE         IN VARCHAR2,
                                P_IB_FLAG           IN VARCHAR2,
                                P_ARC_CHGS          IN OUT NOCOPY IFTMS_ARC_MAINT%ROWTYPE,
                                P_ERRCODE           IN OUT VARCHAR2,
                                P_ERRPARAM          IN OUT VARCHAR2,
                                P_AC_NO             IN VARCHAR2,
                                P_AC_BRN            IN VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_charge_pickup_Pre ...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Cspks_arc_custom.fn_charge_pickup_Pre ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_CHARGE_PICKUP_PRE;

  FUNCTION FN_CHARGE_PICKUP_POST(P_COD_BRANCH        IN VARCHAR2,
                                 P_COD_PROD_ACC_CLS  IN VARCHAR2,
                                 P_COD_PROD_ACC_FLAG IN VARCHAR2,
                                 P_COD_PROD_BRN      IN VARCHAR2,
                                 P_COD_CCY           IN VARCHAR2,
                                 P_COD_TRANS_TYPE    IN VARCHAR2,
                                 P_BILL_CCY          IN VARCHAR2,
                                 P_BILL_AMT          IN NUMBER,
                                 P_RATE_CODE         IN VARCHAR2,
                                 P_RATE_TYPE         IN VARCHAR2,
                                 P_IB_FLAG           IN VARCHAR2,
                                 P_ARC_CHGS          IN OUT NOCOPY IFTMS_ARC_MAINT%ROWTYPE,
                                 P_ERRCODE           IN OUT VARCHAR2,
                                 P_ERRPARAM          IN OUT VARCHAR2,
                                 P_AC_NO             IN VARCHAR2,
                                 P_AC_BRN            IN VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_charge_pickup_Post ...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Cspks_arc_custom.fn_charge_pickup_Post ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_CHARGE_PICKUP_POST;

  FUNCTION FN_GETCHGCODE_ROW(P_CHG_CODE       IN STTM_CHARGE_CD_DETAIL.CHG_CODE%TYPE,
                             P_VALUE1         IN STTM_CHARGE_CD_DETAIL.VALUE1%TYPE,
                             P_VALUE2         IN STTM_CHARGE_CD_DETAIL.VALUE2%TYPE,
                             P_VALUE3         IN STTM_CHARGE_CD_DETAIL.VALUE3%TYPE,
                             P_VALUE4         IN STTM_CHARGE_CD_DETAIL.VALUE4%TYPE,
                             P_VALUE5         IN STTM_CHARGE_CD_DETAIL.VALUE5%TYPE,
                             P_CHG_CODE_ROW   OUT NOCOPY STTM_CHARGE_CD_DETAIL%ROWTYPE,
                             P_FN_CALL_ID     IN OUT NOCOPY NUMBER,
                             P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('Start of cspks_arc_custom.fn_getchgcode_row');
  
    DBG('Returning Successfuly from cspks_arc_custom.fn_getchgcode_row');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Cspks_arc_custom.fn_getchgcode_row ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_GETCHGCODE_ROW;

  FUNCTION FN_DO_RP_PROCEESING(P_CUST_NO        IN VARCHAR2,
                               P_PROD           IN VARCHAR2,
                               P_COMP           IN VARCHAR2,
                               P_CCY            IN VARCHAR2,
                               P_ORIG_CHG_AMT   IN NUMBER,
                               P_RP_CHG_AMT     OUT NUMBER,
                               P_AC_NO          IN VARCHAR2,
                               P_BRN            IN VARCHAR2,
                               P_FN_CALL_ID     IN OUT NOCOPY NUMBER,
                               P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('Start of cspks_arc_custom.fn_do_rp_proceesing');
  
    DBG('Returning Successfuly from cspks_arc_custom.fn_do_rp_proceesing');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Cspks_arc_custom.fn_do_rp_proceesing ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_DO_RP_PROCEESING;

  FUNCTION FN_NSF_TRACKER(P_MODULE               IN CSTB_AUTO_SETTLE_BLOCK.MODULE%TYPE,
                          P_TRN_REF_NO           IN CSTB_AUTO_SETTLE_BLOCK.CONTRACT_REF_NO%TYPE,
                          P_PROD                 IN CSTB_AUTO_SETTLE_BLOCK.PRODUCT%TYPE,
                          P_BRANCH_CODE          IN DETB_RTL_TELLER.BRANCH_CODE%TYPE,
                          P_TXN_ACC              IN DETB_RTL_TELLER.TXN_ACC%TYPE,
                          P_TXN_AMOUNT           IN DETB_RTL_TELLER.TXN_AMOUNT%TYPE,
                          P_VALUE_DT             IN DETB_RTL_TELLER.VALUE_DT%TYPE,
                          PKG_MAIN_ENTRIES_BUILT IN BOOLEAN,
                          P_CHG_ACC_BRN          IN CSTB_AUTO_SETTLE_BLOCK.ACCOUNT_BR%TYPE,
                          P_CHG_ACC              IN CSTB_AUTO_SETTLE_BLOCK.ACCOUNT_NO%TYPE,
                          P_CHG_AMT              IN CSTB_AUTO_SETTLE_BLOCK.AMOUNT_DUE%TYPE,
                          P_ACC_CCY              IN DETB_RTL_TELLER.TXN_CCY%TYPE,
                          P_CHG_CCY              IN DETB_RTL_TELLER.TXN_CCY%TYPE,
                          P_COD_RATE_CODE        IN IFTM_ARC_MAINT.COD_RATE_CODE%TYPE,
                          P_COD_RATE_CODE_TYPE   IN IFTM_ARC_MAINT.COD_RATE_CODE_TYPE%TYPE,
                          P_COD_CHG_TRACK_PRF    IN IFTM_ARC_MAINT.COD_CHG_TRACK_PRF%TYPE,
                          P_CHG_SEQ              IN NUMBER,
                          P_CRDR_IND             IN CHAR,
                          P_COD_NET_CHARGES      IN IFTM_ARC_MAINT.COD_NET_CHARGES%TYPE,
                          P_TRACK_CHG_ENTRY_NSF  IN OUT VARCHAR2,
                          P_COD_CHG_AMT_NSF      OUT DETB_RTL_TELLER.TXN_AMOUNT%TYPE,
                          P_ERR_CODE             OUT VARCHAR2,
                          P_RET                  OUT VARCHAR2,
                          P_FN_CALL_ID           IN OUT NUMBER,
                          P_TB_CUSTOM_DATA       IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of Cspks_Arc_Custom.Fn_Nsf_Tracker..');
  
    DBG('Returning Successfuly from Cspks_Arc_Custom.Fn_Nsf_Tracker..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed inside when others of Cspks_Arc_Custom.Fn_Nsf_Tracker ' ||
          SQLERRM);
      P_ERR_CODE := SQLERRM;
      RETURN FALSE;
  END FN_NSF_TRACKER;

  FUNCTION FN_REPLACE_CASH_GL(P_COD_BRANCH     IN VARCHAR2,
                              P_COD_PROD       IN VARCHAR2,
                              P_COD_CCY        IN VARCHAR2,
                              P_ARC_ROW        IN OUT NOCOPY IFTMS_ARC_MAINT%ROWTYPE,
                              P_FN_CALL_ID     IN OUT NUMBER,
                              P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In cspks_arc_custom.fn_replace_cash_gl');
	
	 --MoneyGram Outgoing By CashPickup Sampath Starts
  
    IF Depks_rtl_teller.pkg_rtl_teller_rec.PRODUCT_CODE = 'MGOC' THEN
    
      P_ARC_ROW.cod_chg_amt := depks_ret_telr_upld_custom.FN_GET_MONEY_GRAM_CHARGE(Depks_rtl_teller.pkg_rtl_teller_rec.PRODUCT_CODE,
                                                                                   Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT,
                                                                                   Depks_rtl_teller.pkg_rtl_teller_rec.TXN_CCY,
                                                                                   gwpks_createretailtlr_custom.G_BEN_CON,
                                                                                   Depks_rtl_teller.pkg_rtl_teller_rec.EXCH_RATE); --1;
    
    
    END IF;
    --MoneyGram Outgoing By CashPickup Sampath Ends
  
    DBG('Successfully comes out of cspks_arc_custom');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_replace_cash_gl ***' || SQLERRM);
      RETURN FALSE;
  END FN_REPLACE_CASH_GL;

  FUNCTION FN_CALC_CHG(P_BRN            VARCHAR2,
                       P_TXN_CCY        VARCHAR2,
                       P_TXN_AMT        NUMBER,
                       P_CHG_TAB        IN OUT NOCOPY CSPKS_ARC.TB_CHG_AMT,
                       P_ERR_CODE       IN OUT VARCHAR2,
                       P_AC_NO          IN VARCHAR2,
                       P_AC_BRN         IN VARCHAR2,
                       P_TBL_RESTR      IN STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR,
                       P_FN_CALL_ID     IN OUT NUMBER,
                       P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In cspks_arc_custom.fn_calc_chg');
  
    DBG('Successfully comes out of cspks_arc_custom');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In W-O of fn_calc_chg>>> :-(' || SQLERRM);
      RETURN FALSE;
  END FN_CALC_CHG;

  FUNCTION FN_CALC_CHG(P_BRN            VARCHAR2,
                       P_TXN_CCY        VARCHAR2,
                       P_TXN_AMT        NUMBER,
                       P_CHG_TAB        IN OUT NOCOPY CSPKS_ARC.TB_CHG_AMT,
                       P_ERR_CODE       IN OUT VARCHAR2,
                       P_AC_NO          IN VARCHAR2,
                       P_AC_BRN         IN VARCHAR2,
                       P_FN_CALL_ID     IN OUT NUMBER,
                       P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In cspks_arc_custom.fn_calc_chg');
  
    DBG('Successfully comes out of cspks_arc_custom');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In W-O of fn_calc_chg>>> :-(' || SQLERRM);
      RETURN FALSE;
  END FN_CALC_CHG;

  PROCEDURE PR_GET_ARC_ROW(P_COD_BRANCH     IN VARCHAR2,
                           P_COD_PROD       IN VARCHAR2,
                           P_PROD_ACC_FLG   IN VARCHAR2,
                           P_COD_TRANS_TYPE IN VARCHAR2,
                           P_COD_CCY        IN VARCHAR2,
                           P_IB_FLAG        IN VARCHAR2 DEFAULT 'N',
                           P_ARC_ROW        IN OUT NOCOPY IFTMS_ARC_MAINT%ROWTYPE,
                           P_FN_CALL_ID     IN OUT NUMBER,
                           P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                           P_ERR_CD         IN OUT VARCHAR2,
                           P_ERR_PARM       IN OUT VARCHAR2,
                           P_AC_NO          IN VARCHAR2,
                           P_AC_BRN         IN VARCHAR2,
                           PKG_CHG_TAB      IN OUT CSPKS_ARC.TY_ARC_CHG_TAB) IS
  BEGIN
    DBG('Start of pr_get_arc_row');
  
    DBG('Returning Successfuly from pr_get_arc_row');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed inside when others of pr_get_arc_row' || SQLERRM);
      P_ERR_CD := SQLERRM;
      RETURN;
  END PR_GET_ARC_ROW;

END CSPKS_ARC_CUSTOM;
