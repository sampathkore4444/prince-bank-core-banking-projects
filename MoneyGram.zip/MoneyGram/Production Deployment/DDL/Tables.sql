-- Create table
create table IFTB_MGT_IN_MASTER
(
  branch_code      VARCHAR2(3),
  trn_ref_no       VARCHAR2(20) not null,
  product_code     VARCHAR2(4),
  transfer_date    DATE,
  txn_ccy          VARCHAR2(3),
  txn_amt          NUMBER(22,3),
  net_txn_amt      NUMBER(22,3),
  exch_rate        NUMBER(24,12),
  txn_remarks      VARCHAR2(255),
  sender_name      VARCHAR2(255),
  sender_addr1     VARCHAR2(105),
  sender_addr2     VARCHAR2(105),
  sender_addr3     VARCHAR2(105),
  sender_addr4     VARCHAR2(105),
  sender_dob       DATE,
  ben_acc          VARCHAR2(100),
  ben_name         VARCHAR2(100),
  ben_acc_ccy      VARCHAR2(3),
  ben_acc_brn      VARCHAR2(3),
  ben_remarks      VARCHAR2(255),
  pass_code        VARCHAR2(105),
  maker_id         VARCHAR2(12),
  maker_dt_stamp   DATE,
  checker_id       VARCHAR2(12),
  checker_dt_stamp DATE,
  auth_stat        VARCHAR2(1),
  record_stat      VARCHAR2(1),
  once_auth        VARCHAR2(1),
  mod_no           NUMBER(4),
  source_of_funds  VARCHAR2(105),
  purpose_of_trf   VARCHAR2(105)
)
/
alter table IFTB_MGT_IN_MASTER add primary key (TRN_REF_NO)
/
-- Create table
create table IFTB_MGT_MASTER
(
  branch_code      VARCHAR2(3),
  trn_ref_no       VARCHAR2(20) not null,
  product_code     VARCHAR2(4),
  transfer_date    DATE,
  txn_ccy          VARCHAR2(3),
  txn_amt          NUMBER(22,3),
  tot_chg_amt      NUMBER(22,3),
  net_txn_amt      NUMBER(22,3),
  exch_rate        NUMBER(24,12),
  txn_remarks      VARCHAR2(255),
  rem_acc          VARCHAR2(100),
  rem_name         VARCHAR2(100),
  rem_add1         VARCHAR2(105),
  rem_add2         VARCHAR2(105),
  rem_add3         VARCHAR2(105),
  rem_add4         VARCHAR2(105),
  ben_name         VARCHAR2(100),
  ben_add1         VARCHAR2(105),
  ben_add2         VARCHAR2(105),
  ben_add3         VARCHAR2(105),
  ben_add4         VARCHAR2(105),
  ben_remarks      VARCHAR2(255),
  pass_code        VARCHAR2(105),
  maker_id         VARCHAR2(12),
  maker_dt_stamp   DATE,
  checker_id       VARCHAR2(12),
  checker_dt_stamp DATE,
  auth_stat        VARCHAR2(1),
  record_stat      VARCHAR2(1),
  once_auth        VARCHAR2(1),
  mod_no           NUMBER(4),
  ben_relationship VARCHAR2(255),
  ben_dob          DATE,
  source_of_funds  VARCHAR2(105),
  purpose_of_trf   VARCHAR2(105),
  ben_mob          VARCHAR2(105)
)
/
alter table IFTB_MGT_MASTER add primary key (TRN_REF_NO)
/
-- Create table
create table IFTB_MGT_CHARGE
(
  trn_ref_no  VARCHAR2(20),
  chg_srno    NUMBER(1),
  chg1_desc   VARCHAR2(255),
  chg1_waiver VARCHAR2(1),
  chg1_amt    NUMBER(22,3),
  chg1_ccy    VARCHAR2(3),
  lcy_chg1    NUMBER(22,3),
  fcy_chg1    NUMBER(22,3),
  chg1_gl     VARCHAR2(20),
  chg2_desc   VARCHAR2(255),
  chg2_waiver VARCHAR2(1),
  chg2_amt    NUMBER(22,3),
  chg2_ccy    VARCHAR2(3),
  lcy_chg2    NUMBER(22,3),
  fcy_chg2    NUMBER(22,3),
  chg2_gl     VARCHAR2(20),
  chg3_desc   VARCHAR2(255),
  chg3_waiver VARCHAR2(1),
  chg3_amt    NUMBER(22,3),
  chg3_ccy    VARCHAR2(3),
  lcy_chg3    NUMBER(22,3),
  fcy_chg3    NUMBER(22,3),
  chg3_gl     VARCHAR2(20),
  netting_req CHAR(1),
  xrate       NUMBER(22,10),
  txn_code    VARCHAR2(3),
  chg1_type   VARCHAR2(1),
  chg1_in_txn NUMBER(22,3),
  chg1_in_acc NUMBER(22,3),
  chg2_type   VARCHAR2(1),
  chg2_in_txn NUMBER(22,3),
  chg2_in_acc NUMBER(22,3),
  chg3_type   VARCHAR2(1),
  chg3_in_txn NUMBER(22,3),
  chg3_in_acc NUMBER(22,3),
  oth_ccy     VARCHAR2(3),
  txn_xrate   NUMBER(22,10),
  acc_xrate   NUMBER(22,10)
)
/
-- Create table
create table IFTB_MG_IN_INFO
(
  trn_ref_no     VARCHAR2(16) PRIMARY KEY,
  ben_cif        VARCHAR2(105),
  ben_name       VARCHAR2(105),
  ben_dob        DATE,
  ben_country    VARCHAR2(105),
  ben_mobile     VARCHAR2(35),
  ben_uid        VARCHAR2(35),
  ben_uvalue     VARCHAR2(35),
  sender_name    VARCHAR2(105),
  sender_addr1   VARCHAR2(105),
  sender_addr2   VARCHAR2(105),
  sender_addr3   VARCHAR2(105),
  sender_country VARCHAR2(105),
  sender_dob     DATE,
  purpose_of_trf VARCHAR2(105)
)
/
alter table IFTB_MG_IN_INFO add primary key (TRN_REF_NO)
/
-- Create table
create table IFTB_MG_OUT_INFO
(
  trn_ref_no       VARCHAR2(16) PRIMARY KEY,
  sender_cif       VARCHAR2(105),
  sender_name      VARCHAR2(105),
  sender_mobile    VARCHAR2(35),
  purpose_of_trf   VARCHAR2(105),
  source_of_funds  VARCHAR2(105),
  ben_name         VARCHAR2(105),
  ben_country      VARCHAR2(5),
  ben_relationship VARCHAR2(105),
  ben_dob          DATE,
  ben_addr1        VARCHAR2(105),
  ben_addr2        VARCHAR2(105),
  ben_addr3        VARCHAR2(105),
  ben_addr4        VARCHAR2(105),
  passcode         VARCHAR2(105),
  ben_mob          VARCHAR2(105)
)
/
alter table IFTB_MG_OUT_INFO add primary key (TRN_REF_NO)
/
-- Create sequence 
create sequence TRSQ_MGT_SEQID
minvalue 1
maxvalue 999999999
start with 1
increment by 1
nocache
cycle
/
create or replace synonym iftbs_mgt_master for iftb_mgt_master
/
create or replace synonym iftbs_mgt_in_master for iftb_mgt_in_master
/