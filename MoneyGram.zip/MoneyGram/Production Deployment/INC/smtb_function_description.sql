insert into smtb_function_description (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'IFDMGIAC', 'MoneyGram Payment', 'Operations', 'MoneyGram Incoming Payment By Account', null, null, null, 'MoneyGram Incoming Payment By Account', 'IFDMGIAC');

insert into smtb_function_description (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'IFDMGPAC', 'MoneyGram Payment', 'Operations', 'MoneyGram Outgoing Payment By Account', null, null, null, 'MoneyGram Outgoing Payment By Account', 'IFDMGPAC');

insert into smtb_function_description (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'IFSMGIAC', 'MoneyGram Payment', 'View', 'MoneyGram Incoming Payment By Account', null, null, null, 'MoneyGram Incoming Payment By Account', 'IFDMGIAC');

insert into smtb_function_description (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'IFSMGPAC', 'MoneyGram Payment', 'View', 'MoneyGram Outgoing Payment By Account', null, null, null, 'MoneyGram Outgoing Payment By Account', 'IFDMGPAC');

insert into smtb_function_description (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'MGIC', 'MoneyGram Payment', 'Operations', 'MoneyGram Remittance Withdrawal By Cash', null, 'WB', null, 'MoneyGram Remittance Withdrawal By Cash', 'MGIC');

insert into smtb_function_description (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'MGOC', 'MoneyGram Payment', 'Operations', 'MoneyGram Outgoing Payment By Cash', null, 'WB', '100', 'MoneyGram Outgoing Payment By Cash', 'MGOC');

COMMIT;
