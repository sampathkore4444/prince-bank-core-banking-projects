CREATE OR REPLACE FUNCTION process_http (
    in_url            IN VARCHAR2,                                      -- URL
    in_data           IN VARCHAR2,                              -- data as XML
    in_contect_type      VARCHAR2                              -- content type
                                 )
    RETURN VARCHAR2
AS
    LANGUAGE JAVA
    --NAME 'com/prince/utilities/https/CallHTTPS.processHTTPS(java.lang.String, java.lang.String, java.lang.String) return java.lang.String';
    NAME 'CALLHTTP.processHTTP(java.lang.String, java.lang.String, java.lang.String) return java.lang.String';
