-- Create table
create table IFTB_MIN_TO_MAJ_MASTER
(
  reference_no VARCHAR2(105) PRIMARY KEY,
  customer_no  VARCHAR2(105),
  cust_ac_no   VARCHAR2(105),
  minor        CHAR(1),
  status       CHAR(1) default 'N'
)
/
-- Create table
create table IFTB_MIN_TO_MAJ_WS_LOG
(
  reference_no VARCHAR2(105) PRIMARY KEY,
  invoke_date  TIMESTAMP(6),
  customer_no  VARCHAR2(105),
  cust_ac_no   VARCHAR2(105),
  req_type     VARCHAR2(25),
  req_msg      CLOB,
  res_msg      CLOB,
  status       CHAR(1),
  addl_info    VARCHAR2(105)
)
/
create sequence TRSQ_MINOR_TO_MAJOR_SEQ
minvalue 1
maxvalue 9999999999999
start with 1
increment by 1
cache 20
/