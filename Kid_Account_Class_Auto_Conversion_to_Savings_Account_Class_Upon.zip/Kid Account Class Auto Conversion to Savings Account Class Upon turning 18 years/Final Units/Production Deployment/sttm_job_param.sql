insert into sttm_job_param (JOB_CODE, PARAM_NAME, DATA_TYPE, PARAM_VALUE)
values ('PR_MINOR_TO_MAJOR_CUST', 'NAME', 'VARCHAR', 'OFSS');

COMMIT;
