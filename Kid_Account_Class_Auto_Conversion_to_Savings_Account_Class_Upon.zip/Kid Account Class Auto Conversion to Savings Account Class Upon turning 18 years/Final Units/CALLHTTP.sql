create or replace and compile java source named CALLHTTP as
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.SSLSession;
import javax.net.ssl.X509TrustManager;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class CALLHTTP
{
  public static String processHTTPS(String URL_, String data, String cont_type)
  {
    CallHTTPS o = new CallHTTPS();

    String r = "";
    try
    {
      r = o.httpsPOST(URL_, data, cont_type);
    } catch (Exception e) {
      return "ERR:" + e.getMessage();
    }

    return r;
  }

  public static String processHTTP(String URL_, String data, String cont_type)
  {
    CallHTTPS o = new CallHTTPS();

    String r = "";
    try
    {
      r = o.httpPOST(URL_, data, cont_type);
    } catch (Exception e) {
      return "ERR:" + e.getMessage();
    }

    return r;
  }

  public String httpsPOST(String URL_, String data, String cont_type)
    throws Exception
  {
    HttpsURLConnection con = null;
    try
    {
      con = openHttpsConnection(URL_);
    } catch (Exception e) {
      if (con != null)
        con.disconnect();
      return "ERR:Not connected to the host: " + e.getMessage();
    }

    if (con == null) {
      return "ERR:Connected to the host, but null";
    }

    con.setRequestMethod("POST");

    con.setRequestProperty("Content-length", String.valueOf(data.length()));
    con.setRequestProperty("Content-Type", cont_type);

    con.setDoOutput(true);
    con.setDoInput(true);

    DataOutputStream output = null;
    try
    {
      output = new DataOutputStream(con.getOutputStream());
    } catch (Exception ex) {
      con.disconnect();
      return "ERR:Could't open output stream: " + ex.getMessage();
    }

    output.writeBytes(data);

    output.flush();
    output.close();

    String content = "";

    DataInputStream input = null;
    try {
      input = new DataInputStream(con.getInputStream());
    }
    catch (Exception ex) {
      InputStream error = con.getErrorStream();
      try
      {
        int data2 = error.read();
        while (data2 != -1) {
          content = content + (char)data2;
          data2 = error.read();
        }
        error.close();
      } catch (Exception ex2) {
        try {
          if (error != null)
            error.close();
        }
        catch (Exception localException1)
        {
        }
        con.disconnect();
        return "ERR:Could't open input stream to get data from remote host: " + ex.getMessage();
      }
      con.disconnect();
      if (content == "") {
        return "ERR:No data found in error stream";
      }
      return content;
    }

    String line = "";
    do
      content = content + line + "\n";
    while ((line = input.readLine()) != null);

    input.close();

    con.disconnect();

    if (content.length() == 0) {
      return "ERR:No data received from remote host";
    }
    return content;
  }

  public String httpPOST(String URL_, String data, String cont_type)
    throws Exception
  {
    URL url = new URL(URL_);

    HttpURLConnection con = null;
    try
    {
      con = (HttpURLConnection)url.openConnection();
    } catch (Exception e) {
      if (con != null)
        con.disconnect();
      return "ERR:Not connected to the host";
    }

    if (con == null) {
      return "ERR:Connected to the host, but null";
    }

    con.setRequestMethod("POST");

    con.setRequestProperty("Content-length", String.valueOf(data.length()));
    con.setRequestProperty("Content-Type", cont_type);

    con.setDoOutput(true);
    con.setDoInput(true);

    DataOutputStream output = null;
    try
    {
      output = new DataOutputStream(con.getOutputStream());
    } catch (Exception ex) {
      con.disconnect();
      return "ERR:Could't open output stream: " + ex.getMessage();
    }

    output.writeBytes(data);

    output.flush();
    output.close();

    String content = "";

    DataInputStream input = null;
    try {
      input = new DataInputStream(con.getInputStream());
    }
    catch (Exception ex) {
      content = "";

      InputStream error = con.getErrorStream();
      try
      {
        int data2 = error.read();
        while (data2 != -1) {
          content = content + (char)data2;
          data2 = error.read();
        }
        error.close();
      } catch (Exception ex2) {
        try {
          if (error != null)
            error.close();
        }
        catch (Exception localException1)
        {
        }
        con.disconnect();
        return "ERR:Could't open error input stream to get data from remote host: " + ex.getMessage();
      }
      con.disconnect();
      if (content.length() == 0) {
        return "ERR:No data found in error stream";
      }

      return content;
    }

    content = "";
    String line;
    while ((line = input.readLine()) != null) {
      content = content + line + "\n";
    }

    input.close();

    con.disconnect();

    if (content.length() == 0) {
      return "ERR:No data received from remote host";
    }
    return content;
  }

  private HttpsURLConnection openHttpsConnection(String queryString)
    throws Exception
  {
    TrustManager[] trustAllCerts = new TrustManager[] {
    new X509TrustManager() {

     @Override
     public void checkClientTrusted(java.security.cert.X509Certificate[] arg0,
       String arg1) throws CertificateException {
      // TODO Auto-generated method stub

     }

     @Override
     public void checkServerTrusted(java.security.cert.X509Certificate[] arg0,
       String arg1) throws CertificateException {
      // TODO Auto-generated method stub
    try {
                    arg0[0].checkValidity();
                } catch (Exception e) {
                    throw new CertificateException("Certificate not valid or trusted.");
                }
     }

     @Override
     public java.security.cert.X509Certificate[] getAcceptedIssuers() {
      // TODO Auto-generated method stub
      return null;
     }

    }
  };

    SSLContext sc = SSLContext.getInstance("SSL");
    sc.init(null, trustAllCerts, new SecureRandom());
    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

    HostnameVerifier allHostsValid = new HostnameVerifier() {
   public boolean verify(String hostname, SSLSession session) {
    return true;
   }
  };

    HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);

    URL url = new URL(queryString);
    HttpsURLConnection con = (HttpsURLConnection)url.openConnection();

    return con;
  }
}