CREATE OR REPLACE PROCEDURE PR_PROCESS_MINOR_TO_MAJOR(P_PARAM_NAMES VARCHAR2,
                                                      P_PARAM_VALS  VARCHAR2) AS

  L_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;

  L_RESPONSE VARCHAR2(32767) := '';
  L_XML      VARCHAR2(32767);
  L_REF      VARCHAR2(100);
  L_SEQ      VARCHAR2(100);
  
   CURSOR C1 IS
  /*SELECT A.CUSTOMER_NO
                                                    FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
                                                   WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                                                     AND (GLOBAL.application_date - B.DATE_OF_BIRTH) > = 18
                                                     AND A.RECORD_STAT = 'O'
                                                     AND A.AUTH_STAT = 'A'
                                                     AND B.MINOR = 'Y';*/

    select *
      from (select a.customer_no CUSTOMER_NO,
                   b.date_of_birth,
                   sysdate,
                   trunc(months_between(sysdate,
                                        to_date(to_char(b.date_of_birth,
                                                        'DDMMYYYY'),
                                                'DDMMYYYY')) / 12) year,
                   trunc(mod(months_between(sysdate,
                                            to_date(to_char(b.date_of_birth,
                                                            'DDMMYYYY'),
                                                    'DDMMYYYY')),
                             12)) month,
                   trunc(sysdate - add_months(to_date(to_char(b.date_of_birth,
                                                              'DDMMYYYY'),
                                                      'DDMMYYYY'),
                                              trunc(months_between(sysdate,
                                                                   to_date(to_char(b.date_of_birth,
                                                                                   'DDMMYYYY'),
                                                                           'DDMMYYYY')) / 12) * 12 +
                                              trunc(mod(months_between(sysdate,
                                                                       to_date(to_char(b.date_of_birth,
                                                                                       'DDMMYYYY'),
                                                                               'DDMMYYYY')),
                                                        12)))) day
              from sttm_customer a, Sttm_Cust_Personal b
             where a.customer_no = b.customer_no
               and a.record_stat = 'O'
               and a.auth_stat = 'A'
               and b.minor = 'Y'
              -- and a.customer_no = '00014642'
            /*and exists (select cust_no
             from sttm_cust_account z
            where z.account_class = 'SA05'
              and z.record_stat = 'O'
              and z.auth_stat = 'A')*/
            ) a
     where a.year = 18
    -- and a.month = 0
    --and a.day = 0
    ;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'PR_PROCESS_MINOR_TO_MAJOR ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  PROCEDURE PR_INSERT_WS_LOG(P_SEQ_NO    IN VARCHAR2,
                             P_INVOKE_TS IN TIMESTAMP,
                             P_CUST_NO   IN VARCHAR2,
                             P_AC_NO     IN VARCHAR2,
                             P_REQ_TYPE  IN VARCHAR2,
                             P_REQ_MSG   IN VARCHAR2,
                             P_ADDL_INFO IN VARCHAR2) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    INSERT INTO IFTB_MIN_TO_MAJ_WS_LOG
      (REFERENCE_NO,
       INVOKE_DATE,
       CUSTOMER_NO,
       CUST_AC_NO,
       REQ_TYPE,
       REQ_MSG,
       ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_INVOKE_TS,
       P_CUST_NO,
       P_AC_NO,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ADDL_INFO);

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_WS_LOG=' || SQLERRM);
  END PR_INSERT_WS_LOG;

  PROCEDURE PR_UPDATE_WS_LOG(P_SEQ_NO   IN VARCHAR2,
                             P_RESPONSE IN CLOB,
                             P_STATUS   IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_WS_LOG');

    UPDATE IFTB_MIN_TO_MAJ_WS_LOG
       SET RES_MSG = P_RESPONSE, STATUS = P_STATUS
     WHERE REFERENCE_NO = P_SEQ_NO;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_WS_LOG=' || SQLERRM);
  END PR_UPDATE_WS_LOG;

  PROCEDURE PR_INSERT_MIN_MAJ_MASTER(P_SEQ_NO   IN VARCHAR2,
                                     P_CUST_NO  IN VARCHAR2,
                                     P_CUST_ACC IN VARCHAR2,
                                     P_MINOR    IN CHAR,
                                     P_STATUS   IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_INSERT_MIN_MAJ_MASTER');

    INSERT INTO IFTB_MIN_TO_MAJ_MASTER
    VALUES
      (P_SEQ_NO, P_CUST_NO, P_CUST_ACC, P_MINOR, P_STATUS);

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_MIN_MAJ_MASTER');
      DBG('ERROR CODE IN PR_INSERT_MIN_MAJ_MASTER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_MIN_MAJ_MASTER=' || SQLERRM);
  END PR_INSERT_MIN_MAJ_MASTER;

  PROCEDURE PR_UPDATE_MIN_MAJ_MASTER(P_SEQ_NO   IN VARCHAR2,
                                     P_CUST_NO  IN VARCHAR2,
                                     P_CUST_ACC IN VARCHAR2,
                                     P_STATUS   IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_MIN_MAJ_MASTER');

    UPDATE IFTB_MIN_TO_MAJ_MASTER
       SET STATUS = P_STATUS
     WHERE REFERENCE_NO = P_SEQ_NO
       AND CUSTOMER_NO = P_CUST_NO
       AND CUST_AC_NO = P_CUST_ACC;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_MIN_MAJ_MASTER');
      DBG('ERROR CODE IN PR_UPDATE_MIN_MAJ_MASTER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_MIN_MAJ_MASTER=' || SQLERRM);
  END PR_UPDATE_MIN_MAJ_MASTER;

  PROCEDURE PR_UPDATE_CUST_PERSONAL(P_CUST_NO IN VARCHAR2) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_CUST_PERSONAL');

    UPDATE STTM_CUST_PERSONAL
       SET MINOR = 'N'
     WHERE CUSTOMER_NO = P_CUST_NO;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_CUST_PERSONAL');
      DBG('ERROR CODE IN PR_UPDATE_CUST_PERSONAL=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_CUST_PERSONAL=' || SQLERRM);
  END PR_UPDATE_CUST_PERSONAL;
  
  

BEGIN

  FOR G IN C1 LOOP

    BEGIN

      SAVEPOINT A;

      --call account class webservice
      SELECT *
        INTO L_CUST_ACCOUNT
        FROM STTM_CUST_ACCOUNT
       WHERE ACCOUNT_CLASS = 'SA05'
            -- AND BRANCH_CODE = '001'
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
         AND CUST_NO IN (SELECT CUSTOMER_NO
                           FROM STTM_CUST_PERSONAL A
                          WHERE /*A.MINOR = 'N'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                     AND */
                          A.CUSTOMER_NO = G.CUSTOMER_NO
                      AND A.MINOR = 'Y');

      GLOBAL.PR_INIT(L_CUST_ACCOUNT.BRANCH_CODE, 'SYSTEM');

      --SEQUENCE GENERATION FOR MSGID AND REF ID
      SELECT TRSQ_MINOR_TO_MAJOR_SEQ.NEXTVAL INTO L_SEQ FROM DUAL;

      L_REF := SUBSTR(TO_CHAR(SYSDATE, 'YYMM'), 2) || LPAD(L_SEQ, 9, '0');

      --insert into master table
      PR_INSERT_MIN_MAJ_MASTER(L_REF,
                               G.CUSTOMER_NO,
                               L_CUST_ACCOUNT.CUST_AC_NO,
                               'Y',
                               'N');

      --update from minor to major
      PR_UPDATE_CUST_PERSONAL(G.CUSTOMER_NO);

      --call ws
      L_XML := '<soapenv:Envelope
  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
  xmlns:fcub="http://fcubs.ofss.com/service/FCUBSAccService">
  <soapenv:Header/>
  <soapenv:Body>
    <fcub:CREATEACCLASSTFR_FSFS_REQ>
      <fcub:FCUBS_HEADER>
        <fcub:SOURCE>DIGIBANK2</fcub:SOURCE>
        <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
        <fcub:MSGID></fcub:MSGID>
        <fcub:CORRELID></fcub:CORRELID>
        <fcub:USERID>DIGIUSER1</fcub:USERID>
        <fcub:ENTITY></fcub:ENTITY>
        <fcub:BRANCH>$L_BRN_CODE</fcub:BRANCH>
        <fcub:MODULEID></fcub:MODULEID>
        <fcub:SERVICE>FCUBSAccService</fcub:SERVICE>
        <fcub:OPERATION>CreateAcClassTfr</fcub:OPERATION>
        <fcub:SOURCE_OPERATION></fcub:SOURCE_OPERATION>
        <fcub:SOURCE_USERID></fcub:SOURCE_USERID>
        <fcub:DESTINATION></fcub:DESTINATION>
        <fcub:MULTITRIPID></fcub:MULTITRIPID>
        <fcub:FUNCTIONID>STGACTFR</fcub:FUNCTIONID>
        <fcub:ACTION>NEW</fcub:ACTION>
      </fcub:FCUBS_HEADER>
      <fcub:FCUBS_BODY>
        <fcub:Main-Full>
          <fcub:CHQBOOK>N</fcub:CHQBOOK>
          <fcub:PASSBOOK>N</fcub:PASSBOOK>
          <fcub:BRN>$L_BRN_CODE</fcub:BRN>
          <fcub:ACC>$L_CUST_AC_NO</fcub:ACC>
          <fcub:ACCLS>SA07</fcub:ACCLS>
          <fcub:OLDACCLASS>SA05</fcub:OLDACCLASS>
          <fcub:EFFECTIVEDATE>$L_EFFECTIVE_DATE</fcub:EFFECTIVEDATE>
          <fcub:AUTOREORDERCHKR>N</fcub:AUTOREORDERCHKR>
          <fcub:Mis>
            <fcub:POOLCODE>DFLTPOOL</fcub:POOLCODE>
            <fcub:RATE_FLAG1></fcub:RATE_FLAG1>
            <fcub:REF_RATE></fcub:REF_RATE>
          </fcub:Mis>
        </fcub:Main-Full>
      </fcub:FCUBS_BODY>
    </fcub:CREATEACCLASSTFR_FSFS_REQ>
  </soapenv:Body>
</soapenv:Envelope>';

      L_XML := REPLACE(L_XML, '$L_BRN_CODE', L_CUST_ACCOUNT.BRANCH_CODE);
      L_XML := REPLACE(L_XML, '$L_CUST_AC_NO', L_CUST_ACCOUNT.CUST_AC_NO);
      L_XML := REPLACE(L_XML,
                       '$L_EFFECTIVE_DATE',
                       to_char(GLOBAL.APPLICATION_DATE + 1, 'YYYY-MM-DD'));

      --log ws call

      PR_INSERT_WS_LOG(L_REF,
                       SYSTIMESTAMP,
                       G.CUSTOMER_NO,
                       L_CUST_ACCOUNT.CUST_AC_NO,
                       'NEW',
                       L_XML,
                       'AccountClass Transfer Call');

      --call

      L_RESPONSE := process_http('http://10.80.80.79:8007/' ||
                                  'FCUBSAccService/FCUBSAccService',
                                  L_XML,
                                  'text/xml;charset=utf-8');

      DBG('L_RESPONSE=' || L_RESPONSE);

      IF instr(L_RESPONSE, 'Record Successfully Saved and Authorized') > 0 THEN

        PR_UPDATE_MIN_MAJ_MASTER(L_REF,
                                 G.CUSTOMER_NO,
                                 L_CUST_ACCOUNT.CUST_AC_NO,
                                 'Y');

        PR_UPDATE_WS_LOG(L_REF, L_RESPONSE, 'S');

        COMMIT;

      ELSE

        PR_UPDATE_WS_LOG(L_REF, L_RESPONSE, 'F');

        ROLLBACK TO A;

        CONTINUE;

      END IF;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN PR_PROCESS_MINOR_TO_MAJOR');
        DBG('ERROR LINE NUMBER PR_PROCESS_MINOR_TO_MAJOR=' ||
            DBMS_UTILITY.format_error_backtrace);
        DBG('ERROR CODE IN PR_PROCESS_MINOR_TO_MAJOR=' || SQLCODE);
        DBG('ERROR MESSAGE in PR_PROCESS_MINOR_TO_MAJOR=' || SQLERRM);
        ROLLBACK TO A;
        CONTINUE;
    END;
  END LOOP;

END PR_PROCESS_MINOR_TO_MAJOR;

