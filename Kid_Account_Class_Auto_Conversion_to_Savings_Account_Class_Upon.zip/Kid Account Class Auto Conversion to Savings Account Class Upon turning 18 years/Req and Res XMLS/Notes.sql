
SELECT * FROM STTM_CUST_ACCOUNT WHERE ACCOUNT_CLASS = 'SA05' AND BRANCH_CODE = '001' AND RECORD_STAT = 'O' AND AUTH_STAT = 'A';


--to check if any major with account class - SA05
SELECT * FROM STTM_CUST_ACCOUNT WHERE ACCOUNT_CLASS = 'SA05' AND BRANCH_CODE = '001' AND RECORD_STAT = 'O' AND AUTH_STAT = 'A'
AND CUST_NO IN (SELECT CUSTOMER_NO FROM STTM_CUST_PERSONAL A WHERE A.MINOR = 'N');



update STTM_CUST_PERSONAL set MINOR = 'N' WHERE  CUSTOMER_NO = '00009427';
COMMIT;



--Below example ran eod also
--027 branch
SELECT * FROM STTM_CUST_aCCOUNT WHERE ACCOUNT_CLASS = 'SA05' AND BRANCH_CODE = '027' AND RECORD_STAT = 'O' AND AUTH_STAT = 'A'
AND CUST_NO IN (SELECT CUSTOMER_NO FROM STTM_CUST_PERSONAL A WHERE A.MINOR = 'Y') --000100008
update STTM_CUST_PERSONAL set MINOR = 'N' WHERE  CUSTOMER_NO = '00013598';

SELECT * FROM STTM_CUSACC_ACLASS WHERE CUST_AC_NO = '000100008'


--Error if any during EOD while transfer from old to new account class by batch
SELECT * FROM sttbs_actfr_err_log WHERE CUST_AC_NO = '000045685'



******************MOS ISSUE**************************************************************************
STDACTFR - Account Class Transfer did not get processed during EOD (Doc ID 2734782.1)	

SYMPTOMS
ACTUAL BEHAVIOR
---------------
STDACTFR - Account Class not transferred after EOD

EXPECTED BEHAVIOR
-----------------------
Customer account marked for Account Class transfer should get transferred as part of EOD.

STEPS
-----------------------
The issue can be reproduced at will with the following steps:
1. Mark an customer account for Account Class transfer
2. Run couple of EOD

BUSINESS IMPACT
-----------------------
The issue has the following business impact:
Due to this issue, Account class transfer is not happening.


CAUSE
The issue is caused by the following setup:

CASA Batch is not maintained as part of EOD process
 
EVIDENCE OF CAUSE
---------------
From the eitm_modules_installed table data received, it is evident that CASA Batch is not maintained as part of EOD.

SUPPORT OF CONCLUSION
---------------
As the CASA Batch is not maintained, system is not processing the accounts marked for account class transfer.

SOLUTION
check if CASABAT batch is maintained for the branch.
To maintain the CASABAT batch, please execute the following steps:

1. Go into the responsibility: Flexcube

2. Navigate to MENUPATH > EOC Operations > Maintenance > Mandatory Programs, or launch using function id EIDMANPE.

3. Perform the maintenance for Function CASABAT for EOC Group "Beginning of the day"
       

        2. Then check if the process ACCLSTFR is available in the table sttbs_automatic_process with invoke_during_bod as Y.

        3. Run the eod till next working day.

        4. If still the transfer has not happened, check in the error log table sttbs_actfr_err_log for errors and rectify the same.

******************MOS ISSUE**************************************************************************