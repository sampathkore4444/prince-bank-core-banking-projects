
select trunc(months_between(sysdate,dob)/12) year,
 trunc(mod(months_between(sysdate,dob),12)) month,
 trunc(sysdate-add_months(dob,trunc(months_between(sysdate,dob)/12)*12+trunc(mod(months_between(sysdate,dob),12)))) day
from (Select to_date('14122003','DDMMYYYY') dob from dual);


select customer_no,date_of_birth,sysdate,trunc(months_between(sysdate,dob)/12) year,
 trunc(mod(months_between(sysdate,dob),12)) month,
 trunc(sysdate-add_months(dob,trunc(months_between(sysdate,dob)/12)*12+trunc(mod(months_between(sysdate,dob),12)))) day
from (Select customer_no,date_of_birth, to_date(to_char(date_of_birth, 'DDMMYYYY'), 'DDMMYYYY') dob from Sttm_Cust_Personal) a 
where trunc(months_between(sysdate,dob)/12) =18;