*************************Final Starts*********************
BEGIN
DBMS_SCHEDULER.CREATE_PROGRAM (
program_name      => 'PROG_PROCESS_MINOR_TO_MAJOR',
program_action    => 'PR_PROCESS_MINOR_TO_MAJOR',
program_type      => 'STORED_PROCEDURE');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_SCHEDULE (
 schedule_name   => 'SCH_DAILY_MINOR_TO_MAJOR_SCHEDULE',
 start_date    => '01-dec-2021 10:39:00 pm',--SYSTIMESTAMP,
 repeat_interval  => 'FREQ=MINUTELY;INTERVAL=2;', --BYHOUR=10;BYMINUTE=39,--INTERVAL=5; BYDAY=SAT,SUN',
 --end_date     => SYSTIMESTAMP + INTERVAL '30' day,
 comments     => 'Daily at 10:39 AM');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_JOB (
  job_name     => 'JOB_PROCESS_MINOR_TO_MAJOR',
  program_name   => 'PROG_PROCESS_MINOR_TO_MAJOR',
  schedule_name   => 'SCH_DAILY_MINOR_TO_MAJOR_SCHEDULE',
  enabled            =>  true);
END;
/


--enable job
begin
dbms_scheduler.enable('JOB_PROCESS_MINOR_TO_MAJOR');
end;
--enable program
begin
DBMS_SCHEDULER.ENABLE('PROG_PROCESS_MINOR_TO_MAJOR');
end;


--drop commands in sequence

--drop1:
begin
  dbms_scheduler.drop_job('JOB_PROCESS_MINOR_TO_MAJOR');
end;

--drop2:
begin
 dbms_scheduler.drop_schedule('SCH_DAILY_MINOR_TO_MAJOR_SCHEDULE');
end;

--drop3:
begin
  dbms_scheduler.drop_program('PROG_PROCESS_MINOR_TO_MAJOR');
end;
**************************Final Ends****************************