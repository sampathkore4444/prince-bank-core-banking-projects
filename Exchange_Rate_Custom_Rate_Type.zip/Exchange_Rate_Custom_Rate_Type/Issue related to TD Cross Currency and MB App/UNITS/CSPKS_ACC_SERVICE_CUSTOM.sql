CREATE OR REPLACE PACKAGE BODY cspks_acc_service_custom AS

  PROCEDURE DBG(X VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('CO', 'cspks_acc_service_custom >>>: ' || X);
  END DBG;

  FUNCTION FN_ADJUSTMENTS(P_BRN             VARCHAR2,
                          P_ACC             VARCHAR2,
                          P_CCY             VARCHAR2,
                          P_CUST            VARCHAR2,
                          P_PROD            VARCHAR2,
                          P_LIQDT           DATE,
                          P_ERR_CODE        IN OUT NOCOPY VARCHAR2,
                          P_PARAM           IN OUT NOCOPY VARCHAR2,
                          P_FN_CALL_ID      IN NUMBER,
                          P_TBL_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('inside cspks_acc_service_custom.Fn_Adjustments ');
  
    DBG('cspks_acc_service_custom.Fn_Adjustments Process completed successfully');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in Fn_Adjustments ' || SQLERRM);
      RETURN FALSE;
  END FN_ADJUSTMENTS;

  FUNCTION FN_TELLER_UPLOAD(P_SCODE          IN VARCHAR2,
                            P_XREF           IN VARCHAR2,
                            P_PROD_CODE      IN VARCHAR2,
                            P_ACC_BR         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                            P_ACCOUNT        IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                            P_MODE           IN VARCHAR2,
                            P_LIQD_DATE      IN DATE,
                            P_BAL_TO_BE_WD   IN NUMBER,
                            P_LCY_EQUIV      IN NUMBER,
                            P_OFFSET_DETAILS IN VARCHAR2,
                            P_MCK_TSLIST     IN VARCHAR2,
                            P_ERR_CODES      IN OUT VARCHAR2,
                            P_ERR_PARAMS     IN OUT VARCHAR2,
                            P_FROMTD         IN BOOLEAN,
                            P_FN_CALL_ID     IN NUMBER,
                            P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Returning true from Fn_Teller_Upload');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in Cspks_Acc_Service_custom.Fn_Teller_Upload' ||
          SQLERRM);
      RETURN FALSE;
  END FN_TELLER_UPLOAD;

  PROCEDURE PR_CLOSE_OUT_WITHDRAWAL(P_SCODE           IN VARCHAR2,
                                    P_XREF            IN VARCHAR2,
                                    P_PROD_CODE       IN VARCHAR2,
                                    P_ACC_BR          IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                    P_ACCOUNT         IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                    P_MODE            IN VARCHAR2,
                                    P_LIQD_DATE       IN DATE,
                                    P_OFFSET_DETAILS  IN VARCHAR2,
                                    P_MCK_TSLIST      IN VARCHAR2,
                                    P_FLAG            IN OUT NUMBER,
                                    P_ERR_CODES       IN OUT VARCHAR2,
                                    P_ERR_PARAMS      IN OUT VARCHAR2,
                                    P_FROMTD          IN BOOLEAN := FALSE,
                                    P_AMT_DRAWN       IN OUT NUMBER,
                                    P_FN_CALL_ID      IN NUMBER,
                                    P_TBL_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
    --sampath starts
    L_RATE           NUMBER;
    L_CCY            STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_CLOSE_OUT_CCY  VARCHAR2(3);
    PRATEFLAG        NUMBER(1);
    LERRORCODE       ERTBS_MSGS.ERR_CODE%TYPE;
    L_LOCKED_ACCOUNT BOOLEAN := FALSE;
    L_ERR_CODE       VARCHAR2(255);
    L_BAL_TO_BE_WD   NUMBER(22, 3);
    L_RATE_CODE1     CSTM_PRODUCT.RATE_CODE_PREFERRED%TYPE;
  
    PROCEDURE PR_RELEASE_LOCK IS
    BEGIN
      IF L_LOCKED_ACCOUNT THEN
        IF NOT ICPKS_INTRADAY_UTILS.FN_RELEASE_LOCK(P_ACCOUNT,
                                                    P_ACC_BR,
                                                    ICPKS_PARTITION_INFO.G_THIS_PART,
                                                    L_ERR_CODE) THEN
          DBG('Attention..Some issue in releasing the lock..' ||
              L_ERR_CODE);
        ELSE
          DBG('Lock relased successfully');
          L_LOCKED_ACCOUNT := FALSE;
        END IF;
        CSPKS_ACC_SERVICE.G_CLOSE_OUT_WITHDRAWL := FALSE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('WO exception in releasing the lock' || SQLERRM);
    END PR_RELEASE_LOCK;
    --sampath ends
  BEGIN
    DBG('cspks_acc_service_custom.Pr_Close_Out_Withdrawal Process completed successfully');
  
    --sampath starts
  
    IF P_FN_CALL_ID = '2' THEN
    
      DBG('Ll_Ccy=' || P_TBL_CUSTOM_DATA('l_Ccy')); --TD CURRENCY
      DBG('l_close_out_ccy=' || P_TBL_CUSTOM_DATA('l_close_out_ccy')); --CASA CURRENCY
    
      IF P_TBL_CUSTOM_DATA('l_Ccy') <> P_TBL_CUSTOM_DATA('l_close_out_ccy') THEN
      
        IF TO_NUMBER(CSPKES_MISC.FN_GETPARAM(P_OFFSET_DETAILS, 5, '~')) IS NOT NULL THEN
          L_RATE := TO_NUMBER(CSPKES_MISC.FN_GETPARAM(P_OFFSET_DETAILS,
                                                      5,
                                                      '~'));
        ELSE
        
          L_RATE_CODE1 := 'S';
        
          IF NOT CYPKSS.FN_GETRATE(GLOBAL.current_branch,
                                   P_TBL_CUSTOM_DATA('l_Ccy'),
                                   P_TBL_CUSTOM_DATA('l_close_out_ccy'), --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                   'COMM',
                                   L_RATE_CODE1, --l_prod.rate_code_preferred,
                                   GLOBAL.APPLICATION_DATE,
                                   GLOBAL.APPLICATION_DATE,
                                   L_RATE,
                                   PRATEFLAG,
                                   LERRORCODE) THEN
            DBG('FAILED IN FN_GETRATE');
          
            /*
            
            
            IF NOT CYPKSS.FN_GETRATE(P_ACC_BR,
                                     L_CCY,
                                     L_CLOSE_OUT_CCY,
                                     L_RATE,
                                     PRATEFLAG,
                                     LERRORCODE)
            
             THEN*/
            P_FLAG := -1;
            PR_RELEASE_LOCK;
            RETURN;
          END IF;
        END IF;
      
        DBG('DERIVED EXCHANGE RATE=' || L_RATE);
        DBG('prateflag' || PRATEFLAG);
      
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(L_CCY,
                                      L_CLOSE_OUT_CCY,
                                      L_BAL_TO_BE_WD,
                                      L_RATE,
                                      'Y',
                                      ICPKS_BOD.G_OFFSET_AMT,
                                      LERRORCODE) THEN
          P_FLAG := -1;
          PR_RELEASE_LOCK;
        
          DBG('SKIPPING KERNEL');
          GLOBAL.G_SKIP_KERNEL := TRUE; --skipping kernel
        
          RETURN;
        END IF;
      
      END IF;
    
    END IF;
    --sampath ends
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CO',
                     'Exception in Pr_Close_Out_Withdrawal ' || SQLERRM);
      RAISE;
  END PR_CLOSE_OUT_WITHDRAWAL;

  FUNCTION FN_ONLINE_LIQ(P_ACC_BR          IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                         P_ACCOUNT         IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                         P_LIQD_DATE       IN DATE,
                         P_ERR_CODES       IN OUT VARCHAR2,
                         P_ERR_PARAMS      IN OUT VARCHAR2,
                         P_FN_CALL_ID      IN NUMBER,
                         P_TBL_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside function cspks_acc_service_custom.Fn_Online_Liq');
  
    DBG('End of cspks_acc_service_custom.Fn_Online_Liq');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IC',
                     'In When Others of   cspks_acc_service_custom.Fn_Online_Liq ..');
      DEBUG.PR_DEBUG('IC', SQLERRM);
      RETURN FALSE;
  END FN_ONLINE_LIQ;

  FUNCTION FN_PRE_ALLOW_CLOSE(P_ACCOUNT    IN VARCHAR2,
                              P_BRANCH     IN VARCHAR2,
                              P_ERRCODE    OUT VARCHAR2,
                              P_FIRST_CALL IN VARCHAR2,
                              P_FROMTD     IN BOOLEAN := FALSE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In cspks_acc_service_custom.Fn_Pre_Allow_Close..');
  
    DBG('Returning True from In cspks_acc_service_custom.Fn_Pre_Allow_Close..');
    RETURN TRUE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBG('Check Account Bal Tov? - No data found');
      RETURN FALSE;
    WHEN OTHERS THEN
      DBG('In others ' || SQLERRM);
      RETURN FALSE;
  END FN_PRE_ALLOW_CLOSE;

  FUNCTION FN_POST_ALLOW_CLOSE(P_ACCOUNT    IN VARCHAR2,
                               P_BRANCH     IN VARCHAR2,
                               P_ERRCODE    OUT VARCHAR2,
                               P_FIRST_CALL IN VARCHAR2,
                               P_FROMTD     IN BOOLEAN := FALSE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In cspks_acc_service_custom.Fn_Post_Allow_Close..');
  
    DBG('Returning True from In cspks_acc_service_custom.Fn_Post_Allow_Close..');
    RETURN TRUE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBG('Check Account Bal Tov? - No data found');
      RETURN FALSE;
    WHEN OTHERS THEN
      DBG('In others ' || SQLERRM);
      RETURN FALSE;
  END FN_POST_ALLOW_CLOSE;

END CSPKS_ACC_SERVICE_CUSTOM;
