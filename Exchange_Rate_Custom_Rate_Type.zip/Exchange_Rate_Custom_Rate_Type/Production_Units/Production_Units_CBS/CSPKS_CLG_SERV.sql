CREATE OR REPLACE PACKAGE BODY cspks_clg_serv 

/*-----------------------------------------------------------------------------------------------------
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  Changed By         : Kore Sampath Kumar
  Change Description : Commercial Exchange Rate Changes
  Seacrh String      : Commercial Exchange Rate Changes
  
  -------------------------------------------------------------------------------------------------------
  */
  
AS

  TYPE TYP_CHGDET_REC IS RECORD(
    CHG_AMOUNT NUMBER(22, 3));
  TYPE TYP_CHGDETNEW_TBL IS TABLE OF TYP_CHGDET_REC INDEX BY BINARY_INTEGER;
  TB_CHG_AMT TYP_CHGDETNEW_TBL;

  MAXINT CONSTANT NUMBER := POWER(2, 31) - 1;

  PKG_PROD VARCHAR2(4);

  G_CLG_BANK_CD STTMS_BANK.CLG_BANK_CD%TYPE;

  G_MAST_ROW_ID   ROWID;
  G_CGTB_ROW_ID   ROWID;
  PKG_NSF_TRACKED VARCHAR2(1) := 'N';

  G_RATE_TYPE_PREFERRED VARCHAR2(8);
  G_RATE_CODE_PREFERRED VARCHAR2(1);

  PKG_ENTRY_REC    CSTB_CLEARING_MASTER%ROWTYPE;
  PKG_CASA_ERROR   VARCHAR2(1) := 'N';
  PKG_REVR_ENTRY   VARCHAR2(1) := 'N';
  G_REFERRAL_QUEUE VARCHAR2(1) := 'N';

  TYPE PROD_TYPE_TAB IS TABLE OF CSTMS_PRODUCT%ROWTYPE INDEX BY VARCHAR2(4);
  TB_PROD_TYPE PROD_TYPE_TAB;

  P_TRACK_CHG_ENTRY_NSF VARCHAR2(1) := NULL;
  G_TXN_ACC             CSTBS_CLEARING_MASTER.REM_ACCOUNT%TYPE := NULL;
  G_TXN_ACC_BRN         CSTBS_CLEARING_MASTER.ACC_BRANCH%TYPE := NULL;
  G_TXN_ACC_CCY         CSTBS_CLEARING_MASTER.ACC_CCY%TYPE := NULL;
  G_CHG_LCY             IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE := NULL;
  G_CHG_CCY_AMT         IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE := NULL;
  G_EXCH_RATE_LCY       ACTBS_DAILY_LOG.EXCH_RATE%TYPE := NULL;
  PROCEDURE PR_TRACK_ACCOUNT_NSF(TRN_REF_NO IN VARCHAR2);

  G_NSF_ACC CSTBS_CLEARING_MASTER.REM_ACCOUNT%TYPE := NULL;

  L_ERR_CODE   ERTBS_MSGS.ERR_CODE%TYPE := NULL;
  L_ERR_PARAMS ERTBS_MSGS.MESSAGE%TYPE := NULL;

  FUNCTION FN_FRAME_CHG_ENTRIES(P_BRANCH       IN VARCHAR2,
                                P_ENTRY_REC    IN CSTBS_CLEARING_MASTER%ROWTYPE,
                                P_CHG_ROW      IN IFTMS_ARC_MAINT%ROWTYPE,
                                P_ACC_HAND     IN OUT ACPKSS.TBL_ACHOFF,
                                I              IN NUMBER,
                                P_PRODUCT_TYPE IN VARCHAR2,
                                P_ERR_CODE     IN OUT VARCHAR2)
    RETURN BOOLEAN;

  PROCEDURE PR_PRINT_CHG_ENTRIES(P_ACC_HAND IN ACPKSS.TBL_ACHOFF);

  PROCEDURE PR_REMOVE_ZERO_CHGS(P_ACC_HAND IN OUT ACPKSS.TBL_ACHOFF);

  TYPE REC_BRN IS RECORD(
    BRN_CD     VARCHAR2(3),
    CLG_BRN    VARCHAR2(3),
    SECT_CD    VARCHAR2(9),
    CLG_BRN_CD VARCHAR2(9));

  TYPE TB_BRN IS TABLE OF REC_BRN INDEX BY VARCHAR2(3);

  G_BRN_TAB   TB_BRN;
  PKG_BRN     VARCHAR2(3);
  PKG_BRN_REC REC_BRN;

  TYPE TB_STTM_BRN IS TABLE OF STTMS_BRANCH%ROWTYPE INDEX BY BINARY_INTEGER;

  STTM_BRN_TAB TB_STTM_BRN;

  FUNCTION FN_BACKUP_CLG_TABLES(P_TRANSACTION_REF_NO IN VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_DELETE_BACKUP(P_TRANSACTION_REF_NO IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_REFERRAL_QUEUE(PBRANCH         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                             PCUSTNO         IN STTMS_CUST_ACCOUNT.CUST_NO%TYPE,
                             PACCOUNT        IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                             PREFNO          IN CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE,
                             PLCYAMT         IN CSTBS_CLEARING_MASTER.ACC_CCY_AMT%TYPE,
                             PEVENTNO        IN NUMBER,
                             PVALUEDATE      IN DATE,
                             PTEMPFLAG       IN BOOLEAN,
                             P_CONSOL_REF_NO IN VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN;

  FUNCTION FN_TEMP_TO_QUEUE(PCUSTNO IN STTMS_CUST_ACCOUNT.CUST_NO%TYPE)
    RETURN BOOLEAN;

  FUNCTION FN_CHG_PROC(PBRANCH     IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                       P_ENTRY_REC IN OUT CSTBS_CLEARING_MASTER%ROWTYPE,
                       P_CHG_ROW   IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                       P_ERR_CODE  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                       P_ERRPARAM  IN OUT ERTBS_MSGS.MESSAGE%TYPE,
                       P_ACC_HAND  IN OUT ACPKS.TBL_ACHOFF) RETURN BOOLEAN;

  PROCEDURE PR_BUILD_XRATE_P_AND_L_ENTRIES(P_ACC_HAND  IN OUT ACPKS.TBL_ACHOFF,
                                           P_ARC_ROW   IN IFTMS_ARC_MAINT%ROWTYPE,
                                           P_NEG_AMT   IN NUMBER,
                                           P_ENTRY_REC IN CSTBS_CLEARING_MASTER%ROWTYPE,
                                           P_ERR_CODE  IN OUT VARCHAR2,
                                           P_RET       IN OUT NUMBER);

  G_CONSOL_REFERRAL_REQD VARCHAR2(1) := 'N';

  PROCEDURE DBG(X VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('CA', 'cspks_clg_serv >>>: ' || X);
  END DBG;

  PROCEDURE PR_PRINT_ACCTNG_TABLE(P_ACC_HAND IN ACPKS.TBL_ACHOFF);

  PROCEDURE PR_PRINT_ACCTNG_TABLE(P_ACC_HAND IN ACPKS.TBL_ACHOFF) IS
    I      NUMBER;
    L_ROW  VARCHAR2(500);
    L_LINE VARCHAR2(500);
  BEGIN
  
    SELECT RPAD('-',
                20 + 15 + 15 + 15 + 15 + 1 + 1 + 3 + 3 + 3 + 6 + 3,
                '-')
      INTO L_LINE
      FROM DUAL;
    DBG(L_LINE);
    SELECT '|' || RPAD('Tag', 10, '.') || '|' || RPAD('Brn', 3, '.') || '|' ||
           RPAD('Acc', 20, '.') || '|' || RPAD('Lcy Amt', 15, '.') || '|' ||
           RPAD('Fcy Amt', 15, '.') || '|' || RPAD('Exch Rate', 15, '.') || '|' ||
           RPAD('D/C', 1, '.') || '|' || RPAD('Netting', 1, '.') || '|' ||
           RPAD('Ccy', 3, '.') || '|' || RPAD('TrnCode', 3, '.') || '|' ||
           RPAD('Brn', 3, '.') || '|'
      INTO L_ROW
      FROM DUAL;
    DBG(L_ROW);
    DBG(L_LINE);
  
    FOR I IN 1 .. P_ACC_HAND.COUNT LOOP
      IF P_ACC_HAND.EXISTS(I) THEN
        SELECT '|' || RPAD(P_ACC_HAND(I).AMOUNT_TAG, 10, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_BRANCH, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_NO, 20, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).LCY_AMOUNT, -1111), 15, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).FCY_AMOUNT, -1111), 15, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).EXCH_RATE, -1111), 15, '.') || '|' ||
               RPAD(P_ACC_HAND(I).DRCR_IND, 1, '.') || '|' ||
               RPAD(P_ACC_HAND(I).NETTING_IND, 1, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_CCY, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).TRN_CODE, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_BRANCH, 3, '.') || '|'
          INTO L_ROW
          FROM DUAL;
        DBG(L_ROW);
        DBG(L_LINE);
      END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN;
  END PR_PRINT_ACCTNG_TABLE;

  FUNCTION FN_PROCESS_INSTR(P_ENTRY_REC IN CSTBS_CLEARING_MASTER%ROWTYPE,
                            P_ERR_CODE  IN OUT VARCHAR2) RETURN NUMBER IS
    L_NO NUMBER;
  BEGIN
    DEBUG.PR_DEBUG('CG', 'In process instr ' || P_ENTRY_REC.BRANCH_CODE);
  
    IF P_ENTRY_REC.BANK_CODE <> GLOBALS_FRC.G_TBL_STTM_BANK_REC.BANK_CODE
    
     THEN
      DEBUG.PR_DEBUG('CG', 'Instrumen may have been issued by us');
      BEGIN
        SELECT 1
          INTO L_NO
          FROM ISTM_INSTR_TXN
         WHERE INSTR_NO = P_ENTRY_REC.INSTRUMENT_NO_1
           AND PAYABLE_BANK = P_ENTRY_REC.BANK_CODE
           AND PAYABLE_BRANCH = P_ENTRY_REC.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('CG', 'Cud not locate the instrument ' || SQLERRM);
          RETURN 0;
      END;
      UPDATE ISTMS_INSTR_TXN
         SET INSTR_STAT = 'LIQD'
       WHERE INSTR_NO = P_ENTRY_REC.INSTRUMENT_NO_1
         AND PAYABLE_BANK = P_ENTRY_REC.BANK_CODE
         AND PAYABLE_BRANCH = P_ENTRY_REC.BRANCH_CODE;
    ELSE
      DEBUG.PR_DEBUG('CG', 'No instrument to b marked as liq');
    END IF;
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'In exception while trin to mark instr as liq ' ||
                     SQLERRM);
      P_ERR_CODE := 'CG-INSTR001';
      OVPKS.PR_APPENDTBL('CG-INSTR001', 'Exception in fn_save_entry');
      RETURN - 1;
  END FN_PROCESS_INSTR;

  PROCEDURE PR_END_POS(STR         IN VARCHAR2,
                       SEARCH_CHAR IN CHAR,
                       END_POS     IN OUT NUMBER) IS
    POS NUMBER := 1;
  BEGIN
    LOOP
      END_POS := INSTR(STR, SEARCH_CHAR, POS);
      IF END_POS = 0 THEN
        END_POS := POS;
        EXIT;
      END IF;
      POS := POS + 1;
    END LOOP;
    DEBUG.PR_DEBUG('CG', 'Final end pos' || END_POS);
  END;

  FUNCTION FN_HASH40(X VARCHAR2) RETURN NUMBER IS
    L NUMBER;
    N NUMBER := 0;
    C NUMBER;
  BEGIN
    L := LENGTH(X);
    FOR I IN 1 .. L LOOP
      C := CSPKES_MISC.FN_GETASCII(SUBSTR(X, I, 1)) - 48;
      IF C > 9 THEN
        C := C - 7;
      END IF;
      N := N + C * POWER(40, L - I);
    END LOOP;
  
    IF N > MAXINT THEN
      N := MAXINT - N;
    END IF;
  
    RETURN N;
  END FN_HASH40;

  PROCEDURE PR_GET_PROD(P_PROD VARCHAR2) IS
  
    H CSTMS_PRODUCT.PRODUCT_CODE%TYPE;
  
    L_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM VARCHAR2(250);
  
  BEGIN
    IF PKG_PROD <> P_PROD THEN
    
      H := P_PROD;
      IF NOT TB_PROD_TYPE.EXISTS(H) THEN
      
        DEBUG.PR_DEBUG('CG',
                       'Calling Fn_Get_Product_Rec_Wrp for...' || P_PROD);
        IF CSPKSS_FUNCTION_CACHE.FN_GET_PRODUCT_REC_WRP(P_PROD,
                                                        L_ERR_CODE,
                                                        L_ERR_PARAM) THEN
          TB_PROD_TYPE(H) := CSPKSS_FUNCTION_CACHE.G_TBL_CSTM_PROD_REC;
          DEBUG.PR_DEBUG('CG', 'Product details retrieved...');
        ELSE
          DEBUG.PR_DEBUG('CG',
                         'Error in getting the product details...' ||
                         L_ERR_CODE);
          RETURN;
        END IF;
        DEBUG.PR_DEBUG('CG', 'Product details retrived...');
      
      END IF;
      PKG_PROD_REC := TB_PROD_TYPE(H);
      PKG_PROD     := P_PROD;
    END IF;
  END PR_GET_PROD;

  PROCEDURE PR_GET_BRN_DET(P_BRN VARCHAR2) IS
  
    L STTMS_BRANCH.BRANCH_CODE%TYPE;
  BEGIN
    IF PKG_BRN <> P_BRN THEN
    
      L := P_BRN;
      IF NOT G_BRN_TAB.EXISTS(L) THEN
        SELECT A.BRANCH_CODE, A.CLEARING_BRN, B.SECTOR_CODE, B.CLG_BRN_CODE
          INTO G_BRN_TAB(L)
          FROM STTMS_BRANCH A, STTMS_BRANCH B
         WHERE A.CLEARING_BRN = B.BRANCH_CODE
           AND A.BRANCH_CODE = P_BRN;
      END IF;
      PKG_BRN_REC := G_BRN_TAB(L);
      PKG_BRN     := P_BRN;
    END IF;
  END PR_GET_BRN_DET;

  PROCEDURE CALL_DO_IT(P_REF_NO      IN CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                       P_EVNT_SEQ    IN CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO%TYPE,
                       P_ERR_CODES   IN VARCHAR2,
                       P_PARAM_LIST  IN VARCHAR2,
                       P_AMOUNTS     IN VARCHAR2,
                       P_MODULE      IN VARCHAR2,
                       P_DISP_REQ    IN CHAR,
                       P_UPD_REQ     IN CHAR,
                       PSEP          IN CHAR,
                       P_LANG_CD     IN SMTBS_LANGUAGE.LANG_CODE%TYPE,
                       PBATCH_ONLINE IN CHAR,
                       PMSGS         OUT VARCHAR2,
                       PMSGTYPES     OUT VARCHAR2,
                       PAMOUNT       OUT NUMBER,
                       PCOUNT        OUT NUMBER,
                       PTYPE         OUT VARCHAR2,
                       PRETERRCODE   OUT VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    IF NOT OVPKSS_MISC.DO_IT(P_REF_NO
                             
                            ,
                             P_EVNT_SEQ,
                             P_ERR_CODES,
                             P_PARAM_LIST,
                             P_AMOUNTS,
                             P_MODULE,
                             P_DISP_REQ,
                             P_UPD_REQ,
                             PSEP,
                             P_LANG_CD,
                             PBATCH_ONLINE,
                             PMSGS,
                             PMSGTYPES,
                             PAMOUNT,
                             PCOUNT,
                             PTYPE,
                             PRETERRCODE) THEN
    
      DEBUG.PR_DEBUG('CG', 'Ovpkss_misc.do_it returns FALSE ');
    
      RETURN;
    END IF;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END CALL_DO_IT;

  FUNCTION FN_REVERSE_PDC(P_BRANCH    IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                          P_REF_NO    IN CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE,
                          P_REMARKS   IN VARCHAR2,
                          P_ERR_CODE  OUT ERTBS_MSGS.ERR_CODE%TYPE,
                          P_ERR_PARAM OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
    L_REC               CSTBS_CLEARING_MASTER%ROWTYPE;
    L_EVENT_SEQ         CSTBS_CLEARING_DETAILS.EVENT_SEQ_NO%TYPE;
    L_DEFER_LIQUIDATION CGTMS_PRODUCT_REFERRAL.DEFER_LIQUIDATION%TYPE;
  BEGIN
    BEGIN
      SELECT *
        INTO L_REC
        FROM CSTBS_CLEARING_MASTER
       WHERE MODULE_REFERENCE_NO = P_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Some thing happened =' || SQLERRM);
        BEGIN
          SELECT *
            INTO L_REC
            FROM CSTBS_CLEARING_MASTER
           WHERE REFERENCE_NO = P_REF_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found for the referenece=' || P_REF_NO);
            NULL;
        END;
    END;
    BEGIN
      SELECT NVL(DEFER_LIQUIDATION, 'N')
        INTO L_DEFER_LIQUIDATION
        FROM CGTMS_PRODUCT_REFERRAL
       WHERE PRODUCT_CODE = L_REC.PRODUCT_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_CODE  := 'CG-PROD-001';
        P_ERR_PARAM := L_REC.PRODUCT_CODE;
    END;
    IF L_DEFER_LIQUIDATION = 'Y' THEN
      IF NVL(L_REC.DISPATCH_STATUS, 'N') = 'L' THEN
        L_EVENT_SEQ := 4;
      ELSIF NVL(L_REC.DISPATCH_STATUS, 'N') = 'D' THEN
        L_EVENT_SEQ := 3;
      ELSIF NVL(L_REC.DISPATCH_STATUS, 'N') = 'B' THEN
        L_EVENT_SEQ := 2;
      END IF;
    ELSE
      L_EVENT_SEQ := 2;
    END IF;
    BEGIN
      INSERT INTO CSTBS_CLEARING_DETAILS
        (DIRECTION,
         PRODUCT_CODE,
         TXN_BRANCH,
         END_POINT,
         REFERENCE_NO,
         REM_ACCOUNT,
         BEN_ACCOUNT,
         ACC_BRANCH,
         INSTRUMENT_NO_1,
         BRANCH_CODE,
         SECTOR_CODE,
         XREF,
         EVENT_SEQ_NO,
         REMARKS,
         STATUS,
         ENTRY_NO)
      VALUES
        (L_REC.DIRECTION,
         L_REC.PRODUCT_CODE,
         L_REC.TXN_BRANCH,
         L_REC.END_POINT,
         L_REC.REFERENCE_NO,
         L_REC.REM_ACCOUNT,
         L_REC.BEN_ACCOUNT,
         L_REC.ACC_BRANCH,
         L_REC.INSTRUMENT_NO_1,
         L_REC.BRANCH_CODE,
         L_REC.SECTOR_CODE,
         L_REC.XREF,
         NVL(G_EVENT_SEQ, L_EVENT_SEQ),
         P_REMARKS,
         L_REC.STATUS,
         L_REC.ENTRY_NO + 1);
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        DEBUG.PR_DEBUG('CG', 'event is not incremented');
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('CG',
                       'problem in inserting into cstbs_clearing_details1' ||
                       SQLERRM);
        RETURN FALSE;
    END;
  
    DBG('going to call for return');
    IF DEPK_PDC.G_PD_REVERSE THEN
      DBG('inside pd reversal call');
    ELSE
      DBG('not inside pd reversal call');
      IF L_REC.MODULE_CODE = 'PD' THEN
        DBG('Before Returning the PD transactions...');
        IF NOT DEPK_PDC.FN_RETN_PDC_CONTRACT(L_REC.MODULE_REFERENCE_NO,
                                             P_ERR_CODE,
                                             P_ERR_PARAM) THEN
          DBG('Failed in DEPK_PDC.fn_return_pdc_contract...' || P_ERR_CODE || '~' ||
              P_ERR_PARAM);
          RETURN FALSE;
        ELSE
          DBG('Sucessfully Returned the PD transactions...');
        END IF;
      END IF;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'fn_reverse_pdc:' || SQLERRM);
      DEBUG.PR_DEBUG('CG',
                     'fn_reverse_pdc error here--->  ' ||
                     DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_REVERSE_PDC;

  FUNCTION FN_READ_ENTRY_DATA_STRING(P_ENTRY_DATA_STRING IN VARCHAR2,
                                     P_ENTRY_COLUMN_LIST IN VARCHAR2,
                                     PDTF                IN VARCHAR2,
                                     P_ENTRY_REC         OUT CSTBS_CLEARING_MASTER%ROWTYPE,
                                     P_ERR_CODE          OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_ENTRY_COLUMN_LIST VARCHAR2(6000);
  
    L_COLUMN_LIST VARCHAR2(6000);
  
    L_COLUMN_NAME        VARCHAR2(30);
    L_COL_COUNT          INTEGER := 1;
    L_POS_IN_COLUMN_LIST INTEGER := 0;
    L_COLUMN_VALUE       VARCHAR2(32767);
    L_PRODUCT_TYPE       CSTMS_PRODUCT.PRODUCT_TYPE%TYPE;
    L_BANK_CODE          DETMS_CLG_BRN_CODE.BANK_CODE%TYPE;
    L_BRN_CODE           DETMS_CLG_BRN_CODE.BRANCH_CODE%TYPE;
    L_SECTOR_CODE        DETMS_CLG_BRN_CODE.SECTOR_CODE%TYPE;
    L_ROUTING_NO         STTMS_BRANCH.ROUTING_NO%TYPE;
    L_START_POS          INTEGER;
    L_END_POS            INTEGER;
    L_LEN                INTEGER;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside fn_read_entry_data_string');
  
    IF GWPKS_UTIL.G_FROM_BEAN THEN
    
      L_COLUMN_LIST := 'SCODE~XREF~PRODUCT~TXNBRN~REMACCOUNT~REMBANK~REMBRANCH~BENACCOUNT~BENBANK~BENBRANCH~INSTRNO~INSTRCCY~INSTRAMT~INSTRDATE~TXNDATE~VALDATE~LATECLG~ROUTINGNO~ENDPOINT~SERIALNO~FCCREF~STATUS~ENTRY_NO~BENE_CCY~REGCC~SPLCHQ~ACCCY~ACCCYAMT~EXCHRATE~ROUTBNKCOD~ROUTBNKNAM~ROUTBRNCOD~ROUTBRNNAM~ROUTSECTCOD~ROUTSECTDISC~BENCUSTID~LCYTOTCHGAMT~TCYTOTCHGAMT~DENMCCY1~DENMAMT1~DENMCCY2~DENMAMT2~CUST_ID~ACCTITLE~REMARKS~PROJECTNAME~UNITPAYMENT~UNITID~DEPOSITSLIPNO~INSTRUMENT_TYPE~BENROUTINGNO~BATCHNO~CHEQUEISSUEDATE~';
    ELSE
      L_COLUMN_LIST := 'SCODE~XREF~PRODUCT~TXNBRN~REMACCOUNT~REMBANK~REMBRANCH~BENACCOUNT~BENBANK~BENBRANCH~INSTRNO~INSTRCCY~INSTRAMT~INSTRDATE~TXNDATE~VALDATE~LATECLG~ROUTINGNO~ENDPOINT~SERIALNO~FCCREF~STATUS~ENTRY_NO~BENE_CCY~DIN~DIN_DATE~REMARKS~CONSIDER_FOR_REG_CC~SPL_CHQ_FLG~ACCCY~ACCCYAMT~EXCHRATE~MODCODE~MODREFNO~RECSTAT~AUTHSTAT~MAKERID~CHECKERID~MAKERDTSTAMP~CHEKERDTSTAMP~INSTRUMENT_TYPE~BENROUTINGNO~BATCHNO~';
    END IF;
  
    IF P_ENTRY_COLUMN_LIST IS NULL THEN
      L_ENTRY_COLUMN_LIST := L_COLUMN_LIST;
    ELSE
      L_ENTRY_COLUMN_LIST := UPPER(P_ENTRY_COLUMN_LIST);
    END IF;
    DEBUG.PR_DEBUG('CG', 'Before the loop');
  
    L_COLUMN_NAME := CSPKES_MISC.FN_GETPARAM(L_ENTRY_COLUMN_LIST,
                                             L_COL_COUNT,
                                             '~');
  
    WHILE L_COLUMN_NAME <> 'EOPL' LOOP
      L_POS_IN_COLUMN_LIST := CSPKES_MISC.FN_GETPARAM_NO(L_ENTRY_COLUMN_LIST,
                                                         L_COLUMN_NAME,
                                                         '~');
      L_COLUMN_VALUE       := CSPKES_MISC.FN_GETPARAM(P_ENTRY_DATA_STRING,
                                                      L_POS_IN_COLUMN_LIST,
                                                      '~');
      DEBUG.PR_DEBUG('CG',
                     'Inside the loop for ' || L_COLUMN_NAME || ' -> ' ||
                     L_COLUMN_VALUE);
      IF L_COLUMN_NAME = 'PRODUCT' THEN
        P_ENTRY_REC.PRODUCT_CODE := L_COLUMN_VALUE;
        PR_GET_PROD(P_ENTRY_REC.PRODUCT_CODE);
        L_PRODUCT_TYPE := PKG_PROD_REC.PRODUCT_TYPE;
      ELSIF L_COLUMN_NAME = 'REMACCOUNT' THEN
        P_ENTRY_REC.REM_ACCOUNT := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'BENACCOUNT' THEN
        P_ENTRY_REC.BEN_ACCOUNT := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'TXNBRN' THEN
        P_ENTRY_REC.TXN_BRANCH := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'ROUTINGNO' THEN
        P_ENTRY_REC.ROUTING_NO := L_COLUMN_VALUE;
        L_ROUTING_NO           := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'INSTRNO' THEN
        P_ENTRY_REC.INSTRUMENT_NO_1 := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'INSTRCCY' THEN
        P_ENTRY_REC.INSTRUMENT_CCY := L_COLUMN_VALUE;
      
      ELSIF L_COLUMN_NAME = 'PROJECTNAME' THEN
        P_ENTRY_REC.PROJECT_NAME := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'UNITPAYMENT' THEN
        P_ENTRY_REC.UNIT_PAYMENT := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'UNITID' THEN
        P_ENTRY_REC.UNIT_ID := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'DEPOSITSLIPNO' THEN
        P_ENTRY_REC.DEPOSIT_SLIP_NO := L_COLUMN_VALUE;
      
      ELSIF L_COLUMN_NAME = 'INSTRUMENT_TYPE' THEN
        P_ENTRY_REC.INSTRUMENT_TYPE := L_COLUMN_VALUE;
      
      ELSIF L_COLUMN_NAME = 'BENROUTINGNO' THEN
        P_ENTRY_REC.BENROUTINGNO := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'BATCHNO' THEN
        P_ENTRY_REC.BATCH_NO := L_COLUMN_VALUE;
      
      ELSIF L_COLUMN_NAME = 'INSTRAMT' THEN
        P_ENTRY_REC.INSTRUMENT_AMT := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'INSTRDATE' THEN
        P_ENTRY_REC.INSTRUMENT_DATE := TO_DATE(L_COLUMN_VALUE, PDTF);
      ELSIF L_COLUMN_NAME = 'TXNDATE' THEN
        P_ENTRY_REC.TXN_DATE := TO_DATE(L_COLUMN_VALUE, PDTF);
      ELSIF L_COLUMN_NAME = 'VALDATE' THEN
        P_ENTRY_REC.VAL_DATE_CUST := TO_DATE(L_COLUMN_VALUE, PDTF);
      ELSIF L_COLUMN_NAME = 'LATECLG' THEN
        P_ENTRY_REC.LATE_CLG_FLG := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'XREF' THEN
        P_ENTRY_REC.XREF := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'ENTRY_NO' THEN
        P_ENTRY_REC.ENTRY_NO := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'SCODE' THEN
        P_ENTRY_REC.SCODE := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'BENE_CCY' THEN
        P_ENTRY_REC.BENE_CCY := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'ACCCY' THEN
        IF L_COLUMN_VALUE <> 'EOPL' THEN
          P_ENTRY_REC.ACC_CCY := L_COLUMN_VALUE;
        END IF;
      ELSIF L_COLUMN_NAME = 'ACCCYAMT' THEN
        IF L_COLUMN_VALUE <> 'EOPL' THEN
          P_ENTRY_REC.ACC_CCY_AMT := L_COLUMN_VALUE;
        END IF;
      ELSIF L_COLUMN_NAME = 'EXCHRATE' THEN
        IF L_COLUMN_VALUE <> 'EOPL' THEN
          P_ENTRY_REC.EXCH_RATE := L_COLUMN_VALUE;
        END IF;
      ELSIF L_COLUMN_NAME = 'FCCREF' THEN
        P_ENTRY_REC.REFERENCE_NO := L_COLUMN_VALUE;
        DEBUG.PR_DEBUG('CG',
                       'p_entry_rec.reference_no ' ||
                       P_ENTRY_REC.REFERENCE_NO);
      
      ELSIF L_COLUMN_NAME = 'REMARKS' THEN
        P_ENTRY_REC.REMARKS := L_COLUMN_VALUE;
        DEBUG.PR_DEBUG('CG', 'p_entry_rec.rematks ' || P_ENTRY_REC.REMARKS);
      
      ELSIF L_COLUMN_NAME = 'MODCODE' THEN
        IF L_COLUMN_VALUE <> 'EOPL' THEN
          P_ENTRY_REC.MODULE_CODE := L_COLUMN_VALUE;
        END IF;
      ELSIF L_COLUMN_NAME = 'MODREFNO' THEN
        IF L_COLUMN_VALUE <> 'EOPL' THEN
          P_ENTRY_REC.MODULE_REFERENCE_NO := L_COLUMN_VALUE;
        END IF;
      ELSIF L_COLUMN_NAME = 'RECSTAT' THEN
        IF L_COLUMN_VALUE <> 'EOPL' THEN
          P_ENTRY_REC.RECORD_STAT := NVL(L_COLUMN_VALUE, 'O');
        END IF;
      ELSIF L_COLUMN_NAME = 'AUTHSTAT' THEN
        IF L_COLUMN_VALUE <> 'EOPL' THEN
          P_ENTRY_REC.AUTH_STAT := NVL(L_COLUMN_VALUE, 'U');
        END IF;
      ELSIF L_COLUMN_NAME = 'MAKERID' THEN
        IF L_COLUMN_VALUE <> 'EOPL' THEN
          P_ENTRY_REC.MAKER_ID := L_COLUMN_VALUE;
        END IF;
      ELSIF L_COLUMN_NAME = 'CHECKERID' THEN
        IF L_COLUMN_VALUE <> 'EOPL' THEN
          P_ENTRY_REC.CHECKER_ID := L_COLUMN_VALUE;
        END IF;
      ELSIF L_COLUMN_NAME = 'MAKERDTSTAMP' THEN
        IF L_COLUMN_VALUE <> 'EOPL' THEN
          P_ENTRY_REC.MAKER_DT_STAMP := L_COLUMN_VALUE;
        END IF;
      ELSIF L_COLUMN_NAME = 'CHECKERDTSTAMP' THEN
        IF L_COLUMN_VALUE <> 'EOPL' THEN
          P_ENTRY_REC.CHECKER_DT_STAMP := TO_DATE(L_COLUMN_VALUE,
                                                  'YYYY/MM/DD HH:MI:SS');
        END IF;
      
      ELSIF L_COLUMN_NAME = 'CHEQUEISSUEDATE' THEN
        IF L_COLUMN_VALUE <> 'EOPL' THEN
          P_ENTRY_REC.CHEQUE_ISSUE_DATE := TO_DATE(L_COLUMN_VALUE, PDTF);
        END IF;
      
      END IF;
      IF (L_PRODUCT_TYPE = 'IC') THEN
        P_ENTRY_REC.DIRECTION := 'I';
        IF L_COLUMN_NAME = 'REMBRANCH' THEN
          P_ENTRY_REC.ACC_BRANCH := L_COLUMN_VALUE;
        ELSIF L_COLUMN_NAME = 'ENDPOINT' THEN
          P_ENTRY_REC.END_POINT := L_COLUMN_VALUE;
        ELSIF L_COLUMN_NAME = 'BENBANK' THEN
          P_ENTRY_REC.BANK_CODE := L_COLUMN_VALUE;
        ELSIF L_COLUMN_NAME = 'BENBRANCH' THEN
          P_ENTRY_REC.BRANCH_CODE := L_COLUMN_VALUE;
        ELSIF L_COLUMN_NAME = 'DIN' THEN
          P_ENTRY_REC.DIN := L_COLUMN_VALUE;
          DEBUG.PR_DEBUG('CG', 'p_entry_rec.din ' || P_ENTRY_REC.DIN);
        ELSIF L_COLUMN_NAME = 'DIN_DATE' THEN
          P_ENTRY_REC.DIN_DATE := TO_DATE(L_COLUMN_VALUE, PDTF);
          DEBUG.PR_DEBUG('CG',
                         'p_entry_rec.din_date ' || P_ENTRY_REC.DIN_DATE);
        ELSIF L_COLUMN_NAME = 'REMARKS' THEN
          P_ENTRY_REC.REMARKS := L_COLUMN_VALUE;
          DEBUG.PR_DEBUG('CG',
                         'p_entry_rec.rematks ' || P_ENTRY_REC.REMARKS);
        ELSIF L_COLUMN_VALUE = 'BENROUTINGNO' THEN
          P_ENTRY_REC.BENROUTINGNO := L_COLUMN_VALUE;
          DEBUG.PR_DEBUG('CG',
                         'p_entry_rec.benroutingno' ||
                         P_ENTRY_REC.BENROUTINGNO);
        END IF;
      ELSIF (L_PRODUCT_TYPE = 'OC') THEN
        P_ENTRY_REC.DIRECTION := 'O';
        IF L_COLUMN_NAME = 'BENBRANCH' THEN
        
          DEBUG.PR_DEBUG('CG', 'account branch assignment commented');
        
        ELSIF L_COLUMN_NAME IN ('CONSIDER_FOR_REG_CC', 'REGCC') THEN
          P_ENTRY_REC.CONSIDER_FOR_REG_CC := L_COLUMN_VALUE;
        
        ELSIF L_COLUMN_NAME IN ('SPL_CHG_FLG', 'SPLCHQ') THEN
          P_ENTRY_REC.SPL_CHQ_FLG := L_COLUMN_VALUE;
        END IF;
      END IF;
      L_COL_COUNT := L_COL_COUNT + 1;
    
      L_COLUMN_NAME := CSPKES_MISC.FN_GETPARAM(L_ENTRY_COLUMN_LIST,
                                               L_COL_COUNT,
                                               '~');
    
    END LOOP;
    DEBUG.PR_DEBUG('CG', 'Routing mask is ..' || G_ROUTING_MASK);
    IF G_ROUTING_MASK IS NULL THEN
      P_ERR_CODE := 'CG-CL0020';
      DEBUG.PR_DEBUG('CG', 'Routing Mask is null..');
      OVPKS.PR_APPENDTBL('CG-CL0020', 'Exception in fn_save_entry');
      RETURN FALSE;
    END IF;
    IF L_PRODUCT_TYPE = 'OC' THEN
      PR_BREAK_ROUTING_NO(L_ROUTING_NO, P_ENTRY_REC);
    END IF;
    P_ENTRY_REC.AUTH_STAT := 'U';
    DEBUG.PR_DEBUG('CG', 'Thru with reading string');
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      DBG('cspks_clg_serv_cluster.fn_post_read_entry_data_string ');
      IF NOT
          CSPKS_CLG_SERV_CLUSTER.FN_POST_READ_ENTRY_DATA_STRING(P_ENTRY_DATA_STRING,
                                                                P_ENTRY_COLUMN_LIST,
                                                                PDTF,
                                                                P_ENTRY_REC,
                                                                P_ERR_CODE,
                                                                L_FN_CALL_ID,
                                                                L_TB_CLUSTER_DATA)
      
       THEN
        DBG('Failure has happened in cspks_clg_serv_cluster.fn_post_read_entry_data_string');
        RETURN FALSE;
      END IF;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'Exception in fn_read_entry_data_string - ' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_READ_ENTRY_DATA_STRING;

  PROCEDURE PR_BREAK_ROUTING_NO(P_ROUTING_NO IN VARCHAR2,
                                P_ENTRY_REC  IN OUT CSTBS_CLEARING_MASTER%ROWTYPE) IS
  
  BEGIN
  
    PR_BREAK_ROUTING_NO(P_ROUTING_NO,
                        P_ENTRY_REC.SECTOR_CODE,
                        P_ENTRY_REC.BANK_CODE,
                        P_ENTRY_REC.BRANCH_CODE);
  
  END PR_BREAK_ROUTING_NO;

  PROCEDURE PR_BREAK_ROUTING_NO(P_ROUTING_NO  IN VARCHAR2,
                                P_SECTOR_CODE OUT VARCHAR2,
                                P_BANK_CODE   OUT VARCHAR2,
                                P_BRANCH_CODE OUT VARCHAR2) IS
    L_START_POS   INTEGER;
    L_END_POS     INTEGER;
    L_LEN         INTEGER;
    L_BANK_CODE   DETMS_CLG_BRN_CODE.BANK_CODE%TYPE;
    L_BRN_CODE    DETMS_CLG_BRN_CODE.BRANCH_CODE%TYPE;
    L_SECTOR_CODE DETMS_CLG_BRN_CODE.SECTOR_CODE%TYPE;
  BEGIN
    L_START_POS := INSTR(G_ROUTING_MASK, 'B', 1);
    DEBUG.PR_DEBUG('CG', 'l_start_pos of BANK is  ' || L_START_POS);
    L_END_POS := 0;
    PR_END_POS(G_ROUTING_MASK, 'B', L_END_POS);
    L_LEN := L_END_POS - L_START_POS;
    DEBUG.PR_DEBUG('CG', 'length of BANK string ' || L_LEN);
    L_BANK_CODE := SUBSTR(P_ROUTING_NO, L_START_POS, L_LEN);
    DEBUG.PR_DEBUG('CG', 'Bank Code is ...' || L_BANK_CODE);
    L_START_POS := INSTR(G_ROUTING_MASK, 'b', 1);
    L_END_POS   := 0;
    PR_END_POS(G_ROUTING_MASK, 'b', L_END_POS);
    L_LEN := L_END_POS - L_START_POS;
    DEBUG.PR_DEBUG('CG', 'length of Branch string ' || L_LEN);
    L_BRN_CODE := SUBSTR(P_ROUTING_NO, L_START_POS, L_LEN);
    DEBUG.PR_DEBUG('CG', 'Brn Code is...' || L_BRN_CODE);
    L_START_POS := INSTR(G_ROUTING_MASK, 'S', 1);
    L_END_POS   := 0;
    PR_END_POS(G_ROUTING_MASK, 'S', L_END_POS);
    L_LEN := L_END_POS - L_START_POS;
    DEBUG.PR_DEBUG('CG', 'length of SECTOR string ' || L_LEN);
    L_SECTOR_CODE := SUBSTR(P_ROUTING_NO, L_START_POS, L_LEN);
    DEBUG.PR_DEBUG('CG', 'Sector code is ...' || L_SECTOR_CODE);
    P_BANK_CODE   := L_BANK_CODE;
    P_BRANCH_CODE := L_BRN_CODE;
    P_SECTOR_CODE := L_SECTOR_CODE;
  
  END PR_BREAK_ROUTING_NO;

  FUNCTION FN_MANDATORY_CHECK(P_ENTRY_REC IN CSTBS_CLEARING_MASTER%ROWTYPE,
                              P_ERR_CODE  OUT VARCHAR2) RETURN BOOLEAN IS
    L_PRODUCT_TYPE    CSTMS_PRODUCT.PRODUCT_TYPE%TYPE;
    L_COUNT           INTEGER;
    L_OUTSTANDING_AMT NUMBER(22, 3);
    PAY_BRANCH        STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_BRN_CD          STTMS_BRANCH.CLG_BRN_CODE%TYPE;
    L_SECTOR_CD       STTMS_BRANCH.SECTOR_CODE%TYPE;
    L_START_POS       INTEGER;
    L_LEN             INTEGER;
    L_BANK_CODE       STTMS_BANK.CLG_BANK_CD%TYPE;
    L_BRN_CODE        STTMS_BRANCH.CLG_BRN_CODE%TYPE;
    L_SECTOR_CODE     STTMS_BRANCH.SECTOR_CODE%TYPE;
    L_END_POS         INTEGER;
    L_ERR_PARAM       VARCHAR2(2000);
    L_ERR_CODE        ERTB_MSGS.ERR_CODE% TYPE;
  
    L_BRN_CD_ACC    STTMS_BRANCH.CLG_BRN_CODE%TYPE;
    L_SECTOR_CD_ACC STTMS_BRANCH.SECTOR_CODE%TYPE;
    L_CLEARING_THRU STTMS_BRANCH.BRANCH_CODE%TYPE;
  
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_CALL_FUNC_ID          NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside fn_mandatory_check');
    IF P_ENTRY_REC.PRODUCT_CODE IS NULL THEN
      DEBUG.PR_DEBUG('CG', 'Product Code is null ');
      P_ERR_CODE := 'CG-CL0002';
      OVPKS.PR_APPENDTBL('CG-CL0002', 'Exception in fn_save_entry');
    ELSE
      PR_GET_PROD(P_ENTRY_REC.PRODUCT_CODE);
      L_PRODUCT_TYPE := PKG_PROD_REC.PRODUCT_TYPE;
    END IF;
  
    IF P_ENTRY_REC.INSTRUMENT_AMT = 0 OR P_ENTRY_REC.INSTRUMENT_AMT IS NULL THEN
      DEBUG.PR_DEBUG('CG', 'Amount is null or Zero ');
      P_ERR_CODE := P_ERR_CODE || 'CG-CL0003';
      OVPKS.PR_APPENDTBL('CG-CL0003', 'Exception in fn_save_entry');
    END IF;
  
    IF P_ENTRY_REC.INSTRUMENT_NO_1 IS NULL THEN
      DEBUG.PR_DEBUG('CG', 'Instrument No. is null ');
      P_ERR_CODE := P_ERR_CODE || 'CG-CL0005';
    
      OVPKS.PR_APPENDTBL('CG-CL0005', 'Exception in fn_save_entry');
    
    END IF;
  
    DBG('p_entry_rec.txn_branch >>>' || P_ENTRY_REC.TXN_BRANCH);
    DBG('pkg_brn_rec.clg_brn_cd >>>' || PKG_BRN_REC.CLG_BRN_CD);
    DBG('pkg_brn_rec.sect_cd >>>' || PKG_BRN_REC.SECT_CD);
    DBG('g_routing_mask >>>>' || G_ROUTING_MASK);
    PR_GET_BRN_DET(P_ENTRY_REC.TXN_BRANCH);
    L_BRN_CD    := PKG_BRN_REC.CLG_BRN_CD;
    L_SECTOR_CD := PKG_BRN_REC.SECT_CD;
    L_START_POS := INSTR(G_ROUTING_MASK, 'B', 1);
    DEBUG.PR_DEBUG('CG', 'l_start_pos of BANK is  ' || L_START_POS);
    L_END_POS := 0;
    PR_END_POS(G_ROUTING_MASK, 'B', L_END_POS);
    L_LEN := L_END_POS - L_START_POS;
    DEBUG.PR_DEBUG('CG', 'length of BANK string ' || L_LEN);
    L_BANK_CODE := SUBSTR(P_ENTRY_REC.ROUTING_NO, L_START_POS, L_LEN);
    DEBUG.PR_DEBUG('CG', 'Bank Code is ...' || L_BANK_CODE);
    L_START_POS := INSTR(G_ROUTING_MASK, 'b', 1);
    DEBUG.PR_DEBUG('CG', 'l_start_pos of BANK is  ' || L_START_POS);
    L_END_POS := 0;
    PR_END_POS(G_ROUTING_MASK, 'b', L_END_POS);
    L_LEN := L_END_POS - L_START_POS;
    DEBUG.PR_DEBUG('CG', 'length of BRANCH string ' || L_LEN);
    L_BRN_CODE := SUBSTR(P_ENTRY_REC.ROUTING_NO, L_START_POS, L_LEN);
    DEBUG.PR_DEBUG('CG', 'Brn Code is...' || L_BRN_CODE);
    L_START_POS := INSTR(G_ROUTING_MASK, 'S', 1);
    DEBUG.PR_DEBUG('CG', 'l_start_pos of sector is  ' || L_START_POS);
    L_END_POS := 0;
    PR_END_POS(G_ROUTING_MASK, 'S', L_END_POS);
    L_LEN := L_END_POS - L_START_POS;
    DEBUG.PR_DEBUG('CG', 'length of SECTOR string ' || L_LEN);
    L_SECTOR_CODE := SUBSTR(P_ENTRY_REC.ROUTING_NO, L_START_POS, L_LEN);
    DEBUG.PR_DEBUG('CG', 'Sector code is ...' || L_SECTOR_CODE);
  
    IF L_PRODUCT_TYPE = 'IC' THEN
      IF P_ENTRY_REC.REM_ACCOUNT IS NULL OR P_ENTRY_REC.ACC_BRANCH IS NULL THEN
        DEBUG.PR_DEBUG('CG', 'Remitter A/c or A/c Branch is null ');
        P_ERR_CODE := P_ERR_CODE || 'CG-CL0006';
        OVPKS.PR_APPENDTBL('CG-CL0006', 'Exception in fn_save_entry');
      ELSE
        BEGIN
          SELECT 1
            INTO L_COUNT
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_AC_NO = P_ENTRY_REC.REM_ACCOUNT
             AND BRANCH_CODE = P_ENTRY_REC.ACC_BRANCH;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
          
            DBG('Calling Fn_Get_Gl_Master_Rec_Wrp for the account...' ||
                P_ENTRY_REC.REM_ACCOUNT);
            IF NOT
                CSPKSS_FUNCTION_CACHE.FN_GET_GL_MASTER_REC_WRP(P_ENTRY_REC.REM_ACCOUNT,
                                                               L_ERR_CODE,
                                                               L_ERR_PARAM) THEN
              IF L_ERR_CODE = 'CS-FRC-001' THEN
                DEBUG.PR_DEBUG('AC', 'No data found exception..');
                P_ERR_CODE  := P_ERR_CODE || 'CG-CL0007';
                L_ERR_CODE  := NULL;
                L_ERR_PARAM := NULL;
                OVPKS.PR_APPENDTBL('CG-CL0007',
                                   'Exception in fn_save_entry');
              ELSE
                DBG('WOT from FRC function..so raising exception..');
                P_ERR_CODE  := P_ERR_CODE || 'CG-CL0001';
                L_ERR_CODE  := NULL;
                L_ERR_PARAM := NULL;
                OVPKS.PR_APPENDTBL('CG-CL0001',
                                   'Exception in fn_save_entry');
              END IF;
            ELSE
              DEBUG.PR_DEBUG('AC', 'Record is available in FRC..');
              L_COUNT := 1;
            END IF;
            DEBUG.PR_DEBUG('AC', 'l_count is - ' || L_COUNT);
          
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CG',
                           'Exception while validating Account ' || SQLERRM);
            P_ERR_CODE := P_ERR_CODE || 'CG-CL0001';
            OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
        END;
      END IF;
    
      IF G_CLG_BANK_CD <> L_BANK_CODE OR L_BRN_CD <> L_BRN_CODE OR
         L_SECTOR_CD <> L_SECTOR_CODE THEN
      
        DEBUG.PR_DEBUG('CG',
                       'Routing Number is not Valid with respect to the transaction branch');
        DEBUG.PR_DEBUG('CG',
                       '*****Clearing Through Branch Validation Starts*****');
        DEBUG.PR_DEBUG('CG',
                       'The account branch is ' || P_ENTRY_REC.ACC_BRANCH);
        DEBUG.PR_DEBUG('CG',
                       'The transaction branch is ' ||
                       P_ENTRY_REC.TXN_BRANCH);
      
        SELECT G.CLG_BRN_CODE, G.SECTOR_CODE, G.CLEARING_BRN
          INTO L_BRN_CD_ACC, L_SECTOR_CD_ACC, L_CLEARING_THRU
          FROM STTM_BRANCH G
         WHERE BRANCH_CODE = P_ENTRY_REC.ACC_BRANCH;
        DEBUG.PR_DEBUG('CG',
                       'The Clearing through branch is ' || L_CLEARING_THRU);
      
        DEBUG.PR_DEBUG('CG', 'Clearing Through~Given Values');
        DEBUG.PR_DEBUG('CG',
                       'Branch Code comparison ...' || L_BRN_CD_ACC || '~' ||
                       L_BRN_CODE);
        DEBUG.PR_DEBUG('CG',
                       'Sector Code comparison ...' || L_SECTOR_CD_ACC || '~' ||
                       L_SECTOR_CODE);
        DEBUG.PR_DEBUG('CG',
                       'l_clearing_thru~txn_branch' || L_CLEARING_THRU || '~' ||
                       P_ENTRY_REC.TXN_BRANCH);
        DEBUG.PR_DEBUG('CG',
                       'g_clg_bank_cd~l_bank_code' || G_CLG_BANK_CD || '~' ||
                       L_BANK_CODE);
      
        IF (L_CLEARING_THRU <> P_ENTRY_REC.TXN_BRANCH) OR
           (G_CLG_BANK_CD <> L_BANK_CODE OR L_BRN_CODE <> L_BRN_CD_ACC OR
           L_SECTOR_CODE <> L_SECTOR_CD_ACC) THEN
        
          DEBUG.PR_DEBUG('CG', 'Routing Number is not Valid');
          P_ERR_CODE := 'CG-CL0009';
          OVPKS.PR_APPENDTBL('CG-CL0009', 'Exception in fn_save_entry');
        END IF;
      END IF;
      DEBUG.PR_DEBUG('CG',
                     '*****Clearing Through Branch Validation Ends*****');
    
      DEBUG.PR_DEBUG('CG', 'validating account wrt self and staff ');
      IF P_ENTRY_REC.BEN_ACCOUNT IS NOT NULL AND
         P_ENTRY_REC.ACC_BRANCH IS NOT NULL THEN
        IF NOT CSPKS_STAFF_RESTR.FN_CHECK_CUST(NULL,
                                               P_ENTRY_REC.BEN_ACCOUNT,
                                               P_ENTRY_REC.ACC_BRANCH,
                                               'N',
                                               L_ERR_PARAM,
                                               P_ERR_CODE) THEN
          DBG('FAILED IN fn_check_cust' || SQLERRM);
          OVPKS.PR_APPENDTBL(P_ERR_CODE, L_ERR_PARAM);
        END IF;
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_CALL_FUNC_ID    := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      
        DBG('Now calling CSPKS_CLG_SERV_CLUSTER.fn_mandatory_check ');
        IF NOT
            CSPKS_CLG_SERV_CLUSTER.FN_MANDATORY_CHECK(P_ENTRY_REC,
                                                      P_ERR_CODE,
                                                      L_CALL_FUNC_ID,
                                                      L_TB_CLUSTER_DATA) THEN
          DBG('Failed in cspks_clg_serv_cluster.fn_save_entry');
        END IF;
      
      END IF;
    
    ELSIF L_PRODUCT_TYPE = 'OC' THEN
      IF P_ENTRY_REC.BEN_ACCOUNT IS NULL OR P_ENTRY_REC.ACC_BRANCH IS NULL THEN
        DEBUG.PR_DEBUG('CG', 'Beneficiary A/c or A/c Branch is null ');
        P_ERR_CODE := P_ERR_CODE || 'CG-CL0010';
        OVPKS.PR_APPENDTBL('CG-CL0010', 'Exception in fn_save_entry');
      ELSE
        BEGIN
          SELECT 1
            INTO L_COUNT
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_AC_NO = P_ENTRY_REC.BEN_ACCOUNT
             AND BRANCH_CODE = P_ENTRY_REC.ACC_BRANCH;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
          
            DEBUG.PR_DEBUG('AC',
                           'Calling Fn_Get_Gl_Master_Rec_Wrp for the account...' ||
                           P_ENTRY_REC.BEN_ACCOUNT);
            IF NOT
                CSPKSS_FUNCTION_CACHE.FN_GET_GL_MASTER_REC_WRP(P_ENTRY_REC.BEN_ACCOUNT,
                                                               L_ERR_CODE,
                                                               L_ERR_PARAM) THEN
              IF L_ERR_CODE = 'CS-FRC-001' THEN
                DEBUG.PR_DEBUG('AC', 'No data found exception..');
                P_ERR_CODE  := P_ERR_CODE || 'CG-CL0017';
                L_ERR_CODE  := NULL;
                L_ERR_PARAM := NULL;
                OVPKS.PR_APPENDTBL('CG-CL0017',
                                   'Exception in fn_save_entry');
              ELSE
                DBG('WOT from FRC function..');
                P_ERR_CODE  := P_ERR_CODE || 'CG-CL0001';
                L_ERR_CODE  := NULL;
                L_ERR_PARAM := NULL;
                OVPKS.PR_APPENDTBL('CG-CL0001',
                                   'Exception in fn_save_entry');
              END IF;
            ELSE
              DEBUG.PR_DEBUG('AC', 'Record is available in FRC..');
              L_COUNT := 1;
            END IF;
            DEBUG.PR_DEBUG('AC', 'l_count is - ' || L_COUNT);
          
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CG',
                           'Exception while validating Account ' || SQLERRM);
            P_ERR_CODE := P_ERR_CODE || 'CG-CL0001';
            OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
        END;
      
        DEBUG.PR_DEBUG('CG', 'validating account wrt self and staff ');
        IF P_ENTRY_REC.BEN_ACCOUNT IS NOT NULL AND
           P_ENTRY_REC.ACC_BRANCH IS NOT NULL THEN
          IF NOT CSPKS_STAFF_RESTR.FN_CHECK_CUST(NULL,
                                                 P_ENTRY_REC.BEN_ACCOUNT,
                                                 P_ENTRY_REC.ACC_BRANCH,
                                                 'N',
                                                 L_ERR_PARAM,
                                                 P_ERR_CODE) THEN
            DBG('FAILED IN fn_check_cust' || SQLERRM);
          
            RETURN FALSE;
          END IF;
        END IF;
        IF P_ENTRY_REC.REM_ACCOUNT IS NOT NULL AND
           P_ENTRY_REC.ACC_BRANCH IS NOT NULL THEN
          IF NOT CSPKS_STAFF_RESTR.FN_CHECK_CUST(NULL,
                                                 P_ENTRY_REC.REM_ACCOUNT,
                                                 P_ENTRY_REC.ACC_BRANCH,
                                                 'N',
                                                 L_ERR_PARAM,
                                                 P_ERR_CODE) THEN
            DBG('FAILED IN fn_check_cust' || SQLERRM);
          
            RETURN FALSE;
          END IF;
        END IF;
      
      END IF;
    END IF;
  
    IF P_ERR_CODE IS NULL THEN
      DEBUG.PR_DEBUG('CG', 'Mandatory Check - Returning TRUE ');
      RETURN TRUE;
    ELSE
      DEBUG.PR_DEBUG('CG',
                     'Mandatory Check - Returning FALSE -> ' || P_ERR_CODE);
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'Exception while doing validations - ' || SQLERRM);
      DBG('Trace :::' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_MANDATORY_CHECK;

  FUNCTION FN_ACC_PROD_RESTRC(P_ENTRY_REC IN CSTBS_CLEARING_MASTER%ROWTYPE,
                              P_ERR_CODE  IN OUT VARCHAR2,
                              P_ERR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_ACCREC      STTBS_ACCOUNT%ROWTYPE;
    L_COUNT_PROD  NUMBER;
    L_COUNT_PROD1 NUMBER;
  BEGIN
    DEBUG.PR_DEBUG('CG', 'in fn_acc_prod_restrc');
    IF CVPKS_UTILS.GET_STTB_ACC(P_ENTRY_REC.TXN_BRANCH,
                                P_ENTRY_REC.REM_ACCOUNT,
                                L_ACCREC) THEN
      IF L_ACCREC.AC_OR_GL = 'A' THEN
        BEGIN
          DEBUG.PR_DEBUG('CG', 'Selecting from the product view');
          SELECT COUNT(*)
            INTO L_COUNT_PROD
            FROM CSVWS_ALLOWED_PRODUCTS
           WHERE CUSTAC = P_ENTRY_REC.REM_ACCOUNT
             AND BRANCH_CODE = P_ENTRY_REC.TXN_BRANCH
             AND PRODUCT_CODE = P_ENTRY_REC.PRODUCT_CODE
             AND DEBIT_TXN = 'Y';
          DEBUG.PR_DEBUG('CG',
                         'Count from the product view is ' || L_COUNT_PROD);
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CG',
                           'When others of select from the views' ||
                           SQLERRM);
        END;
        IF L_COUNT_PROD = 0 THEN
          DEBUG.PR_DEBUG('CG',
                         'The Debit transaction is not allowed for this customer and product');
          P_ERR_CODE  := 'AC-PROD2';
          P_ERR_PARAM := P_ENTRY_REC.PRODUCT_CODE || '~' ||
                         P_ENTRY_REC.REM_ACCOUNT || '~';
          IF P_ERR_CODE IS NOT NULL THEN
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;
        END IF;
      END IF;
    END IF;
    IF CVPKS_UTILS.GET_STTB_ACC(P_ENTRY_REC.TXN_BRANCH,
                                P_ENTRY_REC.BEN_ACCOUNT,
                                L_ACCREC) THEN
      IF L_ACCREC.AC_OR_GL = 'A' THEN
        BEGIN
          DEBUG.PR_DEBUG('CG', 'Selecting from the product view');
          SELECT COUNT(*)
            INTO L_COUNT_PROD1
            FROM CSVWS_ALLOWED_PRODUCTS
           WHERE CUSTAC = P_ENTRY_REC.BEN_ACCOUNT
             AND BRANCH_CODE = P_ENTRY_REC.TXN_BRANCH
             AND PRODUCT_CODE = P_ENTRY_REC.PRODUCT_CODE
             AND CREDIT_TXN = 'Y';
          DEBUG.PR_DEBUG('CG',
                         'Count from the product view is ' || L_COUNT_PROD1);
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CG',
                           'When others of select from the views' ||
                           SQLERRM);
        END;
        IF L_COUNT_PROD1 = 0 THEN
          DEBUG.PR_DEBUG('CG',
                         'The Credit transaction is not allowed for this customer and product');
          P_ERR_CODE  := 'AC-PROD2';
          P_ERR_PARAM := P_ENTRY_REC.PRODUCT_CODE || '~' ||
                         P_ENTRY_REC.BEN_ACCOUNT || '~';
          IF P_ERR_CODE IS NOT NULL THEN
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;
        END IF;
      END IF;
    END IF;
    DEBUG.PR_DEBUG('CG', 'before returning true from fn_acc_prod_restrc');
    RETURN TRUE;
  END FN_ACC_PROD_RESTRC;

  FUNCTION FN_GENERATE_REF_NO(PBRANCH     IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                              P_ENTRY_REC IN OUT CSTBS_CLEARING_MASTER%ROWTYPE,
                              P_ERR_CODE  OUT VARCHAR2) RETURN BOOLEAN IS
    L_SERIAL VARCHAR2(50);
    L_REF_NO CSTB_CONTRACT.CONTRACT_REF_NO%TYPE;
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside fn_generate_ref_no');
    IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(PBRANCH,
                                       P_ENTRY_REC.PRODUCT_CODE,
                                       GLOBAL.APPLICATION_DATE,
                                       L_SERIAL,
                                       L_REF_NO,
                                       P_ERR_CODE) THEN
      DEBUG.PR_DEBUG('CG', 'Falied in Generating Ref No - ' || P_ERR_CODE);
      RETURN FALSE;
    END IF;
    P_ENTRY_REC.REFERENCE_NO := L_REF_NO;
    DEBUG.PR_DEBUG('CG', 'Reference No is ...' || L_REF_NO);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'Exception in fn_generate_ref_no -  ' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_GENERATE_REF_NO;

  FUNCTION FN_PROCESS_RBRETN(P_BRANCH   IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                             P_REF_NO   IN CSTBS_CLEARING_MASTER.MODULE_REFERENCE_NO%TYPE,
                             P_ERR_CODE IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                             P_ERRPARAM IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  
    L_TY_TB_RB   RBPKSS_DML.TY_TB_RB;
    L_CSTBREC    CSTBS_CONTRACT%ROWTYPE;
    L_CSRECFOUND BOOLEAN;
    L_SOURCE     VARCHAR2(15) := 'FLEXCUBE';
    L_FUNCID     VARCHAR2(15) := 'RBDOCCNL';
    L_REF        CSTBS_CLEARING_MASTER.MODULE_REFERENCE_NO%TYPE := P_REF_NO;
  
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside fn_process_rbretn');
  
    BEGIN
      SELECT *
        INTO L_CSTBREC
        FROM CSTBS_CONTRACT
       WHERE EXISTS (SELECT 1
                FROM RBTB_CONTRACT_MASTER
               WHERE CONTRACT_REF_NO = P_REF_NO)
         AND CONTRACT_REF_NO = P_REF_NO
         AND AUTH_STATUS = 'A'
         AND CONTRACT_STATUS = 'A';
    
      L_CSRECFOUND := TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        L_CSRECFOUND := FALSE;
    END;
  
    IF L_CSRECFOUND THEN
      IF NOT RBPKSS_COPY.FN_RBCOPY_ACONTRACT(P_REF_NO,
                                             L_REF,
                                             'E',
                                             P_ERR_CODE,
                                             P_ERRPARAM) THEN
        DBG('Failed here');
      END IF;
    
      IF NOT RBPKS_DML.FN_GET_OBJECT_REC(P_REF_NO,
                                         NULL,
                                         L_TY_TB_RB,
                                         NULL,
                                         P_ERR_CODE,
                                         P_ERRPARAM) THEN
        DBG('Failed in getting mater record');
      END IF;
    
      L_TY_TB_RB(1).G_CONT_MASTER.EVENT_CODE := 'RETN';
    
      IF NOT RBPKSS_DML.FN_STORE_OBJECT(L_TY_TB_RB, P_ERR_CODE, P_ERRPARAM) THEN
        DBG('Failed in Insert into RBTBS_CONTRACT_PAAARTIES..');
        RETURN FALSE;
      END IF;
    
      IF NOT
          RBPKSS_SAVE.FN_SAVE_CONTRACT(L_SOURCE,
                                       L_FUNCID,
                                       L_TY_TB_RB,
                                       L_TY_TB_RB(1).G_CONT_MASTER.EVENT_CODE,
                                       '',
                                       'N',
                                       'N',
                                       P_ERR_CODE,
                                       P_ERRPARAM) THEN
        DBG('Failed here' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN FALSE;
      END IF;
    
      IF NOT RBPKS_AUTH.FN_AUTHORIZECONTRACT(GLOBAL.USER_ID,
                                             P_REF_NO,
                                             L_TY_TB_RB    (1)
                                             .G_CONTRACT.LATEST_VERSION_NO,
                                             L_TY_TB_RB    (1)
                                             .G_CONTRACT.LATEST_EVENT_SEQ_NO,
                                             L_TY_TB_RB    (1)
                                             .G_CONT_MASTER.EVENT_CODE,
                                             FN_MNTSTAMP,
                                             FN_MNTSTAMP,
                                             'Y',
                                             P_ERR_CODE,
                                             P_ERRPARAM) THEN
        DBG('Failed In rbpks_auth.Fn_Authorizecontract..');
        RETURN FALSE;
      END IF;
    END IF;
    DEBUG.PR_DEBUG('CG', 'Returning from fn_process_rbretn');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_process_rbretn -  ' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_process_rbretn');
      RETURN FALSE;
  END FN_PROCESS_RBRETN;

  FUNCTION FN_AUTH_TXN(P_BRANCH   IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                       P_REF_NO   IN CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE,
                       P_ERR_CODE OUT ERTBS_MSGS.ERR_CODE%TYPE,
                       P_ERRPARAM OUT ERTBS_MSGS.MESSAGE%TYPE) RETURN BOOLEAN IS
    L_APPL_DATE     DATE;
    L_LCY           CYTMS_CCY_DEFN.CCY_CODE%TYPE;
    L_USER          ACTBS_DAILY_LOG.AUTH_ID%TYPE;
    L_AUTH_DT_STAMP DATE;
    L_EVENT_SR_NO   ACTBS_DAILY_LOG.EVENT_SR_NO%TYPE;
  BEGIN
    L_APPL_DATE := GLOBAL.APPLICATION_DATE;
    L_LCY       := GLOBAL.LCY;
  
    L_USER          := NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID);
    L_AUTH_DT_STAMP := CEPKSS_DATE.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE);
  
    BEGIN
      SELECT DISTINCT EVENT_SR_NO
        INTO L_EVENT_SR_NO
        FROM ACVWS_ALL_ENTRIES_SEL A
       WHERE A.TRN_REF_NO = P_REF_NO
         AND AUTH_STAT = 'U'
         AND NVL(A.DELETE_STAT, '*') <> 'D';
      DEBUG.PR_DEBUG('CG',
                     'cspks_clg_serv.fn_auth_txn=> l_event_sr_no - ' ||
                     L_EVENT_SR_NO);
    EXCEPTION
    
      WHEN NO_DATA_FOUND THEN
        BEGIN
          SELECT DISTINCT EVENT_SR_NO
            INTO L_EVENT_SR_NO
            FROM ACTB_ENTRIES_HANDOFF A
           WHERE A.TRN_REF_NO = P_REF_NO
             AND A.AUTH_STAT = 'U'
             AND NOT EXISTS (
                  
                  SELECT 1
                  
                    FROM ACTB_ACSERVICE_HANDOFF B
                   WHERE B.GRP_REF_NO = A.GRP_REF_NO
                     AND B.TRN_REF_NO = A.TRN_REF_NO
                     AND B.EVENT_SR_NO = A.EVENT_SR_NO
                     AND B.ACTION_CODE IN ('D'));
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CG',
                           'not event found in entries handoff cspks_clg_serv.fn_auth_txn=> SQLERRM ' ||
                           SQLERRM);
            L_EVENT_SR_NO := 1;
        END;
      
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('CG',
                       'cspks_clg_serv.fn_auth_txn=> SQLERRM ' || SQLERRM);
        L_EVENT_SR_NO := 1;
    END;
    DEBUG.PR_DEBUG('CG',
                   'cspks_clg_serv.fn_auth_txn=> l_event_sr_no - ' ||
                   L_EVENT_SR_NO);
  
    IF NOT ACPKSS.FN_ACSERVICE(P_BRANCH,
                               L_APPL_DATE,
                               L_LCY,
                               P_REF_NO,
                               L_EVENT_SR_NO,
                               'A',
                               L_USER,
                               P_ERR_CODE,
                               P_ERRPARAM)
    
     THEN
      DEBUG.PR_DEBUG('CG', 'Fn_acservice returned FALSE - ' || P_ERR_CODE);
      RETURN FALSE;
    END IF;
    BEGIN
      UPDATE CSTBS_CLEARING_MASTER
         SET AUTH_STAT        = 'A',
             CHECKER_ID       = L_USER,
             CHECKER_DT_STAMP = L_AUTH_DT_STAMP
       WHERE REFERENCE_NO = P_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('CG', 'This transaction does not exist');
        P_ERR_CODE := 'CG-CL0014';
        RETURN FALSE;
    END;
    BEGIN
      UPDATE CGTBS_TRANSACTION_MASTER
         SET AUTH_STAT        = 'A',
             CHECKER_ID       = L_USER,
             CHECKER_DT_STAMP = L_AUTH_DT_STAMP
       WHERE TRANSACTION_REF_NO = P_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('CG', 'This transaction does not exist');
        P_ERR_CODE := 'CG-CL0014';
        RETURN FALSE;
    END;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_auth_txn - ' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_AUTH_TXN;

  FUNCTION FN_AUTH_REJECT_TXN(P_BRANCH   IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                              P_REF_NO   IN CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE,
                              P_ERR_CODE OUT ERTBS_MSGS.ERR_CODE%TYPE,
                              P_ERRPARAM OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
    L_APPL_DATE     DATE;
    L_LCY           CYTMS_CCY_DEFN.CCY_CODE%TYPE;
    L_USER          ACTBS_DAILY_LOG.AUTH_ID%TYPE;
    L_AUTH_DT_STAMP DATE;
  
    L_EVENT_SEQ  NUMBER := 2;
    L_MASTER_REC CSTB_CLEARING_MASTER%ROWTYPE;
  
    L_DEFER_LIQUIDATION VARCHAR2(1);
  BEGIN
    L_APPL_DATE := GLOBAL.APPLICATION_DATE;
    L_LCY       := GLOBAL.LCY;
  
    L_USER          := NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID);
    L_AUTH_DT_STAMP := CEPKSS_DATE.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE);
  
    DBG('Inside Fn_Auth_Reject_Txn');
  
    BEGIN
      SELECT *
        INTO L_MASTER_REC
        FROM CSTB_CLEARING_MASTER
       WHERE REFERENCE_NO = P_REF_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;
  
    BEGIN
      SELECT NVL(DEFER_LIQUIDATION, 'N')
        INTO L_DEFER_LIQUIDATION
        FROM CGTMS_PRODUCT_REFERRAL
       WHERE PRODUCT_CODE = L_MASTER_REC.PRODUCT_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_CODE := 'CG-PROD-001';
        P_ERRPARAM := L_MASTER_REC.PRODUCT_CODE;
    END;
  
    IF L_DEFER_LIQUIDATION = 'Y' THEN
    
      IF NVL(L_MASTER_REC.DISPATCH_STATUS, 'N') = 'L' THEN
        L_EVENT_SEQ := 4;
      ELSIF NVL(L_MASTER_REC.DISPATCH_STATUS, 'N') = 'D' THEN
        L_EVENT_SEQ := 3;
      ELSIF NVL(L_MASTER_REC.DISPATCH_STATUS, 'N') = 'B' THEN
        L_EVENT_SEQ := 2;
      END IF;
    END IF;
  
    IF NOT ACPKSS.FN_ACSERVICE(P_BRANCH,
                               L_APPL_DATE,
                               L_LCY,
                               P_REF_NO,
                               L_EVENT_SEQ,
                               'A',
                               L_USER,
                               P_ERR_CODE,
                               P_ERRPARAM) THEN
      DEBUG.PR_DEBUG('CG',
                     'cspks_clg_serv ==> ' ||
                     'Fn_acservice returned FALSE - ' || P_ERR_CODE);
      RETURN FALSE;
    END IF;
  
    BEGIN
      UPDATE CSTBS_CLEARING_MASTER
         SET AUTH_STAT        = 'A',
             CHECKER_ID       = L_USER,
             CHECKER_DT_STAMP = L_AUTH_DT_STAMP
       WHERE REFERENCE_NO = P_REF_NO;
    
      UPDATE IFTBS_CLEARING_UPLOAD
         SET AUTH_STAT = 'A'
             
            ,
             CHECKER_ID       = GLOBAL.USER_ID,
             CHECKER_DT_STAMP = CEPKSS_DATE.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE)
       WHERE FCCREF = P_REF_NO;
      DBG('Updated iftb_clearing_upload');
    
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('CG',
                       'cspks_clg_serv ==> ' ||
                       'This transaction does not exist');
        P_ERR_CODE := 'CG-CL0014';
        RETURN FALSE;
    END;
    BEGIN
      UPDATE CGTBS_TRANSACTION_MASTER
         SET AUTH_STAT        = 'A',
             CHECKER_ID       = L_USER,
             CHECKER_DT_STAMP = L_AUTH_DT_STAMP
       WHERE TRANSACTION_REF_NO = P_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('CG',
                       'cspks_clg_serv ==> ' ||
                       'This transaction does not exist');
        P_ERR_CODE := 'CG-CL0014';
        RETURN FALSE;
    END;
  
    IF L_MASTER_REC.DIRECTION = 'O' THEN
      DEBUG.PR_DEBUG('CG', 'Calling fn_process_rbretn');
      IF NOT FN_PROCESS_RBRETN(P_BRANCH,
                               L_MASTER_REC.MODULE_REFERENCE_NO,
                               P_ERR_CODE,
                               P_ERRPARAM) THEN
        DEBUG.PR_DEBUG('CG', 'failed in fn_process_rbretn');
      END IF;
    END IF;
  
    IF L_MASTER_REC.NOTIFY_RETN_TO_MODULE = 'Y'
    
     THEN
      BEGIN
        UPDATE CGTB_MODULE_CHQ_STATUS
           SET STATUS = 'R'
         WHERE REFERENCE_NO = P_REF_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('cspks_clg_serv ==> ' || 'This transaction does not exist');
          P_ERR_CODE := 'CG-CL0014';
          RETURN FALSE;
      END;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'cspks_clg_serv ==> ' || 'Exception in fn_auth_txn - ' ||
                     SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_AUTH_REJECT_TXN;

  PROCEDURE PR_PROCESS_RETN_ENTRIES(PBRANCH          IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                                    P_XREF           IN CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE,
                                    P_ENTRY_REC      IN CSTBS_CLEARING_MASTER%ROWTYPE,
                                    P_CHG_ROW        IN IFTMS_ARC_MAINT%ROWTYPE,
                                    P_CHQ_RETURN_AMT IN CSTBS_CLEARING_MASTER.INSTRUMENT_AMT%TYPE,
                                    P_REJECT_CODE    IN VARCHAR2,
                                    P_ERR_CODE       IN OUT VARCHAR2,
                                    P_RET            IN OUT NUMBER)
  
   IS
    L_ACC_HAND         ACPKSS.TBL_ACHOFF;
    L_ACTION           CHAR(1);
    L_ERRCODE          VARCHAR2(1000);
    L_ERRORPARAM       VARCHAR2(10000);
    L_USER_ID          ACTBS_DAILY_LOG.USER_ID%TYPE;
    L_OFF_TRN_CODE     STTM_END_POINT.OFFSET_TXN_CODE%TYPE;
    L_MAIN_TRN_CODE    STTM_END_POINT.MAIN_TXN_CODE%TYPE;
    L_INWARD_GL        STTM_END_POINT.IW_RETURN_SUSPENSE_GL%TYPE;
    L_TOTAL_CHG_AMT    IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_TOTAL_CHG_AMT_1  NUMBER(22, 3);
    L_TOTAL_CHEQUE_AMT NUMBER(22, 3);
    L_REF_NO           VARCHAR2(16);
    L_RATE             CYTMS_RATES.MID_RATE%TYPE;
  BEGIN
    DBG('Inside procedure pr_process_retn_entries');
    DBG('instrument_ccy -->' || P_ENTRY_REC.INSTRUMENT_CCY);
    DBG('p_chg_row.cod_prod_acc_cls-->' || P_CHG_ROW.COD_PROD_ACC_CLS);
    IF P_CHG_ROW.COD_PROD_ACC_CLS IS NOT NULL THEN
      L_TOTAL_CHG_AMT := NVL(P_CHG_ROW.COD_CHG_AMT, 0) +
                         NVL(P_CHG_ROW.COD_CHG_AMT1, 0) +
                         NVL(P_CHG_ROW.COD_CHG_AMT2, 0) +
                         NVL(P_CHG_ROW.COD_CHG_AMT3, 0) +
                         NVL(P_CHG_ROW.COD_CHG_AMT4, 0);
      DBG('l_total_chg_amt-->' || L_TOTAL_CHG_AMT);
      DBG('cod_chg_ccy    -->' || P_CHG_ROW.COD_CHG_CCY);
      IF L_TOTAL_CHG_AMT > 0 THEN
        IF P_ENTRY_REC.INSTRUMENT_CCY = P_CHG_ROW.COD_CHG_CCY THEN
          L_TOTAL_CHG_AMT_1 := L_TOTAL_CHG_AMT;
        ELSE
          DBG('calling cypkss.fn_amt1_to_amt2');
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(PBRANCH,
                                        P_CHG_ROW.COD_CHG_CCY,
                                        P_ENTRY_REC.INSTRUMENT_CCY,
                                        'STANDARD',
                                        'M',
                                        L_TOTAL_CHG_AMT,
                                        'Y',
                                        L_TOTAL_CHG_AMT_1,
                                        L_RATE,
                                        L_ERRCODE) THEN
            DBG('Error while computing LCY');
            P_ERR_CODE := L_ERRCODE;
            P_RET      := -1;
          END IF;
        END IF;
      END IF;
      DBG('l_total_chg_amt_1    -->' || L_TOTAL_CHG_AMT_1);
      L_TOTAL_CHEQUE_AMT := NVL(P_CHQ_RETURN_AMT, 0) + L_TOTAL_CHG_AMT_1;
    ELSE
      L_TOTAL_CHEQUE_AMT := NVL(P_CHQ_RETURN_AMT, 0);
    END IF;
    DBG('l_total_cheque_amt-->' || L_TOTAL_CHEQUE_AMT);
    DBG('END POINT-->' || P_ENTRY_REC.END_POINT);
    BEGIN
      SELECT OFFSET_TXN_CODE, MAIN_TXN_CODE, IW_RETURN_SUSPENSE_GL
        INTO L_OFF_TRN_CODE, L_MAIN_TRN_CODE, L_INWARD_GL
        FROM STTM_END_POINT
       WHERE END_POINT = P_ENTRY_REC.END_POINT;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('END POINT NOT MAINATINED');
    END;
    DBG('l_off_trn_code -->' || L_OFF_TRN_CODE);
    DBG('l_main_trn_code-->' || L_MAIN_TRN_CODE);
    DBG('l_inward_gl    -->' || L_INWARD_GL);
  
    L_REF_NO := P_ENTRY_REC.REFERENCE_NO;
    DBG('l_ref_no    -->' || L_REF_NO);
  
    L_USER_ID := GLOBAL.USER_ID;
  
    L_ACC_HAND := ACPKS.EMPTY_HOFF;
    DBG('BUILDING DEBIT ENTRIES FOR TOTAL CHEQUE AMOUNT -->' ||
        L_TOTAL_CHEQUE_AMT);
    L_ACC_HAND(1).MODULE := 'CG';
    L_ACC_HAND(1).TRN_REF_NO := L_REF_NO;
    L_ACC_HAND(1).EVENT_SR_NO := 1;
    L_ACC_HAND(1).EVENT := 'RETN';
    L_ACC_HAND(1).TRN_DT := GLOBAL.APPLICATION_DATE;
    L_ACC_HAND(1).VALUE_DT := GLOBAL.APPLICATION_DATE;
    L_ACC_HAND(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
    L_ACC_HAND(1).INSTRUMENT_CODE := P_ENTRY_REC.INSTRUMENT_NO_1;
    L_ACC_HAND(1).RELATED_CUSTOMER := P_ENTRY_REC.BEN_CUST;
    L_ACC_HAND(1).RELATED_ACCOUNT := P_ENTRY_REC.BEN_ACCOUNT;
    L_ACC_HAND(1).BATCH_NO := P_ENTRY_REC.BATCH_NO;
    L_ACC_HAND(1).CURR_NO := NULL;
    L_ACC_HAND(1).USER_ID := L_USER_ID;
    L_ACC_HAND(1).BANK_CODE := P_ENTRY_REC.BANK_CODE;
    L_ACC_HAND(1).DRCR_IND := 'D';
  
    L_ACC_HAND(1).TRN_CODE := L_OFF_TRN_CODE;
    L_ACC_HAND(1).AMOUNT_TAG := 'CHEQUE_AMOUNT';
    L_ACC_HAND(1).NETTING_IND := 'N';
    L_ACC_HAND(1).EXTERNAL_REF_NO := P_XREF;
  
    L_ACC_HAND(1).AC_NO := P_ENTRY_REC.BEN_ACCOUNT;
    L_ACC_HAND(1).AC_CCY := P_ENTRY_REC.ACC_CCY;
    L_ACC_HAND(1).AC_BRANCH := P_ENTRY_REC.ACC_BRANCH;
    DBG('ac_ccy' || L_ACC_HAND(1).AC_CCY);
    IF (P_ENTRY_REC.INSTRUMENT_CCY = GLOBAL.LCY) THEN
      DBG('INSTRUMENT CCY = GLOBAL.LCY');
      L_ACC_HAND(1).LCY_AMOUNT := L_TOTAL_CHEQUE_AMT;
      L_ACC_HAND(1).FCY_AMOUNT := NULL;
      L_ACC_HAND(1).EXCH_RATE := NULL;
    ELSE
      L_ACC_HAND(1).FCY_AMOUNT := L_TOTAL_CHEQUE_AMT;
      DBG('INSTRUMENT CCY <> GLOBAL LCY.HENCE CCY CONVERSION CALLED');
      IF NOT CYPKSS.FN_AMT1_TO_AMT2(PBRANCH,
                                    P_ENTRY_REC.INSTRUMENT_CCY,
                                    GLOBAL.LCY,
                                    'STANDARD',
                                    'M',
                                    L_TOTAL_CHEQUE_AMT,
                                    'Y',
                                    L_ACC_HAND                (1).LCY_AMOUNT,
                                    L_ACC_HAND                (1).EXCH_RATE,
                                    L_ERRCODE) THEN
        DBG('Error while computing LCY');
        P_ERR_CODE := L_ERRCODE;
        P_RET      := -1;
      
      END IF;
    END IF;
    DBG('LCY AMOUNT1    -->' || L_ACC_HAND(1).LCY_AMOUNT);
  
    DBG('FCY AMOUNT1    -->' || L_ACC_HAND(1).FCY_AMOUNT);
    DBG('EXCHANGE RATE1 -->' || L_ACC_HAND(1).EXCH_RATE);
  
    DBG('BUILDING CREDIT ENTRIES FOR RETURN CHEQUE AMOUNT -->' ||
        P_CHQ_RETURN_AMT);
    L_ACC_HAND(2) := L_ACC_HAND(1);
    L_ACC_HAND(2).RELATED_CUSTOMER := P_CHG_ROW.END_POINT;
    L_ACC_HAND(2).DRCR_IND := 'C';
    L_ACC_HAND(2).TRN_CODE := L_OFF_TRN_CODE;
    L_ACC_HAND(2).AMOUNT_TAG := 'CHK_RETN_AMT';
    L_ACC_HAND(2).NETTING_IND := 'N';
    L_ACC_HAND(2).EXTERNAL_REF_NO := P_XREF;
  
    L_ACC_HAND(2).AC_NO := L_INWARD_GL;
    L_ACC_HAND(2).AC_BRANCH := PBRANCH;
    L_ACC_HAND(2).AC_CCY := P_ENTRY_REC.INSTRUMENT_CCY;
  
    IF (P_ENTRY_REC.INSTRUMENT_CCY = GLOBAL.LCY) THEN
      DBG('INSTRUMENT CCY = GLOBAL LCY');
      L_ACC_HAND(2).LCY_AMOUNT := P_CHQ_RETURN_AMT;
      L_ACC_HAND(2).FCY_AMOUNT := NULL;
      L_ACC_HAND(2).EXCH_RATE := NULL;
    ELSE
      DBG('INSTRUMENT CCY <> GLOBAL LCY');
      L_ACC_HAND(2).FCY_AMOUNT := P_CHQ_RETURN_AMT;
      IF NOT CYPKSS.FN_AMT1_TO_AMT2(PBRANCH,
                                    P_ENTRY_REC.INSTRUMENT_CCY,
                                    GLOBAL.LCY,
                                    'STANDARD',
                                    'M',
                                    P_CHQ_RETURN_AMT,
                                    'Y',
                                    L_ACC_HAND                (2).LCY_AMOUNT,
                                    L_ACC_HAND                (2).EXCH_RATE,
                                    L_ERRCODE) THEN
        DBG('Error while computing LCY');
        P_ERR_CODE := L_ERRCODE;
        P_RET      := -1;
      
      END IF;
    END IF;
  
    DBG('LCY AMOUNT2    -->' || L_ACC_HAND(2).LCY_AMOUNT);
    DBG('FCY AMOUNT2    -->' || L_ACC_HAND(2).FCY_AMOUNT);
    DBG('EXCHANGE RATE2 -->' || L_ACC_HAND(2).EXCH_RATE);
  
    IF P_CHG_ROW.COD_PROD_ACC_CLS IS NOT NULL THEN
      DBG('BUILDING CREDIT ENTRIES FOR CHARGE AMOUNT -->' ||
          L_TOTAL_CHG_AMT_1);
      L_ACC_HAND(3) := L_ACC_HAND(1);
      L_ACC_HAND(3).RELATED_CUSTOMER := P_CHG_ROW.END_POINT;
      L_ACC_HAND(3).DRCR_IND := 'C';
      L_ACC_HAND(3).TRN_CODE := P_CHG_ROW.COD_CHG_TXN_CODE;
      L_ACC_HAND(3).AMOUNT_TAG := 'OUR_CHARGE';
      L_ACC_HAND(3).NETTING_IND := 'N';
      L_ACC_HAND(3).EXTERNAL_REF_NO := P_XREF;
    
      L_ACC_HAND(3).AC_NO := P_CHG_ROW.COD_CHG_GL;
      L_ACC_HAND(3).AC_BRANCH := PBRANCH;
      L_ACC_HAND(3).AC_CCY := P_ENTRY_REC.INSTRUMENT_CCY;
    
      IF (P_ENTRY_REC.INSTRUMENT_CCY = GLOBAL.LCY) THEN
        DBG('INSTRUMENT CCY = GLOBAL LCY');
        L_ACC_HAND(3).LCY_AMOUNT := L_TOTAL_CHG_AMT_1;
        L_ACC_HAND(3).FCY_AMOUNT := NULL;
        L_ACC_HAND(3).EXCH_RATE := NULL;
      ELSE
        DBG('INSTRUMENT CCY <> GLOBAL LCY');
        L_ACC_HAND(3).FCY_AMOUNT := L_TOTAL_CHG_AMT_1;
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(PBRANCH,
                                      P_ENTRY_REC.INSTRUMENT_CCY,
                                      GLOBAL.LCY,
                                      'STANDARD',
                                      'M',
                                      L_TOTAL_CHG_AMT_1,
                                      'Y',
                                      L_ACC_HAND                (3).LCY_AMOUNT,
                                      L_ACC_HAND                (3).EXCH_RATE,
                                      L_ERRCODE) THEN
          DBG('Error while computing LCY');
          P_ERR_CODE := L_ERRCODE;
          P_RET      := -1;
        
        END IF;
      END IF;
      DBG('LCY AMOUNT3    -->' || L_ACC_HAND(3).LCY_AMOUNT);
      DBG('FCY AMOUNT3    -->' || L_ACC_HAND(3).FCY_AMOUNT);
      DBG('EXCHANGE RATE3 -->' || L_ACC_HAND(3).EXCH_RATE);
    END IF;
    IF GLOBAL.BRANCH_STATUS = 'N' THEN
      L_ACTION := 'U';
    ELSE
      L_ACTION := 'B';
    END IF;
  
    IF CVPKS_UPLOAD_CG_REJECT.G_UPLOAD = TRUE OR
       GWPKS_UTIL.G_FROM_BEAN = TRUE THEN
      DBG('Picking Records from File...');
      L_ACTION := 'B';
    END IF;
  
    DBG('l_acc_hand COUNT' || L_ACC_HAND.COUNT);
    IF L_ACC_HAND.COUNT > 0 THEN
      DBG('CALLING acpkss_handoff.fn_handoff');
    
      IF NOT ACPKSS.FN_ACHANDOFF(L_REF_NO,
                                 1,
                                 GLOBAL.APPLICATION_DATE,
                                 L_ACC_HAND,
                                 L_ACTION,
                                 'N',
                                 'Y',
                                 L_USER_ID,
                                 L_ERRCODE,
                                 L_ERRORPARAM) THEN
        DBG('Failed While calling acpkss_handoff.fn_handoff' || SQLERRM);
        P_ERR_CODE := L_ERRCODE;
        P_RET      := -1;
      ELSE
        DBG('Accounting  Successful');
      END IF;
      L_ACC_HAND.DELETE;
    END IF;
  
    P_RET := 0;
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception in pr_process_retn_entries..' || SQLERRM);
      P_RET := -1;
      RAISE;
  END PR_PROCESS_RETN_ENTRIES;
  FUNCTION FN_INWARD_RETURN_ENT(P_CLG_REC        IN CSTBS_CLEARING_MASTER%ROWTYPE,
                                P_XREF           IN CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE,
                                PBRANCH          IN VARCHAR2,
                                P_CHQ_RETURN_AMT IN CSTBS_CLEARING_MASTER.INSTRUMENT_AMT%TYPE,
                                P_REJECT_CODE    IN VARCHAR2,
                                P_TOT_CHG_AMT    OUT NUMBER,
                                P_ERR_CODE       OUT VARCHAR2,
                                P_ERR_PARAM      OUT VARCHAR2,
                                P_ONLINE_AUTH    IN CHAR) RETURN BOOLEAN
  
   IS
    L_CHG_ROW           IFTMS_ARC_MAINT%ROWTYPE;
    L_TOTAL_CHG_AMT     IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_CHARGE_APPLICABLE CSTBS_CLG_REJ_REASON.CHARGE%TYPE;
    L_CHARGE_PROD       CSTBS_CLG_REJ_REASON.CHARGE_PROD_IW%TYPE;
    L_RET               INTEGER;
    L_CHQ_RETURN_AMOUNT CSTB_CLEARING_MASTER.CHEQUE_RETN_AMT%TYPE;
  BEGIN
    DBG('Inside function fn_inward_return_ent' || PBRANCH);
    DBG('instrument_ccy  -->' || P_CLG_REC.INSTRUMENT_CCY);
  
    BEGIN
      SELECT CHARGE, CHARGE_PROD_IW
        INTO L_CHARGE_APPLICABLE, L_CHARGE_PROD
        FROM CSTBS_CLG_REJ_REASON
       WHERE REASON_CODE = P_REJECT_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN CHARGE DETAILS' || SQLERRM);
    END;
    DBG('l_charge_applicable-->' || L_CHARGE_APPLICABLE);
    DBG('l_charge_prod-->' || L_CHARGE_PROD);
  
    IF NVL(L_CHARGE_APPLICABLE, 'N') = 'Y' THEN
      DBG('CALLING cspkss_arc.pr_get_arc_row-->');
      CSPKSS_ARC.PR_GET_ARC_ROW(PBRANCH,
                                L_CHARGE_PROD,
                                'P',
                                '*.*',
                                P_CLG_REC.INSTRUMENT_CCY,
                                'N',
                                L_CHG_ROW,
                                P_ERR_CODE,
                                P_ERR_PARAM,
                                NULL,
                                NULL);
    
      L_TOTAL_CHG_AMT := NVL(L_CHG_ROW.COD_CHG_AMT, 0) +
                         NVL(L_CHG_ROW.COD_CHG_AMT1, 0) +
                         NVL(L_CHG_ROW.COD_CHG_AMT2, 0) +
                         NVL(L_CHG_ROW.COD_CHG_AMT3, 0) +
                         NVL(L_CHG_ROW.COD_CHG_AMT4, 0);
    
    END IF;
  
    DBG('l_total_chg_amt  -->' || L_TOTAL_CHG_AMT);
    DBG('p_chq_return_amt -->' || P_CHQ_RETURN_AMT);
    DBG('instrument_amt   -->' || P_CLG_REC.INSTRUMENT_AMT);
  
    IF NOT CVPKS_UPLOAD_CG_REJECT.G_UPLOAD AND
       NVL(CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID'), '$$$') IN
       ('CGDCLGDT', 'IFDCLGDT', '6560') AND
       CVPKS_UPLOAD_CG_REJECT.G_PARENT_FOUND AND
       NVL(L_CHARGE_APPLICABLE, 'N') = 'Y' AND
       (NVL(P_CHQ_RETURN_AMT, 0) + NVL(L_TOTAL_CHG_AMT, 0) !=
       NVL(P_CLG_REC.INSTRUMENT_AMT, 0)) THEN
      DBG('Function ID  ->' || CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID'));
      L_CHQ_RETURN_AMOUNT := NVL(P_CLG_REC.INSTRUMENT_AMT, 0) -
                             NVL(L_TOTAL_CHG_AMT, 0);
    ELSE
      L_CHQ_RETURN_AMOUNT := NVL(P_CLG_REC.INSTRUMENT_AMT, 0);
    END IF;
    DBG('l_chq_return_amount -->' || L_CHQ_RETURN_AMOUNT);
    DBG('l_total_chg_amt -->' || L_TOTAL_CHG_AMT);
    DBG('p_clg_rec.instrument_amt -->' || P_CLG_REC.INSTRUMENT_AMT);
  
    IF CVPKS_UPLOAD_CG_REJECT.G_PARENT_FOUND AND
       NVL(L_CHARGE_APPLICABLE, 'N') = 'Y' THEN
    
      IF NVL(L_CHQ_RETURN_AMOUNT, 0) + NVL(L_TOTAL_CHG_AMT, 0) !=
         NVL(P_CLG_REC.INSTRUMENT_AMT, 0) THEN
        DBG('sum of Cheque return amount and charge amount not equal to original cheque amount ');
        OVPKS.PR_APPENDTBL('CG-CL0044', '');
        RETURN FALSE;
      END IF;
    END IF;
    DBG('calling  pr_process_retn_entries');
  
    PR_PROCESS_RETN_ENTRIES(PBRANCH,
                            P_XREF,
                            P_CLG_REC,
                            L_CHG_ROW,
                            L_CHQ_RETURN_AMOUNT,
                            P_REJECT_CODE,
                            P_ERR_CODE,
                            L_RET);
  
    IF L_RET = -1 THEN
      DBG('pr_process_retn_entries failed' || SQLERRM);
      OVPKS.PR_APPENDTBL(P_ERR_CODE, '');
      RETURN FALSE;
    END IF;
    P_TOT_CHG_AMT := NVL(L_TOTAL_CHG_AMT, 0);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception in fn_inward_return_ent..' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_inward_return_ent');
      RETURN FALSE;
  END FN_INWARD_RETURN_ENT;

  FUNCTION FN_REVERSE_ACCT(P_REF_NO        IN CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE,
                           P_ERR_CODE      OUT VARCHAR2,
                           P_ERR_PARAM     OUT VARCHAR2,
                           P_ONLINE_AUTH   IN CHAR,
                           P_CONSOL_REF_NO IN VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN IS
    L_COUNT                       INTEGER;
    L_ACC_TAB                     ACPKSS.TBL_ACHOFF;
    L_ACC_TAB1                    ACPKSS.TBL_ACHOFF;
    L_DATE_TIME                   DATE;
    L_PRODUCT_CODE                CGTM_PRODUCT_REFERRAL.PRODUCT_CODE%TYPE;
    L_INSUFFICIENT_FUNDS_REVERSAL CGTM_PRODUCT_REFERRAL.INSUF_FUNDS_RVRSL_TXN_CODE%TYPE;
    Z                             INTEGER;
    L_ENTRY_REC                   CSTB_CLEARING_MASTER%ROWTYPE;
  
    L_EVENT_SEQ  NUMBER := NULL;
    L_REVR_ESN   NUMBER := 2;
    L_MASTER_REC CSTB_CLEARING_MASTER%ROWTYPE;
  
    L_DEFER_LIQUIDATION VARCHAR2(1);
  
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_MAX_EVENT_SEQ NUMBER := NULL;
  BEGIN
    DBG('Entered fn_reverse_acct for p_consol_ref_no ' || P_CONSOL_REF_NO);
  
    IF CSPKSS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKSS_REQ_GLOBAL.P_CLUSTER, CSPKSS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
      DBG('cslling cspkss_clg_serv_cluster.fn_reverse_acct..');
      IF NOT CSPKSS_CLG_SERV_CLUSTER.FN_REVERSE_ACCT(P_REF_NO,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAM,
                                                     P_ONLINE_AUTH,
                                                     P_CONSOL_REF_NO,
                                                     L_FN_CALL_ID,
                                                     L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('CG',
                       'Failed in cspkss_clg_serv_cluster.fn_reverse_acct...' ||
                       SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      BEGIN
        SELECT MAX(EVENT_SR_NO)
          INTO L_MAX_EVENT_SEQ
          FROM ACVWS_ALL_AC_ENTRIES
         WHERE TRN_REF_NO = P_REF_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_MAX_EVENT_SEQ := NULL;
      END;
      DBG('l_max_event_seq passed is ' || L_MAX_EVENT_SEQ);
    
      L_COUNT := ACPKSS.FN_ACENTRY_RETRIEVAL(P_REF_NO,
                                             L_MAX_EVENT_SEQ,
                                             L_ACC_TAB);
    
      BEGIN
        SELECT *
          INTO L_MASTER_REC
          FROM CSTB_CLEARING_MASTER
         WHERE REFERENCE_NO = P_REF_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    
      BEGIN
        SELECT NVL(DEFER_LIQUIDATION, 'N')
          INTO L_DEFER_LIQUIDATION
          FROM CGTMS_PRODUCT_REFERRAL
         WHERE PRODUCT_CODE = L_MASTER_REC.PRODUCT_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_CODE  := 'CG-PROD-001';
          P_ERR_PARAM := L_MASTER_REC.PRODUCT_CODE;
      END;
    
      IF L_DEFER_LIQUIDATION = 'Y' THEN
      
        IF NVL(L_MASTER_REC.DISPATCH_STATUS, 'N') = 'L' THEN
          L_EVENT_SEQ := 4;
        ELSIF NVL(L_MASTER_REC.DISPATCH_STATUS, 'N') = 'D' THEN
          L_EVENT_SEQ := 3;
        ELSIF NVL(L_MASTER_REC.DISPATCH_STATUS, 'N') = 'B' THEN
          L_EVENT_SEQ := 2;
        END IF;
      
      ELSE
        L_EVENT_SEQ := 2;
      END IF;
    
      DEBUG.PR_DEBUG('CG', 'l_event_seq ' || L_EVENT_SEQ);
    
      L_DATE_TIME := CEPKSS_DATE.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE);
      DEBUG.PR_DEBUG('CG', 'Number of entries ' || TO_CHAR(L_COUNT));
      FOR Y IN 1 .. L_COUNT LOOP
        DBG('Direction ' || L_MASTER_REC.DIRECTION);
        DBG('l_defer_liquidation ' || L_DEFER_LIQUIDATION);
      
        IF L_MASTER_REC.DIRECTION = 'O' AND
           NVL(L_DEFER_LIQUIDATION, 'N') = 'Y' AND
           NVL(L_MASTER_REC.FILE_CONSOL_STATUS, 'N') = 'Y'
        
         THEN
          L_ACC_TAB(Y).EVENT := 'RETN';
        ELSE
        
          L_ACC_TAB(Y).EVENT := 'REVR';
        END IF;
        DEBUG.PR_DEBUG('CG', 'l_acc_tab(y) .event ' || L_ACC_TAB(Y).EVENT);
      
        L_ACC_TAB(Y).EVENT_SR_NO := NVL(L_EVENT_SEQ, 2);
        DEBUG.PR_DEBUG('CG',
                       'l_acc_tab(y) .event_sr_no ' || L_ACC_TAB(Y)
                       .EVENT_SR_NO);
      
        DEBUG.PR_DEBUG('CG',
                       'l_acc_tab(y) .trn_dt--> ' || L_ACC_TAB(Y).TRN_DT);
        G_TXN_DATE := L_ACC_TAB(Y).TRN_DT;
        IF NOT GWPKS_UTIL.G_FROM_BEAN OR
           (L_ACC_TAB(Y).TRN_DT < GLOBAL.APPLICATION_DATE)
        
         THEN
          DEBUG.PR_DEBUG('CG',
                         'inside ..l_acc_tab(y) .trn_dt--> ' || L_ACC_TAB(Y)
                         .TRN_DT);
          L_ACC_TAB(Y).TRN_DT := TRUNC(L_DATE_TIME);
        END IF;
      
        L_ACC_TAB(Y).TXN_INIT_DATE := TRUNC(L_DATE_TIME);
        L_ACC_TAB(Y).FCY_AMOUNT := -1 * L_ACC_TAB(Y).FCY_AMOUNT;
        L_ACC_TAB(Y).LCY_AMOUNT := -1 * L_ACC_TAB(Y).LCY_AMOUNT;
        L_ACC_TAB(Y).FINANCIAL_CYCLE := '';
        L_ACC_TAB(Y).PERIOD_CODE := '';
        L_ACC_TAB(Y).BATCH_NO := '';
        L_ACC_TAB(Y).CURR_NO := '';
        L_ACC_TAB(Y).USER_ID := GLOBAL.USER_ID;
        L_ACC_TAB(Y).MODULE := 'CG';
      
      END LOOP;
      G_EVENT_SEQ := NVL(L_EVENT_SEQ, 2);
      Z           := L_COUNT + 1;
    
      IF P_CONSOL_REF_NO IS NOT NULL THEN
        DBG('FCC6.1 CCD 19 Change if condn entered');
      
        SELECT *
          INTO L_ENTRY_REC
          FROM CSTBS_CLEARING_MASTER
         WHERE REFERENCE_NO = P_REF_NO;
      
        IF NOT FN_CONSOLIDATION_REVERSAL(P_CONSOL_REF_NO,
                                         L_ENTRY_REC,
                                         'R',
                                         P_ERR_CODE,
                                         P_ERR_PARAM,
                                         L_ACC_TAB1,
                                         P_ONLINE_AUTH) THEN
          DBG('Function fn_consolidation_reversal bombed in fn_reverse_acct');
        ELSE
          DBG('Consolidation reversal returned true for reference ' ||
              P_REF_NO);
        END IF;
      
        FOR X IN 1 .. L_ACC_TAB1.COUNT LOOP
          L_ACC_TAB(Z) := L_ACC_TAB1(X);
        
          Z := Z + 1;
        END LOOP;
      END IF;
    
      IF P_ONLINE_AUTH = 'Y' THEN
        IF NOT ACPKSS.FN_ACHANDOFF(P_REF_NO,
                                   2,
                                   TRUNC(L_DATE_TIME),
                                   L_ACC_TAB,
                                   'B',
                                   'N',
                                   'Y',
                                   GLOBAL.USER_ID,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
          DEBUG.PR_DEBUG('CG', 'Failed in Accounting Reversal...');
          RETURN FALSE;
        END IF;
      ELSE
        IF NOT ACPKSS.FN_ACHANDOFF(P_REF_NO,
                                   2,
                                   TRUNC(L_DATE_TIME),
                                   L_ACC_TAB,
                                   'U',
                                   'N',
                                   'Y',
                                   GLOBAL.USER_ID,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
          DEBUG.PR_DEBUG('CG', 'Failed in Accounting Reversal...');
          RETURN FALSE;
        END IF;
      END IF;
    
      L_ACC_TAB.DELETE;
    
    ELSE
      DBG('Resetting skip kernel..');
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_reverse_acct..' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_REVERSE_ACCT;

  FUNCTION FN_INSERT_ENTRY(P_USER           IN CSTBS_CLEARING_MASTER.MAKER_ID%TYPE,
                           P_MAKER_DT_STAMP IN DATE,
                           P_ENTRY_REC      IN CSTBS_CLEARING_MASTER%ROWTYPE,
                           P_ERR_CODE       OUT VARCHAR2) RETURN BOOLEAN IS
    L_RECORD_STAT           CHAR(1) := 'O';
    L_ERR_CODE              VARCHAR2(2000);
    L_ERR_PARAM             VARCHAR2(100);
    L_EVENT_SEQ_NO          NUMBER;
    L_AUTH_STAT             VARCHAR2(1);
    L_CHECKER_ID            VARCHAR2(100);
    L_CHECKER_DATESTAMP     DATE;
    L_NOTIFY_RETN_TO_MODULE CHAR(1) := 'N';
  
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside fn_insert_entry');
    DEBUG.PR_DEBUG('CG',
                   'Event seq no before increment is ' || L_EVENT_SEQ_NO);
  
    IF L_AUTH_STAT IS NULL THEN
      L_CHECKER_ID        := NULL;
      L_CHECKER_DATESTAMP := NULL;
    ELSE
      L_CHECKER_ID        := NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID);
      L_CHECKER_DATESTAMP := P_MAKER_DT_STAMP;
    END IF;
    DEBUG.PR_DEBUG('CG', 'l_checker_id:' || L_CHECKER_ID);
  
    DEBUG.PR_DEBUG('CG',
                   'The cheque issue date is => ' ||
                   P_ENTRY_REC.CHEQUE_ISSUE_DATE);
  
    IF P_ENTRY_REC.EVENT_SEQ_NO IS NULL THEN
      L_EVENT_SEQ_NO := 1;
    ELSE
      L_EVENT_SEQ_NO := P_ENTRY_REC.EVENT_SEQ_NO;
    END IF;
    DEBUG.PR_DEBUG('CG',
                   'Event seq no after increment is ' || L_EVENT_SEQ_NO);
  
    IF GWPKS_UTIL.G_FROM_BEAN THEN
    
      DEBUG.PR_DEBUG('CG', 'boss .. authorise it');
      L_AUTH_STAT := 'A';
    ELSE
      DEBUG.PR_DEBUG('CG', 'boss .. not from branch');
      L_AUTH_STAT := P_ENTRY_REC.AUTH_STAT;
    END IF;
  
    IF P_ENTRY_REC.DIRECTION = 'O' AND
       P_ENTRY_REC.MODULE_CODE NOT IN ('CG', 'RB', 'PD') THEN
      DBG('Module_code-->' || P_ENTRY_REC.MODULE_CODE || '~' ||
          'Direction-->' || '~' || P_ENTRY_REC.DIRECTION);
      L_NOTIFY_RETN_TO_MODULE := 'Y';
    END IF;
  
    BEGIN
      DBG('p_entry_rec.PROJECT_NAME-->' || P_ENTRY_REC.PROJECT_NAME);
      INSERT INTO CSTBS_CLEARING_MASTER
        (DIRECTION,
         PRODUCT_CODE,
         TXN_BRANCH,
         END_POINT,
         REFERENCE_NO,
         REM_CUST,
         BEN_CUST,
         REM_ACCOUNT,
         BEN_ACCOUNT,
         ACC_BRANCH,
         ACC_CCY,
         ACC_CCY_AMT,
         INSTRUMENT_CCY,
         INSTRUMENT_AMT,
         EXCH_RATE,
         INSTRUMENT_NO_1,
         INSTRUMENT_NO_2,
         STATUS,
         TXN_DATE,
         INSTRUMENT_DATE,
         VAL_DATE_BNK,
         VAL_DATE_CUST,
         BANK_CODE,
         BRANCH_CODE,
         SECTOR_CODE,
         ROUTING_NO,
         LATE_CLG_FLG,
         RECORD_STAT,
         AUTH_STAT,
         MAKER_ID,
         MAKER_DT_STAMP,
         CHECKER_ID,
         CHECKER_DT_STAMP,
         ERR_CODE,
         XREF,
         SCODE,
         SERIAL_NO,
         ENTRY_NO,
         MODULE_REFERENCE_NO,
         EVENT_SEQ_NO,
         MODULE_CODE,
         BENE_CCY,
         DIN,
         DIN_DATE,
         REMARKS,
         CONSIDER_FOR_REG_CC,
         SPL_CHQ_FLG,
         TXN_TANKED
         
        ,
         REM_COUNTRY,
         BENE_COUNTRY
         
        ,
         NEGOTIATED_RATE,
         NEGOTIATION_REF_NO
         
        ,
         PROJECT_NAME,
         UNIT_PAYMENT,
         UNIT_ID,
         DEPOSIT_SLIP_NO
         
        ,
         INSTRUMENT_TYPE,
         BENROUTINGNO,
         BATCH_NO,
         CHEQUE_ISSUE_DATE
         
        ,
         CHG_AMT,
         CHG_CCY,
         CHG_DESC,
         CHGCCY_LCY_XRATE,
         CHG_AMT1,
         CHG_CCY1,
         CHG_DESC1,
         CHGCCY_LCY_XRATE1,
         CHG_AMT2,
         CHG_CCY2,
         CHG_DESC2,
         CHGCCY_LCY_XRATE2,
         CHG_AMT3,
         CHG_CCY3,
         CHG_DESC3,
         CHGCCY_LCY_XRATE3,
         CHG_AMT4,
         CHG_CCY4,
         CHG_DESC4,
         CHGCCY_LCY_XRATE4,
         NOTIFY_RETN_TO_MODULE)
      
      VALUES
        (P_ENTRY_REC.DIRECTION,
         P_ENTRY_REC.PRODUCT_CODE,
         P_ENTRY_REC.TXN_BRANCH,
         P_ENTRY_REC.END_POINT,
         P_ENTRY_REC.REFERENCE_NO,
         P_ENTRY_REC.REM_CUST,
         P_ENTRY_REC.BEN_CUST,
         P_ENTRY_REC.REM_ACCOUNT,
         P_ENTRY_REC.BEN_ACCOUNT,
         P_ENTRY_REC.ACC_BRANCH,
         P_ENTRY_REC.ACC_CCY,
         P_ENTRY_REC.ACC_CCY_AMT,
         P_ENTRY_REC.INSTRUMENT_CCY,
         P_ENTRY_REC.INSTRUMENT_AMT,
         P_ENTRY_REC.EXCH_RATE,
         P_ENTRY_REC.INSTRUMENT_NO_1,
         P_ENTRY_REC.INSTRUMENT_NO_2,
         P_ENTRY_REC.STATUS,
         P_ENTRY_REC.TXN_DATE,
         P_ENTRY_REC.INSTRUMENT_DATE,
         P_ENTRY_REC.VAL_DATE_BNK,
         P_ENTRY_REC.VAL_DATE_CUST,
         P_ENTRY_REC.BANK_CODE,
         P_ENTRY_REC.BRANCH_CODE,
         P_ENTRY_REC.SECTOR_CODE,
         P_ENTRY_REC.ROUTING_NO,
         P_ENTRY_REC.LATE_CLG_FLG,
         L_RECORD_STAT,
         
         L_AUTH_STAT,
         P_USER,
         P_MAKER_DT_STAMP
         
        ,
         L_CHECKER_ID,
         L_CHECKER_DATESTAMP,
         P_ENTRY_REC.ERR_CODE,
         P_ENTRY_REC.XREF,
         P_ENTRY_REC.SCODE,
         P_ENTRY_REC.SERIAL_NO,
         P_ENTRY_REC.ENTRY_NO,
         P_ENTRY_REC.MODULE_REFERENCE_NO,
         L_EVENT_SEQ_NO,
         P_ENTRY_REC.MODULE_CODE,
         P_ENTRY_REC.BENE_CCY,
         P_ENTRY_REC.DIN,
         P_ENTRY_REC.DIN_DATE,
         P_ENTRY_REC.REMARKS,
         P_ENTRY_REC.CONSIDER_FOR_REG_CC,
         P_ENTRY_REC.SPL_CHQ_FLG,
         P_ENTRY_REC.TXN_TANKED
         
        ,
         P_ENTRY_REC.REM_COUNTRY,
         P_ENTRY_REC.BENE_COUNTRY
         
        ,
         P_ENTRY_REC.NEGOTIATED_RATE,
         P_ENTRY_REC.NEGOTIATION_REF_NO
         
        ,
         P_ENTRY_REC.PROJECT_NAME,
         P_ENTRY_REC.UNIT_PAYMENT,
         P_ENTRY_REC.UNIT_ID,
         P_ENTRY_REC.DEPOSIT_SLIP_NO
         
        ,
         P_ENTRY_REC.INSTRUMENT_TYPE,
         P_ENTRY_REC.BENROUTINGNO,
         P_ENTRY_REC.BATCH_NO,
         P_ENTRY_REC.CHEQUE_ISSUE_DATE
         
        ,
         P_ENTRY_REC.CHG_AMT,
         P_ENTRY_REC.CHG_CCY,
         P_ENTRY_REC.CHG_DESC,
         P_ENTRY_REC.CHGCCY_LCY_XRATE,
         P_ENTRY_REC.CHG_AMT1,
         P_ENTRY_REC.CHG_CCY1,
         P_ENTRY_REC.CHG_DESC1,
         P_ENTRY_REC.CHGCCY_LCY_XRATE1,
         P_ENTRY_REC.CHG_AMT2,
         P_ENTRY_REC.CHG_CCY2,
         P_ENTRY_REC.CHG_DESC2,
         P_ENTRY_REC.CHGCCY_LCY_XRATE2,
         P_ENTRY_REC.CHG_AMT3,
         P_ENTRY_REC.CHG_CCY3,
         P_ENTRY_REC.CHG_DESC3,
         P_ENTRY_REC.CHGCCY_LCY_XRATE3,
         P_ENTRY_REC.CHG_AMT4,
         P_ENTRY_REC.CHG_CCY4,
         P_ENTRY_REC.CHG_DESC4,
         P_ENTRY_REC.CHGCCY_LCY_XRATE4,
         L_NOTIFY_RETN_TO_MODULE)
      
      RETURNING ROWID INTO G_MAST_ROW_ID;
      DBG('p_entry_rec.instrument_type:::: ' ||
          P_ENTRY_REC.INSTRUMENT_TYPE);
    
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('CG',
                       'Exception while inserting into cstbs_clearing_master ..' ||
                       SQLERRM);
        P_ERR_CODE := 'CG-CL0001';
        OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
        RETURN FALSE;
    END;
  
    BEGIN
      DBG('l_event_seq_no-->' || L_EVENT_SEQ_NO || '~' || P_ENTRY_REC.XREF);
      INSERT INTO CSTBS_CLEARING_DETAILS
        (DIRECTION,
         PRODUCT_CODE,
         TXN_BRANCH,
         END_POINT,
         REFERENCE_NO,
         REM_ACCOUNT,
         BEN_ACCOUNT,
         ACC_BRANCH,
         INSTRUMENT_NO_1,
         BRANCH_CODE,
         SECTOR_CODE,
         XREF,
         EVENT_SEQ_NO,
         REMARKS,
         STATUS,
         ENTRY_NO)
      VALUES
        (P_ENTRY_REC.DIRECTION,
         P_ENTRY_REC.PRODUCT_CODE,
         P_ENTRY_REC.TXN_BRANCH,
         P_ENTRY_REC.END_POINT,
         P_ENTRY_REC.REFERENCE_NO,
         P_ENTRY_REC.REM_ACCOUNT,
         P_ENTRY_REC.BEN_ACCOUNT,
         P_ENTRY_REC.ACC_BRANCH,
         P_ENTRY_REC.INSTRUMENT_NO_1,
         P_ENTRY_REC.BRANCH_CODE,
         P_ENTRY_REC.SECTOR_CODE,
         P_ENTRY_REC.XREF,
         L_EVENT_SEQ_NO,
         P_ENTRY_REC.REMARKS,
         P_ENTRY_REC.STATUS,
         P_ENTRY_REC.ENTRY_NO);
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('CG',
                       'problem in inserting into cstbs_clearing_details4' ||
                       SQLERRM);
        RETURN FALSE;
    END;
  
    DBG('Module_code-->' || P_ENTRY_REC.MODULE_CODE || '~' ||
        'Direction-->' || '~' || P_ENTRY_REC.DIRECTION);
    IF P_ENTRY_REC.DIRECTION = 'O' AND
       P_ENTRY_REC.MODULE_CODE NOT IN ('CG', 'RB', 'PD') THEN
      DEBUG.PR_DEBUG('CG',
                     'Going to insert into CGTB_MODULE_CHQ_STATUS for other than CG RB and PD module');
      BEGIN
      
        INSERT INTO CGTB_MODULE_CHQ_STATUS
          (REFERENCE_NO,
           SCODE,
           XREF,
           MODULE_CODE,
           MODULE_REF_NO,
           BEN_ACCOUNT,
           ACC_BRANCH,
           ACC_CCY,
           INSTRUMENT_NO_1,
           VAL_DATE_CUST,
           REM_ACCOUNT,
           REM_DETAILS1,
           REM_DETAILS2,
           REM_DETAILS3,
           STATUS,
           RETN_NOTIFIED_TO_MODULE)
        VALUES
          (P_ENTRY_REC.REFERENCE_NO,
           P_ENTRY_REC.SCODE,
           P_ENTRY_REC.XREF,
           P_ENTRY_REC.MODULE_CODE,
           P_ENTRY_REC.MODULE_REFERENCE_NO,
           P_ENTRY_REC.BEN_ACCOUNT,
           P_ENTRY_REC.ACC_BRANCH,
           P_ENTRY_REC.ACC_CCY,
           P_ENTRY_REC.INSTRUMENT_NO_1,
           P_ENTRY_REC.VAL_DATE_CUST,
           P_ENTRY_REC.REM_ACCOUNT,
           P_ENTRY_REC.REM_DETAILS1,
           P_ENTRY_REC.REM_DETAILS2,
           P_ENTRY_REC.REM_DETAILS3,
           'S',
           'N');
      EXCEPTION
        WHEN OTHERS THEN
          DBG('problem in inserting into CGTB_MODULE_CHQ_STATUS' ||
              SQLERRM);
          RETURN FALSE;
      END;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('calling cspks_clg_serv_cluster.fn_insert_entry');
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT CSPKS_CLG_SERV_CLUSTER.FN_INSERT_ENTRY(P_USER,
                                                    P_MAKER_DT_STAMP,
                                                    P_ENTRY_REC,
                                                    P_ERR_CODE,
                                                    L_FN_CALL_ID,
                                                    L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('CG', 'Failed in fn_insert_entry');
        RETURN FALSE;
      END IF;
    END IF;
  
    DEBUG.PR_DEBUG('CG', 'fn_insert_entry returning TRUE');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_insert_entry - ' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_INSERT_ENTRY;

  FUNCTION FN_PASS_IC_ACCT_ENTRIES(PBRANCH         IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                                   P_ENTRY_REC     IN OUT CSTBS_CLEARING_MASTER%ROWTYPE,
                                   P_CHG_ROW       IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                                   P_ERR_CODE      OUT VARCHAR2,
                                   P_ERR_PARAM     OUT VARCHAR2,
                                   P_CONSOL_REF_NO IN VARCHAR2 DEFAULT 'N')
    RETURN BOOLEAN IS
    L_ACC_HAND     ACPKSS.TBL_ACHOFF;
    L_ACTION       CHAR(1);
    L_USER_ID      ACTBS_DAILY_LOG.USER_ID%TYPE;
    L_ERRCODE      VARCHAR2(1000);
    L_ERRPARAM     VARCHAR2(10000);
    L_OVD_CD       VARCHAR2(2000);
    L_OVD_PARAM    VARCHAR2(2000);
    L_LCY_AVG      ACTBS_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_RATE1        ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE2        ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    L_ADJREC       IFTBS_CLEARING_UPLOAD%ROWTYPE;
    L_DIFF         IFTBS_CLEARING_UPLOAD.INSTRAMT%TYPE;
    L_BRANCH_PARAM CATMS_BRANCH_PARAM%ROWTYPE;
    L_MIS_HEAD     STTMS_TRN_CODE.TRN_CODE%TYPE;
  
    L_PROD_ERR               VARCHAR2(32767);
    L_PROD_PARAM             VARCHAR2(32767);
    L_REFERRAL_REQUIRED      STTMS_CUST_ACCOUNT.REFERRAL_REQUIRED%TYPE;
    L_PROD_REFERRAL_REQUIRED CGTM_PRODUCT_REFERRAL.REFERRAL_REQUIRED%TYPE;
    LBAL                     NUMBER(22, 3) := 0;
    L_CUSTNO                 STTM_CUST_ACCOUNT.CUST_NO%TYPE;
    L_COUNT_REF_QUE          NUMBER;
  
    L_RET NUMBER;
  
    L_ACC_REC STTBS_ACCOUNT%ROWTYPE;
  
    L_FUNDING            STTMS_CUST_ACCOUNT.FUNDING%TYPE;
    L_POSPARKING_ACCOUNT STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT%TYPE;
    L_POSPARKING_BRANCH  STTMS_CUST_ACCOUNT.FUNDING_BRANCH%TYPE;
    L_CURRENCY           STTMS_CUST_ACCOUNT.CCY%TYPE;
  
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside fn_pass_ic_acct_entries.');
    DEBUG.PR_DEBUG('CG',
                   'Accounts involved 1. Beneficiary ' ||
                   P_ENTRY_REC.BEN_ACCOUNT);
    DEBUG.PR_DEBUG('CG', '2. Remitter ' || P_ENTRY_REC.REM_ACCOUNT);
    DEBUG.PR_DEBUG('CG', '3. Txn in ARC ' || P_CHG_ROW.COD_TXN_ACCOUNT);
    DEBUG.PR_DEBUG('CG', '4. Offset in ARC ' || P_CHG_ROW.COD_OFFSET_ACC);
    DEBUG.PR_DEBUG('CG',
                   'p_Entry_Rec.Instrument_No_1-->' ||
                   P_ENTRY_REC.INSTRUMENT_NO_1);
    G_REFERRAL_QUEUE := 'N';
    DEBUG.PR_DEBUG('CG', 'g_referral_queue-->' || G_REFERRAL_QUEUE);
    DEBUG.PR_DEBUG('CG',
                   'p_entry_rec.acc_ccy_amt--> ' || P_ENTRY_REC.ACC_CCY_AMT);
  
    L_USER_ID := GLOBAL.USER_ID;
  
    IF NOT CAPKS_POSPAY_SERV.FN_CHECK_FUNDING(
                                              
                                              P_ENTRY_REC.ACC_BRANCH,
                                              P_ENTRY_REC.REM_ACCOUNT,
                                              L_FUNDING,
                                              L_POSPARKING_ACCOUNT,
                                              L_POSPARKING_BRANCH,
                                              L_CURRENCY,
                                              L_ERRCODE,
                                              L_ERRPARAM) THEN
    
      DBG('function fn_check_funding returns false');
    
      P_ERR_CODE  := L_ERRCODE;
      P_ERR_PARAM := L_ERRPARAM;
    
      RETURN FALSE;
    
    END IF;
  
    G_EVENT_SEQ := 1;
    L_ACC_HAND := ACPKS.EMPTY_HOFF;
    L_ACC_HAND(1).MODULE := 'CG';
    L_ACC_HAND(1).MIS_HEAD := P_CHG_ROW.COD_MIS_HEAD;
    L_ACC_HAND(1).AVLDAYS := 0;
    L_ACC_HAND(1).TRN_REF_NO := P_ENTRY_REC.REFERENCE_NO;
    L_ACC_HAND(1).EVENT_SR_NO := 1;
    L_ACC_HAND(1).EVENT := 'INIT';
  
    L_ACC_HAND(1).TRN_DT := GLOBAL.APPLICATION_DATE;
    L_ACC_HAND(1).VALUE_DT := P_ENTRY_REC.VAL_DATE_CUST;
  
    L_ACC_HAND(1).TXN_INIT_DATE := P_ENTRY_REC.TXN_DATE;
  
    L_ACC_HAND(1).INSTRUMENT_CODE := P_ENTRY_REC.INSTRUMENT_NO_1;
    DEBUG.PR_DEBUG('CG',
                   'l_Acc_Hand(1) .Instrument_Code-->' || L_ACC_HAND(1)
                   .INSTRUMENT_CODE);
    L_ACC_HAND(1).RELATED_CUSTOMER := P_ENTRY_REC.REM_CUST;
    L_ACC_HAND(1).BATCH_NO := P_ENTRY_REC.BATCH_NO;
    L_ACC_HAND(1).CURR_NO := NULL;
    L_ACC_HAND(1).USER_ID := L_USER_ID;
    L_ACC_HAND(1).BANK_CODE := P_ENTRY_REC.BANK_CODE;
    L_ACC_HAND(1).DRCR_IND := 'D';
    L_ACC_HAND(1).TRN_CODE := P_CHG_ROW.COD_MAIN_TXN_CODE;
    L_ACC_HAND(1).AMOUNT_TAG := 'TXN_AMOUNT';
    L_ACC_HAND(1).NETTING_IND := 'N';
    L_ACC_HAND(1).EXTERNAL_REF_NO := P_ENTRY_REC.XREF;
  
    IF P_ENTRY_REC.REM_ACCOUNT IS NOT NULL AND L_FUNDING = 'Y' THEN
      L_ACC_HAND(1).AC_NO := L_POSPARKING_ACCOUNT;
      G_FUNDING_PARKING_ACC := P_ENTRY_REC.REM_ACCOUNT;
    
    ELSIF P_ENTRY_REC.REM_ACCOUNT IS NOT NULL THEN
      L_ACC_HAND(1).AC_NO := P_ENTRY_REC.REM_ACCOUNT;
    ELSE
      L_ACC_HAND(1).AC_NO := P_CHG_ROW.COD_TXN_ACCOUNT;
    END IF;
  
    L_ACC_HAND(1).AC_CCY := P_ENTRY_REC.ACC_CCY;
  
    IF L_FUNDING = 'Y' THEN
      L_ACC_HAND(1).AC_BRANCH := L_POSPARKING_BRANCH;
    ELSE
    
      L_ACC_HAND(1).AC_BRANCH := P_ENTRY_REC.ACC_BRANCH;
    END IF;
  
    G_NSF_ACC     := L_ACC_HAND(1).AC_NO;
    G_TXN_ACC     := L_ACC_HAND(1).AC_NO;
    G_TXN_ACC_BRN := L_ACC_HAND(1).AC_BRANCH;
    G_TXN_ACC_CCY := L_ACC_HAND(1).AC_CCY;
  
    IF P_ENTRY_REC.ACC_CCY = GLOBAL.LCY THEN
      L_ACC_HAND(1).LCY_AMOUNT := P_ENTRY_REC.ACC_CCY_AMT;
      L_ACC_HAND(1).FCY_AMOUNT := NULL;
      L_ACC_HAND(1).EXCH_RATE := NULL;
    ELSE
      L_ACC_HAND(1).FCY_AMOUNT := P_ENTRY_REC.ACC_CCY_AMT;
      IF P_ENTRY_REC.INSTRUMENT_CCY = GLOBAL.LCY THEN
        L_ACC_HAND(1).LCY_AMOUNT := P_ENTRY_REC.INSTRUMENT_AMT;
        L_ACC_HAND(1).EXCH_RATE := P_ENTRY_REC.EXCH_RATE;
      ELSE
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(PBRANCH,
                                      P_ENTRY_REC.ACC_CCY,
                                      GLOBAL.LCY
                                      
                                     ,
                                      NVL(G_RATE_TYPE_PREFERRED, 'STANDARD')
                                      
                                     ,
                                      NVL(G_RATE_CODE_PREFERRED, 'M')
                                      
                                     ,
                                      P_ENTRY_REC.ACC_CCY_AMT,
                                      'Y',
                                      L_ACC_HAND             (1).LCY_AMOUNT,
                                      L_ACC_HAND             (1).EXCH_RATE,
                                      L_ERRCODE) THEN
          DEBUG.PR_DEBUG('CG', 'Error while computing LCY');
          P_ERR_CODE := L_ERRCODE;
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    DEBUG.PR_DEBUG('CG', 'After building handoff 1 ');
  
    IF NOT CVPKS_UTILS.GET_STTB_ACC(L_ACC_HAND(1).AC_BRANCH,
                                    L_ACC_HAND(1).AC_NO,
                                    L_ACC_REC) THEN
      DEBUG.PR_DEBUG('CG', 'Failed to get account details');
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
    ELSE
      DBG('Successfully returned the get_sttb_acc values');
    END IF;
    DBG('l_acc_rec.ac_or_gl is :' || L_ACC_REC.AC_OR_GL);
    IF L_ACC_REC.AC_OR_GL = 'A' THEN
    
      DEBUG.PR_DEBUG('CG', 'Start of FCC5.3 changes referral check');
    
      SELECT CUST_NO, NVL(REFERRAL_REQUIRED, 'N')
        INTO L_CUSTNO, L_REFERRAL_REQUIRED
        FROM STTMS_CUST_ACCOUNT
       WHERE BRANCH_CODE = L_ACC_HAND(1).AC_BRANCH
         AND CUST_AC_NO = L_ACC_HAND(1).AC_NO
         AND AUTH_STAT = 'A';
    
      DEBUG.PR_DEBUG('CG', 'customer no is' || L_CUSTNO);
      DEBUG.PR_DEBUG('CG', 'l_referral_required ' || L_REFERRAL_REQUIRED);
      DEBUG.PR_DEBUG('CG', 'customer account  ' || L_ACC_HAND(1).AC_NO);
      DEBUG.PR_DEBUG('CG', 'customer branch  ' || L_ACC_HAND(1).AC_BRANCH);
      DEBUG.PR_DEBUG('CG',
                     'external ref no ' || L_ACC_HAND(1).EXTERNAL_REF_NO);
      DEBUG.PR_DEBUG('CG',
                     'Transaction ref no ' || L_ACC_HAND(1).TRN_REF_NO);
    
      BEGIN
      
        SELECT NVL(REFERRAL_REQUIRED, 'N')
          INTO L_PROD_REFERRAL_REQUIRED
          FROM CGTM_PRODUCT_REFERRAL
        
         WHERE PRODUCT_CODE = SUBSTR(L_ACC_HAND(1).TRN_REF_NO, 4, 4);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_PROD_REFERRAL_REQUIRED := 'N';
      END;
    
      DEBUG.PR_DEBUG('CG',
                     'l_prod_referral_required ' ||
                     L_PROD_REFERRAL_REQUIRED);
    
      IF (L_REFERRAL_REQUIRED = 'Y' AND L_PROD_REFERRAL_REQUIRED = 'Y') AND
         NVL(P_CONSOL_REF_NO, 'N') = 'Y' THEN
        IF G_CONSOL_REFERRAL_REQD = 'Y' THEN
          IF NOT FN_REFERRAL_QUEUE(L_ACC_HAND(1).AC_BRANCH,
                                   L_CUSTNO,
                                   L_ACC_HAND(1).AC_NO,
                                   L_ACC_HAND(1).TRN_REF_NO
                                   
                                  ,
                                   P_ENTRY_REC.ACC_CCY_AMT,
                                   L_ACC_HAND             (1).EVENT_SR_NO,
                                   L_ACC_HAND             (1).VALUE_DT,
                                   TRUE,
                                   P_CONSOL_REF_NO) THEN
            DEBUG.PR_DEBUG('CG',
                           'Falied to insert into Referral Queue ' ||
                           SQLERRM);
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    
      IF (L_REFERRAL_REQUIRED = 'Y' AND L_PROD_REFERRAL_REQUIRED = 'Y' AND
         NVL(P_CONSOL_REF_NO, 'N') = 'N') THEN
        LBAL := 0;
        IF NOT ACPKSS_MISC.FN_GETAVLBAL(L_ACC_HAND(1).AC_BRANCH,
                                        L_ACC_HAND(1).AC_NO,
                                        LBAL,
                                        'Y') THEN
        
          DEBUG.PR_DEBUG('CG', 'exception in fn_getavlbal ');
          RETURN FALSE;
        END IF;
      
        DEBUG.PR_DEBUG('CG',
                       'limit inside referral account' || L_ACC_HAND(1)
                       .AC_NO);
        DEBUG.PR_DEBUG('CG', 'limit inside referral Balance' || LBAL);
        DEBUG.PR_DEBUG('CG',
                       'limit inside referral Contract  fcy amount ' || L_ACC_HAND(1)
                       .FCY_AMOUNT);
        DEBUG.PR_DEBUG('CG',
                       'limit inside referral Contract  lcy amount ' || L_ACC_HAND(1)
                       .LCY_AMOUNT);
        DEBUG.PR_DEBUG('CG',
                       'checking if there is any record in referral table');
      
        SELECT COUNT(*)
          INTO L_COUNT_REF_QUE
          FROM STTBS_REFERRAL_QUEUE
         WHERE CUST_AC_NO = L_ACC_HAND(1).AC_NO
           AND PROCESSED_FLG = 'N';
        DEBUG.PR_DEBUG('CG',
                       'No of record found in referral_queue' ||
                       L_COUNT_REF_QUE);
        IF L_COUNT_REF_QUE = 0 AND LBAL >= L_ACC_HAND(1).LCY_AMOUNT THEN
        
          DEBUG.PR_DEBUG('CG',
                         'No rows found in referral queue, inserting into temp table');
          IF NOT FN_REFERRAL_QUEUE(L_ACC_HAND(1).AC_BRANCH,
                                   L_CUSTNO,
                                   L_ACC_HAND(1).AC_NO,
                                   L_ACC_HAND(1).TRN_REF_NO
                                   
                                  ,
                                   P_ENTRY_REC.ACC_CCY_AMT,
                                   L_ACC_HAND             (1).EVENT_SR_NO,
                                   L_ACC_HAND             (1).VALUE_DT,
                                   FALSE) THEN
            DEBUG.PR_DEBUG('CG',
                           'Falied to insert into Referral_Queue_t' ||
                           SQLERRM);
            RETURN FALSE;
          END IF;
        ELSE
          IF LBAL < L_ACC_HAND(1).LCY_AMOUNT THEN
            DEBUG.PR_DEBUG('CG',
                           'Account balance  busted inserting into referral queue');
          
            IF NOT FN_REFERRAL_QUEUE(L_ACC_HAND(1).AC_BRANCH,
                                     L_CUSTNO,
                                     L_ACC_HAND(1).AC_NO,
                                     L_ACC_HAND(1).TRN_REF_NO
                                     
                                    ,
                                     P_ENTRY_REC.ACC_CCY_AMT,
                                     L_ACC_HAND             (1).EVENT_SR_NO,
                                     L_ACC_HAND             (1).VALUE_DT,
                                     TRUE) THEN
              DEBUG.PR_DEBUG('CG',
                             'Falied to insert into Referral Queue ' ||
                             SQLERRM);
              RETURN FALSE;
            END IF;
          
            DEBUG.PR_DEBUG('CG',
                           'Account balance  busted inserting from temp table to referral queue');
            IF NOT FN_TEMP_TO_QUEUE(L_CUSTNO) THEN
              DEBUG.PR_DEBUG('CG',
                             'Falied to insert into Queue from temp ' ||
                             SQLERRM);
              RETURN FALSE;
            END IF;
          
            DEBUG.PR_DEBUG('CG', 'deleting from temp table');
          
            DELETE FROM PCTBS_REFERRAL_QUEUE_TEMP WHERE CUST_NO = L_CUSTNO;
          
          ELSE
            DEBUG.PR_DEBUG('CG', 'Account balance busted ');
          
            IF NOT FN_REFERRAL_QUEUE(L_ACC_HAND(1).AC_BRANCH,
                                     L_CUSTNO,
                                     L_ACC_HAND(1).AC_NO,
                                     L_ACC_HAND(1).TRN_REF_NO
                                     
                                    ,
                                     P_ENTRY_REC.ACC_CCY_AMT,
                                     L_ACC_HAND             (1).EVENT_SR_NO,
                                     L_ACC_HAND             (1).VALUE_DT,
                                     TRUE) THEN
              DEBUG.PR_DEBUG('CG',
                             'Falied to insert into Referral Queue ' ||
                             SQLERRM);
              RETURN FALSE;
            END IF;
          END IF;
        END IF;
      END IF;
      DEBUG.PR_DEBUG('CG', 'End of Fcc5.3 changes for Referral Check');
    
    END IF;
  
    BEGIN
      SELECT *
        INTO L_ADJREC
        FROM IFTBS_CLEARING_UPLOAD
       WHERE SCODE = P_ENTRY_REC.SCODE
         AND XREF = P_ENTRY_REC.XREF
         AND ENTRY_NO = P_ENTRY_REC.ENTRY_NO
         AND AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DEBUG.PR_DEBUG('CG',
                       'Could not find record for adjustment entries');
        NULL;
    END;
    L_DIFF := NULL;
    L_DIFF := NVL(L_ADJREC.OLD_INSTR_AMT, 0) - NVL(L_ADJREC.INSTRAMT, 0);
  
    L_ACC_HAND(2).MODULE := 'CG';
    L_ACC_HAND(2).MIS_HEAD := P_CHG_ROW.COD_MIS_HEAD;
    L_ACC_HAND(2).AVLDAYS := 0;
    L_ACC_HAND(2).TRN_REF_NO := P_ENTRY_REC.REFERENCE_NO;
    L_ACC_HAND(2).EVENT_SR_NO := 1;
    L_ACC_HAND(2).EVENT := 'INIT';
  
    L_ACC_HAND(2).TRN_DT := GLOBAL.APPLICATION_DATE;
    L_ACC_HAND(2).VALUE_DT := P_ENTRY_REC.VAL_DATE_BNK;
  
    L_ACC_HAND(2).TXN_INIT_DATE := P_ENTRY_REC.TXN_DATE;
  
    DEBUG.PR_DEBUG('CG',
                   'p_Entry_Rec.Instrument_No_1(2)-->' ||
                   P_ENTRY_REC.INSTRUMENT_NO_1);
    L_ACC_HAND(2).INSTRUMENT_CODE := P_ENTRY_REC.INSTRUMENT_NO_1;
    DEBUG.PR_DEBUG('CG',
                   'l_Acc_Hand(2) .Instrument_Code-->' || L_ACC_HAND(2)
                   .INSTRUMENT_CODE);
  
    L_ACC_HAND(2).BATCH_NO := P_ENTRY_REC.BATCH_NO;
    L_ACC_HAND(2).CURR_NO := NULL;
    L_ACC_HAND(2).USER_ID := GLOBAL.USER_ID;
    L_ACC_HAND(2).BANK_CODE := P_ENTRY_REC.BANK_CODE;
    L_ACC_HAND(2).DRCR_IND := 'C';
    L_ACC_HAND(2).TRN_CODE := P_CHG_ROW.COD_OFFSET_TXN_CODE;
    L_ACC_HAND(2).AMOUNT_TAG := 'OFS_AMOUNT';
    L_ACC_HAND(2).NETTING_IND := 'N';
    L_ACC_HAND(2).EXTERNAL_REF_NO := P_ENTRY_REC.XREF;
  
    IF P_CHG_ROW.COD_OFFSET_ACC IS NULL THEN
      L_ACC_HAND(2).AC_NO := P_ENTRY_REC.BEN_ACCOUNT;
      L_ACC_HAND(2).RELATED_CUSTOMER := P_ENTRY_REC.BEN_CUST;
      L_ACC_HAND(2).AC_BRANCH := P_ENTRY_REC.TXN_BRANCH;
    ELSE
      L_ACC_HAND(2).AC_NO := P_CHG_ROW.COD_OFFSET_ACC;
      L_ACC_HAND(2).RELATED_CUSTOMER := P_ENTRY_REC.REM_CUST;
      IF P_CHG_ROW.COD_OFFSET_BRN = '*.*' THEN
        PR_GET_BRN_DET(P_ENTRY_REC.TXN_BRANCH);
        L_ACC_HAND(2).AC_BRANCH := PKG_BRN_REC.CLG_BRN;
      ELSE
        L_ACC_HAND(2).AC_BRANCH := P_CHG_ROW.COD_OFFSET_BRN;
      END IF;
    END IF;
    L_ACC_HAND(2).AC_CCY := P_ENTRY_REC.INSTRUMENT_CCY;
    IF L_ADJREC.ADJUST_AMT_FLAG = 'Y' AND L_DIFF <> 0 THEN
      IF P_ENTRY_REC.INSTRUMENT_CCY = GLOBAL.LCY THEN
        L_ACC_HAND(2).LCY_AMOUNT := L_ADJREC.OLD_INSTR_AMT;
        L_ACC_HAND(2).FCY_AMOUNT := NULL;
        L_ACC_HAND(2).EXCH_RATE := NULL;
      ELSE
        L_ACC_HAND(2).FCY_AMOUNT := L_ADJREC.OLD_INSTR_AMT;
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(PBRANCH,
                                      P_ENTRY_REC.INSTRUMENT_CCY,
                                      GLOBAL.LCY
                                      
                                     ,
                                      NVL(G_RATE_TYPE_PREFERRED, 'STANDARD')
                                      
                                     ,
                                      NVL(G_RATE_CODE_PREFERRED, 'M')
                                      
                                     ,
                                      L_ADJREC.OLD_INSTR_AMT,
                                      'Y',
                                      L_ACC_HAND            (2).LCY_AMOUNT,
                                      L_ACC_HAND            (2).EXCH_RATE,
                                      L_ERRCODE) THEN
          DEBUG.PR_DEBUG('CG', 'Error while computing LCY');
          P_ERR_CODE := L_ERRCODE;
          RETURN FALSE;
        END IF;
      END IF;
    ELSE
      IF P_ENTRY_REC.INSTRUMENT_CCY = GLOBAL.LCY THEN
        L_ACC_HAND(2).LCY_AMOUNT := P_ENTRY_REC.INSTRUMENT_AMT;
        L_ACC_HAND(2).FCY_AMOUNT := NULL;
        L_ACC_HAND(2).EXCH_RATE := NULL;
      ELSE
        L_ACC_HAND(2).FCY_AMOUNT := P_ENTRY_REC.INSTRUMENT_AMT;
        IF P_ENTRY_REC.ACC_CCY = GLOBAL.LCY THEN
          L_ACC_HAND(2).LCY_AMOUNT := P_ENTRY_REC.ACC_CCY_AMT;
          L_ACC_HAND(2).EXCH_RATE := P_ENTRY_REC.EXCH_RATE;
        ELSE
          IF NOT
              CYPKSS.FN_AMT1_TO_AMT2(PBRANCH,
                                     P_ENTRY_REC.INSTRUMENT_CCY,
                                     GLOBAL.LCY
                                     
                                    ,
                                     NVL(G_RATE_TYPE_PREFERRED, 'STANDARD')
                                     
                                    ,
                                     NVL(G_RATE_CODE_PREFERRED, 'M')
                                     
                                    ,
                                     P_ENTRY_REC.INSTRUMENT_AMT,
                                     'Y',
                                     L_ACC_HAND                (2).LCY_AMOUNT,
                                     L_ACC_HAND                (2).EXCH_RATE,
                                     L_ERRCODE) THEN
            DEBUG.PR_DEBUG('CG', 'Error while computing LCY');
            P_ERR_CODE := L_ERRCODE;
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    END IF;
    DEBUG.PR_DEBUG('CG', 'After building hand off - 2 ');
    IF L_ADJREC.ADJUST_AMT_FLAG = 'Y' AND L_DIFF <> 0 THEN
      DEBUG.PR_DEBUG('CG',
                     'selecting branch param for branch ' ||
                     GLOBAL.CURRENT_BRANCH);
      BEGIN
        SELECT *
          INTO L_BRANCH_PARAM
          FROM CATMS_BRANCH_PARAM
         WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('CG',
                         'In when no data found while selecting branch param for branch adjustment entry record');
          DEBUG.PR_DEBUG('CG', 'Cannot build acc hand 3');
          P_ERR_CODE := 'CA-POS075';
          RETURN FALSE;
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('CG',
                         'In when others while selecting branch param for branch adjustment entry record' ||
                         SQLERRM);
          DEBUG.PR_DEBUG('CG', 'Cannot build acc hand 3');
          P_ERR_CODE := 'CG-CL0001';
          OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
          RETURN FALSE;
      END;
    
      BEGIN
        DEBUG.PR_DEBUG('CG',
                       'Selecting mis head for adjustment transaction code ' ||
                       L_BRANCH_PARAM.ADJ_TRN_CODE);
        SELECT MIS_HEAD
          INTO L_MIS_HEAD
          FROM STTMS_TRN_CODE
         WHERE TRN_CODE = L_BRANCH_PARAM.ADJ_TRN_CODE
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('CG',
                         'In when no data found while selecting mis head for adjustment transaction code');
          DEBUG.PR_DEBUG('CG', 'Cannot build acc hand 3');
          P_ERR_CODE := 'CA-POS076';
          RETURN FALSE;
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('CG',
                         'In when others while selecting mis head for adjustment transaction code' ||
                         SQLERRM);
          DEBUG.PR_DEBUG('CG', 'Cannot build acc hand 3');
          P_ERR_CODE := 'CG-CL0001';
          OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
          RETURN FALSE;
      END;
      L_USER_ID := GLOBAL.USER_ID;
      L_ACC_HAND(3).MODULE := 'CG';
      L_ACC_HAND(3).MIS_HEAD := L_MIS_HEAD;
      L_ACC_HAND(3).AVLDAYS := 0;
      L_ACC_HAND(3).TRN_REF_NO := P_ENTRY_REC.REFERENCE_NO;
      L_ACC_HAND(3).EVENT_SR_NO := 1;
      L_ACC_HAND(3).EVENT := 'INIT';
    
      L_ACC_HAND(3).TRN_DT := GLOBAL.APPLICATION_DATE;
      L_ACC_HAND(3).VALUE_DT := P_ENTRY_REC.VAL_DATE_CUST;
    
      L_ACC_HAND(3).TXN_INIT_DATE := P_ENTRY_REC.TXN_DATE;
    
      DEBUG.PR_DEBUG('CG',
                     'p_Entry_Rec.Reference_No-->' ||
                     P_ENTRY_REC.REFERENCE_NO);
      L_ACC_HAND(3).INSTRUMENT_CODE := P_ENTRY_REC.REFERENCE_NO;
      DEBUG.PR_DEBUG('CG',
                     'l_Acc_Hand(3) .Instrument_Code-->' || L_ACC_HAND(3)
                     .INSTRUMENT_CODE);
      L_ACC_HAND(3).RELATED_CUSTOMER := P_ENTRY_REC.REM_CUST;
      L_ACC_HAND(3).BATCH_NO := P_ENTRY_REC.BATCH_NO;
      L_ACC_HAND(3).CURR_NO := NULL;
      L_ACC_HAND(3).USER_ID := L_USER_ID;
      L_ACC_HAND(3).BANK_CODE := P_ENTRY_REC.BANK_CODE;
      L_ACC_HAND(3).TRN_CODE := L_BRANCH_PARAM.ADJ_TRN_CODE;
      L_ACC_HAND(3).AMOUNT_TAG := 'ADJ_AMT';
      L_ACC_HAND(3).NETTING_IND := 'N';
      L_ACC_HAND(3).EXTERNAL_REF_NO := P_ENTRY_REC.XREF;
      L_ACC_HAND(3).AC_CCY := P_ENTRY_REC.INSTRUMENT_CCY;
      L_ACC_HAND(3).AC_BRANCH := PBRANCH;
      IF NVL(L_ADJREC.OLD_INSTR_AMT, 0) > NVL(L_ADJREC.INSTRAMT, 0) THEN
        L_ACC_HAND(3).DRCR_IND := 'D';
        L_DIFF := NULL;
        L_DIFF := NVL(L_ADJREC.OLD_INSTR_AMT, 0) -
                  NVL(L_ADJREC.INSTRAMT, 0);
      
        IF L_DIFF < NVL(L_BRANCH_PARAM.ADJ_ENTRY, 0) THEN
          L_ACC_HAND(3).AC_NO := NVL(L_BRANCH_PARAM.ADJ_EXPENSE_GL,
                                     P_CHG_ROW.COD_TXN_ACCOUNT);
        ELSIF L_DIFF >= NVL(L_BRANCH_PARAM.ADJ_ENTRY, 0) THEN
          L_ACC_HAND(3).AC_NO := NVL(L_BRANCH_PARAM.ADJ_RECEIVABLE_GL,
                                     P_CHG_ROW.COD_TXN_ACCOUNT);
        END IF;
      
      ELSIF NVL(L_ADJREC.INSTRAMT, 0) > NVL(L_ADJREC.OLD_INSTR_AMT, 0) THEN
        L_ACC_HAND(3).DRCR_IND := 'C';
        L_DIFF := NULL;
        L_DIFF := NVL(L_ADJREC.INSTRAMT, 0) -
                  NVL(L_ADJREC.OLD_INSTR_AMT, 0);
        IF L_DIFF < NVL(L_BRANCH_PARAM.ADJ_ENTRY, 0) THEN
          L_ACC_HAND(3).AC_NO := NVL(L_BRANCH_PARAM.ADJ_INCOME_GL,
                                     P_CHG_ROW.COD_TXN_ACCOUNT);
        ELSIF L_DIFF >= NVL(L_BRANCH_PARAM.ADJ_ENTRY, 0) THEN
          L_ACC_HAND(3).AC_NO := NVL(L_BRANCH_PARAM.ADJ_PAYABLE_GL,
                                     P_CHG_ROW.COD_TXN_ACCOUNT);
        END IF;
      END IF;
      DEBUG.PR_DEBUG('CG',
                     'l_Acc_Hand(4) .Instrument_Code-->' || L_ACC_HAND(3)
                     .INSTRUMENT_CODE);
      IF P_ENTRY_REC.INSTRUMENT_CCY = GLOBAL.LCY THEN
        L_ACC_HAND(3).LCY_AMOUNT := L_DIFF;
        L_ACC_HAND(3).FCY_AMOUNT := NULL;
        L_ACC_HAND(3).EXCH_RATE := NULL;
      ELSE
        L_ACC_HAND(3).FCY_AMOUNT := L_DIFF;
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(PBRANCH,
                                      P_ENTRY_REC.ACC_CCY,
                                      GLOBAL.LCY
                                      
                                     ,
                                      NVL(G_RATE_TYPE_PREFERRED, 'STANDARD')
                                      
                                     ,
                                      NVL(G_RATE_CODE_PREFERRED, 'M')
                                      
                                     ,
                                      L_DIFF,
                                      'Y',
                                      L_ACC_HAND(3).LCY_AMOUNT,
                                      L_ACC_HAND(3).EXCH_RATE,
                                      L_ERRCODE) THEN
          DEBUG.PR_DEBUG('CG', 'Error while computing LCY');
          P_ERR_CODE := L_ERRCODE;
          RETURN FALSE;
        END IF;
      END IF;
      DEBUG.PR_DEBUG('CG', 'After building handoff 3 ');
    END IF;
  
    IF (P_ENTRY_REC.INSTRUMENT_CCY <> P_ENTRY_REC.ACC_CCY) AND
       (P_ENTRY_REC.INSTRUMENT_CCY <> GLOBAL.LCY AND
       P_ENTRY_REC.ACC_CCY <> GLOBAL.LCY) THEN
      IF L_ADJREC.ADJUST_AMT_FLAG = 'Y' THEN
        L_LCY_AVG := (L_ACC_HAND(1).LCY_AMOUNT + L_ACC_HAND(2).LCY_AMOUNT + L_ACC_HAND(3)
                     .LCY_AMOUNT) / 3;
      ELSE
        L_LCY_AVG := (L_ACC_HAND(1).LCY_AMOUNT + L_ACC_HAND(2).LCY_AMOUNT) / 2;
      END IF;
      L_ACC_HAND(1).LCY_AMOUNT := L_LCY_AVG;
      L_ACC_HAND(2).LCY_AMOUNT := L_LCY_AVG;
      IF L_ADJREC.ADJUST_AMT_FLAG = 'Y' THEN
        L_ACC_HAND(3).LCY_AMOUNT := L_LCY_AVG;
      END IF;
      IF NOT CYPKSS.FN_AMT_TO_RATE(P_ENTRY_REC.ACC_CCY,
                                   GLOBAL.LCY,
                                   P_ENTRY_REC.ACC_CCY_AMT,
                                   L_LCY_AVG,
                                   L_RATE1) THEN
        DEBUG.PR_DEBUG('CG', 'Failed to get the exch rate for lcy avg...');
        RETURN FALSE;
      END IF;
      IF NOT CYPKSS.FN_AMT_TO_RATE(P_ENTRY_REC.INSTRUMENT_CCY,
                                   GLOBAL.LCY,
                                   P_ENTRY_REC.INSTRUMENT_AMT,
                                   L_LCY_AVG,
                                   L_RATE2) THEN
        DEBUG.PR_DEBUG('CG', 'Failed to get the exch rate for lcy avg....');
        RETURN FALSE;
      END IF;
      L_ACC_HAND(1).EXCH_RATE := L_RATE1;
      L_ACC_HAND(2).EXCH_RATE := L_RATE2;
      IF L_ADJREC.ADJUST_AMT_FLAG = 'Y' THEN
        L_ACC_HAND(3).EXCH_RATE := L_RATE2;
      END IF;
    END IF;
  
    L_ACTION := 'U';
  
    IF P_CONSOL_REF_NO IS NOT NULL THEN
      L_ACC_HAND.DELETE;
    END IF;
  
    IF NOT FN_CHG_PROC(PBRANCH,
                       P_ENTRY_REC,
                       P_CHG_ROW,
                       P_ERR_CODE,
                       P_ERR_PARAM,
                       L_ACC_HAND) THEN
      DEBUG.PR_DEBUG('CG', 'Failed in Chg Processing');
      RETURN FALSE;
    END IF;
    IF P_CHG_ROW.COD_NET_CHARGES = 'Y' THEN
      CSPKSS_ARC.PR_NET_CHARGES(L_ACC_HAND,
                                P_CHG_ROW.CHG_FROM,
                                P_CHG_ROW.DR_ACC,
                                'TXN_AMOUNT',
                                'OFS_AMOUNT',
                                L_RET);
      IF L_RET = -1 THEN
        DEBUG.PR_DEBUG('RT', 'Netting failed');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF L_ACC_HAND.COUNT > 0 THEN
      FOR ZED IN 1 .. L_ACC_HAND.COUNT LOOP
        DBG('Printing the value of acc_ccy for value ' || ZED || ' as' || L_ACC_HAND(ZED)
            .AC_CCY);
      END LOOP;
    END IF;
  
    IF L_ACC_HAND.COUNT > 0 THEN
    
      IF NOT ACPKSS.FN_ACHANDOFF(P_ENTRY_REC.REFERENCE_NO,
                                 1,
                                 GLOBAL.APPLICATION_DATE,
                                 L_ACC_HAND,
                                 L_ACTION,
                                 'N',
                                 'Y',
                                 L_USER_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAM) THEN
        DEBUG.PR_DEBUG('CG', 'Failed in Call to achandoff ...');
        DEBUG.PR_DEBUG('CG', 'Errors returned are...' || P_ERR_CODE);
        RETURN FALSE;
      END IF;
      DEBUG.PR_DEBUG('CG', 'Accounting  Successful');
    
      DEBUG.PR_DEBUG('CG', 'Going To Call fn_mt110_recon');
    
      IF NOT FN_MT110_RECON(L_ACC_HAND, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('FAILED IN fn_mt110_recon' || SQLERRM);
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
      END IF;
    
      L_ACC_HAND.DELETE;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'Exception in fn_pass_ic_acct_entries ...' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_PASS_IC_ACCT_ENTRIES;

  FUNCTION FN_REFERRAL_QUEUE(PBRANCH         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                             PCUSTNO         IN STTMS_CUST_ACCOUNT.CUST_NO%TYPE,
                             PACCOUNT        IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                             PREFNO          IN CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE,
                             PLCYAMT         IN CSTBS_CLEARING_MASTER.ACC_CCY_AMT%TYPE,
                             PEVENTNO        IN NUMBER,
                             PVALUEDATE      IN DATE,
                             PTEMPFLAG       IN BOOLEAN,
                             P_CONSOL_REF_NO IN VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN AS
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside fn_referral_queue');
    DEBUG.PR_DEBUG('CG', 'pBranch ' || PBRANCH);
    DEBUG.PR_DEBUG('CG', 'each_row.DR_ACCOUNT ' || PACCOUNT);
    DEBUG.PR_DEBUG('CG', 'each_row.CONTRACT_REF_NO ' || PREFNO);
    DEBUG.PR_DEBUG('CG', 'each_row.DR_AMOUNT ' || PLCYAMT);
    G_REFERRAL_QUEUE := 'Y';
    IF PTEMPFLAG = TRUE THEN
    
      INSERT INTO STTBS_REFERRAL_QUEUE
        (BRANCH_CODE,
         MODULE_CODE,
         CUST_AC_NO,
         POSTING_DATE,
         CONTRACT_REF_NO,
         VERSION_NO,
         EVENT_SEQ_NO,
         REFERRAL_DESCRIPTION,
         DR_AMOUNT,
         ENTRIES_STATUS,
         PAY_FLG,
         UNPAY_FLG,
         WAIVE_CHARGES,
         REASON,
         CUST_NO,
         CONSOL_REF_NO)
      VALUES
        (PBRANCH,
         'CG',
         PACCOUNT,
         SIPKSS_BATCH.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE),
         PREFNO,
         NULL,
         PEVENTNO,
         NULL,
         PLCYAMT,
         'Y',
         'N',
         'N',
         'N',
         '',
         PCUSTNO,
         P_CONSOL_REF_NO);
    
    ELSE
    
      INSERT INTO PCTBS_REFERRAL_QUEUE_TEMP
        (
         
         BRANCH_CODE,
         MODULE_CODE,
         CUST_AC_NO,
         POSTING_DATE,
         CONTRACT_REF_NO,
         VERSION_NO,
         EVENT_SEQ_NO,
         REFERRAL_DESCRIPTION,
         DR_AMOUNT,
         ENTRIES_STATUS,
         PAY_FLG,
         UNPAY_FLG,
         WAIVE_CHARGES,
         REASON,
         CUST_NO)
      VALUES
        (PBRANCH,
         'CG',
         PACCOUNT,
         SIPKSS_BATCH.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE),
         PREFNO,
         NULL,
         PEVENTNO,
         NULL,
         PLCYAMT,
         'Y',
         'N',
         'N',
         'N',
         '',
         PCUSTNO
         
         );
    
    END IF;
    DEBUG.PR_DEBUG('CG', 'after insert fn_referral_queue');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'when others Exception in fn_referral_queue');
      DEBUG.PR_DEBUG('CG', 'ORACLE ERROR - ' || SQLERRM);
      RETURN FALSE;
  END FN_REFERRAL_QUEUE;

  FUNCTION FN_TEMP_TO_QUEUE(PCUSTNO IN STTMS_CUST_ACCOUNT.CUST_NO%TYPE
                            
                            ) RETURN BOOLEAN AS
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside fn_temp_to_queue');
    DEBUG.PR_DEBUG('CG',
                   ' inserting into ref queue from temp for customer' ||
                   PCUSTNO);
  
    INSERT INTO STTBS_REFERRAL_QUEUE
      (BRANCH_CODE,
       MODULE_CODE,
       CUST_AC_NO,
       POSTING_DATE,
       CONTRACT_REF_NO,
       VERSION_NO,
       EVENT_SEQ_NO,
       REFERRAL_DESCRIPTION,
       DR_AMOUNT,
       ENTRIES_STATUS,
       PAY_FLG,
       UNPAY_FLG,
       WAIVE_CHARGES,
       REASON,
       CUST_NO)
      SELECT BRANCH_CODE,
             MODULE_CODE,
             CUST_AC_NO,
             POSTING_DATE,
             CONTRACT_REF_NO,
             VERSION_NO,
             EVENT_SEQ_NO,
             REFERRAL_DESCRIPTION,
             DR_AMOUNT,
             ENTRIES_STATUS,
             PAY_FLG,
             UNPAY_FLG,
             WAIVE_CHARGES,
             REASON,
             CUST_NO
      
        FROM PCTBS_REFERRAL_QUEUE_TEMP
       WHERE CUST_NO = PCUSTNO;
  
    DEBUG.PR_DEBUG('CG', 'after insert in PCTBS_REFERRAL_QUEUE_TEMP');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'when others Exception in fn_temp_to_queue');
      DEBUG.PR_DEBUG('CG', 'ORACLE ERROR - ' || SQLERRM);
      RETURN FALSE;
  END FN_TEMP_TO_QUEUE;

  FUNCTION FN_PASS_OC_ACCT_ENTRIES(PBRANCH       IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                                   P_ENTRY_REC   IN OUT CSTBS_CLEARING_MASTER%ROWTYPE,
                                   P_CHG_ROW     IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                                   P_ERR_CODE    OUT VARCHAR2,
                                   P_ERR_PARAM   OUT VARCHAR2,
                                   P_ONLINE_AUTH IN CHAR) RETURN BOOLEAN IS
    L_ACC_HAND   ACPKSS.TBL_ACHOFF;
    L_ACTION     CHAR(1);
    L_USER_ID    ACTBS_DAILY_LOG.USER_ID%TYPE;
    L_ERRCODE    VARCHAR2(1000);
    L_ERRORPARAM VARCHAR2(10000);
    L_OVD_CD     VARCHAR2(2000);
    L_OVD_PARAM  VARCHAR2(2000);
    L_LCY_AVG    ACTBS_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_RATE1      ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE2      ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
  
    L_RET         NUMBER;
    L_EVENT_CODE  VARCHAR2(100) := 'INIT';
    L_EVENT_SEQ   NUMBER := 1;
    L_NEG_AMT     NUMBER;
    L_TXN_AC_NO   DETBS_RTL_TELLER.TXN_ACC%TYPE;
    L_TXN_BRN     DETBS_RTL_TELLER.TXN_BRANCH%TYPE;
    L_MODULE_CODE CSTBS_CLEARING_MASTER.MODULE_CODE%TYPE;
  
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_CALL_FUNC_ID          NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside fn_pass_oc_acct_entries..');
    L_MODULE_CODE := 'CG';
  
    DBG('fn_pass_oc_acct_entries ==> Setting Account Number and Branch Code for ARC Pick up');
    IF CSPKSS_CLG_SERVICES.G_CLG_ACCOUNT_ARC IS NOT NULL THEN
      DBG('Account Number NOT NULL ' ||
          CSPKSS_CLG_SERVICES.G_CLG_ACCOUNT_ARC);
      L_TXN_AC_NO := CSPKSS_CLG_SERVICES.G_CLG_ACCOUNT_ARC;
    ELSE
      L_TXN_AC_NO := NULL;
    END IF;
    IF CSPKSS_CLG_SERVICES.G_CLG_BRANCH_ARC IS NOT NULL THEN
      DBG('Branch is NOT NULL ' || CSPKSS_CLG_SERVICES.G_CLG_BRANCH_ARC);
      L_TXN_BRN := CSPKSS_CLG_SERVICES.G_CLG_BRANCH_ARC;
    END IF;
    DBG('Account Number ' || L_TXN_AC_NO);
    DBG('Branch ' || L_TXN_BRN);
  
    IF NOT CSPKSS_ARC.FN_CHARGE_PICKUP(P_ENTRY_REC.TXN_BRANCH,
                                       P_ENTRY_REC.PRODUCT_CODE,
                                       'P',
                                       P_ENTRY_REC.TXN_BRANCH,
                                       P_ENTRY_REC.INSTRUMENT_CCY,
                                       P_ENTRY_REC.SECTOR_CODE,
                                       P_ENTRY_REC.INSTRUMENT_CCY,
                                       P_ENTRY_REC.INSTRUMENT_AMT,
                                       'STANDARD',
                                       'M',
                                       NULL,
                                       P_ENTRY_REC.BEN_CUST,
                                       P_CHG_ROW,
                                       P_ERR_CODE,
                                       P_ERR_PARAM,
                                       L_TXN_AC_NO,
                                       L_TXN_BRN) THEN
      DEBUG.PR_DEBUG('CG', 'Error in ARC pick up');
      RETURN FALSE;
    END IF;
  
    IF P_ENTRY_REC.DISPATCH_STATUS = 'D' THEN
      L_EVENT_CODE := 'LIQD';
      L_EVENT_SEQ  := 4;
    END IF;
  
    IF ICPKS_BOD.G_MANUAL_ROLL THEN
    
      L_EVENT_CODE  := 'MROL';
      L_MODULE_CODE := 'TD';
    END IF;
  
    G_EVENT_SEQ           := L_EVENT_SEQ;
    P_ENTRY_REC.END_POINT := P_CHG_ROW.END_POINT;
  
    L_USER_ID  := GLOBAL.USER_ID;
    L_ACC_HAND := ACPKS.EMPTY_HOFF;
  
    L_ACC_HAND(1).MODULE := L_MODULE_CODE;
    L_ACC_HAND(1).MIS_HEAD := P_CHG_ROW.COD_MIS_HEAD;
    L_ACC_HAND(1).AVLDAYS := 0;
    L_ACC_HAND(1).TRN_REF_NO := P_ENTRY_REC.REFERENCE_NO;
  
    L_ACC_HAND(1).EVENT_SR_NO := L_EVENT_SEQ;
    L_ACC_HAND(1).EVENT := L_EVENT_CODE;
  
    L_ACC_HAND(1).TRN_DT := P_ENTRY_REC.TXN_DATE;
    L_ACC_HAND(1).VALUE_DT := P_ENTRY_REC.VAL_DATE_CUST;
  
    L_ACC_HAND(1).TXN_INIT_DATE := P_ENTRY_REC.TXN_DATE;
  
    DEBUG.PR_DEBUG('CG',
                   'p_Entry_Rec.Instrument_No_1(3)-->' ||
                   P_ENTRY_REC.INSTRUMENT_NO_1);
    L_ACC_HAND(1).INSTRUMENT_CODE := P_ENTRY_REC.INSTRUMENT_NO_1;
    DEBUG.PR_DEBUG('CG',
                   'l_Acc_Hand(1) .Instrument_Code_OC-->' || L_ACC_HAND(1)
                   .INSTRUMENT_CODE);
    L_ACC_HAND(1).RELATED_CUSTOMER := P_ENTRY_REC.BEN_CUST;
    L_ACC_HAND(1).BATCH_NO := P_ENTRY_REC.BATCH_NO;
    L_ACC_HAND(1).CURR_NO := NULL;
    L_ACC_HAND(1).USER_ID := L_USER_ID;
    L_ACC_HAND(1).BANK_CODE := P_ENTRY_REC.BANK_CODE;
    L_ACC_HAND(1).DRCR_IND := 'C';
    L_ACC_HAND(1).TRN_CODE := P_CHG_ROW.COD_MAIN_TXN_CODE;
    L_ACC_HAND(1).AMOUNT_TAG := 'TXN_AMOUNT';
    L_ACC_HAND(1).NETTING_IND := 'N';
    L_ACC_HAND(1).EXTERNAL_REF_NO := P_ENTRY_REC.XREF;
  
    DEBUG.PR_DEBUG('CG',
                   'Accounts involved 1. Beneficiary ' ||
                   P_ENTRY_REC.BEN_ACCOUNT);
    DEBUG.PR_DEBUG('CG', '2. Remitter ' || P_ENTRY_REC.REM_ACCOUNT);
    DEBUG.PR_DEBUG('CG', '3. Txn in ARC ' || P_CHG_ROW.COD_TXN_ACCOUNT);
    DEBUG.PR_DEBUG('CG', '4. Offset in ARC ' || P_CHG_ROW.COD_OFFSET_ACC);
  
    IF P_ENTRY_REC.BEN_ACCOUNT IS NOT NULL THEN
      L_ACC_HAND(1).AC_NO := P_ENTRY_REC.BEN_ACCOUNT;
    ELSE
      L_ACC_HAND(1).AC_NO := P_CHG_ROW.COD_TXN_ACCOUNT;
    END IF;
  
    L_ACC_HAND(1).AC_CCY := P_ENTRY_REC.ACC_CCY;
    L_ACC_HAND(1).AC_BRANCH := P_ENTRY_REC.ACC_BRANCH;
  
    IF (P_ENTRY_REC.ACC_CCY = GLOBAL.LCY) THEN
      DBG('Acc ccy matches LCY');
      L_ACC_HAND(1).LCY_AMOUNT := P_ENTRY_REC.ACC_CCY_AMT;
      L_ACC_HAND(1).FCY_AMOUNT := NULL;
      L_ACC_HAND(1).EXCH_RATE := NULL;
    ELSE
      DBG('Acc ccy diff from LCY');
      L_ACC_HAND(1).FCY_AMOUNT := P_ENTRY_REC.ACC_CCY_AMT;
      IF P_ENTRY_REC.INSTRUMENT_CCY = GLOBAL.LCY THEN
        DBG(' Instrument Ccy same as LCY');
        L_ACC_HAND(1).LCY_AMOUNT := P_ENTRY_REC.INSTRUMENT_AMT;
        L_ACC_HAND(1).EXCH_RATE := P_ENTRY_REC.EXCH_RATE;
      ELSE
        DBG('Instrument ccy not LCY - Conversion reqd');
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(PBRANCH,
                                      P_ENTRY_REC.ACC_CCY,
                                      GLOBAL.LCY
                                      
                                     ,
                                      --NVL(G_RATE_TYPE_PREFERRED, 'STANDARD') --Commercial Exchange Rate Changes Commented
                                      'STANDARD' --Commercial Exchange Rate Changes added
                                     ,
                                      --NVL(G_RATE_CODE_PREFERRED, 'M')  --Commercial Exchange Rate Changes Commented
                                      'M' --Commercial Exchange Rate Changes added
                                      
                                     ,
                                      P_ENTRY_REC.ACC_CCY_AMT,
                                      'Y',
                                      L_ACC_HAND             (1).LCY_AMOUNT,
                                      L_ACC_HAND             (1).EXCH_RATE,
                                      L_ERRCODE) THEN
          DEBUG.PR_DEBUG('CG', 'Error while computing LCY');
          P_ERR_CODE := L_ERRCODE;
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    DBG('Now building l_acc_hand(2)...');
  
    L_ACC_HAND(2).MODULE := L_MODULE_CODE;
    L_ACC_HAND(2).MIS_HEAD := P_CHG_ROW.COD_MIS_HEAD;
    L_ACC_HAND(2).AVLDAYS := 0;
    L_ACC_HAND(2).TRN_REF_NO := P_ENTRY_REC.REFERENCE_NO;
  
    L_ACC_HAND(2).EVENT_SR_NO := L_EVENT_SEQ;
    L_ACC_HAND(2).EVENT := L_EVENT_CODE;
  
    L_ACC_HAND(2).TRN_DT := P_ENTRY_REC.TXN_DATE;
    L_ACC_HAND(2).VALUE_DT := P_ENTRY_REC.VAL_DATE_BNK;
  
    L_ACC_HAND(2).TXN_INIT_DATE := P_ENTRY_REC.TXN_DATE;
  
    L_ACC_HAND(2).INSTRUMENT_CODE := P_ENTRY_REC.INSTRUMENT_NO_1;
  
    L_ACC_HAND(2).RELATED_CUSTOMER := P_ENTRY_REC.BEN_CUST;
  
    L_ACC_HAND(2).BATCH_NO := P_ENTRY_REC.BATCH_NO;
    L_ACC_HAND(2).CURR_NO := NULL;
    L_ACC_HAND(2).USER_ID := GLOBAL.USER_ID;
    L_ACC_HAND(2).BANK_CODE := P_ENTRY_REC.BANK_CODE;
    L_ACC_HAND(2).DRCR_IND := 'D';
    L_ACC_HAND(2).TRN_CODE := P_CHG_ROW.COD_OFFSET_TXN_CODE;
    L_ACC_HAND(2).AMOUNT_TAG := 'OFS_AMOUNT';
    L_ACC_HAND(2).NETTING_IND := 'N';
    L_ACC_HAND(2).EXTERNAL_REF_NO := P_ENTRY_REC.XREF;
  
    L_ACC_HAND(2).AC_NO := P_CHG_ROW.COD_OFFSET_ACC;
    IF P_CHG_ROW.COD_OFFSET_BRN = '*.*' THEN
      PR_GET_BRN_DET(P_ENTRY_REC.TXN_BRANCH);
      L_ACC_HAND(2).AC_BRANCH := NVL(GLOBAL.CURRENT_BRANCH,
                                     PKG_BRN_REC.CLG_BRN);
    ELSE
      L_ACC_HAND(2).AC_BRANCH := P_CHG_ROW.COD_OFFSET_BRN;
    END IF;
  
    L_ACC_HAND(2).AC_CCY := P_ENTRY_REC.INSTRUMENT_CCY;
  
    G_NSF_ACC     := P_ENTRY_REC.BEN_ACCOUNT;
    G_TXN_ACC     := L_ACC_HAND(2).AC_NO;
    G_TXN_ACC_BRN := L_ACC_HAND(2).AC_BRANCH;
    G_TXN_ACC_CCY := L_ACC_HAND(2).AC_CCY;
  
    IF (P_ENTRY_REC.INSTRUMENT_CCY = GLOBAL.LCY) THEN
      L_ACC_HAND(2).LCY_AMOUNT := P_ENTRY_REC.INSTRUMENT_AMT;
      L_ACC_HAND(2).FCY_AMOUNT := NULL;
      L_ACC_HAND(2).EXCH_RATE := NULL;
    ELSE
      L_ACC_HAND(2).FCY_AMOUNT := P_ENTRY_REC.INSTRUMENT_AMT;
      IF P_ENTRY_REC.ACC_CCY = GLOBAL.LCY THEN
        L_ACC_HAND(2).LCY_AMOUNT := P_ENTRY_REC.ACC_CCY_AMT;
        L_ACC_HAND(2).EXCH_RATE := P_ENTRY_REC.EXCH_RATE;
      ELSE
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(PBRANCH,
                                      P_ENTRY_REC.INSTRUMENT_CCY,
                                      GLOBAL.LCY
                                      
                                     ,
                                      --NVL(G_RATE_TYPE_PREFERRED, 'STANDARD') --Commercial Exchange Rate Changes commented
                                      'STANDARD' --Commercial Exchange Rate Changes added
                                      
                                     ,
                                      -- NVL(G_RATE_CODE_PREFERRED, 'M') --Commercial Exchange Rate Changes commented
                                      'M' --Commercial Exchange Rate Changes added
                                      
                                     ,
                                      P_ENTRY_REC.INSTRUMENT_AMT,
                                      'Y',
                                      L_ACC_HAND                (2).LCY_AMOUNT,
                                      L_ACC_HAND                (2).EXCH_RATE,
                                      L_ERRCODE) THEN
          DEBUG.PR_DEBUG('CG', 'Error while computing LCY');
          P_ERR_CODE := L_ERRCODE;
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    IF GLOBAL.BRANCH_STATUS = 'N' THEN
      L_ACTION := 'U';
    ELSE
      L_ACTION := 'B';
    END IF;
  
    IF (P_ENTRY_REC.INSTRUMENT_CCY <> P_ENTRY_REC.ACC_CCY) AND
       (P_ENTRY_REC.INSTRUMENT_CCY <> GLOBAL.LCY AND
       P_ENTRY_REC.ACC_CCY <> GLOBAL.LCY) THEN
      DBG('3 currency case');
      L_ACC_HAND(1).LCY_AMOUNT := L_ACC_HAND(2).LCY_AMOUNT;
    
      DBG('p_entry_rec.Acc_Ccy_Amt is ' || P_ENTRY_REC.ACC_CCY_AMT);
      DBG('l_acc_hand(1).fcy_amount is' || L_ACC_HAND(1).FCY_AMOUNT);
      IF P_ENTRY_REC.ACC_CCY_AMT IS NOT NULL AND
         NVL(GWPKS_UTIL.PKG_FUNC, '***') IN ('6501') THEN
        L_ACC_HAND(1).FCY_AMOUNT := P_ENTRY_REC.ACC_CCY_AMT;
        IF NOT
            CYPKSS.FN_AMT_TO_RATE(P_ENTRY_REC.ACC_CCY,
                                  GLOBAL.LCY,
                                  P_ENTRY_REC.ACC_CCY_AMT,
                                  L_ACC_HAND             (1).LCY_AMOUNT,
                                  L_ACC_HAND             (1).EXCH_RATE) THEN
          DEBUG.PR_DEBUG('CG',
                         'Failed to get the exch rate for lcy avg....');
          RETURN FALSE;
        END IF;
      
        IF NOT
            CYPKSS.FN_AMT_TO_RATE(P_ENTRY_REC.INSTRUMENT_CCY,
                                  GLOBAL.LCY,
                                  P_ENTRY_REC.INSTRUMENT_AMT,
                                  L_ACC_HAND                (2).LCY_AMOUNT,
                                  L_ACC_HAND                (2).EXCH_RATE) THEN
          DEBUG.PR_DEBUG('CG',
                         'Failed to get the exch rate for lcy avg....');
          RETURN FALSE;
        END IF;
      
        DBG('l_acc_hand(1).fcy_amount is' || L_ACC_HAND(1).FCY_AMOUNT);
      ELSE
      
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(PBRANCH,
                                      GLOBAL.LCY,
                                      P_ENTRY_REC.ACC_CCY,
                                      NVL(G_RATE_TYPE_PREFERRED, 'STANDARD'),
                                      NVL(G_RATE_CODE_PREFERRED, 'M'),
                                      L_ACC_HAND(2).LCY_AMOUNT,
                                      'Y',
                                      L_ACC_HAND(1).FCY_AMOUNT,
                                      L_ACC_HAND(1).EXCH_RATE,
                                      L_ERRCODE) THEN
          DEBUG.PR_DEBUG('CG', 'Error while computing LCY');
          P_ERR_CODE := L_ERRCODE;
          RETURN FALSE;
        END IF;
        P_ENTRY_REC.ACC_CCY_AMT := L_ACC_HAND(1).FCY_AMOUNT;
        DBG('l_acc_hand(1).fcy_amount is' || L_ACC_HAND(1).FCY_AMOUNT);
      END IF;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('calling cspks_clg_serv_cluster.fn_pass_oc_acct_entries');
      L_CALL_FUNC_ID    := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          CSPKS_CLG_SERV_CLUSTER.FN_PASS_OC_ACCT_ENTRIES(PBRANCH,
                                                         P_ENTRY_REC,
                                                         P_CHG_ROW,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAM,
                                                         P_ONLINE_AUTH,
                                                         L_ACC_HAND,
                                                         L_CALL_FUNC_ID,
                                                         L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('CG', 'Failed in fn_pass_oc_acct_entries');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT FN_CHG_PROC(PBRANCH,
                       P_ENTRY_REC,
                       P_CHG_ROW,
                       P_ERR_CODE,
                       P_ERR_PARAM,
                       L_ACC_HAND) THEN
      DEBUG.PR_DEBUG('CG', 'Failed in Chg Processing');
      RETURN FALSE;
    END IF;
    IF P_CHG_ROW.COD_NET_CHARGES = 'Y' THEN
      CSPKSS_ARC.PR_NET_CHARGES(L_ACC_HAND,
                                P_CHG_ROW.CHG_FROM,
                                P_CHG_ROW.DR_ACC,
                                'TXN_AMOUNT',
                                'OFS_AMOUNT',
                                L_RET);
      IF L_RET = -1 THEN
        DEBUG.PR_DEBUG('RT', 'Netting failed');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('negotiated_rate ' || P_ENTRY_REC.NEGOTIATED_RATE || 'exch_rate' ||
        P_ENTRY_REC.EXCH_RATE || 'profit_reval_gl' ||
        P_CHG_ROW.PROFIT_REVAL_GL || 'loss_reval_gl' ||
        P_CHG_ROW.LOSS_REVAL_GL);
    IF P_ENTRY_REC.NEGOTIATED_RATE IS NOT NULL AND
       P_ENTRY_REC.EXCH_RATE <> 1 AND P_CHG_ROW.PROFIT_REVAL_GL IS NOT NULL AND
       P_CHG_ROW.LOSS_REVAL_GL IS NOT NULL THEN
      DBG('acc_ccy ' || P_ENTRY_REC.ACC_CCY || 'instrument_ccy' ||
          P_ENTRY_REC.INSTRUMENT_CCY || 'ACC_CCY_AMT' ||
          P_ENTRY_REC.ACC_CCY_AMT || 'instrument_amount' ||
          P_ENTRY_REC.INSTRUMENT_AMT);
      IF NOT CYPKS.FN_AMT1_TO_AMT2(P_ENTRY_REC.ACC_CCY,
                                   P_ENTRY_REC.INSTRUMENT_CCY,
                                   P_ENTRY_REC.ACC_CCY_AMT,
                                   P_ENTRY_REC.NEGOTIATED_RATE,
                                   'Y',
                                   L_NEG_AMT,
                                   P_ERR_CODE) THEN
        RETURN FALSE;
      END IF;
      DBG('l_neg_amt ' || L_NEG_AMT);
      PR_BUILD_XRATE_P_AND_L_ENTRIES(L_ACC_HAND,
                                     P_CHG_ROW,
                                     L_NEG_AMT,
                                     P_ENTRY_REC,
                                     P_ERR_CODE,
                                     L_RET);
      IF L_RET = -1 THEN
        DBG('profit loss entry failed');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF L_ACC_HAND.COUNT > 0 THEN
    
      BEGIN
        DBG('pr_print_acctng_table is cmd in begin.....');
        PR_PRINT_ACCTNG_TABLE(L_ACC_HAND);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In OTHERS with line tracking  ::::: ' ||
              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      END;
    
      IF NOT ACPKSS.FN_ACHANDOFF(P_ENTRY_REC.REFERENCE_NO,
                                 1,
                                 GLOBAL.APPLICATION_DATE,
                                 L_ACC_HAND,
                                 L_ACTION,
                                 'N',
                                 'Y',
                                 L_USER_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAM) THEN
        DEBUG.PR_DEBUG('CG', 'Failed in Call to achandoff ...');
        RETURN FALSE;
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('calling cspks_clg_serv_cluster.fn_pass_oc_acct_entries');
        L_CALL_FUNC_ID    := 2;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT
            CSPKS_CLG_SERV_CLUSTER.FN_PASS_OC_ACCT_ENTRIES(PBRANCH,
                                                           P_ENTRY_REC,
                                                           P_CHG_ROW,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM,
                                                           P_ONLINE_AUTH,
                                                           L_ACC_HAND,
                                                           L_CALL_FUNC_ID,
                                                           L_TB_CLUSTER_DATA) THEN
          DEBUG.PR_DEBUG('CG', 'Failed in fn_pass_oc_acct_entries');
          RETURN FALSE;
        END IF;
      END IF;
    
      DEBUG.PR_DEBUG('CG', 'Accounting  Successful');
      L_ACC_HAND.DELETE;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'Exception in fn_pass_oc_acct_entries ...' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_PASS_OC_ACCT_ENTRIES;

  FUNCTION FN_CHG_PROC(PBRANCH     IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                       P_ENTRY_REC IN OUT CSTBS_CLEARING_MASTER%ROWTYPE,
                       P_CHG_ROW   IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                       P_ERR_CODE  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                       P_ERRPARAM  IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
    L_ACC_HAND ACPKSS.TBL_ACHOFF;
  BEGIN
  
    IF NOT FN_ARC_PICKUP(PBRANCH,
                         P_ENTRY_REC,
                         P_CHG_ROW,
                         P_ERR_CODE,
                         P_ERRPARAM) THEN
      DEBUG.PR_DEBUG('CG',
                     'Failed in arc pick up , from overloaded fn_ch_proc');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_CHG_PROC(PBRANCH,
                       P_ENTRY_REC,
                       P_CHG_ROW,
                       P_ERR_CODE,
                       P_ERRPARAM,
                       L_ACC_HAND) THEN
      L_ACC_HAND.DELETE;
      RETURN FALSE;
    ELSE
      L_ACC_HAND.DELETE;
      RETURN TRUE;
    END IF;
  END FN_CHG_PROC;

  FUNCTION FN_CHG_PROC(PBRANCH     IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                       P_ENTRY_REC IN OUT CSTBS_CLEARING_MASTER%ROWTYPE,
                       P_CHG_ROW   IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                       P_ERR_CODE  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                       P_ERRPARAM  IN OUT ERTBS_MSGS.MESSAGE%TYPE,
                       P_ACC_HAND  IN OUT ACPKS.TBL_ACHOFF)
  
   RETURN BOOLEAN IS
    L_PROD_ACC_FLAG CHAR(1) := NULL;
    L_ACCOUNT_CLASS STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_PRODUCT_TYPE  CSTMS_PRODUCT.PRODUCT_TYPE%TYPE;
  
    L_ACTION            CHAR(1);
    L_USER_ID           ACTBS_DAILY_LOG.USER_ID%TYPE;
    L_ERRCODE           ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERRPARAM          ERTBS_MSGS.MESSAGE%TYPE;
    L_ACC_CCY_CHG       NUMBER(22, 3);
    L_ACC_CHG_EXCH_RATE ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
  
    L_CURRPOS            NUMBER;
    L_CHG_TCY            NUMBER;
    L_TCY_CHG_EXCH_RATE  NUMBER;
    L_COD_CHG_CCY        VARCHAR2(3);
    L_COD_CHG_AMT        NUMBER;
    L_COD_RATE_CODE      IFTMS_ARC_MAINT.COD_RATE_CODE%TYPE;
    L_COD_RATE_CODE_TYPE IFTMS_ARC_MAINT.COD_RATE_CODE_TYPE%TYPE;
    L_CHG_ACY            NUMBER;
    L_ACY_CHG_EXCH_RATE  NUMBER;
    L_LCY                VARCHAR2(3);
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
  
    DBG('FN_CHG_PROC : ' || PKG_PROD_REC.PRODUCT_TYPE);
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
    
      DBG('cspks_clg_serv_cluster.FN_PRE_CHG_PROC ');
      IF NOT CSPKS_CLG_SERV_CLUSTER.FN_PRE_CHG_PROC(PBRANCH,
                                                    P_ENTRY_REC,
                                                    P_CHG_ROW,
                                                    P_ERR_CODE,
                                                    P_ERRPARAM,
                                                    P_ACC_HAND,
                                                    L_FN_CALL_ID,
                                                    L_TB_CLUSTER_DATA)
      
       THEN
        DBG('Failure has happened in cspks_clg_serv_cluster.FN_PRE_CHG_PROC');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      L_PROD_ACC_FLAG := 'P';
      L_ACCOUNT_CLASS := P_ENTRY_REC.PRODUCT_CODE;
      PR_GET_PROD(P_ENTRY_REC.PRODUCT_CODE);
      L_PRODUCT_TYPE := PKG_PROD_REC.PRODUCT_TYPE;
    
      IF (L_PRODUCT_TYPE IN ('IC', 'OC')) THEN
      
        L_USER_ID := GLOBAL.USER_ID;
        L_ACTION  := 'U';
        DEBUG.PR_DEBUG('CG', 'Chg is ' || P_CHG_ROW.COD_CHG_AMT);
        L_CURRPOS := P_ACC_HAND.COUNT;
        FOR I IN 1 .. 5 LOOP
        
          G_CHG_CCY_AMT   := NULL;
          G_CHG_LCY       := NULL;
          G_EXCH_RATE_LCY := NULL;
        
          IF NOT FN_FRAME_CHG_ENTRIES(PBRANCH,
                                      P_ENTRY_REC,
                                      P_CHG_ROW,
                                      P_ACC_HAND,
                                      I,
                                      L_PRODUCT_TYPE,
                                      P_ERR_CODE) THEN
            DEBUG.PR_DEBUG('CG',
                           'Error while building chg acctng entries ' ||
                           P_ERR_CODE);
            RETURN FALSE;
          END IF;
        
          DBG('l_currpos : ' || L_CURRPOS);
          L_LCY := GLOBAL.LCY;
          IF P_ACC_HAND.COUNT > L_CURRPOS THEN
            L_CURRPOS := P_ACC_HAND.COUNT;
          
            L_CHG_TCY           := NULL;
            L_TCY_CHG_EXCH_RATE := NULL;
            L_CHG_ACY           := NULL;
            L_ACY_CHG_EXCH_RATE := NULL;
          
            IF I = 1 THEN
              P_ENTRY_REC.CHG_CCY := P_ACC_HAND(L_CURRPOS).AC_CCY;
            
              P_ENTRY_REC.CHG_AMT          := G_CHG_CCY_AMT;
              P_ENTRY_REC.LCY_CHG_AMT      := G_CHG_LCY;
              P_ENTRY_REC.CHGCCY_LCY_XRATE := NVL(G_EXCH_RATE_LCY, 1);
            
              L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE;
              L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE;
              L_COD_CHG_CCY        := P_ENTRY_REC.CHG_CCY;
              L_COD_CHG_AMT        := P_ENTRY_REC.CHG_AMT;
              DBG('p_entry_rec.chg_ccy          : ' || P_ENTRY_REC.CHG_CCY);
              DBG('p_entry_rec.chg_amt          : ' || P_ENTRY_REC.CHG_AMT);
              DBG('p_entry_rec.lcy_chg_amt      : ' ||
                  P_ENTRY_REC.LCY_CHG_AMT);
              DBG('p_entry_rec.chgccy_lcy_xrate : ' ||
                  P_ENTRY_REC.CHGCCY_LCY_XRATE);
            
              IF P_ENTRY_REC.INSTRUMENT_CCY = L_LCY THEN
                L_CHG_TCY           := P_ENTRY_REC.LCY_CHG_AMT;
                L_TCY_CHG_EXCH_RATE := P_ENTRY_REC.CHGCCY_LCY_XRATE;
              ELSIF P_ENTRY_REC.INSTRUMENT_CCY = P_ENTRY_REC.CHG_CCY THEN
                L_CHG_TCY           := P_ENTRY_REC.CHG_AMT;
                L_TCY_CHG_EXCH_RATE := 1;
              END IF;
            
              IF P_ENTRY_REC.ACC_CCY = L_LCY THEN
                L_CHG_ACY           := P_ENTRY_REC.LCY_CHG_AMT;
                L_ACY_CHG_EXCH_RATE := P_ENTRY_REC.CHGCCY_LCY_XRATE;
              ELSIF P_ENTRY_REC.ACC_CCY = P_ENTRY_REC.CHG_CCY THEN
                L_CHG_ACY           := P_ENTRY_REC.CHG_AMT;
                L_ACY_CHG_EXCH_RATE := 1;
              END IF;
            
              P_ENTRY_REC.CHG_TYPE := P_CHG_ROW.COD_CHG_TYPE;
              P_ENTRY_REC.CHG_DESC := P_CHG_ROW.COD_CHG_DESC;
            
            ELSIF I = 2 THEN
              P_ENTRY_REC.CHG_CCY1 := P_ACC_HAND(L_CURRPOS).AC_CCY;
            
              P_ENTRY_REC.CHG_AMT1          := G_CHG_CCY_AMT;
              P_ENTRY_REC.LCY_CHG_AMT1      := G_CHG_LCY;
              P_ENTRY_REC.CHGCCY_LCY_XRATE1 := NVL(G_EXCH_RATE_LCY, 1);
            
              P_ENTRY_REC.CHG_TYPE1 := P_CHG_ROW.COD_CHG_TYPE1;
              P_ENTRY_REC.CHG_DESC1 := P_CHG_ROW.COD_CHG_DESC1;
            
              L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE1;
              L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE1;
              L_COD_CHG_CCY        := P_ENTRY_REC.CHG_CCY1;
              L_COD_CHG_AMT        := P_ENTRY_REC.CHG_AMT1;
              DBG('p_entry_rec.chg_ccy1          : ' ||
                  P_ENTRY_REC.CHG_CCY1);
              DBG('p_entry_rec.chg_amt1          : ' ||
                  P_ENTRY_REC.CHG_AMT1);
              DBG('p_entry_rec.lcy_chg_amt1      : ' ||
                  P_ENTRY_REC.LCY_CHG_AMT1);
              DBG('p_entry_rec.chgccy_lcy_xrate1 : ' ||
                  P_ENTRY_REC.CHGCCY_LCY_XRATE1);
              IF P_ENTRY_REC.INSTRUMENT_CCY = L_LCY THEN
                L_CHG_TCY           := P_ENTRY_REC.LCY_CHG_AMT1;
                L_TCY_CHG_EXCH_RATE := P_ENTRY_REC.CHGCCY_LCY_XRATE1;
              ELSIF P_ENTRY_REC.INSTRUMENT_CCY = P_ENTRY_REC.CHG_CCY1 THEN
                L_CHG_TCY           := P_ENTRY_REC.CHG_AMT1;
                L_TCY_CHG_EXCH_RATE := 1;
              END IF;
            
              IF P_ENTRY_REC.ACC_CCY = L_LCY THEN
                L_CHG_ACY           := P_ENTRY_REC.LCY_CHG_AMT1;
                L_ACY_CHG_EXCH_RATE := P_ENTRY_REC.CHGCCY_LCY_XRATE1;
              ELSIF P_ENTRY_REC.ACC_CCY = P_ENTRY_REC.CHG_CCY THEN
                L_CHG_ACY           := P_ENTRY_REC.CHG_AMT1;
                L_ACY_CHG_EXCH_RATE := 1;
              END IF;
            
            ELSIF I = 3 THEN
              P_ENTRY_REC.CHG_CCY2 := P_ACC_HAND(L_CURRPOS).AC_CCY;
            
              P_ENTRY_REC.CHG_AMT2          := G_CHG_CCY_AMT;
              P_ENTRY_REC.LCY_CHG_AMT2      := G_CHG_LCY;
              P_ENTRY_REC.CHGCCY_LCY_XRATE2 := NVL(G_EXCH_RATE_LCY, 1);
            
              P_ENTRY_REC.CHG_TYPE2 := P_CHG_ROW.COD_CHG_TYPE2;
              P_ENTRY_REC.CHG_DESC2 := P_CHG_ROW.COD_CHG_DESC2;
            
              L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE2;
              L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE2;
              L_COD_CHG_CCY        := P_ENTRY_REC.CHG_CCY2;
              L_COD_CHG_AMT        := P_ENTRY_REC.CHG_AMT2;
            
              DBG('p_entry_rec.chg_ccy2          : ' ||
                  P_ENTRY_REC.CHG_CCY2);
              DBG('p_entry_rec.chg_amt2          : ' ||
                  P_ENTRY_REC.CHG_AMT2);
              DBG('p_entry_rec.lcy_chg_amt2      : ' ||
                  P_ENTRY_REC.LCY_CHG_AMT2);
              DBG('p_entry_rec.chgccy_lcy_xrate2 : ' ||
                  P_ENTRY_REC.CHGCCY_LCY_XRATE2);
              IF P_ENTRY_REC.INSTRUMENT_CCY = L_LCY THEN
                L_CHG_TCY           := P_ENTRY_REC.LCY_CHG_AMT2;
                L_TCY_CHG_EXCH_RATE := P_ENTRY_REC.CHGCCY_LCY_XRATE2;
              ELSIF P_ENTRY_REC.INSTRUMENT_CCY = P_ENTRY_REC.CHG_CCY2 THEN
                L_CHG_TCY           := P_ENTRY_REC.CHG_AMT2;
                L_TCY_CHG_EXCH_RATE := 1;
              END IF;
            
              IF P_ENTRY_REC.ACC_CCY = L_LCY THEN
                L_CHG_ACY           := P_ENTRY_REC.LCY_CHG_AMT2;
                L_ACY_CHG_EXCH_RATE := P_ENTRY_REC.CHGCCY_LCY_XRATE2;
              ELSIF P_ENTRY_REC.ACC_CCY = P_ENTRY_REC.CHG_CCY THEN
                L_CHG_ACY           := P_ENTRY_REC.CHG_AMT2;
                L_ACY_CHG_EXCH_RATE := 1;
              END IF;
            ELSIF I = 4 THEN
              P_ENTRY_REC.CHG_CCY3 := P_ACC_HAND(L_CURRPOS).AC_CCY;
            
              P_ENTRY_REC.CHG_AMT3          := G_CHG_CCY_AMT;
              P_ENTRY_REC.LCY_CHG_AMT3      := G_CHG_LCY;
              P_ENTRY_REC.CHGCCY_LCY_XRATE3 := NVL(G_EXCH_RATE_LCY, 1);
            
              P_ENTRY_REC.CHG_TYPE3 := P_CHG_ROW.COD_CHG_TYPE3;
              P_ENTRY_REC.CHG_DESC3 := P_CHG_ROW.COD_CHG_DESC3;
            
              L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE3;
              L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE3;
              L_COD_CHG_CCY        := P_ENTRY_REC.CHG_CCY3;
              L_COD_CHG_AMT        := P_ENTRY_REC.CHG_AMT3;
              DBG('p_entry_rec.chg_ccy3          : ' ||
                  P_ENTRY_REC.CHG_CCY3);
              DBG('p_entry_rec.chg_amt3          : ' ||
                  P_ENTRY_REC.CHG_AMT3);
              DBG('p_entry_rec.lcy_chg_amt3      : ' ||
                  P_ENTRY_REC.LCY_CHG_AMT3);
              DBG('p_entry_rec.chgccy_lcy_xrate3 : ' ||
                  P_ENTRY_REC.CHGCCY_LCY_XRATE3);
              IF P_ENTRY_REC.INSTRUMENT_CCY = L_LCY THEN
                L_CHG_TCY           := P_ENTRY_REC.LCY_CHG_AMT3;
                L_TCY_CHG_EXCH_RATE := P_ENTRY_REC.CHGCCY_LCY_XRATE3;
              ELSIF P_ENTRY_REC.INSTRUMENT_CCY = P_ENTRY_REC.CHG_CCY3 THEN
                L_CHG_TCY           := P_ENTRY_REC.CHG_AMT3;
                L_TCY_CHG_EXCH_RATE := 1;
              END IF;
            
              IF P_ENTRY_REC.ACC_CCY = L_LCY THEN
                L_CHG_ACY           := P_ENTRY_REC.LCY_CHG_AMT3;
                L_ACY_CHG_EXCH_RATE := P_ENTRY_REC.CHGCCY_LCY_XRATE3;
              ELSIF P_ENTRY_REC.ACC_CCY = P_ENTRY_REC.CHG_CCY THEN
                L_CHG_ACY           := P_ENTRY_REC.CHG_AMT3;
                L_ACY_CHG_EXCH_RATE := 1;
              END IF;
            ELSIF I = 5 THEN
              P_ENTRY_REC.CHG_CCY4 := P_ACC_HAND(L_CURRPOS).AC_CCY;
            
              P_ENTRY_REC.CHG_AMT4          := G_CHG_CCY_AMT;
              P_ENTRY_REC.LCY_CHG_AMT4      := G_CHG_LCY;
              P_ENTRY_REC.CHGCCY_LCY_XRATE4 := NVL(G_EXCH_RATE_LCY, 1);
            
              P_ENTRY_REC.CHG_TYPE4 := P_CHG_ROW.COD_CHG_TYPE4;
              P_ENTRY_REC.CHG_DESC4 := P_CHG_ROW.COD_CHG_DESC4;
            
              L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE4;
              L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE4;
              L_COD_CHG_CCY        := P_ENTRY_REC.CHG_CCY4;
              L_COD_CHG_AMT        := P_ENTRY_REC.CHG_AMT4;
              DBG('p_entry_rec.chg_ccy4          : ' ||
                  P_ENTRY_REC.CHG_CCY4);
              DBG('p_entry_rec.chg_amt4          : ' ||
                  P_ENTRY_REC.CHG_AMT4);
              DBG('p_entry_rec.lcy_chg_amt4      : ' ||
                  P_ENTRY_REC.LCY_CHG_AMT4);
              DBG('p_entry_rec.chgccy_lcy_xrate4 : ' ||
                  P_ENTRY_REC.CHGCCY_LCY_XRATE4);
              IF P_ENTRY_REC.INSTRUMENT_CCY = L_LCY THEN
                L_CHG_TCY           := P_ENTRY_REC.LCY_CHG_AMT4;
                L_TCY_CHG_EXCH_RATE := P_ENTRY_REC.CHGCCY_LCY_XRATE4;
              ELSIF P_ENTRY_REC.INSTRUMENT_CCY = P_ENTRY_REC.CHG_CCY4 THEN
                L_CHG_TCY           := P_ENTRY_REC.CHG_AMT4;
                L_TCY_CHG_EXCH_RATE := 1;
              END IF;
            
              IF P_ENTRY_REC.ACC_CCY = L_LCY THEN
                L_CHG_ACY           := P_ENTRY_REC.LCY_CHG_AMT4;
                L_ACY_CHG_EXCH_RATE := P_ENTRY_REC.CHGCCY_LCY_XRATE4;
              ELSIF P_ENTRY_REC.ACC_CCY = P_ENTRY_REC.CHG_CCY THEN
                L_CHG_ACY           := P_ENTRY_REC.CHG_AMT4;
                L_ACY_CHG_EXCH_RATE := 1;
              END IF;
            END IF;
          
            IF L_CHG_TCY IS NULL THEN
              IF NOT CYPKS.FN_AMT1_TO_AMT2(P_ENTRY_REC.TXN_BRANCH,
                                           L_COD_CHG_CCY,
                                           P_ENTRY_REC.INSTRUMENT_CCY,
                                           NVL(L_COD_RATE_CODE, 'STANDARD'),
                                           NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                           L_COD_CHG_AMT,
                                           'Y',
                                           L_CHG_TCY,
                                           L_TCY_CHG_EXCH_RATE,
                                           P_ERR_CODE) THEN
                DBG('Failed while findin xch rate ' || P_ERR_CODE);
              
                RETURN FALSE;
              END IF;
            END IF;
          
            IF L_CHG_ACY IS NULL THEN
              DBG('p_Entry_Rec.Acc_Ccy  ' || P_ENTRY_REC.ACC_CCY);
              IF NOT CYPKS.FN_AMT1_TO_AMT2(P_ENTRY_REC.TXN_BRANCH,
                                           L_COD_CHG_CCY,
                                           P_ENTRY_REC.ACC_CCY,
                                           NVL(L_COD_RATE_CODE, 'STANDARD'),
                                           NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                           L_COD_CHG_AMT,
                                           'Y',
                                           L_CHG_ACY,
                                           L_ACY_CHG_EXCH_RATE,
                                           P_ERR_CODE) THEN
                DBG('Failed while findin xch rate ' || P_ERR_CODE);
              
                RETURN FALSE;
              END IF;
            END IF;
            DBG('l_Acy_Chg_Exch_Rate ' || L_ACY_CHG_EXCH_RATE);
          
            P_ENTRY_REC.TCYTOTCHGAMT := NVL(P_ENTRY_REC.TCYTOTCHGAMT, 0) +
                                        NVL(L_CHG_TCY, 0);
            P_ENTRY_REC.ACYTOTCHGAMT := NVL(P_ENTRY_REC.ACYTOTCHGAMT, 0) +
                                        NVL(L_CHG_ACY, 0);
          
            DBG('p_entry_rec.tcytotchgamt     : ' ||
                P_ENTRY_REC.TCYTOTCHGAMT);
            DBG('p_entry_rec.acytotchgamt     : ' ||
                P_ENTRY_REC.ACYTOTCHGAMT);
          END IF;
        
        END LOOP;
      
        DBG('p_entry_rec.reference_no : ' || P_ENTRY_REC.REFERENCE_NO);
      
      END IF;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 1;
      
        DBG('cspks_clg_serv_cluster.FN_POST_CHG_PROC ');
        IF NOT CSPKS_CLG_SERV_CLUSTER.FN_POST_CHG_PROC(PBRANCH,
                                                       P_ENTRY_REC,
                                                       P_CHG_ROW,
                                                       P_ERR_CODE,
                                                       P_ERRPARAM,
                                                       P_ACC_HAND,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA)
        
         THEN
          DBG('Failure has happened in cspks_clg_serv_cluster.FN_POST_CHG_PROC');
          RETURN FALSE;
        END IF;
      END IF;
    
      UPDATE CSTB_CLEARING_MASTER
         SET TCYTOTCHGAMT      = P_ENTRY_REC.TCYTOTCHGAMT,
             ACYTOTCHGAMT      = P_ENTRY_REC.ACYTOTCHGAMT,
             CHG_CCY           = P_ENTRY_REC.CHG_CCY,
             CHG_AMT           = P_ENTRY_REC.CHG_AMT,
             LCY_CHG_AMT       = P_ENTRY_REC.LCY_CHG_AMT,
             CHGCCY_LCY_XRATE  = P_ENTRY_REC.CHGCCY_LCY_XRATE,
             CHG_CCY1          = P_ENTRY_REC.CHG_CCY1,
             CHG_AMT1          = P_ENTRY_REC.CHG_AMT1,
             LCY_CHG_AMT1      = P_ENTRY_REC.LCY_CHG_AMT1,
             CHGCCY_LCY_XRATE1 = P_ENTRY_REC.CHGCCY_LCY_XRATE1,
             CHG_CCY2          = P_ENTRY_REC.CHG_CCY2,
             CHG_AMT2          = P_ENTRY_REC.CHG_AMT2,
             LCY_CHG_AMT2      = P_ENTRY_REC.LCY_CHG_AMT2,
             CHGCCY_LCY_XRATE2 = P_ENTRY_REC.CHGCCY_LCY_XRATE2,
             CHG_CCY3          = P_ENTRY_REC.CHG_CCY3,
             CHG_AMT3          = P_ENTRY_REC.CHG_AMT3,
             LCY_CHG_AMT3      = P_ENTRY_REC.LCY_CHG_AMT3,
             CHGCCY_LCY_XRATE3 = P_ENTRY_REC.CHGCCY_LCY_XRATE3,
             CHG_CCY4          = P_ENTRY_REC.CHG_CCY4,
             CHG_AMT4          = P_ENTRY_REC.CHG_AMT4,
             LCY_CHG_AMT4      = P_ENTRY_REC.LCY_CHG_AMT4,
             CHGCCY_LCY_XRATE4 = P_ENTRY_REC.CHGCCY_LCY_XRATE4,
             
             CHG_DESC  = P_ENTRY_REC.CHG_DESC,
             CHG_DESC1 = P_ENTRY_REC.CHG_DESC1,
             CHG_DESC2 = P_ENTRY_REC.CHG_DESC2,
             CHG_DESC3 = P_ENTRY_REC.CHG_DESC3,
             CHG_DESC4 = P_ENTRY_REC.CHG_DESC4,
             CHG_TYPE  = P_ENTRY_REC.CHG_TYPE,
             CHG_TYPE1 = P_ENTRY_REC.CHG_TYPE1,
             CHG_TYPE2 = P_ENTRY_REC.CHG_TYPE2,
             CHG_TYPE3 = P_ENTRY_REC.CHG_TYPE3,
             CHG_TYPE4 = P_ENTRY_REC.CHG_TYPE4
      
       WHERE REFERENCE_NO = P_ENTRY_REC.REFERENCE_NO;
    
      PR_PRINT_CHG_ENTRIES(P_ACC_HAND);
    
      PR_REMOVE_ZERO_CHGS(P_ACC_HAND);
    
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_chg_proc...' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_CHG_PROC;

  FUNCTION FN_ARC_PICKUP(PBRANCH     IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                         P_ENTRY_REC IN OUT CSTBS_CLEARING_MASTER%ROWTYPE,
                         P_CHG_ROW   IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                         P_ERR_CODE  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                         P_ERR_PARAM IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
    L_ACCOUNT_CLASS STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_PRODUCT_TYPE  CSTMS_PRODUCT.PRODUCT_TYPE%TYPE;
    L_TXN_AC_NO     DETBS_RTL_TELLER.TXN_ACC%TYPE;
    L_TXN_BRN       DETBS_RTL_TELLER.TXN_BRANCH%TYPE;
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside function fn_arc_pickup');
  
    L_ACCOUNT_CLASS := P_ENTRY_REC.PRODUCT_CODE;
    PR_GET_PROD(P_ENTRY_REC.PRODUCT_CODE);
    L_PRODUCT_TYPE := PKG_PROD_REC.PRODUCT_TYPE;
  
    DBG('fn_arc_pickup ==> Setting Account Number and Branch Code for ARC Pick up');
    IF CSPKSS_CLG_SERVICES.G_CLG_ACCOUNT_ARC IS NOT NULL THEN
      DBG('Account Number NOT NULL ' ||
          CSPKSS_CLG_SERVICES.G_CLG_ACCOUNT_ARC);
      L_TXN_AC_NO := CSPKSS_CLG_SERVICES.G_CLG_ACCOUNT_ARC;
    ELSE
      L_TXN_AC_NO := NULL;
    END IF;
    IF CSPKSS_CLG_SERVICES.G_CLG_BRANCH_ARC IS NOT NULL THEN
      DBG('Branch is NOT NULL ' || CSPKSS_CLG_SERVICES.G_CLG_BRANCH_ARC);
      L_TXN_BRN := CSPKSS_CLG_SERVICES.G_CLG_BRANCH_ARC;
    END IF;
    DBG('Account Number ' || L_TXN_AC_NO);
    DBG('Branch ' || L_TXN_BRN);
  
    IF (L_PRODUCT_TYPE = 'OC') THEN
      DEBUG.PR_DEBUG('CG', 'Arc pick up for OC');
      DEBUG.PR_DEBUG('CG', 'Txn brn is ..' || P_ENTRY_REC.TXN_BRANCH);
      DEBUG.PR_DEBUG('CG', 'Prod ..' || L_ACCOUNT_CLASS);
      DEBUG.PR_DEBUG('CG', 'insr ccy is ..' || P_ENTRY_REC.INSTRUMENT_CCY);
      DEBUG.PR_DEBUG('CG', 'Sector code is ..' || P_ENTRY_REC.SECTOR_CODE);
      DEBUG.PR_DEBUG('CG',
                     'Account Number for ARC pick up is  .. ' ||
                     L_TXN_AC_NO);
      DEBUG.PR_DEBUG('CG', 'Branch for ARC pick up is .. ' || L_TXN_BRN);
      IF NOT CSPKSS_ARC.FN_CHARGE_PICKUP(P_ENTRY_REC.TXN_BRANCH,
                                         L_ACCOUNT_CLASS,
                                         'P',
                                         P_ENTRY_REC.TXN_BRANCH,
                                         P_ENTRY_REC.INSTRUMENT_CCY,
                                         P_ENTRY_REC.SECTOR_CODE,
                                         P_ENTRY_REC.INSTRUMENT_CCY,
                                         P_ENTRY_REC.INSTRUMENT_AMT,
                                         'STANDARD',
                                         'M',
                                         NULL,
                                         P_ENTRY_REC.BEN_CUST,
                                         P_CHG_ROW,
                                         P_ERR_CODE,
                                         P_ERR_PARAM,
                                         L_TXN_AC_NO,
                                         L_TXN_BRN) THEN
        DEBUG.PR_DEBUG('CG', 'Error in ARC pick up');
        RETURN FALSE;
      END IF;
      P_ENTRY_REC.END_POINT := P_CHG_ROW.END_POINT;
    ELSIF (L_PRODUCT_TYPE = 'IC') THEN
      DEBUG.PR_DEBUG('CG', 'Arc pick up for IC');
      DEBUG.PR_DEBUG('CG', 'Txn brn is ..' || P_ENTRY_REC.TXN_BRANCH);
      DEBUG.PR_DEBUG('CG', 'Prod ..' || L_ACCOUNT_CLASS);
      DEBUG.PR_DEBUG('CG', 'insr ccy is ..' || P_ENTRY_REC.INSTRUMENT_CCY);
      DEBUG.PR_DEBUG('CG', 'End point is ..' || P_ENTRY_REC.END_POINT);
      DEBUG.PR_DEBUG('CG',
                     'Account Number for ARC pick up is  .. ' ||
                     L_TXN_AC_NO);
      DEBUG.PR_DEBUG('CG', 'Branch for ARC pick up is .. ' || L_TXN_BRN);
    
      IF NOT CSPKSS_ARC.FN_CHARGE_PICKUP(P_ENTRY_REC.TXN_BRANCH,
                                         L_ACCOUNT_CLASS,
                                         'P',
                                         P_ENTRY_REC.TXN_BRANCH,
                                         P_ENTRY_REC.INSTRUMENT_CCY,
                                         P_ENTRY_REC.END_POINT,
                                         P_ENTRY_REC.INSTRUMENT_CCY,
                                         P_ENTRY_REC.INSTRUMENT_AMT,
                                         'STANDARD',
                                         'M',
                                         NULL,
                                         P_ENTRY_REC.REM_CUST,
                                         P_CHG_ROW,
                                         P_ERR_CODE,
                                         P_ERR_PARAM,
                                         L_TXN_AC_NO,
                                         L_TXN_BRN) THEN
        DEBUG.PR_DEBUG('CG', 'Error in ARC pick up ');
        RETURN FALSE;
      END IF;
    END IF;
    DEBUG.PR_DEBUG('CG', 'Returning true from fn_arc_pickup');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_arc_pickup...' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_ARC_PICKUP;

  FUNCTION FN_PROCESS_IC_ENTRY(PBRANCH         IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                               P_ENTRY_REC     IN OUT CSTBS_CLEARING_MASTER%ROWTYPE,
                               P_CHG_ROW       IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                               P_ERR_CODE      OUT VARCHAR2,
                               P_ERR_PARAM     OUT VARCHAR2,
                               P_CONSOL_REF_NO IN VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN IS
    L_CLG_BRN   STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_ERRCODE   ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERRPARAM  ERTBS_MSGS.MESSAGE%TYPE;
    L_COUNT     NUMBER;
    L_ERRORTYPE ERTBS_MSGS.TYPE%TYPE;
  BEGIN
  
    PR_GET_BRN_DET(P_ENTRY_REC.TXN_BRANCH);
    L_CLG_BRN := PKG_BRN_REC.CLG_BRN;
    IF P_CHG_ROW.COD_OFFSET_BRN <> '*.*' THEN
      IF (P_CHG_ROW.COD_OFFSET_BRN <> L_CLG_BRN) THEN
        DEBUG.PR_DEBUG('CG',
                       'Clg Brn for this txn brn is ..' || L_CLG_BRN ||
                       ' - Use a Susp GL of that Brn');
        P_ERR_CODE := 'CG-CL0013';
        RETURN FALSE;
      END IF;
    END IF;
    L_COUNT := NULL;
    SELECT COUNT(*)
      INTO L_COUNT
      FROM CSTBS_CLEARING_MASTER
     WHERE ACC_BRANCH = P_ENTRY_REC.ACC_BRANCH
       AND REM_ACCOUNT = P_ENTRY_REC.REM_ACCOUNT
          
       AND INSTRUMENT_NO_1 = P_ENTRY_REC.INSTRUMENT_NO_1
       AND DIRECTION = 'I'
       AND RECORD_STAT = 'O'
       AND AUTH_STAT = 'A'
       AND
          
           STATUS NOT IN ('REVR', 'REJE', 'REJR');
  
    L_ERRORTYPE := NULL;
    L_ERRORTYPE := OVPKSS.FN_GETTYPE('CA-POS000');
    DEBUG.PR_DEBUG('AC', 'Error type is ' || L_ERRORTYPE);
    IF L_ERRORTYPE IN ('E', 'O') AND L_COUNT > 0 THEN
      DEBUG.PR_DEBUG('AC', 'Warrant is already paid');
      P_ERR_CODE := 'CA-POS000;';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, NULL);
      RETURN FALSE;
    END IF;
    L_COUNT := NULL;
    IF P_ENTRY_REC.DIN IS NOT NULL AND P_ENTRY_REC.DIN_DATE IS NOT NULL
    
     THEN
      SELECT COUNT(*)
        INTO L_COUNT
        FROM CSTBS_CLEARING_MASTER
       WHERE DIN = P_ENTRY_REC.DIN
         AND DIN_DATE = P_ENTRY_REC.DIN_DATE
         AND DIRECTION = 'I'
         AND STATUS IN ('SUCC', 'REJA', 'REJR')
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
            
         AND ACC_BRANCH = P_ENTRY_REC.ACC_BRANCH
         AND REM_ACCOUNT = P_ENTRY_REC.REM_ACCOUNT
      
      ;
      L_ERRORTYPE := NULL;
      L_ERRORTYPE := OVPKSS.FN_GETTYPE('CA-POS044');
      DEBUG.PR_DEBUG('AC', 'Error type is ' || L_ERRORTYPE);
      IF L_ERRORTYPE IN ('E', 'O') AND L_COUNT > 0 THEN
        DEBUG.PR_DEBUG('AC',
                       'Warrant with din ' || P_ENTRY_REC.DIN ||
                       ' and din date ' || P_ENTRY_REC.DIN_DATE ||
                       'is already paid');
        P_ERR_CODE  := 'CA-POS044;';
        P_ERR_PARAM := P_ENTRY_REC.DIN || '~' || P_ENTRY_REC.DIN_DATE;
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT FN_PASS_IC_ACCT_ENTRIES(PBRANCH,
                                   P_ENTRY_REC,
                                   P_CHG_ROW,
                                   P_ERR_CODE,
                                   P_ERR_PARAM,
                                   P_CONSOL_REF_NO) THEN
      DEBUG.PR_DEBUG('CG', 'Failed in accounting entry  - ' || L_ERRCODE);
      RETURN FALSE;
    END IF;
    IF FN_PROCESS_INSTR(P_ENTRY_REC, P_ERR_CODE) = -1 THEN
      DEBUG.PR_DEBUG('CG',
                     'Failed while marking instrument as Liquidated ' ||
                     P_ERR_CODE);
      RETURN FALSE;
    END IF;
    DEBUG.PR_DEBUG('CG', 'Inst processing success');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'Exception in fn_process_ic_entry - ' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_PROCESS_IC_ENTRY;

  FUNCTION FN_PROCESS_OC_ENTRY(PBRANCH       IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                               P_ENTRY_REC   IN OUT CSTBS_CLEARING_MASTER%ROWTYPE,
                               P_CHG_ROW     IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                               P_ERR_CODE    OUT VARCHAR2,
                               P_ERR_PARAM   OUT VARCHAR2,
                               P_ONLINE_AUTH IN CHAR) RETURN BOOLEAN IS
    L_CLG_BRN           STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_ERRCODE           ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERRPARAM          ERTBS_MSGS.MESSAGE%TYPE;
    L_DEFER_LIQUIDATION VARCHAR2(100);
  BEGIN
    PR_GET_BRN_DET(P_ENTRY_REC.TXN_BRANCH);
    L_CLG_BRN := PKG_BRN_REC.CLG_BRN;
  
    IF P_CHG_ROW.COD_OFFSET_BRN <> '*.*' THEN
      IF P_CHG_ROW.COD_OFFSET_BRN <> L_CLG_BRN THEN
        DEBUG.PR_DEBUG('CG',
                       'Clg Brn for this txn brn is ..' || L_CLG_BRN ||
                       ' - Use a Susp GL of that Brn');
        P_ERR_CODE := 'CG-CL0013';
        RETURN FALSE;
      END IF;
    END IF;
  
    BEGIN
      SELECT DEFER_LIQUIDATION
        INTO L_DEFER_LIQUIDATION
        FROM CGTMS_PRODUCT_REFERRAL
       WHERE PRODUCT_CODE = P_ENTRY_REC.PRODUCT_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERR_CODE  := 'CG-PROD-001';
        P_ERR_PARAM := P_ENTRY_REC.PRODUCT_CODE;
    END;
    L_DEFER_LIQUIDATION := NVL(L_DEFER_LIQUIDATION, 'N');
  
    DEBUG.PR_DEBUG('CG',
                   'gwpks_util.pkg_actType is ' || GWPKS_UTIL.PKG_ACTTYPE ||
                   '  and  ' || 'gwpks_util.pkg_func is ' ||
                   GWPKS_UTIL.PKG_FUNC);
  
    IF GWPKS_UTIL.PKG_ACTTYPE IN ('INPUT', 'ENRICH')
      
       AND GWPKS_UTIL.PKG_FUNC = '6501' THEN
      DEBUG.PR_DEBUG('CG',
                     'Skipping accounting in case of 6501 input stage');
    ELSE
    
      IF L_DEFER_LIQUIDATION = 'Y' THEN
        IF NOT CGPKS_EOD.FN_INIT_FOR_A_CHEQUE(P_ENTRY_REC,
                                              P_ONLINE_AUTH,
                                              P_ERR_CODE,
                                              P_ERR_PARAM) THEN
          DEBUG.PR_DEBUG('CG', 'Failed in accounting entry');
          RETURN FALSE;
        END IF;
      ELSE
        DBG('about to call Fn_Pass_Oc_Acct_Entries for init event');
        IF NOT FN_PASS_OC_ACCT_ENTRIES(PBRANCH,
                                       P_ENTRY_REC,
                                       P_CHG_ROW,
                                       P_ERR_CODE,
                                       P_ERR_PARAM,
                                       P_ONLINE_AUTH) THEN
          DEBUG.PR_DEBUG('CG', 'Failed in accounting entry');
          RETURN FALSE;
        END IF;
        UPDATE CSTB_CLEARING_MASTER
           SET DISPATCH_STATUS = 'L'
         WHERE REFERENCE_NO = P_ENTRY_REC.REFERENCE_NO;
      
      END IF;
    
      DEBUG.PR_DEBUG('CG', 'Accounting Successful');
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'Exception in fn_process_oc_entry - ' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_PROCESS_OC_ENTRY;

  FUNCTION FN_READ_OC_REJECT_DATA_STRING(P_ENTRY_DATA_STRING IN VARCHAR2,
                                         P_ENTRY_COLUMN_LIST IN VARCHAR2,
                                         P_REM_ACC           OUT CSTBS_CLEARING_MASTER.REM_ACCOUNT%TYPE,
                                         P_ROUTING_NO        OUT CSTBS_CLEARING_MASTER.ROUTING_NO%TYPE,
                                         P_INSTRUMENT_NO     OUT CSTBS_CLEARING_MASTER.INSTRUMENT_NO_1%TYPE,
                                         P_REJECT_REASON     OUT CSTBS_CLEARING_MASTER.REJECT_REASON%TYPE,
                                         P_REJECT_CODE       OUT CSTBS_CLEARING_MASTER.REJECT_CODE%TYPE
                                         
                                        ,
                                         P_XREF           OUT CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE,
                                         P_CHQ_RETURN_AMT OUT CSTBS_CLEARING_MASTER.INSTRUMENT_AMT%TYPE,
                                         P_BRANCH_CODE    OUT CSTBS_CLEARING_MASTER.TXN_BRANCH%TYPE
                                         
                                        ,
                                         P_ERR_CODE OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_ENTRY_COLUMN_LIST  VARCHAR2(6000);
    L_COLUMN_LIST        VARCHAR2(6000) := 'SCODE~XREF~TXNBRN~REMACCOUNT~INSTRNO~ROUTINGNO~REJECTCODE~REJECTREASON~TXNBRN~INSTRAMT';
    L_COLUMN_NAME        VARCHAR2(30);
    L_COL_COUNT          INTEGER := 1;
    L_POS_IN_COLUMN_LIST INTEGER := 0;
    L_COLUMN_VALUE       VARCHAR2(32767);
    L_SCODE              CSTBS_CLEARING_MASTER.SCODE%TYPE;
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside fn_read_oc_reject_data_string');
    IF P_ENTRY_COLUMN_LIST IS NULL THEN
      L_ENTRY_COLUMN_LIST := L_COLUMN_LIST;
    ELSE
      L_ENTRY_COLUMN_LIST := UPPER(P_ENTRY_COLUMN_LIST);
    END IF;
    DEBUG.PR_DEBUG('CG', 'Before Looping into OC reject data string ');
    L_COLUMN_NAME := CSPKES_MISC.FN_GETPARAM(L_COLUMN_LIST,
                                             L_COL_COUNT,
                                             '~');
    WHILE L_COLUMN_NAME <> 'EOPL' LOOP
      L_POS_IN_COLUMN_LIST := CSPKES_MISC.FN_GETPARAM_NO(L_ENTRY_COLUMN_LIST,
                                                         L_COLUMN_NAME,
                                                         '~');
      L_COLUMN_VALUE       := CSPKES_MISC.FN_GETPARAM(P_ENTRY_DATA_STRING,
                                                      L_POS_IN_COLUMN_LIST,
                                                      '~');
      DEBUG.PR_DEBUG('CG',
                     'Inside the loop for ' || L_COLUMN_NAME || ' -> ' ||
                     L_COLUMN_VALUE);
      IF L_COLUMN_NAME = 'SCODE' THEN
        DEBUG.PR_DEBUG('CG',
                       'l_column_value ----moni-SCODE' || L_COLUMN_VALUE);
        L_SCODE := L_COLUMN_VALUE;
      
      ELSIF L_COLUMN_NAME = 'REMACCOUNT' THEN
        DEBUG.PR_DEBUG('CG',
                       'l_column_value ----moni1--REMACCOUNT' ||
                       L_COLUMN_VALUE);
        P_REM_ACC := L_COLUMN_VALUE;
      
      ELSIF L_COLUMN_NAME = 'INSTRNO' THEN
        DEBUG.PR_DEBUG('CG',
                       'l_column_value ----moni2--INSTRNO' ||
                       L_COLUMN_VALUE);
      
        P_INSTRUMENT_NO := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'ROUTINGNO' THEN
        DEBUG.PR_DEBUG('CG',
                       'l_column_value ----moni3-ROUTINGNO' ||
                       L_COLUMN_VALUE);
      
        P_ROUTING_NO := L_COLUMN_VALUE;
      
      ELSIF L_COLUMN_NAME = 'REJECTCODE' THEN
        DEBUG.PR_DEBUG('CG',
                       'l_column_value ----moni4--REJECTCODE' ||
                       L_COLUMN_VALUE);
      
        P_REJECT_CODE := L_COLUMN_VALUE;
      
      ELSIF L_COLUMN_NAME = 'REJECTREASON' THEN
        DEBUG.PR_DEBUG('CG',
                       'l_column_value ----moni5---REJECTREASON' ||
                       L_COLUMN_VALUE);
      
        P_REJECT_REASON := L_COLUMN_VALUE;
      
      ELSIF L_COLUMN_NAME = 'XREF' THEN
        DEBUG.PR_DEBUG('CG',
                       'l_column_value ----moni6---XREF' || L_COLUMN_VALUE);
      
        P_XREF := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'TXNBRN' THEN
        DEBUG.PR_DEBUG('CG',
                       'l_column_value ----moni7---branch_code' ||
                       L_COLUMN_VALUE);
      
        P_BRANCH_CODE := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'INSTRAMT' THEN
        DEBUG.PR_DEBUG('CG',
                       'l_column_value ----moni8---INSTRAMT' ||
                       L_COLUMN_VALUE);
      
        P_CHQ_RETURN_AMT := L_COLUMN_VALUE;
      
      END IF;
      L_COL_COUNT   := L_COL_COUNT + 1;
      L_COLUMN_NAME := CSPKES_MISC.FN_GETPARAM(L_COLUMN_LIST,
                                               L_COL_COUNT,
                                               '~');
    END LOOP;
    DEBUG.PR_DEBUG('CG', 'Thru with reading string');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'Exception in fn_read_oc_reject_data_string - ' ||
                     SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_READ_OC_REJECT_DATA_STRING;

  FUNCTION FN_READ_OC_REJECT_DATA_STRING(P_ENTRY_DATA_STRING IN VARCHAR2,
                                         P_ENTRY_COLUMN_LIST IN VARCHAR2,
                                         P_REM_ACC           OUT CSTBS_CLEARING_MASTER.REM_ACCOUNT%TYPE,
                                         P_ROUTING_NO        OUT CSTBS_CLEARING_MASTER.ROUTING_NO%TYPE,
                                         P_INSTRUMENT_NO     OUT CSTBS_CLEARING_MASTER.INSTRUMENT_NO_1%TYPE,
                                         P_REJECT_REASON     OUT CSTBS_CLEARING_MASTER.REJECT_REASON%TYPE,
                                         P_ERR_CODE          OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_REJECT_CODE VARCHAR2(3);
  
    L_CHQ_RETURN_AMT CSTBS_CLEARING_MASTER.INSTRUMENT_AMT%TYPE;
    L_BRANCH_CODE    CSTBS_CLEARING_MASTER.TXN_BRANCH%TYPE;
    L_XREF           CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE;
  
  BEGIN
    IF NOT FN_READ_OC_REJECT_DATA_STRING(P_ENTRY_DATA_STRING,
                                         P_ENTRY_COLUMN_LIST,
                                         P_REM_ACC,
                                         P_ROUTING_NO,
                                         P_INSTRUMENT_NO,
                                         P_REJECT_REASON,
                                         L_REJECT_CODE
                                         
                                        ,
                                         L_XREF,
                                         L_CHQ_RETURN_AMT,
                                         L_BRANCH_CODE
                                         
                                        ,
                                         P_ERR_CODE) THEN
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  END FN_READ_OC_REJECT_DATA_STRING;

  FUNCTION FN_READ_REV_DATA_STRING(P_ENTRY_DATA_STRING IN VARCHAR2,
                                   P_ENTRY_COLUMN_LIST IN VARCHAR2,
                                   P_XREF              OUT CSTBS_CLEARING_MASTER.XREF%TYPE,
                                   P_ERR_CODE          OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_ENTRY_COLUMN_LIST  VARCHAR2(6000);
    L_COLUMN_LIST        VARCHAR2(6000) := 'SCODE~XREF~TXNBRN~';
    L_COLUMN_NAME        VARCHAR2(30);
    L_COL_COUNT          INTEGER := 1;
    L_POS_IN_COLUMN_LIST INTEGER := 0;
    L_COLUMN_VALUE       VARCHAR2(32767);
    L_SCODE              VARCHAR2(32767);
    L_COUNT              INTEGER;
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside fn_read_rev_data_string');
    IF P_ENTRY_COLUMN_LIST IS NULL THEN
      L_ENTRY_COLUMN_LIST := L_COLUMN_LIST;
    ELSE
      L_ENTRY_COLUMN_LIST := UPPER(P_ENTRY_COLUMN_LIST);
    END IF;
    DEBUG.PR_DEBUG('CG', 'Before Looping into reversal data string ');
    L_COLUMN_NAME := CSPKES_MISC.FN_GETPARAM(L_COLUMN_LIST,
                                             L_COL_COUNT,
                                             '~');
    WHILE L_COLUMN_NAME <> 'EOPL' LOOP
      L_POS_IN_COLUMN_LIST := CSPKES_MISC.FN_GETPARAM_NO(L_ENTRY_COLUMN_LIST,
                                                         L_COLUMN_NAME,
                                                         '~');
      L_COLUMN_VALUE       := CSPKES_MISC.FN_GETPARAM(P_ENTRY_DATA_STRING,
                                                      L_POS_IN_COLUMN_LIST,
                                                      '~');
      DEBUG.PR_DEBUG('CG',
                     'Inside the loop for ' || L_COLUMN_NAME || ' -> ' ||
                     L_COLUMN_VALUE);
      IF L_COLUMN_NAME = 'SCODE' THEN
        L_SCODE := L_COLUMN_VALUE;
      ELSIF L_COLUMN_NAME = 'XREF' THEN
        P_XREF := L_COLUMN_VALUE;
      END IF;
      L_COL_COUNT   := L_COL_COUNT + 1;
      L_COLUMN_NAME := CSPKES_MISC.FN_GETPARAM(L_COLUMN_LIST,
                                               L_COL_COUNT,
                                               '~');
    END LOOP;
    DEBUG.PR_DEBUG('CG', 'Thru with reading string');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'Exception in fn_read_rev_data_string - ' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_READ_REV_DATA_STRING;

  FUNCTION FN_PROCESS_OC_REJECTS(PBRANCH           IN VARCHAR2,
                                 P_REJ_COL_LIST    IN VARCHAR2,
                                 P_REJ_DATA_STRING IN VARCHAR2,
                                 P_XREF            OUT VARCHAR2,
                                 P_FCCREF          OUT VARCHAR2,
                                 P_STATUS          OUT VARCHAR2,
                                 P_ERR_CODE        OUT VARCHAR2,
                                 P_ERR_PARAM       OUT VARCHAR2,
                                 P_ONLINE_AUTH     IN CHAR) RETURN BOOLEAN IS
    L_REJ_REC         CSTBS_CLEARING_MASTER%ROWTYPE;
    L_ERR_CODE        ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM       ERTBS_MSGS.MESSAGE%TYPE;
    L_CONTRACT_REF_NO CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE;
    L_STATUS          CHAR(1);
    L_MAKER_DT_STAMP  DATE;
    L_USER            ACTBS_DAILY_LOG.USER_ID%TYPE;
    L_REFERENCE_NO    ACTBS_DAILY_LOG.TRN_REF_NO%TYPE;
    L_REM_ACCOUNT     CSTBS_CLEARING_MASTER.REM_ACCOUNT%TYPE;
    L_INSTRUMENT_NO   CSTBS_CLEARING_MASTER.INSTRUMENT_NO_1%TYPE;
    L_ROUTING_NO      CSTBS_CLEARING_MASTER.ROUTING_NO%TYPE;
    L_REJECT_REASON   CSTBS_CLEARING_MASTER.REJECT_REASON%TYPE;
    L_REJECT_CODE     VARCHAR2(3);
    L_EVENT_SEQ_NO    NUMBER;
    L_REMARKS         VARCHAR2(200);
  
    L_CNT NUMBER;
  
    L_TB_REJREASON   CGPKS_CGDCLGDT_KERNEL.TY_REJREASON;
    L_REJECT_ACCOUNT VARCHAR2(20);
  
    L_COD_REFERENCE_NO UPTB_TXN_UPLOAD.COD_REFERENCE_NO%TYPE;
  
    L_DEFER_LIQUIDATION VARCHAR2(1);
    L_CHQ_RETURN_AMT    CSTBS_CLEARING_MASTER.INSTRUMENT_AMT%TYPE;
    L_BRANCH_CODE       CSTBS_CLEARING_MASTER.TXN_BRANCH%TYPE;
    L_XREF              CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE;
    L_TOT_CHG_AMT       NUMBER;
  
    L_TB_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_CALL_FUNC_ID          NUMBER;
  
  BEGIN
    L_USER           := GLOBAL.USER_ID;
    L_MAKER_DT_STAMP := CEPKSS_DATE.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE);
    IF P_REJ_DATA_STRING IS NULL THEN
      DEBUG.PR_DEBUG('CG', 'OC Reject Data String is null');
      P_ERR_CODE := 'CG-CL0015';
      RETURN FALSE;
    END IF;
    IF NOT FN_READ_OC_REJECT_DATA_STRING(P_REJ_DATA_STRING,
                                         P_REJ_COL_LIST,
                                         L_REM_ACCOUNT,
                                         L_ROUTING_NO,
                                         L_INSTRUMENT_NO,
                                         L_REJECT_REASON,
                                         L_REJECT_CODE
                                         
                                        ,
                                         L_XREF,
                                         L_CHQ_RETURN_AMT,
                                         L_BRANCH_CODE
                                         
                                        ,
                                         L_ERR_CODE) THEN
      DBG('fn_read_oc_reject_data_string - RETURN FALSE');
      P_ERR_CODE := L_ERR_CODE;
      RETURN FALSE;
    END IF;
    DBG('Reference no is ...' || L_REJ_REC.REFERENCE_NO);
    DBG('before ..l_reject_code , Reject Reason ...' || L_REJECT_CODE ||
        L_REJECT_REASON);
  
    BEGIN
      IF L_REJECT_REASON IS NULL THEN
        SELECT REASON_DESC
          INTO L_REJECT_REASON
          FROM CSTBS_CLG_REJ_REASON
         WHERE REASON_CODE = L_REJECT_CODE;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_REJECT_CODE := '';
    END;
    DEBUG.PR_DEBUG('CG',
                   'l_reject_code , Reject Reason  after assign...' ||
                   L_REJECT_CODE || L_REJECT_REASON);
  
    DBG('pbranch--> ' || PBRANCH);
    SELECT COUNT(*)
      INTO L_CNT
      FROM CSTB_CLEARING_MASTER
     WHERE REM_ACCOUNT = L_REM_ACCOUNT
       AND INSTRUMENT_NO_1 = L_INSTRUMENT_NO
       AND ROUTING_NO = L_ROUTING_NO
       AND TXN_BRANCH = PBRANCH
       AND STATUS <> 'REVR';
  
    DBG('l_cnt--> ' || L_CNT);
  
    IF L_CNT > 1 THEN
      BEGIN
        SELECT *
          INTO L_REJ_REC
          FROM CSTBS_CLEARING_MASTER
         WHERE REM_ACCOUNT = L_REM_ACCOUNT
           AND ROUTING_NO = L_ROUTING_NO
           AND INSTRUMENT_NO_1 = L_INSTRUMENT_NO
           AND TXN_BRANCH = PBRANCH
           AND STATUS = 'SUCC';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('CG',
                         'No Data Found for Ref.No. - ' ||
                         L_REJ_REC.REFERENCE_NO);
          P_ERR_CODE := 'CG-CL0014';
          RETURN FALSE;
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('CG', 'Exception raised -' || SQLERRM);
          RETURN FALSE;
      END;
    ELSE
    
      BEGIN
        SELECT *
          INTO L_REJ_REC
          FROM CSTBS_CLEARING_MASTER
         WHERE REM_ACCOUNT = L_REM_ACCOUNT
           AND ROUTING_NO = L_ROUTING_NO
           AND INSTRUMENT_NO_1 = L_INSTRUMENT_NO
           AND TXN_BRANCH = PBRANCH
           AND STATUS <> 'REVR';
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('CG',
                         'No Data Found for Ref.No. - ' ||
                         L_REJ_REC.REFERENCE_NO);
          P_ERR_CODE := 'CG-CL0014';
          RETURN FALSE;
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('CG', 'Exception raised -' || SQLERRM);
          RETURN FALSE;
      END;
    END IF;
  
    DBG('23541461***rbpks_clearing.g_ref_no--> ' ||
        RBPKS_CLEARING.G_REF_NO);
    DBG('l_rej_rec.xref--> ' || L_REJ_REC.XREF);
    IF L_REJ_REC.MODULE_CODE = 'RB' THEN
      DBG('Assigning RB xref..');
      RBPKS_CLEARING.G_REF_NO := L_REJ_REC.XREF;
    END IF;
    DBG('rbpks_clearing.g_ref_no--> ' || RBPKS_CLEARING.G_REF_NO);
  
    IF L_REJ_REC.MODULE_CODE IN ('CG', 'TD', 'CL', 'PD')
    
     THEN
      IF L_REJ_REC.STATUS <> 'SUCC' THEN
        DEBUG.PR_DEBUG('CG',
                       'This record is already reversed or rejected...');
        P_ERR_CODE := 'CG-CL0018';
        RETURN FALSE;
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        GLOBAL.PR_RESET_SKIP_KERNEL;
        DBG('calling cspks_clg_serv_cluster.fn_process_oc_rejects');
        L_CALL_FUNC_ID    := 2;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      
        L_TB_CLUSTER_DATA('p_xref') := L_REJ_REC.XREF;
        L_TB_CLUSTER_DATA('p_fccref') := L_REJ_REC.REFERENCE_NO;
        L_TB_CLUSTER_DATA('p_status') := L_REJ_REC.STATUS;
      
        IF NOT
            CSPKS_CLG_SERV_CLUSTER.FN_PROCESS_OC_REJECTS(PBRANCH,
                                                         P_REJ_COL_LIST,
                                                         P_REJ_DATA_STRING,
                                                         P_XREF,
                                                         P_FCCREF,
                                                         P_STATUS,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAM,
                                                         P_ONLINE_AUTH,
                                                         L_CALL_FUNC_ID,
                                                         L_TB_CLUSTER_DATA) THEN
          DEBUG.PR_DEBUG('CG', 'Failed in fn_process_oc_rejects');
          RETURN FALSE;
        END IF;
      
        L_REJ_REC.XREF         := L_TB_CLUSTER_DATA('p_xref');
        L_REJ_REC.REFERENCE_NO := L_TB_CLUSTER_DATA('p_fccref');
        L_REJ_REC.STATUS       := L_TB_CLUSTER_DATA('p_status');
      
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        DEBUG.PR_DEBUG('CG',
                       'l_rej_rec.direcion...' || L_REJ_REC.DIRECTION);
      
        IF L_REJ_REC.VAL_DATE_CUST < GLOBAL.APPLICATION_DATE THEN
          DEBUG.PR_DEBUG('CG', 'This record is already Cleared...');
          P_ERR_CODE := 'CG-CL0031';
          RETURN FALSE;
        END IF;
      
      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;
    
      IF NOT FN_BACKUP_CLG_TABLES(L_REJ_REC.REFERENCE_NO) THEN
        DEBUG.PR_DEBUG('CG', 'Backup not successful');
        RETURN FALSE;
      END IF;
      UPDATE CGTBS_TRANSACTION_MASTER
         SET STATUS           = 'Rejected',
             AUTH_STAT        = 'U',
             CHECKER_ID       = '',
             CHECKER_DT_STAMP = '',
             MAKER_ID         = GLOBAL.USER_ID,
             MAKER_DT_STAMP   = L_MAKER_DT_STAMP
       WHERE TRANSACTION_REF_NO = L_REJ_REC.XREF;
    
      DBG('product_code-->' || L_REJ_REC.PRODUCT_CODE);
      BEGIN
        SELECT NVL(DEFER_LIQUIDATION, 'N')
          INTO L_DEFER_LIQUIDATION
          FROM CGTMS_PRODUCT_REFERRAL
         WHERE PRODUCT_CODE = L_REJ_REC.PRODUCT_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_CODE  := 'CG-PROD-001';
          P_ERR_PARAM := L_REJ_REC.PRODUCT_CODE;
      END;
      DBG('l_defer_liquidation-->' || L_DEFER_LIQUIDATION);
      DBG('Direction          -->' || L_REJ_REC.DIRECTION);
      DBG('FILE_CONSOL_STATUS-->' || L_REJ_REC.FILE_CONSOL_STATUS);
      DBG('l_defer_liquidation-->' || L_DEFER_LIQUIDATION);
      IF L_REJ_REC.DIRECTION = 'O' AND NVL(L_DEFER_LIQUIDATION, 'N') = 'N' AND
         NVL(L_REJ_REC.FILE_CONSOL_STATUS, 'N') = 'Y'
      
       THEN
      
        DBG('l_rej_rec.val_date_cust--->' || L_REJ_REC.VAL_DATE_CUST);
        DBG('global.application_date--->' || GLOBAL.APPLICATION_DATE);
        IF L_REJ_REC.VAL_DATE_CUST >= GLOBAL.APPLICATION_DATE THEN
          DBG('Funds are in uncollected. Need to move from uncollected before passing RETN event');
          IF NOT ACPKS_EOD.FN_DRPUNCOL(L_REJ_REC.ACC_BRANCH,
                                       L_REJ_REC.BEN_ACCOUNT,
                                       L_REJ_REC.REFERENCE_NO,
                                       P_ERR_CODE,
                                       'N') THEN
            DBG('Failed in fn_drpUncol');
          END IF;
        END IF;
      
        DBG('Calling function FN_INWARD_RETURN_ENT for posting RETN entries for Inward returns');
        IF NOT FN_INWARD_RETURN_ENT(L_REJ_REC,
                                    L_XREF,
                                    L_BRANCH_CODE,
                                    L_CHQ_RETURN_AMT,
                                    L_REJECT_CODE,
                                    L_TOT_CHG_AMT,
                                    P_ERR_CODE,
                                    P_ERR_PARAM,
                                    P_ONLINE_AUTH) THEN
          DBG('Failed in Accounting Reversal');
          RETURN FALSE;
        END IF;
        IF L_REJ_REC.MODULE_CODE IN ('PD') THEN
          IF NOT FN_REVERSE_PDC(PBRANCH,
                                L_REJ_REC.MODULE_REFERENCE_NO,
                                L_REMARKS,
                                P_ERR_CODE,
                                P_ERR_PARAM) THEN
            DEBUG.PR_DEBUG('CG', 'Error while calling fn_reverse_txn');
            RETURN FALSE;
          END IF;
        END IF;
      ELSE
      
        IF L_REJ_REC.MODULE_CODE IN ('PD') THEN
          IF NOT FN_REVERSE_TXN(PBRANCH,
                                L_REJ_REC.MODULE_REFERENCE_NO,
                                P_ERR_CODE,
                                P_ERR_PARAM) THEN
            DEBUG.PR_DEBUG('CG', 'Error while calling fn_reverse_txn');
            RETURN FALSE;
          END IF;
        ELSE
          DEBUG.PR_DEBUG('CG', 'Reverse 3');
          IF NOT FN_REVERSE_ACCT(L_REJ_REC.REFERENCE_NO,
                                 P_ERR_CODE,
                                 P_ERR_PARAM,
                                 P_ONLINE_AUTH) THEN
            DEBUG.PR_DEBUG('CG', 'Failed in Accounting Reversal');
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    
      DBG('l_reject_code--->>>' || L_REJECT_CODE);
      L_TB_REJREASON(1) := L_REJECT_CODE;
    
      DBG('l_rej_rec.Acc_Branch ----->>>>>' || L_REJ_REC.ACC_BRANCH);
      DBG('l_rej_rec.Ben_Account ----->>>>>' || L_REJ_REC.BEN_ACCOUNT);
    
      DBG('l_rej_rec.Direction-->' || L_REJ_REC.DIRECTION);
      DBG('l_rej_rec.Rem_Account-->' || L_REJ_REC.REM_ACCOUNT);
      DBG('l_rej_rec.Ben_Account-->' || L_REJ_REC.BEN_ACCOUNT);
      IF L_REJ_REC.DIRECTION = 'I' THEN
        L_REJECT_ACCOUNT := L_REJ_REC.REM_ACCOUNT;
      ELSE
        L_REJECT_ACCOUNT := L_REJ_REC.BEN_ACCOUNT;
      END IF;
      DBG('l_reject_account-->' || L_REJECT_ACCOUNT);
    
      DBG('gwpks_util.pkg_func: ' || GWPKS_UTIL.PKG_FUNC);
      IF NOT CVPKS_UPLOAD_CG_REJECT.G_UPLOAD THEN
        IF NVL(CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID'), '$$$') NOT IN
           ('CGDCLGDT', 'IFDCLGDT') THEN
          IF NOT CGPKS_CGDCLGDT_KERNEL.FN_CHG_REJECT(L_TB_REJREASON,
                                                     L_REJ_REC.ACC_BRANCH
                                                     
                                                    ,
                                                     L_REJECT_ACCOUNT,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAM) THEN
          
            DBG('Error in calculating the Charge for Reject Reason');
          END IF;
        END IF;
      END IF;
      DBG('Charge entry done');
    
    ELSIF L_REJ_REC.MODULE_CODE IN ('UP', 'DE') THEN
      DBG('calling cspkss_clg_services.fn_reverse_txn for module--> ' ||
          L_REJ_REC.MODULE_CODE);
      IF NOT CSPKSS_CLG_SERVICES.FN_REVERSE_TXN(L_REJ_REC.MODULE_REFERENCE_NO,
                                                'F',
                                                L_REJ_REC.MODULE_CODE,
                                                L_REJ_REC.EVENT_SEQ_NO,
                                                GLOBAL.USER_ID,
                                                P_ERR_CODE,
                                                P_ERR_PARAM) THEN
        DEBUG.PR_DEBUG('CG',
                       'Error while calling cspkss_clg_services.fn_reverse_txn');
        RETURN FALSE;
      END IF;
    
    END IF;
  
    DBG('Module_Reference_No >>>' || L_REJ_REC.MODULE_REFERENCE_NO);
    DBG('event_seq_no >>>' || L_REJ_REC.EVENT_SEQ_NO);
    BEGIN
      SELECT COD_REFERENCE_NO
        INTO L_COD_REFERENCE_NO
        FROM UPTBS_PTXN_LOG
       WHERE COD_EXT_REFERENCE_NO = L_REJ_REC.XREF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_COD_REFERENCE_NO := NULL;
        DBG('No datat found l_Cod_Reference_No >>');
    END;
    IF L_COD_REFERENCE_NO IS NOT NULL THEN
      IF NOT CSPKSS_CLG_SERVICES.FN_REVERSE_TXN(L_COD_REFERENCE_NO,
                                                'F',
                                                'UP',
                                                L_REJ_REC.EVENT_SEQ_NO,
                                                GLOBAL.USER_ID,
                                                P_ERR_CODE,
                                                P_ERR_PARAM) THEN
        DEBUG.PR_DEBUG('CG',
                       'Error while calling cspkss_clg_services.fn_reverse_txn');
        RETURN FALSE;
      END IF;
    END IF;
  
    L_REJ_REC.STATUS := 'REJR';
    SELECT EVENT_SEQ_NO
      INTO L_EVENT_SEQ_NO
      FROM CSTBS_CLEARING_MASTER
     WHERE REFERENCE_NO = L_REJ_REC.REFERENCE_NO;
    DEBUG.PR_DEBUG('CG', 'Last event seq no was ' || L_EVENT_SEQ_NO);
    L_EVENT_SEQ_NO := L_EVENT_SEQ_NO + 1;
  
    DBG('To check the reject string here--->' || P_REJ_DATA_STRING);
    L_REMARKS := CSPKES_MISC.FN_GETPARAM(P_REJ_DATA_STRING, 20, '~');
    DBG('l_remarks-->' || L_REMARKS);
    DBG('Event Seq No   ->' || L_EVENT_SEQ_NO || 'g_event_seq  ->' ||
        G_EVENT_SEQ);
    DBG('Reference No   ->' || L_REJ_REC.REFERENCE_NO);
  
    IF P_ONLINE_AUTH <> 'Y' THEN
      UPDATE CSTBS_CLEARING_MASTER
         SET REJECT_REASON    = L_REJECT_REASON,
             REJECT_CODE      = L_REJECT_CODE,
             STATUS           = L_REJ_REC.STATUS,
             EVENT_SEQ_NO     = L_EVENT_SEQ_NO,
             AUTH_STAT        = 'U',
             CHECKER_ID       = '',
             CHECKER_DT_STAMP = '',
             MAKER_ID         = GLOBAL.USER_ID,
             MAKER_DT_STAMP   = L_MAKER_DT_STAMP,
             REMARKS          = L_REMARKS
             
            ,
             CHEQUE_RETN_AMT  = NVL(L_CHQ_RETURN_AMT, 0),
             PRESENT_BANK_CHG = NVL(L_TOT_CHG_AMT, 0)
      
       WHERE REFERENCE_NO = L_REJ_REC.REFERENCE_NO;
      DEBUG.PR_DEBUG('CG', 'Reverse 1');
    
      UPDATE IFTB_CLEARING_UPLOAD
         SET REJ_REASON_CODE  = L_REJECT_CODE,
             STATUS           = L_REJ_REC.STATUS,
             REMARKS          = L_REMARKS,
             AUTH_STAT        = 'U',
             CHECKER_ID       = '',
             CHECKER_DT_STAMP = '',
             MAKER_ID         = GLOBAL.USER_ID,
             MAKER_DT_STAMP   = L_MAKER_DT_STAMP
             
            ,
             CHEQUE_RETN_AMT  = NVL(L_CHQ_RETURN_AMT, 0),
             PRESENT_BANK_CHG = NVL(L_TOT_CHG_AMT, 0)
      
       WHERE FCCREF = L_REJ_REC.REFERENCE_NO;
      DEBUG.PR_DEBUG('CG', 'Reverse 1 iftb');
    
      IF L_REJ_REC.MODULE_CODE NOT IN ('PD') THEN
        BEGIN
          DEBUG.PR_DEBUG('CG',
                         'Going to insert cstbs_clearing_details--> ' ||
                         G_EVENT_SEQ);
          DBG('g_event_seq' || G_EVENT_SEQ || '~' || L_REJ_REC.XREF);
          INSERT INTO CSTBS_CLEARING_DETAILS
            (DIRECTION,
             PRODUCT_CODE,
             TXN_BRANCH,
             END_POINT,
             REFERENCE_NO,
             REM_ACCOUNT,
             BEN_ACCOUNT,
             ACC_BRANCH,
             INSTRUMENT_NO_1,
             BRANCH_CODE,
             SECTOR_CODE,
             XREF,
             EVENT_SEQ_NO,
             REMARKS,
             STATUS,
             ENTRY_NO)
          VALUES
            (L_REJ_REC.DIRECTION,
             L_REJ_REC.PRODUCT_CODE,
             L_REJ_REC.TXN_BRANCH,
             L_REJ_REC.END_POINT,
             L_REJ_REC.REFERENCE_NO,
             L_REJ_REC.REM_ACCOUNT,
             L_REJ_REC.BEN_ACCOUNT,
             L_REJ_REC.ACC_BRANCH,
             L_REJ_REC.INSTRUMENT_NO_1,
             L_REJ_REC.BRANCH_CODE,
             L_REJ_REC.SECTOR_CODE,
             L_REJ_REC.XREF,
             
             NVL(G_EVENT_SEQ, L_EVENT_SEQ_NO),
             
             L_REMARKS,
             L_REJ_REC.STATUS,
             L_REJ_REC.ENTRY_NO + 1);
          DEBUG.PR_DEBUG('CG',
                         'Inserted into cstbs_clearing_details--> ' ||
                         SQL%ROWCOUNT);
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CG',
                           'problem in inserting into cstbs_clearing_details6' ||
                           SQLERRM);
            RETURN FALSE;
        END;
      
      END IF;
    
    ELSE
      UPDATE CSTBS_CLEARING_MASTER
         SET REJECT_REASON = L_REJECT_REASON,
             STATUS        = L_REJ_REC.STATUS,
             REJECT_CODE   = L_REJECT_CODE,
             REMARKS       = L_REMARKS
             
            ,
             CHEQUE_RETN_AMT  = NVL(L_CHQ_RETURN_AMT, 0),
             PRESENT_BANK_CHG = NVL(L_TOT_CHG_AMT, 0)
      
       WHERE REFERENCE_NO = L_REJ_REC.REFERENCE_NO;
      DEBUG.PR_DEBUG('CG', 'Reverse 2');
    
      UPDATE IFTB_CLEARING_UPLOAD
         SET REJ_REASON_CODE = L_REJECT_CODE,
             STATUS          = L_REJ_REC.STATUS,
             REMARKS         = L_REMARKS
             
            ,
             CHEQUE_RETN_AMT  = NVL(L_CHQ_RETURN_AMT, 0),
             PRESENT_BANK_CHG = NVL(L_TOT_CHG_AMT, 0)
      
       WHERE FCCREF = L_REJ_REC.REFERENCE_NO;
    
      DEBUG.PR_DEBUG('CG',
                     'Going to insert cstbs_clearing_details2 --> ' ||
                     G_EVENT_SEQ);
      IF L_REJ_REC.MODULE_CODE NOT IN ('PD') THEN
        BEGIN
          DBG('g_event_seq' || G_EVENT_SEQ || '~' || L_REJ_REC.XREF);
          INSERT INTO CSTBS_CLEARING_DETAILS
            (DIRECTION,
             PRODUCT_CODE,
             TXN_BRANCH,
             END_POINT,
             REFERENCE_NO,
             REM_ACCOUNT,
             BEN_ACCOUNT,
             ACC_BRANCH,
             INSTRUMENT_NO_1,
             BRANCH_CODE,
             SECTOR_CODE,
             XREF,
             EVENT_SEQ_NO,
             REMARKS,
             STATUS,
             ENTRY_NO)
          VALUES
            (L_REJ_REC.DIRECTION,
             L_REJ_REC.PRODUCT_CODE,
             L_REJ_REC.TXN_BRANCH,
             L_REJ_REC.END_POINT,
             L_REJ_REC.REFERENCE_NO,
             L_REJ_REC.REM_ACCOUNT,
             L_REJ_REC.BEN_ACCOUNT,
             L_REJ_REC.ACC_BRANCH,
             L_REJ_REC.INSTRUMENT_NO_1,
             L_REJ_REC.BRANCH_CODE,
             L_REJ_REC.SECTOR_CODE,
             L_REJ_REC.XREF,
             NVL(G_EVENT_SEQ, L_EVENT_SEQ_NO),
             L_REMARKS,
             L_REJ_REC.STATUS,
             L_REJ_REC.ENTRY_NO + 1);
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CG',
                           'problem in inserting into cstbs_clearing_details3' ||
                           SQLERRM);
            RETURN FALSE;
        END;
      END IF;
    
    END IF;
  
    IF L_REJ_REC.NOTIFY_RETN_TO_MODULE = 'Y' THEN
      BEGIN
        UPDATE CGTB_MODULE_CHQ_STATUS
           SET STATUS = 'R'
         WHERE REFERENCE_NO = L_REJ_REC.REFERENCE_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('cspks_clg_serv ==> ' || 'This transaction does not exist');
          P_ERR_CODE := 'CG-CL0014';
          RETURN FALSE;
      END;
    END IF;
  
    P_XREF   := L_REJ_REC.XREF;
    P_FCCREF := L_REJ_REC.REFERENCE_NO;
    P_STATUS := L_REJ_REC.STATUS;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'Exception in fn_process_oc_rejects...' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_PROCESS_OC_REJECTS;

  FUNCTION FN_PROCESS_REVERSALS(PBRANCH           IN VARCHAR2,
                                P_REV_COL_LIST    IN VARCHAR2,
                                P_REV_DATA_STRING IN VARCHAR2,
                                P_XREF            OUT VARCHAR2,
                                P_FCCREF          OUT VARCHAR2,
                                P_STATUS          OUT VARCHAR2,
                                P_ERR_CODE        OUT VARCHAR2,
                                P_ERR_PARAM       OUT VARCHAR2,
                                P_ONLINE_AUTH     IN CHAR,
                                P_CONSOL_REF_NO   IN VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN IS
    L_REV_REC        CSTBS_CLEARING_MASTER%ROWTYPE;
    L_ERR_CODE       ERTBS_MSGS.ERR_CODE%TYPE;
    L_XREF           CSTBS_CLEARING_MASTER.XREF%TYPE;
    L_EVENT_SEQ_NO   NUMBER;
    L_MAKER_DT_STAMP DATE;
    L_REASON         STTBS_REFERRAL_QUEUE.REASON%TYPE;
    CURSOR REV_RECS(P_XREF VARCHAR2) IS
      SELECT *
        FROM CSTBS_CLEARING_MASTER
       WHERE XREF = P_XREF
         AND REFERENCE_NO = NVL(P_FCCREF, REFERENCE_NO);
  
  BEGIN
    IF P_REV_DATA_STRING IS NULL THEN
      DEBUG.PR_DEBUG('CG', 'Reversal Data String is null');
      P_ERR_CODE := 'CG-CL0015';
      RETURN FALSE;
    END IF;
    IF NOT FN_READ_REV_DATA_STRING(P_REV_DATA_STRING,
                                   P_REV_COL_LIST,
                                   L_XREF,
                                   L_ERR_CODE) THEN
      DEBUG.PR_DEBUG('CG', 'fn_read_rev_data_string - RETURN FALSE');
      P_ERR_CODE := L_ERR_CODE;
      RETURN FALSE;
    END IF;
    DEBUG.PR_DEBUG('CG', 'Xref is ..' || L_XREF);
    FOR X IN REV_RECS(L_XREF) LOOP
      DEBUG.PR_DEBUG('CG',
                     'Reference no for reversal is ...' || X.REFERENCE_NO);
      IF (X.STATUS <> 'SUCC') THEN
        DEBUG.PR_DEBUG('CG', 'This record is already reversed or rejected');
        P_ERR_CODE := 'CG-CL0018';
        RETURN FALSE;
      END IF;
      IF NOT FN_BACKUP_CLG_TABLES(X.REFERENCE_NO) THEN
        DEBUG.PR_DEBUG('CG', 'Backup not successful');
        RETURN FALSE;
      END IF;
      L_MAKER_DT_STAMP := CEPKSS_DATE.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE);
    
      BEGIN
        DBG('selecting reason code given in referral queue..');
        SELECT REASON
          INTO L_REASON
          FROM STTBS_REFERRAL_QUEUE
         WHERE CONTRACT_REF_NO = X.REFERENCE_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Inside exception..');
          L_REASON := NULL;
      END;
    
      DBG('##cspks_charge.g_instrno--> ' || CSPKS_CHARGE.G_INSTRNO);
      DBG('x.instrument_no_1--> ' || X.INSTRUMENT_NO_1);
      CSPKS_CHARGE.G_INSTRNO := X.INSTRUMENT_NO_1;
      DBG('cspks_charge.g_instrno--> ' || CSPKS_CHARGE.G_INSTRNO);
    
      UPDATE CGTBS_TRANSACTION_MASTER
         SET STATUS           = 'Rejected',
             AUTH_STAT        = 'U',
             CHECKER_ID       = '',
             CHECKER_DT_STAMP = '',
             MAKER_ID         = GLOBAL.USER_ID,
             MAKER_DT_STAMP   = L_MAKER_DT_STAMP
      
       WHERE TRANSACTION_REF_NO = X.REFERENCE_NO;
      IF NOT FN_REVERSE_ACCT(X.REFERENCE_NO,
                             P_ERR_CODE,
                             P_ERR_PARAM,
                             P_ONLINE_AUTH,
                             P_CONSOL_REF_NO) THEN
        DEBUG.PR_DEBUG('CG', 'Failed in Accounting Reversal');
        RETURN FALSE;
      END IF;
    
      L_REV_REC.STATUS := 'REJR';
      DBG('!!!l_rev_rec.status--> ' || L_REV_REC.STATUS);
    
      SELECT EVENT_SEQ_NO
        INTO L_EVENT_SEQ_NO
        FROM CSTBS_CLEARING_MASTER
       WHERE REFERENCE_NO = X.REFERENCE_NO;
      DEBUG.PR_DEBUG('CG', 'Last event seq no was ' || L_EVENT_SEQ_NO);
      L_EVENT_SEQ_NO := L_EVENT_SEQ_NO + 1;
      UPDATE CSTBS_CLEARING_MASTER
         SET STATUS           = L_REV_REC.STATUS,
             REMARKS          = L_REV_REC.REMARKS,
             EVENT_SEQ_NO     = L_EVENT_SEQ_NO,
             AUTH_STAT        = 'U',
             CHECKER_ID       = '',
             CHECKER_DT_STAMP = '',
             MAKER_ID         = GLOBAL.USER_ID,
             MAKER_DT_STAMP   = L_MAKER_DT_STAMP
             
            ,
             REVR_DATE = GLOBAL.APPLICATION_DATE
             
            ,
             REJECT_CODE = L_REASON
       WHERE REFERENCE_NO = X.REFERENCE_NO;
    
      BEGIN
        DBG('g_event_seq' || G_EVENT_SEQ || '~' || L_REV_REC.XREF);
      
        DBG('Assigning the value of fccref , ensure its not going as null ');
        L_REV_REC.REFERENCE_NO := X.REFERENCE_NO;
        DBG('Assignment done ,l_rev_rec.reference_no = ' ||
            L_REV_REC.REFERENCE_NO);
      
        DBG('l_event_seq_no--> ' || L_EVENT_SEQ_NO);
        INSERT INTO CSTBS_CLEARING_DETAILS
          (DIRECTION,
           PRODUCT_CODE,
           TXN_BRANCH,
           END_POINT,
           REFERENCE_NO,
           REM_ACCOUNT,
           BEN_ACCOUNT,
           ACC_BRANCH,
           INSTRUMENT_NO_1,
           BRANCH_CODE,
           SECTOR_CODE,
           XREF,
           EVENT_SEQ_NO,
           REMARKS,
           STATUS,
           ENTRY_NO)
        VALUES
          (L_REV_REC.DIRECTION,
           L_REV_REC.PRODUCT_CODE,
           L_REV_REC.TXN_BRANCH,
           L_REV_REC.END_POINT,
           L_REV_REC.REFERENCE_NO,
           L_REV_REC.REM_ACCOUNT,
           L_REV_REC.BEN_ACCOUNT,
           L_REV_REC.ACC_BRANCH,
           L_REV_REC.INSTRUMENT_NO_1,
           L_REV_REC.BRANCH_CODE,
           L_REV_REC.SECTOR_CODE,
           L_REV_REC.XREF,
           
           NVL(G_EVENT_SEQ, L_EVENT_SEQ_NO),
           
           L_REV_REC.REMARKS,
           L_REV_REC.STATUS,
           L_REV_REC.ENTRY_NO + 1);
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('CG',
                         'problem in inserting into cstbs_clearing_details2' ||
                         SQLERRM);
          RETURN FALSE;
      END;
    
      DEBUG.PR_DEBUG('CG', 'Authorizing the txn..');
      IF NOT FN_AUTH_TXN(PBRANCH, X.REFERENCE_NO, P_ERR_CODE, P_ERR_PARAM) THEN
        DEBUG.PR_DEBUG('CG',
                       'Failed in Authorizing the txn  - ' || P_ERR_CODE);
        RETURN FALSE;
      END IF;
    
      IF L_REV_REC.NOTIFY_RETN_TO_MODULE = 'Y' THEN
        BEGIN
          UPDATE CGTB_MODULE_CHQ_STATUS
             SET STATUS = 'R'
           WHERE REFERENCE_NO = L_REV_REC.REFERENCE_NO;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('cspks_clg_serv ==> ' || 'This transaction does not exist');
            P_ERR_CODE := 'CG-CL0014';
            RETURN FALSE;
        END;
      END IF;
    
    END LOOP;
    P_XREF := L_XREF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_process_reversals');
      RETURN FALSE;
  END FN_PROCESS_REVERSALS;

  FUNCTION FN_SAVE_ENTRY(P_ENTRY_COLUMN_LIST IN VARCHAR2,
                         P_ENTRY_DATA_STRING IN VARCHAR2,
                         PDTF                IN VARCHAR2,
                         P_REF_NO            OUT VARCHAR2,
                         P_STATUS            OUT VARCHAR2,
                         P_PROD              OUT VARCHAR2,
                         P_INSTRNO           OUT VARCHAR2,
                         P_ENTRY_NO          OUT VARCHAR2,
                         P_ERROR             OUT VARCHAR2,
                         P_ERROR_PARAM       OUT VARCHAR2,
                         P_ONLINE_AUTH       IN CHAR,
                         P_DEFAULT_MIS       IN CHAR,
                         P_RID               IN VARCHAR2 := 'X',
                         P_FORCE_POST        IN VARCHAR2 DEFAULT 'N',
                         P_UPD_ONL           IN VARCHAR2 DEFAULT 'U',
                         P_CONSOL_REF_NO     IN VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN IS
    L_CLG_DET CSTBS_CLEARING_MASTER%ROWTYPE;
  BEGIN
    IF NOT FN_SAVE_ENTRY(P_ENTRY_COLUMN_LIST,
                         P_ENTRY_DATA_STRING,
                         'Y',
                         'Y',
                         L_CLG_DET,
                         PDTF,
                         P_REF_NO,
                         P_STATUS,
                         P_PROD,
                         P_INSTRNO,
                         P_ENTRY_NO,
                         P_ERROR,
                         P_ERROR_PARAM,
                         P_ONLINE_AUTH,
                         P_DEFAULT_MIS,
                         P_RID,
                         P_FORCE_POST,
                         P_UPD_ONL,
                         P_CONSOL_REF_NO) THEN
      RETURN FALSE;
    ELSE
      RETURN TRUE;
    END IF;
  END FN_SAVE_ENTRY;

  FUNCTION FN_SAVE_ENTRY(P_ENTRY_COLUMN_LIST IN VARCHAR2,
                         P_ENTRY_DATA_STRING IN VARCHAR2,
                         P_READ_FROM_STRING  IN VARCHAR2,
                         P_TO_INS            IN VARCHAR2,
                         P_ENTRY_REC         IN OUT CSTBS_CLEARING_MASTER%ROWTYPE,
                         PDTF                IN VARCHAR2,
                         P_REF_NO            OUT VARCHAR2,
                         P_STATUS            OUT VARCHAR2,
                         P_PROD              OUT VARCHAR2,
                         P_INSTRNO           OUT VARCHAR2,
                         P_ENTRY_NO          OUT VARCHAR2,
                         P_ERROR             OUT VARCHAR2,
                         P_ERROR_PARAM       OUT VARCHAR2,
                         P_ONLINE_AUTH       IN CHAR,
                         P_DEFAULT_MIS       IN CHAR,
                         P_RID               IN VARCHAR2 := 'X',
                         P_FORCE_POST        IN VARCHAR2 DEFAULT 'N',
                         P_UPD_ONL           IN VARCHAR2 DEFAULT 'U',
                         P_CONSOL_REF_NO     IN VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN IS
    PBRANCH           STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_ENTRY_REC       CSTBS_CLEARING_MASTER%ROWTYPE;
    L_NULL_ENTRY_REC  CSTBS_CLEARING_MASTER%ROWTYPE;
    L_ERR_CODE        ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM       ERTBS_MSGS.MESSAGE%TYPE;
    L_CONTRACT_REF_NO CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE;
    L_PRODUCT_TYPE    CSTMS_PRODUCT.PRODUCT_TYPE%TYPE;
    L_STATUS          CHAR(1);
    L_MAKER_DT_STAMP  DATE;
    L_USER            ACTBS_DAILY_LOG.USER_ID%TYPE;
    L_CUSTOMER        STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_CCY             STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_CHG_ROW         IFTMS_ARC_MAINT%ROWTYPE;
    L_AC_OR_GL        STTBS_ACCOUNT.AC_OR_GL%TYPE;
    L_MSGS            VARCHAR2(100);
    L_MSG_TYPE        VARCHAR2(255);
    L_AMOUNT          NUMBER;
    L_COUNT           NUMBER;
    L_TYPE            VARCHAR2(255);
    L_REGCC_AVL       CHAR(1);
    L_ERR             VARCHAR2(32767);
    L_PARAM           VARCHAR2(32767);
    L_SPLIT_AVL       CSTMS_US_REG_PARAM.SPLIT_AVL_NEW_AC%TYPE;
  
    L_PROD_ERR   VARCHAR2(32767);
    L_PROD_PARAM VARCHAR2(32767);
  
    L_ERTYPE VARCHAR2(1);
  
    L_ACC_CCY VARCHAR2(3);
  
    CONSOLIDATION_CHECK EXCEPTION;
    L_CASA_ERROR  VARCHAR2(1) := 'N';
    L_RETURN_TRUE VARCHAR2(1) := 'N';
    L_LCYAMT      NUMBER;
    L_FCYAMT      NUMBER;
    L_EXCHRATE    NUMBER;
    L_AMT         NUMBER;
  
    XCODE      VARCHAR2(32);
    XPARAM     VARCHAR2(64);
    L_RETCODE  VARCHAR2(128);
    L_RETPARAM VARCHAR2(256);
  
    LOC_ERR   VARCHAR2(32767);
    LOC_PARAM VARCHAR2(32767);
  
    LOC_MSGS      VARCHAR2(100);
    LOC_MSG_TYPE  VARCHAR2(255);
    LOC_AMOUNT    NUMBER;
    LOC_COUNT     NUMBER;
    LOC_TYPE      VARCHAR2(255);
    L_ACC_CCY_AMT NUMBER;
    L_ACC_TAB     ACPKSS.TBL_ACHOFF;
  
    TEMPT   NUMBER;
    FCCREF1 VARCHAR2(20);
    I       NUMBER;
  
    L_BRN_AVAILABLE VARCHAR2(1);
  
    L_COUNTRYCODE CSTBS_CLEARING_MASTER.REM_COUNTRY%TYPE;
  
    L_NEGOTIATED_RATE    CSTBS_CLEARING_MASTER.NEGOTIATED_RATE%TYPE;
    L_NEGOTIATION_REF_NO CSTBS_CLEARING_MASTER.NEGOTIATION_REF_NO%TYPE;
    L_EXCH_RATE          IFTB_CLEARING_UPLOAD.EXCH_RATE%TYPE;
    TOT_AMOUNT_DUE       CSTB_AUTO_SETTLE_BLOCK.AMOUNT_DUE%TYPE;
    L_NSF_CCY            STTM_CUST_ACCOUNT.CCY%TYPE;
  
    PERRCODES  VARCHAR2(32767);
    PPARAMS    VARCHAR2(32767);
    L_ERR_TYPE VARCHAR2(1);
  
    L_OVDRAFT_OVDS VARCHAR2(100) := 'EL-LM-00117' || ';' || 'AC-LM-00117' || ';' ||
                                    'AC-OVD02' || ';' || 'AC-OVDLM' || ';' ||
                                    'AC-OVD01' || ';' || 'AC-OVD05' || ';';
  
    L_NON_OVERDRAFT_OVD VARCHAR2(1) := 'N';
  
    L_ERR_VAL      VARCHAR2(32767);
    L_MAIN_ERR_TBL OVPKS.TBL_ERROR;
    L_LOGGED_COUNT NUMBER := 0;
    L_NEW_COUNT    NUMBER := 0;
    L_DUPLICATE    BOOLEAN := FALSE;
  
    M           NUMBER := 0;
    L_DATA      NUMBER(22, 3) := 0;
    L_TEMP_DATA VARCHAR2(100);
  
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_CALL_FUNC_ID          NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_INFO_COUNT NUMBER := 0;
  
    L_CUSTACCREC   STTMS_CUST_ACCOUNT%ROWTYPE;
    L_QUERY_STATUS NUMBER;
  
  BEGIN
    SAVEPOINT SP_IFTB_LOG;
  
    PKG_CASA_ERROR := 'N';
    PKG_ENTRY_REC  := L_NULL_ENTRY_REC;
    PKG_REVR_ENTRY := 'N';
  
    G_FUNDING_PARKING_ACC := NULL;
  
    L_USER           := GLOBAL.USER_ID;
    L_MAKER_DT_STAMP := CEPKSS_DATE.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE);
    DEBUG.PR_DEBUG('CG', 'Inside fn_save_entry');
    IF P_READ_FROM_STRING = 'Y' THEN
      IF P_ENTRY_DATA_STRING IS NULL THEN
        DEBUG.PR_DEBUG('CG', 'Entry Data String is null');
        P_ERROR := 'CG-CL0015';
      
        IF P_CONSOL_REF_NO IS NULL THEN
          RETURN FALSE;
        ELSE
          ROLLBACK TO SP_IFTB_LOG;
          RAISE CONSOLIDATION_CHECK;
        END IF;
      END IF;
    
      IF NOT FN_READ_ENTRY_DATA_STRING(P_ENTRY_DATA_STRING,
                                       P_ENTRY_COLUMN_LIST,
                                       PDTF,
                                       L_ENTRY_REC,
                                       L_ERR_CODE) THEN
        DEBUG.PR_DEBUG('CG', 'fn_read_entry_data_string - RETURN FALSE');
        P_ERROR := L_ERR_CODE;
      
        IF P_CONSOL_REF_NO IS NULL THEN
          RETURN FALSE;
        ELSE
          ROLLBACK TO SP_IFTB_LOG;
          RAISE CONSOLIDATION_CHECK;
        END IF;
      END IF;
    ELSE
      DEBUG.PR_DEBUG('CG', 'Goingt o assign entry rec');
      L_ENTRY_REC := P_ENTRY_REC;
      DEBUG.PR_DEBUG('CG', 'After assigning entry rec');
    END IF;
    PBRANCH := L_ENTRY_REC.TXN_BRANCH;
  
    DEBUG.PR_DEBUG('CG',
                   'Checking for the branch--' || PBRANCH || '~' ||
                   GLOBAL.CURRENT_BRANCH);
  
    DEBUG.PR_DEBUG('CG', 'l_Entry_Rec.Txn_Date:' || L_ENTRY_REC.TXN_DATE);
    DEBUG.PR_DEBUG('CG', 'Pbranch :' || PBRANCH);
    IF PBRANCH = GLOBAL.CURRENT_BRANCH THEN
    
      L_ENTRY_REC.TXN_DATE := NVL(L_ENTRY_REC.TXN_DATE,
                                  GLOBAL.APPLICATION_DATE);
    ELSE
      DEBUG.PR_DEBUG('CG', 'Into teh else part of branch ver');
      SELECT TODAY
        INTO L_ENTRY_REC.TXN_DATE
        FROM STTMS_DATES
       WHERE BRANCH_CODE = PBRANCH;
      DEBUG.PR_DEBUG('CG',
                     'After selecting today ---' || L_ENTRY_REC.TXN_DATE);
    END IF;
  
    DEBUG.PR_DEBUG('CG', 'Calling ovpkss_addon.pr_init');
    IF PKG_ADDON_BRN <> PBRANCH THEN
      OVPKSS_ADDON.PR_INIT(PBRANCH, NVL(GWPKS_UTIL.PKG_FUNC, 'Clearing'));
      PKG_ADDON_BRN := PBRANCH;
    END IF;
    PR_GET_PROD(L_ENTRY_REC.PRODUCT_CODE);
    L_PRODUCT_TYPE := PKG_PROD_REC.PRODUCT_TYPE;
    P_PROD         := L_ENTRY_REC.PRODUCT_CODE;
    P_INSTRNO      := L_ENTRY_REC.INSTRUMENT_NO_1;
    P_ENTRY_NO     := L_ENTRY_REC.ENTRY_NO;
  
    DEBUG.PR_DEBUG('CG', 'Selecting rate code and types');
    DEBUG.PR_DEBUG('CG', 'The product code is -> ' || P_PROD);
  
    BEGIN
      SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
        INTO G_RATE_CODE_PREFERRED, G_RATE_TYPE_PREFERRED
        FROM CSTMS_PRODUCT
       WHERE PRODUCT_CODE = P_PROD;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DEBUG.PR_DEBUG('CG', 'Some problem in maintenance');
    END;
  
    DEBUG.PR_DEBUG('CG',
                   'g_rate_code_preferred is ->' || G_RATE_CODE_PREFERRED);
    DEBUG.PR_DEBUG('CG',
                   'g_rate_type_preferred is -->' || G_RATE_TYPE_PREFERRED);
  
    IF L_ENTRY_REC.REFERENCE_NO IS NULL THEN
      IF NOT FN_GENERATE_REF_NO(PBRANCH, L_ENTRY_REC, L_ERR_CODE) THEN
        DEBUG.PR_DEBUG('CG', 'Failed to generate ref no');
        P_ERROR := L_ERR_CODE;
      
        IF P_CONSOL_REF_NO IS NULL THEN
          RETURN FALSE;
        ELSE
          ROLLBACK TO SP_IFTB_LOG;
          RAISE CONSOLIDATION_CHECK;
        END IF;
      END IF;
      DEBUG.PR_DEBUG('CG', 'fn_generate_ref_no returns true...');
      IF P_RID <> 'X' THEN
      
        DEBUG.PR_DEBUG('CG', 'p_Rid::' || P_RID);
        SELECT COUNT(*)
          INTO TEMPT
          FROM IFTBS_CLEARING_UPLOAD
         WHERE ROWID = P_RID;
        SELECT FCCREF
          INTO FCCREF1
          FROM IFTBS_CLEARING_UPLOAD
         WHERE ROWID = P_RID;
        DBG(' Fccref1::::' || FCCREF1);
        DBG(' COUNT::::' || TEMPT);
      
        UPDATE IFTBS_CLEARING_UPLOAD
           SET FCCREF = L_ENTRY_REC.REFERENCE_NO
         WHERE ROWID = P_RID;
      ELSE
        UPDATE IFTBS_CLEARING_UPLOAD
           SET FCCREF = L_ENTRY_REC.REFERENCE_NO
         WHERE SCODE = L_ENTRY_REC.SCODE
           AND XREF = L_ENTRY_REC.XREF
           AND ENTRY_NO = L_ENTRY_REC.ENTRY_NO;
      END IF;
      DEBUG.PR_DEBUG('CG', 'After updating fccref');
    END IF;
    P_REF_NO := L_ENTRY_REC.REFERENCE_NO;
  
    PR_GET_PROD(L_ENTRY_REC.PRODUCT_CODE);
    L_PRODUCT_TYPE := PKG_PROD_REC.PRODUCT_TYPE;
  
    IF (L_PRODUCT_TYPE = 'OC') THEN
      IF L_ENTRY_REC.BEN_ACCOUNT IS NOT NULL AND
         L_ENTRY_REC.ACC_BRANCH IS NULL THEN
        BEGIN
          SELECT BRANCH_CODE
            INTO L_ENTRY_REC.ACC_BRANCH
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = L_ENTRY_REC.BEN_ACCOUNT;
        EXCEPTION
        
          WHEN OTHERS THEN
            L_ENTRY_REC.ACC_BRANCH := PBRANCH;
        END;
      END IF;
      DEBUG.PR_DEBUG('CG', 'Beneficiary A/c = ' || L_ENTRY_REC.BEN_ACCOUNT);
      DEBUG.PR_DEBUG('CG',
                     'Beneficiary acc_branch = ' || L_ENTRY_REC.ACC_BRANCH);
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_CALL_FUNC_ID    := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      
        L_TB_CLUSTER_DATA('l_entry_rec.ben_account') := L_ENTRY_REC.BEN_ACCOUNT;
        DBG('l_entry_rec.ben_account' ||
            L_TB_CLUSTER_DATA('l_entry_rec.ben_account'));
        L_TB_CLUSTER_DATA('l_entry_rec.scode') := L_ENTRY_REC.SCODE;
        DBG('l_entry_rec.scode' || L_TB_CLUSTER_DATA('l_entry_rec.scode'));
        L_TB_CLUSTER_DATA('l_entry_rec.acc_ccy') := L_ENTRY_REC.ACC_CCY;
        DBG('l_entry_rec.acc_ccy' ||
            L_TB_CLUSTER_DATA('l_entry_rec.acc_ccy'));
      
        IF NOT CSPKS_CLG_SERV_CLUSTER.FN_SAVE_ENTRY(P_ENTRY_COLUMN_LIST,
                                                    P_ENTRY_DATA_STRING,
                                                    P_READ_FROM_STRING,
                                                    P_TO_INS,
                                                    L_ENTRY_REC,
                                                    PDTF,
                                                    P_REF_NO,
                                                    P_STATUS,
                                                    P_PROD,
                                                    P_INSTRNO,
                                                    P_ENTRY_NO,
                                                    P_ERROR,
                                                    P_ERROR_PARAM,
                                                    P_ONLINE_AUTH,
                                                    P_DEFAULT_MIS,
                                                    P_RID,
                                                    P_FORCE_POST,
                                                    P_UPD_ONL,
                                                    P_CONSOL_REF_NO,
                                                    L_CALL_FUNC_ID,
                                                    L_TB_CLUSTER_DATA) THEN
          DBG('Failed in cspks_clg_serv_cluster.fn_save_entry');
        END IF;
      
        IF L_TB_CLUSTER_DATA.EXISTS('l_entry_rec.ben_account') THEN
          L_ENTRY_REC.BEN_ACCOUNT := L_TB_CLUSTER_DATA('l_entry_rec.ben_account');
        END IF;
      END IF;
    
      IF L_ENTRY_REC.ROUTING_NO IS NOT NULL THEN
        IF NOT CGPKS_UPLOAD_UTILS.FN_VALIDATE_ROUTING_NO(L_ENTRY_REC.ROUTING_NO,
                                                         L_ENTRY_REC.BANK_CODE,
                                                         L_ENTRY_REC.BRANCH_CODE,
                                                         L_ENTRY_REC.SECTOR_CODE,
                                                         L_ERR_CODE,
                                                         L_ERR_PARAM) THEN
          DBG('Failed in  fn_validate_routing_no..');
          P_ERROR := L_ERR_CODE;
        
          IF P_CONSOL_REF_NO IS NULL THEN
            RETURN FALSE;
          ELSE
            ROLLBACK TO SP_IFTB_LOG;
            RAISE CONSOLIDATION_CHECK;
          END IF;
        END IF;
      END IF;
    
    ELSIF (L_PRODUCT_TYPE = 'IC') THEN
      DBG('Before Validating the Cheque Details for the Inward Clearing: l_product_type is' ||
          L_PRODUCT_TYPE);
      DBG(' l_entry_rec.acc_branch Is: ' || L_ENTRY_REC.ACC_BRANCH);
      IF L_ENTRY_REC.REM_ACCOUNT IS NOT NULL AND
         L_ENTRY_REC.ACC_BRANCH IS NULL THEN
        BEGIN
          SELECT BRANCH_CODE
            INTO L_ENTRY_REC.ACC_BRANCH
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = L_ENTRY_REC.REM_ACCOUNT;
        EXCEPTION
        
          WHEN OTHERS THEN
            L_ENTRY_REC.ACC_BRANCH := PBRANCH;
        END;
      END IF;
      DBG('Remitter A/c = ' || L_ENTRY_REC.REM_ACCOUNT);
      DBG('Beneficiary acc_branch = ' || L_ENTRY_REC.ACC_BRANCH);
    
      DBG('Cheque Validations in casapks Returned Success');
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('calling cspks_clg_serv_cluster.fn_save_entry');
        L_CALL_FUNC_ID := 2;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('l_ovdraft_ovds') := L_OVDRAFT_OVDS;
        IF NOT CSPKS_CLG_SERV_CLUSTER.FN_SAVE_ENTRY(P_ENTRY_COLUMN_LIST,
                                                    P_ENTRY_DATA_STRING,
                                                    'Y',
                                                    'Y',
                                                    P_ENTRY_REC,
                                                    PDTF,
                                                    P_REF_NO,
                                                    P_STATUS,
                                                    P_PROD,
                                                    P_INSTRNO,
                                                    P_ENTRY_NO,
                                                    P_ERROR,
                                                    P_ERROR_PARAM,
                                                    P_ONLINE_AUTH,
                                                    P_DEFAULT_MIS,
                                                    P_RID,
                                                    P_FORCE_POST,
                                                    P_UPD_ONL,
                                                    P_CONSOL_REF_NO,
                                                    L_CALL_FUNC_ID,
                                                    L_TB_CLUSTER_DATA) THEN
          DEBUG.PR_DEBUG('CG', 'Failed in fn_save_entry');
          RETURN FALSE;
        END IF;
      
        IF L_TB_CLUSTER_DATA.EXISTS('l_ovdraft_ovds') THEN
          L_OVDRAFT_OVDS := L_TB_CLUSTER_DATA('l_ovdraft_ovds');
        END IF;
      
      END IF;
    
    END IF;
  
    IF NOT FN_MANDATORY_CHECK(L_ENTRY_REC, L_ERR_CODE) THEN
      DEBUG.PR_DEBUG('CG', 'fn_mandaory_check returning FALSE ');
      P_ERROR := L_ERR_CODE;
    
      IF P_CONSOL_REF_NO IS NULL THEN
        RETURN FALSE;
      ELSE
        ROLLBACK TO SP_IFTB_LOG;
        RAISE CONSOLIDATION_CHECK;
      END IF;
    END IF;
  
    PR_GET_PROD(L_ENTRY_REC.PRODUCT_CODE);
    L_PRODUCT_TYPE := PKG_PROD_REC.PRODUCT_TYPE;
  
    DBG('Assinging Account Branch ' || L_ENTRY_REC.ACC_BRANCH);
    CSPKSS_CLG_SERVICES.G_CLG_BRANCH_ARC := L_ENTRY_REC.ACC_BRANCH;
    DBG('cspkss_clg_services.g_clg_branch_arc ' || L_ENTRY_REC.ACC_BRANCH);
  
    IF (L_PRODUCT_TYPE = 'IC') THEN
    
      BEGIN
        SELECT CUST_NO
          INTO L_CUSTOMER
          FROM STTMS_CUST_ACCOUNT
         WHERE BRANCH_CODE = L_ENTRY_REC.ACC_BRANCH
           AND CUST_AC_NO = L_ENTRY_REC.BEN_ACCOUNT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
      DEBUG.PR_DEBUG('CG',
                     'This is the rem customer ... ' ||
                     L_ENTRY_REC.REM_CUST);
      DEBUG.PR_DEBUG('CG',
                     'This is the txn_branch ... ' ||
                     L_ENTRY_REC.TXN_BRANCH);
      DEBUG.PR_DEBUG('CG',
                     'This is the product_code ... ' ||
                     L_ENTRY_REC.PRODUCT_CODE);
    
      IF L_ENTRY_REC.ROUTING_NO IS NOT NULL THEN
        IF NOT CGPKS_UPLOAD_UTILS.FN_VALIDATE_ROUTING_NO(L_ENTRY_REC.ROUTING_NO,
                                                         L_ENTRY_REC.BANK_CODE,
                                                         L_ENTRY_REC.BRANCH_CODE,
                                                         L_ENTRY_REC.SECTOR_CODE,
                                                         L_ERR_CODE,
                                                         L_ERR_PARAM) THEN
          DBG('Failed in  fn_validate_routing_no..');
        END IF;
      END IF;
    
      DBG('fn_save_entry ==> Product is IC');
      DBG('Hence Remitter Account for ARC pick up ' ||
          L_ENTRY_REC.REM_ACCOUNT);
      CSPKSS_CLG_SERVICES.G_CLG_ACCOUNT_ARC := L_ENTRY_REC.REM_ACCOUNT;
      DBG(' cspkss_clg_services.g_clg_account_arc ' ||
          CSPKSS_CLG_SERVICES.G_CLG_ACCOUNT_ARC);
    
      IF NOT CSPKSS_CLG_SERVICES.FN_GET_VALUE_DATES(L_ENTRY_REC.BANK_CODE,
                                                    L_ENTRY_REC.BRANCH_CODE,
                                                    L_CUSTOMER,
                                                    L_ENTRY_REC.TXN_BRANCH,
                                                    L_ENTRY_REC.PRODUCT_CODE,
                                                    L_ENTRY_REC.INSTRUMENT_CCY,
                                                    NULL,
                                                    L_ENTRY_REC.END_POINT,
                                                    L_ENTRY_REC.VAL_DATE_BNK,
                                                    L_ENTRY_REC.VAL_DATE_CUST,
                                                    L_ENTRY_REC.LATE_CLG_FLG,
                                                    
                                                    P_ERROR,
                                                    L_ENTRY_REC.TXN_DATE) THEN
        DEBUG.PR_DEBUG('CG', 'Error while calculating value dates');
      
        OVPKS.PR_APPENDTBL(P_ERROR, '');
        IF P_CONSOL_REF_NO IS NULL THEN
          RETURN FALSE;
        ELSE
          ROLLBACK TO SP_IFTB_LOG;
          RAISE CONSOLIDATION_CHECK;
        END IF;
      END IF;
    ELSIF (L_PRODUCT_TYPE = 'OC') THEN
      BEGIN
        SELECT NVL(REG_CC_AVAILABILITY, 'N'), CUST_NO
          INTO L_REGCC_AVL, L_CUSTOMER
          FROM STTMS_CUST_ACCOUNT
         WHERE BRANCH_CODE = L_ENTRY_REC.ACC_BRANCH
           AND CUST_AC_NO = L_ENTRY_REC.BEN_ACCOUNT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
      BEGIN
        SELECT NVL(SPLIT_AVL_NEW_AC, 'N')
          INTO L_SPLIT_AVL
          FROM CSTMS_US_REG_PARAM;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_SPLIT_AVL := 'N';
      END;
      DEBUG.PR_DEBUG('CG', 'reg cc availabilty is -' || L_REGCC_AVL);
      DEBUG.PR_DEBUG('CG', 'split availabilty is -' || L_SPLIT_AVL);
    
      DBG('fn_save_entry ==> Product is OC');
      DBG('Hence Benificiary Account for ARC pick up ' ||
          L_ENTRY_REC.BEN_ACCOUNT);
      CSPKSS_CLG_SERVICES.G_CLG_ACCOUNT_ARC := L_ENTRY_REC.BEN_ACCOUNT;
      DBG(' cspkss_clg_services.g_clg_account_arc ' ||
          CSPKSS_CLG_SERVICES.G_CLG_ACCOUNT_ARC);
    
      IF L_REGCC_AVL = 'Y' THEN
      
        IF NOT CSPKSS_CLG_SERVICES.FN_GET_VALUE_DATES(L_ENTRY_REC.BANK_CODE,
                                                      L_ENTRY_REC.BRANCH_CODE,
                                                      L_CUSTOMER,
                                                      L_ENTRY_REC.TXN_BRANCH,
                                                      L_ENTRY_REC.PRODUCT_CODE,
                                                      L_ENTRY_REC.INSTRUMENT_CCY,
                                                      NULL,
                                                      L_ENTRY_REC.SECTOR_CODE,
                                                      L_ENTRY_REC.VAL_DATE_CUST,
                                                      L_ENTRY_REC.VAL_DATE_BNK,
                                                      L_ENTRY_REC.LATE_CLG_FLG,
                                                      P_ERROR,
                                                      L_ENTRY_REC.TXN_DATE,
                                                      'N',
                                                      'N') THEN
          DEBUG.PR_DEBUG('CG', 'Error while calculating value dates');
          OVPKS.PR_APPENDTBL(P_ERROR, '');
          RETURN FALSE;
        
        END IF;
      ELSE
        IF NVL(L_SPLIT_AVL, 'N') = 'Y' THEN
        
          IF NOT CSPKSS_CLG_SERVICES.FN_GET_VALUE_DATES(L_ENTRY_REC.BANK_CODE,
                                                        L_ENTRY_REC.BRANCH_CODE,
                                                        L_CUSTOMER,
                                                        L_ENTRY_REC.TXN_BRANCH,
                                                        L_ENTRY_REC.PRODUCT_CODE,
                                                        L_ENTRY_REC.INSTRUMENT_CCY,
                                                        NULL,
                                                        L_ENTRY_REC.SECTOR_CODE,
                                                        L_ENTRY_REC.VAL_DATE_CUST,
                                                        L_ENTRY_REC.VAL_DATE_BNK,
                                                        
                                                        L_ENTRY_REC.LATE_CLG_FLG,
                                                        P_ERROR,
                                                        L_ENTRY_REC.TXN_DATE,
                                                        'N',
                                                        'N') THEN
            DEBUG.PR_DEBUG('CG', 'Error while calculating value dates');
            OVPKS.PR_APPENDTBL(P_ERROR, '');
            RETURN FALSE;
          
          END IF;
        ELSIF NVL(L_SPLIT_AVL, 'N') = 'N' THEN
        
          IF NOT CSPKSS_CLG_SERVICES.FN_GET_VALUE_DATES(L_ENTRY_REC.BANK_CODE,
                                                        L_ENTRY_REC.BRANCH_CODE,
                                                        L_CUSTOMER,
                                                        L_ENTRY_REC.TXN_BRANCH,
                                                        L_ENTRY_REC.PRODUCT_CODE,
                                                        L_ENTRY_REC.INSTRUMENT_CCY,
                                                        NULL,
                                                        L_ENTRY_REC.SECTOR_CODE,
                                                        L_ENTRY_REC.VAL_DATE_CUST,
                                                        L_ENTRY_REC.VAL_DATE_BNK,
                                                        L_ENTRY_REC.LATE_CLG_FLG,
                                                        P_ERROR,
                                                        L_ENTRY_REC.TXN_DATE,
                                                        'N',
                                                        'N') THEN
          
            DEBUG.PR_DEBUG('CG', 'Error while calculating value dates');
            OVPKS.PR_APPENDTBL(P_ERROR, '');
            RETURN FALSE;
          
          END IF;
        END IF;
      END IF;
    
      DBG('Late Clearing Flag is' || L_ENTRY_REC.LATE_CLG_FLG);
    
      UPDATE IFTB_CLEARING_UPLOAD
         SET LATECLG = L_ENTRY_REC.LATE_CLG_FLG
       WHERE FCCREF = L_ENTRY_REC.REFERENCE_NO;
    
    END IF;
    IF (L_PRODUCT_TYPE = 'IC') THEN
      DBG('Printing rem account b4 selecing l_ccy -- rem acc is --> ' ||
          L_ENTRY_REC.REM_ACCOUNT);
      DBG('Printing account branch b4 selecing l_ccy -- rem brn is --> ' ||
          L_ENTRY_REC.ACC_BRANCH);
    
      BEGIN
        SELECT CUST_NO, CCY
          INTO L_CUSTOMER, L_CCY
          FROM STTMS_CUST_ACCOUNT
         WHERE CUST_AC_NO = L_ENTRY_REC.REM_ACCOUNT
           AND BRANCH_CODE = L_ENTRY_REC.ACC_BRANCH;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    
      BEGIN
        SELECT COUNTRY
          INTO L_COUNTRYCODE
          FROM STTMS_CUSTOMER
         WHERE CUSTOMER_NO = L_CUSTOMER;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    
      L_ENTRY_REC.REM_CUST := L_CUSTOMER;
    
      L_ENTRY_REC.REM_COUNTRY := L_COUNTRYCODE;
    
      DBG('Printing l_ccy --> ' || L_CCY);
    ELSIF (L_PRODUCT_TYPE = 'OC') THEN
      BEGIN
        SELECT CUST_NO, CCY
          INTO L_CUSTOMER, L_CCY
          FROM STTMS_CUST_ACCOUNT
         WHERE CUST_AC_NO = L_ENTRY_REC.BEN_ACCOUNT
           AND BRANCH_CODE = L_ENTRY_REC.ACC_BRANCH;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    
      BEGIN
        SELECT COUNTRY
          INTO L_COUNTRYCODE
          FROM STTMS_CUSTOMER
         WHERE CUSTOMER_NO = L_CUSTOMER;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    
      L_ENTRY_REC.BEN_CUST := L_CUSTOMER;
    
      L_ENTRY_REC.BENE_COUNTRY := L_COUNTRYCODE;
    
    END IF;
  
    IF L_CCY IS NULL THEN
      L_CCY := L_ENTRY_REC.INSTRUMENT_CCY;
    END IF;
  
    DBG('B4 NULL check and assignment l_entry_rec.acc_ccy is ' ||
        L_ENTRY_REC.ACC_CCY);
  
    L_ENTRY_REC.ACC_CCY := L_CCY;
  
    DBG('l_Entry_Rec.BENE_CCY --> ' || L_ENTRY_REC.BENE_CCY);
    IF L_ENTRY_REC.BENE_CCY IS NOT NULL THEN
      L_ENTRY_REC.ACC_CCY := L_ENTRY_REC.BENE_CCY;
      DBG('ASSIGNED BEN CURRECNY TO ACCOUNT CCY' || L_ENTRY_REC.ACC_CCY);
    END IF;
  
    IF L_ENTRY_REC.ACC_CCY = L_ENTRY_REC.INSTRUMENT_CCY THEN
      L_ENTRY_REC.ACC_CCY_AMT := L_ENTRY_REC.INSTRUMENT_AMT;
      L_ENTRY_REC.EXCH_RATE   := 1;
    ELSE
      L_ENTRY_REC.ACC_CCY_AMT := NULL;
    
      L_ENTRY_REC.EXCH_RATE := NULL;
    END IF;
  
    DBG('After final assignment --> ' || L_ENTRY_REC.ACC_CCY);
    DBG('l_entry_rec.exch_rate --> ' || L_ENTRY_REC.EXCH_RATE);
  
    IF L_ENTRY_REC.EXCH_RATE IS NULL THEN
    
      BEGIN
        SELECT EXCH_RATE
          INTO L_EXCH_RATE
          FROM IFTB_CLEARING_UPLOAD
         WHERE XREF = L_ENTRY_REC.XREF
           AND ENTRY_NO = L_ENTRY_REC.ENTRY_NO;
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found in cstb_clearing_master');
          P_ERROR := 'CG-CL0014';
          RETURN FALSE;
        
      END;
    
      L_ENTRY_REC.EXCH_RATE := L_EXCH_RATE;
    END IF;
    DBG('Now l_entry_rec.exch_rate = ' || L_ENTRY_REC.EXCH_RATE);
  
    DBG('l_entry_rec.acc_ccy_amt --> ' || L_ENTRY_REC.ACC_CCY_AMT);
  
    IF ((L_ENTRY_REC.ACC_CCY <> L_ENTRY_REC.INSTRUMENT_CCY) AND
       (L_ENTRY_REC.ACC_CCY_AMT IS NULL)) THEN
      IF NOT CYPKSS.FN_AMT1_TO_AMT2(L_ENTRY_REC.ACC_BRANCH,
                                    L_ENTRY_REC.INSTRUMENT_CCY,
                                    L_ENTRY_REC.ACC_CCY
                                    
                                   ,
                                    NVL(G_RATE_TYPE_PREFERRED, 'STANDARD')
                                    
                                   ,
                                    NVL(G_RATE_CODE_PREFERRED, 'M')
                                    
                                   ,
                                    L_ENTRY_REC.INSTRUMENT_AMT,
                                    'Y',
                                    L_ENTRY_REC.ACC_CCY_AMT,
                                    L_ENTRY_REC.EXCH_RATE,
                                    L_ERR_CODE) THEN
        DEBUG.PR_DEBUG('CG',
                       'Failure in converting instr amt to ac ccy amt');
        P_ERROR := L_ERR_CODE;
      
        IF P_CONSOL_REF_NO IS NULL THEN
          RETURN FALSE;
        ELSE
          ROLLBACK TO SP_IFTB_LOG;
          RAISE CONSOLIDATION_CHECK;
        END IF;
      END IF;
    ELSIF (L_ENTRY_REC.ACC_CCY_AMT IS NULL) THEN
      L_ENTRY_REC.ACC_CCY_AMT := L_ENTRY_REC.INSTRUMENT_AMT;
      L_ENTRY_REC.EXCH_RATE   := 1;
    END IF;
  
    DEBUG.PR_DEBUG('CG', 'B4 charge pick up');
  
    IF NOT FN_ARC_PICKUP(PBRANCH,
                         L_ENTRY_REC,
                         L_CHG_ROW,
                         P_ERROR,
                         P_ERROR_PARAM) THEN
      DEBUG.PR_DEBUG('CG', 'Failed in arc pick up in fn_save_entry');
    
      IF P_CONSOL_REF_NO IS NULL THEN
        RETURN FALSE;
      ELSE
        ROLLBACK TO SP_IFTB_LOG;
        RAISE CONSOLIDATION_CHECK;
      END IF;
    END IF;
  
    DEBUG.PR_DEBUG('CG', 'Charge pick up successful');
  
    BEGIN
      SELECT BRN_AVAIL_STAT
        INTO L_BRN_AVAILABLE
        FROM STTM_BRANCH
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
    
      IF NVL(L_BRN_AVAILABLE, 'Y') = 'N' OR
         L_ENTRY_REC.TXN_DATE > GLOBAL.APPLICATION_DATE THEN
        L_ENTRY_REC.TXN_TANKED := 'Y';
      ELSE
        L_ENTRY_REC.TXN_TANKED := 'N';
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('any way this will never happen');
        RETURN FALSE;
    END;
  
    DBG('charge details is-->' || GWPKS_UTIL.PKG_CHG_DETS);
  
    DBG('Beneficiary account is-->' || L_ENTRY_REC.BEN_ACCOUNT);
    DBG('Beneficiary branch is-->' || L_ENTRY_REC.ACC_BRANCH);
    IF NOT CVPKSS_UTILS.FN_GET_CUST_ACC_RECORD(L_ENTRY_REC.BEN_ACCOUNT,
                                               L_ENTRY_REC.ACC_BRANCH,
                                               L_QUERY_STATUS,
                                               L_CUSTACCREC) THEN
      DBG('Failed in getting cust details');
    END IF;
    DBG('waiver check-->' || L_CUSTACCREC.DEFAULT_WAIVER);
    IF L_CUSTACCREC.DEFAULT_WAIVER = 'Y' THEN
      DBG('Waiver present at customer account level. hence no charges');
      L_ENTRY_REC.CHG_AMT := NULL;
    ELSE
    
      IF GWPKS_UTIL.PKG_CHG_DETS IS NOT NULL THEN
        M := 1;
        WHILE M <= 9 LOOP
          DBG('inside this-->' || M);
          L_TEMP_DATA := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS, M);
        
          IF L_TEMP_DATA = 'EOPL' THEN
            EXIT;
          END IF;
          TB_CHG_AMT(M).CHG_AMOUNT := TO_NUMBER(L_TEMP_DATA);
          DBG('after this-->' || TB_CHG_AMT(M).CHG_AMOUNT);
        
          M := M + 2;
        
        END LOOP;
      END IF;
    
      DBG('here 1');
      IF TB_CHG_AMT.EXISTS(1) THEN
        DBG('assigning this-->' || TB_CHG_AMT(1).CHG_AMOUNT || '~' ||
            L_ENTRY_REC.CHG_AMT);
        IF TB_CHG_AMT(1).CHG_AMOUNT <> L_CHG_ROW.COD_CHG_AMT THEN
          L_ENTRY_REC.CHG_AMT := TB_CHG_AMT(1).CHG_AMOUNT;
        ELSE
          L_ENTRY_REC.CHG_AMT := L_CHG_ROW.COD_CHG_AMT;
        END IF;
      ELSE
      
        L_ENTRY_REC.LCY_CHG_AMT := L_ENTRY_REC.CHG_AMT;
      
        L_ENTRY_REC.CHG_AMT := L_CHG_ROW.COD_CHG_AMT;
      END IF;
      DBG('#l_entry_rec.chg_amt--> ' || L_ENTRY_REC.CHG_AMT);
      DBG('l_entry_rec.lcy_chg_amt--> ' || L_ENTRY_REC.LCY_CHG_AMT);
      L_ENTRY_REC.CHG_CCY          := L_CHG_ROW.COD_CHG_CCY;
      L_ENTRY_REC.CHG_DESC         := L_CHG_ROW.COD_CHG_DESC;
      L_ENTRY_REC.CHGCCY_LCY_XRATE := L_CHG_ROW.COD_CHG_RATE;
      DBG('l_entry_rec.chg_amt IS ' || L_ENTRY_REC.CHG_AMT);
      IF TB_CHG_AMT.EXISTS(3) THEN
        DBG('tb_chg_amt(3).chg_amount is-->' || TB_CHG_AMT(3).CHG_AMOUNT || '~' ||
            L_CHG_ROW.COD_CHG_AMT1);
        IF TB_CHG_AMT(3).CHG_AMOUNT <> L_CHG_ROW.COD_CHG_AMT1 THEN
          L_ENTRY_REC.CHG_AMT1 := TB_CHG_AMT(3).CHG_AMOUNT;
        ELSE
          L_ENTRY_REC.CHG_AMT1 := L_CHG_ROW.COD_CHG_AMT1;
        END IF;
      ELSE
      
        L_ENTRY_REC.LCY_CHG_AMT1 := L_ENTRY_REC.CHG_AMT1;
      
        L_ENTRY_REC.CHG_AMT1 := L_CHG_ROW.COD_CHG_AMT1;
      END IF;
      DBG('l_entry_rec.chg_amt1--> ' || L_ENTRY_REC.CHG_AMT1);
      L_ENTRY_REC.CHG_CCY1          := L_CHG_ROW.COD_CHG_CCY1;
      L_ENTRY_REC.CHG_DESC1         := L_CHG_ROW.COD_CHG_DESC1;
      L_ENTRY_REC.CHGCCY_LCY_XRATE1 := L_CHG_ROW.COD_CHG_RATE1;
      DBG('here 2');
      IF TB_CHG_AMT.EXISTS(5) THEN
        DBG('tb_chg_amt(5).chg_amount is-->' || TB_CHG_AMT(5).CHG_AMOUNT || '~' ||
            L_CHG_ROW.COD_CHG_AMT2);
        IF TB_CHG_AMT(5).CHG_AMOUNT <> L_CHG_ROW.COD_CHG_AMT2 THEN
          L_ENTRY_REC.CHG_AMT2 := TB_CHG_AMT(5).CHG_AMOUNT;
        ELSE
          L_ENTRY_REC.CHG_AMT2 := L_CHG_ROW.COD_CHG_AMT2;
        END IF;
      ELSE
      
        L_ENTRY_REC.LCY_CHG_AMT2 := L_ENTRY_REC.CHG_AMT2;
      
        L_ENTRY_REC.CHG_AMT2 := L_CHG_ROW.COD_CHG_AMT2;
      END IF;
      DBG('l_entry_rec.chg_amt2--> ' || L_ENTRY_REC.CHG_AMT2);
      L_ENTRY_REC.CHG_CCY2          := L_CHG_ROW.COD_CHG_CCY2;
      L_ENTRY_REC.CHG_DESC2         := L_CHG_ROW.COD_CHG_DESC2;
      L_ENTRY_REC.CHGCCY_LCY_XRATE2 := L_CHG_ROW.COD_CHG_RATE2;
      DBG('here 3');
      IF TB_CHG_AMT.EXISTS(7) THEN
        DBG('tb_chg_amt(7).chg_amount is-->' || TB_CHG_AMT(7).CHG_AMOUNT || '~' ||
            L_CHG_ROW.COD_CHG_AMT3);
        IF TB_CHG_AMT(7).CHG_AMOUNT <> L_CHG_ROW.COD_CHG_AMT3 THEN
          L_ENTRY_REC.CHG_AMT3 := TB_CHG_AMT(7).CHG_AMOUNT;
        ELSE
          L_ENTRY_REC.CHG_AMT3 := L_CHG_ROW.COD_CHG_AMT3;
        END IF;
      ELSE
      
        L_ENTRY_REC.LCY_CHG_AMT3 := L_ENTRY_REC.CHG_AMT3;
      
        L_ENTRY_REC.CHG_AMT3 := L_CHG_ROW.COD_CHG_AMT3;
      END IF;
      DBG('l_entry_rec.chg_amt3--> ' || L_ENTRY_REC.CHG_AMT3);
      L_ENTRY_REC.CHG_CCY3          := L_CHG_ROW.COD_CHG_CCY3;
      L_ENTRY_REC.CHG_DESC3         := L_CHG_ROW.COD_CHG_DESC3;
      L_ENTRY_REC.CHGCCY_LCY_XRATE3 := L_CHG_ROW.COD_CHG_RATE3;
      DBG('here 4');
      IF TB_CHG_AMT.EXISTS(9) THEN
        DBG('tb_chg_amt(9).chg_amount  is-->' || TB_CHG_AMT(9).CHG_AMOUNT || '~' ||
            L_CHG_ROW.COD_CHG_AMT4);
        IF TB_CHG_AMT(9).CHG_AMOUNT <> L_CHG_ROW.COD_CHG_AMT4 THEN
          L_ENTRY_REC.CHG_AMT4 := TB_CHG_AMT(9).CHG_AMOUNT;
        ELSE
          L_ENTRY_REC.CHG_AMT4 := L_CHG_ROW.COD_CHG_AMT4;
        END IF;
      ELSE
      
        L_ENTRY_REC.LCY_CHG_AMT4 := L_ENTRY_REC.CHG_AMT4;
      
        L_ENTRY_REC.CHG_AMT4 := L_CHG_ROW.COD_CHG_AMT4;
      END IF;
      DBG('l_entry_rec.chg_amt4--> ' || L_ENTRY_REC.CHG_AMT4);
    
      L_ENTRY_REC.CHG_CCY4          := L_CHG_ROW.COD_CHG_CCY4;
      L_ENTRY_REC.CHG_DESC4         := L_CHG_ROW.COD_CHG_DESC4;
      L_ENTRY_REC.CHGCCY_LCY_XRATE4 := L_CHG_ROW.COD_CHG_RATE4;
    
    END IF;
  
    DEBUG.PR_DEBUG('CG',
                   'SPL_CHQ_FLG:' || L_CHG_ROW.SPL_CHQ_FLG || 'REGCC:' ||
                   L_CHG_ROW.CONSIDER_FOR_REG_CC);
    DEBUG.PR_DEBUG('CG',
                   'Ref no is new ..' || L_ENTRY_REC.REFERENCE_NO ||
                   'Entry no is ..' || L_ENTRY_REC.ENTRY_NO);
    L_ENTRY_REC.CONSIDER_FOR_REG_CC := L_CHG_ROW.CONSIDER_FOR_REG_CC;
    L_ENTRY_REC.SPL_CHQ_FLG         := L_CHG_ROW.SPL_CHQ_FLG;
  
    L_ENTRY_REC.MODULE_CODE := NVL(L_ENTRY_REC.MODULE_CODE, 'CG');
    BEGIN
      SELECT NEGOTIATED_RATE, NEGOTIATION_REF_NO
        INTO L_NEGOTIATED_RATE, L_NEGOTIATION_REF_NO
        FROM IFTB_CLEARING_UPLOAD
       WHERE XREF = L_ENTRY_REC.XREF
         AND ENTRY_NO = L_ENTRY_REC.ENTRY_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('any way this will never happen');
      
    END;
    L_ENTRY_REC.NEGOTIATED_RATE    := L_NEGOTIATED_RATE;
    L_ENTRY_REC.NEGOTIATION_REF_NO := L_NEGOTIATION_REF_NO;
    IF P_TO_INS = 'Y' THEN
      IF NOT
          FN_INSERT_ENTRY(L_USER, L_MAKER_DT_STAMP, L_ENTRY_REC, L_ERR_CODE) THEN
        DEBUG.PR_DEBUG('CG', 'Failed to insert instr in Clearing master');
        P_ERROR := L_ERR_CODE;
      
        IF P_CONSOL_REF_NO IS NULL THEN
          RETURN FALSE;
        ELSE
          ROLLBACK TO SP_IFTB_LOG;
          RAISE CONSOLIDATION_CHECK;
        END IF;
      END IF;
    END IF;
  
    IF (L_PRODUCT_TYPE = 'IC') THEN
    
      IF P_CONSOL_REF_NO IS NOT NULL THEN
        IF NOT FN_FCY_LCY_CONV(L_ENTRY_REC.INSTRUMENT_CCY,
                               L_ENTRY_REC.INSTRUMENT_AMT,
                               L_ENTRY_REC.ACC_BRANCH,
                               L_ENTRY_REC.REM_ACCOUNT,
                               L_ENTRY_REC.ACC_CCY,
                               L_ACC_CCY_AMT,
                               L_LCYAMT,
                               L_FCYAMT,
                               L_EXCHRATE,
                               L_ERR_CODE,
                               L_ERR_PARAM) THEN
          DBG('Failed in ccy conversion in 6.1 Change');
          P_ERROR       := L_ERR_CODE;
          P_ERROR_PARAM := L_ERR_PARAM;
          IF P_CONSOL_REF_NO IS NOT NULL THEN
            ROLLBACK TO SP_IFTB_LOG;
            RAISE CONSOLIDATION_CHECK;
          END IF;
        END IF;
      
        IF L_ENTRY_REC.ACC_CCY = GLOBAL.LCY THEN
          L_AMT := L_LCYAMT;
        ELSE
          L_AMT := L_FCYAMT;
        END IF;
      
        OVPKSS.PR_INITERRTBL;
      
        IF NOT CASAPKS.FN_DISCHK_N_UPDSTATUS(GLOBAL.CURRENT_BRANCH,
                                             GLOBAL.APPLICATION_DATE,
                                             L_ENTRY_REC.REM_ACCOUNT,
                                             'Y',
                                             L_ENTRY_REC.INSTRUMENT_NO_1,
                                             'Y',
                                             GLOBAL.USER_ID,
                                             L_ENTRY_REC.REFERENCE_NO,
                                             L_AMT,
                                             '!=*',
                                             '!=*',
                                             L_ERR_CODE,
                                             L_ERR_PARAM,
                                             P_CONSOL_REF_NO) THEN
          IF P_CONSOL_REF_NO IS NOT NULL THEN
            PKG_CASA_ERROR := 'Y';
            ROLLBACK TO SP_IFTB_LOG;
            RAISE CONSOLIDATION_CHECK;
          END IF;
        END IF;
      
        DBG('l_err_code ' || L_ERR_CODE);
        DBG('l_err_param ' || L_ERR_PARAM);
      
        IF NOT ACPKSS.FN_GET_OVR(L_ERR_CODE, L_ERR_PARAM, XCODE, XPARAM) THEN
          IF P_CONSOL_REF_NO IS NOT NULL THEN
            ROLLBACK TO SP_IFTB_LOG;
            RAISE CONSOLIDATION_CHECK;
          END IF;
        END IF;
      
        OVPKSS.PR_READTBL(LOC_ERR, LOC_PARAM);
      
        DBG('loc err' || LOC_ERR);
      
        IF LOC_ERR IS NOT NULL THEN
          CALL_DO_IT(L_ENTRY_REC.REFERENCE_NO,
                     1,
                     LOC_ERR,
                     LOC_PARAM,
                     NULL,
                     'CG',
                     'Y',
                     'Y',
                     ';',
                     GLOBAL.LANG,
                     'B',
                     LOC_MSGS,
                     LOC_MSG_TYPE,
                     LOC_AMOUNT,
                     LOC_COUNT,
                     LOC_TYPE,
                     L_ERR_CODE);
        END IF;
        DBG(' zed - loc_type ' || LOC_TYPE);
        IF LOC_TYPE = 'E' THEN
          DBG('This override is configured as an error');
          ROLLBACK TO SP_IFTB_LOG;
          IF P_RID <> 'X' THEN
            IF P_CONSOL_REF_NO IS NOT NULL THEN
              PKG_CASA_ERROR := 'Y';
              ROLLBACK TO SP_IFTB_LOG;
              RAISE CONSOLIDATION_CHECK;
            END IF;
          END IF;
        END IF;
      
        IF LOC_TYPE IN ('O', 'A') THEN
          IF GLOBAL.USER_ID = 'SYSTEM' THEN
            DBG('Override - Rolled Back');
            ROLLBACK TO SP_IFTB_LOG;
            IF P_RID <> 'X' THEN
              UPDATE IFTBS_CLEARING_UPLOAD
                 SET FCCREF       = L_ENTRY_REC.REFERENCE_NO,
                     STATUS       = 'OVER',
                     ERROR_CODES  = L_PROD_ERR || LOC_ERR,
                     ERROR_PARAMS = L_PROD_PARAM || L_PARAM
               WHERE ROWID = P_RID;
            
              IF P_CONSOL_REF_NO IS NOT NULL THEN
                L_RETURN_TRUE  := 'Y';
                PKG_CASA_ERROR := 'Y';
                RAISE CONSOLIDATION_CHECK;
              END IF;
            END IF;
          ELSE
            IF P_FORCE_POST = 'Y' THEN
              LOC_TYPE := 'I';
            ELSE
              DBG('zed - p_upd_onl ' || P_UPD_ONL);
              IF P_UPD_ONL = 'U' THEN
                ROLLBACK TO SP_IFTB_LOG;
                IF P_RID <> 'X' THEN
                  UPDATE IFTBS_CLEARING_UPLOAD
                     SET FCCREF       = L_ENTRY_REC.REFERENCE_NO,
                         STATUS       = 'OVER',
                         ERROR_CODES  = L_PROD_ERR || LOC_ERR,
                         ERROR_PARAMS = L_PROD_PARAM || L_PARAM
                   WHERE ROWID = P_RID;
                END IF;
              
                IF P_CONSOL_REF_NO IS NOT NULL THEN
                  PKG_CASA_ERROR := 'Y';
                  DBG('Finally set pkg casa err to ' || PKG_CASA_ERROR);
                  L_RETURN_TRUE := 'Y';
                  RAISE CONSOLIDATION_CHECK;
                END IF;
              END IF;
            END IF;
          END IF;
        END IF;
      END IF;
    
      IF NOT FN_PROCESS_IC_ENTRY(PBRANCH,
                                 L_ENTRY_REC,
                                 L_CHG_ROW,
                                 P_ERROR,
                                 P_ERROR_PARAM,
                                 P_CONSOL_REF_NO) THEN
        DEBUG.PR_DEBUG('CG', 'Failed to process IC entry ... ' || P_ERROR);
      
        L_ERTYPE := OVPKSS.FN_GETTYPE(P_ERROR);
        DEBUG.PR_DEBUG('CG',
                       'the error type in IC entry is... ' || L_ERTYPE);
        IF L_ERTYPE = 'E' THEN
        
          DEBUG.PR_DEBUG('CG', 'Return without doing anything');
        
        END IF;
      
        IF P_CONSOL_REF_NO IS NULL THEN
          RETURN FALSE;
        ELSE
          RAISE CONSOLIDATION_CHECK;
        END IF;
      END IF;
    
      DEBUG.PR_DEBUG('CG', 'now have to delete the duplicate overrides');
      L_LOGGED_COUNT := OVPKS.GL_TBLERROR.COUNT;
    
      IF L_LOGGED_COUNT > 1 THEN
        FOR LOGGEDCNTR IN 1 .. L_LOGGED_COUNT LOOP
          L_DUPLICATE := FALSE;
          IF LOGGEDCNTR < L_LOGGED_COUNT THEN
            FOR NEWCNTR IN LOGGEDCNTR + 1 .. L_LOGGED_COUNT LOOP
              IF NVL(OVPKS.GL_TBLERROR(NEWCNTR).ERR_CODE, '*') =
                 NVL(OVPKS.GL_TBLERROR(LOGGEDCNTR).ERR_CODE, '*') AND
                 NVL(OVPKS.GL_TBLERROR(NEWCNTR).PARAMS, '*') =
                 NVL(OVPKS.GL_TBLERROR(LOGGEDCNTR).PARAMS, '*') THEN
                DBG('Duplicate Error :' || OVPKS.GL_TBLERROR(NEWCNTR)
                    .ERR_CODE || '/' || OVPKS.GL_TBLERROR(NEWCNTR).PARAMS);
                L_DUPLICATE := TRUE;
              END IF;
            END LOOP;
          END IF;
          IF NOT L_DUPLICATE THEN
            L_NEW_COUNT := L_NEW_COUNT + 1;
            L_MAIN_ERR_TBL(L_NEW_COUNT) := OVPKS.GL_TBLERROR(LOGGEDCNTR);
          END IF;
        END LOOP;
      
        IF L_LOGGED_COUNT <> L_NEW_COUNT THEN
          DBG('Old And New Counts :' || L_LOGGED_COUNT || '/' ||
              L_NEW_COUNT);
          OVPKS.GL_TBLERROR := L_MAIN_ERR_TBL;
        END IF;
      END IF;
      DEBUG.PR_DEBUG('CG', 'deleted the duplicate overrides');
    
      OVPKSS.PR_READTBL(L_ERR, L_PARAM);
      DEBUG.PR_DEBUG('CG', 'Before call do it ..');
      IF L_ERR IS NOT NULL THEN
        CALL_DO_IT(L_ENTRY_REC.REFERENCE_NO,
                   1,
                   L_ERR,
                   L_PARAM,
                   NULL,
                   'CG',
                   'Y',
                   'Y',
                   ';',
                   GLOBAL.LANG,
                   'B',
                   L_MSGS,
                   L_MSG_TYPE,
                   L_AMOUNT,
                   L_COUNT,
                   L_TYPE,
                   L_ERR_CODE);
      END IF;
      DEBUG.PR_DEBUG('CG', 'After call do it..');
    
      DEBUG.PR_DEBUG('CG',
                     'treatment id is ..' || OVPKSS_ADDON.G_TREATMENT);
      DEBUG.PR_DEBUG('CG', 'Msgs is ..' || L_MSGS);
      DEBUG.PR_DEBUG('CG', 'Msg  type is ..' || L_MSG_TYPE);
      DEBUG.PR_DEBUG('CG', 'Amount is ..' || L_AMOUNT);
      DEBUG.PR_DEBUG('CG', 'Count is ..' || L_COUNT);
      DEBUG.PR_DEBUG('CG', 'Type is ..' || L_TYPE);
      DEBUG.PR_DEBUG('CG', 'Err code is ..' || L_ERR_CODE);
    
      PERRCODES := '';
      PPARAMS   := '';
      DBG('Going to call ovpks');
      IF OVPKSS.GL_TBLERROR.COUNT > 0 THEN
        L_INFO_COUNT := 0;
        FOR I IN 1 .. OVPKSS.GL_TBLERROR.COUNT LOOP
          IF NVL(LENGTH(PERRCODES), 0) <
             (32767 - LENGTH(OVPKSS.GL_TBLERROR(I).ERR_CODE)) AND
             NVL(LENGTH(PPARAMS), 0) <
             (32767 - NVL(LENGTH(OVPKSS.GL_TBLERROR(I).PARAMS), 0)) THEN
            DBG('error-->' || OVPKSS.GL_TBLERROR(I).ERR_CODE);
            OVPKSS.GL_TBLERROR(I).ERR_CODE := OVPKSS_ADDON.FN_RET_OVD_CODE(OVPKSS.GL_TBLERROR(I)
                                                                           .ERR_CODE);
            DBG('error-->' || OVPKSS.GL_TBLERROR(I).ERR_CODE);
          
            DBG('Calling Fn_Get_ertb_msgs_Rec_Wrp for the error code.. -->' || OVPKSS.GL_TBLERROR(I)
                .ERR_CODE);
            IF NOT
                CSPKSS_FUNCTION_CACHE.FN_GET_ERTB_MSGS_REC_WRP(OVPKSS.GL_TBLERROR(I)
                                                               .ERR_CODE,
                                                               GLOBAL.LANG,
                                                               P_ERROR,
                                                               P_ERROR_PARAM) THEN
              DBG('In Exception error type not found -->' || P_ERROR);
              DBG('Exception was not raised..so assignin null value.. ');
              L_ERR_TYPE    := NULL;
              P_ERROR       := NULL;
              P_ERROR_PARAM := NULL;
            ELSE
              DBG('Rec exists for the err code..');
              L_ERR_TYPE := CSPKSS_FUNCTION_CACHE.G_TBL_ERTB_MSGS_DEFN_REC.TYPE;
            
            END IF;
            DBG('l_err_type is - ' || L_ERR_TYPE);
          
            IF INSTR(L_OVDRAFT_OVDS, OVPKSS.GL_TBLERROR(I).ERR_CODE) = 0 THEN
              L_NON_OVERDRAFT_OVD := 'Y';
            END IF;
            DBG('l_non_overdraft_ovd -->' || L_NON_OVERDRAFT_OVD);
          
            IF L_ERR_TYPE = 'E' THEN
              PERRCODES := PERRCODES || OVPKSS.GL_TBLERROR(I).ERR_CODE || ';';
              PPARAMS   := PPARAMS || OVPKSS.GL_TBLERROR(I).PARAMS || ';';
            END IF;
          
            DBG('l_err_type is ---->' || L_ERR_TYPE);
            IF L_ERR_TYPE <> 'I' THEN
              L_INFO_COUNT := L_INFO_COUNT + 1;
            END IF;
          
          END IF;
        END LOOP;
        DBG('Perrcodes---->' || PERRCODES);
        DBG('Pparams--->' || PPARAMS);
      END IF;
    
      IF OVPKSS.GL_TBLERROR.COUNT > 0 AND L_INFO_COUNT = 0 THEN
        DBG('l_info_count---->' || L_INFO_COUNT);
        L_TYPE := 'I';
      END IF;
    
      IF L_TYPE = 'E' THEN
        DEBUG.PR_DEBUG('CG',
                       'This override is configured as an error ... ');
        ROLLBACK TO SP_IFTB_LOG;
        IF P_RID <> 'X' THEN
          UPDATE IFTBS_CLEARING_UPLOAD
             SET FCCREF = L_ENTRY_REC.REFERENCE_NO,
                 STATUS = 'ERRR'
                 
                ,
                 ERROR_CODES  = PERRCODES,
                 ERROR_PARAMS = PPARAMS
           WHERE ROWID = P_RID;
          PERRCODES := '';
          PPARAMS   := '';
          IF P_CONSOL_REF_NO IS NOT NULL THEN
            L_RETURN_TRUE := 'Y';
            RAISE CONSOLIDATION_CHECK;
          END IF;
        END IF;
      END IF;
      IF L_TYPE IN ('O', 'A') THEN
        IF GLOBAL.USER_ID = 'SYSTEM' THEN
        
          DBG('g_referral_queue -->' || G_REFERRAL_QUEUE);
          DBG('l_non_overdraft_ovd -->' || L_NON_OVERDRAFT_OVD);
          IF G_REFERRAL_QUEUE = 'Y' AND L_NON_OVERDRAFT_OVD = 'N' THEN
            DEBUG.PR_DEBUG('CG', 'user id is SYSTEM');
            DEBUG.PR_DEBUG('CG',
                           'Only overdraft errors/overrides are logged. It should not rollback');
          ELSE
          
            DEBUG.PR_DEBUG('CG',
                           'This is an override. However I have to roll back ... ');
            ROLLBACK TO SP_IFTB_LOG;
            IF P_RID <> 'X' THEN
              DEBUG.PR_DEBUG('CG',
                             'the fn_acc error codes coming are' ||
                             L_PROD_ERR);
              DEBUG.PR_DEBUG('CG',
                             'the fn_acc error param coming are' ||
                             L_PROD_PARAM);
              UPDATE IFTBS_CLEARING_UPLOAD
                 SET FCCREF       = L_ENTRY_REC.REFERENCE_NO,
                     STATUS       = 'OVER',
                     ERROR_CODES  = L_PROD_ERR || L_ERR,
                     ERROR_PARAMS = L_PROD_PARAM || L_PARAM
               WHERE ROWID = P_RID;
              IF P_CONSOL_REF_NO IS NOT NULL THEN
                L_RETURN_TRUE := 'Y';
                RAISE CONSOLIDATION_CHECK;
              END IF;
            END IF;
          END IF;
        ELSE
          IF P_FORCE_POST = 'Y' THEN
            L_TYPE := 'I';
          ELSE
          
            IF P_UPD_ONL = 'U' THEN
            
              DBG('g_referral_queue here -->' || G_REFERRAL_QUEUE);
              DBG('l_non_overdraft_ovd here -->' || L_NON_OVERDRAFT_OVD);
              IF G_REFERRAL_QUEUE = 'Y' AND L_NON_OVERDRAFT_OVD = 'N' THEN
                DEBUG.PR_DEBUG('CG',
                               'Only overdraft errors/overrides are logged. It should not rollback');
              ELSE
              
                ROLLBACK TO SP_IFTB_LOG;
                DEBUG.PR_DEBUG('CG',
                               'the fn_acc error codes coming are' ||
                               L_PROD_ERR);
                DEBUG.PR_DEBUG('CG',
                               'the fn_acc error param coming are' ||
                               L_PROD_PARAM);
                IF P_RID <> 'X' THEN
                  UPDATE IFTBS_CLEARING_UPLOAD
                     SET FCCREF       = L_ENTRY_REC.REFERENCE_NO,
                         STATUS       = 'OVER',
                         ERROR_CODES  = L_PROD_ERR || L_ERR,
                         ERROR_PARAMS = L_PROD_PARAM || L_PARAM
                   WHERE ROWID = P_RID;
                  IF P_CONSOL_REF_NO IS NOT NULL THEN
                    L_RETURN_TRUE := 'Y';
                    RAISE CONSOLIDATION_CHECK;
                  END IF;
                END IF;
              END IF;
            END IF;
          END IF;
        END IF;
      END IF;
      DEBUG.PR_DEBUG('CG', 'L type is ..' || L_TYPE);
      DEBUG.PR_DEBUG('CG', 'p_error is ..' || L_ERR);
      DEBUG.PR_DEBUG('CG', 'online auth is ..' || P_ONLINE_AUTH);
      DBG('g_referral_queue here -->' || G_REFERRAL_QUEUE);
      DBG('l_non_overdraft_ovd on succ -->' || L_NON_OVERDRAFT_OVD);
    
      IF (NVL(L_TYPE, 'I') = 'I' OR L_ERR IS NULL OR
         (G_REFERRAL_QUEUE = 'Y' AND L_NON_OVERDRAFT_OVD = 'N')) AND
         P_ONLINE_AUTH = 'Y'
      
       THEN
        DEBUG.PR_DEBUG('CG', 'Authorizing the txn..');
        IF NOT FN_AUTH_TXN(PBRANCH,
                           L_ENTRY_REC.REFERENCE_NO,
                           P_ERROR,
                           P_ERROR_PARAM) THEN
          DEBUG.PR_DEBUG('CG',
                         'Failed in Authorizing the txn  - ' || P_ERROR);
        
          IF P_CONSOL_REF_NO IS NULL THEN
            RETURN FALSE;
          ELSE
            ROLLBACK TO SP_IFTB_LOG;
            RAISE CONSOLIDATION_CHECK;
          END IF;
        ELSE
          DEBUG.PR_DEBUG('CG', 'Successfully authorized');
          DEBUG.PR_DEBUG('CG', 'before updating iftb_clearing_upload');
          IF P_RID <> 'X' THEN
            UPDATE IFTBS_CLEARING_UPLOAD
               SET FCCREF       = L_ENTRY_REC.REFERENCE_NO,
                   STATUS       = 'SUCS',
                   ERROR_CODES  = NULL,
                   ERROR_PARAMS = NULL
             WHERE ROWID = P_RID;
          END IF;
          DEBUG.PR_DEBUG('CG', 'After updating iftbs_clearing_upload');
        END IF;
      
      ELSIF (NVL(L_TYPE, 'I') = 'I' OR L_ERR IS NULL OR
            (G_REFERRAL_QUEUE = 'Y' AND L_NON_OVERDRAFT_OVD = 'N')) AND
            P_ONLINE_AUTH = 'N' THEN
        DEBUG.PR_DEBUG('CG', 'Updating iftb_clearing_upload...');
        IF P_RID <> 'X' THEN
          UPDATE IFTBS_CLEARING_UPLOAD
             SET FCCREF       = L_ENTRY_REC.REFERENCE_NO,
                 STATUS       = 'SUCS',
                 ERROR_CODES  = NULL,
                 ERROR_PARAMS = NULL
           WHERE ROWID = P_RID;
        END IF;
        DEBUG.PR_DEBUG('CG', 'Updated iftbs_clearing_upload...');
      
      END IF;
    ELSIF (L_PRODUCT_TYPE = 'OC') THEN
      IF NOT FN_PROCESS_OC_ENTRY(PBRANCH,
                                 L_ENTRY_REC,
                                 L_CHG_ROW,
                                 P_ERROR,
                                 P_ERROR_PARAM,
                                 P_ONLINE_AUTH) THEN
        DEBUG.PR_DEBUG('CG', 'Failed to process OC entry - ' || P_ERROR);
      
        DBG('l_entry_rec.reference_no1--> ' || L_ENTRY_REC.REFERENCE_NO);
        P_REF_NO := L_ENTRY_REC.REFERENCE_NO;
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_CALL_FUNC_ID    := 2;
          DBG('Calling cspks_clg_serv_cluster.fn_save_entry');
          IF NOT CSPKS_CLG_SERV_CLUSTER.FN_SAVE_ENTRY(P_ENTRY_COLUMN_LIST,
                                                      P_ENTRY_DATA_STRING,
                                                      P_READ_FROM_STRING,
                                                      P_TO_INS,
                                                      P_ENTRY_REC,
                                                      PDTF,
                                                      P_REF_NO,
                                                      P_STATUS,
                                                      P_PROD,
                                                      P_INSTRNO,
                                                      P_ENTRY_NO,
                                                      P_ERROR,
                                                      P_ERROR_PARAM,
                                                      P_ONLINE_AUTH,
                                                      P_DEFAULT_MIS,
                                                      P_RID,
                                                      P_FORCE_POST,
                                                      P_UPD_ONL,
                                                      P_CONSOL_REF_NO,
                                                      L_CALL_FUNC_ID,
                                                      L_TB_CLUSTER_DATA) THEN
          
            DBG('Failure has happened in cspks_clg_serv_cluster.fn_save_entry');
            RETURN FALSE;
          END IF;
        END IF;
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          IF NVL(GWPKS_UTIL.PKG_FUNC, '*') NOT IN
             ('5555', '6514', '6512', '5521') THEN
            OVPKS.PR_APPENDTBL(P_ERROR, P_ERROR_PARAM);
            RETURN FALSE;
          ELSE
          
            L_ERTYPE := OVPKSS.FN_GETTYPE(P_ERROR);
            DEBUG.PR_DEBUG('CG',
                           'the error type in OC entry is... ' || L_ERTYPE);
            IF L_ERTYPE = 'E' THEN
              DEBUG.PR_DEBUG('CG', 'Return without doing anything');
            END IF;
          
            IF P_CONSOL_REF_NO IS NULL THEN
              DBG('check1..');
              RETURN FALSE;
            ELSE
              DBG('check2..');
              RAISE CONSOLIDATION_CHECK;
            END IF;
          
          END IF;
        END IF;
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_CALL_FUNC_ID    := 3;
        DBG('Calling cspks_clg_serv_cluster.fn_save_entry');
        IF NOT CSPKS_CLG_SERV_CLUSTER.FN_SAVE_ENTRY(P_ENTRY_COLUMN_LIST,
                                                    P_ENTRY_DATA_STRING,
                                                    P_READ_FROM_STRING,
                                                    P_TO_INS,
                                                    P_ENTRY_REC,
                                                    PDTF,
                                                    P_REF_NO,
                                                    P_STATUS,
                                                    P_PROD,
                                                    P_INSTRNO,
                                                    P_ENTRY_NO,
                                                    P_ERROR,
                                                    P_ERROR_PARAM,
                                                    P_ONLINE_AUTH,
                                                    P_DEFAULT_MIS,
                                                    P_RID,
                                                    P_FORCE_POST,
                                                    P_UPD_ONL,
                                                    P_CONSOL_REF_NO,
                                                    L_CALL_FUNC_ID,
                                                    L_TB_CLUSTER_DATA) THEN
        
          DBG('Failure has happened in cspks_clg_serv_cluster.fn_save_entry');
          RETURN FALSE;
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        IF NVL(GWPKS_UTIL.PKG_FUNC, '*') IN
           ('5555', '6514', '6512', '5521') THEN
          DEBUG.PR_DEBUG('CG',
                         'now have to delete the duplicate overrides');
          L_LOGGED_COUNT := OVPKS.GL_TBLERROR.COUNT;
        
          IF L_LOGGED_COUNT > 1 THEN
            FOR LOGGEDCNTR IN 1 .. L_LOGGED_COUNT LOOP
              L_DUPLICATE := FALSE;
              IF LOGGEDCNTR < L_LOGGED_COUNT THEN
                FOR NEWCNTR IN LOGGEDCNTR + 1 .. L_LOGGED_COUNT LOOP
                  IF NVL(OVPKS.GL_TBLERROR(NEWCNTR).ERR_CODE, '*') =
                     NVL(OVPKS.GL_TBLERROR(LOGGEDCNTR).ERR_CODE, '*') AND
                     NVL(OVPKS.GL_TBLERROR(NEWCNTR).PARAMS, '*') =
                     NVL(OVPKS.GL_TBLERROR(LOGGEDCNTR).PARAMS, '*') THEN
                    DBG('Duplicate Error :' || OVPKS.GL_TBLERROR(NEWCNTR)
                        .ERR_CODE || '/' || OVPKS.GL_TBLERROR(NEWCNTR)
                        .PARAMS);
                    L_DUPLICATE := TRUE;
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_DUPLICATE THEN
                L_NEW_COUNT := L_NEW_COUNT + 1;
                L_MAIN_ERR_TBL(L_NEW_COUNT) := OVPKS.GL_TBLERROR(LOGGEDCNTR);
              END IF;
            END LOOP;
          
            IF L_LOGGED_COUNT <> L_NEW_COUNT THEN
              DBG('Old And New Counts :' || L_LOGGED_COUNT || '/' ||
                  L_NEW_COUNT);
              OVPKS.GL_TBLERROR := L_MAIN_ERR_TBL;
            END IF;
          END IF;
          DEBUG.PR_DEBUG('CG', 'deleted the duplicate overrides');
        
          OVPKSS.PR_READTBL(L_ERR, L_PARAM);
          DEBUG.PR_DEBUG('CG', 'Error code is ..' || P_ERROR);
          IF L_ERR IS NOT NULL THEN
            CALL_DO_IT(L_ENTRY_REC.REFERENCE_NO,
                       1,
                       L_ERR,
                       L_PARAM,
                       NULL,
                       'CG',
                       'Y',
                       'Y',
                       ';',
                       GLOBAL.LANG,
                       'B',
                       L_MSGS,
                       L_MSG_TYPE,
                       L_AMOUNT,
                       L_COUNT,
                       L_TYPE,
                       L_ERR_CODE);
          END IF;
          DEBUG.PR_DEBUG('CG', 'After call do it..');
        
          DEBUG.PR_DEBUG('CG',
                         'treatment id is ..' || OVPKSS_ADDON.G_TREATMENT);
          DEBUG.PR_DEBUG('CG', 'Msgs is ..' || L_MSGS);
          DEBUG.PR_DEBUG('CG', 'Msg  type is ..' || L_MSG_TYPE);
          DEBUG.PR_DEBUG('CG', 'Amount is ..' || L_AMOUNT);
          DEBUG.PR_DEBUG('CG', 'Count is ..' || L_COUNT);
          DEBUG.PR_DEBUG('CG', 'Type is ..' || L_TYPE);
          DEBUG.PR_DEBUG('CG', 'Err code is ..' || L_ERR_CODE);
        
          PERRCODES := '';
          PPARAMS   := '';
          DBG('Going to call ovpks');
          IF OVPKSS.GL_TBLERROR.COUNT > 0 THEN
            L_INFO_COUNT := 0;
            FOR I IN 1 .. OVPKSS.GL_TBLERROR.COUNT LOOP
              IF NVL(LENGTH(PERRCODES), 0) <
                 (32767 - LENGTH(OVPKSS.GL_TBLERROR(I).ERR_CODE)) AND
                 NVL(LENGTH(PPARAMS), 0) <
                 (32767 - NVL(LENGTH(OVPKSS.GL_TBLERROR(I).PARAMS), 0)) THEN
                DBG('error-->' || OVPKSS.GL_TBLERROR(I).ERR_CODE);
                OVPKSS.GL_TBLERROR(I).ERR_CODE := OVPKSS_ADDON.FN_RET_OVD_CODE(OVPKSS.GL_TBLERROR(I)
                                                                               .ERR_CODE);
                DBG('error-->' || OVPKSS.GL_TBLERROR(I).ERR_CODE);
                BEGIN
                  SELECT TYPE
                    INTO L_ERR_TYPE
                    FROM ERTB_MSGS
                   WHERE ERR_CODE = OVPKSS.GL_TBLERROR(I).ERR_CODE
                     AND LANGUAGE = GLOBAL.LANG;
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('In Exception error type not found -->' || SQLERRM);
                END;
                DBG('l_err_type--> ' || L_ERR_TYPE);
                IF INSTR(L_OVDRAFT_OVDS, OVPKSS.GL_TBLERROR(I).ERR_CODE) = 0 THEN
                  L_NON_OVERDRAFT_OVD := 'Y';
                END IF;
                DBG('l_non_overdraft_ovd -->' || L_NON_OVERDRAFT_OVD);
              
                DBG('l_err_type is ---->' || L_ERR_TYPE);
                IF L_ERR_TYPE <> 'I' THEN
                  L_INFO_COUNT := L_INFO_COUNT + 1;
                END IF;
              
                IF L_ERR_TYPE = 'E' THEN
                  PERRCODES := PERRCODES || OVPKSS.GL_TBLERROR(I).ERR_CODE || ';';
                  PPARAMS   := PPARAMS || OVPKSS.GL_TBLERROR(I).PARAMS || ';';
                END IF;
              END IF;
            END LOOP;
            DBG('Perrcodes---->' || PERRCODES);
            DBG('Pparams--->' || PPARAMS);
          END IF;
        
          IF OVPKSS.GL_TBLERROR.COUNT > 0 AND L_INFO_COUNT = 0 THEN
            DBG('l_info_count---->' || L_INFO_COUNT);
            L_TYPE := 'I';
          END IF;
        
          IF NVL(L_TYPE, L_ERR_TYPE) = 'E' THEN
            DEBUG.PR_DEBUG('CG',
                           'This override is configured as an error ... ');
            ROLLBACK TO SP_IFTB_LOG;
            IF P_RID <> 'X' THEN
              UPDATE IFTBS_CLEARING_UPLOAD
                 SET FCCREF       = L_ENTRY_REC.REFERENCE_NO,
                     STATUS       = 'ERRR',
                     ERROR_CODES  = PERRCODES,
                     ERROR_PARAMS = PPARAMS
               WHERE ROWID = P_RID;
              PERRCODES := '';
              PPARAMS   := '';
              IF P_CONSOL_REF_NO IS NOT NULL THEN
                L_RETURN_TRUE := 'Y';
                RAISE CONSOLIDATION_CHECK;
              END IF;
            END IF;
          END IF;
        
          IF NVL(L_TYPE, L_ERR_TYPE) IN ('O', 'A') THEN
            IF GLOBAL.USER_ID = 'SYSTEM' THEN
              DBG('g_referral_queue -->' || G_REFERRAL_QUEUE);
              DBG('l_non_overdraft_ovd -->' || L_NON_OVERDRAFT_OVD);
              IF G_REFERRAL_QUEUE = 'Y' AND L_NON_OVERDRAFT_OVD = 'N' THEN
                DEBUG.PR_DEBUG('CG', 'user id is SYSTEM');
                DEBUG.PR_DEBUG('CG',
                               'Only overdraft errors/overrides are logged. It should not rollback');
              ELSE
                DEBUG.PR_DEBUG('CG',
                               'This is an override. However I have to roll back ... ');
                ROLLBACK TO SP_IFTB_LOG;
                IF P_RID <> 'X' THEN
                  DEBUG.PR_DEBUG('CG',
                                 'the fn_acc error codes coming are' ||
                                 L_PROD_ERR);
                  DEBUG.PR_DEBUG('CG',
                                 'the fn_acc error param coming are' ||
                                 L_PROD_PARAM);
                  UPDATE IFTBS_CLEARING_UPLOAD
                     SET FCCREF       = L_ENTRY_REC.REFERENCE_NO,
                         STATUS       = 'OVER',
                         ERROR_CODES  = L_PROD_ERR || L_ERR,
                         ERROR_PARAMS = L_PROD_PARAM || L_PARAM
                   WHERE ROWID = P_RID;
                  IF P_CONSOL_REF_NO IS NOT NULL THEN
                    L_RETURN_TRUE := 'Y';
                    RAISE CONSOLIDATION_CHECK;
                  END IF;
                END IF;
              END IF;
            ELSE
              IF P_FORCE_POST = 'Y' THEN
                L_TYPE := 'I';
              ELSE
                IF P_UPD_ONL = 'U' THEN
                  DBG('g_referral_queue here -->' || G_REFERRAL_QUEUE);
                  DBG('l_non_overdraft_ovd here -->' ||
                      L_NON_OVERDRAFT_OVD);
                  IF G_REFERRAL_QUEUE = 'Y' AND L_NON_OVERDRAFT_OVD = 'N' THEN
                    DEBUG.PR_DEBUG('CG',
                                   'Only overdraft errors/overrides are logged. It should not rollback');
                  ELSE
                    ROLLBACK TO SP_IFTB_LOG;
                    DEBUG.PR_DEBUG('CG',
                                   'the fn_acc error codes coming are' ||
                                   L_PROD_ERR);
                    DEBUG.PR_DEBUG('CG',
                                   'the fn_acc error param coming are' ||
                                   L_PROD_PARAM);
                    IF P_RID <> 'X' THEN
                      UPDATE IFTBS_CLEARING_UPLOAD
                         SET FCCREF       = L_ENTRY_REC.REFERENCE_NO,
                             STATUS       = 'OVER',
                             ERROR_CODES  = L_PROD_ERR || L_ERR,
                             ERROR_PARAMS = L_PROD_PARAM || L_PARAM
                       WHERE ROWID = P_RID;
                      IF P_CONSOL_REF_NO IS NOT NULL THEN
                        L_RETURN_TRUE := 'Y';
                        RAISE CONSOLIDATION_CHECK;
                      END IF;
                    END IF;
                  END IF;
                END IF;
              END IF;
            END IF;
          END IF;
          DEBUG.PR_DEBUG('CG', 'L type is ..' || L_TYPE);
          DEBUG.PR_DEBUG('CG', 'p_error is ..' || L_ERR);
          DEBUG.PR_DEBUG('CG', 'online auth is ..' || P_ONLINE_AUTH);
          DBG('g_referral_queue here -->' || G_REFERRAL_QUEUE);
          DBG('l_non_overdraft_ovd on succ -->' || L_NON_OVERDRAFT_OVD);
        
        END IF;
      
      END IF;
      DEBUG.PR_DEBUG('CG',
                     '**l_type**l_err**p_online_auth**pbranch**p_rid' ||
                     L_TYPE || '~' || L_ERR || '~' || P_ONLINE_AUTH || '~' ||
                     P_RID);
      IF (NVL(L_TYPE, 'I') = 'I' OR L_ERR IS NULL) AND P_ONLINE_AUTH = 'Y' THEN
        DEBUG.PR_DEBUG('CG', 'Authorizing the txn..');
        IF NOT FN_AUTH_TXN(PBRANCH,
                           L_ENTRY_REC.REFERENCE_NO,
                           P_ERROR,
                           P_ERROR_PARAM) THEN
          DEBUG.PR_DEBUG('CG',
                         'Failed in Authorizing the txn  - ' || P_ERROR);
          RETURN FALSE;
        ELSE
          DEBUG.PR_DEBUG('CG', 'Successfully authorized');
          DEBUG.PR_DEBUG('CG', 'before updating iftb_clearing_upload');
          IF P_RID <> 'X' THEN
            UPDATE IFTBS_CLEARING_UPLOAD
               SET FCCREF       = L_ENTRY_REC.REFERENCE_NO,
                   STATUS       = 'SUCS',
                   ERROR_CODES  = NULL,
                   ERROR_PARAMS = NULL
             WHERE ROWID = P_RID;
          END IF;
          DEBUG.PR_DEBUG('CG', 'After updating iftbs_clearing_upload');
        END IF;
      
      ELSIF (NVL(L_TYPE, 'I') = 'I' OR L_ERR IS NULL) AND
            P_ONLINE_AUTH = 'N' THEN
        DEBUG.PR_DEBUG('CG', 'Updating iftb_clearing_upload...');
        IF P_RID <> 'X' THEN
          UPDATE IFTBS_CLEARING_UPLOAD
             SET FCCREF       = L_ENTRY_REC.REFERENCE_NO,
                 STATUS       = 'SUCS',
                 ERROR_CODES  = NULL,
                 ERROR_PARAMS = NULL
           WHERE ROWID = P_RID;
        END IF;
        DEBUG.PR_DEBUG('CG',
                       'Updated iftbs_clearing_upload for outward...');
      
      END IF;
    
    END IF;
    DEBUG.PR_DEBUG('CG', 'Thru with passing unauth entries....');
  
    DEBUG.PR_DEBUG('CG',
                   'For Tracking Account for NSF--> ' ||
                   P_TRACK_CHG_ENTRY_NSF);
    IF P_TRACK_CHG_ENTRY_NSF = 'Y' THEN
    
      DEBUG.PR_DEBUG('CG',
                     'Reference Number being tracked--> ' ||
                     L_ENTRY_REC.REFERENCE_NO);
      PR_TRACK_ACCOUNT_NSF(L_ENTRY_REC.REFERENCE_NO);
      DBG('Account has been tracked');
    
      BEGIN
        DEBUG.PR_DEBUG('CG',
                       'NSF Tracked... Before Total Tracked Calculation');
        SELECT SUM(AMOUNT_DUE)
          INTO TOT_AMOUNT_DUE
          FROM CSTB_AUTO_SETTLE_BLOCK
         WHERE CONTRACT_REF_NO = L_ENTRY_REC.REFERENCE_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('CG', 'NSF Tracked...Not able to do Total');
      END;
      DEBUG.PR_DEBUG('CG',
                     'NSF Tracked..tot_amount_due ' || TOT_AMOUNT_DUE);
      IF NVL(TOT_AMOUNT_DUE, 0) > 0 THEN
      
        BEGIN
          DEBUG.PR_DEBUG('CG',
                         'NSF Tracked... Before Total Tracked Calculation');
          SELECT CCY
            INTO L_NSF_CCY
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO =
                 (SELECT ACCOUNT_NO
                    FROM CSTB_AUTO_SETTLE_BLOCK
                   WHERE CONTRACT_REF_NO = L_ENTRY_REC.REFERENCE_NO
                     AND ROWNUM = 1);
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CG',
                           'NSF Tracked...Not able find CCY for Account');
        END;
        DEBUG.PR_DEBUG('CG', 'NSF Tracked..l_ccy ' || L_NSF_CCY);
        L_ERR_CODE  := 'DE-TRACK02';
        L_ERR_PARAM := TOT_AMOUNT_DUE || '~' || L_NSF_CCY || '~;';
        OVPKS.PR_APPENDTBL(L_ERR_CODE, L_ERR_PARAM);
      END IF;
      DEBUG.PR_DEBUG('CG', ' Receviables Updation finished ');
    
    END IF;
  
    DEBUG.PR_DEBUG('CG', 'Checking for value date cust and bank.... ');
  
    DEBUG.PR_DEBUG('CG', 'Print RowiD %%%%% :: ' || P_RID);
    IF P_RID <> 'X' THEN
    
      UPDATE IFTBS_CLEARING_UPLOAD
         SET VALDATEBNK  = L_ENTRY_REC.VAL_DATE_BNK,
             VALDATECUST = L_ENTRY_REC.VAL_DATE_CUST,
             ENDPOINT    = L_ENTRY_REC.END_POINT
       WHERE ROWID = P_RID;
    END IF;
  
    IF P_DEFAULT_MIS = 'Y' THEN
      IF NOT MIPKSS_REFERRAL.FN_GET_CON_DEFAULT(L_ENTRY_REC.TXN_BRANCH,
                                                L_ENTRY_REC.REFERENCE_NO,
                                                L_CUSTOMER,
                                                L_ENTRY_REC.ACC_CCY) THEN
        P_ERROR       := 'CG-CL0016';
        P_ERROR_PARAM := '';
      
        IF P_CONSOL_REF_NO IS NULL THEN
          RETURN FALSE;
        ELSE
          ROLLBACK TO SP_IFTB_LOG;
          RAISE CONSOLIDATION_CHECK;
        END IF;
      END IF;
    END IF;
  
    DBG('gwpks_clearingservice.g_upload_status--> ' ||
        GWPKS_CLEARINGSERVICE.G_UPLOAD_STATUS);
    DBG('gwpks_util.pkg_func--> ' || GWPKS_UTIL.PKG_FUNC);
    DBG('gwpks_clearingservice.g_source--> ' ||
        GWPKS_CLEARINGSERVICE.G_SOURCE);
  
    L_ENTRY_REC.STATUS := 'SUCC';
    IF NOT FN_BACKUP_CLG_TABLES(L_ENTRY_REC.REFERENCE_NO) THEN
      DEBUG.PR_DEBUG('CG', 'Backup not successful');
    
      IF P_CONSOL_REF_NO IS NULL THEN
        RETURN FALSE;
      ELSE
        ROLLBACK TO SP_IFTB_LOG;
        RAISE CONSOLIDATION_CHECK;
      END IF;
    END IF;
    DEBUG.PR_DEBUG('CG', 'Before updating clearing master');
    UPDATE CSTBS_CLEARING_MASTER
       SET STATUS = L_ENTRY_REC.STATUS
     WHERE ROWID = G_MAST_ROW_ID;
  
    DBG('Updating clearing master for ' || L_ENTRY_REC.REFERENCE_NO || '~' ||
        G_EVENT_SEQ);
  
    IF G_EVENT_SEQ IS NOT NULL THEN
      DBG('g_event_seq is not null');
      UPDATE CSTBS_CLEARING_MASTER
         SET LIQN_DATE    = GLOBAL.APPLICATION_DATE,
             EVENT_SEQ_NO = G_EVENT_SEQ
       WHERE REFERENCE_NO = L_ENTRY_REC.REFERENCE_NO;
    
      UPDATE CSTBS_CLEARING_DETAILS
         SET STATUS = L_ENTRY_REC.STATUS, EVENT_SEQ_NO = G_EVENT_SEQ
       WHERE REFERENCE_NO = L_ENTRY_REC.REFERENCE_NO;
    
    ELSE
      DBG('inside this update here ');
      UPDATE CSTBS_CLEARING_MASTER
         SET LIQN_DATE = GLOBAL.APPLICATION_DATE
       WHERE REFERENCE_NO = L_ENTRY_REC.REFERENCE_NO
         AND EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM CSTBS_CLEARING_MASTER
               WHERE REFERENCE_NO = L_ENTRY_REC.REFERENCE_NO);
    
      UPDATE CSTBS_CLEARING_DETAILS
         SET STATUS = L_ENTRY_REC.STATUS
       WHERE REFERENCE_NO = L_ENTRY_REC.REFERENCE_NO
         AND EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM CSTBS_CLEARING_MASTER
               WHERE REFERENCE_NO = L_ENTRY_REC.REFERENCE_NO);
    END IF;
  
    DEBUG.PR_DEBUG('CG',
                   'AFR rows updated in clearing details-->' ||
                   SQL%ROWCOUNT);
  
    P_REF_NO := L_ENTRY_REC.REFERENCE_NO;
    P_STATUS := L_ENTRY_REC.STATUS;
  
    IF P_UPD_ONL = 'O' THEN
      P_ERROR       := P_ERROR || L_ERR;
      P_ERROR_PARAM := P_ERROR_PARAM || L_PARAM;
    END IF;
  
    G_ENTRY_REC := L_ENTRY_REC;
    IF G_ENTRY_REC.DIRECTION = 'O' THEN
      IF G_ENTRY_REC.BEN_ACCOUNT IS NOT NULL THEN
        IF NOT FN_IS_GL(G_ENTRY_REC.ACC_BRANCH,
                        G_ENTRY_REC.BEN_ACCOUNT,
                        L_ACC_CCY) THEN
          IF L_CHG_ROW.GENERATE_TRANSACTION_ADVICE = 'Y' THEN
            PR_MESSAGING;
          END IF;
          IF GWPKS_UTIL.G_GENMSG = 'Y' THEN
          
            PR_GEN_ADV_FOR_CONTRACT(L_ENTRY_REC.REFERENCE_NO);
          END IF;
        END IF;
      END IF;
    
    ELSIF G_ENTRY_REC.DIRECTION = 'I' THEN
      IF G_ENTRY_REC.REM_ACCOUNT IS NOT NULL THEN
        IF NOT FN_IS_GL(G_ENTRY_REC.ACC_BRANCH,
                        G_ENTRY_REC.REM_ACCOUNT,
                        L_ACC_CCY) THEN
          IF L_CHG_ROW.GENERATE_TRANSACTION_ADVICE = 'Y' THEN
            PR_MESSAGING;
          END IF;
          IF GWPKS_UTIL.G_GENMSG = 'Y' THEN
            PR_GEN_ADV_FOR_CONTRACT(L_ENTRY_REC.REFERENCE_NO);
          END IF;
        END IF;
      END IF;
    END IF;
  
    DBG('fn_save_entry Process completed successfully');
    RETURN TRUE;
  EXCEPTION
  
    WHEN CONSOLIDATION_CHECK THEN
      DBG('entering consolidation_check exception....');
      DBG('pkg_casa_error -->' || PKG_CASA_ERROR);
      DBG('l_return_true -->' || L_RETURN_TRUE);
    
      PKG_REVR_ENTRY := 'Y';
      PKG_ENTRY_REC  := L_ENTRY_REC;
    
      DBG('PKG REVR_ENTRY ' || PKG_REVR_ENTRY);
    
      IF L_RETURN_TRUE = 'Y' THEN
        RETURN TRUE;
      ELSE
        RETURN FALSE;
      END IF;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_save_entry ' || SQLERRM);
      P_ERROR := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
    
  END FN_SAVE_ENTRY;

  PROCEDURE PR_MESSAGING IS
  BEGIN
    IF G_ENTRY_REC.DIRECTION = 'O' THEN
      PR_INS_MSG_HANDOFF('CR ADVICE');
    
    ELSE
      DBG('inside debit advice');
      PR_INS_MSG_HANDOFF('DEBIT_ADVICE');
    END IF;
  
  END PR_MESSAGING;

  PROCEDURE PR_INS_MSG_HANDOFF(P_DRCR VARCHAR2) IS
    CURSOR CUR_ACC(P_AC_NO VARCHAR2, P_BRANCH VARCHAR2) IS
      SELECT AC_OR_GL, CUST_NO
        FROM STTB_ACCOUNT
       WHERE NVL(BRANCH_CODE, P_BRANCH) = P_BRANCH
         AND AC_GL_NO = P_AC_NO;
    L_CUST_NO   STTB_ACCOUNT.CUST_NO%TYPE;
    L_AC_OR_GL  STTB_ACCOUNT.AC_OR_GL%TYPE;
    L_CUST_NAME STTMS_CUSTOMER.CUSTOMER_NAME1%TYPE := NULL;
    L_ADDRESS1  STTMS_CUSTOMER.ADDRESS_LINE1%TYPE := NULL;
    L_ADDRESS2  STTMS_CUSTOMER.ADDRESS_LINE1%TYPE := NULL;
    L_ADDRESS3  STTMS_CUSTOMER.ADDRESS_LINE1%TYPE := NULL;
    L_ADDRESS4  STTMS_CUSTOMER.ADDRESS_LINE1%TYPE := NULL;
    L_CCY       VARCHAR2(3);
    L_AMOUNT    NUMBER;
    L_MEDIA     STTMS_CUSTOMER.DEFAULT_MEDIA%TYPE := NULL;
    L_ACC       STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    CURSOR CUR_CUST(CUSTNO VARCHAR2) IS
      SELECT CUSTOMER_NAME1,
             ADDRESS_LINE1,
             ADDRESS_LINE2,
             ADDRESS_LINE3,
             ADDRESS_LINE4,
             DEFAULT_MEDIA
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO = CUSTNO;
  BEGIN
  
    IF G_ENTRY_REC.DIRECTION = 'O' AND P_DRCR = 'CR ADVICE' THEN
      OPEN CUR_ACC(G_ENTRY_REC.BEN_ACCOUNT, G_ENTRY_REC.ACC_BRANCH);
      FETCH CUR_ACC
        INTO L_AC_OR_GL, L_CUST_NO;
      CLOSE CUR_ACC;
      DEBUG.PR_DEBUG('CG', 'customer number fetched');
      L_ACC    := G_ENTRY_REC.BEN_ACCOUNT;
      L_CCY    := G_ENTRY_REC.INSTRUMENT_CCY;
      L_AMOUNT := G_ENTRY_REC.INSTRUMENT_AMT;
      DEBUG.PR_DEBUG('CG', 'values initialized for OFS');
    
    ELSIF G_ENTRY_REC.DIRECTION = 'I' AND P_DRCR = 'DEBIT_ADVICE' THEN
      OPEN CUR_ACC(G_ENTRY_REC.REM_ACCOUNT, G_ENTRY_REC.ACC_BRANCH);
      FETCH CUR_ACC
        INTO L_AC_OR_GL, L_CUST_NO;
      CLOSE CUR_ACC;
      DEBUG.PR_DEBUG('CG', 'customer number fetched');
      L_ACC    := G_ENTRY_REC.REM_ACCOUNT;
      L_CCY    := G_ENTRY_REC.INSTRUMENT_CCY;
      L_AMOUNT := G_ENTRY_REC.INSTRUMENT_AMT;
      DEBUG.PR_DEBUG('CG', 'values initialized for OFS');
    
    END IF;
    IF L_AC_OR_GL = 'A' THEN
      FOR I IN CUR_CUST(L_CUST_NO) LOOP
        L_MEDIA := I.DEFAULT_MEDIA;
      END LOOP;
    
      INSERT INTO MSTBS_MSG_HANDOFF
        (BRANCH,
         REFERENCE_NO,
         ESN,
         MSG_TYPE,
         RECEIVER,
         NAME,
         SERIAL_NO,
         CCY,
         PRODUCT,
         AMOUNT,
         MEDIA,
         PRIORITY,
         MODULE,
         ADDRESS1,
         ADDRESS2,
         ADDRESS3,
         ADDRESS4,
         FORMAT,
         DIRECTIVE_STATUS,
         PROCESSED_FLAG,
         SUPPRESS_FLAG,
         HOLD_STATUS,
         CUST_AC_NO)
      VALUES
        (G_ENTRY_REC.TXN_BRANCH,
         G_ENTRY_REC.REFERENCE_NO,
         1,
         P_DRCR,
         L_CUST_NO,
         L_CUST_NAME,
         1,
         L_CCY,
         G_ENTRY_REC.PRODUCT_CODE,
         L_AMOUNT,
         L_MEDIA,
         1,
         'CG',
         L_ADDRESS1,
         L_ADDRESS2,
         L_ADDRESS3,
         L_ADDRESS4,
         NULL,
         'N',
         'N',
         'N',
         'N',
         L_ACC);
    ELSIF L_AC_OR_GL = 'G' THEN
      L_MEDIA := 'MAIL';
    
      BEGIN
      
        INSERT INTO MSTBS_MSG_HANDOFF
          (BRANCH,
           REFERENCE_NO,
           ESN,
           MSG_TYPE,
           RECEIVER,
           NAME,
           SERIAL_NO,
           CCY,
           PRODUCT,
           AMOUNT,
           MEDIA,
           PRIORITY,
           MODULE,
           ADDRESS1,
           ADDRESS2,
           ADDRESS3,
           ADDRESS4,
           FORMAT,
           DIRECTIVE_STATUS,
           PROCESSED_FLAG,
           SUPPRESS_FLAG,
           HOLD_STATUS,
           CUST_AC_NO)
        VALUES
          (G_ENTRY_REC.TXN_BRANCH,
           G_ENTRY_REC.REFERENCE_NO,
           1,
           P_DRCR,
           'WALKIN',
           GWPKS_UTIL.G_BENEF_NAME,
           1,
           L_CCY,
           G_ENTRY_REC.PRODUCT_CODE,
           L_AMOUNT,
           L_MEDIA,
           1,
           'CG',
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           'N',
           'N',
           'N',
           'N',
           L_ACC);
        DEBUG.PR_DEBUG('CG',
                       'pr_ins_msg_handoff-> After insert for GL account');
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('CG',
                         'pr_ins_msg_handoff-> Failed in WO while insert into mstbs_msg_handoff with ' ||
                         SQLERRM);
      END;
    END IF;
  END PR_INS_MSG_HANDOFF;

  FUNCTION FN_SAVE_ENTRY(PXREF           IN VARCHAR2,
                         P_ERROR         OUT VARCHAR2,
                         P_ERROR_PARAM   OUT VARCHAR2,
                         P_PROCESS_ID    IN NUMBER DEFAULT -1,
                         P_FORCE_POST    IN VARCHAR2 DEFAULT 'N',
                         P_UPD_ONL       IN VARCHAR2 DEFAULT 'U',
                         P_CONSOL_REF_NO IN VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN IS
    L_COL_LIST    VARCHAR2(2000);
    L_DATA_LIST   VARCHAR2(4000);
    PDTF          VARCHAR2(20);
    L_REF_NO      CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE;
    L_STATUS      CSTBS_CLEARING_MASTER.STATUS%TYPE;
    L_PROD        CSTBS_CLEARING_MASTER.PRODUCT_CODE%TYPE;
    L_INSTRNO     CSTBS_CLEARING_MASTER.INSTRUMENT_NO_1%TYPE;
    L_ENTRY_NO    CSTBS_CLEARING_MASTER.ENTRY_NO%TYPE;
    L_ACC_TAB     ACPKSS.TBL_ACHOFF;
    L_ONLINE_AUTH VARCHAR2(1) := 'N';
  
    L_POST_UPLOAD_STATUS VARCHAR2(1) := 'N';
  
    L_CUSTNO     STTM_CUST_ACCOUNT.CUST_NO%TYPE;
    L_NEW_STATUS STTB_CUST_NSF_CON_DET.NSFIB_CS_LVL%TYPE;
    L_AC_OR_GL   STTBS_ACCOUNT.AC_GL_NO%TYPE;
    L_CNT_NSF    NUMBER := 0;
    L_SOURCE     COTMS_SOURCE.SOURCE_CODE%TYPE;
  
    L_ACC_REC STTBS_ACCOUNT%ROWTYPE;
    CURSOR C_UPLOAD_REC(P_XREF VARCHAR2, PPROCESS_ID NUMBER) IS
      SELECT A.*, A.ROWID R_ID
        FROM IFTBS_CLEARING_UPLOAD A
       WHERE A.XREF = P_XREF
         AND A.PROCESS_ID = PPROCESS_ID
         AND A.STATUS = DECODE(P_CONSOL_REF_NO, NULL, 'UNPR', A.STATUS)
         AND A.AUTH_STAT = 'A'
         AND A.RECORD_STAT = 'O';
    L_COUNT_PROD NUMBER := 0;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
  
    PDTF := GLOBAL.GET_NLS_DT_FORMAT;
  
    FOR X IN C_UPLOAD_REC(PXREF, P_PROCESS_ID) LOOP
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 1;
        DBG('Calling cspks_clg_serv_cluster.fn_save_entry');
        IF NOT CSPKS_CLG_SERV_CLUSTER.FN_SAVE_ENTRY(PXREF,
                                                    P_ERROR,
                                                    P_ERROR_PARAM,
                                                    L_FN_CALL_ID,
                                                    L_TB_CLUSTER_DATA,
                                                    P_PROCESS_ID,
                                                    P_FORCE_POST,
                                                    P_UPD_ONL,
                                                    P_CONSOL_REF_NO
                                                    
                                                    ) THEN
        
          DBG('Failure has happened in cspks_clg_serv_cluster.fn_save_entry');
          RETURN FALSE;
        END IF;
      END IF;
    
      DBG('x.remaccount--> ' || X.REMACCOUNT);
      DBG('x.rembranch--> ' || X.REMBRANCH);
      DBG('x.benaccount--> ' || X.BENACCOUNT);
      DBG('x.benbranch--> ' || X.BENBRANCH);
    
      IF X.DIRECTION = 'I' THEN
        DEBUG.PR_DEBUG('CG',
                       'Checking if account is frozen or dormant for remitter..');
      
        BEGIN
          SELECT *
            INTO L_ACC_REC
            FROM STTBS_ACCOUNT
           WHERE AC_GL_NO = X.REMACCOUNT
                
             AND NVL(BRANCH_CODE, X.REMBRANCH) = X.REMBRANCH;
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DEBUG.PR_DEBUG('CG',
                           'No data while selecting the rem account ...' ||
                           SQLERRM);
            P_ERROR := 'CG-CL0007';
            OVPKS.PR_APPENDTBL('CG-CL0007', X.REMACCOUNT);
            RETURN TRUE;
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CG',
                           'Error while selecting the rem account ...' ||
                           SQLERRM);
        END;
        DBG('The ac_or_gl flag / flag of remitter ac no is ...' ||
            L_ACC_REC.AC_OR_GL);
        DBG('l_acc_rec.auth_stat--> ' || L_ACC_REC.AUTH_STAT);
        IF NVL(L_ACC_REC.AUTH_STAT, 'U') <> 'A' THEN
          DEBUG.PR_DEBUG('CG', 'The remitter Ac is not authorized ...');
          OVPKS.PR_APPENDTBL('CG-IO0119', X.REMACCOUNT);
        END IF;
      
        DBG('l_acc_rec.ac_gl_rec_status--> ' || L_ACC_REC.AC_GL_REC_STATUS);
        IF NVL(L_ACC_REC.AC_GL_REC_STATUS, 'C') <> 'O' THEN
          DEBUG.PR_DEBUG('CG', 'The remitter Ac is closed ...');
        
          OVPKS.PR_APPENDTBL('CG-CL0022', X.REMACCOUNT);
        END IF;
      
        DBG('l_acc_rec.Ac_Stat_Frozen--> ' || L_ACC_REC.AC_STAT_FROZEN);
        IF L_ACC_REC.AC_OR_GL = 'A' AND L_ACC_REC.AC_STAT_FROZEN = 'Y' THEN
          DEBUG.PR_DEBUG('CG', 'The remitter Ac is frozen ...');
          OVPKS.PR_APPENDTBL('CG-IO0117', NULL);
        END IF;
      
        DBG('l_acc_rec.Ac_Stat_Dormant--> ' || L_ACC_REC.AC_STAT_DORMANT);
        IF L_ACC_REC.AC_OR_GL = 'A' AND L_ACC_REC.AC_STAT_DORMANT = 'Y' THEN
          DEBUG.PR_DEBUG('CG', 'The remitter Ac is dormant ...');
          OVPKS.PR_APPENDTBL('CG-IO0118', NULL);
        END IF;
      
        DBG('Checking for account class product restriction for inward..');
        DBG('x.prod--> ' || X.PROD);
      
        DBG('l_acc_rec.Ac_Or_Gl--> ' || L_ACC_REC.AC_OR_GL);
        DBG('x.benaccount--> ' || X.BENACCOUNT);
        DBG('x.benbranch--> ' || X.BENBRANCH);
        IF L_ACC_REC.AC_OR_GL = 'A' THEN
          DBG('l_acc_rec.Ac_Or_Gl is A');
        
          BEGIN
            SELECT COUNT(*)
              INTO L_COUNT_PROD
              FROM CSVWS_ALLOWED_PRODUCTS
             WHERE CUSTAC = X.REMACCOUNT
               AND BRANCH_CODE = X.REMBRANCH
               AND PRODUCT_CODE = X.PROD
               AND DEBIT_TXN = 'Y';
            DBG('Count from the product view is ' || L_COUNT_PROD);
          
          EXCEPTION
            WHEN OTHERS THEN
              DBG('When others of select from the views csvws_allowed_products...' ||
                  SQLERRM);
          END;
        
          IF L_COUNT_PROD = 0 THEN
            DBG('The Debit transaction is not allowed for this customer and product');
            OVPKSS.PR_APPENDTBL('AC-PROD2',
                                X.PROD || '~' || X.REMACCOUNT ||
                                
                                '~');
          END IF;
        END IF;
      
      ELSIF X.DIRECTION = 'O' THEN
        DEBUG.PR_DEBUG('CG',
                       'Checking if account is frozen or dormant for beneficiary..');
        BEGIN
          SELECT *
            INTO L_ACC_REC
            FROM STTBS_ACCOUNT
           WHERE AC_GL_NO = X.BENACCOUNT
                
             AND NVL(BRANCH_CODE, X.BENBRANCH) = X.BENBRANCH;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DEBUG.PR_DEBUG('CG',
                           'No data while selecting the ben account ...' ||
                           SQLERRM);
          
            P_ERROR := 'CG-CL0017';
            OVPKS.PR_APPENDTBL('CG-CL0017', X.BENACCOUNT);
          
            RETURN FALSE;
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CG',
                           'Error while selecting the ben account ...' ||
                           SQLERRM);
        END;
        DBG('The ac_or_gl flag / flag of remitter ac no is ...' ||
            L_ACC_REC.AC_OR_GL);
      
        IF L_ACC_REC.AC_OR_GL = 'A' AND L_ACC_REC.AC_STAT_FROZEN = 'Y' THEN
          DEBUG.PR_DEBUG('CG', 'The beneficiary Ac is frozen ...');
          OVPKS.PR_APPENDTBL('CG-IO0117', NULL);
        END IF;
        IF L_ACC_REC.AC_OR_GL = 'A' AND L_ACC_REC.AC_STAT_DORMANT = 'Y' THEN
          DEBUG.PR_DEBUG('CG', 'The beneficiary Ac is dormant ...');
          OVPKS.PR_APPENDTBL('CG-IO0118', NULL);
        END IF;
      
        DBG('l_acc_rec.ac_stat_no_cr--> ' || L_ACC_REC.AC_STAT_NO_CR);
        IF NVL(L_ACC_REC.AC_STAT_NO_CR, 'N') = 'Y' THEN
          DEBUG.PR_DEBUG('CG',
                         'The beneficiary Ac is marked for no credit...');
          OVPKS.PR_APPENDTBL('AC-VAC03', X.BENACCOUNT);
        END IF;
      
        DBG('Checking for account class product restriction for outward..');
        DBG('x.prod--> ' || X.PROD);
      
        DBG('l_acc_rec.Ac_Or_Gl--> ' || L_ACC_REC.AC_OR_GL);
        DBG('x.benaccount--> ' || X.BENACCOUNT);
        DBG('x.benbranch--> ' || X.BENBRANCH);
        IF L_ACC_REC.AC_OR_GL = 'A' THEN
          DBG('l_acc_rec.Ac_Or_Gl is A');
        
          BEGIN
            SELECT COUNT(*)
              INTO L_COUNT_PROD
              FROM CSVWS_ALLOWED_PRODUCTS
             WHERE CUSTAC = X.BENACCOUNT
               AND BRANCH_CODE = X.BENBRANCH
               AND PRODUCT_CODE = X.PROD
               AND CREDIT_TXN = 'Y';
            DBG('Count from the product view is ' || L_COUNT_PROD);
          
          EXCEPTION
            WHEN OTHERS THEN
              DBG('When others of select from the views csvws_allowed_products...' ||
                  SQLERRM);
          END;
        
          IF L_COUNT_PROD = 0 THEN
            DBG('The credit transaction is not allowed for this customer and product');
            OVPKSS.PR_APPENDTBL('AC-PROD2',
                                X.PROD || '~' || X.BENACCOUNT ||
                                
                                '~');
          END IF;
        END IF;
      END IF;
    
      DEBUG.PR_DEBUG('CG', 'Now processing for ..' || P_PROCESS_ID);
    
      IF GWPKS_UTIL.G_FROM_BEAN THEN
      
        DBG('gwpks_util.G_FROM_JAVABEAN is true');
        L_ONLINE_AUTH := 'Y';
        L_DATA_LIST   := X.SCODE || '~' || X.XREF || '~' || X.PROD || '~' ||
                         X.TXN_BRN || '~' || X.REMACCOUNT || '~' ||
                         X.REMBANK || '~' || X.REMBRANCH || '~' ||
                         X.BENACCOUNT || '~' || X.BENBANK || '~' ||
                         X.BENBRANCH || '~' || X.INSTRNO || '~' ||
                         X.INSTRCCY || '~' || X.INSTRAMT || '~' ||
                         TO_CHAR(X.INSTRDATE, PDTF) || '~' ||
                         TO_CHAR(X.TXNDATE, PDTF) || '~' ||
                         TO_CHAR(X.VALDATECUST, PDTF) || '~' || X.LATECLG || '~' ||
                         X.ROUTINGNO || '~' || X.ENDPOINT || '~' ||
                         X.SERIALNO || '~' || X.FCCREF || '~' || X.STATUS || '~' ||
                         X.ENTRY_NO || '~' || X.BENE_CCY || '~' ||
                         X.CONSIDER_FOR_REG_CC || '~' || X.SPL_CHQ_FLG || '~' ||
                         X.INSTRCCY || '~' || X.INSTRAMT || '~' ||
                         X.EXCH_RATE || '~' || '~' || '~' || '~' || '~' || '~' || '~' || '~' || '~' || '~' || '~' || '~' || '~' || '~' || '~' || '~' ||
                         X.REMARKS || '~' || X.PROJECT_NAME || '~' ||
                         X.UNIT_PAYMENT || '~' || X.UNIT_ID || '~' ||
                         X.DEPOSIT_SLIP_NO || '~' || X.INSTR_TYPE || '~' ||
                         X.BENROUTINGNO || '~' || X.BUNDLE_ID || '~' ||
                         X.CHEQUEISSUEDATE || '~';
      ELSE
      
        IF X.MODULE_CODE = 'PD' THEN
          L_ONLINE_AUTH := 'Y';
        END IF;
      
        DBG('gwpks_clearingservice.g_upload_status' ||
            GWPKS_CLEARINGSERVICE.G_UPLOAD_STATUS);
        IF NVL(GWPKS_CLEARINGSERVICE.G_UPLOAD_STATUS, 'U') = 'A' THEN
          L_ONLINE_AUTH := 'Y';
        END IF;
        DBG('l_online_auth ' || L_ONLINE_AUTH);
      
        L_DATA_LIST := X.SCODE || '~' || X.XREF || '~' || X.PROD || '~' ||
                       X.TXN_BRN || '~' || X.REMACCOUNT || '~' || X.REMBANK || '~' ||
                       X.REMBRANCH || '~' || X.BENACCOUNT || '~' ||
                       X.BENBANK || '~' || X.BENBRANCH || '~' || X.INSTRNO || '~' ||
                       X.INSTRCCY || '~' || X.INSTRAMT || '~' ||
                       TO_CHAR(X.INSTRDATE, PDTF) || '~' ||
                       TO_CHAR(X.TXNDATE, PDTF) || '~' ||
                       TO_CHAR(X.VALDATECUST, PDTF) || '~' || X.LATECLG || '~' ||
                       X.ROUTINGNO || '~' || X.ENDPOINT || '~' ||
                       X.SERIALNO || '~' || X.FCCREF || '~' || X.STATUS || '~' ||
                       X.ENTRY_NO || '~' || X.BENE_CCY || '~' || X.DIN || '~' ||
                       TO_CHAR(X.DIN_DATE, PDTF) || '~' ||
                      
                       X.REMARKS || '~~~' || X.INSTRCCY || '~' ||
                       X.INSTRAMT || '~' || X.EXCH_RATE || '~' ||
                       X.MODULE_CODE || '~' || X.MODULE_REFERENCE_NO || '~' ||
                       X.RECORD_STAT || '~' || X.AUTH_STAT || '~' ||
                       X.MAKER_ID || '~' || X.CHECKER_ID || '~' ||
                       X.MAKER_DT_STAMP || '~' || X.CHECKER_DT_STAMP || '~' ||
                       X.INSTR_TYPE || '~' || X.BENROUTINGNO || '~' ||
                       X.BUNDLE_ID || '~';
      END IF;
    
      DEBUG.PR_DEBUG('CG', 'Data list is ..' || L_DATA_LIST);
      IF NOT CSPKSS_CLG_SERV.FN_SAVE_ENTRY(L_COL_LIST,
                                           L_DATA_LIST,
                                           PDTF,
                                           L_REF_NO,
                                           L_STATUS,
                                           L_PROD,
                                           L_INSTRNO,
                                           L_ENTRY_NO,
                                           P_ERROR,
                                           P_ERROR_PARAM,
                                           L_ONLINE_AUTH,
                                           'Y',
                                           X.R_ID,
                                           X.FORCE_POSTING,
                                           P_UPD_ONL,
                                           P_CONSOL_REF_NO) THEN
        DEBUG.PR_DEBUG('CG',
                       'Failed in fn save entry in first fn save entry');
        OVPKS.PR_APPENDTBL(P_ERROR, NULL);
        ROLLBACK TO SP_IFTB_LOG;
        DBG('l_ref_no--> ' || L_REF_NO);
      
        UPDATE IFTBS_CLEARING_UPLOAD
           SET STATUS       = 'ERRR',
               FCCREF       = L_REF_NO,
               ERROR_CODES  = P_ERROR,
               ERROR_PARAMS = P_ERROR_PARAM
         WHERE ROWID = X.R_ID;
      
        IF GWPKS_UTIL.PKG_FUNC IN ('6501') THEN
          RETURN FALSE;
        END IF;
      END IF;
    
      IF P_CONSOL_REF_NO IS NOT NULL THEN
        DBG('updating IFTBS_CLEARING_UPLOAD with consol ref no ' ||
            P_CONSOL_REF_NO || ' for instrument ' ||
            PKG_ENTRY_REC.INSTRUMENT_NO_1 || ' with xref ' || PXREF);
        UPDATE IFTBS_CLEARING_UPLOAD
           SET CONSOL_REF_NO = P_CONSOL_REF_NO
         WHERE SCODE = X.SCODE
           AND XREF = PXREF
           AND ENTRY_NO = X.ENTRY_NO;
      
        IF PKG_REVR_ENTRY = 'Y' THEN
          DBG('printing pkg_revr_entry just before processing consol rvrsl in chota save entry');
          DBG('p_consol_ref_no is ' || P_CONSOL_REF_NO);
          DBG(' Entry Rec instrument number is ' ||
              PKG_ENTRY_REC.INSTRUMENT_NO_1);
          DBG(' Instr CCY ' || PKG_ENTRY_REC.INSTRUMENT_CCY);
          DBG('instrument_amt ' || PKG_ENTRY_REC.INSTRUMENT_AMT);
          DBG('acc_branch ' || PKG_ENTRY_REC.ACC_BRANCH);
          DBG('rem_account' || PKG_ENTRY_REC.REM_ACCOUNT);
          DBG('acc_ccy ' || PKG_ENTRY_REC.ACC_CCY);
        
          IF NOT FN_CONSOLIDATION_REVERSAL(P_CONSOL_REF_NO,
                                           PKG_ENTRY_REC,
                                           PKG_CASA_ERROR,
                                           P_ERROR,
                                           P_ERROR_PARAM,
                                           L_ACC_TAB,
                                           'Y') THEN
            DBG('Consolidation Reversal Failed from within save entry exception with pkg_revr_entry Y');
            RETURN FALSE;
          END IF;
        
          UPDATE IFTBS_CLEARING_UPLOAD
             SET REVERSAL_FLAG = 'Y'
           WHERE SCODE = X.SCODE
             AND XREF = PKG_ENTRY_REC.XREF
             AND ENTRY_NO = X.ENTRY_NO;
        
        END IF;
      END IF;
    
      DBG('calling nsf package to check for the represnted chq');
      DBG('remaccount-->' || X.REMACCOUNT || '~' || 'instrno-->' ||
          X.INSTRNO || '~' || 'Branch code-->' || X.TXN_BRN || '~' ||
          'direction-->' || X.DIRECTION || '~' || 'instrtype-->' ||
          X.INSTR_TYPE || '~' || 'Instr amt -->' || X.TXN_BRN || '~' ||
          'Xref-->' || X.XREF || '~' || 'txndate-->' || X.TXNDATE);
    
      SELECT COUNT(1)
        INTO L_CNT_NSF
        FROM IFTB_CLEARING_UPLOAD
       WHERE REMACCOUNT = X.REMACCOUNT
         AND INSTRNO = X.INSTRNO
         AND TXN_BRN = X.TXN_BRN
         AND STATUS IN ('REJR', 'REJA');
    
      DBG('l_cnt_nsf-->' || L_CNT_NSF);
    
      IF L_CNT_NSF > 0 AND L_STATUS = 'SUCC' THEN
        DBG('inside if to validate the status of blacklist cust after represnting chq');
        L_STATUS := 'SUCS';
        IF X.DIRECTION = 'I'
        
         THEN
        
          BEGIN
            SELECT AC_OR_GL
              INTO L_AC_OR_GL
              FROM STTBS_ACCOUNT
             WHERE AC_GL_NO = X.REMACCOUNT
                  
               AND BRANCH_CODE = NVL(X.REMBRANCH, X.TXN_BRN);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Something happened~' || SQLERRM);
              P_ERROR       := 'AC-VAC01';
              P_ERROR_PARAM := X.REMACCOUNT;
          END;
        
          IF L_AC_OR_GL = 'A' THEN
          
            BEGIN
              SELECT CUST_NO
                INTO L_CUSTNO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = X.REMACCOUNT
                    
                 AND BRANCH_CODE = NVL(X.REMBRANCH, X.TXN_BRN);
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('Failed in selecting the records');
                P_ERROR       := 'AC-VAC01';
                P_ERROR_PARAM := X.REMACCOUNT;
                RETURN FALSE;
            END;
          
            DBG('customer no-->' || L_CUSTNO);
            DBG('b4 entering into the function stpks_nsf.Fn_NSF_lvl_change');
            STPKS_NSF.G_SETT_STAT := 'CLR';
            DBG('clearing stat-->' || STPKS_NSF.G_SETT_STAT);
            IF NOT STPKS_NSF.FN_NSF_LVL_CHANGE(L_SOURCE,
                                               X.XREF,
                                               L_CUSTNO,
                                               
                                               L_STATUS,
                                               X.REMACCOUNT,
                                               X.TXNDATE,
                                               X.INSTRNO,
                                               X.INSTRAMT,
                                               
                                               NVL(X.REMBRANCH, X.TXN_BRN),
                                               L_NEW_STATUS,
                                               P_ERROR,
                                               P_ERROR_PARAM)
            
             THEN
              DBG('Failed in  Stpks_Fcmaint_Utils.Fn_Auth..');
              RETURN FALSE;
            END IF;
            DBG('Returning successfully from function Fn_NSF_lvl_change ');
          ELSE
            DBG('The account is not account GL');
          
          END IF;
        ELSE
          DBG(' clearing is not of inward type');
        END IF;
      ELSE
        DBG('Status need not be computed for the cutsomer');
      END IF;
    
    END LOOP;
  
    DBG('return11111  true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_save_entry ' || SQLERRM);
      P_ERROR := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_SAVE_ENTRY;

  FUNCTION FN_SAVE_ENTRY(PBRANCH       IN VARCHAR2,
                         P_FCCREF      OUT VARCHAR2,
                         P_ERROR       OUT VARCHAR2,
                         P_ERROR_PARAM OUT VARCHAR2,
                         P_FORCE_POST  IN VARCHAR2 DEFAULT 'N',
                         P_UPD_ONL     IN VARCHAR2 DEFAULT 'U')
    RETURN BOOLEAN IS
    L_COL_LIST  VARCHAR2(2000);
    L_DATA_LIST VARCHAR2(4000);
    PDTF        VARCHAR2(20);
    L_REF_NO    CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE;
    L_STATUS    CSTBS_CLEARING_MASTER.STATUS%TYPE;
    L_PROD      CSTBS_CLEARING_MASTER.PRODUCT_CODE%TYPE;
    L_INSTRNO   CSTBS_CLEARING_MASTER.INSTRUMENT_NO_1%TYPE;
    L_ENTRY_NO  CSTBS_CLEARING_MASTER.ENTRY_NO%TYPE;
    L_PARAM     CSTBS_PARAM.PARAM_VAL%TYPE;
    CURSOR C_UPLOAD_REC(PBRANCH VARCHAR2) IS
      SELECT A.*, A.ROWID R_ID
        FROM IFTBS_CLEARING_UPLOAD A
       WHERE A.TXN_BRN = PBRANCH
         AND A.STATUS = 'UNPR'
         AND A.AUTH_STAT = 'A'
         AND A.RECORD_STAT = 'O'
       ORDER BY A.XREF;
    CURSOR C_UPD_PRCD_FILE(PBRANCH VARCHAR2) IS
      SELECT A.*, A.ROWID R_ID
        FROM IFTBS_CLEARING_UPLOAD A
       WHERE A.TXN_BRN = PBRANCH
         AND A.STATUS = 'UNPR'
         AND A.AUTH_STAT = 'A'
         AND A.RECORD_STAT = 'O'
         AND A.FILE_ID IN (SELECT DISTINCT FILE_ID
                             FROM CATBS_MICR_TOTAL_CONTROL
                            WHERE PROCESSED_FLAG = 'Y')
       ORDER BY A.XREF;
  BEGIN
  
    PDTF := GLOBAL.GET_NLS_DT_FORMAT;
    SELECT PARAM_VAL
      INTO L_PARAM
      FROM CSTBS_PARAM
     WHERE PARAM_NAME = 'CHQ_ISSUED_IN_FCC';
    IF L_PARAM = 'N' THEN
      FOR I IN C_UPD_PRCD_FILE(PBRANCH) LOOP
        L_DATA_LIST := I.SCODE || '~' || I.XREF || '~' || I.PROD || '~' ||
                       I.TXN_BRN || '~' || I.REMACCOUNT || '~' || I.REMBANK || '~' ||
                       I.REMBRANCH || '~' || I.BENACCOUNT || '~' ||
                       I.BENBANK || '~' || I.BENBRANCH || '~' || I.INSTRNO || '~' ||
                       I.INSTRCCY || '~' || I.INSTRAMT || '~' ||
                       TO_CHAR(I.INSTRDATE, PDTF) || '~' ||
                       TO_CHAR(I.TXNDATE, PDTF) || '~' ||
                       TO_CHAR(I.VALDATECUST, PDTF) || '~' || I.LATECLG || '~' ||
                       I.ROUTINGNO || '~' || I.ENDPOINT || '~' ||
                       I.SERIALNO || '~' || I.FCCREF || '~' || I.STATUS || '~' ||
                       I.ENTRY_NO || '~' || I.BENE_CCY || '~' || I.DIN || '~' ||
                       TO_CHAR(I.DIN_DATE, PDTF) || '~' || I.REMARKS || '~';
        DEBUG.PR_DEBUG('CG', 'Data list is ..' || L_DATA_LIST);
      
        SAVEPOINT SP_IFTB_LOG1;
      
        IF NOT CSPKSS_CLG_SERV.FN_SAVE_ENTRY(L_COL_LIST,
                                             L_DATA_LIST,
                                             PDTF,
                                             L_REF_NO,
                                             L_STATUS,
                                             L_PROD,
                                             L_INSTRNO,
                                             L_ENTRY_NO,
                                             P_ERROR,
                                             P_ERROR_PARAM,
                                             'Y',
                                             'Y',
                                             I.R_ID,
                                             I.FORCE_POSTING,
                                             P_UPD_ONL) THEN
        
          DEBUG.PR_DEBUG('CG',
                         'Failed in fn save entry in second fn save entry');
        
          ROLLBACK TO SP_IFTB_LOG1;
        
          UPDATE IFTBS_CLEARING_UPLOAD
             SET STATUS       = 'ERRR',
                 FCCREF       = L_REF_NO,
                 ERROR_CODES  = P_ERROR,
                 ERROR_PARAMS = P_ERROR_PARAM
           WHERE ROWID = I.R_ID;
        
        END IF;
      END LOOP;
    ELSE
      FOR X IN C_UPLOAD_REC(PBRANCH) LOOP
        L_DATA_LIST := X.SCODE || '~' || X.XREF || '~' || X.PROD || '~' ||
                       X.TXN_BRN || '~' || X.REMACCOUNT || '~' || X.REMBANK || '~' ||
                       X.REMBRANCH || '~' || X.BENACCOUNT || '~' ||
                       X.BENBANK || '~' || X.BENBRANCH || '~' || X.INSTRNO || '~' ||
                       X.INSTRCCY || '~' || X.INSTRAMT || '~' ||
                       TO_CHAR(X.INSTRDATE, PDTF) || '~' ||
                       TO_CHAR(X.TXNDATE, PDTF) || '~' ||
                       TO_CHAR(X.VALDATECUST, PDTF) || '~' || X.LATECLG || '~' ||
                       X.ROUTINGNO || '~' || X.ENDPOINT || '~' ||
                       X.SERIALNO || '~' || X.FCCREF || '~' || X.STATUS || '~' ||
                       X.ENTRY_NO || '~' || X.BENE_CCY || '~' || X.DIN || '~' ||
                       TO_CHAR(X.DIN_DATE, PDTF) || '~' || X.REMARKS || '~';
        DEBUG.PR_DEBUG('CG', 'Data list is ..' || L_DATA_LIST);
      
        IF NOT CSPKSS_CLG_SERV.FN_SAVE_ENTRY(L_COL_LIST,
                                             L_DATA_LIST,
                                             PDTF,
                                             L_REF_NO,
                                             L_STATUS,
                                             L_PROD,
                                             L_INSTRNO,
                                             L_ENTRY_NO,
                                             P_ERROR,
                                             P_ERROR_PARAM,
                                             'Y',
                                             'Y',
                                             X.R_ID,
                                             X.FORCE_POSTING,
                                             P_UPD_ONL) THEN
        
          DEBUG.PR_DEBUG('CG',
                         'Failed in fn save entry in second fn save entry second Time');
        
          ROLLBACK TO SP_IFTB_LOG;
        
          UPDATE IFTBS_CLEARING_UPLOAD
             SET STATUS       = 'ERRR',
                 FCCREF       = L_REF_NO,
                 ERROR_CODES  = P_ERROR,
                 ERROR_PARAMS = P_ERROR_PARAM
           WHERE ROWID = X.R_ID;
        
        END IF;
      END LOOP;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_save_entry ' || SQLERRM);
      P_ERROR := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_SAVE_ENTRY;

  FUNCTION FN_SAVE_ENTRY(PXREF         IN VARCHAR2,
                         PENTRY_NO     IN NUMBER,
                         P_ERROR       OUT VARCHAR2,
                         P_ERROR_PARAM OUT VARCHAR2,
                         P_FORCE_POST  IN VARCHAR2 DEFAULT 'N',
                         P_UPD_ONL     IN VARCHAR2 DEFAULT 'U')
    RETURN BOOLEAN IS
    L_COL_LIST  VARCHAR2(2000);
    L_DATA_LIST VARCHAR2(4000);
    PDTF        VARCHAR2(20);
    L_REF_NO    CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE;
    L_STATUS    CSTBS_CLEARING_MASTER.STATUS%TYPE;
    L_PROD      CSTBS_CLEARING_MASTER.PRODUCT_CODE%TYPE;
    L_INSTRNO   CSTBS_CLEARING_MASTER.INSTRUMENT_NO_1%TYPE;
    L_ENTRY_NO  CSTBS_CLEARING_MASTER.ENTRY_NO%TYPE;
    CURSOR C_UPLOAD_REC(P_XREF VARCHAR2, P_ENTRY_NO NUMBER) IS
      SELECT A.*, A.ROWID R_ID
        FROM IFTBS_CLEARING_UPLOAD A
       WHERE XREF = P_XREF
         AND ENTRY_NO = P_ENTRY_NO
         AND STATUS = 'UNPR'
         AND A.AUTH_STAT = 'A'
         AND A.RECORD_STAT = 'O';
  BEGIN
  
    PDTF := GLOBAL.GET_NLS_DT_FORMAT;
    FOR X IN C_UPLOAD_REC(PXREF, PENTRY_NO) LOOP
      L_DATA_LIST := X.SCODE || '~' || X.XREF || '~' || X.PROD || '~' ||
                     X.TXN_BRN || '~' || X.REMACCOUNT || '~' || X.REMBANK || '~' ||
                     X.REMBRANCH || '~' || X.BENACCOUNT || '~' || X.BENBANK || '~' ||
                     X.BENBRANCH || '~' || X.INSTRNO || '~' || X.INSTRCCY || '~' ||
                     X.INSTRAMT || '~' || TO_CHAR(X.INSTRDATE, PDTF) || '~' ||
                     TO_CHAR(X.TXNDATE, PDTF) || '~' ||
                     TO_CHAR(X.VALDATECUST, PDTF) || '~' || X.LATECLG || '~' ||
                     X.ROUTINGNO || '~' || X.ENDPOINT || '~' || X.SERIALNO || '~' ||
                     X.FCCREF || '~' || X.STATUS || '~' || X.ENTRY_NO || '~' ||
                     X.BENE_CCY || '~';
      DEBUG.PR_DEBUG('CG', 'data list is ..' || L_DATA_LIST);
      IF NOT FN_SAVE_ENTRY(L_COL_LIST,
                           L_DATA_LIST,
                           PDTF,
                           L_REF_NO,
                           L_STATUS,
                           L_PROD,
                           L_INSTRNO,
                           L_ENTRY_NO,
                           P_ERROR,
                           P_ERROR_PARAM,
                           'Y',
                           'Y',
                           X.R_ID,
                           X.FORCE_POSTING,
                           P_UPD_ONL) THEN
        DEBUG.PR_DEBUG('CG',
                       'Failed in fn save entry in third fn save entry');
      
        UPDATE IFTBS_CLEARING_UPLOAD
           SET STATUS       = 'ERRR',
               FCCREF       = L_REF_NO,
               ERROR_CODES  = P_ERROR,
               ERROR_PARAMS = P_ERROR_PARAM
         WHERE ROWID = X.R_ID;
      
      END IF;
    END LOOP;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_save_entry ' || SQLERRM);
      P_ERROR := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_SAVE_ENTRY;

  PROCEDURE PR_SAVE_ENTRY(P_XREF       IN VARCHAR2,
                          P_ERR_CODE   OUT VARCHAR2,
                          P_ERR_MSG    OUT VARCHAR2,
                          P_FORCE_POST IN VARCHAR2 DEFAULT 'N',
                          P_UPD_ONL    IN VARCHAR2 DEFAULT 'U') IS
    L_NO_PROCS        NUMBER;
    L_TOTAL_RECS      NUMBER;
    L_BATCH_SIZE      NUMBER;
    L_PREV_PROCESS_ID NUMBER;
    L_PROCESS_ID      NUMBER;
    L_CNT             NUMBER;
    L_JOB_NO          NUMBER;
    L_WHAT            VARCHAR2(1000);
    MAX_REM           IFTBS_CLEARING_UPLOAD.REMACCOUNT%TYPE;
    MIN_REM           IFTBS_CLEARING_UPLOAD.REMACCOUNT%TYPE;
    MAX_BEN           IFTBS_CLEARING_UPLOAD.BENACCOUNT%TYPE;
    MIN_BEN           IFTBS_CLEARING_UPLOAD.BENACCOUNT%TYPE;
    L_ENTRY_NO        NUMBER;
    L_PRODUCT_TYPE    CHAR(2);
    REPEAT_CNT        INTEGER := 0;
    L_FCCREF          VARCHAR2(16);
    CURSOR C_REC(PXREF VARCHAR2) IS
      SELECT A.*
        FROM IFTBS_CLEARING_UPLOAD A, CSTMS_PRODUCT B
       WHERE A.PROD = B.PRODUCT_CODE
         AND A.XREF = PXREF
         AND A.STATUS = 'UNPR'
       ORDER BY DECODE(B.PRODUCT_TYPE,
                       'IC',
                       A.REMACCOUNT,
                       A.REMACCOUNT,
                       'OC',
                       A.BENACCOUNT,
                       A.BENACCOUNT);
  BEGIN
    L_NO_PROCS := CSPKSS_OS_PARAM.GET_PARAM_VAL('CLG_PROCESSES');
    DEBUG.PR_DEBUG('CG', 'Got no of proc as  ' || L_NO_PROCS);
    IF L_NO_PROCS IS NULL THEN
      L_NO_PROCS := 1;
    END IF;
  
    IF L_NO_PROCS = 1 THEN
      DEBUG.PR_DEBUG('CG', 'Calling for branch ' || GLOBAL.CURRENT_BRANCH);
      IF NOT FN_SAVE_ENTRY(GLOBAL.CURRENT_BRANCH,
                           L_FCCREF,
                           P_ERR_CODE,
                           P_ERR_MSG,
                           P_FORCE_POST,
                           P_UPD_ONL) THEN
        DEBUG.PR_DEBUG('CG',
                       'Error while calling fn_save_entry ' || P_ERR_CODE);
      ELSE
        DEBUG.PR_DEBUG('CG', 'Gor fccref as  ' || L_FCCREF);
      END IF;
    ELSE
      SELECT COUNT(*)
        INTO L_TOTAL_RECS
        FROM IFTBS_CLEARING_UPLOAD
       WHERE XREF = P_XREF
         AND STATUS = 'UNPR';
    
      L_BATCH_SIZE      := L_TOTAL_RECS / L_NO_PROCS;
      L_PREV_PROCESS_ID := 0;
      L_PROCESS_ID      := 1;
      L_CNT             := 0;
      L_ENTRY_NO        := 1;
      FOR X IN C_REC(P_XREF) LOOP
        UPDATE IFTBS_CLEARING_UPLOAD
           SET PROCESS_ID = L_PROCESS_ID
         WHERE XREF = P_XREF
           AND PROCESS_ID = -1
           AND ENTRY_NO = L_ENTRY_NO;
        L_CNT := L_CNT + 1;
        IF L_CNT > L_BATCH_SIZE THEN
          PR_GET_PROD(X.PROD);
          L_PRODUCT_TYPE := PKG_PROD_REC.PRODUCT_TYPE;
          IF (L_PRODUCT_TYPE = 'IC') THEN
            SELECT NVL(MAX(REMACCOUNT), '0')
              INTO MAX_REM
              FROM IFTBS_CLEARING_UPLOAD
             WHERE XREF = P_XREF
               AND STATUS = 'UNPR'
               AND PROCESS_ID = L_PREV_PROCESS_ID;
          
            SELECT COUNT(*)
              INTO REPEAT_CNT
              FROM IFTBS_CLEARING_UPLOAD
             WHERE XREF = P_XREF
               AND STATUS = 'UNPR'
               AND PROCESS_ID = L_PROCESS_ID
               AND REMACCOUNT = MAX_REM;
          
            IF (L_PREV_PROCESS_ID <> L_PROCESS_ID) AND (REPEAT_CNT <> 0) THEN
              UPDATE IFTBS_CLEARING_UPLOAD
                 SET PROCESS_ID = L_PREV_PROCESS_ID
               WHERE XREF = P_XREF
                 AND STATUS = 'UNPR'
                 AND PROCESS_ID = L_PROCESS_ID
                 AND REMACCOUNT = MAX_REM;
            END IF;
          ELSIF L_PRODUCT_TYPE = 'OC' THEN
            SELECT NVL(MAX(BENACCOUNT), '0')
              INTO MAX_BEN
              FROM IFTBS_CLEARING_UPLOAD
             WHERE XREF = P_XREF
               AND STATUS = 'UNPR'
               AND PROCESS_ID = L_PREV_PROCESS_ID;
          
            SELECT COUNT(*)
              INTO REPEAT_CNT
              FROM IFTBS_CLEARING_UPLOAD
             WHERE XREF = P_XREF
               AND STATUS = 'UNPR'
               AND PROCESS_ID = L_PROCESS_ID
               AND BENACCOUNT = MAX_BEN;
          
            IF (L_PREV_PROCESS_ID <> L_PROCESS_ID) AND (REPEAT_CNT <> 0) THEN
              UPDATE IFTBS_CLEARING_UPLOAD
                 SET PROCESS_ID = L_PREV_PROCESS_ID
               WHERE XREF = P_XREF
                 AND STATUS = 'UNPR'
                 AND PROCESS_ID = L_PROCESS_ID
                 AND BENACCOUNT = MAX_BEN;
            END IF;
          END IF;
          L_PREV_PROCESS_ID := L_PROCESS_ID;
          L_PROCESS_ID      := L_PROCESS_ID + 1;
          L_CNT             := 0;
        END IF;
        L_ENTRY_NO := L_ENTRY_NO + 1;
      END LOOP;
      COMMIT;
    
      FOR PROC_ID IN 1 .. L_NO_PROCS LOOP
      
        L_WHAT := 'BEGIN' || CHR(10);
        L_WHAT := L_WHAT || 'cspkss_clg_serv.pr_fire_job(' ||
                  CSPKES_MISC.FN_GETCHR(39) || P_XREF ||
                  CSPKES_MISC.FN_GETCHR(39) || ',' || PROC_ID ||
                  ' , job ); ' || CHR(10);
        L_WHAT := L_WHAT || 'debug.pr_close_db;' || CHR(10);
        L_WHAT := L_WHAT || 'END;' || CHR(10);
      
        DBMS_SCHEDULER.CREATE_JOB(JOB_NAME        => 'CLG_PROCESSES',
                                  JOB_TYPE        => 'PLSQL_BLOCK',
                                  JOB_ACTION      => L_WHAT,
                                  START_DATE      => SYSDATE,
                                  REPEAT_INTERVAL => NULL,
                                  ENABLED         => TRUE,
                                  COMMENTS        => 'CG');
      
        COMMIT;
      END LOOP;
      COMMIT;
    END IF;
  END PR_SAVE_ENTRY;

  PROCEDURE PR_FIRE_JOB(P_XREF VARCHAR2, P_PROCESS_ID NUMBER, P_JOB NUMBER) IS
    L_ERR_CODE VARCHAR2(255);
    L_ERR_MSG  VARCHAR2(2000);
  BEGIN
  
    IF NOT FN_SAVE_ENTRY(P_XREF, L_ERR_CODE, L_ERR_MSG, P_PROCESS_ID) THEN
      DEBUG.PR_DEBUG('CG', 'Failed in pr_fire_job...');
    END IF;
  END PR_FIRE_JOB;

  FUNCTION FN_BACKUP_CLG_TABLES(P_TRANSACTION_REF_NO IN VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    IF NOT FN_DELETE_BACKUP(P_TRANSACTION_REF_NO) THEN
      RETURN FALSE;
    END IF;
  
    DEBUG.PR_DEBUG('CG', 'Delete of backup tables done.');
  
    INSERT INTO CSTBS_TEMP_CLEARING_MASTER
      (DIRECTION,
       PRODUCT_CODE,
       TXN_BRANCH,
       END_POINT,
       REFERENCE_NO,
       REM_CUST,
       BEN_CUST,
       REM_ACCOUNT,
       BEN_ACCOUNT,
       REM_DETAILS1,
       REM_DETAILS2,
       REM_DETAILS3,
       BENE_DETAILS1,
       BENE_DETAILS2,
       BENE_DETAILS3,
       ACC_BRANCH,
       ACC_CCY,
       ACC_CCY_AMT,
       INSTRUMENT_CCY,
       INSTRUMENT_AMT,
       EXCH_RATE,
       INSTRUMENT_NO_1,
       INSTRUMENT_NO_2,
       STATUS,
       TXN_DATE,
       INSTRUMENT_DATE,
       VAL_DATE,
       BANK_CODE,
       BRANCH_CODE,
       SECTOR_CODE,
       ROUTING_NO,
       LATE_CLG_FLG,
       ERR_CODE,
       REJECT_REASON,
       RECORD_STAT,
       AUTH_STAT,
       MAKER_ID,
       MAKER_DT_STAMP,
       CHECKER_ID,
       CHECKER_DT_STAMP,
       XREF,
       SCODE,
       SERIAL_NO,
       ENTRY_NO,
       MODULE_REFERENCE_NO,
       EVENT_SEQ_NO,
       MODULE_CODE,
       BENE_CCY)
      SELECT DIRECTION,
             PRODUCT_CODE,
             TXN_BRANCH,
             END_POINT,
             REFERENCE_NO,
             REM_CUST,
             BEN_CUST,
             REM_ACCOUNT,
             BEN_ACCOUNT,
             REM_DETAILS1,
             REM_DETAILS2,
             REM_DETAILS3,
             BENE_DETAILS1,
             BENE_DETAILS2,
             BENE_DETAILS3,
             ACC_BRANCH,
             ACC_CCY,
             ACC_CCY_AMT,
             INSTRUMENT_CCY,
             INSTRUMENT_AMT,
             EXCH_RATE,
             INSTRUMENT_NO_1,
             INSTRUMENT_NO_2,
             STATUS,
             TXN_DATE,
             INSTRUMENT_DATE,
             VAL_DATE_CUST,
             BANK_CODE,
             BRANCH_CODE,
             SECTOR_CODE,
             ROUTING_NO,
             LATE_CLG_FLG,
             ERR_CODE,
             REJECT_REASON,
             RECORD_STAT,
             AUTH_STAT,
             MAKER_ID,
             MAKER_DT_STAMP,
             CHECKER_ID,
             CHECKER_DT_STAMP,
             XREF,
             SCODE,
             SERIAL_NO,
             ENTRY_NO,
             MODULE_REFERENCE_NO,
             EVENT_SEQ_NO,
             MODULE_CODE,
             BENE_CCY
        FROM CSTBS_CLEARING_MASTER
       WHERE REFERENCE_NO = P_TRANSACTION_REF_NO;
  
    DEBUG.PR_DEBUG('CG', 'cstbs_clearing_master backed up');
  
    INSERT INTO CGTBS_TEMP_TRANSACTION_MASTER
      (BRANCH_CODE,
       PRODUCT_CODE,
       TRANSACTION_REF_NO,
       USER_REF_NO,
       BENEFICIARY_BRANCH,
       BENEFICIARY_ACCOUNT,
       INSTRUMENT_NO,
       INSTRUMENT_CCY,
       INSTRUMENT_AMOUNT,
       INSTRUMENT_DATE,
       TRANSACTION_DATE,
       VALUE_DATE,
       LATE_CLEARING,
       ROUTING_NO,
       REJECT_REASON,
       CHECKER_ID,
       CHECKER_DT_STAMP,
       MAKER_ID,
       MAKER_DT_STAMP,
       AUTH_STAT,
       RECORD_STAT,
       REMITTER_ACCOUNT,
       STATUS,
       CONSIDER_FOR_REG_CC)
      SELECT BRANCH_CODE,
             PRODUCT_CODE,
             TRANSACTION_REF_NO,
             USER_REF_NO,
             BENEFICIARY_BRANCH,
             BENEFICIARY_ACCOUNT,
             INSTRUMENT_NO,
             INSTRUMENT_CCY,
             INSTRUMENT_AMOUNT,
             INSTRUMENT_DATE,
             TRANSACTION_DATE,
             VALUE_DATE,
             LATE_CLEARING,
             ROUTING_NO,
             REJECT_REASON,
             CHECKER_ID,
             CHECKER_DT_STAMP,
             MAKER_ID,
             MAKER_DT_STAMP,
             AUTH_STAT,
             RECORD_STAT,
             REMITTER_ACCOUNT,
             STATUS,
             CONSIDER_FOR_REG_CC
        FROM CGTBS_TRANSACTION_MASTER
       WHERE TRANSACTION_REF_NO = P_TRANSACTION_REF_NO;
  
    DEBUG.PR_DEBUG('CG', 'cgtbs_transaction_master backed up');
  
    RETURN(TRUE);
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Error While backingup tables ' || SQLERRM);
      DEBUG.PR_DEBUG('CG',
                     'Bombed in cspks_clg_serv.fn_backup with ' || SQLERRM);
      RETURN(FALSE);
  END FN_BACKUP_CLG_TABLES;

  FUNCTION FN_DELETE_BACKUP(P_TRANSACTION_REF_NO IN VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DELETE FROM CSTBS_TEMP_CLEARING_MASTER
     WHERE REFERENCE_NO = P_TRANSACTION_REF_NO;
  
    DELETE FROM CGTBS_TEMP_TRANSACTION_MASTER
     WHERE TRANSACTION_REF_NO = P_TRANSACTION_REF_NO;
  
    DEBUG.PR_DEBUG('CG', 'Temp tables deleted');
    RETURN(TRUE);
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Error While deleting temp tables ' || SQLERRM);
      DEBUG.PR_DEBUG('CG',
                     'Bombed in cspks_clg_serv.fn_delete_backup with ' ||
                     SQLERRM);
      RETURN(FALSE);
  END FN_DELETE_BACKUP;

  FUNCTION FN_RESTORE(P_TRANSACTION_REF_NO IN VARCHAR2) RETURN BOOLEAN IS
    L_EVENT_SEQ_NO NUMBER;
  BEGIN
    SELECT EVENT_SEQ_NO
      INTO L_EVENT_SEQ_NO
      FROM CSTBS_CLEARING_MASTER
     WHERE REFERENCE_NO = P_TRANSACTION_REF_NO;
  
    IF L_EVENT_SEQ_NO > 1 THEN
    
      DELETE FROM CSTBS_CLEARING_MASTER
       WHERE REFERENCE_NO = P_TRANSACTION_REF_NO;
    
      INSERT INTO CSTBS_CLEARING_MASTER
        (DIRECTION,
         PRODUCT_CODE,
         TXN_BRANCH,
         END_POINT,
         REFERENCE_NO,
         REM_CUST,
         BEN_CUST,
         REM_ACCOUNT,
         BEN_ACCOUNT,
         REM_DETAILS1,
         REM_DETAILS2,
         REM_DETAILS3,
         BENE_DETAILS1,
         BENE_DETAILS2,
         BENE_DETAILS3,
         ACC_BRANCH,
         ACC_CCY,
         ACC_CCY_AMT,
         INSTRUMENT_CCY,
         INSTRUMENT_AMT,
         EXCH_RATE,
         INSTRUMENT_NO_1,
         INSTRUMENT_NO_2,
         STATUS,
         TXN_DATE,
         INSTRUMENT_DATE,
         VAL_DATE_CUST,
         BANK_CODE,
         BRANCH_CODE,
         SECTOR_CODE,
         ROUTING_NO,
         LATE_CLG_FLG,
         ERR_CODE,
         REJECT_REASON,
         RECORD_STAT,
         AUTH_STAT,
         MAKER_ID,
         MAKER_DT_STAMP,
         CHECKER_ID,
         CHECKER_DT_STAMP,
         XREF,
         SCODE,
         SERIAL_NO,
         ENTRY_NO,
         MODULE_REFERENCE_NO,
         EVENT_SEQ_NO,
         MODULE_CODE,
         BENE_CCY)
        SELECT DIRECTION,
               PRODUCT_CODE,
               TXN_BRANCH,
               END_POINT,
               REFERENCE_NO,
               REM_CUST,
               BEN_CUST,
               REM_ACCOUNT,
               BEN_ACCOUNT,
               REM_DETAILS1,
               REM_DETAILS2,
               REM_DETAILS3,
               BENE_DETAILS1,
               BENE_DETAILS2,
               BENE_DETAILS3,
               ACC_BRANCH,
               ACC_CCY,
               ACC_CCY_AMT,
               INSTRUMENT_CCY,
               INSTRUMENT_AMT,
               EXCH_RATE,
               INSTRUMENT_NO_1,
               INSTRUMENT_NO_2,
               STATUS,
               TXN_DATE,
               INSTRUMENT_DATE,
               VAL_DATE,
               BANK_CODE,
               BRANCH_CODE,
               SECTOR_CODE,
               ROUTING_NO,
               LATE_CLG_FLG,
               ERR_CODE,
               REJECT_REASON,
               RECORD_STAT,
               AUTH_STAT,
               MAKER_ID,
               MAKER_DT_STAMP,
               CHECKER_ID,
               CHECKER_DT_STAMP,
               XREF,
               SCODE,
               SERIAL_NO,
               ENTRY_NO,
               MODULE_REFERENCE_NO,
               EVENT_SEQ_NO,
               MODULE_CODE,
               BENE_CCY
          FROM CSTBS_TEMP_CLEARING_MASTER
         WHERE REFERENCE_NO = P_TRANSACTION_REF_NO;
    
      DEBUG.PR_DEBUG('CG', 'cstbs_clearing_master restored');
    
      DELETE FROM CGTBS_TRANSACTION_MASTER
       WHERE TRANSACTION_REF_NO = P_TRANSACTION_REF_NO;
    
      INSERT INTO CGTBS_TRANSACTION_MASTER
        (BRANCH_CODE,
         PRODUCT_CODE,
         TRANSACTION_REF_NO,
         USER_REF_NO,
         BENEFICIARY_BRANCH,
         BENEFICIARY_ACCOUNT,
         INSTRUMENT_NO,
         INSTRUMENT_CCY,
         INSTRUMENT_AMOUNT,
         INSTRUMENT_DATE,
         TRANSACTION_DATE,
         VALUE_DATE,
         LATE_CLEARING,
         ROUTING_NO,
         REJECT_REASON,
         CHECKER_ID,
         CHECKER_DT_STAMP,
         MAKER_ID,
         MAKER_DT_STAMP,
         AUTH_STAT,
         RECORD_STAT,
         REMITTER_ACCOUNT,
         STATUS,
         CONSIDER_FOR_REG_CC)
        SELECT BRANCH_CODE,
               PRODUCT_CODE,
               TRANSACTION_REF_NO,
               USER_REF_NO,
               BENEFICIARY_BRANCH,
               BENEFICIARY_ACCOUNT,
               INSTRUMENT_NO,
               INSTRUMENT_CCY,
               INSTRUMENT_AMOUNT,
               INSTRUMENT_DATE,
               TRANSACTION_DATE,
               VALUE_DATE,
               LATE_CLEARING,
               ROUTING_NO,
               REJECT_REASON,
               CHECKER_ID,
               CHECKER_DT_STAMP,
               MAKER_ID,
               MAKER_DT_STAMP,
               AUTH_STAT,
               RECORD_STAT,
               REMITTER_ACCOUNT,
               STATUS,
               CONSIDER_FOR_REG_CC
          FROM CGTBS_TEMP_TRANSACTION_MASTER
         WHERE TRANSACTION_REF_NO = P_TRANSACTION_REF_NO;
      DEBUG.PR_DEBUG('CG', 'cgtbs_transaction_master restored');
      IF NOT FN_DELETE_BACKUP(P_TRANSACTION_REF_NO) THEN
        RETURN FALSE;
      END IF;
      DEBUG.PR_DEBUG('CG', 'Delete of backup tables done.');
    ELSIF L_EVENT_SEQ_NO = 1 THEN
      DELETE FROM CSTBS_CLEARING_MASTER
       WHERE REFERENCE_NO = P_TRANSACTION_REF_NO;
      DELETE FROM CGTBS_TRANSACTION_MASTER
       WHERE TRANSACTION_REF_NO = P_TRANSACTION_REF_NO;
      DEBUG.PR_DEBUG('CG', 'Delete done.');
    END IF;
  
    RETURN(TRUE);
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Error While restoring tables ' || SQLERRM);
      DEBUG.PR_DEBUG('CG',
                     'Bombed in cspks_clg_serv.fn_restore with ' || SQLERRM);
      RETURN(FALSE);
  END FN_RESTORE;

  FUNCTION FN_FRAME_CHG_ENTRIES(P_BRANCH       IN VARCHAR2,
                                P_ENTRY_REC    IN CSTBS_CLEARING_MASTER%ROWTYPE,
                                P_CHG_ROW      IN IFTMS_ARC_MAINT%ROWTYPE,
                                P_ACC_HAND     IN OUT ACPKSS.TBL_ACHOFF,
                                I              IN NUMBER,
                                P_PRODUCT_TYPE IN VARCHAR2,
                                P_ERR_CODE     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_ACC_CCY_CHG        NUMBER(22, 3);
    L_ACC_CHG_EXCH_RATE  ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    L_COD_CHG_AMT        IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_COD_CHG_CCY        IFTMS_ARC_MAINT.COD_CHG_CCY%TYPE;
    L_COD_MIS_HEAD       IFTMS_ARC_MAINT.COD_MIS_HEAD1%TYPE;
    L_COD_CHG_TXN_CODE   IFTMS_ARC_MAINT.COD_CHG_TXN_CODE1%TYPE;
    L_COD_CHG_NETTING    IFTMS_ARC_MAINT.COD_CHG_NETTING1%TYPE;
    L_COD_CHG_GL         IFTMS_ARC_MAINT.COD_CHG_GL%TYPE;
    L_COD_RATE_CODE      IFTMS_ARC_MAINT.COD_RATE_CODE%TYPE;
    L_COD_RATE_CODE_TYPE IFTMS_ARC_MAINT.COD_RATE_CODE_TYPE%TYPE;
  
    L_COD_CHG_DESC IFTMS_ARC_MAINT.COD_CHG_DESC%TYPE;
    L_COD_CHG_TYPE IFTMS_ARC_MAINT.COD_CHG_TYPE%TYPE;
    K              NUMBER;
    L_AMT          NUMBER;
    L_WAIVER       VARCHAR2(1);
  
    J            NUMBER;
    L_ACC_NO_DR  CSTBS_CLEARING_MASTER.REM_ACCOUNT%TYPE;
    L_ACC_BRN_DR CSTBS_CLEARING_MASTER.ACC_BRANCH%TYPE;
    L_ACC_CCY_DR CSTBS_CLEARING_MASTER.ACC_CCY%TYPE;
    L_ACCCCYAMT  NUMBER;
    L_RATE       ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
  
    L_AC_CCY     VARCHAR2(3);
    L_LCY_AMOUNT NUMBER;
    L_FCY_AMOUNT NUMBER;
    L_EXCH_RATE  NUMBER;
  
    L_EVENT_CODE VARCHAR2(100) := 'INIT';
    L_EVENT_SEQ  NUMBER := 1;
  
    L_COD_CHG_TRACK_PRF IFTMS_ARC_MAINT.COD_CHG_TRACK_PRF%TYPE;
    L_COD_CHG_LIQD_PRF  IFTMS_ARC_MAINT.COD_CHG_LIQD_PRF%TYPE;
    L_AC_OR_GL          STTBS_ACCOUNT.AC_OR_GL%TYPE;
    L_COD_CHG_AMT_NSF   IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_RET               NUMBER := 0;
    L_CHG_SEQ           NUMBER;
    L_COD_CHG_AMT_TEMP  IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_CHG_LCY_TEMP      NUMBER;
    L_CRDR_IND          VARCHAR2(1);
    L_MODULE_CODE       CSTB_CLEARING_MASTER.MODULE_CODE%TYPE;
  
    L_LCY_AMOUNT1 NUMBER;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
    DEBUG.PR_DEBUG('CG', 'To frame chg entries ' || I);
    DEBUG.PR_DEBUG('CG', 'Chg here is ' || P_CHG_ROW.COD_CHG_AMT);
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
    
      DBG('cspks_clg_serv_cluster.FN_PRE_FRAME_CHG_ENTRIES ');
      IF NOT
          CSPKS_CLG_SERV_CLUSTER.FN_PRE_FRAME_CHG_ENTRIES(P_BRANCH,
                                                          P_ENTRY_REC,
                                                          P_CHG_ROW,
                                                          P_ACC_HAND,
                                                          I,
                                                          P_PRODUCT_TYPE,
                                                          P_ERR_CODE,
                                                          L_FN_CALL_ID,
                                                          L_TB_CLUSTER_DATA)
      
       THEN
        DBG('Failure has happened in cspks_clg_serv_cluster.FN_CHG_PROC');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      L_MODULE_CODE := 'CG';
    
      IF P_ENTRY_REC.DISPATCH_STATUS = 'D' THEN
        L_EVENT_CODE := 'LIQD';
        L_EVENT_SEQ  := 4;
      END IF;
    
      IF ICPKS_BOD.G_MANUAL_ROLL THEN
      
        L_EVENT_CODE  := 'MROL';
        L_MODULE_CODE := 'TD';
      END IF;
    
      IF I = 1 THEN
        L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT;
        L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE;
        L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD1;
        L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE;
        L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING;
        L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL;
        L_COD_CHG_DESC       := P_CHG_ROW.COD_CHG_DESC;
        L_COD_CHG_TYPE       := P_CHG_ROW.COD_CHG_TYPE;
      
        L_COD_CHG_TRACK_PRF := P_CHG_ROW.COD_CHG_TRACK_PRF;
        L_COD_CHG_LIQD_PRF  := P_CHG_ROW.COD_CHG_LIQD_PRF;
      
        J := 1;
      ELSIF I = 2 THEN
        L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT1;
        L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY1;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE1;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE1;
        L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD2;
        L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE1;
        L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING1;
        L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL1;
        L_COD_CHG_DESC       := P_CHG_ROW.COD_CHG_DESC1;
        L_COD_CHG_TYPE       := P_CHG_ROW.COD_CHG_TYPE1;
      
        L_COD_CHG_TRACK_PRF := P_CHG_ROW.COD_CHG_TRACK_PRF1;
        L_COD_CHG_LIQD_PRF  := P_CHG_ROW.COD_CHG_LIQD_PRF1;
      
        J := 3;
      ELSIF I = 3 THEN
        L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT2;
        L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY2;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE2;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE2;
        L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD3;
        L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE2;
        L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING2;
        L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL2;
        L_COD_CHG_DESC       := P_CHG_ROW.COD_CHG_DESC2;
        L_COD_CHG_TYPE       := P_CHG_ROW.COD_CHG_TYPE2;
      
        L_COD_CHG_TRACK_PRF := P_CHG_ROW.COD_CHG_TRACK_PRF2;
        L_COD_CHG_LIQD_PRF  := P_CHG_ROW.COD_CHG_LIQD_PRF2;
      
        J := 5;
      ELSIF I = 4 THEN
        L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT3;
        L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY3;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE3;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE3;
        L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD4;
        L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE3;
        L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING3;
        L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL3;
        L_COD_CHG_DESC       := P_CHG_ROW.COD_CHG_DESC3;
        L_COD_CHG_TYPE       := P_CHG_ROW.COD_CHG_TYPE3;
      
        L_COD_CHG_TRACK_PRF := P_CHG_ROW.COD_CHG_TRACK_PRF3;
        L_COD_CHG_LIQD_PRF  := P_CHG_ROW.COD_CHG_LIQD_PRF3;
      
        J := 7;
      ELSIF I = 5 THEN
        L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT4;
        L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY4;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE4;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE4;
        L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD5;
        L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE4;
        L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING4;
        L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL4;
        L_COD_CHG_DESC       := P_CHG_ROW.COD_CHG_DESC4;
        L_COD_CHG_TYPE       := P_CHG_ROW.COD_CHG_TYPE4;
      
        L_COD_CHG_TRACK_PRF := P_CHG_ROW.COD_CHG_TRACK_PRF4;
        L_COD_CHG_LIQD_PRF  := P_CHG_ROW.COD_CHG_LIQD_PRF4;
      
        J := 9;
      END IF;
      DBG('l_cod_chg_track_prf--> ' || L_COD_CHG_TRACK_PRF);
      DBG('l_cod_chg_liqd_prf--> ' || L_COD_CHG_LIQD_PRF);
    
      IF GWPKS_UTIL.G_FROM_BEAN THEN
      
        DBG('After Charge Pickup : gwpks_util.pkg_actType = ' ||
            GWPKS_UTIL.PKG_ACTTYPE);
      
        K     := 0;
        L_AMT := 0;
      
        IF (REPLACE(GWPKS_UTIL.PKG_CHG_DETS, '~', NULL) IS NOT NULL) THEN
        
          DBG('Charge recd ... ' || GWPKS_UTIL.PKG_CHG_DETS);
          WHILE NVL(CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS, K, '~'),
                    ' ') <> 'EOPL' LOOP
            K := K + 1;
          END LOOP;
          K := K - 1;
          DBG('i IS ' || I);
          DBG('k IS ' || K);
          IF I = 1 AND K > 1 THEN
            L_AMT := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                             1,
                                             '~');
            IF L_AMT IS NOT NULL THEN
              DBG('First Chg IS NOT NULL');
              L_COD_CHG_AMT := L_AMT;
              L_COD_CHG_CCY := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                                       2,
                                                       '~');
            ELSE
              DBG('First Chg IS VERY MUCH NULL');
              L_COD_CHG_AMT := NULL;
              L_COD_CHG_CCY := NULL;
            END IF;
          ELSIF I = 2 AND K > 3 THEN
            L_AMT := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                             3,
                                             '~');
            IF L_AMT IS NOT NULL THEN
              DBG('Second Chg IS NOT NULL');
              L_COD_CHG_AMT := L_AMT;
              L_COD_CHG_CCY := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                                       4,
                                                       '~');
            ELSE
              DBG('Second Chg IS VERY MUCH NULL');
              L_COD_CHG_AMT := NULL;
              L_COD_CHG_CCY := NULL;
            END IF;
          ELSIF I = 3 AND K > 5 THEN
            L_AMT := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                             5,
                                             '~');
            IF L_AMT IS NOT NULL THEN
              DBG('Third Chg IS NOT NULL');
              L_COD_CHG_AMT := L_AMT;
              L_COD_CHG_CCY := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                                       6,
                                                       '~');
            ELSE
              DBG('Third Chg IS VERY MUCH NULL');
              L_COD_CHG_AMT := NULL;
              L_COD_CHG_CCY := NULL;
            END IF;
          ELSIF I = 4 AND K > 7 THEN
            L_AMT := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                             7,
                                             '~');
            IF L_AMT IS NOT NULL THEN
              DBG('Fourth Chg IS NOT NULL');
              L_COD_CHG_AMT := L_AMT;
              L_COD_CHG_CCY := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                                       8,
                                                       '~');
            ELSE
              DBG('Fourth Chg IS VERY MUCH NULL');
              L_COD_CHG_AMT := NULL;
              L_COD_CHG_CCY := NULL;
            END IF;
          ELSIF I = 5 AND K > 9 THEN
            L_AMT := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                             9,
                                             '~');
            IF L_AMT IS NOT NULL THEN
              DBG('Fifth Chg IS NOT NULL');
              L_COD_CHG_AMT := L_AMT;
              L_COD_CHG_CCY := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                                       10,
                                                       '~');
            ELSE
              DBG('Fifth Chg IS VERY MUCH NULL');
              L_COD_CHG_AMT := NULL;
              L_COD_CHG_CCY := NULL;
            END IF;
          END IF;
        END IF;
      END IF;
    
      DEBUG.PR_DEBUG('CG', 'Amt is ' || L_COD_CHG_AMT);
      IF L_COD_CHG_AMT IS NOT NULL THEN
        DEBUG.PR_DEBUG('CG', 'Dr leg of charges...');
        DBG('Product_type~p_entry_rec.instrument_ccy~p_entry_rec.acc_ccy : ' ||
            P_PRODUCT_TYPE || '~' || P_ENTRY_REC.INSTRUMENT_CCY || '~' ||
            P_ENTRY_REC.ACC_CCY);
        IF P_PRODUCT_TYPE = 'IC' THEN
          IF (P_CHG_ROW.DR_ACC = P_CHG_ROW.CHG_FROM) THEN
            L_ACC_NO_DR  := P_ENTRY_REC.REM_ACCOUNT;
            L_ACC_BRN_DR := P_ENTRY_REC.ACC_BRANCH;
            L_ACC_CCY_DR := P_ENTRY_REC.ACC_CCY;
          END IF;
          DEBUG.PR_DEBUG('CG', 'l_acc_ccy_dr before TXN' || L_ACC_CCY_DR);
          IF (P_CHG_ROW.DR_ACC <> NVL(P_CHG_ROW.CHG_FROM, '*')) THEN
            IF P_CHG_ROW.CHG_FROM = 'TXN' THEN
              BEGIN
                SELECT NVL(AC_GL_CCY, P_ENTRY_REC.INSTRUMENT_CCY)
                  INTO L_ACC_CCY_DR
                  FROM STTB_ACCOUNT
                 WHERE AC_GL_NO = P_CHG_ROW.COD_TXN_ACCOUNT
                   AND BRANCH_CODE = P_CHG_ROW.COD_TXN_BRN;
              EXCEPTION
                WHEN OTHERS THEN
                  L_ACC_CCY_DR := P_ENTRY_REC.ACC_CCY;
              END;
              L_ACC_NO_DR  := P_CHG_ROW.COD_TXN_ACCOUNT;
              L_ACC_BRN_DR := P_CHG_ROW.COD_TXN_BRN;
              L_ACC_CCY_DR := L_ACC_CCY_DR;
              DEBUG.PR_DEBUG('CG', 'l_acc_ccy_dr ' || L_ACC_CCY_DR);
            ELSE
              BEGIN
                SELECT NVL(AC_GL_CCY, P_ENTRY_REC.INSTRUMENT_CCY)
                  INTO L_ACC_CCY_DR
                  FROM STTB_ACCOUNT
                 WHERE AC_GL_NO = P_CHG_ROW.COD_OFFSET_ACC
                   AND BRANCH_CODE = P_CHG_ROW.COD_OFFSET_BRN;
              EXCEPTION
                WHEN OTHERS THEN
                  L_ACC_CCY_DR := P_ENTRY_REC.ACC_CCY;
              END;
              L_ACC_NO_DR  := P_CHG_ROW.COD_OFFSET_ACC;
              L_ACC_BRN_DR := P_CHG_ROW.COD_OFFSET_BRN;
              L_ACC_CCY_DR := L_ACC_CCY_DR;
            END IF;
          END IF;
          IF L_ACC_CCY_DR = '*.*' THEN
            L_ACC_CCY_DR := P_ENTRY_REC.ACC_CCY;
          END IF;
          IF P_CHG_ROW.COD_OFFSET_BRN = '*.*' THEN
            L_ACC_BRN_DR := P_ENTRY_REC.ACC_BRANCH;
          END IF;
          L_CRDR_IND := 'D';
        END IF;
      
        IF P_PRODUCT_TYPE = 'OC' THEN
          DBG('p_chg_row.dr_acc : ' || P_CHG_ROW.DR_ACC);
          DBG('p_chg_row.chg_from : ' || P_CHG_ROW.CHG_FROM);
        
          IF (P_CHG_ROW.DR_ACC <> NVL(P_CHG_ROW.CHG_FROM, '*')) THEN
            DBG('here11111');
            L_ACC_NO_DR  := P_ENTRY_REC.BEN_ACCOUNT;
            L_ACC_BRN_DR := P_ENTRY_REC.ACC_BRANCH;
            L_ACC_CCY_DR := P_ENTRY_REC.ACC_CCY;
          END IF;
          IF (P_CHG_ROW.DR_ACC = P_CHG_ROW.CHG_FROM) THEN
            DBG('p_chg_row.chg_from :' || P_CHG_ROW.CHG_FROM);
            IF P_CHG_ROW.CHG_FROM = 'TXN' THEN
              DBG('p_chg_row.cod_txn_brn~p_chg_row.cod_txn_account : ' ||
                  P_CHG_ROW.COD_TXN_BRN || '~' ||
                  P_CHG_ROW.COD_TXN_ACCOUNT);
              BEGIN
                SELECT NVL(AC_GL_CCY, P_ENTRY_REC.INSTRUMENT_CCY)
                  INTO L_ACC_CCY_DR
                  FROM STTB_ACCOUNT
                 WHERE AC_GL_NO = P_CHG_ROW.COD_TXN_ACCOUNT
                   AND BRANCH_CODE = P_CHG_ROW.COD_TXN_BRN;
              EXCEPTION
                WHEN OTHERS THEN
                  L_ACC_CCY_DR := P_ENTRY_REC.ACC_CCY;
              END;
              L_ACC_NO_DR  := P_CHG_ROW.COD_TXN_ACCOUNT;
              L_ACC_BRN_DR := P_CHG_ROW.COD_TXN_BRN;
              L_ACC_CCY_DR := L_ACC_CCY_DR;
            ELSE
              DBG('p_chg_row.cod_offset_brn~p_chg_row.cod_offset_acc : ' ||
                  P_CHG_ROW.COD_OFFSET_BRN || '~' ||
                  P_CHG_ROW.COD_OFFSET_ACC);
              BEGIN
                SELECT NVL(AC_GL_CCY, P_ENTRY_REC.INSTRUMENT_CCY)
                  INTO L_ACC_CCY_DR
                  FROM STTB_ACCOUNT
                 WHERE AC_GL_NO = P_CHG_ROW.COD_OFFSET_ACC
                   AND BRANCH_CODE = P_CHG_ROW.COD_OFFSET_BRN;
              EXCEPTION
                WHEN OTHERS THEN
                  L_ACC_CCY_DR := P_ENTRY_REC.ACC_CCY;
              END;
              L_ACC_NO_DR  := P_CHG_ROW.COD_OFFSET_ACC;
              L_ACC_BRN_DR := P_CHG_ROW.COD_OFFSET_BRN;
              L_ACC_CCY_DR := L_ACC_CCY_DR;
            END IF;
          END IF;
          DBG('l_acc_ccy_dr~p_chg_row.cod_offset_brn' || L_ACC_CCY_DR || '~' ||
              P_CHG_ROW.COD_OFFSET_BRN);
          IF L_ACC_CCY_DR = '*.*' THEN
            L_ACC_CCY_DR := P_ENTRY_REC.ACC_CCY;
          END IF;
          IF P_CHG_ROW.COD_OFFSET_BRN = '*.*' THEN
            L_ACC_BRN_DR := P_ENTRY_REC.ACC_BRANCH;
          END IF;
          L_CRDR_IND := 'C';
        END IF;
        DBG('l_acc_ccy_dr : ' || L_ACC_CCY_DR);
      
        DBG('Account is >> l_acc_no_dr-->  ' || L_ACC_NO_DR);
        DBG('branch is >> l_acc_brn_dr-->  ' || L_ACC_BRN_DR);
      
        DBG('branch is >> l_acc_ccy_dr-->  ' || L_ACC_CCY_DR);
        DBG('p_entry_rec.acc_ccy--> ' || P_ENTRY_REC.ACC_CCY);
        DBG('p_entry_rec.instrument_ccy--> ' || P_ENTRY_REC.INSTRUMENT_CCY);
      
        IF L_ACC_CCY_DR IS NULL THEN
          L_ACC_CCY_DR := NVL(P_ENTRY_REC.ACC_CCY,
                              P_ENTRY_REC.INSTRUMENT_CCY);
        END IF;
      
        BEGIN
          SELECT AC_OR_GL
            INTO L_AC_OR_GL
            FROM STTBS_ACCOUNT
           WHERE BRANCH_CODE = L_ACC_BRN_DR
             AND AC_GL_NO = L_ACC_NO_DR;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_AC_OR_GL := 'X';
        END;
        DBG('l_cod_chg_track_prf-->  ' || L_COD_CHG_TRACK_PRF);
        IF NVL(L_COD_CHG_TRACK_PRF, 'N') <> 'N' AND L_AC_OR_GL = 'A' THEN
          PKG_NSF_TRACKED       := 'Y';
          P_TRACK_CHG_ENTRY_NSF := 'Y';
        
          L_CHG_SEQ := I;
        
          DBG('p_trn_ref_no-->  ' || P_ENTRY_REC.REFERENCE_NO);
          DBG('p_prod-->  ' || P_ENTRY_REC.PRODUCT_CODE);
          DBG('p_entry_rec.branch_code-->  ' || P_ENTRY_REC.BRANCH_CODE);
          DBG('g_txn_acc-->  ' || G_TXN_ACC);
          DBG('p_entry_rec.acc_ccy_amt-->  ' || P_ENTRY_REC.ACC_CCY_AMT);
          DBG('p_entry_rec.txn_date-->  ' || P_ENTRY_REC.TXN_DATE);
        
          DBG('l_acc_brn_dr-->  ' || L_ACC_BRN_DR);
          DBG('l_acc_no_dr-->  ' || L_ACC_NO_DR);
          DBG('l_cod_chg_amt-->  ' || L_COD_CHG_AMT);
          DBG('l_acc_ccy_dr-->  ' || L_ACC_CCY_DR);
          DBG('l_cod_chg_ccy-->  ' || L_COD_CHG_CCY);
          DBG('l_cod_rate_code-->  ' || L_COD_RATE_CODE);
          DBG('l_cod_rate_code_type-->  ' || L_COD_RATE_CODE_TYPE);
          DBG('l_cod_chg_track_prf-->  ' || L_COD_CHG_TRACK_PRF);
          DBG('l_chg_seq-->  ' || L_CHG_SEQ);
          DBG('l_crdr_ind-->  ' || L_CRDR_IND);
          DBG('p_chg_row.cod_net_charges-->  ' ||
              P_CHG_ROW.COD_NET_CHARGES);
        
          DBG('Before Call To cspks_arc. to decide for NSF Tracking ');
          IF NOT CSPKSS_ARC.FN_NSF_TRACKER('CG',
                                           P_ENTRY_REC.REFERENCE_NO,
                                           P_ENTRY_REC.PRODUCT_CODE
                                           
                                          ,
                                           P_BRANCH,
                                           G_TXN_ACC,
                                           P_ENTRY_REC.ACC_CCY_AMT,
                                           P_ENTRY_REC.TXN_DATE,
                                           TRUE,
                                           L_ACC_BRN_DR,
                                           L_ACC_NO_DR,
                                           L_COD_CHG_AMT,
                                           L_ACC_CCY_DR,
                                           L_COD_CHG_CCY,
                                           L_COD_RATE_CODE,
                                           L_COD_RATE_CODE_TYPE,
                                           L_COD_CHG_TRACK_PRF,
                                           L_CHG_SEQ,
                                           L_CRDR_IND,
                                           P_CHG_ROW.COD_NET_CHARGES,
                                           P_TRACK_CHG_ENTRY_NSF,
                                           L_COD_CHG_AMT_NSF,
                                           P_ERR_CODE,
                                           L_RET)
          
           THEN
            DBG('Failure in cspkss_arc.fn_nsf_tracker ' || P_ERR_CODE);
          
            RETURN FALSE;
          END IF;
        
          IF L_RET = -1 THEN
            DBG('cspkss_arc.fn_nsf_tracker returned with errors');
            RETURN FALSE;
          END IF;
          DBG('p_track_chg_entry_nsf-->  ' || P_TRACK_CHG_ENTRY_NSF);
          DBG('l_cod_chg_amt_NSF-->  ' || L_COD_CHG_AMT_NSF);
        
          L_COD_CHG_AMT_TEMP := L_COD_CHG_AMT;
          L_COD_CHG_AMT      := L_COD_CHG_AMT_NSF;
          IF L_COD_CHG_AMT_NSF <> 0 THEN
          
            IF L_COD_CHG_CCY <> GLOBAL.LCY THEN
              L_RATE := NULL;
              IF NOT CYPKS.FN_AMT1_TO_AMT2(P_BRANCH,
                                           L_COD_CHG_CCY,
                                           GLOBAL.LCY,
                                           NVL(L_COD_RATE_CODE, 'STANDARD'),
                                           NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                           L_COD_CHG_AMT_TEMP,
                                           'Y',
                                           L_CHG_LCY_TEMP,
                                           L_RATE,
                                           P_ERR_CODE) THEN
                DBG('Failed while findin xch rate ' || P_ERR_CODE);
                RETURN FALSE;
              END IF;
            ELSE
              DBG('Am fine now');
              L_CHG_LCY_TEMP := L_COD_CHG_AMT_TEMP;
              L_RATE         := 1;
            END IF;
          END IF;
          G_CHG_CCY_AMT   := L_COD_CHG_AMT_TEMP;
          G_CHG_LCY       := L_CHG_LCY_TEMP;
          G_EXCH_RATE_LCY := L_RATE;
        
          DBG('l_cod_chg_amt_temp  ' || L_COD_CHG_AMT_TEMP);
          DBG('l_chg_lcy_temp  ' || L_CHG_LCY_TEMP);
          DBG('l_cod_chg_amt  ' || L_COD_CHG_AMT);
        END IF;
      
        IF L_COD_CHG_AMT IS NOT NULL AND L_COD_CHG_AMT <> 0 THEN
        
          J := P_ACC_HAND.COUNT + 1;
        
          P_ACC_HAND(J).MODULE := L_MODULE_CODE;
          P_ACC_HAND(J).MIS_HEAD := L_COD_MIS_HEAD;
          P_ACC_HAND(J).AVLDAYS := 0;
          P_ACC_HAND(J).TRN_REF_NO := P_ENTRY_REC.REFERENCE_NO;
        
          P_ACC_HAND(J).EVENT_SR_NO := L_EVENT_SEQ;
          P_ACC_HAND(J).EVENT := L_EVENT_CODE;
        
          P_ACC_HAND(J).TRN_DT := GLOBAL.APPLICATION_DATE;
          P_ACC_HAND(J).VALUE_DT := P_ENTRY_REC.TXN_DATE;
        
          P_ACC_HAND(J).TXN_INIT_DATE := P_ENTRY_REC.TXN_DATE;
        
          P_ACC_HAND(J).INSTRUMENT_CODE := NULL;
        
          P_ACC_HAND(J).BATCH_NO := P_ENTRY_REC.BATCH_NO;
          P_ACC_HAND(J).CURR_NO := NULL;
          P_ACC_HAND(J).USER_ID := GLOBAL.USER_ID;
          P_ACC_HAND(J).BANK_CODE := P_ENTRY_REC.BANK_CODE;
          P_ACC_HAND(J).DRCR_IND := 'D';
          P_ACC_HAND(J).TRN_CODE := L_COD_CHG_TXN_CODE;
          P_ACC_HAND(J).AMOUNT_TAG := 'CHG_AMT' || I;
          P_ACC_HAND(J).NETTING_IND := L_COD_CHG_NETTING;
          P_ACC_HAND(J).EXTERNAL_REF_NO := P_ENTRY_REC.XREF;
        
          IF (P_PRODUCT_TYPE = 'IC') THEN
            P_ACC_HAND(J).AC_NO := L_ACC_NO_DR;
            P_ACC_HAND(J).RELATED_CUSTOMER := P_ENTRY_REC.REM_CUST;
          ELSIF (P_PRODUCT_TYPE = 'OC') THEN
            P_ACC_HAND(J).AC_NO := L_ACC_NO_DR;
            P_ACC_HAND(J).RELATED_CUSTOMER := P_ENTRY_REC.BEN_CUST;
          END IF;
        
          P_ACC_HAND(J).AC_BRANCH := L_ACC_BRN_DR;
          P_ACC_HAND(J).AC_CCY := L_ACC_CCY_DR;
        
          DEBUG.PR_DEBUG('CG',
                         'Converting charge ccy to charge_payable ccy and global.lcy ');
          IF (L_ACC_CCY_DR = GLOBAL.LCY) THEN
            P_ACC_HAND(J).FCY_AMOUNT := NULL;
            P_ACC_HAND(J).EXCH_RATE := NULL;
            IF (L_ACC_CCY_DR = L_COD_CHG_CCY) THEN
              P_ACC_HAND(J).LCY_AMOUNT := L_COD_CHG_AMT;
            ELSE
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_BRANCH,
                                            L_COD_CHG_CCY,
                                            L_ACC_CCY_DR,
                                            NVL(L_COD_RATE_CODE, 'STANDARD'),
                                            NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                            L_COD_CHG_AMT,
                                            'Y',
                                            L_ACCCCYAMT,
                                            L_RATE,
                                            P_ERR_CODE) THEN
                DEBUG.PR_DEBUG('CG',
                               'Error while computing LCY ' || P_ERR_CODE);
                RETURN FALSE;
              ELSE
                P_ACC_HAND(J).LCY_AMOUNT := L_ACCCCYAMT;
              END IF;
            END IF;
          ELSE
            IF (L_ACC_CCY_DR = L_COD_CHG_CCY) THEN
              P_ACC_HAND(J).FCY_AMOUNT := L_COD_CHG_AMT;
            
              DEBUG.PR_DEBUG('CG',
                             'inside ac equal ch ccy ' || L_COD_CHG_CCY);
              IF L_ACC_CCY_DR <> GLOBAL.LCY THEN
                DEBUG.PR_DEBUG('CG',
                               ' inside different l_acc_ccy_dr and global.lcy ' ||
                               L_ACC_CCY_DR || '~ ' || GLOBAL.LCY);
                IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_BRANCH,
                                              L_ACC_CCY_DR,
                                              GLOBAL.LCY,
                                              NVL(L_COD_RATE_CODE, 'STANDARD'),
                                              NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                              L_COD_CHG_AMT,
                                              'Y',
                                              L_ACCCCYAMT,
                                              L_RATE,
                                              P_ERR_CODE) THEN
                  DEBUG.PR_DEBUG('CG',
                                 ' Error while computing LCY ' ||
                                 P_ERR_CODE);
                  RETURN FALSE;
                ELSE
                  DEBUG.PR_DEBUG('CG', ' inside else of ac conversion');
                  P_ACC_HAND(J).FCY_AMOUNT := L_COD_CHG_AMT;
                  DBG(' l_accccyamt--> ' || L_ACCCCYAMT);
                  DBG(' l_rate after-> ' || L_RATE);
                  P_ACC_HAND(J).LCY_AMOUNT := L_ACCCCYAMT;
                  P_ACC_HAND(J).EXCH_RATE := L_RATE;
                END IF;
              
              ELSE
                DEBUG.PR_DEBUG('CG', ' inside final else' || L_COD_CHG_AMT);
                P_ACC_HAND(J).FCY_AMOUNT := NULL;
                P_ACC_HAND(J).LCY_AMOUNT := L_COD_CHG_AMT;
                P_ACC_HAND(J).EXCH_RATE := NULL;
              END IF;
            
            ELSE
            
              DBG('l_rate-> ' || L_RATE);
              IF L_RATE = 1 THEN
                L_RATE := NULL;
              END IF;
              IF L_COD_CHG_AMT IS NOT NULL THEN
                P_ACC_HAND(J).LCY_AMOUNT := NULL;
              END IF;
              DBG('l_rate after-> ' || L_RATE);
            
              L_RATE := NULL;
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_BRANCH,
                                            L_COD_CHG_CCY,
                                            L_ACC_CCY_DR,
                                            NVL(L_COD_RATE_CODE, 'STANDARD'),
                                            NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                            L_COD_CHG_AMT,
                                            'Y',
                                            L_ACCCCYAMT,
                                            L_RATE,
                                            P_ERR_CODE) THEN
                DEBUG.PR_DEBUG('CG',
                               'Error while computing LCY ' || P_ERR_CODE);
                RETURN FALSE;
              ELSE
                P_ACC_HAND(J).FCY_AMOUNT := L_ACCCCYAMT;
              
                DBG('l_accccyamt--> ' || L_ACCCCYAMT);
                DBG('l_rate after-> ' || L_RATE);
                L_RATE := NULL;
              
                IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_BRANCH,
                                              L_ACC_CCY_DR,
                                              GLOBAL.LCY,
                                              NVL(L_COD_RATE_CODE, 'STANDARD'),
                                              NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                              L_ACCCCYAMT,
                                              'Y',
                                              L_LCY_AMOUNT1,
                                              L_RATE,
                                              P_ERR_CODE) THEN
                  DEBUG.PR_DEBUG('CG',
                                 'Error while computing LCY ' || P_ERR_CODE);
                  RETURN FALSE;
                END IF;
              
                DBG('l_accccyamt--> eur egp ' || L_ACCCCYAMT);
                DBG('l_rate after-> ' || L_RATE);
                P_ACC_HAND(J).LCY_AMOUNT := L_LCY_AMOUNT1;
                P_ACC_HAND(J).EXCH_RATE := L_RATE;
              
              END IF;
            END IF;
            L_ACCCCYAMT := NULL;
          
          END IF;
          DEBUG.PR_DEBUG('CG', 'Cr leg of charges...');
          P_ACC_HAND(J + 1).AC_BRANCH := P_ENTRY_REC.ACC_BRANCH;
        
          P_ACC_HAND(J + 1).MODULE := L_MODULE_CODE;
          P_ACC_HAND(J + 1).MIS_HEAD := L_COD_MIS_HEAD;
          P_ACC_HAND(J + 1).AVLDAYS := 0;
          P_ACC_HAND(J + 1).TRN_REF_NO := P_ENTRY_REC.REFERENCE_NO;
        
          P_ACC_HAND(J + 1).EVENT_SR_NO := L_EVENT_SEQ;
          P_ACC_HAND(J + 1).EVENT := L_EVENT_CODE;
        
          P_ACC_HAND(J + 1).TRN_DT := GLOBAL.APPLICATION_DATE;
          P_ACC_HAND(J + 1).VALUE_DT := P_ENTRY_REC.TXN_DATE;
        
          P_ACC_HAND(J + 1).TXN_INIT_DATE := P_ENTRY_REC.TXN_DATE;
        
          P_ACC_HAND(J + 1).INSTRUMENT_CODE := P_ENTRY_REC.INSTRUMENT_NO_1;
        
          P_ACC_HAND(J + 1).BATCH_NO := P_ENTRY_REC.BATCH_NO;
          P_ACC_HAND(J + 1).CURR_NO := NULL;
          P_ACC_HAND(J + 1).USER_ID := GLOBAL.USER_ID;
          P_ACC_HAND(J + 1).BANK_CODE := P_ENTRY_REC.BANK_CODE;
          P_ACC_HAND(J + 1).DRCR_IND := 'C';
          P_ACC_HAND(J + 1).TRN_CODE := L_COD_CHG_TXN_CODE;
          P_ACC_HAND(J + 1).AMOUNT_TAG := 'CHG_AMT' || I;
          P_ACC_HAND(J + 1).NETTING_IND := L_COD_CHG_NETTING;
          P_ACC_HAND(J + 1).EXTERNAL_REF_NO := P_ENTRY_REC.XREF;
          P_ACC_HAND(J + 1).AC_NO := L_COD_CHG_GL;
        
          IF (P_PRODUCT_TYPE = 'IC') THEN
            P_ACC_HAND(J + 1).RELATED_CUSTOMER := P_ENTRY_REC.REM_CUST;
          ELSIF (P_PRODUCT_TYPE = 'OC') THEN
            P_ACC_HAND(J + 1).RELATED_CUSTOMER := P_ENTRY_REC.BEN_CUST;
          END IF;
        
          IF (L_COD_CHG_CCY = '*.*' OR L_COD_CHG_CCY = P_ACC_HAND(J).AC_CCY) THEN
            L_AC_CCY     := P_ACC_HAND(J).AC_CCY;
            L_FCY_AMOUNT := P_ACC_HAND(J).FCY_AMOUNT;
            L_LCY_AMOUNT := P_ACC_HAND(J).LCY_AMOUNT;
            L_EXCH_RATE  := P_ACC_HAND(J).EXCH_RATE;
          ELSE
            L_AC_CCY := L_COD_CHG_CCY;
            IF L_COD_CHG_CCY = GLOBAL.LCY THEN
              L_FCY_AMOUNT := NULL;
              L_EXCH_RATE  := NULL;
            
              L_LCY_AMOUNT := P_ACC_HAND(J).LCY_AMOUNT;
            
            ELSE
              L_LCY_AMOUNT := P_ACC_HAND(J).LCY_AMOUNT;
              L_FCY_AMOUNT := L_COD_CHG_AMT;
              L_EXCH_RATE  := NULL;
              IF NOT CYPKS.FN_AMT_TO_RATE(L_COD_CHG_CCY,
                                          GLOBAL.LCY,
                                          L_COD_CHG_AMT,
                                          L_LCY_AMOUNT,
                                          L_EXCH_RATE) THEN
                DEBUG.PR_DEBUG('CG', 'failed in fn_amt_to_rate in cypks ');
                P_ERR_CODE := 'CG-SERV05';
                RETURN FALSE;
              END IF;
            END IF;
          END IF;
          DEBUG.PR_DEBUG('CG', 'l_accccyamt :: ' || L_ACCCCYAMT);
          DEBUG.PR_DEBUG('CG', 'l_exch_rate :: ' || L_EXCH_RATE);
        
          P_ACC_HAND(J + 1).AC_CCY := L_AC_CCY;
          P_ACC_HAND(J + 1).FCY_AMOUNT := L_FCY_AMOUNT;
          P_ACC_HAND(J + 1).LCY_AMOUNT := L_LCY_AMOUNT;
          P_ACC_HAND(J + 1).EXCH_RATE := L_EXCH_RATE;
        
          IF P_CHG_ROW.COD_BRANCH = '*.*' THEN
          
            P_ACC_HAND(J + 1).AC_BRANCH := NVL(GLOBAL.CURRENT_BRANCH,
                                               P_ENTRY_REC.ACC_BRANCH);
          ELSE
            P_ACC_HAND(J + 1).AC_BRANCH := P_CHG_ROW.COD_BRANCH;
          END IF;
        
          G_CHG_CCY_AMT   := L_COD_CHG_AMT;
          G_CHG_LCY       := P_ACC_HAND(J + 1).LCY_AMOUNT;
          G_EXCH_RATE_LCY := L_EXCH_RATE;
        
        END IF;
      END IF;
      DEBUG.PR_DEBUG('CG', 'To ret true now -->' || P_ACC_HAND.COUNT);
    
      DEBUG.PR_DEBUG('CG', 'l_ac_ccy : ' || L_AC_CCY);
      DEBUG.PR_DEBUG('CG', 'l_fcy_amount : ' || L_FCY_AMOUNT);
      DEBUG.PR_DEBUG('CG', 'l_lcy_amount : ' || L_LCY_AMOUNT);
    
      DBG('l_cod_chg_amt  : ' || L_COD_CHG_AMT);
      IF GWPKS_UTIL.G_FROM_BEAN THEN
      
        IF L_COD_CHG_AMT IS NOT NULL THEN
          DBG('ts_val for chg : ' || L_COD_CHG_DESC || '~' ||
              L_COD_CHG_TYPE || '~' || 'N' || '~' || L_COD_CHG_AMT
              
              || '~' || L_COD_CHG_CCY || '~');
        
          DBG('gwpks_util.pkg_temp_chg_dets ' ||
              GWPKS_UTIL.PKG_TEMP_CHG_DETS);
          BEGIN
            L_WAIVER := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_TEMP_CHG_DETS,
                                                ((I - 1) * 7) + 1,
                                                '~');
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
          DBG('l_waiver ' || L_WAIVER);
        
        END IF;
      END IF;
    
    END IF;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
    
      DBG('cspks_clg_serv_cluster.FN_POST_FRAME_CHG_ENTRIES ');
      IF NOT
          CSPKS_CLG_SERV_CLUSTER.FN_POST_FRAME_CHG_ENTRIES(P_BRANCH,
                                                           P_ENTRY_REC,
                                                           P_CHG_ROW,
                                                           P_ACC_HAND,
                                                           I,
                                                           P_PRODUCT_TYPE,
                                                           P_ERR_CODE,
                                                           L_FN_CALL_ID,
                                                           L_TB_CLUSTER_DATA)
      
       THEN
        DBG('Failure has happened in cspks_clg_serv_cluster.FN_CHG_PROC');
        RETURN FALSE;
      END IF;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Error in pr_frame_chg_entries ' || SQLERRM);
      RETURN FALSE;
  END FN_FRAME_CHG_ENTRIES;

  PROCEDURE PR_PRINT_CHG_ENTRIES(P_ACC_HAND IN ACPKSS.TBL_ACHOFF) IS
  BEGIN
    DEBUG.PR_DEBUG('CG', 'The entries are : ');
    DEBUG.PR_DEBUG('CG',
                   'Tag --- > Acc ----> Lcy amt ---> Fcy ---> Exch RAte ---> D/C --->');
    DEBUG.PR_DEBUG('CG', 'netting --- > ccy ----> trn code ---> branch ');
    IF P_ACC_HAND.COUNT > 0 THEN
      FOR I IN P_ACC_HAND.FIRST .. P_ACC_HAND.LAST LOOP
        IF P_ACC_HAND.EXISTS(I) THEN
          DEBUG.PR_DEBUG('CG',
                         P_ACC_HAND(I)
                         .AMOUNT_TAG || '--->' || P_ACC_HAND(I).AC_NO ||
                          '--->' || TO_CHAR(P_ACC_HAND(I).LCY_AMOUNT) ||
                          '--->' || TO_CHAR(P_ACC_HAND(I).FCY_AMOUNT) ||
                          '--->' || TO_CHAR(P_ACC_HAND(I).EXCH_RATE) ||
                          '--->' || P_ACC_HAND(I).DRCR_IND);
          DEBUG.PR_DEBUG('CG',
                         P_ACC_HAND(I)
                         .NETTING_IND || '--->' || P_ACC_HAND(I).AC_CCY ||
                          '--->' || P_ACC_HAND(I).TRN_CODE || '--->' || P_ACC_HAND(I)
                         .AC_BRANCH);
        END IF;
      END LOOP;
    ELSE
    
      DBG('Coming out of pr_print_chg_entries without printing anything.....empty HAND');
    END IF;
    RETURN;
  END PR_PRINT_CHG_ENTRIES;

  PROCEDURE PR_REMOVE_ZERO_CHGS(P_ACC_HAND IN OUT ACPKSS.TBL_ACHOFF) IS
    L_TEMP ACPKSS.TBL_ACHOFF := ACPKSS.EMPTY_HOFF;
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Removing zero chgs');
    IF P_ACC_HAND.COUNT > 0 THEN
      FOR I IN P_ACC_HAND.FIRST .. P_ACC_HAND.LAST LOOP
        IF P_ACC_HAND.EXISTS(I) THEN
          IF NVL(P_ACC_HAND(I).LCY_AMOUNT, 0) <> 0 THEN
            L_TEMP(L_TEMP.COUNT + 1) := P_ACC_HAND(I);
          END IF;
        END IF;
      END LOOP;
    ELSE
    
      DBG('No charges to be removed');
    END IF;
    DEBUG.PR_DEBUG('CG', 'Removed zero chgs');
    P_ACC_HAND.DELETE;
    P_ACC_HAND := L_TEMP;
    PR_PRINT_CHG_ENTRIES(P_ACC_HAND);
  END PR_REMOVE_ZERO_CHGS;

  PROCEDURE PR_GEN_ADV_FOR_CONTRACT(P_TRN_REF_NO VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('CG', 'IN pr_gen_adv_for_contract ' || P_TRN_REF_NO);
    FOR EACH_DCN IN (SELECT BRANCH, DCN, CCY, CUST_AC_NO
                       FROM MSTBS_DLY_MSG_OUT
                      WHERE REFERENCE_NO = P_TRN_REF_NO) LOOP
      IF EACH_DCN.CUST_AC_NO IS NOT NULL THEN
        PR_GENERATE_ADVICE(EACH_DCN.DCN);
      END IF;
    END LOOP;
    DEBUG.PR_DEBUG('CG', 'END OF pr_gen_adv_for_contract');
  END PR_GEN_ADV_FOR_CONTRACT;

  PROCEDURE PR_GENERATE_ADVICE(P_MSG_CUR MSPKSS.MODULE_PROC_CURTYPE) IS
    CURSOR CUR_CLG(REFNO VARCHAR2) IS
      SELECT * FROM CSTBS_CLEARING_MASTER WHERE REFERENCE_NO = REFNO;
  
    L_TXN_ACC         CSTBS_CLEARING_MASTER.BEN_ACCOUNT%TYPE;
    L_TXN_TRN_CODE    DETBS_RTL_TELLER.TXN_TRN_CODE%TYPE;
    L_TXN_AMOUNT      CSTBS_CLEARING_MASTER.INSTRUMENT_AMT%TYPE;
    L_TXN_CCY         CSTBS_CLEARING_MASTER.INSTRUMENT_CCY%TYPE;
    L_INSTRUMENT_CODE CSTBS_CLEARING_MASTER.INSTRUMENT_NO_1%TYPE;
  
    L_BRANCH_NAME    STTMS_BRANCH.BRANCH_NAME%TYPE;
    L_TRN_DESC       STTMS_TRN_CODE.TRN_DESC%TYPE;
    L_CUST_NO        STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_CUSTOMER_NAME1 STTMS_CUSTOMER.CUSTOMER_NAME1%TYPE;
    L_TRN_CODE       STTMS_TRN_CODE.TRN_CODE%TYPE;
  
    P_MSG_ROW         MSTBS_DLY_MSG_OUT%ROWTYPE;
    CSTB_CLEARING_ROW CSTBS_CLEARING_MASTER%ROWTYPE;
  
    L_PRODDESC CSTM_PRODUCT.PRODUCT_DESCRIPTION%TYPE;
    L_ACCOUNT  VARCHAR2(20);
    L_CCY      VARCHAR2(3);
    L_AMOUNT   NUMBER;
    L_ACCBAL   NUMBER;
    L_AVL_BAL  BOOLEAN;
    L_DT_FMT   VARCHAR2(20);
  
    L_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM VARCHAR2(250);
  
  BEGIN
    FETCH P_MSG_CUR
      INTO P_MSG_ROW;
    OPEN CUR_CLG(P_MSG_ROW.REFERENCE_NO);
    FETCH CUR_CLG
      INTO CSTB_CLEARING_ROW;
    CLOSE CUR_CLG;
  
    PR_INSERT_ROWS(P_MSG_ROW.DCN,
                   1,
                   'CONTRACTREFNO',
                   CSTB_CLEARING_ROW.REFERENCE_NO);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'USERREFNO', CSTB_CLEARING_ROW.XREF);
    PR_INSERT_ROWS(P_MSG_ROW.DCN,
                   1,
                   'PRODUCT',
                   CSTB_CLEARING_ROW.PRODUCT_CODE);
  
    L_DT_FMT := GLOBAL.GET_NLS_DT_FORMAT;
    PR_INSERT_ROWS(P_MSG_ROW.DCN,
                   1,
                   'TXNDT',
                   TO_CHAR(CSTB_CLEARING_ROW.TXN_DATE, L_DT_FMT));
    PR_INSERT_ROWS(P_MSG_ROW.DCN,
                   1,
                   'TRNTIME',
                   TO_CHAR(CSTB_CLEARING_ROW.MAKER_DT_STAMP, 'HH:MI'));
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'USER-ID', CSTB_CLEARING_ROW.MAKER_ID);
  
    PR_INSERT_ROWS(P_MSG_ROW.DCN,
                   1,
                   'INSTRNO',
                   CSTB_CLEARING_ROW.INSTRUMENT_NO_1);
    BEGIN
      SELECT BRANCH_NAME
        INTO L_BRANCH_NAME
        FROM STTMS_BRANCH
       WHERE BRANCH_CODE = CSTB_CLEARING_ROW.BRANCH_CODE;
    
      BEGIN
      
        SELECT TRN_CODE
          INTO L_TRN_CODE
          FROM ACVW_ALL_AC_ENTRIES
         WHERE TRN_REF_NO = CSTB_CLEARING_ROW.REFERENCE_NO;
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          BEGIN
            SELECT TRN_CODE
              INTO L_TRN_CODE
              FROM ACVW_ALL_UN_AC_ENTRIES
             WHERE TRN_REF_NO = CSTB_CLEARING_ROW.REFERENCE_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DEBUG.PR_DEBUG('CG', 'failed in deriving trn code');
          END;
        WHEN OTHERS THEN
          L_BRANCH_NAME := NULL;
      END;
    
      SELECT TRN_DESC
        INTO L_TRN_DESC
        FROM STTMS_TRN_CODE
       WHERE TRN_CODE = L_TRN_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        L_BRANCH_NAME := NULL;
        L_TRN_DESC    := NULL;
    END;
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'TRNDES', L_TRN_DESC);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'BRANCHNAME', L_BRANCH_NAME);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'TRNCODE', L_TRN_CODE);
  
    DEBUG.PR_DEBUG('CG',
                   LENGTH(CYPKSS.CSFN_FORMAT_AMT(P_MSG_ROW.CCY,
                                                 P_MSG_ROW.AMOUNT)));
  
    DEBUG.PR_DEBUG('CG', 'Opening cursor-----' || P_MSG_ROW.REFERENCE_NO);
  
    DEBUG.PR_DEBUG('CG',
                   'Calling Fn_Get_Product_Rec_Wrp for...' ||
                   CSTB_CLEARING_ROW.PRODUCT_CODE);
    IF CSPKSS_FUNCTION_CACHE.FN_GET_PRODUCT_REC_WRP(CSTB_CLEARING_ROW.PRODUCT_CODE,
                                                    L_ERR_CODE,
                                                    L_ERR_PARAM) THEN
      L_PRODDESC := CSPKSS_FUNCTION_CACHE.G_TBL_CSTM_PROD_REC.PRODUCT_DESCRIPTION;
      DEBUG.PR_DEBUG('CG', 'Product description...' || L_PRODDESC);
    ELSE
      DEBUG.PR_DEBUG('CG',
                     'Error in getting the product details...' ||
                     L_ERR_CODE);
      DEBUG.PR_DEBUG('CG', 'Passign null value to the prod desc..');
      L_PRODDESC  := NULL;
      L_ERR_CODE  := NULL;
      L_ERR_PARAM := NULL;
    END IF;
    DEBUG.PR_DEBUG('CG', 'Product details retrived...');
  
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'PRODDESC', L_PRODDESC);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CUSTOMER', P_MSG_ROW.RECEIVER);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CUSTOMER-NAME', P_MSG_ROW.NAME);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CUSTADDR1', P_MSG_ROW.ADDRESS1);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CUSTADDR2', P_MSG_ROW.ADDRESS2);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CUSTADDR3', P_MSG_ROW.ADDRESS3);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CUSTADDR4', P_MSG_ROW.ADDRESS4);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'BRN-DATE', GLOBAL.APPLICATION_DATE);
  
    IF P_MSG_ROW.CUST_AC_NO IS NULL THEN
      IF P_MSG_ROW.MSG_TYPE = 'CR ADVICE' AND
         CSTB_CLEARING_ROW.DIRECTION = 'O' THEN
        L_ACCOUNT := CSTB_CLEARING_ROW.BEN_ACCOUNT;
      END IF;
    ELSE
      L_ACCOUNT := P_MSG_ROW.CUST_AC_NO;
    END IF;
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'ACCOUNT', L_ACCOUNT);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CCY', P_MSG_ROW.CCY);
    PR_INSERT_ROWS(P_MSG_ROW.DCN,
                   1,
                   'AMOUNT',
                   CYPKSS.CSFN_FORMAT_AMT(P_MSG_ROW.CCY, P_MSG_ROW.AMOUNT));
    L_DT_FMT := GLOBAL.GET_NLS_DT_FORMAT;
    PR_INSERT_ROWS(P_MSG_ROW.DCN,
                   1,
                   'TRNDT',
                   TO_CHAR(CSTB_CLEARING_ROW.TXN_DATE, L_DT_FMT));
    PR_INSERT_ROWS(P_MSG_ROW.DCN,
                   1,
                   'VALDT',
                   TO_CHAR(CSTB_CLEARING_ROW.VAL_DATE_CUST, L_DT_FMT));
  
  END PR_GENERATE_ADVICE;

  PROCEDURE PR_GENERATE_ADVICE(P_DCN VARCHAR2) IS
    CURSOR CUR_MSG IS
      SELECT MESSAGE FROM MSTBS_DLY_MSG_OUT WHERE DCN = P_DCN;
    L_MESSAGE     MSTBS_DLY_MSG_OUT.MESSAGE%TYPE;
    L_DATA        VARCHAR2(32767);
    L_KEY         VARCHAR2(60);
    P_DLY_MSG_CUR MSTBS_MSG_HANDOFF%ROWTYPE;
    P_BAD_DCN     VARCHAR2(1000);
  BEGIN
    DEBUG.PR_DEBUG('CG',
                   'Inside pr_generate_advice. before opening cursor');
    SELECT * INTO P_DLY_MSG_CUR FROM MSTBS_DLY_MSG_OUT WHERE DCN = P_DCN;
    IF P_DLY_MSG_CUR.MSG_TYPE IN ('DR ADVICE', 'CR ADVICE') THEN
      DEBUG.PR_DEBUG('CG',
                     'Inside pr_generate_advice. before calling overloaded pr_generate_advice');
      IF NOT MSPKSS.FN_GEN_MSG_OUT(P_DLY_MSG_CUR, P_BAD_DCN) THEN
        DEBUG.PR_DEBUG('CG', 'Failed in mspks');
      END IF;
      DEBUG.PR_DEBUG('CG',
                     'Inside pr_generate_advice. after return from overloaded pr_generate_advice');
      OPEN CUR_MSG;
      FETCH CUR_MSG
        INTO L_MESSAGE;
      CLOSE CUR_MSG;
    
      DEBUG.PR_DEBUG('CG',
                     'Inside pr_generate_advice. After last line of procedure');
    END IF;
  END PR_GENERATE_ADVICE;

  PROCEDURE PR_INSERT_ROWS(P_DCN       VARCHAR2,
                           P_LOOP_NO   NUMBER,
                           P_FIELD_TAG VARCHAR2,
                           P_VALUE     VARCHAR2) IS
  BEGIN
    INSERT INTO MSTB_ADV_INPUT
      (DCN, LOOP_NO, FIELD_TAG, VALUE, JUSTIFY)
    VALUES
      (P_DCN, P_LOOP_NO, P_FIELD_TAG, P_VALUE, 'L');
  END PR_INSERT_ROWS;

  FUNCTION FN_IS_GL(P_BRN IN VARCHAR2,
                    P_ACC IN VARCHAR2,
                    P_CCY OUT VARCHAR2) RETURN BOOLEAN IS
    L_GL             STTBS_ACCOUNT.AC_OR_GL%TYPE;
    PKG_STTB_ACCOUNT STTBS_ACCOUNT%ROWTYPE;
  BEGIN
    IF NOT CVPKS_UTILS.GET_STTB_ACC(P_BRN, P_ACC, PKG_STTB_ACCOUNT) THEN
      RETURN FALSE;
    END IF;
    IF PKG_STTB_ACCOUNT.AC_OR_GL = 'G' THEN
      RETURN TRUE;
    ELSE
      P_CCY := PKG_STTB_ACCOUNT.AC_GL_CCY;
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'FROM fn IS gl ' || SQLERRM);
      DEBUG.PR_DEBUG('CG', 'Err FOR ' || P_BRN || ' ' || P_ACC);
      P_CCY := NULL;
      RETURN FALSE;
  END FN_IS_GL;

  FUNCTION FN_CONSOL_CLG_ENTRY(P_FILEID      IN VARCHAR2,
                               P_PROCESSDATE IN DATE,
                               P_ERRCODE     IN OUT VARCHAR2,
                               P_ERRPARAM    IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_TXN_AC_NO DETBS_RTL_TELLER.TXN_ACC%TYPE;
    L_TXN_BRN   DETBS_RTL_TELLER.TXN_BRANCH%TYPE;
    CURSOR CR_CONSOL_CLG_ENTRY(P_FILEID VARCHAR2) IS
      SELECT SUM(INSTRAMT) CONSOLAMT,
             REMACCOUNT,
             PROD,
             REMBRANCH,
             INSTRCCY,
             ENDPOINT,
             LATECLG
        FROM IFTBS_CLEARING_UPLOAD A
       WHERE A.
       TXN_BRN = GLOBAL.CURRENT_BRANCH
            
         AND A.FILE_ID = P_FILEID
         AND A.RECORD_STAT = 'O'
         AND A.AUTH_STAT = 'A'
         AND A.PROD = (SELECT PRODUCT_CODE
                         FROM CGTMS_PRODUCT_REFERRAL
                        WHERE PRODUCT_CODE = A.PROD
                          AND NVL(CONSOLIDATION_REQD, 'N') = 'Y')
         AND REMACCOUNT =
             (SELECT CUST_AC_NO
                FROM STTMS_CUST_ACCOUNT
               WHERE BRANCH_CODE = A.REMBRANCH
                 AND CUST_AC_NO = A.REMACCOUNT
                 AND NVL(CONSOLIDATION_REQD, 'N') = 'Y')
       GROUP BY REMACCOUNT, PROD, INSTRCCY, ENDPOINT, REMBRANCH;
  
    CURSOR CR_CONSOL_RVRSL_ENTRY(P_PROD       VARCHAR2,
                                 P_REMACCOUNT VARCHAR2,
                                 P_REMBRANCH  VARCHAR2,
                                 P_INSTRCCY   VARCHAR2,
                                 P_ENDPOINT   VARCHAR2,
                                 P_FILEID     VARCHAR2) IS
      SELECT *
        FROM IFTBS_CLEARING_UPLOAD
       WHERE FILE_ID = P_FILEID
         AND PROD = P_PROD
         AND REMACCOUNT = P_REMACCOUNT
         AND REMBRANCH = P_REMBRANCH
         AND INSTRCCY = P_INSTRCCY
         AND ENDPOINT = P_ENDPOINT;
  
    LOC_MICR_SUSP_GL  CATMS_BRANCH_PARAM.MICR_SUSPENSE_GL%TYPE;
    LOC_MICR_TRN_CODE CATMS_BRANCH_PARAM.MICR_TRN_CODE%TYPE;
    LOC_OFS_MIS_HEAD  STTMS_TRN_CODE.MIS_HEAD%TYPE;
    LOC_MAIN_MIS_HEAD STTMS_TRN_CODE.MIS_HEAD%TYPE;
    LOC_EMPTY_HAND    ACPKSS.TBL_ACHOFF;
    LOC_ACC_HAND      ACPKSS.TBL_ACHOFF;
    LOC_SERIAL        VARCHAR2(100);
    LOC_TRN_REF_NO    ACTBS_DAILY_LOG.TRN_REF_NO%TYPE;
    Z                 NUMBER := 1;
    LOC_ACC_CCY_AMT   NUMBER;
    L_RATE1           NUMBER;
    L_RATE2           NUMBER;
    L_CR_LCYAMT       NUMBER;
    L_CR_FCYAMT       NUMBER;
    L_CR_EXCHRATE     NUMBER;
    L_DR_LCYAMT       NUMBER;
    L_DR_FCYAMT       NUMBER;
    L_DR_EXCHRATE     NUMBER;
    L_LCY_AMT_AVG     NUMBER;
    LOC_ARC_ROW       IFTMS_ARC_MAINT%ROWTYPE;
    LOC_ACC_CCY       STTMS_CUST_ACCOUNT.CCY%TYPE;
    LOC_OFS_ACC_CCY   STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_ERRCODE         VARCHAR2(1000);
    L_ERRPARAM        VARCHAR2(1000);
    L_VAL_DATE_CUST   DATE;
    L_VAL_DATE_BNK    DATE;
    L_CUSTOMER        STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_CLEARING_BRN    STTMS_BRANCH.CLEARING_BRN%TYPE;
    L_AC_BRANCH       STTMS_BRANCH.CLEARING_BRN%TYPE;
    L_CONSOL_TXN_CODE CGTMS_PRODUCT_REFERRAL.CONSOL_TXN_CODE%TYPE;
    LBAL              NUMBER(22, 3) := 0;
  
    L_FUNDING            STTMS_CUST_ACCOUNT.FUNDING%TYPE;
    L_POSPARKING_ACCOUNT STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT%TYPE;
    L_POSPARKING_BRANCH  STTMS_CUST_ACCOUNT.FUNDING_BRANCH%TYPE;
    L_CURRENCY           STTMS_CUST_ACCOUNT.CCY%TYPE;
  
  BEGIN
    DBG('Start of Cspks_Clg_Serv.fn_consol_clg_entry');
    DBG('The File Id is :' || P_FILEID);
  
    Z := 1;
  
    SAVEPOINT START_OF_CONSOL_ENTRY;
  
    FOR EACH_REC IN CR_CONSOL_CLG_ENTRY(P_FILEID) LOOP
    
      DBG('Consolamt' || EACH_REC.CONSOLAMT);
      DBG('Remaccount' || EACH_REC.REMACCOUNT);
      DBG('prod' || EACH_REC.PROD);
      DBG('Instrccy' || EACH_REC.INSTRCCY);
      DBG('rembranch' || EACH_REC.REMBRANCH);
      DBG('end point' || EACH_REC.ENDPOINT);
    
      DBG('Setting Account Number and Branch Code for ARC Pick up');
      IF EACH_REC.REMACCOUNT IS NOT NULL THEN
        DBG('Account Number NOT NULL ' || EACH_REC.REMACCOUNT);
        L_TXN_AC_NO := EACH_REC.REMACCOUNT;
      ELSE
        L_TXN_AC_NO := NULL;
      END IF;
      IF EACH_REC.REMBRANCH IS NOT NULL THEN
        DBG('Branch is NOT NULL ' || EACH_REC.REMBRANCH);
        L_TXN_BRN := EACH_REC.REMBRANCH;
      END IF;
      DBG('Account Number ' || L_TXN_AC_NO);
      DBG('Branch ' || L_TXN_BRN);
    
      IF NOT CAPKS_POSPAY_SERV.FN_CHECK_FUNDING(EACH_REC.REMBRANCH,
                                                EACH_REC.REMACCOUNT,
                                                L_FUNDING,
                                                L_POSPARKING_ACCOUNT,
                                                L_POSPARKING_BRANCH,
                                                L_CURRENCY,
                                                L_ERRCODE,
                                                L_ERRPARAM) THEN
      
        DBG('function fn_check_funding returns false in Cspks_Clg_Serv.fn_consol_clg_entry');
        RETURN FALSE;
      
      END IF;
    
      DBG('Funding account -->' || L_FUNDING);
      DBG('Posparking account -->' || L_POSPARKING_ACCOUNT);
      DBG('Posparking branch  -->' || L_POSPARKING_BRANCH);
      DBG('Currency           -->' || L_CURRENCY);
      DBG('Remitter account ---->' || EACH_REC.REMACCOUNT);
      DBG('Remitter branch  ---->' || EACH_REC.REMBRANCH);
    
      L_CONSOL_TXN_CODE := NULL;
    
      SELECT CONSOL_TXN_CODE
        INTO L_CONSOL_TXN_CODE
        FROM CGTMS_PRODUCT_REFERRAL
       WHERE PRODUCT_CODE = EACH_REC.PROD;
    
      IF NOT TRPKSS.FN_GET_PROCESS_REFNO(GLOBAL.CURRENT_BRANCH,
                                         'ZCCE',
                                         GLOBAL.APPLICATION_DATE,
                                         LOC_SERIAL,
                                         LOC_TRN_REF_NO,
                                         P_ERRCODE) THEN
        DEBUG.PR_DEBUG('CG', 'Could not generate process reference no');
        ROLLBACK TO START_OF_CONSOL_ENTRY;
        RETURN FALSE;
      END IF;
    
      DBG('Ref No generated is -->' || LOC_TRN_REF_NO);
    
      LOC_ACC_HAND := LOC_EMPTY_HAND;
    
      DBG('Picking arc details for ' || GLOBAL.CURRENT_BRANCH || '~' ||
          EACH_REC.INSTRCCY || '~' || EACH_REC.ENDPOINT || '~' ||
          GLOBAL.LCY);
      CSPKSS_ARC.PR_GET_ARC_ROW(GLOBAL.CURRENT_BRANCH,
                                EACH_REC.PROD,
                                'P',
                                EACH_REC.ENDPOINT,
                                EACH_REC.INSTRCCY,
                                LOC_ARC_ROW,
                                P_ERRCODE,
                                P_ERRPARAM,
                                L_TXN_AC_NO,
                                L_TXN_BRN);
    
      BEGIN
        SELECT MIS_HEAD
          INTO LOC_OFS_MIS_HEAD
          FROM STTMS_TRN_CODE
         WHERE TRN_CODE = LOC_ARC_ROW.COD_OFFSET_TXN_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LOC_OFS_MIS_HEAD := NULL;
      END;
    
      BEGIN
        SELECT MIS_HEAD
          INTO LOC_MAIN_MIS_HEAD
          FROM STTMS_TRN_CODE
         WHERE TRN_CODE = LOC_ARC_ROW.COD_MAIN_TXN_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LOC_MAIN_MIS_HEAD := NULL;
      END;
    
      IF LOC_ARC_ROW.COD_OFFSET_BRN IS NULL OR
         LOC_ARC_ROW.COD_OFFSET_ACC IS NULL THEN
        DBG('Arc details are null');
        ROLLBACK TO START_OF_CONSOL_ENTRY;
        P_ERRCODE  := 'CG-MICR001';
        P_ERRPARAM := NULL;
        RETURN FALSE;
      END IF;
    
      DBG('selecting ccy value for the account.....' ||
          NVL(EACH_REC.REMACCOUNT, LOC_ARC_ROW.COD_TXN_ACCOUNT));
    
      BEGIN
        SELECT CCY
          INTO LOC_ACC_CCY
          FROM STTMS_CUST_ACCOUNT
         WHERE BRANCH_CODE = EACH_REC.REMBRANCH
           AND CUST_AC_NO =
               NVL(EACH_REC.REMACCOUNT, LOC_ARC_ROW.COD_TXN_ACCOUNT);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    
      DBG('loc_acc_ccy' || LOC_ACC_CCY);
      DBG('Calling the conversion wrapper...');
    
      IF NOT FN_FCY_LCY_CONV(EACH_REC.INSTRCCY,
                             EACH_REC.CONSOLAMT,
                             EACH_REC.REMBRANCH,
                             NVL(EACH_REC.REMACCOUNT,
                                 LOC_ARC_ROW.COD_TXN_ACCOUNT),
                             LOC_ACC_CCY,
                             LOC_ACC_CCY_AMT,
                             L_DR_LCYAMT,
                             L_DR_FCYAMT,
                             L_DR_EXCHRATE,
                             L_ERRCODE,
                             L_ERRPARAM) THEN
        DBG('Function fcy_lcy conversion bombed...');
        DBG('Big Trouble brewing...');
        P_ERRCODE  := L_ERRCODE;
        P_ERRPARAM := L_ERRPARAM;
        RETURN FALSE;
      END IF;
    
      DBG('l_lcyamt' || L_DR_LCYAMT);
      DBG('l_fcyamt' || L_DR_FCYAMT);
      DBG('l_exchrate' || L_DR_EXCHRATE);
    
      DBG('Now calling get_value_dates fn...');
    
      IF NOT CSPKSS_CLG_SERVICES.FN_GET_VALUE_DATES(NULL,
                                                    NULL,
                                                    NULL,
                                                    GLOBAL.CURRENT_BRANCH,
                                                    EACH_REC.PROD,
                                                    EACH_REC.INSTRCCY,
                                                    NULL,
                                                    EACH_REC.ENDPOINT,
                                                    L_VAL_DATE_BNK,
                                                    L_VAL_DATE_CUST,
                                                    EACH_REC.LATECLG
                                                    
                                                   ,
                                                    L_ERRCODE) THEN
        DBG('Error while calculating value dates');
        P_ERRCODE  := L_ERRCODE;
        P_ERRPARAM := NULL;
        RETURN FALSE;
      END IF;
    
      BEGIN
        SELECT A.CLEARING_BRN
          INTO L_CLEARING_BRN
          FROM STTMS_BRANCH A
        
         WHERE A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_CLEARING_BRN := NULL;
      END;
    
      DBG('Consolamt' || EACH_REC.CONSOLAMT);
    
      IF NVL(EACH_REC.CONSOLAMT, 0) <> 0 THEN
        DBG('Building the credit entries ....entry no :' || Z);
      
        LOC_ACC_HAND(Z).MODULE := 'CG';
        LOC_ACC_HAND(Z).MIS_HEAD := LOC_OFS_MIS_HEAD;
        LOC_ACC_HAND(Z).AVLDAYS := 0;
        LOC_ACC_HAND(Z).EVENT_SR_NO := 1;
        LOC_ACC_HAND(Z).EVENT := 'INIT';
        LOC_ACC_HAND(Z).TRN_DT := GLOBAL.APPLICATION_DATE;
        LOC_ACC_HAND(Z).VALUE_DT := L_VAL_DATE_BNK;
        LOC_ACC_HAND(Z).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        LOC_ACC_HAND(Z).INSTRUMENT_CODE := NULL;
        LOC_ACC_HAND(Z).RELATED_CUSTOMER := NULL;
        LOC_ACC_HAND(Z).BATCH_NO := NULL;
        LOC_ACC_HAND(Z).CURR_NO := NULL;
        LOC_ACC_HAND(Z).USER_ID := GLOBAL.USER_ID;
        LOC_ACC_HAND(Z).BANK_CODE := NULL;
        LOC_ACC_HAND(Z).DRCR_IND := 'C';
        LOC_ACC_HAND(Z).TRN_CODE := LOC_ARC_ROW.COD_OFFSET_TXN_CODE;
        LOC_ACC_HAND(Z).AMOUNT_TAG := 'OFS_AMOUNT';
        LOC_ACC_HAND(Z).NETTING_IND := 'N';
        LOC_ACC_HAND(Z).EXTERNAL_REF_NO := NULL;
        LOC_ACC_HAND(Z).AC_NO := LOC_ARC_ROW.COD_OFFSET_ACC;
        LOC_ACC_HAND(Z).AC_CCY := EACH_REC.INSTRCCY;
      
        IF LOC_ARC_ROW.COD_OFFSET_BRN = '*.*' THEN
          LOC_ACC_HAND(Z).AC_BRANCH := L_CLEARING_BRN;
          L_AC_BRANCH := L_CLEARING_BRN;
        ELSE
          LOC_ACC_HAND(Z).AC_BRANCH := LOC_ARC_ROW.COD_OFFSET_BRN;
          L_AC_BRANCH := LOC_ARC_ROW.COD_OFFSET_BRN;
        END IF;
      
        IF EACH_REC.INSTRCCY = GLOBAL.LCY THEN
          L_CR_LCYAMT   := EACH_REC.CONSOLAMT;
          L_CR_FCYAMT   := NULL;
          L_CR_EXCHRATE := NULL;
        ELSE
          L_CR_FCYAMT := EACH_REC.CONSOLAMT;
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(L_AC_BRANCH,
                                        EACH_REC.INSTRCCY,
                                        GLOBAL.LCY
                                        
                                       ,
                                        NVL(G_RATE_TYPE_PREFERRED, 'STANDARD')
                                        
                                       ,
                                        NVL(G_RATE_CODE_PREFERRED, 'M')
                                        
                                       ,
                                        EACH_REC.CONSOLAMT,
                                        'Y',
                                        L_CR_LCYAMT,
                                        L_CR_EXCHRATE,
                                        L_ERRCODE) THEN
            DBG('Error while computing LCY');
            P_ERRCODE := L_ERRCODE;
            RETURN FALSE;
          END IF;
        END IF;
      
        LOC_ACC_HAND(Z).LCY_AMOUNT := L_CR_LCYAMT;
        LOC_ACC_HAND(Z).FCY_AMOUNT := L_CR_FCYAMT;
        LOC_ACC_HAND(Z).EXCH_RATE := L_CR_EXCHRATE;
        LOC_ACC_HAND(Z).TRN_REF_NO := LOC_TRN_REF_NO;
        LOC_ACC_HAND(Z).TRN_CODE := L_CONSOL_TXN_CODE;
        DBG('Cr leg built for ac~amount~cr...' || LOC_ACC_HAND(Z).AC_NO || '~' || LOC_ACC_HAND(Z)
            .LCY_AMOUNT || '~C');
        Z := Z + 1;
      
        DBG('Building the Dr entries....entry no ' || Z);
      
        LOC_ACC_HAND(Z).MODULE := 'CG';
        LOC_ACC_HAND(Z).MIS_HEAD := LOC_MAIN_MIS_HEAD;
        LOC_ACC_HAND(Z).AVLDAYS := 0;
        LOC_ACC_HAND(Z).EVENT_SR_NO := 1;
        LOC_ACC_HAND(Z).EVENT := 'INIT';
        LOC_ACC_HAND(Z).TRN_DT := GLOBAL.APPLICATION_DATE;
        LOC_ACC_HAND(Z).VALUE_DT := L_VAL_DATE_CUST;
        LOC_ACC_HAND(Z).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        LOC_ACC_HAND(Z).INSTRUMENT_CODE := NULL;
        LOC_ACC_HAND(Z).RELATED_CUSTOMER := NULL;
        LOC_ACC_HAND(Z).BATCH_NO := NULL;
        LOC_ACC_HAND(Z).CURR_NO := NULL;
        LOC_ACC_HAND(Z).USER_ID := GLOBAL.USER_ID;
        LOC_ACC_HAND(Z).BANK_CODE := NULL;
        LOC_ACC_HAND(Z).DRCR_IND := 'D';
        LOC_ACC_HAND(Z).TRN_CODE := LOC_ARC_ROW.COD_MAIN_TXN_CODE;
        LOC_ACC_HAND(Z).AMOUNT_TAG := 'TXN_AMOUNT';
        LOC_ACC_HAND(Z).NETTING_IND := 'N';
        LOC_ACC_HAND(Z).EXTERNAL_REF_NO := NULL;
      
        IF EACH_REC.REMACCOUNT IS NOT NULL THEN
          IF L_FUNDING = 'Y' THEN
            LOC_ACC_HAND(Z).AC_NO := L_POSPARKING_ACCOUNT;
          ELSE
            LOC_ACC_HAND(Z).AC_NO := EACH_REC.REMACCOUNT;
          END IF;
        ELSE
          LOC_ACC_HAND(Z).AC_NO := LOC_ARC_ROW.COD_TXN_ACCOUNT;
        END IF;
      
        IF L_FUNDING = 'Y' THEN
          LOC_ACC_HAND(Z).AC_BRANCH := EACH_REC.REMBRANCH;
        ELSE
          LOC_ACC_HAND(Z).AC_BRANCH := EACH_REC.REMBRANCH;
        END IF;
      
        DBG('proceeding to handoff');
      
        LOC_ACC_HAND(Z).AC_CCY := LOC_ACC_CCY;
        LOC_ACC_HAND(Z).LCY_AMOUNT := L_DR_LCYAMT;
        LOC_ACC_HAND(Z).FCY_AMOUNT := L_DR_FCYAMT;
        LOC_ACC_HAND(Z).EXCH_RATE := L_DR_EXCHRATE;
        LOC_ACC_HAND(Z).TRN_REF_NO := LOC_TRN_REF_NO;
        LOC_ACC_HAND(Z).TRN_CODE := L_CONSOL_TXN_CODE;
      
        IF (EACH_REC.INSTRCCY <> LOC_ACC_CCY) AND
           (EACH_REC.INSTRCCY <> GLOBAL.LCY AND LOC_ACC_CCY <> GLOBAL.LCY) THEN
          L_LCY_AMT_AVG := (LOC_ACC_HAND(Z)
                           .LCY_AMOUNT + LOC_ACC_HAND(Z - 1).LCY_AMOUNT) / 2;
          LOC_ACC_HAND(Z - 1).LCY_AMOUNT := L_LCY_AMT_AVG;
          LOC_ACC_HAND(Z).LCY_AMOUNT := L_LCY_AMT_AVG;
          IF NOT CYPKSS.FN_AMT_TO_RATE(LOC_ACC_CCY,
                                       GLOBAL.LCY,
                                       LOC_ACC_CCY_AMT,
                                       L_LCY_AMT_AVG,
                                       L_RATE1) THEN
            DEBUG.PR_DEBUG('CG',
                           'Failed to get the exch rate for lcy avg...');
            RETURN FALSE;
          END IF;
          IF NOT CYPKSS.FN_AMT_TO_RATE(EACH_REC.INSTRCCY,
                                       GLOBAL.LCY,
                                       EACH_REC.CONSOLAMT,
                                       L_LCY_AMT_AVG,
                                       L_RATE2) THEN
            DEBUG.PR_DEBUG('CG',
                           'Failed to get the exch rate for lcy avg....');
            RETURN FALSE;
          END IF;
          LOC_ACC_HAND(Z).EXCH_RATE := L_RATE1;
          LOC_ACC_HAND(Z - 1).EXCH_RATE := L_RATE2;
        END IF;
      
        Z := Z + 1;
      END IF;
    
      IF LOC_ACC_HAND.COUNT > 0 THEN
        DBG('B4 calling accounting in fn_consol_clg_entry');
        IF NOT ACPKSS.FN_ACHANDOFF(LOC_TRN_REF_NO,
                                   1,
                                   GLOBAL.APPLICATION_DATE,
                                   LOC_ACC_HAND,
                                   'B',
                                   'N',
                                   'Y',
                                   GLOBAL.USER_ID,
                                   P_ERRCODE,
                                   P_ERRPARAM) THEN
          DBG('Failed in Call to achandoff for  consol clg entries...');
          ROLLBACK TO START_OF_CONSOL_ENTRY;
          RETURN FALSE;
        END IF;
      END IF;
    
      LBAL := 0;
    
      DBG('calling acpkss_misc.fn_GetAvlBal with branch -->' || LOC_ACC_HAND(1)
          .AC_BRANCH || 'account no -->' || LOC_ACC_HAND(1).AC_NO);
      IF NOT ACPKSS_MISC.FN_GETAVLBAL(
                                      
                                      CASE WHEN L_FUNDING = 'Y' THEN
                                      L_POSPARKING_BRANCH ELSE
                                      EACH_REC.REMBRANCH END,
                                      CASE WHEN L_FUNDING = 'Y' THEN
                                      L_POSPARKING_ACCOUNT ELSE
                                      EACH_REC.REMACCOUNT END,
                                      LBAL,
                                      'Y') THEN
      
        DEBUG.PR_DEBUG('CG',
                       'Function acpkss_misc.fn_GetAvlBal returns false');
        RETURN FALSE;
      END IF;
    
      DBG('setting consol referral reqd ');
      IF LBAL < 0 THEN
      
        G_CONSOL_REFERRAL_REQD := 'Y';
        DBG('setting consol referral reqd as -->' ||
            G_CONSOL_REFERRAL_REQD);
      END IF;
    
      FOR EACH_RVRSL_REC IN CR_CONSOL_RVRSL_ENTRY(EACH_REC.PROD,
                                                  EACH_REC.REMACCOUNT,
                                                  EACH_REC.REMBRANCH,
                                                  EACH_REC.INSTRCCY,
                                                  EACH_REC.ENDPOINT,
                                                  P_FILEID) LOOP
        DBG('Calling fn_save_entry in cr_consol_rvrsl_entry for the following values');
        DBG('Inside the cursor cr_consol_rvrsl_entry -->prod' ||
            EACH_REC.PROD);
        DBG('Inside the cursor cr_consol_rvrsl_entry -->remaccount' ||
            EACH_REC.REMACCOUNT);
        DBG('Inside the cursor cr_consol_rvrsl_entry -->instrccy' ||
            EACH_REC.INSTRCCY);
        DBG('Inside the cursor cr_consol_rvrsl_entry -->rembranch' ||
            EACH_REC.REMBRANCH);
        DBG('Inside the cursor cr_consol_rvrsl_entry -->endpoint' ||
            EACH_REC.ENDPOINT);
        DBG('Status of instrument ' || EACH_RVRSL_REC.INSTRNO ||
            ' with xref ' || EACH_RVRSL_REC.XREF || ' is ' ||
            EACH_RVRSL_REC.STATUS);
        DBG('Consolidated transaction ref no passed is ' || LOC_TRN_REF_NO);
      
        DBG('Now calling fn_save_entry from reversal cursor');
      
        IF NOT FN_SAVE_ENTRY(EACH_RVRSL_REC.XREF,
                             L_ERRCODE,
                             L_ERRPARAM,
                             -1,
                             
                             'Y',
                             'U',
                             LOC_TRN_REF_NO) THEN
          DBG('Failed in fn_save_entry while trying to reverse consol entries');
          ROLLBACK TO START_OF_CONSOL_ENTRY;
          RETURN FALSE;
        ELSE
          DBG('fn_save_entry returned true from cr_consol_rvrsl_entry');
        END IF;
      END LOOP;
    
    END LOOP;
  
    DBG('Returning true from fn_consol_clg_entry....');
    COMMIT;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Function fn_consol_clg_entry returned false');
      ROLLBACK TO START_OF_CONSOL_ENTRY;
      P_ERRCODE  := 'CG-CL0001';
      P_ERRPARAM := '';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_CONSOL_CLG_ENTRY;

  FUNCTION FN_FCY_LCY_CONV(P_INSTRCCY    IN VARCHAR2,
                           P_CONSOLAMT   IN NUMBER,
                           P_ACCBRN      IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                           P_ACCNO       IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                           P_ACC_CCY     IN VARCHAR2,
                           P_ACC_CCY_AMT OUT NUMBER,
                           P_LCYAMT      OUT NUMBER,
                           P_FCYAMT      OUT NUMBER,
                           P_EXCHRATE    IN OUT NUMBER,
                           P_ERRCODE     IN OUT VARCHAR2,
                           P_ERRPARAM    IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_ACC_CCYAMT NUMBER(22, 3);
    L_EXCHRATE   NUMBER;
    L_EXCHRATE1  NUMBER;
    L_LCYAMT     NUMBER(22, 3);
    L_FCYAMT     NUMBER(22, 3);
    L_ERRCODE    VARCHAR2(1000);
    L_ERRPARAM   VARCHAR2(1000);
  BEGIN
    DBG('Inside fn_fcy_lcy_conv....');
    DBG('The parameters are...');
    DBG('Instrument Ccy -->' || P_INSTRCCY);
    DBG('Consolidated Amt -->' || P_CONSOLAMT);
    DBG('Acc Branch -->' || P_ACCBRN);
    DBG('Acc Number -->' || P_ACCNO);
    DBG('Acc Ccy  -->' || P_ACC_CCY);
    DBG('p_Exchrate -->' || P_EXCHRATE);
  
    IF P_ACC_CCY = P_INSTRCCY THEN
      DBG('Acc Ccy same as Inst ccy....half the headache is over');
      L_ACC_CCYAMT := P_CONSOLAMT;
    ELSE
      DBG('Start Praying....the *@^x9$ currencies are different');
      IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_ACCBRN,
                                    P_INSTRCCY,
                                    P_ACC_CCY
                                    
                                   ,
                                    NVL(G_RATE_TYPE_PREFERRED, 'STANDARD')
                                    
                                   ,
                                    NVL(G_RATE_CODE_PREFERRED, 'M')
                                    
                                   ,
                                    P_CONSOLAMT,
                                    'Y',
                                    L_ACC_CCYAMT,
                                    L_EXCHRATE,
                                    L_ERRCODE) THEN
        DBG('Error while converting Instr Ccy to Acc Ccy...');
        P_ERRCODE := L_ERRCODE;
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_ACC_CCY = GLOBAL.LCY THEN
      DBG('Acc ccy same as lcy');
      L_LCYAMT   := L_ACC_CCYAMT;
      L_FCYAMT   := NULL;
      P_EXCHRATE := NULL;
    ELSE
      DBG('The damned acc ccy is not the same as lcy');
      L_FCYAMT := L_ACC_CCYAMT;
    
      IF P_INSTRCCY = GLOBAL.LCY THEN
        L_LCYAMT   := P_CONSOLAMT;
        P_EXCHRATE := L_EXCHRATE;
      ELSE
        IF P_EXCHRATE IS NOT NULL THEN
        
          L_EXCHRATE1 := P_EXCHRATE;
        END IF;
      
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_ACCBRN,
                                      P_ACC_CCY,
                                      GLOBAL.LCY
                                      
                                     ,
                                      NVL(G_RATE_TYPE_PREFERRED, 'STANDARD')
                                      
                                     ,
                                      NVL(G_RATE_CODE_PREFERRED, 'M')
                                      
                                     ,
                                      L_ACC_CCYAMT,
                                      'Y',
                                      L_LCYAMT,
                                      L_EXCHRATE1,
                                      L_ERRCODE) THEN
          DBG('Error in converting Instr Ccy amt to Local ccy amt');
          P_ERRCODE := L_ERRCODE;
          RETURN FALSE;
        END IF;
        P_EXCHRATE := L_EXCHRATE1;
      END IF;
    END IF;
  
    DBG('In fn_fcy_lcy_conv, lcy returned as ' || L_LCYAMT);
    DBG('In fn_fcy_lcy_conv, fcy returned as ' || L_FCYAMT);
    DBG('In fn_fcy_lcy_conv, exch rate returned as ' || P_EXCHRATE);
    DBG('In fn_fcy_lcy_conv, l_acc_ccy amt is ' || L_ACC_CCYAMT);
  
    P_LCYAMT      := L_LCYAMT;
    P_FCYAMT      := L_FCYAMT;
    P_ACC_CCY_AMT := L_ACC_CCYAMT;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception in fn_fcy_lcy_conv.....');
      P_ERRCODE  := 'CG-CL0001';
      P_ERRPARAM := '';
      OVPKS.PR_APPENDTBL('CG-CL0001', 'Exception in fn_save_entry');
      RETURN FALSE;
  END FN_FCY_LCY_CONV;

  FUNCTION FN_CONSOLIDATION_REVERSAL(P_TRN_REF_NO  IN VARCHAR2,
                                     P_ENTRY_REC   IN CSTBS_CLEARING_MASTER%ROWTYPE,
                                     P_CASA_ERROR  IN VARCHAR2,
                                     P_ERRCODE     OUT VARCHAR2,
                                     P_ERRPARAM    OUT VARCHAR2,
                                     P_ACC_TAB     OUT ACPKSS.TBL_ACHOFF,
                                     P_ONLINE_AUTH IN VARCHAR2)
    RETURN BOOLEAN IS
  
    L_COUNT                       INTEGER;
    L_ACC_TAB                     ACPKSS.TBL_ACHOFF;
    L_DATE_TIME                   DATE;
    L_AMT                         NUMBER;
    L_LCYAMT                      NUMBER;
    L_FCYAMT                      NUMBER;
    L_EXCHRATE                    NUMBER;
    L_CASA_ERR_TRN_CODE           VARCHAR2(3);
    L_INSUFFICIENT_FUNDS_REVERSAL VARCHAR2(3);
    L_ACC_CCY_AMT                 NUMBER;
    L_AC_OR_GL                    STTBS_ACCOUNT.AC_OR_GL%TYPE;
  
  BEGIN
    DBG('Inside fn_consolidation_reversal');
    DBG('Parameters are as follows...');
    DBG('Trn Ref Number -->' || P_TRN_REF_NO);
    DBG('CASA err flag -->' || P_CASA_ERROR);
  
    DBG('Now calling acpkss.fn_acEntry_retrieval for trn ref no' ||
        P_TRN_REF_NO);
    L_COUNT := ACPKSS.FN_ACENTRY_RETRIEVAL(P_TRN_REF_NO, 1, L_ACC_TAB);
  
    DBG('Number of entries recd from acpkss.fn_acEntry_retrieval ' ||
        TO_CHAR(L_COUNT));
  
    L_DATE_TIME := CEPKSS_DATE.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE);
  
    L_AC_OR_GL := NULL;
  
    BEGIN
      SELECT CASA_RVRSL_TXN_CODE, INSUF_FUNDS_RVRSL_TXN_CODE
        INTO L_CASA_ERR_TRN_CODE, L_INSUFFICIENT_FUNDS_REVERSAL
        FROM CGTM_PRODUCT_REFERRAL
       WHERE PRODUCT_CODE = P_ENTRY_REC.PRODUCT_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  
    DBG('l_casa_err_trn_code -->' || L_CASA_ERR_TRN_CODE);
    DBG('l_insufficient_funds_reversal -->' ||
        L_INSUFFICIENT_FUNDS_REVERSAL);
  
    FOR Y IN 1 .. L_COUNT LOOP
      DBG('In fn_consolidation_reversal, printing the values of the parameters for cross checking for FCY NULL');
      DBG('For count ' || Y);
      DBG('instr ccy is ' || P_ENTRY_REC.INSTRUMENT_CCY);
      DBG('instr amt is ' || P_ENTRY_REC.INSTRUMENT_AMT);
      DBG('p_entry_rec.acc_branch ' || P_ENTRY_REC.ACC_BRANCH);
      DBG('p_entry_rec.rem_account ' || P_ENTRY_REC.REM_ACCOUNT);
      DBG('p_entry_rec.acc_ccy ' || P_ENTRY_REC.ACC_CCY);
      DBG('l_acc_tab.ac_ccy passed in as ' || L_ACC_TAB(Y).AC_CCY);
      DBG('l_acc_tab.ac_branch passed in as ' || L_ACC_TAB(Y).AC_BRANCH);
      DBG('l_acc_tab.ac_no passed in as ' || L_ACC_TAB(Y).AC_NO);
    
      BEGIN
        SELECT AC_OR_GL
          INTO L_AC_OR_GL
          FROM STTBS_ACCOUNT
         WHERE BRANCH_CODE = L_ACC_TAB(Y).AC_BRANCH
           AND AC_GL_NO = L_ACC_TAB(Y).AC_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          SELECT AC_OR_GL
            INTO L_AC_OR_GL
            FROM STTBS_ACCOUNT
           WHERE AC_GL_NO = L_ACC_TAB(Y).AC_NO;
      END;
    
      IF NOT FN_FCY_LCY_CONV(P_ENTRY_REC.INSTRUMENT_CCY,
                             P_ENTRY_REC.INSTRUMENT_AMT,
                             P_ENTRY_REC.ACC_BRANCH,
                             P_ENTRY_REC.REM_ACCOUNT,
                             L_ACC_TAB                 (Y).AC_CCY,
                             L_ACC_CCY_AMT,
                             L_LCYAMT,
                             L_FCYAMT,
                             L_ACC_TAB                 (Y).EXCH_RATE,
                             P_ERRCODE,
                             P_ERRPARAM) THEN
        DBG('Function fcy_lcy conversion bombed...');
        DBG('Big Trouble brewing...');
        RETURN FALSE;
      END IF;
    
      L_ACC_TAB(Y).EVENT := 'REVR';
      L_ACC_TAB(Y).EVENT_SR_NO := 2;
    
      IF GWPKS_UTIL.G_FROM_BEAN THEN
        L_ACC_TAB(Y).TRN_DT := NVL(GWPKS_UTIL.G_BRANCH_DATE,
                                   TRUNC(L_DATE_TIME));
      ELSE
        L_ACC_TAB(Y).TRN_DT := TRUNC(L_DATE_TIME);
      END IF;
    
      L_ACC_TAB(Y).TXN_INIT_DATE := TRUNC(L_DATE_TIME);
      L_ACC_TAB(Y).FCY_AMOUNT := -1 * L_FCYAMT;
      L_ACC_TAB(Y).LCY_AMOUNT := -1 * L_LCYAMT;
      L_ACC_TAB(Y).FINANCIAL_CYCLE := '';
      L_ACC_TAB(Y).PERIOD_CODE := '';
      L_ACC_TAB(Y).BATCH_NO := '';
      L_ACC_TAB(Y).CURR_NO := '';
      L_ACC_TAB(Y).USER_ID := GLOBAL.USER_ID;
      L_ACC_TAB(Y).MODULE := 'CG';
    
      DBG('FCY amt for the reversal transaction is ' || L_ACC_TAB(Y)
          .FCY_AMOUNT);
    
      IF P_CASA_ERROR = 'Y' THEN
      
        IF L_CASA_ERR_TRN_CODE IS NOT NULL THEN
          L_ACC_TAB(Y).TRN_CODE := L_CASA_ERR_TRN_CODE;
        END IF;
      ELSIF P_CASA_ERROR = 'R' THEN
        IF L_INSUFFICIENT_FUNDS_REVERSAL IS NOT NULL THEN
          L_ACC_TAB(Y).TRN_CODE := L_INSUFFICIENT_FUNDS_REVERSAL;
        END IF;
      
      END IF;
    
      IF P_CASA_ERROR = 'Y' AND L_AC_OR_GL = 'A' THEN
        IF P_ENTRY_REC.ACC_CCY = GLOBAL.LCY THEN
          L_AMT := L_LCYAMT;
        ELSE
          L_AMT := L_FCYAMT;
        END IF;
      
        DBG('l_amt value returned as ' || L_AMT);
      
        DBG('Inside casa error processing');
        IF NOT CASAPKS.FN_DIS_UPDSTATUS(P_ENTRY_REC.ACC_BRANCH,
                                        P_ENTRY_REC.TXN_DATE,
                                        P_ENTRY_REC.REM_ACCOUNT,
                                        'Y',
                                        P_ENTRY_REC.INSTRUMENT_NO_1,
                                        'Y',
                                        GLOBAL.USER_ID,
                                        P_ENTRY_REC.REFERENCE_NO,
                                        L_AMT,
                                        'D',
                                        '!=*',
                                        '!=*',
                                        P_ERRCODE,
                                        P_ERRPARAM) THEN
          DBG('casapks.fn_dis_updstatus FAILED in function fn_consolidation_reveral');
          RETURN FALSE;
        END IF;
      END IF;
    END LOOP;
  
    IF (P_CASA_ERROR = 'Y' OR P_CASA_ERROR = 'N') THEN
      DBG('Calling ac handoff for clearing consolidation reversal');
      IF P_ONLINE_AUTH = 'Y' THEN
        IF NOT ACPKSS.FN_ACHANDOFF(P_TRN_REF_NO,
                                   2,
                                   TRUNC(L_DATE_TIME),
                                   L_ACC_TAB,
                                   'B',
                                   'N',
                                   'Y',
                                   GLOBAL.USER_ID,
                                   P_ERRCODE,
                                   P_ERRPARAM) THEN
          DBG('Failed in Accounting Reversal for online auth Y...in consolidation reversal');
          RETURN FALSE;
        END IF;
      ELSE
        IF NOT ACPKSS.FN_ACHANDOFF(P_TRN_REF_NO,
                                   2,
                                   TRUNC(L_DATE_TIME),
                                   L_ACC_TAB,
                                   'U',
                                   'N',
                                   'Y',
                                   GLOBAL.USER_ID,
                                   P_ERRCODE,
                                   P_ERRPARAM) THEN
          DBG('Failed in Accounting Reversal for online auth N...in consolidation reversal');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    P_ACC_TAB := L_ACC_TAB;
    L_ACC_TAB.DELETE;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Function fn_consolidation_reversal returned false');
      RETURN FALSE;
  END FN_CONSOLIDATION_REVERSAL;

  FUNCTION FN_REVERSE_TXN(P_BRANCH    IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                          P_REF_NO    IN CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE,
                          P_ERR_CODE  OUT ERTBS_MSGS.ERR_CODE%TYPE,
                          P_ERR_PARAM OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
    L_REC            CSTBS_CLEARING_MASTER%ROWTYPE;
    L_ERR_CODE       ERTBS_MSGS.ERR_CODE%TYPE;
    L_EVENT_SEQ_NO   NUMBER;
    L_MAKER_DT_STAMP DATE;
    L_ONLINE_AUTH    CHAR(1) := 'N';
    L_AUTH           CHAR(1) := 'U';
    L_MAKER_ID       CSTBS_CLEARING_MASTER.MAKER_ID%TYPE;
    L_REJ_CODE       CSTBS_CLEARING_MASTER.REJECT_CODE%TYPE;
    L_REJECT_REASON  CSTBS_CLEARING_MASTER.REJECT_REASON%TYPE;
    L_REMARKS        CSTBS_CLEARING_MASTER.REMARKS%TYPE;
    L_AUTH_STAT      VARCHAR2(10);
  
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_CALL_FUNC_ID          NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_STATS IFTBS_CLEARING_UPLOAD.STATUS%TYPE;
  BEGIN
    BEGIN
      SELECT *
        INTO L_REC
        FROM CSTBS_CLEARING_MASTER
      
       WHERE MODULE_REFERENCE_NO = P_REF_NO;
    EXCEPTION
    
      WHEN OTHERS THEN
        DBG('Some thing happened =' || SQLERRM);
        BEGIN
          SELECT *
            INTO L_REC
            FROM CSTBS_CLEARING_MASTER
           WHERE REFERENCE_NO = P_REF_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found for the referenece=' || P_REF_NO);
            NULL;
        END;
      
    END;
  
    BEGIN
    
      SELECT AUTH_STAT
        INTO L_AUTH_STAT
        FROM IFTB_CLEARING_UPLOAD
       WHERE XREF = L_REC.XREF
         AND ENTRY_NO = L_REC.ENTRY_NO
         AND SCODE = L_REC.SCODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found for the referenece=' || P_REF_NO);
        NULL;
      WHEN OTHERS THEN
        DBG('No data found for the referenece=' || P_REF_NO);
        NULL;
    END;
    DBG('l_auth_stat=' || L_AUTH_STAT);
  
    DEBUG.PR_DEBUG('CG',
                   'Reference no for reversal is ...' || L_REC.REFERENCE_NO);
    DEBUG.PR_DEBUG('CG',
                   'cgpkss_ifdclgdt_kernel.g_auth_stat--> ' ||
                   CGPKSS_IFDCLGDT_KERNEL.G_AUTH_STAT);
    IF (L_REC.STATUS <> 'SUCC') AND
      
       NVL(CGPKSS_IFDCLGDT_KERNEL.G_AUTH_STAT, L_AUTH_STAT) = 'A' THEN
      DEBUG.PR_DEBUG('CG', 'This record is already reversed or rejected');
      P_ERR_CODE := 'CG-CL0018';
      RETURN FALSE;
    END IF;
  
    DBG('##cspks_charge.g_instrno--> ' || CSPKS_CHARGE.G_INSTRNO);
    DBG('l_rec.instrument_no_1--> ' || L_REC.INSTRUMENT_NO_1);
    CSPKS_CHARGE.G_INSTRNO := L_REC.INSTRUMENT_NO_1;
    DBG('cspks_charge.g_instrno--> ' || CSPKS_CHARGE.G_INSTRNO);
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('calling cspks_clg_serv_cluster.fn_reverse_txn');
      GLOBAL.PR_RESET_SKIP_KERNEL;
      L_CALL_FUNC_ID    := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT CSPKS_CLG_SERV_CLUSTER.FN_REVERSE_TXN(P_BRANCH,
                                                   P_REF_NO,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM,
                                                   L_CALL_FUNC_ID,
                                                   L_TB_CLUSTER_DATA) THEN
        DBG('Failed in cspks_clg_serv_cluster.fn_reverse_txn');
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      DEBUG.PR_DEBUG('CG', 'VAL_DATE_CUST :: ' || L_REC.VAL_DATE_CUST);
    
      DEBUG.PR_DEBUG('CG',
                     'global.application_date :: ' ||
                     GLOBAL.APPLICATION_DATE);
    
      DBG('l_rec.direction--> ' || L_REC.DIRECTION);
      IF L_REC.DIRECTION = 'O' THEN
        DBG('#24317705 l_rec.val_date_cust--> ' || L_REC.VAL_DATE_CUST);
        DBG('#24317705 global.application_date--> ' ||
            GLOBAL.APPLICATION_DATE);
      
        IF L_REC.VAL_DATE_CUST < GLOBAL.APPLICATION_DATE
        
         THEN
          DEBUG.PR_DEBUG('CG', 'This record is already Cleared...');
          P_ERR_CODE := 'CG-CL0031';
          RETURN FALSE;
        END IF;
      
      ELSIF L_REC.DIRECTION = 'I' THEN
        IF L_REC.VAL_DATE_CUST < GLOBAL.APPLICATION_DATE THEN
          DEBUG.PR_DEBUG('CG', 'This record is already Cleared...');
          P_ERR_CODE := 'CG-CL0031';
          RETURN FALSE;
        END IF;
      END IF;
    
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    IF NOT FN_BACKUP_CLG_TABLES(L_REC.REFERENCE_NO) THEN
      DEBUG.PR_DEBUG('CG', 'Backup not successful');
      RETURN FALSE;
    END IF;
    L_MAKER_DT_STAMP := CEPKSS_DATE.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE);
  
    IF L_REC.MODULE_CODE = 'PD' THEN
      L_ONLINE_AUTH := 'Y';
      L_AUTH        := 'A';
    END IF;
  
    IF L_REC.MODULE_CODE IN ('CG') THEN
      L_ONLINE_AUTH := 'Y';
    END IF;
  
    IF NOT FN_REVERSE_ACCT(L_REC.REFERENCE_NO,
                           P_ERR_CODE,
                           P_ERR_PARAM,
                           L_ONLINE_AUTH) THEN
      DEBUG.PR_DEBUG('CG', 'Failed in Accounting Reversal');
      RETURN FALSE;
    END IF;
  
    DEBUG.PR_DEBUG('CG',
                   'l_rec.xref->' || L_REC.XREF || '~l_rec.entry_no->' ||
                   L_REC.ENTRY_NO || '~l_rec.scode:' || L_REC.SCODE);
    BEGIN
      SELECT REJ_REASON_CODE, MAKER_ID, REMARKS, STATUS
        INTO L_REJ_CODE, L_MAKER_ID, L_REMARKS, L_STATS
        FROM IFTB_CLEARING_UPLOAD
       WHERE XREF = L_REC.XREF
            
         AND ENTRY_NO = L_REC.ENTRY_NO
         AND SCODE = L_REC.SCODE;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_REJ_CODE := '';
      
      WHEN OTHERS THEN
        SELECT REJ_REASON_CODE, MAKER_ID, REMARKS, STATUS
          INTO L_REJ_CODE, L_MAKER_ID, L_REMARKS, L_STATS
          FROM IFTB_CLEARING_UPLOAD
         WHERE XREF = L_REC.XREF
           AND INSTRNO = L_REC.INSTRUMENT_NO_1;
      
    END;
  
    DEBUG.PR_DEBUG('CG', 'l_stats: ' || L_STATS);
    DEBUG.PR_DEBUG('CG', 'l_rec.status: ' || L_REC.STATUS);
    IF L_STATS = 'REJR' THEN
      L_REC.STATUS := 'REJR';
    ELSE
      L_REC.STATUS := 'REVR';
    END IF;
    DEBUG.PR_DEBUG('CG', 'before selcting reject reason');
    BEGIN
      SELECT REASON_DESC
        INTO L_REJECT_REASON
        FROM CSTBS_CLG_REJ_REASON
       WHERE REASON_CODE = L_REJ_CODE;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_REJ_CODE := '';
    END;
    DEBUG.PR_DEBUG('CG',
                   'l_rej_code , Reject Reason  after assign...' ||
                   L_REJ_CODE || L_REJECT_REASON || L_REC.XREF);
    DEBUG.PR_DEBUG('CG',
                   'l_auth , Reject Reason  after assign...' || L_AUTH ||
                   ' user ' || GLOBAL.USER_ID || 'maker stamp ' ||
                   L_MAKER_DT_STAMP || 'maker id ' || L_MAKER_ID ||
                   'reference no ' || P_REF_NO);
  
    BEGIN
      UPDATE CSTBS_CLEARING_MASTER
      
         SET STATUS      = L_REC.STATUS,
             RECORD_STAT = 'V',
             
             REVR_DATE = GLOBAL.APPLICATION_DATE
             
            ,
             REJECT_CODE      = L_REJ_CODE,
             REJECT_REASON    = L_REJECT_REASON,
             EVENT_SEQ_NO     = EVENT_SEQ_NO + 1,
             REMARKS          = L_REMARKS,
             AUTH_STAT        = L_AUTH,
             CHECKER_ID       = DECODE(L_AUTH, 'A', GLOBAL.USER_ID, 'U', ''),
             CHECKER_DT_STAMP = DECODE(L_AUTH,
                                       'A',
                                       L_MAKER_DT_STAMP,
                                       'U',
                                       ''),
             MAKER_ID         = L_MAKER_ID,
             MAKER_DT_STAMP   = L_MAKER_DT_STAMP
       WHERE REFERENCE_NO = P_REF_NO;
    
      BEGIN
        INSERT INTO CSTBS_CLEARING_DETAILS
          (DIRECTION,
           PRODUCT_CODE,
           TXN_BRANCH,
           END_POINT,
           REFERENCE_NO,
           REM_ACCOUNT,
           BEN_ACCOUNT,
           ACC_BRANCH,
           INSTRUMENT_NO_1,
           BRANCH_CODE,
           SECTOR_CODE,
           XREF,
           EVENT_SEQ_NO,
           REMARKS,
           STATUS,
           ENTRY_NO)
        VALUES
          (L_REC.DIRECTION,
           L_REC.PRODUCT_CODE,
           L_REC.TXN_BRANCH,
           L_REC.END_POINT,
           L_REC.REFERENCE_NO,
           L_REC.REM_ACCOUNT,
           L_REC.BEN_ACCOUNT,
           L_REC.ACC_BRANCH,
           L_REC.INSTRUMENT_NO_1,
           L_REC.BRANCH_CODE,
           L_REC.SECTOR_CODE,
           L_REC.XREF,
           G_EVENT_SEQ,
           L_REMARKS,
           L_REC.STATUS,
           L_REC.ENTRY_NO + 1);
      EXCEPTION
      
        WHEN DUP_VAL_ON_INDEX THEN
          DEBUG.PR_DEBUG('CG', 'event is not incremented');
        
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('CG',
                         'problem in inserting into cstbs_clearing_details1' ||
                         SQLERRM);
          RETURN FALSE;
      END;
    
      DEBUG.PR_DEBUG('CG', 'l_auth , ' || SQL%ROWCOUNT);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  
    DEBUG.PR_DEBUG('CG',
                   'updating IFTB_CLEARING_UPLOAD table with REJR status');
    DEBUG.PR_DEBUG('CG', 'l_rec.xref::' || L_REC.XREF);
    DEBUG.PR_DEBUG('CG', 'l_rec.entry_no::' || L_REC.ENTRY_NO);
    DEBUG.PR_DEBUG('CG', 'l_rec.scode' || L_REC.SCODE);
  
    UPDATE IFTB_CLEARING_UPLOAD
    
       SET STATUS = L_REC.STATUS,
           
           AUTH_STAT        = L_AUTH,
           CHECKER_ID       = DECODE(L_AUTH, 'A', GLOBAL.USER_ID, 'U', ''),
           CHECKER_DT_STAMP = DECODE(L_AUTH, 'A', L_MAKER_DT_STAMP, 'U', ''),
           MAKER_ID         = L_MAKER_ID,
           MAKER_DT_STAMP   = L_MAKER_DT_STAMP
     WHERE XREF = L_REC.XREF
       AND ENTRY_NO = L_REC.ENTRY_NO
       AND SCODE = L_REC.SCODE;
    DEBUG.PR_DEBUG('CG',
                   'number of records updatedIFTB_CLEARING_UPLOAD' ||
                   SQL%ROWCOUNT);
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('calling cspks_clg_serv_cluster.fn_reverse_txn');
      GLOBAL.PR_RESET_SKIP_KERNEL;
      L_CALL_FUNC_ID    := 2;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT CSPKS_CLG_SERV_CLUSTER.FN_REVERSE_TXN(P_BRANCH,
                                                   P_REF_NO,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM,
                                                   L_CALL_FUNC_ID,
                                                   L_TB_CLUSTER_DATA) THEN
        DBG('Failed in cspks_clg_serv_cluster.fn_reverse_txn');
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      DBG('going to call for return');
      IF DEPK_PDC.G_PD_REVERSE THEN
        DBG('inside pd reversal call');
      ELSE
      
        DBG('not inside pd reversal call');
        IF L_REC.MODULE_CODE = 'PD' THEN
          DBG('Before Returning the PD transactions...');
        
          IF NOT DEPK_PDC.FN_RETN_PDC_CONTRACT(L_REC.MODULE_REFERENCE_NO,
                                               P_ERR_CODE,
                                               P_ERR_PARAM) THEN
            DBG('Failed in DEPK_PDC.fn_return_pdc_contract...' ||
                P_ERR_CODE || '~' || P_ERR_PARAM);
            RETURN FALSE;
          ELSE
            DBG('Sucessfully Returned the PD transactions...');
          END IF;
        END IF;
      END IF;
    
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('calling cspks_clg_serv_cluster.fn_reverse_txn');
      L_CALL_FUNC_ID    := 3;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT CSPKS_CLG_SERV_CLUSTER.FN_REVERSE_TXN(P_BRANCH,
                                                   P_REF_NO,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM,
                                                   L_CALL_FUNC_ID,
                                                   L_TB_CLUSTER_DATA) THEN
        DBG('Failed in cspks_clg_serv_cluster.fn_reverse_txn');
      END IF;
    END IF;
  
    IF L_REC.NOTIFY_RETN_TO_MODULE = 'Y' THEN
      BEGIN
        UPDATE CGTB_MODULE_CHQ_STATUS
           SET STATUS = 'R'
         WHERE REFERENCE_NO = L_REC.REFERENCE_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('cspks_clg_serv ==> ' || 'This transaction does not exist');
          P_ERR_CODE := 'CG-CL0014';
          RETURN FALSE;
      END;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'fn_reverse_txn:' || SQLERRM);
      DEBUG.PR_DEBUG('CG',
                     'fn_reverse_txn error here--->  ' ||
                     DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_REVERSE_TXN;

  FUNCTION FN_DELETE_TXN(P_BRANCH    IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                         P_REF_NO    IN CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE,
                         P_ERR_CODE  OUT ERTBS_MSGS.ERR_CODE%TYPE,
                         P_ERR_PARAM OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
    L_REC            CSTBS_CLEARING_MASTER%ROWTYPE;
    L_ERR_CODE       ERTBS_MSGS.ERR_CODE%TYPE;
    L_EVENT_SEQ_NO   NUMBER;
    L_MAKER_DT_STAMP DATE;
    L_KEY_ID         STTBS_RECORD_LOG.KEY_ID%TYPE;
  
  BEGIN
  
    SELECT *
      INTO L_REC
      FROM CSTBS_CLEARING_MASTER
     WHERE REFERENCE_NO = P_REF_NO;
  
    DEBUG.PR_DEBUG('CG',
                   'Reference no for reversal is ...' || L_REC.REFERENCE_NO);
  
    IF L_REC.AUTH_STAT = 'A' THEN
      P_ERR_CODE := 'CLG-DEL-00';
      DEBUG.PR_DEBUG('CG', 'Contract already authorised, so cannot delete');
      RETURN FALSE;
    ELSE
    
      IF NOT ACPKSS.FN_ACSERVICE(GLOBAL.CURRENT_BRANCH,
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.LCY,
                                 P_REF_NO,
                                 L_REC.EVENT_SEQ_NO,
                                 'D',
                                 GLOBAL.USER_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAM) THEN
        DEBUG.PR_DEBUG('CG',
                       'Deletion of accounting entries Failed with error code :' ||
                       P_ERR_CODE);
        RETURN FALSE;
      END IF;
    
      L_KEY_ID := '~CSTB_CLEARING_MASTER~' || P_REF_NO || '~';
      DEBUG.PR_DEBUG('CG', 'Going to delete the key id:' || L_KEY_ID);
    
      DELETE STTBS_RECORD_LOG WHERE KEY_ID = L_KEY_ID;
    
      DEBUG.PR_DEBUG('CG', 'Key id deleted successfully !');
    
      DELETE CSTBS_CLEARING_MASTER WHERE REFERENCE_NO = P_REF_NO;
    
      DEBUG.PR_DEBUG('CG', 'Deletion of CLG contract successful');
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'fn_delete_txn failed with sqlerrm :' || SQLERRM);
      RETURN FALSE;
  END FN_DELETE_TXN;

  FUNCTION FN_MT110_RECON(P_ACC_HAND IN ACPKSS.TBL_ACHOFF,
                          PERRCODES  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                          PERRPARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_MT110_RECON_REQD VARCHAR2(1) := 'N';
    L_MT_INSTNO        CATBS_MT110_RECON.CHECK_NO%TYPE;
    L_MT_AMT           CATBS_MT110_RECON.AMOUNT%TYPE;
    L_CLEARING_INSTNO  CSTBS_CLEARING_MASTER.INSTRUMENT_NO_1%TYPE;
    L_CLEARING_AMT     CSTBS_CLEARING_MASTER.INSTRUMENT_AMT%TYPE;
    L_MESSAGE_REF_NO   CATBS_MT110_RECON.MESSAGE_REF_NO%TYPE;
  
    CURSOR MT110_CUR IS
    
      SELECT *
        FROM CATBS_MT110_RECON
       WHERE NVL(STATUS, 'U') = 'U'
         AND NVL(RECON_STATUS, 'N') = 'N';
  
  BEGIN
    DBG('Inside Function fn_mt110_recon');
  
    IF P_ACC_HAND.COUNT > 0 THEN
    
      DBG('p_acc_hand.count-->' || P_ACC_HAND.COUNT);
    
      FOR I IN 1 .. P_ACC_HAND.COUNT LOOP
        DBG('customer account number is:' || P_ACC_HAND(I).AC_NO);
        DBG('current branch:' || P_ACC_HAND(I).AC_BRANCH);
      
        IF P_ACC_HAND.EXISTS(I) THEN
        
          DBG('select the mt110_recon_reqd from sttms_cust_account');
        
          BEGIN
          
            SELECT MT110_RECON_REQD
              INTO L_MT110_RECON_REQD
              FROM STTMS_CUST_ACCOUNT
             WHERE CUST_AC_NO = P_ACC_HAND(I).AC_NO
                  
               AND BRANCH_CODE = P_ACC_HAND(I).AC_BRANCH;
          
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DEBUG.PR_DEBUG('ST', 'No record found in sttms_cust_account');
            
          END;
          DBG('l_mt110_recon_reqd-->' || L_MT110_RECON_REQD);
        
          IF NVL(L_MT110_RECON_REQD, 'N') = 'Y' THEN
          
            DBG('the mt110_recon_reqd flag is Y, then select check_no,amount,message_ref_no from catbs_mt110_recon');
            DBG('cheque number' || P_ACC_HAND(I).INSTRUMENT_CODE);
            DBG('amount' || P_ACC_HAND(I).LCY_AMOUNT);
            DBG('instrument date' || P_ACC_HAND(I).TRN_DT);
            DBG('ACCOUNT' || P_ACC_HAND(I).AC_NO);
            DBG('REFERENCE NUMBER' || P_ACC_HAND(I).TRN_REF_NO);
          
            BEGIN
            
              SELECT CHECK_NO, AMOUNT, MESSAGE_REF_NO
                INTO L_MT_INSTNO, L_MT_AMT, L_MESSAGE_REF_NO
                FROM CATBS_MT110_RECON
               WHERE CHECK_NO = P_ACC_HAND(I).INSTRUMENT_CODE
                 AND AMOUNT = P_ACC_HAND(I).LCY_AMOUNT
                 AND BRANCH = P_ACC_HAND(I).AC_BRANCH
                 AND ACCOUNT = P_ACC_HAND(I).AC_NO;
            
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('no record for this Instrument');
                L_MT_INSTNO := NULL;
                L_MT_AMT    := NULL;
              WHEN OTHERS THEN
                DBG('In when others of selecting fields in catbs_mt110_recon');
            END;
          
            DBG('l_mt_instno-->' || L_MT_INSTNO);
            DBG('l_mt_amt-->' || L_MT_AMT);
            DBG('l_message_ref_no-->' || L_MESSAGE_REF_NO);
          
            IF L_MT_INSTNO IS NOT NULL AND L_MT_AMT IS NOT NULL THEN
            
              DBG('Updating cstb_clearing_master');
            
              UPDATE CSTBS_CLEARING_MASTER
                 SET MT110_RECON_STATUS = 'R',
                     MT110_MSG_REF_NO   = L_MESSAGE_REF_NO
               WHERE INSTRUMENT_NO_1 = P_ACC_HAND(I).INSTRUMENT_CODE
                 AND INSTRUMENT_AMT = P_ACC_HAND(I).LCY_AMOUNT
                 AND ACC_BRANCH = P_ACC_HAND(I).AC_BRANCH
                 AND REM_ACCOUNT = P_ACC_HAND(I).AC_NO;
            
              DBG('After update in cstb_clearing_master');
              DBG('Updating catb_mt110_recon');
            
              UPDATE CATBS_MT110_RECON
                 SET STATUS = 'P', RECON_STATUS = 'R'
               WHERE CHECK_NO = P_ACC_HAND(I).INSTRUMENT_CODE
                 AND AMOUNT = P_ACC_HAND(I).LCY_AMOUNT
                 AND BRANCH = P_ACC_HAND(I).AC_BRANCH
                 AND ACCOUNT = P_ACC_HAND(I).AC_NO;
            
              DBG('After update in catb_mt110_recon');
            
            ELSE
            
              DBG('if instrument number and amount is null then update as U');
            
              UPDATE CATBS_MT110_RECON
                 SET RECON_STATUS = 'U'
               WHERE CHECK_NO = P_ACC_HAND(I).INSTRUMENT_CODE
                 AND AMOUNT = P_ACC_HAND(I).LCY_AMOUNT
                 AND BRANCH = P_ACC_HAND(I).AC_BRANCH
                 AND ACCOUNT = P_ACC_HAND(I).AC_NO;
            
              DBG('After update in catb_mt110_recon');
            
              UPDATE CSTBS_CLEARING_MASTER
                 SET MT110_RECON_STATUS = 'U'
               WHERE INSTRUMENT_NO_1 = P_ACC_HAND(I).INSTRUMENT_CODE
                 AND TXN_DATE = P_ACC_HAND(I).TRN_DT
                 AND ACC_BRANCH = P_ACC_HAND(I).AC_BRANCH
                 AND REM_ACCOUNT = P_ACC_HAND(I).AC_NO
                 AND REFERENCE_NO = P_ACC_HAND(I).TRN_REF_NO;
            
              DBG('After update in cstb_clearing_master');
            
            END IF;
          END IF;
        END IF;
      
      END LOOP;
    
      DBG('if p_acc_hand.count is not greater than 0 then.....');
    
    ELSE
    
      FOR MT110_REC IN MT110_CUR LOOP
        DBG('select instrument_no and amount from cstb_clearing_master');
      
        BEGIN
          SELECT INSTRUMENT_NO_1, INSTRUMENT_AMT
            INTO L_CLEARING_INSTNO, L_CLEARING_AMT
            FROM CSTBS_CLEARING_MASTER
           WHERE INSTRUMENT_NO_1 = MT110_REC.CHECK_NO
             AND INSTRUMENT_AMT = MT110_REC.AMOUNT
             AND ACC_BRANCH = MT110_REC.BRANCH
             AND REM_ACCOUNT = MT110_REC.ACCOUNT;
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('no record for this Instrument');
            L_CLEARING_INSTNO := NULL;
            L_CLEARING_AMT    := NULL;
          WHEN OTHERS THEN
            DBG('In when others of selecting fields in cstbs_clearing_master');
        END;
        DBG('l_clearing_instno-->' || L_CLEARING_INSTNO);
        DBG('l_clearing_amt-->' || L_CLEARING_AMT);
      
        IF L_CLEARING_INSTNO IS NOT NULL AND L_CLEARING_AMT IS NOT NULL THEN
          DBG('instrument_no and amount is found then update');
        
          UPDATE CSTBS_CLEARING_MASTER
             SET MT110_RECON_STATUS = 'R',
                 MT110_MSG_REF_NO   = MT110_REC.MESSAGE_REF_NO
           WHERE INSTRUMENT_NO_1 = MT110_REC.CHECK_NO
             AND INSTRUMENT_AMT = MT110_REC.AMOUNT
             AND ACC_BRANCH = MT110_REC.BRANCH
             AND REM_ACCOUNT = MT110_REC.ACCOUNT;
        
          DBG('after update in cstb_clearing_master');
        
          UPDATE CATBS_MT110_RECON
             SET STATUS = 'P', RECON_STATUS = 'R'
           WHERE CHECK_NO = MT110_REC.CHECK_NO
             AND AMOUNT = MT110_REC.AMOUNT
             AND BRANCH = MT110_REC.BRANCH
             AND ACCOUNT = MT110_REC.ACCOUNT;
        
          DBG('after update in catb_mt110_recon');
        
        ELSE
          DBG('if the instrument_no and amount is null then....');
          UPDATE CATBS_MT110_RECON
             SET RECON_STATUS = 'U'
           WHERE CHECK_NO = MT110_REC.CHECK_NO
             AND AMOUNT = MT110_REC.AMOUNT
             AND BRANCH = MT110_REC.BRANCH
             AND ACCOUNT = MT110_REC.ACCOUNT;
        
          UPDATE CSTBS_CLEARING_MASTER
             SET MT110_RECON_STATUS = 'U'
           WHERE INSTRUMENT_NO_1 = MT110_REC.CHECK_NO
             AND TXN_DATE = MT110_REC.TRN_DATE
             AND ACC_BRANCH = MT110_REC.BRANCH
             AND REM_ACCOUNT = MT110_REC.ACCOUNT;
        
        END IF;
      END LOOP;
    END IF;
    RETURN TRUE;
  END FN_MT110_RECON;

  FUNCTION FN_TD_CLOSE(P_REF_NO   IN CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE,
                       P_ERR_CODE OUT ERTBS_MSGS.ERR_CODE%TYPE,
                       P_ERRPARAM OUT ERTBS_MSGS.MESSAGE%TYPE) RETURN BOOLEAN IS
  
    L_REJ_REC       CSTB_CLEARING_MASTER%ROWTYPE;
    L_TD_ACC        STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_ACC_BR        STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_KEY_ID        VARCHAR2(32762);
    L_FLAG          NUMBER := 0;
    L_USER          ACTBS_DAILY_LOG.AUTH_ID%TYPE;
    L_AUTH_DT_STAMP DATE;
  
  BEGIN
  
    DBG('Inside fn_td_close');
    L_USER          := NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID);
    L_AUTH_DT_STAMP := CEPKSS_DATE.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE);
  
    BEGIN
      SELECT *
        INTO L_REJ_REC
        FROM CSTB_CLEARING_MASTER
       WHERE REFERENCE_NO = P_REF_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;
  
    DBG('l_rej_rec.reference_no--->' || L_REJ_REC.REFERENCE_NO);
    DBG('coming here for td');
  
    BEGIN
      SELECT TD_REF_NO, TD_BRANCH
        INTO L_TD_ACC, L_ACC_BR
        FROM CGTB_TD_LINKAGES
       WHERE CLEARING_REF_NO = L_REJ_REC.REFERENCE_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DEBUG.PR_DEBUG('CG',
                       'No Data Found for Ref.No. - ' ||
                       L_REJ_REC.REFERENCE_NO);
        L_TD_ACC := NULL;
        L_ACC_BR := NULL;
    END;
  
    DBG('l_td_acc--->' || L_TD_ACC);
    DBG('l_Acc_Br--->' || L_ACC_BR);
  
    SAVEPOINT SP_CLOSE;
  
    L_KEY_ID := '~STTM_CUST_ACCOUNT~' || L_ACC_BR || '~' || L_TD_ACC || '~';
  
    BEGIN
    
      DBG('going to update the   record_stat and   auth_stat to A');
      UPDATE STTMS_CUST_ACCOUNT
         SET RECORD_STAT      = 'C',
             AUTH_STAT        = 'A',
             MOD_NO           = MOD_NO + 1,
             CHECKER_ID       = L_USER,
             CHECKER_DT_STAMP = L_AUTH_DT_STAMP
       WHERE BRANCH_CODE = L_ACC_BR
         AND CUST_AC_NO = L_TD_ACC;
    
      UPDATE STTMS_DENOM_DEP_CERTIF
         SET NEW_STATUS           = 'C',
             STATUS_CHANGE_DATE   = GLOBAL.APPLICATION_DATE,
             STATUS_CHANGE_REASON = 'Pay-in transaction unsuccesful'
       WHERE BRANCH_CODE = L_ACC_BR
         AND CUST_AC_NO = L_TD_ACC;
    
      UPDATE STTBS_RECORD_MASTER
         SET RECORD_STAT        = 'C',
             AUTH_STAT          = 'A',
             CURR_MOD_NO        = CURR_MOD_NO + 1,
             LATEST_AUTH_MOD_NO = LATEST_AUTH_MOD_NO + 1
       WHERE KEY_ID = L_KEY_ID;
    
      UPDATE ICTBS_ACC_PR
         SET NEXT_CALC_DT      = NULL,
             NEXT_ACCR_DT      = NULL,
             NEXT_SCHD_LIQ_DT  = NULL,
             NEXT_SCHD_ACCR_DT = NULL,
             NEXT_LIQ_DT       = NULL
       WHERE ACC = L_TD_ACC
         AND BRN = L_ACC_BR;
    
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_CODE := 'AC-CLOSE008';
        DBG('Failed while updating Cust Account to closed.');
        ROLLBACK TO SP_CLOSE;
        L_FLAG := -1;
        RETURN FALSE;
    END;
    DBG('Post Closure PART');
    IF NOT CEPKSS.FN_POST_UPDATE_ACCOUNT(L_TD_ACC,
                                         L_ACC_BR,
                                         'CLOSE',
                                         P_ERR_CODE) THEN
      DBG('Error in Post update account ' || P_ERR_CODE);
      ROLLBACK TO SP_CLOSE;
      L_FLAG := -1;
      RETURN FALSE;
    END IF;
  
    IF L_FLAG = -1 THEN
      DBG('Failed in close out withdrawl with....' || P_ERR_CODE);
      DBG('Closure of Account Failed.');
      P_ERR_CODE := 'ST-CUS24';
      P_ERRPARAM := '';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERRPARAM);
      CSPKS_ACC_SERVICE.PR_SET_CLOSURE_FLAG('N');
      RETURN FALSE;
    END IF;
    DBG('Returning Succesfully from fn_td_close');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_td_close...' || SQLERRM);
      RETURN FALSE;
  END FN_TD_CLOSE;

  PROCEDURE PR_BUILD_XRATE_P_AND_L_ENTRIES(P_ACC_HAND  IN OUT ACPKS.TBL_ACHOFF,
                                           P_ARC_ROW   IN IFTMS_ARC_MAINT%ROWTYPE,
                                           P_NEG_AMT   IN NUMBER,
                                           P_ENTRY_REC IN CSTBS_CLEARING_MASTER%ROWTYPE,
                                           P_ERR_CODE  IN OUT VARCHAR2,
                                           P_RET       IN OUT NUMBER) IS
  
    J              NUMBER;
    L_PROFIT_LOSS  VARCHAR2(1);
    L_PL_AMT       NUMBER;
    L_PL_DR_ACC    STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_PL_DR_BRN    STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_PL_CR_ACC    STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_PL_CR_BRN    STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_PL_AMT_LCY   NUMBER;
    L_PL_EXCH_RATE NUMBER;
  
    L_EMPTY_REC ACTBS_HANDOFF%ROWTYPE;
  
  BEGIN
    DBG('To frame PL entries ');
    DBG('p_neg_amt ' || P_NEG_AMT);
    DBG('l_uptb_txnlog.txn_amt_acy ' || P_ENTRY_REC.INSTRUMENT_AMT);
    DBG('p_arc_row.PROFIT_REVAL_GL ' || P_ARC_ROW.PROFIT_REVAL_GL);
    DBG('p_arc_row.LOSS_REVAL_GL ' || P_ARC_ROW.LOSS_REVAL_GL);
    DBG('p_arc_row.RATE_TYPE_INDICATOR ' || P_ARC_ROW.RATE_TYPE_INDICATOR);
  
    IF P_NEG_AMT < P_ENTRY_REC.INSTRUMENT_AMT THEN
      DBG('PROFIT ');
      L_PROFIT_LOSS := 'P';
      L_PL_AMT      := P_ENTRY_REC.INSTRUMENT_AMT - P_NEG_AMT;
      L_PL_DR_ACC   := P_ENTRY_REC.BEN_ACCOUNT;
      L_PL_DR_BRN   := P_ENTRY_REC.ACC_BRANCH;
      L_PL_CR_ACC   := P_ARC_ROW.PROFIT_REVAL_GL;
      L_PL_CR_BRN   := GLOBAL.CURRENT_BRANCH;
    ELSE
      DBG('LOSS ');
      L_PROFIT_LOSS := 'L';
      L_PL_AMT      := P_NEG_AMT - P_ENTRY_REC.INSTRUMENT_AMT;
      L_PL_DR_ACC   := P_ARC_ROW.LOSS_REVAL_GL;
      L_PL_DR_BRN   := GLOBAL.CURRENT_BRANCH;
      L_PL_CR_ACC   := P_ENTRY_REC.BEN_ACCOUNT;
      L_PL_CR_BRN   := P_ENTRY_REC.ACC_BRANCH;
    END IF;
  
    DBG('p_entry_rec.txn_ccy ' || P_ENTRY_REC.INSTRUMENT_CCY ||
        ' ben_account' || P_ENTRY_REC.BEN_ACCOUNT);
    DBG('l_pl_amt ' || L_PL_AMT);
  
    IF NOT CYPKS.FN_AMT1_TO_AMT2(SUBSTR(P_ENTRY_REC.REFERENCE_NO, 1, 3),
                                 P_ENTRY_REC.INSTRUMENT_CCY,
                                 GLOBAL.LCY
                                 
                                ,
                                 NVL(G_RATE_TYPE_PREFERRED, 'STANDARD')
                                 
                                ,
                                 NVL(G_RATE_CODE_PREFERRED, 'M')
                                 
                                ,
                                 L_PL_AMT,
                                 'Y',
                                 L_PL_AMT_LCY,
                                 L_PL_EXCH_RATE,
                                 P_ERR_CODE) THEN
      DBG('Failed in pl lcy conversion ' || P_ERR_CODE);
      RETURN;
    END IF;
  
    DBG('l_pl_amt_lcy ' || L_PL_AMT_LCY);
  
    J := P_ACC_HAND.COUNT;
    DBG('j is  ' || J);
  
    J := J + 1;
  
    P_ACC_HAND(J) := L_EMPTY_REC;
    P_ACC_HAND(J).MODULE := 'CG';
    P_ACC_HAND(J).MIS_HEAD := P_ARC_ROW.COD_MIS_HEAD;
    P_ACC_HAND(J).TRN_REF_NO := P_ACC_HAND(1).TRN_REF_NO;
    P_ACC_HAND(J).EVENT_SR_NO := 1;
    P_ACC_HAND(J).EVENT := 'REVL';
    P_ACC_HAND(J).TRN_DT := P_ACC_HAND(1).TRN_DT;
    P_ACC_HAND(J).VALUE_DT := P_ACC_HAND(1).VALUE_DT;
    P_ACC_HAND(J).TXN_INIT_DATE := P_ACC_HAND(1).TXN_INIT_DATE;
    P_ACC_HAND(J).USER_ID := P_ACC_HAND(1).USER_ID;
    P_ACC_HAND(J).NETTING_IND := P_ACC_HAND(1).NETTING_IND;
    P_ACC_HAND(J).DRCR_IND := 'D';
    P_ACC_HAND(J).INSTRUMENT_CODE := P_ACC_HAND(1).INSTRUMENT_CODE;
    P_ACC_HAND(J).TRN_CODE := P_ACC_HAND(1).TRN_CODE;
    P_ACC_HAND(J).AMOUNT_TAG := 'REVL_AMT';
    P_ACC_HAND(J).AC_BRANCH := L_PL_DR_BRN;
    P_ACC_HAND(J).AC_CCY := GLOBAL.LCY;
    P_ACC_HAND(J).AC_NO := L_PL_DR_ACC;
    P_ACC_HAND(J).FCY_AMOUNT := NULL;
    P_ACC_HAND(J).LCY_AMOUNT := L_PL_AMT_LCY;
    P_ACC_HAND(J).EXCH_RATE := NULL;
  
    P_ACC_HAND(J + 1) := L_EMPTY_REC;
    P_ACC_HAND(J + 1) := P_ACC_HAND(J);
    P_ACC_HAND(J + 1).DRCR_IND := 'C';
    P_ACC_HAND(J + 1).AMOUNT_TAG := 'REVL_AMT';
    P_ACC_HAND(J + 1).AC_BRANCH := L_PL_CR_BRN;
    P_ACC_HAND(J + 1).AC_NO := L_PL_CR_ACC;
    P_ACC_HAND(J + 1).FCY_AMOUNT := NULL;
    P_ACC_HAND(J + 1).LCY_AMOUNT := L_PL_AMT_LCY;
    P_ACC_HAND(J + 1).EXCH_RATE := NULL;
  
    DBG('To ret true now ');
    P_RET := 0;
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in pr_build_xrate_p_and_l_entries  ' || SQLERRM);
      P_RET := -1;
      RETURN;
  END PR_BUILD_XRATE_P_AND_L_ENTRIES;

  FUNCTION FN_PROCESS_REVERSE(PBRANCH           IN VARCHAR2,
                              P_REV_COL_LIST    IN VARCHAR2,
                              P_REV_DATA_STRING IN VARCHAR2,
                              P_REFERENCE_NO    OUT VARCHAR2,
                              P_FCCREF          OUT VARCHAR2,
                              P_STATUS          OUT VARCHAR2,
                              P_ERR_CODE        OUT VARCHAR2,
                              P_ERR_PARAM       OUT VARCHAR2,
                              P_ONLINE_AUTH     IN CHAR,
                              P_CONSOL_REF_NO   IN VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN IS
    L_REV_REC        CSTBS_CLEARING_MASTER%ROWTYPE;
    L_ERR_CODE       ERTBS_MSGS.ERR_CODE%TYPE;
    L_XREF           CSTBS_CLEARING_MASTER.XREF%TYPE;
    L_EVENT_SEQ_NO   NUMBER;
    L_MAKER_DT_STAMP DATE;
    L_REASON         STTBS_REFERRAL_QUEUE.REASON%TYPE;
    CURSOR REV_RECS(P_REFERENCE_NO VARCHAR2) IS
      SELECT *
        FROM CSTBS_CLEARING_MASTER
       WHERE REFERENCE_NO = P_REFERENCE_NO;
  BEGIN
    DEBUG.PR_DEBUG('CG', 'Inside fn_process_reverse' || P_REFERENCE_NO);
    IF P_REV_DATA_STRING IS NULL THEN
      DEBUG.PR_DEBUG('CG', 'Reversal Data String is null');
      P_ERR_CODE := 'CG-CL0015';
      RETURN FALSE;
    END IF;
    IF NOT FN_READ_REV_DATA_STRING(P_REV_DATA_STRING,
                                   P_REV_COL_LIST,
                                   L_XREF,
                                   L_ERR_CODE) THEN
      DEBUG.PR_DEBUG('CG', 'fn_read_rev_data_string - RETURN FALSE');
      P_ERR_CODE := L_ERR_CODE;
      RETURN FALSE;
    END IF;
    DEBUG.PR_DEBUG('CG', 'Xref is ..' || L_XREF);
    FOR X IN REV_RECS(L_XREF) LOOP
      DEBUG.PR_DEBUG('CG',
                     'Reference no for reversal is ...' || X.REFERENCE_NO);
      IF (X.STATUS <> 'SUCC') THEN
        DEBUG.PR_DEBUG('CG', 'This record is already reversed or rejected');
        P_ERR_CODE := 'CG-CL0018';
        OVPKS.PR_APPENDTBL(P_ERR_CODE, NULL);
        RETURN FALSE;
      END IF;
      IF NOT FN_BACKUP_CLG_TABLES(X.REFERENCE_NO) THEN
        DEBUG.PR_DEBUG('CG', 'Backup not successful');
        RETURN FALSE;
      END IF;
      L_MAKER_DT_STAMP := CEPKSS_DATE.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE);
    
      BEGIN
        DBG('selecting reason code given in referral queue..');
        SELECT REASON
          INTO L_REASON
          FROM STTBS_REFERRAL_QUEUE
         WHERE CONTRACT_REF_NO = X.REFERENCE_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Inside exception..');
          L_REASON := NULL;
      END;
    
      DBG('##cspks_charge.g_instrno--> ' || CSPKS_CHARGE.G_INSTRNO);
      DBG('x.instrument_no_1--> ' || X.INSTRUMENT_NO_1);
      CSPKS_CHARGE.G_INSTRNO := X.INSTRUMENT_NO_1;
      DBG('cspks_charge.g_instrno--> ' || CSPKS_CHARGE.G_INSTRNO);
    
      UPDATE CGTBS_TRANSACTION_MASTER
         SET STATUS           = 'Reversed',
             AUTH_STAT        = 'U',
             CHECKER_ID       = '',
             CHECKER_DT_STAMP = '',
             MAKER_ID         = GLOBAL.USER_ID,
             MAKER_DT_STAMP   = L_MAKER_DT_STAMP
      
       WHERE TRANSACTION_REF_NO = X.REFERENCE_NO;
      IF NOT FN_REVERSE_ACCT(X.REFERENCE_NO,
                             P_ERR_CODE,
                             P_ERR_PARAM,
                             P_ONLINE_AUTH,
                             P_CONSOL_REF_NO) THEN
        DEBUG.PR_DEBUG('CG', 'Failed in Accounting Reversal');
        RETURN FALSE;
      END IF;
      L_REV_REC.STATUS := 'REVR';
      SELECT EVENT_SEQ_NO
        INTO L_EVENT_SEQ_NO
        FROM CSTBS_CLEARING_MASTER
       WHERE REFERENCE_NO = X.REFERENCE_NO;
      DEBUG.PR_DEBUG('CG', 'Last event seq no was ' || L_EVENT_SEQ_NO);
      L_EVENT_SEQ_NO := L_EVENT_SEQ_NO + 1;
      UPDATE CSTBS_CLEARING_MASTER
         SET STATUS           = L_REV_REC.STATUS,
             EVENT_SEQ_NO     = L_EVENT_SEQ_NO,
             AUTH_STAT        = 'U',
             CHECKER_ID       = '',
             CHECKER_DT_STAMP = '',
             MAKER_ID         = GLOBAL.USER_ID,
             MAKER_DT_STAMP   = L_MAKER_DT_STAMP,
             REVR_DATE        = GLOBAL.APPLICATION_DATE,
             REJECT_CODE      = L_REASON
       WHERE REFERENCE_NO = X.REFERENCE_NO;
      DEBUG.PR_DEBUG('CG', 'Authorizing the txn..');
      IF NOT FN_AUTH_TXN(PBRANCH, X.REFERENCE_NO, P_ERR_CODE, P_ERR_PARAM) THEN
        DEBUG.PR_DEBUG('CG',
                       'Failed in Authorizing the txn  - ' || P_ERR_CODE);
        RETURN FALSE;
      END IF;
    END LOOP;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG', 'Exception in fn_process_reverse');
      RETURN FALSE;
    
  END FN_PROCESS_REVERSE;

  PROCEDURE PR_TRACK_ACCOUNT_NSF(TRN_REF_NO IN VARCHAR2) IS
  
    L_ACC_NO    STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_ACC_BRN   STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_AVAIL_AMT CSTBS_AUTO_SETTLE_BLOCK.AMOUNT_AVAILABLE%TYPE;
  
    LBAL_TXN       STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;
    LBAL_OFS       STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;
    L_AVL_BAL      STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;
    L_AVL_BAL_USED STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;
    L_AVL_BAL_LEFT STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;
  
    L_TXN_BAL_DONE VARCHAR2(1) := 'N';
    L_OFS_BAL_DONE VARCHAR2(1) := 'N';
  
  BEGIN
    DBG('inside pr_track_account_nsf for ref no ' || TRN_REF_NO);
    DBG('g_nsf_acc--->' || G_NSF_ACC);
  
    IF NVL(PKG_NSF_TRACKED, 'N') = 'Y' THEN
      DBG('nsf tracking is there.. So updating available balance now..');
    
      FOR EACH_REC IN (SELECT *
                         FROM CSTB_AUTO_SETTLE_BLOCK_TEMP
                        WHERE CONTRACT_REF_NO = TRN_REF_NO) LOOP
      
        DBG('each_rec.account_no : ' || EACH_REC.ACCOUNT_NO);
        DBG('each_rec.account_br : ' || EACH_REC.ACCOUNT_BR);
        DBG('each_rec.component : ' || EACH_REC.COMPONENT);
        DBG('each_rec.amount_due : ' || EACH_REC.AMOUNT_DUE);
        DBG('each_rec.amount_available : ' || EACH_REC.AMOUNT_AVAILABLE);
        DBG('g_nsf_acc--->' || G_NSF_ACC);
        L_AVL_BAL := 0;
      
        IF EACH_REC.ACCOUNT_NO = G_NSF_ACC THEN
          DBG('Charge on txn account');
          DBG('l_txn_bal_done : ' || L_TXN_BAL_DONE);
          IF NVL(L_TXN_BAL_DONE, 'N') = 'N' THEN
            IF NOT ACPKSS_MISC.FN_GETAVLBAL(EACH_REC.ACCOUNT_BR,
                                            EACH_REC.ACCOUNT_NO,
                                            LBAL_TXN,
                                            'Y') THEN
              DBG('bombed while callling acpkss_misc.fn_GetAvlBal');
            ELSE
              DBG('Setting l_txn_bal_done to Y');
              L_TXN_BAL_DONE := 'Y';
            END IF;
            DBG('lbal_txn : ' || LBAL_TXN);
            DBG('l_avl_bal_left -->> ' || L_AVL_BAL_LEFT);
          
            DBG('cspkss_arc.g_acc_ccy_chg_txn_NSF : ' ||
                CSPKSS_ARC.G_ACC_CCY_CHG_TXN_NSF);
          
            L_AVL_BAL_LEFT := LBAL_TXN;
          END IF;
          DBG('l_avl_bal_left here is  : ' || L_AVL_BAL_LEFT);
          IF L_AVL_BAL_LEFT > 0 THEN
            DBG('Balance left greater than 0');
            IF L_AVL_BAL_LEFT >= EACH_REC.AMOUNT_DUE THEN
              DBG('Coming txn here 1');
              L_AVL_BAL      := EACH_REC.AMOUNT_DUE;
              L_AVL_BAL_LEFT := L_AVL_BAL_LEFT - EACH_REC.AMOUNT_DUE;
            ELSE
              DBG('Coming txn here 2');
              L_AVL_BAL      := L_AVL_BAL_LEFT;
              L_AVL_BAL_LEFT := 0;
            END IF;
          ELSE
            DBG('Balance left is less than 0.. Setting available balance to 0');
            L_AVL_BAL      := 0;
            L_AVL_BAL_LEFT := 0;
          END IF;
        
        ELSE
          DBG('Charge on ofs account');
          DBG('l_ofs_bal_done : ' || L_OFS_BAL_DONE);
          IF NVL(L_OFS_BAL_DONE, 'N') = 'N' THEN
            IF NOT ACPKSS_MISC.FN_GETAVLBAL(EACH_REC.ACCOUNT_BR,
                                            EACH_REC.ACCOUNT_NO,
                                            LBAL_OFS,
                                            'Y') THEN
              DBG('bombed while callling acpkss_misc.fn_GetAvlBal');
            ELSE
              DBG('Setting l_ofs_bal_done to Y');
              L_OFS_BAL_DONE := 'Y';
            END IF;
            DBG('l_avl_bal_left : ' || L_AVL_BAL_LEFT);
            DBG('lbal_ofs : ' || LBAL_OFS);
            DBG('cspkss_arc.g_acc_ccy_chg_ofs_NSF : ' ||
                CSPKSS_ARC.G_ACC_CCY_CHG_OFS_NSF);
          
            L_AVL_BAL_LEFT := LBAL_OFS;
          END IF;
          DBG('l_avl_bal_left : ' || L_AVL_BAL_LEFT);
          IF L_AVL_BAL_LEFT > 0 THEN
            DBG('Balance left greater than 0');
            IF L_AVL_BAL_LEFT >= EACH_REC.AMOUNT_DUE THEN
              DBG('Coming ofs here 1');
              L_AVL_BAL      := EACH_REC.AMOUNT_DUE;
              L_AVL_BAL_LEFT := L_AVL_BAL_LEFT - EACH_REC.AMOUNT_DUE;
            ELSE
              DBG('Coming ofs here 2');
              L_AVL_BAL      := L_AVL_BAL_LEFT;
              L_AVL_BAL_LEFT := 0;
            END IF;
          ELSE
            DBG('Balance left is less than 0.. Setting available balance to 0');
            L_AVL_BAL      := 0;
            L_AVL_BAL_LEFT := 0;
          END IF;
        END IF;
      
        DBG('l_avl_bal : ' || L_AVL_BAL);
        DBG('l_avl_bal_left : ' || L_AVL_BAL_LEFT || '~' || TRN_REF_NO || '~' ||
            EACH_REC.ACCOUNT_NO || '~' || EACH_REC.COMPONENT);
      
        UPDATE CSTB_AUTO_SETTLE_BLOCK_TEMP
           SET AMOUNT_AVAILABLE = NVL(AMOUNT_AVAILABLE, 0) + L_AVL_BAL
         WHERE CONTRACT_REF_NO = TRN_REF_NO
           AND ACCOUNT_NO = EACH_REC.ACCOUNT_NO
           AND COMPONENT = EACH_REC.COMPONENT;
      
        DBG('UPDATE -->' || SQL%ROWCOUNT);
      END LOOP;
    END IF;
  
    BEGIN
      INSERT INTO CSTBS_AUTO_SETTLE_BLOCK
        (SELECT *
           FROM CSTB_AUTO_SETTLE_BLOCK_TEMP
          WHERE CONTRACT_REF_NO = TRN_REF_NO);
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;
    END;
  
    FOR EACH_REC IN (SELECT ACCOUNT_NO, ACCOUNT_BR, AMOUNT_AVAILABLE
                       FROM CSTBS_AUTO_SETTLE_BLOCK
                      WHERE CONTRACT_REF_NO = TRN_REF_NO) LOOP
      DBG('each_rec.account_no : ' || EACH_REC.ACCOUNT_NO);
      DBG('each_rec.account_br : ' || EACH_REC.ACCOUNT_BR);
      DBG('each_rec.amount_available : ' || EACH_REC.AMOUNT_AVAILABLE);
      UPDATE STTMS_CUST_ACCOUNT
         SET RECEIVABLE_AMOUNT = RECEIVABLE_AMOUNT +
                                 NVL(EACH_REC.AMOUNT_AVAILABLE, 0)
       WHERE CUST_AC_NO = EACH_REC.ACCOUNT_NO
         AND BRANCH_CODE = EACH_REC.ACCOUNT_BR;
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('in when others of pr_track_account_nsf with ' || SQLERRM);
  END PR_TRACK_ACCOUNT_NSF;

  FUNCTION FN_PROCESS_HOST_RETURN(PBRANCH       IN VARCHAR2,
                                  P_XREF        IN OUT VARCHAR2,
                                  P_FCCREF      IN OUT VARCHAR2,
                                  P_ERR_CODE    OUT VARCHAR2,
                                  P_ERR_PARAM   OUT VARCHAR2,
                                  P_ONLINE_AUTH IN CHAR) RETURN BOOLEAN IS
  
    L_REJ_REC           CSTBS_CLEARING_MASTER%ROWTYPE;
    L_MAKER_DT_STAMP    DATE;
    L_REJECT_REASON     CSTBS_CLEARING_MASTER.REJECT_REASON%TYPE;
    L_REJECT_CODE       VARCHAR2(3);
    L_EVENT_SEQ_NO      NUMBER;
    L_REMARKS           VARCHAR2(200);
    L_TB_REJREASON      CGPKS_CGDCLGDT_KERNEL.TY_REJREASON;
    L_REJECT_ACCOUNT    VARCHAR2(20);
    L_DEFER_LIQUIDATION VARCHAR2(1);
    L_CHQ_RETURN_AMT    CSTBS_CLEARING_MASTER.INSTRUMENT_AMT%TYPE;
    L_BRANCH_CODE       CSTBS_CLEARING_MASTER.TXN_BRANCH%TYPE;
    L_XREF              CSTBS_CLEARING_MASTER.REFERENCE_NO%TYPE;
    L_TOT_CHG_AMT       NUMBER;
  BEGIN
    DBG('In Function fn_process_Host_Retn_Revr.....');
    L_MAKER_DT_STAMP := CEPKSS_DATE.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE);
    DBG('XREF is ...' || P_XREF || 'Reference no  ' || P_FCCREF);
  
    BEGIN
      SELECT *
        INTO L_REJ_REC
        FROM CSTBS_CLEARING_MASTER
       WHERE XREF = P_XREF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DEBUG.PR_DEBUG('CG',
                       'No Data Found for Ref.No. - ' ||
                       L_REJ_REC.REFERENCE_NO);
        P_ERR_CODE := 'CG-CL0014';
        RETURN FALSE;
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('CG', 'Exception raised -' || SQLERRM);
        RETURN FALSE;
    END;
  
    IF L_REJ_REC.MODULE_CODE IN ('CG', 'TD', 'CL') THEN
      IF L_REJ_REC.STATUS <> 'SUCC' THEN
        DEBUG.PR_DEBUG('CG',
                       'This record is already reversed or rejected...');
        P_ERR_CODE := 'CG-CL0018';
        RETURN FALSE;
      END IF;
    
      DEBUG.PR_DEBUG('CG', 'l_rej_rec.direcion...' || L_REJ_REC.DIRECTION);
    
      IF L_REJ_REC.VAL_DATE_CUST < GLOBAL.APPLICATION_DATE THEN
        DEBUG.PR_DEBUG('CG', 'This record is already Cleared...');
        P_ERR_CODE := 'CG-CL0031';
        RETURN FALSE;
      END IF;
    
      IF NOT FN_BACKUP_CLG_TABLES(L_REJ_REC.REFERENCE_NO) THEN
        DEBUG.PR_DEBUG('CG', 'Backup not successful');
        RETURN FALSE;
      END IF;
    
      UPDATE CGTBS_TRANSACTION_MASTER
         SET STATUS           = 'Rejected',
             AUTH_STAT        = 'U',
             CHECKER_ID       = '',
             CHECKER_DT_STAMP = '',
             MAKER_ID         = GLOBAL.USER_ID,
             MAKER_DT_STAMP   = L_MAKER_DT_STAMP
       WHERE TRANSACTION_REF_NO = L_REJ_REC.XREF;
      DBG('product_code-->' || L_REJ_REC.PRODUCT_CODE);
    
      BEGIN
        SELECT NVL(DEFER_LIQUIDATION, 'N')
          INTO L_DEFER_LIQUIDATION
          FROM CGTMS_PRODUCT_REFERRAL
         WHERE PRODUCT_CODE = L_REJ_REC.PRODUCT_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_CODE  := 'CG-PROD-001';
          P_ERR_PARAM := L_REJ_REC.PRODUCT_CODE;
      END;
      DBG('l_defer_liquidation-->' || L_DEFER_LIQUIDATION);
      DBG('Direction          -->' || L_REJ_REC.DIRECTION);
      DBG('FILE_CONSOL_STATUS-->' || L_REJ_REC.FILE_CONSOL_STATUS);
      DBG('l_defer_liquidation-->' || L_DEFER_LIQUIDATION);
    
      IF L_REJ_REC.DIRECTION = 'O' AND NVL(L_DEFER_LIQUIDATION, 'N') = 'N' AND
         NVL(L_REJ_REC.FILE_CONSOL_STATUS, 'N') = 'Y' THEN
        DBG('l_rej_rec.val_date_cust--->' || L_REJ_REC.VAL_DATE_CUST);
        DBG('global.application_date--->' || GLOBAL.APPLICATION_DATE);
        IF L_REJ_REC.VAL_DATE_CUST >= GLOBAL.APPLICATION_DATE THEN
          DBG('Funds are in uncollected. Need to move from uncollected before passing RETN event');
          IF NOT ACPKS_EOD.FN_DRPUNCOL(L_REJ_REC.ACC_BRANCH,
                                       L_REJ_REC.BEN_ACCOUNT,
                                       L_REJ_REC.REFERENCE_NO,
                                       P_ERR_CODE,
                                       'N') THEN
            DBG('Failed in fn_drpUncol');
          END IF;
        END IF;
        DBG('Calling function FN_INWARD_RETURN_ENT for posting RETN entries for Inward returns');
        IF NOT FN_INWARD_RETURN_ENT(L_REJ_REC,
                                    L_XREF,
                                    L_BRANCH_CODE,
                                    L_CHQ_RETURN_AMT,
                                    L_REJECT_CODE,
                                    L_TOT_CHG_AMT,
                                    P_ERR_CODE,
                                    P_ERR_PARAM,
                                    P_ONLINE_AUTH) THEN
          DBG('Failed in Accounting Reversal');
          RETURN FALSE;
        END IF;
      END IF;
      DBG('l_reject_code--->>>' || L_REJECT_CODE);
      L_TB_REJREASON(1) := L_REJECT_CODE;
    
      DBG('l_rej_rec.Acc_Branch ----->>>>>' || L_REJ_REC.ACC_BRANCH);
      DBG('l_rej_rec.Ben_Account ----->>>>>' || L_REJ_REC.BEN_ACCOUNT);
      DBG('l_rej_rec.Direction-->' || L_REJ_REC.DIRECTION);
      DBG('l_rej_rec.Rem_Account-->' || L_REJ_REC.REM_ACCOUNT);
      DBG('l_rej_rec.Ben_Account-->' || L_REJ_REC.BEN_ACCOUNT);
    
      IF L_REJ_REC.DIRECTION = 'I' THEN
        L_REJECT_ACCOUNT := L_REJ_REC.REM_ACCOUNT;
      ELSE
        L_REJECT_ACCOUNT := L_REJ_REC.BEN_ACCOUNT;
      END IF;
      DBG('l_reject_account-->' || L_REJECT_ACCOUNT);
    
      IF NOT CGPKS_CGDCLGDT_KERNEL.FN_CHG_REJECT(L_TB_REJREASON,
                                                 L_REJ_REC.ACC_BRANCH,
                                                 L_REJECT_ACCOUNT,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAM) THEN
        DBG('Error in calculating the Charge for Reject Reason');
      END IF;
      DBG('Charge entry done');
    END IF;
    DBG('event_seq_no >>>' || L_REJ_REC.EVENT_SEQ_NO);
    L_REJ_REC.STATUS := 'REJR';
    SELECT EVENT_SEQ_NO
      INTO L_EVENT_SEQ_NO
      FROM CSTBS_CLEARING_MASTER
     WHERE REFERENCE_NO = L_REJ_REC.REFERENCE_NO;
  
    DEBUG.PR_DEBUG('CG', 'Last event seq no was ' || L_EVENT_SEQ_NO);
  
    L_EVENT_SEQ_NO := L_EVENT_SEQ_NO + 1;
    DBG('l_remarks-->' || L_REMARKS);
    IF P_ONLINE_AUTH = 'Y' THEN
    
      UPDATE CSTBS_CLEARING_MASTER
         SET REJECT_REASON    = L_REJECT_REASON,
             STATUS           = L_REJ_REC.STATUS,
             REJECT_CODE      = L_REJECT_CODE,
             REMARKS          = L_REMARKS,
             CHEQUE_RETN_AMT  = NVL(L_CHQ_RETURN_AMT, 0),
             PRESENT_BANK_CHG = NVL(L_TOT_CHG_AMT, 0)
       WHERE REFERENCE_NO = L_REJ_REC.REFERENCE_NO;
      DEBUG.PR_DEBUG('CG', 'Reverse 2');
    
      UPDATE IFTB_CLEARING_UPLOAD
         SET REJ_REASON_CODE  = L_REJECT_CODE,
             STATUS           = L_REJ_REC.STATUS,
             REMARKS          = L_REMARKS,
             CHEQUE_RETN_AMT  = NVL(L_CHQ_RETURN_AMT, 0),
             PRESENT_BANK_CHG = NVL(L_TOT_CHG_AMT, 0)
      
       WHERE FCCREF = L_REJ_REC.REFERENCE_NO;
    
      DEBUG.PR_DEBUG('CG',
                     'Going to insert cstbs_clearing_details2 --> ' ||
                     G_EVENT_SEQ);
      IF L_REJ_REC.MODULE_CODE NOT IN ('PD') THEN
        BEGIN
          DBG('g_event_seq' || G_EVENT_SEQ || '~' || L_REJ_REC.XREF);
          INSERT INTO CSTBS_CLEARING_DETAILS
            (DIRECTION,
             PRODUCT_CODE,
             TXN_BRANCH,
             END_POINT,
             REFERENCE_NO,
             REM_ACCOUNT,
             BEN_ACCOUNT,
             ACC_BRANCH,
             INSTRUMENT_NO_1,
             BRANCH_CODE,
             SECTOR_CODE,
             XREF,
             EVENT_SEQ_NO,
             REMARKS,
             STATUS,
             ENTRY_NO)
          VALUES
            (L_REJ_REC.DIRECTION,
             L_REJ_REC.PRODUCT_CODE,
             L_REJ_REC.TXN_BRANCH,
             L_REJ_REC.END_POINT,
             L_REJ_REC.REFERENCE_NO,
             L_REJ_REC.REM_ACCOUNT,
             L_REJ_REC.BEN_ACCOUNT,
             L_REJ_REC.ACC_BRANCH,
             L_REJ_REC.INSTRUMENT_NO_1,
             L_REJ_REC.BRANCH_CODE,
             L_REJ_REC.SECTOR_CODE,
             L_REJ_REC.XREF,
             G_EVENT_SEQ,
             L_REMARKS,
             L_REJ_REC.STATUS,
             L_REJ_REC.ENTRY_NO + 1);
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CG',
                           'problem in inserting into cstbs_clearing_details3' ||
                           SQLERRM);
            RETURN FALSE;
        END;
      END IF;
    END IF;
    IF L_REJ_REC.NOTIFY_RETN_TO_MODULE = 'Y' THEN
      BEGIN
        UPDATE CGTB_MODULE_CHQ_STATUS
           SET STATUS = 'R'
         WHERE REFERENCE_NO = L_REJ_REC.REFERENCE_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('cspks_clg_serv ==> ' || 'This transaction does not exist');
          P_ERR_CODE := 'CG-CL0014';
          RETURN FALSE;
      END;
    END IF;
    P_XREF   := L_REJ_REC.XREF;
    P_FCCREF := L_REJ_REC.REFERENCE_NO;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CG',
                     'Exception in fn_process_Host_Retn_Revr...' || SQLERRM);
      P_ERR_CODE := 'CG-CL0001';
      OVPKS.PR_APPENDTBL('CG-CL0001',
                         'Exception in fn_process_Host_Retn_Revr');
      RETURN FALSE;
  END FN_PROCESS_HOST_RETURN;

BEGIN

  IF NOT GLOBALS_FRC.FN_GET_BANK_REC_WRP(L_ERR_CODE, L_ERR_PARAMS) THEN
    DEBUG.PR_DEBUG('AC', 'Failed in the FRC function..');
  ELSE
    DEBUG.PR_DEBUG('AC', 'Success from FRC..');
  END IF;

  G_CLG_BANK_CD  := GLOBALS_FRC.G_TBL_STTM_BANK_REC.CLG_BANK_CD;
  G_ROUTING_MASK := GLOBALS_FRC.G_TBL_STTM_BANK_REC.ROUTING_MASK;

  PKG_ADDON_BRN := '*';
  PKG_PROD      := '*';
  PKG_BRN       := '*';

END CSPKS_CLG_SERV;
/