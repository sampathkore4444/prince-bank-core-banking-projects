CREATE OR REPLACE TRIGGER STTR_CYRATES_SV_DETAIL_LOG 
  AFTER INSERT OR UPDATE ON CYTM_RATES
  REFERENCING new AS new old AS old
  FOR EACH ROW
     WHEN (((NEW.BUY_RATE<>OLD.BUY_RATE) or
          (NEW.MID_RATE<>OLD.MID_RATE) or
          (NEW.SALE_RATE<>OLD.SALE_RATE) or
          (NEW.RATE_SERIAL<>OLD.RATE_SERIAL)) AND
          (nvl(NEW.INT_AUTH_STAT,'N')='A') and
          (NEW.RATE_TYPE='COMM') AND  --Commercial exchnage rate changes changed from STANDARD to COMM
          (NEW.BRANCH_CODE='000') AND
          (NEW.CCY1 = 'USD' AND NEW.CCY2 = 'KHR')) DECLARE
  L_OPERATION VARCHAR2(10);
  L_SYS_DATE  DATE;
BEGIN

      debug.pr_debug('CY','came IN TO Trigger STTR_CYRATES_SV_DETAIL_LOG ');

        L_OPERATION:='UPDATE';
      debug.pr_debug('CY','L_OPERATION '||L_OPERATION);

      SELECT TODAY INTO L_SYS_DATE FROM STTM_DATES WHERE BRANCH_CODE IN (SELECT HO_BRANCH FROM STTM_BANK);
      INSERT INTO IFTB_SV_CDC_CUSTOM VALUES
      (sv_sequence.nextval, L_SYS_DATE, 'CYTM_RATES', 'STTR_CYRATES_SV_DETAIL_LOG',
       (:NEW.BRANCH_CODE||'~'||:NEW.CCY1||'~'||:NEW.CCY2||'~'||:NEW.RATE_TYPE), L_OPERATION, SYSDATE,NULL,NULL,'I',null);

      debug.pr_debug('CY','came out of Trigger STTR_CYRATES_SV_DETAIL_LOG ');

EXCEPTION
  WHEN OTHERS THEN
    NULL;
    debug.pr_debug('AC','Error while inserting of sv table ' || SQLERRM);
  --RAISE_APPLICATION_ERROR(-20001, 'An error was encountered while updation of aml log- ' || SQLCODE || ' -ERROR- ' || SQLERRM);
END STTR_CYRATES_SV_DETAIL_LOG;

/
ALTER TRIGGER "P1FCHPRFM"."STTR_CYRATES_SV_DETAIL_LOG" ENABLE;