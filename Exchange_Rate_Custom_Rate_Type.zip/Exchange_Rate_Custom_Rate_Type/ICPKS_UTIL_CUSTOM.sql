CREATE OR REPLACE PACKAGE BODY icpks_util_custom IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'icpks_util_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('IC', L_MSG);
  END DBG;
  PROCEDURE PR_GET_DAYS(D1       DATE,
                        D2       DATE,
                        INT_METH VARCHAR2,
                        D        OUT NUMBER,
                        M        OUT NUMBER,
                        Y        OUT NUMBER,

                        P_ORIG_STARTDT IN DATE DEFAULT NULL,
                        P_ORIG_ENDDT   IN DATE DEFAULT NULL,

                        P_FN_CALL_ID     NUMBER,
                        P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Inside icpks_util_custom.PR_GET_DAYS ...');

    DBG('Returning Successfully from icpks_util_custom.PR_GET_DAYS..');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of icpks_util_custom.PR_GET_DAYS ..');
      DBG(SQLERRM);
  END PR_GET_DAYS;

  FUNCTION FN_GET_INT_AMT_ROUNDED(P_RULE_ID        IN ICTM_RULE_FRM.RULE_ID%TYPE,
                                  P_FRM_NO         IN ICTM_RULE_FRM.FRM_NO%TYPE,
                                  P_ACC            IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                  P_PROD           IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                                  P_UPDATE_UTIL    IN BOOLEAN,
                                  P_INT_AMOUNT     IN OUT ACTBS_DAILY_LOG.LCY_AMOUNT%TYPE,
                                  P_FN_CALL_ID     NUMBER,
                                  P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside icpks_util_custom.FN_GET_INT_AMT_ROUNDED ...');

    DBG('Returning Successfully from icpks_util_custom.FN_GET_INT_AMT_ROUNDED..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of icpks_util_custom.FN_GET_INT_AMT_ROUNDED ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_GET_INT_AMT_ROUNDED;

  FUNCTION FN_AMT1_TO_AMT2(P_BRN            VARCHAR2,
                           P_CCY1           VARCHAR2,
                           P_CCY2           VARCHAR2,
                           P_AMT1           NUMBER,
                           P_ROUND          VARCHAR2,
                           P_AMT2           IN OUT NUMBER,
                           P_XRATE          IN OUT NUMBER,
                           P_EMSG           IN OUT VARCHAR2,
                           P_FN_CALL_ID     NUMBER,
                           P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside icpks_util_custom.FN_AMT1_TO_AMT2 ...');
    
    --sampath starts
    P_XRATE := 4020;
    --sampath ends

    DBG('Returning Successfully from icpks_util_custom.FN_AMT1_TO_AMT2..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of icpks_util_custom.FN_AMT1_TO_AMT2 ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_AMT1_TO_AMT2;

  FUNCTION GETRP_RATE_AMT(P_RP_FLAG        IN VARCHAR2,
                          P_BRN            IN VARCHAR2,
                          P_ACC            IN VARCHAR2,
                          P_PROD           IN VARCHAR2,
                          P_COMP           IN VARCHAR2,
                          P_CCY            IN VARCHAR2,
                          P_RATE_AMT       IN NUMBER,
                          P_FN_CALL_ID     NUMBER,
                          P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN NUMBER IS
    L_RET_VAL NUMBER;
  BEGIN
    DBG('Inside icpks_util_custom.GETRP_RATE_AMT ...');

    DBG('Returning Successfully from icpks_util_custom.GETRP_RATE_AMT..');
    RETURN NVL(L_RET_VAL, 0);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of icpks_util_custom.GETRP_RATE_AMT ..');
      DBG(SQLERRM);
      RETURN NVL(P_RATE_AMT, 0);
  END GETRP_RATE_AMT;

  FUNCTION FN_GET_TAX_AMT_ROUNDED(P_RULE_ID        IN ICTM_RULE_FRM.RULE_ID%TYPE,
                                  P_FRM_NO         IN ICTM_RULE_FRM.FRM_NO%TYPE,
                                  P_ACC            IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                  P_PROD           IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                                  P_TAX_AMOUNT     IN OUT NUMBER,
                                  P_FN_CALL_ID     NUMBER,
                                  P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside icpks_util_custom.FN_GET_TAX_AMT_ROUNDED ...');

    DBG('Returning Successfully from icpks_util_custom.FN_GET_TAX_AMT_ROUNDED..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of icpks_util_custom.FN_GET_TAX_AMT_ROUNDED ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_GET_TAX_AMT_ROUNDED;

END ICPKS_UTIL_CUSTOM;
