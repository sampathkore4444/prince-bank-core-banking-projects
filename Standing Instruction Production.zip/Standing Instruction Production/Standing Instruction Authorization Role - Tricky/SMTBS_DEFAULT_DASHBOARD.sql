insert into SMTBS_DEFAULT_DASHBOARD (DB_FUNCTIONID)
values ('ITSINTRD');

insert into SMTBS_DEFAULT_DASHBOARD (DB_FUNCTIONID)
values ('SISTRAUT'); --IMPORTANT for si auth otherwise you get an error when you click on auth of SIDTRONL

insert into SMTBS_DEFAULT_DASHBOARD (DB_FUNCTIONID)
values ('SVDCONVW');

insert into SMTBS_DEFAULT_DASHBOARD (DB_FUNCTIONID)
values ('SVDIMGVW');

COMMIT;
