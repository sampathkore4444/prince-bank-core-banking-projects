
update smtb_menu set tank_modifications='Y' WHERE  FUNCTION_ID = 'STDCIF';