CREATE OR REPLACE VIEW STVW_ACLASS_CATEGORIES AS
((
/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © 2001 - 2009 Oracle and/or its affiliates.  All rights reserved.
**
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
**
**
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
-----------------------------------------------------------------------------------------*/
SELECT AC.account_class
 	, CAT.cust_cat
 FROM	sttms_account_class AC
 	, sttms_customer_cat CAT
 	, sttms_accls_cat_restr ACCAT
 WHERE	AC.cuscat_list = 'D'
 AND	ACCAT.account_class = AC.account_class
 AND	AC.auth_stat = 'A'
 AND	AC.record_stat = 'O'
 AND	CAT.auth_stat = 'A'
 AND	CAT.record_stat = 'O'
 MINUS
 SELECT AC.account_class
 	, ACCAT.cust_cat
 FROM sttms_account_class AC
 	, sttms_accls_cat_restr ACCAT
 WHERE AC.cuscat_list = 'D'
 AND	 ACCAT.account_class = AC.account_class
 )
 UNION
 SELECT AC.account_class
 	, ACCAT.cust_cat
 FROM sttms_account_class AC
 	, sttms_accls_cat_restr ACCAT
 WHERE AC.cuscat_list = 'A'
 AND	 ACCAT.account_class = AC.account_class
 )
 UNION
 SELECT AC.account_class
 	, CAT.cust_cat
 FROM sttms_account_class AC
 	, sttms_customer_cat CAT
 WHERE AC.account_class NOT IN
 	(
	SELECT	account_class
	FROM	sttms_accls_cat_restr where account_class <> 'EA01' --sampath added where condition
	)
 AND AC.cuscat_list = 'D'
 AND CAT.auth_stat = 'A'
 AND CAT.record_stat = 'O'
 AND AC.auth_stat = 'A'
 AND AC.record_stat = 'O'
;
