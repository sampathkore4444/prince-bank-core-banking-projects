CREATE OR REPLACE PACKAGE BODY Stpks_Stdcif_Utils_0 AS

  G_LIABILITY_LINKED BOOLEAN := FALSE;
  G_STDCIF           STPKS_STDCIF_MAIN.TY_STDCIF;

  G_WRK_STDCIF  STPKS_STDCIF_MAIN.TY_STDCIF;
  G_PREV_STDCIF STPKS_STDCIF_MAIN.TY_STDCIF;

  G_SKIP_KERNEL  BOOLEAN := FALSE;
  G_SKIP_CLUSTER BOOLEAN := FALSE;
  G_SKIP_CUSTOM  BOOLEAN := FALSE;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'stpks_stdcif_utils_0 ==>' || P_MSG;
    DEBUG.PR_DEBUG('ST', L_MSG);
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);

  END PR_LOG_ERROR;
  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    DBG('In Pr_Skip_Handler..');

    STPKS_STDCIF_UTILS_0_CLUSTER.PR_SKIP_HANDLER(P_STAGE);
    STPKS_STDCIF_UTILS_0_CUSTOM.PR_SKIP_HANDLER(P_STAGE);

  END PR_SKIP_HANDLER;

  PROCEDURE PR_SET_SKIP_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := TRUE;
  END PR_SET_SKIP_KERNEL;

  PROCEDURE PR_SET_ACTIVATE_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := FALSE;
  END PR_SET_ACTIVATE_KERNEL;

  PROCEDURE PR_SET_SKIP_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := TRUE;
  END PR_SET_SKIP_CLUSTER;

  PROCEDURE PR_SET_ACTIVATE_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := FALSE;
  END PR_SET_ACTIVATE_CLUSTER;

  FUNCTION FN_SKIP_CUSTOM RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_KERNEL, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CUSTOM;
    END IF;
  END FN_SKIP_CUSTOM;

  FUNCTION FN_SKIP_KERNEL RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_KERNEL;
    END IF;
  END FN_SKIP_KERNEL;

  FUNCTION FN_SKIP_CLUSTER RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CLUSTER THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CLUSTER;
    END IF;
  END FN_SKIP_CLUSTER;

  FUNCTION FN_GENERATECIF(P_FUNCTION_ID IN VARCHAR2,
                          P_CUSTNO      IN OUT STTMS_CUSTOMER.CUSTOMER_NO%TYPE,
                          P_BRANCH      IN OUT STTMS_BRANCH.BRANCH_CODE%TYPE,
                          P_ERR_CODE    IN OUT VARCHAR2,
                          P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_START_CUSTOMER_NO STTMS_CUSTOMER_PARAM.START_CUSTOMER_NO%TYPE;
    L_END_CUSTOMER_NO   STTMS_CUSTOMER_PARAM.END_CUSTOMER_NO%TYPE;

    CNTN        NUMBER;
    L_SEQ_NO    VARCHAR2(20);
    L_REF_NO    VARCHAR2(20);
    L_SERV_STAT VARCHAR2(10);

    L_CIF_MASK             STTMS_BANK.CIF_MASK%TYPE;
    L_MASK                 NUMBER;
    L_RESULTANT_ERROR_TYPE VARCHAR2(32767) := 'I';
  BEGIN

    PR_SKIP_HANDLER('PRE_GENERATECIF');
    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CUSTOM THEN
      DBG('Calling  Stpks_Stdcif_Utils_0_Custom.Fn_Pre_Generatecif..');
      IF NOT STPKS_STDCIF_UTILS_0_CUSTOM.FN_PRE_GENERATECIF(P_FUNCTION_ID,
                                                            P_CUSTNO,
                                                            P_BRANCH,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
        DBG('Failed in  Stpks_Stdcif_Utils_0_Custom.Fn_Pre_Generatecif..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CLUSTER THEN
      DBG('Calling  Stpks_Stdcif_Utils_0_Cluster.Fn_Pre_Generatecif..');
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_PRE_GENERATECIF(P_FUNCTION_ID,
                                                          P_CUSTNO,
                                                          P_BRANCH,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
        DBG('Failed in  Stpks_Stdcif_Utils_0_Cluster.Fn_Pre_Generatecif..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_KERNEL THEN

      DBG('Now Inside fn_GenerateCIF');

      L_SEQ_NO    := GWPKSS_SERVICE_ROUTER.G_POSS_SEQNO;
      L_SERV_STAT := GWPKSS_SERVICE_ROUTER.G_POSS_STATUS;

      DEBUG.PR_DEBUG('TR', 'Server Status' || L_SEQ_NO);
      DEBUG.PR_DEBUG('TR', 'Server Status' || L_SERV_STAT);
      IF L_SEQ_NO IS NOT NULL THEN

        TRPKS.PR_POP_REFNO(L_SEQ_NO, L_REF_NO);
        IF L_REF_NO IS NOT NULL THEN

          P_CUSTNO := L_REF_NO;

        END IF;

      ELSE
        DBG('INSIDE ELSE');

        BEGIN
          SELECT LENGTH(CIF_MASK), CIF_MASK
            INTO L_MASK, L_CIF_MASK
            FROM STTMS_BANK;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_CODE   := 'CS-10000';
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         P_ERR_CODE,
                         P_ERR_PARAMS);
            RETURN FALSE;
        END;

        IF NOT STPKS_ACCGEN.FN_GETUNUSEDCUSTNO(P_BRANCH, P_CUSTNO) THEN

          DBG('Local Branch is ' || P_BRANCH);

          L_RESULTANT_ERROR_TYPE := CSPKS_REQ_UTILS.FN_SCAN_ERROR_LIST;
          IF L_RESULTANT_ERROR_TYPE = 'E' THEN
            RETURN FALSE;
          END IF;

          IF INSTR(L_CIF_MASK, 'bbb') = 0 THEN

            SELECT CESQ_CIF_ID.NEXTVAL INTO P_CUSTNO FROM DUAL;
            DBG('p_custno: ' || P_CUSTNO);
            IF LENGTH(P_CUSTNO) > L_MASK THEN
              DBG('Append Error: ST-SPCL-16 - Customer Number auto generated exeeds the mask maintained at the Bank Level.');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-SPCL-16', NULL);
              RETURN FALSE;
            END IF;
            DBG('Next Sequence number with in the bank level mask--> Proceed');
            P_CUSTNO := LPAD(TO_CHAR(P_CUSTNO), L_MASK, '0');
            DBG('p_custno HERE: ' || P_CUSTNO);

            DBG('p_cust_no: ' || P_CUSTNO);
            IF NOT STPKS_STDCIF_UTILS_0.FN_CHK_VIP_CUST(P_FUNCTION_ID,
                                                        P_CUSTNO,
                                                        'SEQ',
                                                        P_BRANCH,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
              DBG('Failed in validating VIP customer, Might fall in VIP Range');
            END IF;
            DBG('p_cust_no: ' || P_CUSTNO);

            P_CUSTNO := LPAD(TO_CHAR(P_CUSTNO), L_MASK, '0');
            DBG('p_custno HERE: ' || P_CUSTNO);

            IF NOT
                CSPKS_FEATURE.FN_INSTALLED('CIF_MASK', GLOBAL.CURRENT_BRANCH) THEN
              DBG('24472513 going to return true');
              RETURN TRUE;
            END IF;

            DBG('#26160483 return true commented');

            DBG('24472513: p_custno is ' || P_CUSTNO);
          END IF;

          BEGIN

            SELECT START_CUSTOMER_NO, END_CUSTOMER_NO
              INTO L_START_CUSTOMER_NO, L_END_CUSTOMER_NO

              FROM STTMS_CUSTOMER_PARAM
             WHERE BRANCH_CODE = P_BRANCH;
          EXCEPTION
            WHEN OTHERS THEN
              L_START_CUSTOMER_NO := 0;
              L_END_CUSTOMER_NO   := 0;
          END;
          DBG('Start cif no: ' || L_START_CUSTOMER_NO || ' End cif no: ' ||
              L_END_CUSTOMER_NO);

          DBG('No unused customer numbers...going to generate the new cust number...');
          IF L_START_CUSTOMER_NO <> 0 AND L_END_CUSTOMER_NO <> 0 THEN
            DBG('Calling fn_generate_cif with p_Custno~' || P_CUSTNO);

            IF NOT STPKS_ACCGEN.FN_GENERATE_CIF_RUNNO(P_CUSTNO,
                                                      P_BRANCH,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN

              DBG('Could not generate CIF nos. automatically');

              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);

              RETURN FALSE;

              DBG('#28554249 p_custno..' || P_CUSTNO);
            END IF;
          ELSE

            SELECT P_BRANCH ||
                   LPAD(TO_CHAR(CESQ_CIF_ID.NEXTVAL), L_MASK - 3, '0')
              INTO P_CUSTNO
              FROM DUAL;

            DBG('p_cust_no: ' || P_CUSTNO);
            IF NOT STPKS_STDCIF_UTILS_0.FN_CHK_VIP_CUST(P_FUNCTION_ID,
                                                        P_CUSTNO,
                                                        'SEQ',
                                                        P_BRANCH,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
              DBG('Failed in validating VIP customer, Might fall in VIP Range');
            END IF;
            DBG('p_cust_no: ' || P_CUSTNO);
            IF LENGTH(P_CUSTNO) < L_MASK THEN

              P_CUSTNO := P_BRANCH || LPAD(P_CUSTNO, L_MASK - 3, '0');

            END IF;

          END IF;

        END IF;

      END IF;

      DBG('Calling stpkss_accgen.fn_update_customer_srno');
      DBG('custno before registration' || P_CUSTNO);

      IF L_SERV_STAT = 'POSS' THEN

        TRPKS.PR_PUSH_REFNO(L_SEQ_NO, P_CUSTNO);
      END IF;

      DBG('Generated CIF is :' || NVL(P_CUSTNO, 'NULL'));
      DBG('Returning success from Fn_Generatecif..');

    END IF;
    PR_SKIP_HANDLER('POST_GENERATECIF');
    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CLUSTER THEN
      DBG('Calling  Stpks_Stdcif_Utils_0_Cluster.Fn_Post_Generatecif..');
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_POST_GENERATECIF(P_FUNCTION_ID,
                                                           P_CUSTNO,
                                                           P_BRANCH,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
        DBG('Failed in  Stpks_Stdcif_Utils_0_Cluster.Fn_Post_Generatecif..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CUSTOM THEN
      DBG('Calling  Stpks_Stdcif_Utils_0_Custom.Fn_Post_Generatecif..');
      IF NOT
          STPKS_STDCIF_UTILS_0_CUSTOM.FN_POST_GENERATECIF(P_FUNCTION_ID,
                                                          P_CUSTNO,
                                                          P_BRANCH,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
        DBG('Failed in  Stpks_Stdcif_Utils_0_Custom.Fn_Post_Generatecif..');
        RETURN FALSE;
      END IF;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In exception of CIF Generation' || SQLERRM);
      RETURN FALSE;
  END FN_GENERATECIF;

  FUNCTION FN_CHK_VIP_CUST(P_FUNCTION_ID IN VARCHAR2,
                           P_CUST_NO     IN OUT STTMS_CUSTOMER.CUSTOMER_NO%TYPE,
                           P_VIP_CHK     IN STTMS_CUSTOMER.SPECIAL_CUST%TYPE,
                           P_BRANCH      IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                           P_ERR_CODE    IN OUT VARCHAR2,
                           P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_MASK          STTMS_BANK.CIF_MASK%TYPE;
    L_ATGENCIF      STTMS_BANK.AUTO_GEN_CIF%TYPE;
    L_CUST_NUMERIC  STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
    L_CUST_IN_RANGE BOOLEAN := FALSE;
    L_START_RANGE   STTMS_CUST_RANGE_DETAIL.START_RANGE%TYPE;
    L_END_RANGE     STTMS_CUST_RANGE_DETAIL.START_RANGE%TYPE;
    L_BRANCH        STTMS_BRANCH.BRANCH_CODE%TYPE;

    L_CUST_SEQ STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
    L_NMASK    STTMS_BANK.CIF_MASK%TYPE;

    CURSOR CIF_RANGE IS
      SELECT RD.*
        FROM STTMS_CUST_RANGE_MASTER RM, STTMS_CUST_RANGE_DETAIL RD
       WHERE RM.BRANCH_CODE = RD.BRANCH_CODE
         AND RM.RANGE_TYPE = RD.RANGE_TYPE
         AND RM.RANGE_TYPE = 'C'
         AND RM.RECORD_STAT = 'O'
         AND RM.ONCE_AUTH = 'Y'
       ORDER BY END_RANGE;

    FUNCTION FN_CHECK_EXISTS(P_CUST_NO IN VARCHAR2) RETURN BOOLEAN IS
      L_EXISTS NUMBER := 0;
    BEGIN
      DBG('fn_check_exists: IN fn_check_exists...Private Function');
      BEGIN
        DBG('fn_check_exists: Checking for the customer existence: ' ||
            P_CUST_NO);
        SELECT COUNT(1)
          INTO L_EXISTS
          FROM STTMS_CUSTOMER
         WHERE CUSTOMER_NO = P_CUST_NO
           AND AUTH_STAT IN ('A', 'U');
        DBG('l_exists=' || L_EXISTS);
        IF L_EXISTS = 0 THEN
          SELECT COUNT(1)
            INTO L_EXISTS
            FROM STTBS_RECORD_LOG
           WHERE KEY_ID = '~STTM_CUSTOMER~' || P_CUST_NO || '~'
             AND AUTH_STAT = 'U'
             AND FUNCTION_ID IN ('STDCIF', 'STDCIFAD');
        END IF;
        DBG('l_exists=' || L_EXISTS);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Error occuered in fn_check_exists.. ' || SQLERRM ||
              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      END;
      IF L_EXISTS <> 0 THEN
        DBG('Returning FALSE from fn_check_exists as the Given Customer Number is already Exists in the System.');
        RETURN FALSE;
      ELSE
        DBG('returning true...It is Valid Customer');
        RETURN TRUE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In WOT of fn_check_exists: SQLERRM: ' || SQLERRM ||
            DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        DBG('dbms_utility.format_error_backtrace: ' ||
            DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN FALSE;
    END FN_CHECK_EXISTS;

  BEGIN

    DBG('Inside Stpks_Stdcif_Utils_0.fn_chk_vip_cust function ');
    L_CUST_IN_RANGE := FALSE;
    SELECT CIF_MASK, AUTO_GEN_CIF INTO L_MASK, L_ATGENCIF FROM STTMS_BANK;
    DBG('l_mask     -->' || L_MASK);
    DBG('l_atgencif -->' || L_ATGENCIF);
    DBG('p_vip_chk  -->' || P_VIP_CHK);
    DBG('p_cust_no  -->' || P_CUST_NO);
    DBG('p_Branch   -->' || P_BRANCH);
    L_NMASK := SUBSTR(L_MASK, INSTR(L_MASK, 'n'), LENGTH(L_MASK));

    IF P_CUST_NO IS NULL THEN
      DBG('Append Error: ST-SPCL-13 - Customer Number cannot be blank');
      P_ERR_CODE   := 'ST-SPCL-13';
      P_ERR_PARAMS := '';
      RETURN FALSE;

    ELSIF P_CUST_NO IS NOT NULL THEN
      DBG('Customer Number is not blank');
      DBG('Need to Validate whether the Numeric Part of Customer Number is In VIP range');
      DBG('Check whether VIP CIF Range is Maintained For ALL Branch');

      BEGIN
        SELECT SUBSTR(P_CUST_NO, INSTR(L_MASK, 'n'))
          INTO L_CUST_NUMERIC
          FROM DUAL;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In WOT while getting Numeric part of Customer mask SQLERRM: ' ||
              SQLERRM);
      END;
      L_CUST_SEQ := L_CUST_NUMERIC;
      DBG('Numeric part of Customer no l_cust_numeric is:-->' ||
          L_CUST_NUMERIC);
      DBG('Loop Through VIP CIF Range Maintained For the l_branch: ' ||
          L_BRANCH);

      IF NVL(P_VIP_CHK, 'N') <> 'Y' THEN
        FOR CIF_EXP IN CIF_RANGE LOOP
          DBG('VIP: start_range -->' || CIF_EXP.START_RANGE);
          DBG('VIP: end_range   -->' || CIF_EXP.END_RANGE);
          IF L_CUST_NUMERIC BETWEEN CIF_EXP.START_RANGE AND
             CIF_EXP.END_RANGE THEN
            DBG('VIP: Setting the Variable l_cust_in_range to TRUE and EXIT Loop');
            L_CUST_IN_RANGE := TRUE;
            EXIT;
          END IF;
        END LOOP;
      END IF;

      IF NVL(P_VIP_CHK, 'N') = 'Y' THEN
        DBG('p_vip_chk Yes means It is Special Customer and Need to validate whether it is in VIP range and not used already');

        L_CUST_IN_RANGE := FALSE;
        FOR I IN (SELECT RD.*
                    FROM STTMS_CUST_RANGE_MASTER RM,
                         STTMS_CUST_RANGE_DETAIL RD
                   WHERE RM.BRANCH_CODE = RD.BRANCH_CODE
                     AND RM.RANGE_TYPE = RD.RANGE_TYPE
                     AND RM.RANGE_TYPE = 'C'
                     AND RM.RECORD_STAT = 'O'
                     AND RM.ONCE_AUTH = 'Y'
                     AND RM.BRANCH_CODE = P_BRANCH) LOOP

          IF L_CUST_NUMERIC BETWEEN I.START_RANGE AND I.END_RANGE THEN
            L_CUST_IN_RANGE := TRUE;
            DBG('VIP: Setting the Variable l_cust_in_range to TRUE and EXIT Loop');
            EXIT;
          END IF;
        END LOOP;

        IF NOT L_CUST_IN_RANGE THEN
          DBG('Append Error: ST-SPCL-12 - Customer Number entered is not a valid Special Customer Number');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-SPCL-12', '');
          RETURN FALSE;
        ELSIF NOT FN_CHECK_EXISTS(P_CUST_NO) THEN
          DBG('Append Error: ST-SPCL-15 - Customer Number entered under special range is already used');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-SPCL-15', '');
          RETURN FALSE;
        END IF;
      ELSE
        DBG('Not a VIP CIF. Need to show error if the Given Customer Number is In VIP range');
        IF L_CUST_IN_RANGE THEN
          DBG('Given Customer Number is inside the VIP CIF Range');
          IF L_ATGENCIF = 'N' THEN
            DBG('Auto Gen CIF is No');
            DBG('Append Error: ST-SPCL-14 - Customer Number Entered $1 is in a reserved Special Number Range, Start No $1, End Number $2.');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-SPCL-14',
                         P_CUST_NO || '~' || L_START_RANGE || '~' ||
                         L_END_RANGE);
            DBG('Returning False as the Customer Number Entered is in a reserved Special Number Range');
            RETURN FALSE;
          ELSE
            DBG('Auto Gen CIF is Yes, So Skip to End_Range+1');
            BEGIN
              IF P_VIP_CHK = 'SEQ' THEN
                DBG('Dup Chk 1-1');

                IF LENGTH(L_CUST_NUMERIC) > LENGTH(L_NMASK)

                 THEN
                  DBG('Append Error: ST-SPCL-16 - Customer Number auto generated exeeds the mask maintained at the Bank Level.');
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               'ST-SPCL-16',
                               NULL);
                  RETURN FALSE;

                ELSE
                  DBG('Next Sequence number with in the bank level mask-->');

                  EXECUTE IMMEDIATE 'ALTER SEQUENCE cesq_cif_id INCREMENT by ' ||
                                    (L_END_RANGE - L_CUST_SEQ + 1);
                  SELECT TO_CHAR(CESQ_CIF_ID.NEXTVAL)
                    INTO P_CUST_NO
                    FROM DUAL;
                  DBG('p_cust_no-->' || L_CUST_SEQ);

                  EXECUTE IMMEDIATE 'alter SEQUENCE cesq_cif_id increment by 1';
                END IF;
              ELSIF P_VIP_CHK = 'BRANCH' THEN
                DBG('Dup Chk 1-2');

                P_CUST_NO := L_CUST_SEQ + (L_END_RANGE - L_CUST_SEQ);

                DBG('p_cust_no-->' || P_CUST_NO);
              END IF;

            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in SEQUENCE ALTER SQLERRM: ' || SQLERRM);
            END;
          END IF;
        END IF;
      END IF;
    END IF;
    DBG('Returning TRUE from Stpks_Stdcif_Utils_0.fn_chk_vip_Cust');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT exception of Stpks_Stdcif_Utils_0.fn_chk_vip_Cust: SQLERRM: ' ||
          SQLERRM);
      RETURN FALSE;
  END FN_CHK_VIP_CUST;

  FUNCTION FN_SSN_VALID(P_FUNCTION_ID IN VARCHAR2,
                        P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                        P_ERRS        OUT ERTB_MSGS.ERR_CODE%TYPE,
                        P_PRMS        OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS

    L_CNT      NUMBER(5) := 0;
    L_SSN_MASK STTM_CUSTOMER.SSN%TYPE;
  BEGIN

    DBG('Just entered fn_ssn_valid, customer_type: ' ||
        P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE);

    IF P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN

      DBG('Entering check for SSN');
      DBG('ssn - ' || P_CUST_REC.V_STTMS_CUSTOMER.SSN);

      IF P_CUST_REC.V_STTMS_CUSTOMER.SSN IS NULL THEN

        NULL;

      ELSE

        DBG('SSN: ' || P_CUST_REC.V_STTMS_CUSTOMER.SSN);

        DBG('24367801##p_Cust_Rec.v_Sttms_Customer.Ssn--> ' ||
            P_CUST_REC.V_STTMS_CUSTOMER.SSN);
        BEGIN

          L_SSN_MASK := CSPKSS_OS_PARAM.GET_PARAM_VAL('SSN_MASK_FORMAT');

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_SSN_MASK := 'nnn-nn-nnnn';
            DBG('Taking default SSN mask ' || L_SSN_MASK);
        END;
        DBG('l_ssn_mask--> ' || L_SSN_MASK);

        SELECT COUNT(*)
          INTO L_CNT
          FROM STTMS_CUSTOMER
         WHERE SSN = P_CUST_REC.V_STTMS_CUSTOMER.SSN
           AND CUSTOMER_NO <> P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;

        IF L_CNT = 0 THEN

          DBG('calling stpks_stdcif_utils_1.Fn_Ssn_Format_Validation..');
          IF NOT
              STPKS_STDCIF_UTILS_1.FN_SSN_FORMAT_VALIDATION(P_CUST_REC.V_STTMS_CUSTOMER.SSN) THEN
            DBG('failed in ssn validation..');
            P_ERRS := 'ST-SSN001';
            P_PRMS := L_SSN_MASK;
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
            RETURN FALSE;
          END IF;

        ELSE
          P_ERRS := 'FT-SSN003';
          P_PRMS := 'SSN';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
        END IF;

      END IF;

    ELSE
      IF P_CUST_REC.V_STTMS_CUSTOMER.SSN IS NOT NULL THEN

        P_ERRS := 'ST-CIF107';
        P_PRMS := 'SSN';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
      END IF;
    END IF;

    DBG('Successfully completed fn_ssn_valid');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT - Failed in fn_ssn_valid: ' || SQLERRM);
      P_ERRS := 'ST-UPL-001';
      P_PRMS := '- Failed while preparing the data for amendment~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
      RETURN TRUE;
  END FN_SSN_VALID;

  FUNCTION FN_MANDATORY_FOR_NEW(P_FUNCTION_ID IN VARCHAR2,
                                P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_CNT   NUMBER;
    L_MINOR STTMS_BRANCH.MINOR_AGE%TYPE;

    L_CUST_NO STTMS_CUSTOMER.CUSTOMER_NO%TYPE;

  BEGIN

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('calling stpks_stdcif_utils_0_cluster.Fn_Pre_Mandatory_For_New');
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_PRE_MANDATORY_FOR_NEW(P_FUNCTION_ID,
                                                                P_CUST_REC,
                                                                P_ERR_CODE,
                                                                P_ERR_PARAMS) THEN
        DBG('Failed in call to stpks_stdcif_utils_0_cluster.Fn_Pre_Mandatory_For_New');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('Just entered into stpks_cust_upload_type.fn_mandatory_for_new');

      DBG('p_Cust_Rec.v_sttms_customer.Customer_Type' ||
          P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE);
      IF NVL(P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE, 'I') NOT IN
         ('I', 'B', 'C') THEN

        P_ERR_CODE := 'ST-CUST0001';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, '');

        DBG('Validation failed::customer_type: ' ||
            P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      END IF;

      DBG('Calling fn_ssn_valid');

      IF P_CUST_REC.V_STTMS_CUSTOMER.COUNTRY IS NULL THEN

        P_ERR_CODE := 'ST-MAN01';

        P_ERR_PARAMS := '@STTMS_CUSTOMER.COUNTRY~';

        DBG('Validation failed::country: ' ||
            P_CUST_REC.V_STTMS_CUSTOMER.COUNTRY);

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      END IF;

      IF NVL(P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE, 'I') = 'I' THEN

        IF P_CUST_REC.V_STTMS_CUSTOMER.NATIONALITY IS NULL THEN

          P_ERR_CODE := 'ST-MAN01';

          P_ERR_PARAMS := '@STTMS_CUSTOMER.NATIONALITY';

          DBG('Validation failed::nationality: ' ||
              P_CUST_REC.V_STTMS_CUSTOMER.NATIONALITY);

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        END IF;

      END IF;

      IF P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH IS NULL THEN

        P_ERR_CODE := 'ST-MAN01';

        P_ERR_PARAMS := '@STTMS_CUSTOMER.LOCAL_BRANCH';

        DBG('Validation failed::local_branch: ' ||
            P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH);

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      END IF;

      IF P_CUST_REC.V_STTMS_CUSTOMER.LANGUAGE IS NULL THEN

        P_ERR_CODE := 'ST-MAN01';

        P_ERR_PARAMS := '@STTMS_CUSTOMER.LANGUAGE';

        DBG('Validation failed::language: ' ||
            P_CUST_REC.V_STTMS_CUSTOMER.LANGUAGE);

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      END IF;

      IF P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY IS NULL THEN

        P_ERR_CODE := 'ST-MAN01';

        P_ERR_PARAMS := '@STTMS_CUSTOMER.CUSTOMER_CATEGORY';

        DBG('Validation failed::customer_category: ' ||
            P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      END IF;
      DBG('passport validation');
      IF (P_CUST_REC.V_STTMS_CUST_PERSONAL.PPT_ISS_DATE IS NOT NULL) THEN
        IF (P_CUST_REC.V_STTMS_CUST_PERSONAL.PASSPORT_NO IS NULL) THEN

          P_ERR_CODE := 'ST-MAN01';

          P_ERR_PARAMS := '@STTMS_CUST_PERSONAL.PASSPORT_NO';

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        END IF;
      END IF;

      IF (P_CUST_REC.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE IS NOT NULL) THEN
        IF (P_CUST_REC.V_STTMS_CUST_PERSONAL.PASSPORT_NO IS NULL) THEN

          P_ERR_CODE := 'ST-MAN01';

          P_ERR_PARAMS := '@STTMS_CUST_PERSONAL.PASSPORT_NO';

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        END IF;
      END IF;
      IF (P_CUST_REC.V_STTMS_CUST_PERSONAL.PASSPORT_NO IS NOT NULL) THEN
        IF (P_CUST_REC.V_STTMS_CUST_PERSONAL.PPT_ISS_DATE IS NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE IS NULL) THEN

          P_ERR_CODE := 'ST-MAN011';

          P_ERR_PARAMS := '';

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        END IF;
      END IF;

      DBG('mISBAH HERE');
      DBG('Validation minor::Minor option is not checked started');

    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    DBG('stpks_cust_upload_type.fn_mandatory_for_new successful');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT in stpks_cust_upload_type.fn_mandatory_for_new: ' ||
          SQLERRM);

      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the mandatory field for uploading a new customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      RETURN TRUE;
  END FN_MANDATORY_FOR_NEW;

  FUNCTION FN_CHK_OFFLINE(P_FUNCTION_ID  IN VARCHAR2,
                          P_CONNECT_MODE OUT VARCHAR2,
                          P_ERRS         IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                          P_PRMS         IN OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS

    L_HO_NODE STTMS_BRANCH.HOST_NAME%TYPE;

  BEGIN

    DBG('Just entered fn_chk_offline');

    SELECT HOST_NAME
      INTO L_HO_NODE
      FROM STTMS_BRANCH
     WHERE BRANCH_CODE = GLOBAL.HEAD_OFFICE;

    IF L_HO_NODE = GLOBAL.NODE THEN

      P_CONNECT_MODE := 'ONLINE';
      G_OFFLINE      := 'N';
    END IF;

    DBG('Calling cepkss.CheckHOConnectMode for offline check');

    IF L_HO_NODE != GLOBAL.NODE AND
       (NOT CEPKSS.CHECKHOCONNECTMODE(P_CONNECT_MODE)) THEN

      DBG('Call to cepkss.CheckHOConnectMode has failed');
      P_ERRS := 'ST-UPL-001';
      P_PRMS := '- Failed to check the connectivity with HO';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
    END IF;

    DBG('Successfully completed fn_chk_offline');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT in fn_chk_offline: ' || SQLERRM);
      P_ERRS := 'ST-UPL-001';
      P_PRMS := '- Failed to check the connectivity with HO';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
      RETURN TRUE;
  END FN_CHK_OFFLINE;

  FUNCTION FN_COPY_CIF_TO_DETAIL_RECS(P_FUNCTION_ID IN VARCHAR2,
                                      P_CUST_REC    IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                      P_ERR_CODE    IN OUT VARCHAR2,
                                      P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN
    DBG('Entered fn_copy_cif_to_detail_recs');

    IF P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO IS NOT NULL THEN

      P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_NO             := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      P_CUST_REC.V_STTMS_CUST_DOMESTIC.CUSTOMER_NO             := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.CUSTOMER_NO         := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      P_CUST_REC.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUSTOMER := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;

      IF P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C', 'B') THEN
        P_CUST_REC.V_STTMS_CUST_CORPORATE.CUSTOMER_NO := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      END IF;

      P_CUST_REC.V_LMTMS_ISSUER_MASTER.ISSUER_ID     := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      P_CUST_REC.V_LMTMS_ISSUER_MASTER.ISSUER_CIF_ID := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
    END IF;
    DBG('first');
    IF P_CUST_REC.V_LMTMS_ISSUER_LIMIT.COUNT > 0 THEN
      DBG('Count of issuer limit' || P_CUST_REC.V_LMTMS_ISSUER_LIMIT.COUNT);

      FOR I IN P_CUST_REC.V_LMTMS_ISSUER_LIMIT.FIRST .. P_CUST_REC.V_LMTMS_ISSUER_LIMIT.LAST LOOP

        P_CUST_REC.V_LMTMS_ISSUER_LIMIT(I).ISSUER_ID := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      END LOOP;
    END IF;

    DBG('second');

    DBG('count of linked entity ' ||
        P_CUST_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.COUNT);
    IF P_CUST_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.COUNT > 0 THEN

      FOR L_CUST_LINKED_ENTITY IN P_CUST_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.FIRST .. P_CUST_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.LAST LOOP

        DBG('Inside Linked Entity assignment');

        IF P_CUST_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(L_CUST_LINKED_ENTITY)
         .CUSTOMER IS NOT NULL THEN

          P_CUST_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(L_CUST_LINKED_ENTITY).CATEGORY := 'C';
          DBG('Category assigned ');
        END IF;
      END LOOP;

      DBG(' Category assignment done ');

    END IF;

    IF P_CUST_REC.V_STTMS_CORP_DIRECTORS.COUNT > 0 THEN

      FOR I IN P_CUST_REC.V_STTMS_CORP_DIRECTORS.FIRST .. P_CUST_REC.V_STTMS_CORP_DIRECTORS.LAST LOOP

        P_CUST_REC.V_STTMS_CORP_DIRECTORS(I).CUSTOMER_NO := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      END LOOP;
    END IF;

    DBG('-----------------1----------------');

    IF P_CUST_REC.V_STTMS_CUST_SHAREHOLDER.COUNT > 0 THEN

      FOR I IN P_CUST_REC.V_STTMS_CUST_SHAREHOLDER.FIRST .. P_CUST_REC.V_STTMS_CUST_SHAREHOLDER.LAST LOOP

        P_CUST_REC.V_STTMS_CUST_SHAREHOLDER(I).CUSTOMER_NO := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      END LOOP;
    END IF;

    IF P_CUST_REC.V_STTMS_CUST_GROUP.COUNT > 0 THEN
      FOR I IN P_CUST_REC.V_STTMS_CUST_GROUP.FIRST .. P_CUST_REC.V_STTMS_CUST_GROUP.LAST LOOP

        P_CUST_REC.V_STTMS_CUST_GROUP(I).CUSTOMER_NO := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      END LOOP;
    END IF;

    IF P_CUST_REC.TY_STCCIFTX.V_STTMS_CUST_TEXT.COUNT > 0 THEN

      FOR I IN P_CUST_REC.TY_STCCIFTX.V_STTMS_CUST_TEXT.FIRST .. P_CUST_REC.TY_STCCIFTX.V_STTMS_CUST_TEXT.LAST LOOP

        P_CUST_REC.TY_STCCIFTX.V_STTMS_CUST_TEXT(I).CUSTOMER_NO := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      END LOOP;
    END IF;

    DBG('Count of relationship linkage in CSCCURLN' ||
        P_CUST_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.COUNT);
    IF P_CUST_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.COUNT > 0 THEN

      FOR I IN P_CUST_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.FIRST .. P_CUST_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.LAST LOOP

        P_CUST_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I).REF_NO := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      END LOOP;
    END IF;
    DBG('Succefully completed fn_copy_cif_to_detail_recs');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT in fn_copy_cif_to_detail_recs: ' || SQLERRM || ' Trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed to propagate autogenerated CIF to details';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      RETURN TRUE;

  END FN_COPY_CIF_TO_DETAIL_RECS;

  FUNCTION FN_CHECK_MASK(CIF IN OUT VARCHAR2, P_MASK IN OUT VARCHAR2)
    RETURN NUMBER IS

    MASK       VARCHAR2(9);
    LEN        INTEGER;
    LENCIF     INTEGER;
    TEMPMASK   VARCHAR2(1);
    TMPCIF     VARCHAR2(1);
    TMP        INTEGER;
    CNT        INTEGER;
    RETFLAG    INTEGER := 0;
    L_CNT      INTEGER := 0;
    TEMPPLACE  INTEGER := 0;
    TEMPPLACE1 VARCHAR2(9);

    CURSOR C_CIF_BRANCH IS
      SELECT * FROM STTMS_BRANCH ORDER BY BRANCH_CODE;

  BEGIN
    SELECT CIF_MASK INTO MASK FROM STTMS_BANK;
    LEN := NVL(LENGTH(MASK), 0);

    P_MASK := MASK;

    LENCIF := NVL(LENGTH(LTRIM(RTRIM(CIF))), 0);

    IF LENCIF <> LEN THEN

      RETURN 1;
    ELSE
      CNT := 1;

      TEMPPLACE := INSTR(MASK, 'bbb');
      IF TEMPPLACE <> 0 THEN

        DBG('temp place' || TEMPPLACE);
        TEMPPLACE1 := SUBSTR(CIF, TEMPPLACE, TEMPPLACE + 2);
        FOR REC IN C_CIF_BRANCH LOOP

          IF REC.BRANCH_CODE = TEMPPLACE1 THEN

            L_CNT := 1;
          END IF;
        END LOOP;

        IF L_CNT <> 1 THEN

          DBG('Customer no branch is not present in sttm_branch');
          RETURN 3;
        END IF;
      END IF;

      WHILE CNT <= LEN AND RETFLAG = 0 LOOP

        TEMPMASK := SUBSTR(MASK, CNT, 1);
        TMPCIF   := SUBSTR(CIF, CNT, 1);
        TMP      := ASCII(TMPCIF);

        IF (TEMPMASK = 'a' OR TEMPMASK = 'b') AND
           ((TMP >= 65 AND TMP <= 90) OR (TMP >= 48 AND TMP <= 57))

         THEN
          RETFLAG := 0;
        ELSIF TEMPMASK = 'n' AND (TMP >= 48 AND TMP <= 57) THEN

          RETFLAG := 0;
        ELSIF TEMPMASK = '.' AND TMP = 46 THEN

          RETFLAG := 0;
        ELSIF TEMPMASK = '-' AND TMP = 45 THEN

          RETFLAG := 0;

        ELSIF TEMPMASK = 'A' AND
              ((TMP >= 65 AND TMP <= 90) OR (TMP >= 48 AND TMP <= 57)) THEN

          RETFLAG := 0;
        ELSE
          RETFLAG := 2;
        END IF;
        CNT := CNT + 1;
      END LOOP;
      RETURN(RETFLAG);
    END IF;
    RETURN NULL;
  END FN_CHECK_MASK;

  FUNCTION FN_CUSTNO_VALID(P_FUNCTION_ID IN VARCHAR2,
                           P_CUST_NO     IN OUT STTM_CUSTOMER.CUSTOMER_NO%TYPE

                          ,
                           P_AUTO_GEN IN VARCHAR2,
                           P_SPL_CUST IN VARCHAR2,
                           P_ERRS     OUT ERTB_MSGS.ERR_CODE%TYPE,
                           P_PRMS     OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS

    L_CNT  NUMBER(5) := 0;
    L_MASK STTMS_BANK.CIF_MASK%TYPE;
    L_CHK  NUMBER(1);
  BEGIN

    DBG('Just entered fn_custno_valid');

    SELECT COUNT(*)
      INTO L_CNT
      FROM STTMS_CUSTOMER
     WHERE CUSTOMER_NO = P_CUST_NO;

    IF L_CNT > 0 THEN

      DBG('Customer number already exists');
      P_ERRS := 'ST-REC01';
      P_PRMS := 'Customer number already exists';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
    END IF;

    SELECT COUNT(*)
      INTO L_CNT
      FROM STTMS_CUSTOMER_CAT
     WHERE CUST_CAT = P_CUST_NO;

    IF L_CNT > 0 THEN

      P_ERRS := 'ST-CIF55';
      P_PRMS := 'customer number cannot be one of the Customer Categories ';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
    END IF;

    IF (P_CUST_NO = 'ALL' OR P_CUST_NO = 'USERINPUT' OR
       P_CUST_NO = 'STANDARD' OR NVL(LENGTH(P_CUST_NO), 0) < 3) AND
       P_CUST_NO IS NOT NULL THEN

      DBG('Length of customer number is less than 3');
      P_ERRS := 'ST-CIF01';
      P_PRMS := '';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
    END IF;

    IF NVL(LENGTH(P_CUST_NO), 0) = 9 THEN

      SELECT COUNT(*)
        INTO L_CNT
        FROM STTMS_BRANCH_NODE
       WHERE NODE != GLOBAL.NODE
         AND BRANCH_CODE = SUBSTR(P_CUST_NO, 7, 3);

      IF L_CNT != 0 THEN

        P_ERRS := 'ST-CIF08';
        P_PRMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
      END IF;
    END IF;

    IF NVL(P_AUTO_GEN, 'N') = 'N' OR NVL(P_SPL_CUST, 'N') = 'Y' THEN

      BEGIN
        SELECT CIF_MASK
          INTO L_MASK
          FROM STTM_NODE_CIFMASK
         WHERE NODE = GLOBAL.NODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          SELECT CIF_MASK INTO L_MASK FROM STTMS_BANK;
      END;
      IF L_MASK IS NOT NULL THEN

        DBG('Before calling fn_check_mask');
        DBG('Before calling fn_check_mask mask is -->' || L_MASK);

        L_CHK := FN_CHECK_MASK(P_CUST_NO, L_MASK);

        DBG('After calling fn_check_mask' || L_CHK);
        DBG('After calling fn_check_mask mask is -->' || L_MASK);

        IF L_CHK = 1 OR L_CHK = 2 THEN

          P_ERRS := 'ST-CIF99';
          P_PRMS := L_MASK || '~';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
        END IF;

        IF L_CHK = 3 THEN

          P_ERRS := 'ST-CIF01';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
        END IF;
      END IF;
    END IF;

    DBG('Successfully exiting from fn_custno_valid');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      P_ERRS := 'ST-UPL-001';
      P_PRMS := '- Failed in Customer No. validation~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERRS, P_PRMS);
      RETURN TRUE;
  END FN_CUSTNO_VALID;

  FUNCTION FN_GATEWAY_VALIDATE(P_FUNCTION_ID IN VARCHAR2,
                               P_CUST_REC    IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                               P_ERR_CODE    IN OUT VARCHAR2,
                               P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_AUTO_GEN_CIF_GATEWAY STTMS_BANK.AUTO_GEN_CIF%TYPE;

  BEGIN
    DBG('hii');
    BEGIN
      SELECT AUTO_GEN_CIF
        INTO L_AUTO_GEN_CIF_GATEWAY
        FROM STTMS_BANK
       WHERE AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';

    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_CODE   := 'CS-10000';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

    END;

    IF NVL(L_AUTO_GEN_CIF_GATEWAY, 'N') = 'Y' AND
       NVL(P_CUST_REC.V_STTMS_CUSTOMER.SPECIAL_CUST, 'N') = 'N' AND
       P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO IS NOT NULL

     THEN

      DBG('Error: Customer in the req msg should be null when auto gen is on');
      P_ERR_CODE := 'ST-CUST0015';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed in Customer No. validation~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      RETURN TRUE;
  END FN_GATEWAY_VALIDATE;

  FUNCTION FN_GEN_N_VALIDATE_CIF(P_FUNCTION_ID IN VARCHAR2,
                                 P_CUST_REC    IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                 P_ERR_CODE    IN OUT VARCHAR2,
                                 P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_AUTO_GEN_CIF      STTMS_BANK.AUTO_GEN_CIF%TYPE;
    L_START_CUSTOMER_NO STTMS_CUSTOMER_PARAM.START_CUSTOMER_NO%TYPE;
    L_END_CUSTOMER_NO   STTMS_CUSTOMER_PARAM.END_CUSTOMER_NO%TYPE;
    L_CONNECT_MODE      VARCHAR2(30);

  BEGIN

    DBG('Just entered fn_gen_n_validate_cif');

    BEGIN
      SELECT AUTO_GEN_CIF
        INTO L_AUTO_GEN_CIF
        FROM STTMS_BANK
       WHERE AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';

    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_CODE   := 'CS-10000';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

    END;

    DBG('Auto generate CIF: ' || L_AUTO_GEN_CIF);
    DBG('CIF from the req msg: ' ||
        P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO);

    IF NVL(L_AUTO_GEN_CIF, 'N') = 'Y' AND
       P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO IS NULL THEN

      DBG('Error: Customer in the req msg should be null when auto gen is on');
      P_ERR_CODE := 'ST-CUST0015';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

    END IF;

    IF NVL(L_AUTO_GEN_CIF, 'N') = 'N' AND
       P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO IS NULL THEN

      DBG('Error: Customer in the req msg cannot be null when auto gen is off');
      P_ERR_CODE := 'ST-CUST0016';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

    END IF;

    IF NVL(L_AUTO_GEN_CIF, 'N') = 'Y' AND
       P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO IS NULL

     THEN

      IF P_CUST_REC.V_STTMS_CUSTOMER.EXT_REF_NO IS NULL THEN

        DBG('Xref No Cannot be NULL');
        P_ERR_CODE   := 'ST-MAN01';
        P_ERR_PARAMS := 'XREF cannot be NULL when Auto Generation of Customer number is set' || '~';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      END IF;

      DBG('Local Branch is ' || P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH);
      SELECT START_CUSTOMER_NO, END_CUSTOMER_NO
        INTO L_START_CUSTOMER_NO, L_END_CUSTOMER_NO

        FROM STTMS_CUSTOMER_PARAM
       WHERE BRANCH_CODE = P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH;

      DBG('Start cif no: ' || L_START_CUSTOMER_NO || ' End cif no: ' ||
          L_END_CUSTOMER_NO);

      G_AUTO_CIF := 'Y';

      IF L_START_CUSTOMER_NO <> 0 AND L_END_CUSTOMER_NO <> 0 THEN

        DBG('Calling stpkss_accgen.fn_generate_cif');
        IF NOT STPKSS_ACCGEN.FN_GENERATE_CIF(P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                             P_ERR_CODE,
                                             P_ERR_PARAMS) THEN

          DBG('Could not generate CIF nos. automatically');

        END IF;

      ELSE
        SELECT P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH ||
               LPAD(TO_CHAR(CESQ_CIF_ID.NEXTVAL), 6, '0')

          INTO P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO
          FROM DUAL;
      END IF;

      DBG('Calling stpkss_accgen.fn_update_customer_srno');

      IF NOT
          STPKSS_ACCGEN.FN_UPDATE_CUSTOMER_SRNO(P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO) THEN

        P_ERR_CODE   := 'ST-UPL-001';
        P_ERR_PARAMS := '- Failed to register the autogenerated CIF';
        DBG('Call to fn_update_customer_srno failed');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      END IF;

    ELSIF NVL(L_AUTO_GEN_CIF, 'N') = 'N' THEN

      DBG('Before calling fn_chk_offline');

      IF NOT FN_CHK_OFFLINE(P_FUNCTION_ID,
                            L_CONNECT_MODE,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN

        DBG('Error Occurred while checking for Offline/Online');

      END IF;

      IF L_CONNECT_MODE != 'ONLINE' THEN
        DBG('p_Cust_Rec.v_Sttms_Customer.Customer_No::' ||
            P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO);

        IF LENGTH(P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO) > 9 THEN

          P_ERR_CODE := 'ST-CUST0013';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        END IF;

      END IF;

    END IF;

    DBG('Calling fn_copy_cif_to_detail_recs');
    IF NOT FN_COPY_CIF_TO_DETAIL_RECS(P_FUNCTION_ID,
                                      P_CUST_REC,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN

      DBG('Failed in fn_copy_cif_to_detail_recs');

    END IF;

    DBG('Calling fn_custno_valid');

    DBG('Customer Number is ' || P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO);

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('Inside WOT of  fn_gen_n_validate_cif ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := 'Customer no generation error' || '~';
      RETURN TRUE;
  END FN_GEN_N_VALIDATE_CIF;

  FUNCTION FN_TPIN_GEN(P_CUST_REC IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                       P_ERRS     IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                       P_PRMS     IN OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS

    L_CNT    NUMBER;
    L_TPIN   NUMBER;
    L_STATUS VARCHAR2(2);
    L_PARAM  CHAR;

  BEGIN

    L_PARAM := CSPKSS_OS_PARAM.GET_PARAM_VAL('TPIN_GEN');

    IF L_PARAM = 'Y' THEN

      BEGIN
        DBG('Inside function fn_tpin_gen');

        SELECT NVL(COUNT(*), 0)
          INTO L_CNT
          FROM STTMS_CUST_TPIN
         WHERE CUSTOMER_NO = P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;

        DBG('COUNT' || L_CNT);

        IF L_CNT = 0 THEN

          DBG('Before Calling stpkss_tpin.fn_cust_tpin');
          L_TPIN   := NULL;
          L_STATUS := 'UI';
          P_ERRS   := NULL;
          P_PRMS   := NULL;
          IF (STPKSS_TPIN.FN_CUST_TPIN(L_TPIN,
                                       '',
                                       P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                       L_STATUS,
                                       P_ERRS,
                                       P_PRMS)) THEN

            DBG(' TPIN  ' || L_TPIN);
          END IF;
        ELSE
          DBG(' into else');
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Unexpected error in fn_tpin_gen' || SQLERRM);
          P_ERRS := 'ST-UPL-001';
          P_PRMS := '- Failed while generating the TPIN~';
          RETURN FALSE;
      END;
    END IF;
    RETURN TRUE;
  END FN_TPIN_GEN;

  FUNCTION FN_BEFORE_SAVE(P_CUST_REC IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                          P_ERRS     IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                          P_PRMS     IN OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS

    ADD1 NUMBER(3);

  BEGIN
    DBG('Calling fn_check_customer');

    IF NOT STPKSS_SDN.FN_CHECK_CUSTOMER(P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                        P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NAME1,
                                        'N',
                                        'Y',
                                        'Y',
                                        P_ERRS,
                                        P_PRMS) THEN

      DBG('Fn_check_customer returns false');
      RETURN FALSE;
    END IF;

    DBG('Short name2 value before in utils0 ' ||
        P_CUST_REC.V_STTMS_CUSTOMER.SHORT_NAME2);
    IF P_CUST_REC.V_STTMS_CUSTOMER.SHORT_NAME2 IS NULL THEN

      IF P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE IS NOT NULL THEN

        IF LENGTH(P_CUST_REC.V_STTMS_CUSTOMER.SHORT_NAME) > 20 THEN
          P_ERRS := 'ST-CIF13';
          P_PRMS := '';
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
    IF P_CUST_REC.V_STTMS_CUSTOMER.SWIFT_CODE IS NOT NULL THEN
      IF (NVL(LENGTH(P_CUST_REC.V_STTMS_CUSTOMER.SWIFT_CODE), 0) <> 8 AND
         NVL(LENGTH(P_CUST_REC.V_STTMS_CUSTOMER.SWIFT_CODE), 0) <> 11) THEN

        P_ERRS := 'MS-00029';
        P_PRMS := '';
        RETURN FALSE;
      ELSIF (NVL(LENGTH(P_CUST_REC.V_STTMS_CUSTOMER.SWIFT_CODE), 0)) IN
            (8, 11) THEN
        FOR I IN 1 .. LENGTH(P_CUST_REC.V_STTMS_CUSTOMER.SWIFT_CODE) LOOP

          ADD1 := 0;
          SELECT ASCII(SUBSTR(P_CUST_REC.V_STTMS_CUSTOMER.SWIFT_CODE, I, 1))

            INTO ADD1
            FROM DUAL;
          IF (ADD1 <> 32) THEN

            NULL;
          ELSE
            P_ERRS := 'SE-DO0194';
            RETURN FALSE;
          END IF;
        END LOOP;
      END IF;
    END IF;

    DBG('Calling function realtionship');
    DBG('Customer Number :' || P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO);

    IF NOT FN_TPIN_GEN(P_CUST_REC, P_ERRS, P_PRMS) THEN

      DBG('Error in Generating TPIN from the function fn_tpin_gen');
      RETURN FALSE;
    END IF;

    DBG('fn_before_save return true ');

    RETURN TRUE;

  END FN_BEFORE_SAVE;

  FUNCTION FN_CHK_INCORP_DATE(P_DOB_TOCHK  IN DATE,
                              P_DOB_DESC   IN VARCHAR2,
                              P_ERR_CODE   IN OUT VARCHAR2,
                              P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS

  BEGIN
    DBG('Checking for the Date of Birth for the Joint Customer');
    DBG('Date of Birth Coming ' || P_DOB_TOCHK);

    IF P_DOB_TOCHK >= GLOBAL.APPLICATION_DATE THEN

      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '"Incorporation Date" of Corporate Customer or "Date of Birth" of Joint Customer is greater than Application Date~';

      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);

    END IF;

    DBG('Successfully returns from the Function fn_chk_incorp_date');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN

      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the record no~';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_INCORP_DATE;

  FUNCTION FN_VALIDATE_RECORDS(P_FUNCTION_ID IN VARCHAR2,
                               P_CUST_REC    IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                               P_ERR_CODE    IN OUT VARCHAR2,
                               P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_WHAT_TO_DO CHAR(1);

    L_ERR VARCHAR2(255);

    L_ERR_CODE  VARCHAR2(11);
    L_ERR_PARAM VARCHAR2(4000);

    L_COUNT       NUMBER := 0;
    P_TOT_LIM_AMT NUMBER(22, 3) := 0;
    P_LIMIT_AMT   NUMBER(22, 3);
    P_RATE        CYTMS_RATES.MID_RATE%TYPE;

    L_DOCUMENT_TYPES VARCHAR2(4000);

  BEGIN

    DBG('Entered a Hook...');
    PR_SKIP_HANDLER('Pre_Validate_Records');
    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CUSTOM THEN
      DBG('Calling stpks_stdcif_utils_0_custom.Fn_Pre_Validate_Records..');
      IF NOT
          STPKS_STDCIF_UTILS_0_CUSTOM.FN_PRE_VALIDATE_RECORDS(P_FUNCTION_ID,
                                                              P_CUST_REC,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
        DBG('Failed in stpks_stdcif_utils_0_custom.Fn_Pre_Validate_Records..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CLUSTER THEN
      DBG('Calling stpks_stdcif_utils_0_cluster.Fn_Pre_Validate_Records..');
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_PRE_VALIDATE_RECORDS(P_FUNCTION_ID,
                                                               P_CUST_REC,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAMS) THEN
        DBG('Failed in stpks_stdcif_utils_0_cluster.Fn_Pre_Validate_Records..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_KERNEL THEN

      DBG('Starting record validations..');
      P_ERR_CODE   := '';
      P_ERR_PARAMS := '';

      DBG('Calling fn_validate_item');
      IF NOT STPKS_STDCIF_UTILS_1.FN_VALIDATE_ITEM(P_FUNCTION_ID,
                                                   P_CUST_REC,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DBG('fn_validate_item failed ... ' || P_ERR_CODE || '...' ||
            P_ERR_PARAMS);

        RETURN FALSE;
      END IF;

      DBG('Calling fn_lov_validate');

      L_WHAT_TO_DO := NULL;

      IF (P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I') THEN

        DBG('CORPORATE_NAME = ' ||
            P_CUST_REC.V_STTMS_CUST_CORPORATE.CORPORATE_NAME);
        DBG('C_NATIONAL_ID = ' ||
            P_CUST_REC.V_STTMS_CUST_CORPORATE.C_NATIONAL_ID);
        DBG('R_ADDRESS1 = ' ||
            P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS1);
        DBG('R_ADDRESS2 = ' ||
            P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS2);
        DBG('R_ADDRESS3 = ' ||
            P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS3);
        DBG('INCORP_DATE = ' ||
            P_CUST_REC.V_STTMS_CUST_CORPORATE.INCORP_DATE);
        DBG('CAPITAL = ' || P_CUST_REC.V_STTMS_CUST_CORPORATE.CAPITAL);
        DBG('NETWORTH = ' || P_CUST_REC.V_STTMS_CUST_CORPORATE.NETWORTH);
        DBG('BUSINESS_DESCRIPTION = ' ||
            P_CUST_REC.V_STTMS_CUST_CORPORATE.BUSINESS_DESCRIPTION);
        DBG('INCORP_COUNTRY = ' ||
            P_CUST_REC.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);
        DBG('R_COUNTRY = ' || P_CUST_REC.V_STTMS_CUST_CORPORATE.R_COUNTRY);
        DBG('AMOUNTS_CCY = ' ||
            P_CUST_REC.V_STTMS_CUST_CORPORATE.AMOUNTS_CCY);
        DBG('ISSUER_ID = ' || P_CUST_REC.V_LMTMS_ISSUER_MASTER.ISSUER_ID);
        DBG('ISSUER_DETAILS = ' ||
            P_CUST_REC.V_LMTMS_ISSUER_MASTER.ISSUER_DETAILS);
        DBG('OVERALL_LIMIT = ' ||
            P_CUST_REC.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT);
        DBG('OVERALL_LIMIT_CCY = ' ||
            P_CUST_REC.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY);
        DBG('p_Cust_Rec.v_lmtms_issuer_limit.Count: ' ||
            P_CUST_REC.V_LMTMS_ISSUER_LIMIT.COUNT);
        DBG('p_Cust_Rec.v_sttms_corp_directors.Count: ' ||
            P_CUST_REC.V_STTMS_CORP_DIRECTORS.COUNT);
        IF P_CUST_REC.V_STTMS_CUST_CORPORATE.CORPORATE_NAME IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_CORPORATE.C_NATIONAL_ID IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS1 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS2 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS3 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_CORPORATE.INCORP_DATE IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_CORPORATE.CAPITAL IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_CORPORATE.NETWORTH IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_CORPORATE.BUSINESS_DESCRIPTION IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_CORPORATE.R_COUNTRY IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_CORPORATE.AMOUNTS_CCY IS NOT NULL OR
           P_CUST_REC.V_LMTMS_ISSUER_MASTER.ISSUER_DETAILS IS NOT NULL OR
           P_CUST_REC.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT IS NOT NULL OR
           P_CUST_REC.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY IS NOT NULL OR
           P_CUST_REC.V_LMTMS_ISSUER_LIMIT.COUNT > 0 OR
           P_CUST_REC.V_STTMS_CORP_DIRECTORS.COUNT > 0 THEN
          DBG('HItech');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IF-CIF025', '');
        END IF;
      ELSE

        DBG('CUSTOMER_PREFIX = ' ||
            P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX);
        DBG('FIRST_NAME = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.FIRST_NAME);
        DBG('MIDDLE_NAME = ' ||
            P_CUST_REC.V_STTMS_CUST_PERSONAL.MIDDLE_NAME);
        DBG('LAST_NAME = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.LAST_NAME);
        DBG('DATE_OF_BIRTH = ' ||
            P_CUST_REC.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH);
        DBG('LEGAL_GUARDIAN = ' ||
            P_CUST_REC.V_STTMS_CUST_PERSONAL.LEGAL_GUARDIAN);
        DBG('MINOR = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.MINOR);
        DBG('SEX = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.SEX);
        DBG('P_NATIONAL_ID = ' ||
            P_CUST_REC.V_STTMS_CUST_PERSONAL.P_NATIONAL_ID);
        DBG('PASSPORT_NO = ' ||
            P_CUST_REC.V_STTMS_CUST_PERSONAL.PASSPORT_NO);
        DBG('PPT_ISS_DATE = ' ||
            P_CUST_REC.V_STTMS_CUST_PERSONAL.PPT_ISS_DATE);
        DBG('PPT_EXP_DATE = ' ||
            P_CUST_REC.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE);
        DBG('D_ADDRESS1 = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.D_ADDRESS1);
        DBG('D_ADDRESS2 = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.D_ADDRESS2);
        DBG('D_ADDRESS3 = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.D_ADDRESS3);
        DBG('TELEPHONE = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.TELEPHONE);
        DBG('FAX = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.FAX);
        DBG('E_MAIL = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.E_MAIL);
        DBG('P_ADDRESS1 = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.P_ADDRESS1);
        DBG('P_ADDRESS3 = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.P_ADDRESS3);
        DBG('P_ADDRESS2 = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.P_ADDRESS2);

        DBG('D_COUNTRY = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.D_COUNTRY);
        DBG('P_COUNTRY = ' || P_CUST_REC.V_STTMS_CUST_PERSONAL.P_COUNTRY);
        DBG('RESIDENT_STATUS = ' ||
            P_CUST_REC.V_STTMS_CUST_PERSONAL.RESIDENT_STATUS);
        DBG('CUSTOMER_PREFIX1 = ' ||
            P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX1);
        DBG('CUSTOMER_PREFIX2 = ' ||
            P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX2);
        IF P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.FIRST_NAME IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.MIDDLE_NAME IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.LAST_NAME IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.LEGAL_GUARDIAN IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.P_NATIONAL_ID IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.PASSPORT_NO IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.PPT_ISS_DATE IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.D_ADDRESS1 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.D_ADDRESS2 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.D_ADDRESS3 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.TELEPHONE IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.FAX IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.E_MAIL IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.P_ADDRESS1 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.P_ADDRESS3 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.P_ADDRESS2 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.D_COUNTRY IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.P_COUNTRY IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX1 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX2 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_DOMESTIC.SPOUSE_NAME IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_DOMESTIC.DEPENDENT_CHILDREN IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_DOMESTIC.DEPENDENT_OTHERS IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.EMPLOYMENT_TENURE IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.RETIREMENT_AGE IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.PREV_DESIGNATION IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.PREV_EMPLOYER IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.DESIGNATION IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.EMPLOYER IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS1 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS2 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS3 IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_TELEPHONE IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_TELEX IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_FAX IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_EMAIL IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.SALARY IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.OTHER_INCOME IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.RENT IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.INSURANCE IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.LOAN_PAYMENT IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.OTHER_EXPENSES IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.HOUSE_VALUE IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.CREDIT_CARDS IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_COUNTRY IS NOT NULL OR
           P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.CCY_PERS_INCEXP IS NOT NULL THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IF-CIF026', '');
        END IF;
      END IF;

      IF (P_CUST_REC.V_STTMS_CUSTOMER.ISSUER_CUSTOMER = 'Y' OR
         P_CUST_REC.V_STTMS_CUSTOMER.GENERATE_MT920 = 'Y') AND
         P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN

        DBG('Failed this check');
        P_ERR_CODE   := 'ST-UPL-001';
        P_ERR_PARAMS := '"Issuer Customer" or "MT920" cannot be checked for Customer Type "Individual"~';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      IF P_CUST_REC.V_STTMS_CUSTOMER.ISSUER_CUSTOMER = 'Y' THEN

        BEGIN
          L_COUNT := P_CUST_REC.V_LMTMS_ISSUER_LIMIT.COUNT;

          IF L_COUNT > 0 THEN

            FOR L_INDEX IN 1 .. P_CUST_REC.V_LMTMS_ISSUER_LIMIT.COUNT

             LOOP
              P_CUST_REC.V_LMTMS_ISSUER_LIMIT(L_INDEX).LIMIT_AMOUNT := NVL(P_CUST_REC.V_LMTMS_ISSUER_LIMIT(L_INDEX)
                                                                           .LIMIT_AMOUNT,
                                                                           0);
              DBG('Issuer : ' || P_CUST_REC.V_LMTMS_ISSUER_LIMIT(L_INDEX)
                  .ISSUER_ID);

              DBG('Inside loop Values : ' || P_CUST_REC.V_LMTMS_ISSUER_LIMIT(L_INDEX)
                  .LIMIT_CURRENCY || '~' ||
                  P_CUST_REC.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY || '~' ||
                  TO_CHAR(P_CUST_REC.V_LMTMS_ISSUER_LIMIT(L_INDEX)
                          .LIMIT_AMOUNT));

              DBG('Total Lim Amt ' || TO_CHAR(P_TOT_LIM_AMT));

              IF P_CUST_REC.V_LMTMS_ISSUER_LIMIT(L_INDEX)
               .LIMIT_CURRENCY <>
                  P_CUST_REC.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY THEN

                IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                             P_CUST_REC.V_LMTMS_ISSUER_LIMIT(L_INDEX)
                                             .LIMIT_CURRENCY

                                            ,
                                             P_CUST_REC.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY

                                            ,
                                             P_CUST_REC.V_LMTMS_ISSUER_LIMIT(L_INDEX)
                                             .LIMIT_AMOUNT

                                            ,
                                             'N',
                                             P_LIMIT_AMT,
                                             P_RATE,
                                             P_ERR_CODE) THEN

                  DBG('Limit amount could not be converted to overall limit currency amount');
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               '',
                               'BC-AT002',
                               '@' || P_CUST_REC.V_LMTMS_ISSUER_LIMIT(L_INDEX)
                               .LIMIT_CURRENCY || '~@' ||
                                P_CUST_REC.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY || '~' ||
                                L_INDEX);

                END IF;
                DBG('Limit amount in ' ||
                    P_CUST_REC.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY ||
                    ' is ' || TO_CHAR(P_LIMIT_AMT));

              ELSE
                P_LIMIT_AMT := P_CUST_REC.V_LMTMS_ISSUER_LIMIT(L_INDEX)
                               .LIMIT_AMOUNT;

              END IF;
              P_TOT_LIM_AMT := NVL(P_TOT_LIM_AMT, 0) + P_LIMIT_AMT;

              DBG('inside' || P_TOT_LIM_AMT);
            END LOOP;

            IF NVL(P_TOT_LIM_AMT, 0) >
               P_CUST_REC.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT THEN
              DBG('Limit amount is exceeding the overall limit amount' ||
                  TO_CHAR(P_TOT_LIM_AMT) || '~' ||

                  TO_CHAR(P_CUST_REC.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT));
              PR_LOG_ERROR(P_FUNCTION_ID, '', 'AC-LM-00202', NULL);

            END IF;

          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Issuer Limit Amount Check ' || SQLERRM);
            P_ERR_CODE   := 'ST-OTHR-001';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
        END;
      END IF;

      IF (P_CUST_REC.V_STTMS_CUSTOMER.HO_AC_NO IS NOT NULL OR
         P_CUST_REC.V_STTMS_CUSTOMER.DEBTOR_CATEGORY IS NOT NULL OR

         P_CUST_REC.V_STTMS_CUSTOMER.RISK_PROFILE IS NOT NULL

         OR P_CUST_REC.V_STTMS_CUSTOMER.UTILITY_PROVIDER = 'Y' OR
         P_CUST_REC.V_STTMS_CUSTOMER.UTILITY_PROVIDER_ID IS NOT NULL OR
         P_CUST_REC.V_STTMS_CUSTOMER.ALG_ID IS NOT NULL OR
         P_CUST_REC.V_STTMS_CUSTOMER.CHK_DIGIT_VALID_REQD = 'Y') AND
         P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN

        DBG('Failed this check');
        P_ERR_CODE   := 'ST-UPL-001';
        P_ERR_PARAMS := '"Utility Provider" or "Head Office" details are not to be entered for Customer Type "Individual"~';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('Count of document types');
      DBG('p_Cust_Rec.v_Sttms_Cust_Doc_Checklist.count->' ||
          P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST.COUNT);
      IF P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST.COUNT > 0 THEN

        L_DOCUMENT_TYPES := NULL;

        FOR I IN 1 .. P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST.COUNT LOOP
          DBG('Inside document check list loop');
          DBG('Document Type->' || P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I)
              .DOCUMENT_TYPE);
          DBG('checked status->' || P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I)
              .CHECKED);
          IF P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I).CHECKED = 'N' THEN
            IF P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I).EXP_SUB_DATE IS NULL THEN

              IF L_DOCUMENT_TYPES IS NULL AND P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I)
                .DOC_CATEGORY <> 'FATCA' THEN
                L_DOCUMENT_TYPES := P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I)
                                    .DOCUMENT_TYPE;

              ELSE
                IF L_DOCUMENT_TYPES IS NOT NULL AND P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I)
                  .DOC_CATEGORY <> 'FATCA' THEN
                  L_DOCUMENT_TYPES := L_DOCUMENT_TYPES || ',' || P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I)
                                     .DOCUMENT_TYPE;
                END IF;
              END IF;

            ELSIF P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I)
             .EXP_SUB_DATE <= GLOBAL.APPLICATION_DATE THEN
              IF L_DOCUMENT_TYPES IS NULL THEN
                L_DOCUMENT_TYPES := P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I)
                                    .DOCUMENT_TYPE;
              ELSE
                L_DOCUMENT_TYPES := L_DOCUMENT_TYPES || ',' || P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I)
                                   .DOCUMENT_TYPE;
              END IF;
            ELSIF P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I)
             .EXP_SUB_DATE > GLOBAL.APPLICATION_DATE AND
                   P_CUST_REC.V_STTMS_CUSTOMER.KYC_DETAILS = 'V' THEN
              IF L_DOCUMENT_TYPES IS NULL THEN
                L_DOCUMENT_TYPES := P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I)
                                    .DOCUMENT_TYPE;
              ELSE
                L_DOCUMENT_TYPES := L_DOCUMENT_TYPES || ',' || P_CUST_REC.V_STTMS_CUST_DOC_CHECKLIST(I)
                                   .DOCUMENT_TYPE;
              END IF;
            END IF;

          END IF;
        END LOOP;

        IF L_DOCUMENT_TYPES IS NOT NULL AND LENGTH(L_DOCUMENT_TYPES) < 4000 THEN

          P_ERR_CODE   := 'ST-UPL-001';
          P_ERR_PARAMS := 'The following document(s) ' || L_DOCUMENT_TYPES ||
                          ' needs to be marked as checked~';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        ELSIF L_DOCUMENT_TYPES IS NOT NULL THEN

          P_ERR_CODE   := 'ST-UPL-001';
          P_ERR_PARAMS := 'Documents needs to be marked as checked in the Check List Tab~';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        END IF;
        L_DOCUMENT_TYPES := NULL;
      END IF;

      IF NOT FN_BEFORE_SAVE(P_CUST_REC, P_ERR_CODE, P_ERR_PARAMS) THEN

        DBG('Failed in fn_before_save');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      END IF;

      IF (L_WHAT_TO_DO = 'R') THEN

        RETURN FALSE;
      END IF;

      DBG('Calling function to insert into tables..');

      DBG('calling function to update override table');

      IF G_DISTRIBUTED <> 'Y' THEN

        P_ERR_CODE   := '';
        P_ERR_PARAMS := '';
      END IF;

    END IF;
    PR_SKIP_HANDLER('Post_Validate_Records');
    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CLUSTER THEN
      DBG('Calling stpks_stdcif_utils_0_cluster.Fn_Post_Validate_Records..');
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_POST_VALIDATE_RECORDS(P_FUNCTION_ID,
                                                                P_CUST_REC,
                                                                P_ERR_CODE,
                                                                P_ERR_PARAMS) THEN
        DBG('Failed in stpks_stdcif_utils_0_cluster.Fn_Post_Validate_Records..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CUSTOM THEN
      DBG('Calling stpks_stdcif_utils_0_custom.Fn_Post_Validate_Records..');
      IF NOT
          STPKS_STDCIF_UTILS_0_CUSTOM.FN_POST_VALIDATE_RECORDS(P_FUNCTION_ID,
                                                               P_CUST_REC,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAMS) THEN
        DBG('Failed in stpks_stdcif_utils_0_custom.Fn_Post_Validate_Records..');
        RETURN FALSE;
      END IF;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN STPKSS_UPLOAD.G_HALT_ON_EXCEPTION THEN
      DBG('g_halt_on_exception raised');
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while validating the records of the customer~';
      RETURN FALSE;
    WHEN OTHERS THEN
      DBG('Motherhood Exception in fn_validate_records');
      P_ERR_CODE   := 'ST-UPLD103';
      P_ERR_PARAMS := 'Motherhood Exception in fn_validate_records' || '~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      DBG('SQL error is ' || SQLERRM);

      RETURN FALSE;
  END FN_VALIDATE_RECORDS;

  FUNCTION FN_DEFAULTING_FOR_NEW_CUST(P_CUST_BASE_REC IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                      P_USER_ID       IN VARCHAR2,
                                      P_ERR_CODE      OUT ERTB_MSGS.ERR_CODE%TYPE,
                                      P_ERR_PARAMS    OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS

    L_CNT NUMBER(8);

  BEGIN

    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.DEFAULT_MEDIA IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.DEFAULT_MEDIA := 'MAIL';
      DBG('Default Media was null hence assigned to ' ||
          P_CUST_BASE_REC.V_STTMS_CUSTOMER.DEFAULT_MEDIA);

    END IF;

    DBG('count of linked entity ' ||
        P_CUST_BASE_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.COUNT);
    IF P_CUST_BASE_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.COUNT > 0 THEN

      FOR L_CUST_LINKED_ENTITY IN P_CUST_BASE_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.FIRST .. P_CUST_BASE_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.LAST LOOP

        DBG('Inside Linked Entity assignment');

        IF P_CUST_BASE_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(L_CUST_LINKED_ENTITY)
         .CUSTOMER IS NOT NULL THEN

          P_CUST_BASE_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(L_CUST_LINKED_ENTITY).CATEGORY := 'C';
          DBG('Category assigned ');
        END IF;
      END LOOP;

      DBG(' Category assignment done ');

    END IF;

    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.FX_NETTING_CUSTOMER IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.FX_NETTING_CUSTOMER := P_CUST_BASE_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      DBG('FX Netting Customer Defaulted');
    END IF;

    DBG('Group code Defaulted to NULL');

    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.EXPOSURE_COUNTRY IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.EXPOSURE_COUNTRY := P_CUST_BASE_REC.V_STTMS_CUSTOMER.COUNTRY;
    END IF;

    DBG('Short name2 value before assignment in utils0' ||
        P_CUST_BASE_REC.V_STTMS_CUSTOMER.SHORT_NAME2);

    P_CUST_BASE_REC.V_STTMS_CUSTOMER.SHORT_NAME2 := P_CUST_BASE_REC.V_STTMS_CUSTOMER.SHORT_NAME ||
                                                    P_CUST_BASE_REC.V_STTMS_CUSTOMER.LOC_CODE;

    SELECT NVL(COUNT(*), 0)
      INTO L_CNT
      FROM STTMS_EXP_TYPE_MASTER
     WHERE CATEGORY_TYPE =
           DECODE(P_CUST_BASE_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE,
                  'B',
                  'C',
                  P_CUST_BASE_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE)
       AND RECORD_STAT = 'O'
       AND ONCE_AUTH = 'Y';

    IF L_CNT <> 0 THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.EXPOSURE_CATEGORY := NULL;
      DBG('Exposure Category Defaulted');
    END IF;

    DBG('AML CUSTOMER GRP Defaulted');

    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.UTILITY_PROVIDER <> 'Y' THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.CHK_DIGIT_VALID_REQD := 'N';
      P_CUST_BASE_REC.V_STTMS_CUSTOMER.ALG_ID               := NULL;
    END IF;

    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.CHK_DIGIT_VALID_REQD <> 'Y' THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.ALG_ID := NULL;
    END IF;

    DBG('Algorithm Id Defaulted to NULL');

    IF P_CUST_BASE_REC.V_STTMS_CUST_DOMESTIC.MARITAL_STATUS = 'S' THEN

      P_CUST_BASE_REC.V_STTMS_CUST_DOMESTIC.SPOUSE_NAME := NULL;

      P_CUST_BASE_REC.V_STTMS_CUST_DOMESTIC.SPOUSE_EMP_STATUS := NULL;
    END IF;

    DBG('Spouse details Defaulted to NULL');

    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.UNADVISED IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.UNADVISED := 'N';
    END IF;

    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.UNADVISED IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.UNADVISED := 'N';
    END IF;

    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE <> 'I' THEN

      IF P_CUST_BASE_REC.V_LMTMS_ISSUER_MASTER.ISSUER_DETAILS IS NULL THEN

        P_CUST_BASE_REC.V_LMTMS_ISSUER_MASTER.ISSUER_DETAILS := P_CUST_BASE_REC.V_STTMS_CUSTOMER.ADDRESS_LINE1 ||
                                                                P_CUST_BASE_REC.V_STTMS_CUSTOMER.ADDRESS_LINE2 ||
                                                                P_CUST_BASE_REC.V_STTMS_CUSTOMER.ADDRESS_LINE3 ||
                                                                P_CUST_BASE_REC.V_STTMS_CUSTOMER.ADDRESS_LINE4;
      END IF;
    END IF;
    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.CLS_CCY_ALLOWED IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.CLS_CCY_ALLOWED := 'D';
    END IF;
    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.FROZEN IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.FROZEN := 'N';
    END IF;
    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.DECEASED IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.DECEASED := 'N';
    END IF;
    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.CONSOL_TAX_CERT_REQD IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.CONSOL_TAX_CERT_REQD := 'N';
    END IF;
    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.WHEREABOUTS_UNKNOWN IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.WHEREABOUTS_UNKNOWN := 'N';
    END IF;
    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.INDIVIDUAL_TAX_CERT_REQD IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.INDIVIDUAL_TAX_CERT_REQD := 'N';
    END IF;
    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.CLS_PARTICIPANT IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.CLS_PARTICIPANT := 'N';
    END IF;

    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.RP_CUSTOMER IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.RP_CUSTOMER := 'N';
    END IF;

    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.AML_REQUIRED IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.AML_REQUIRED := 'N';
    END IF;
    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.UTILITY_PROVIDER IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.UTILITY_PROVIDER := 'N';
    END IF;
    IF P_CUST_BASE_REC.V_STTMS_CUSTOMER.FT_ACCTING_AS_OF IS NULL THEN

      P_CUST_BASE_REC.V_STTMS_CUSTOMER.FT_ACCTING_AS_OF := 'M';
    END IF;

    DBG('End of Defaulting');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_defaulting_for_new_cust as ' || SQLERRM);

      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := 'Failed while defaulting data for customer upload~';
      RETURN FALSE;
  END FN_DEFAULTING_FOR_NEW_CUST;

  FUNCTION FN_POPULATE_TABLES_FOR_NEW(P_FUNCTION_ID IN VARCHAR2,
                                      P_CUST_REC    IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,

                                      P_ERR_CODE   IN OUT VARCHAR2,
                                      P_ERR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_STDCIF_UTIL       STPKS_STDCIF_UTILS_1.TBL_ADDR_BLOCK;
    LINKTOGRP           VARCHAR2(1);
    L_STDCIF_UTIL_TYGRP STPKS_STDCIF_UTILS_0.TY_ABC;
    L_AUTO_AUTH_MENU    VARCHAR2(32767);
    L_AUTO_AUTH_USER    VARCHAR2(32767);
    CNT                 NUMBER;

    TYPE REC_FIELD_VAL IS RECORD(
      REC_FIELD_VAL CSTMS_FUNCTION_USERDEF_FIELDS.FIELD_VAL_1%TYPE);

    L_ERR VARCHAR2(255) := '';

    L_LIAB_NODE VARCHAR2(105);
    L_CCY       VARCHAR2(3);
    L_AMT_CCY   VARCHAR2(3);
    L_IN_CCY    VARCHAR2(3);

    L_FIELD_NAME    UDTMS_FIELDS.FIELD_NAME%TYPE;
    L_DRV_RULE_TYPE UDTMS_FIELDS.DRV_RULE_TYPE%TYPE;
    L_AMENDABLE     UDTMS_FIELDS.AMENDABLE%TYPE;
    L_FIELD_VAL     VARCHAR2(150);
    L_UDF_1         STTM_CUSTOMER.UDF_1%TYPE;
    L_UDF_2         STTM_CUSTOMER.UDF_2%TYPE;
    L_UDF_3         STTM_CUSTOMER.UDF_3%TYPE;
    L_UDF_4         STTM_CUSTOMER.UDF_4%TYPE;
    L_UDF_5         STTM_CUSTOMER.UDF_5%TYPE;
    L_LIAB_BR       VARCHAR2(3);

  BEGIN

    DBG('p_cust_rec.v_sttms_customer.local_branch' ||
        P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH);
    DBG('p_cust_rec.v_sttms_customer.customer_no' ||
        P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO);
    DBG('p_cust_rec.v_sttms_customer.record_stat' ||
        P_CUST_REC.V_STTMS_CUSTOMER.RECORD_STAT);
    DBG('p_cust_rec.v_sttms_customer.auth_stat' ||
        P_CUST_REC.V_STTMS_CUSTOMER.AUTH_STAT);

    BEGIN
      DBG('Insert into sttms_customer ');

      BEGIN

        DBG('Liability number while populating' ||
            P_CUST_REC.V_STTMS_CUSTOMER.LIABILITY_NO);
        DBG('Customer number while populaating' ||
            P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO);
        DBG('Branch Code while populaating' ||
            P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH);

        IF (P_CUST_REC.V_STTMS_CUSTOMER.LIABILITY_NO =
           P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO) THEN

          P_CUST_REC.V_STTMS_CUSTOMER.LIAB_BR := P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH;
        ELSE
          SELECT C.LOCAL_BRANCH
            INTO L_LIAB_BR
            FROM STTMS_CUSTOMER C
           WHERE C.CUSTOMER_NO = P_CUST_REC.V_STTMS_CUSTOMER.LIABILITY_NO;

          DBG('Liab Branch while populating' || L_LIAB_BR);
          P_CUST_REC.V_STTMS_CUSTOMER.LIAB_BR := L_LIAB_BR;
          DBG('liab_br--->' || P_CUST_REC.V_STTMS_CUSTOMER.LIAB_BR);

        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          P_CUST_REC.V_STTMS_CUSTOMER.LIAB_BR := P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH;
          DBG('in exception-liab_br->' ||
              P_CUST_REC.V_STTMS_CUSTOMER.LIAB_BR);

      END;
      BEGIN
        SELECT B.HOST_NAME
          INTO L_LIAB_NODE
          FROM STTMS_BRANCH B
         WHERE B.BRANCH_CODE = P_CUST_REC.V_STTMS_CUSTOMER.LIAB_BR;
        P_CUST_REC.V_STTMS_CUSTOMER.LIAB_NODE := L_LIAB_NODE;
        DBG('liab_node--->' || P_CUST_REC.V_STTMS_CUSTOMER.LIAB_NODE);

      EXCEPTION
        WHEN OTHERS THEN
          P_CUST_REC.V_STTMS_CUSTOMER.LIAB_NODE := GLOBAL.NODE;
          DBG('liab_node-in exception-->' ||
              P_CUST_REC.V_STTMS_CUSTOMER.LIAB_NODE);

      END;
    END;

    DBG('Before mstm_cust_address fxn call jajango');

    L_STDCIF_UTIL(1).TYP_ADDR_MASTER.CUSTOMER_NO := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
    L_STDCIF_UTIL(1).TYP_ADDR_MASTER.LOCATION := NVL(P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE,
                                                     'CIF');
    L_STDCIF_UTIL(1).TYP_ADDR_MASTER.MEDIA := NVL(P_CUST_REC.V_STTMS_CUSTOMER.DEFAULT_MEDIA,
                                                  'MAIL');

    L_STDCIF_UTIL(1).TYP_ADDR_MASTER.ADDRESS1 := P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE1;
    L_STDCIF_UTIL(1).TYP_ADDR_MASTER.ADDRESS2 := P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE2;
    L_STDCIF_UTIL(1).TYP_ADDR_MASTER.ADDRESS3 := P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE3;
    L_STDCIF_UTIL(1).TYP_ADDR_MASTER.ADDRESS4 := P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE4;
    L_STDCIF_UTIL(1).TYP_ADDR_MASTER.COUNTRY := P_CUST_REC.V_STTMS_CUSTOMER.COUNTRY;
    L_STDCIF_UTIL(1).TYP_ADDR_MASTER.NAME := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NAME1;

    L_STDCIF_UTIL(1).TBL_ADDR_DETAIL(1).MSG_TYPE := 'ANY MSG TYPE';
    L_STDCIF_UTIL(1).TBL_ADDR_DETAIL(1).MODULE := 'AL';
    L_STDCIF_UTIL(1).TBL_ADDR_DETAIL(1).LOCATION := L_STDCIF_UTIL(1)
                                                    .TYP_ADDR_MASTER.LOCATION;
    L_STDCIF_UTIL(1).TBL_ADDR_DETAIL(1).MEDIA := L_STDCIF_UTIL(1)
                                                 .TYP_ADDR_MASTER.MEDIA;
    L_STDCIF_UTIL(1).TBL_ADDR_DETAIL(1).CUSTOMER_NO := L_STDCIF_UTIL(1)
                                                       .TYP_ADDR_MASTER.CUSTOMER_NO;

    IF P_CUST_REC.V_STTMS_CUSTOMER.DEFAULT_MEDIA IN ('MAIL', 'SWIFT') THEN
      IF NOT STPKS_STDCIF_UTILS_1.FN_START_ADDRESS_UPLOAD(P_FUNCTION_ID,
                                                          L_STDCIF_UTIL,
                                                          P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN

        DBG('FUNCTION stpkss_cust_address.fn_start_address_upload RETURN FALSE ');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBALS_FRC.FN_GET_SMTB_MENU_REC_WRP('STDCIF',
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
      DBG('Failed in FRC bec of - ' || P_ERR_CODE);
      P_ERR_CODE   := 'ST-UPLD104';
      P_ERR_PARAMS := NULL;
      L_ERR        := L_ERR || P_ERR_CODE;
      RETURN FALSE;
    END IF;
    DBG('Record exists in FRC..');
    L_AUTO_AUTH_MENU := GLOBAL_FRC.G_TBL_SMTB_MENU_DEFN_REC.AUTO_AUTH;
    DBG('l_Auto_Auth_Menu is - ' || L_AUTO_AUTH_MENU);

    SELECT AUTO_AUTH
      INTO L_AUTO_AUTH_USER
      FROM SMTB_USER
     WHERE USER_ID = GLOBAL.USER_ID();
    DBG('curr USER' || GLOBAL.USER_ID());

    IF P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
      DBG('Populating sttms_cust_personal' ||
          P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_NO);
      DBG('Populating sttms_cust_personal1' ||
          P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO);

      DBG('Custprof node exists-->');

      IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.CCY_PERS_INCEXP IS NOT NULL THEN

        L_IN_CCY := P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.CCY_PERS_INCEXP;
      ELSE
        L_IN_CCY := L_CCY;
      END IF;

      P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.CCY_PERS_INCEXP := L_IN_CCY;

      DBG('Before Insert into professional table');

    ELSIF ((P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C') OR
          (P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'B')) THEN

      IF P_CUST_REC.V_STTMS_CUST_CORPORATE.AMOUNTS_CCY IS NOT NULL THEN

        L_AMT_CCY := P_CUST_REC.V_STTMS_CUST_CORPORATE.AMOUNTS_CCY;
      ELSE
        L_AMT_CCY := L_CCY;
      END IF;

      P_CUST_REC.V_STTMS_CUST_CORPORATE.AMOUNTS_CCY := L_AMT_CCY;
    END IF;
    DBG('Customer Group Upload');

    IF P_CUST_REC.V_STTMS_CUST_GROUP.COUNT > 0 THEN

      DELETE FROM STTMS_CUST_GROUP
       WHERE CUSTOMER_NO = P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;

      FOR L_CORP_GRP IN P_CUST_REC.V_STTMS_CUST_GROUP.FIRST .. P_CUST_REC.V_STTMS_CUST_GROUP.LAST LOOP

        DBG('Inside Loop of Customer Group');

      END LOOP;

      DBG(' insert into group table ');

      DBG(' No.of rows inserted ' || SQL%ROWCOUNT);

    END IF;

    DBG('Before insert into Join table');
    IF P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.COUNT > 0 THEN

      FOR L_CUST_PERS_JOINT IN P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.FIRST .. P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.LAST LOOP

        DBG('Inside Personal Joint');

        IF P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(L_CUST_PERS_JOINT)
         .CUSTOMER_NO <> P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO THEN

          P_ERR_CODE   := 'IF-UPL-20';
          P_ERR_PARAMS := 'JNT' || '~' ||
                          P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO || '~' || P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(L_CUST_PERS_JOINT)
                         .CUSTOMER_NO || '~';

          DBG('customer no mismatch in sttms_upload_personal_joint ');
          RETURN FALSE;
        END IF;
      END LOOP;

      DBG(' insert into sttms_cust_personal_joint table ');

    END IF;

    DBG('p_Cust_Rec.ty_cust_mt920_upld.Count is ' ||
        P_CUST_REC.V_STTMS_CUST_MT920_MAINT.COUNT);
    IF P_CUST_REC.V_STTMS_CUST_MT920_MAINT.COUNT > 0 THEN

      FOR I IN P_CUST_REC.V_STTMS_CUST_MT920_MAINT.FIRST .. P_CUST_REC.V_STTMS_CUST_MT920_MAINT.LAST LOOP

        DBG('Inside Personal Joint');

        IF P_CUST_REC.V_STTMS_CUST_MT920_MAINT(I)
         .CUSTOMER_NO <> P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO THEN

          P_ERR_CODE   := 'IF-UPL-20';
          P_ERR_PARAMS := 'JNT' || '~' ||
                          P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO || '~' || P_CUST_REC.V_STTMS_CUST_MT920_MAINT(I)
                         .CUSTOMER_NO || '~';

          DBG('customer no mismatch in sttms_cust_mt920_maint ');
          RETURN FALSE;
        END IF;
      END LOOP;
    END IF;

    FOR I IN 1 .. 5 LOOP

      DBG('for seq no - ' || I);

      L_FIELD_NAME := NULL;

      BEGIN
        SELECT FIELD_NAME
          INTO L_FIELD_NAME
          FROM STTMS_BASE_TABLE_UDF_DETAIL
         WHERE FUNCTION_ID = 'STDCIF'
           AND SEQ_NO = I
           AND EXISTS (SELECT 1

                  FROM STTMS_BASE_TABLE_UDF_MASTER
                 WHERE FUNCTION_ID = 'STDCIF'
                   AND ONCE_AUTH = 'Y');

      EXCEPTION
        WHEN OTHERS THEN
          DBG('no UDF associated for seq no - ' || I || ' - ' || SQLERRM);

      END;

      DBG('for seq no - ' || I || '->' || L_FIELD_NAME);

      IF L_FIELD_NAME IS NOT NULL THEN
        SELECT DRV_RULE_TYPE, AMENDABLE
          INTO L_DRV_RULE_TYPE, L_AMENDABLE

          FROM UDTMS_FIELDS
         WHERE FIELD_NAME = L_FIELD_NAME;

        IF NVL(L_DRV_RULE_TYPE, 'N') = 'Y' AND L_AMENDABLE = 'N' THEN

          L_FIELD_VAL := NULL;

          IF NOT UDPKS_BASE_TABLE_UDF.FN_GET_DRV_FIELDS('~' ||
                                                        P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO || '~'

                                                       ,
                                                        L_FIELD_NAME,
                                                        L_FIELD_VAL,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN

            DBG('validation failed for udf_1');
          END IF;

          IF I = 1 THEN

            L_UDF_1 := L_FIELD_VAL;
          ELSIF I = 2 THEN

            L_UDF_2 := L_FIELD_VAL;
          ELSIF I = 3 THEN

            L_UDF_3 := L_FIELD_VAL;
          ELSIF I = 4 THEN

            L_UDF_4 := L_FIELD_VAL;
          ELSIF I = 5 THEN

            L_UDF_5 := L_FIELD_VAL;
          END IF;
        ELSE
          IF I = 1 THEN

            L_UDF_1 := P_CUST_REC.V_STTMS_CUSTOMER.UDF_1;
          ELSIF I = 2 THEN

            L_UDF_2 := P_CUST_REC.V_STTMS_CUSTOMER.UDF_2;
          ELSIF I = 3 THEN

            L_UDF_3 := P_CUST_REC.V_STTMS_CUSTOMER.UDF_3;
          ELSIF I = 4 THEN

            L_UDF_4 := P_CUST_REC.V_STTMS_CUSTOMER.UDF_4;
          ELSIF I = 5 THEN

            L_UDF_5 := P_CUST_REC.V_STTMS_CUSTOMER.UDF_5;
          END IF;
        END IF;
      END IF;
    END LOOP;

    DBG('JOKES APART');

    UPDATE STTMS_CUSTOMER
       SET UDF_1 = L_UDF_1,
           UDF_2 = L_UDF_2,
           UDF_3 = L_UDF_3,
           UDF_4 = L_UDF_4,
           UDF_5 = L_UDF_5
     WHERE CUSTOMER_NO = P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;

    DBG('Calling upload relationship');

    DBG('Through with populating tables');

    RETURN TRUE;

  EXCEPTION

    WHEN OTHERS THEN

      DBG('Failed in WOT of fn_populate_tables_for_new and ORACLE error is ' ||
          SQLERRM);

      P_ERR_CODE   := 'ST-UPLD104';
      P_ERR_PARAMS := SQLERRM;
      L_ERR        := L_ERR || P_ERR_CODE;
      RETURN FALSE;

  END FN_POPULATE_TABLES_FOR_NEW;

  FUNCTION FN_UPLOAD_NEW_CUSTOMER(P_FUNCTION_ID    IN VARCHAR2,
                                  P_CUST_REC       IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                  P_USER_ID        IN VARCHAR2,
                                  P_OVERRIDE_FLAG  OUT VARCHAR2,
                                  P_AUTO_AUTH_FLAG OUT VARCHAR2,
                                  P_REC_MSG_HEADER IN GWPKS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                                  P_CUST_BASE_REC  IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                  P_ERR_CODE       IN OUT VARCHAR2,
                                  P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN
    DBG('Inside upload function fn_upload_cust');
    DBG('p_cust_rec.v_sttms_customer.local_branch ' ||
        P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH);

    DBG('p_Cust_Rec.v_sttms_customer.Liability_No==>' ||
        P_CUST_REC.V_STTMS_CUSTOMER.LIABILITY_NO);

    DBG('Calling fn_mandatory_for_new.');
    DBG('in the begin p_cust_rec.v_sttms_customer.LANGUAGE  ' ||
        P_CUST_REC.V_STTMS_CUSTOMER.LANGUAGE);
    IF NOT FN_MANDATORY_FOR_NEW(P_FUNCTION_ID,
                                P_CUST_REC,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN

      DBG('fn_mandatory_for_new has failed with:  ' || P_ERR_CODE);
      RETURN FALSE;
    END IF;
    DBG('p_Cust_Rec.v_sttms_customer.Liability_No==>' ||
        P_CUST_REC.V_STTMS_CUSTOMER.LIABILITY_NO);

    DBG('Calling fn_gen_n_validate_cif');
    IF NOT FN_GEN_N_VALIDATE_CIF(P_FUNCTION_ID,
                                 P_CUST_REC,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN

      DBG('Error in Generating Customer Number');
      RETURN FALSE;
    END IF;
    DBG('p_Cust_Rec.v_sttms_customer.Liability_No==>' ||
        P_CUST_REC.V_STTMS_CUSTOMER.LIABILITY_NO);

    IF NOT FN_VALIDATE_RECORDS(P_FUNCTION_ID,
                               P_CUST_REC,
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
      DBG('Failed in upload... ' || P_ERR_CODE || '....' || P_ERR_PARAMS);

      RETURN FALSE;
    END IF;
    DBG('p_Cust_Rec.v_sttms_customer.Liability_No==>' ||
        P_CUST_REC.V_STTMS_CUSTOMER.LIABILITY_NO);

    IF NOT FN_DEFAULTING_FOR_NEW_CUST(P_CUST_REC,
                                      P_USER_ID,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN

      DBG(' Defaulting Failed ');
      P_ERR_CODE := P_ERR_CODE || 'Default_check';
      RETURN FALSE;
    END IF;
    DBG('p_Cust_Rec.v_sttms_customer.Liability_No==>' ||
        P_CUST_REC.V_STTMS_CUSTOMER.LIABILITY_NO);

    IF NOT FN_POPULATE_TABLES_FOR_NEW(P_FUNCTION_ID,
                                      P_CUST_REC,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      DBG('Function to update tables failed');
      RETURN FALSE;
    END IF;

    DBG('p_Cust_Rec.v_sttms_customer.Liability_No==>' ||
        P_CUST_REC.V_STTMS_CUSTOMER.LIABILITY_NO);

    DBG('p_rec_msg_header.moduleid' || P_REC_MSG_HEADER.SOURCE);
    DBG('p_rec_msg_header.moduleid' || P_REC_MSG_HEADER.MODULEID);
    DBG('fn_upload_cust Return true ');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in fn_upload_new_customer - WOT - ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while uploading the customer details~';
      RETURN FALSE;
  END FN_UPLOAD_NEW_CUSTOMER;
  FUNCTION FN_UPLOAD_NEW_CUSTOMER(P_FUNCTION_ID    IN VARCHAR2,
                                  P_CUST_REC       IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                  P_USER_ID        IN VARCHAR2,
                                  P_OVERRIDE_FLAG  OUT VARCHAR2,
                                  P_REC_MSG_HEADER IN GWPKS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                                  P_ERR_CODE       IN OUT VARCHAR2,
                                  P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_RET            BOOLEAN := FALSE;
    L_AUTO_AUTH_FLAG VARCHAR2(1);
    L_CUST_BASE_REC  STPKS_STDCIF_MAIN.TY_STDCIF;

  BEGIN
    L_RET := FN_UPLOAD_NEW_CUSTOMER(P_FUNCTION_ID,
                                    P_CUST_REC,
                                    P_USER_ID,
                                    P_OVERRIDE_FLAG,
                                    L_AUTO_AUTH_FLAG,
                                    P_REC_MSG_HEADER,
                                    L_CUST_BASE_REC,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS);

    RETURN L_RET;

  END FN_UPLOAD_NEW_CUSTOMER;

  FUNCTION FN_PICKUP(P_FUNCTION_ID IN VARCHAR2,
                     P_CUSTNO      IN STTMS_CUSTOMER.CUSTOMER_NO%TYPE,
                     P_STDCIF      IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                     P_KEY         IN OUT VARCHAR2,
                     P_PARENT      IN OUT VARCHAR2,
                     P_FORMAT      IN OUT VARCHAR2,
                     P_NODE        IN OUT VARCHAR2,
                     G_CNT_LVL2    IN OUT NUMBER,
                     P_ERRS        IN OUT VARCHAR2,
                     P_PRMS        IN OUT VARCHAR2) RETURN BOOLEAN IS
    TIME1 VARCHAR2(20);
    TIME2 VARCHAR2(20);
    I     NUMBER;
    J     NUMBER;

    CURSOR C_CUST_MIS IS
      SELECT *
        FROM GLTMS_MIS_CLASS
       WHERE MIS_TYPE = 'C'
         AND ONCE_AUTH = 'Y'
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
       ORDER BY CLASS_NUM;

    CURSOR C_CORP_MIS IS
      SELECT *
        FROM GLTMS_MIS_CLASS
       WHERE MIS_TYPE = 'O'
         AND ONCE_AUTH = 'Y'
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'

       ORDER BY CLASS_NUM;

  BEGIN

    DBG('Inside fn_pickup');

    SELECT TO_CHAR(SYSTIMESTAMP, 'HH:MI:SS.FF3') INTO TIME1 FROM DUAL;

    DBG('Time Before MIS Pickup' || TIME1);

    I := 0;
    FOR REC IN C_CUST_MIS LOOP

      I := I + 1;
      DBG('value of i' || I);
      P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I).KEY_ID := P_CUSTNO;
      P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_TYPE := 'C';
      P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CLASS := REC.MIS_CLASS;

      IF P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CODE IS NOT NULL THEN
        DBG('MIS Code in pick up' || P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I)
            .MIS_CODE);

      END IF;

      IF REC.CLASS_NUM = 1 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_1 := P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 2 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_2 := P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 3 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_3 := P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 4 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_4 := P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 5 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_5 := P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 6 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_6 := P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 7 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_7 := P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 8 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_8 := P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 9 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_9 := P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 10 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_10 := P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(I)
                                                                     .MIS_CODE;
      END IF;

    END LOOP;

    J := 0;
    FOR REC IN C_CORP_MIS LOOP

      J := J + 1;

      P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).KEY_ID := P_CUSTNO;
      P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_TYPE := 'O';
      P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_CLASS := REC.MIS_CLASS;

      IF REC.CLASS_NUM = 1 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_1 := P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 2 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_2 := P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 3 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_3 := P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 4 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_4 := P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 5 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_5 := P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 6 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_6 := P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 7 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_7 := P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 8 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_8 := P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 9 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_9 := P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J)
                                                                    .MIS_CODE;
      ELSIF REC.CLASS_NUM = 10 THEN
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_10 := P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(J)
                                                                     .MIS_CODE;
      END IF;
    END LOOP;

    SELECT TO_CHAR(SYSTIMESTAMP, 'HH:MI:SS.FF3') INTO TIME2 FROM DUAL;

    DBG('Time After MIS Pickup' || TIME2);
    DBG('End of Function fn_pickup');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('Error Inside Function fn_pickup' || SQLERRM);
      P_ERRS := 'ST-OTHR-001';
      P_PRMS := NULL;
      RETURN FALSE;
  END FN_PICKUP;

  FUNCTION FN_PICKUP_MICCUSTM(P_FUNCTION_ID  IN VARCHAR2,
                              P_CUSTNO       IN STTMS_CUSTOMER.CUSTOMER_NO%TYPE,
                              P_WRK_MICCUSTM IN OUT MIPKS_MICCUSTM_MAIN.TY_MICCUSTM,
                              P_KEY          IN OUT VARCHAR2,
                              P_PARENT       IN OUT VARCHAR2,
                              P_FORMAT       IN OUT VARCHAR2,
                              P_NODE         IN OUT VARCHAR2,
                              G_CNT_LVL2     IN OUT NUMBER,
                              P_ERRS         IN OUT VARCHAR2,
                              P_PRMS         IN OUT VARCHAR2) RETURN BOOLEAN IS

    TIME1 VARCHAR2(20);
    TIME2 VARCHAR2(20);
    I     NUMBER;
    J     NUMBER;

    K                       NUMBER := 1;
    L_CLASS_NAME            VARCHAR2(20);
    L_MITM_CUSTOMER_DEFAULT MITM_CUSTOMER_DEFAULT%ROWTYPE;

    CURSOR C_CUST_MIS IS
      SELECT *
        FROM GLTMS_MIS_CLASS
       WHERE MIS_TYPE = 'C'
         AND ONCE_AUTH = 'Y'
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
       ORDER BY CLASS_NUM;

    CURSOR C_CORP_MIS IS
      SELECT *
        FROM GLTMS_MIS_CLASS
       WHERE MIS_TYPE = 'O'
         AND ONCE_AUTH = 'Y'
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
       ORDER BY CLASS_NUM;

    PROCEDURE MIS_CLASS(CLASS_NAME IN OUT VARCHAR2, CLASS_NUM2 IN NUMBER) IS
      L_CLASS_NAME VARCHAR2(10);
    BEGIN
      DBG('inside class finder' || CLASS_NUM2);
      SELECT MIS_CLASS
        INTO L_CLASS_NAME
        FROM GLTMS_MIS_CLASS
       WHERE MIS_TYPE = 'C'
         AND ONCE_AUTH = 'Y'
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
         AND CLASS_NUM = CLASS_NUM2;
      CLASS_NAME := L_CLASS_NAME;
      DBG('inside class finder' || L_CLASS_NAME);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        CLASS_NAME := NULL;
    END;

    PROCEDURE MIS_CLASS_PAINT_ON_SCREEN(L_CLASS_NAME IN OUT VARCHAR2,
                                        K_INDEX      NUMBER,
                                        L_MIS_CODE   VARCHAR2) IS

    BEGIN
      DBG('inside class painter' || L_CLASS_NAME);

      P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(K_INDEX).KEY_ID := P_CUSTNO;
      P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(K_INDEX).MIS_TYPE := 'C';
      P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(K_INDEX).MIS_CLASS := L_CLASS_NAME;
      P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(K_INDEX).MIS_CODE := L_MIS_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('failed in inside class painter');
    END;

  BEGIN

    DBG('Inside FN_PICKUP_MICCUSTM');

    IF STPKS_STDCUSVW_KERNEL.G_PICK_MIS_DTLS THEN

      SELECT TO_CHAR(SYSTIMESTAMP, 'HH:MI:SS.FF3') INTO TIME1 FROM DUAL;

      DBG('Time Before MIS Pickup' || TIME1);

      DBG('check the action code' || CSPKS_REQ_WRAPPER.G_ACTION_CODE);

      BEGIN
        SELECT *
          INTO L_MITM_CUSTOMER_DEFAULT
          FROM MITM_CUSTOMER_DEFAULT
         WHERE CUSTOMER = P_CUSTNO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          DBG('Failed in selecting the Record for :mitm_customer_default');
      END;

      I := 0;
      FOR REC IN C_CUST_MIS LOOP
        I := I + 1;
        P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).KEY_ID := P_CUSTNO;
        P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_TYPE := 'C';
        P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CLASS := REC.MIS_CLASS;

        IF REC.CLASS_NUM = 1 THEN

          P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.CUST_MIS_1;
        ELSIF REC.CLASS_NUM = 2 THEN
          P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.CUST_MIS_2;

        ELSIF REC.CLASS_NUM = 3 THEN
          P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.CUST_MIS_3;

        ELSIF REC.CLASS_NUM = 4 THEN
          P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.CUST_MIS_4;

        ELSIF REC.CLASS_NUM = 5 THEN
          P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.CUST_MIS_5;

        ELSIF REC.CLASS_NUM = 6 THEN
          P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.CUST_MIS_6;
        ELSIF REC.CLASS_NUM = 7 THEN
          P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.CUST_MIS_7;

        ELSIF REC.CLASS_NUM = 8 THEN
          P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.CUST_MIS_8;

        ELSIF REC.CLASS_NUM = 9 THEN
          P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.CUST_MIS_9;

        ELSIF REC.CLASS_NUM = 10 THEN
          P_WRK_MICCUSTM.V_MITMS_DEFAULT_CODES(I).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.CUST_MIS_10;
        END IF;

      END LOOP;

      J := 0;
      FOR REC IN C_CORP_MIS LOOP
        J := J + 1;

        P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).KEY_ID := P_CUSTNO;
        P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_TYPE := 'O';
        P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_CLASS := REC.MIS_CLASS;

        IF REC.CLASS_NUM = 1 THEN

          P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.COMP_MIS_1;
        ELSIF REC.CLASS_NUM = 2 THEN
          P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.COMP_MIS_2;
        ELSIF REC.CLASS_NUM = 3 THEN
          P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.COMP_MIS_3;
        ELSIF REC.CLASS_NUM = 4 THEN
          P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.COMP_MIS_4;
        ELSIF REC.CLASS_NUM = 5 THEN
          P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.COMP_MIS_5;
        ELSIF REC.CLASS_NUM = 6 THEN
          P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.COMP_MIS_6;
        ELSIF REC.CLASS_NUM = 7 THEN
          P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.COMP_MIS_7;
        ELSIF REC.CLASS_NUM = 8 THEN
          P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.COMP_MIS_8;
        ELSIF REC.CLASS_NUM = 9 THEN
          P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.COMP_MIS_9;
        ELSIF REC.CLASS_NUM = 10 THEN
          P_WRK_MICCUSTM.V_MITM_DEFAULT_CODES__C(J).MIS_CODE := L_MITM_CUSTOMER_DEFAULT.COMP_MIS_10;
        END IF;

      END LOOP;

      SELECT TO_CHAR(SYSTIMESTAMP, 'HH:MI:SS.FF3') INTO TIME2 FROM DUAL;

      DBG('Time After MIS Pickup' || TIME2);
      STPKS_STDCUSVW_KERNEL.G_PICK_MIS_DTLS := FALSE;
    END IF;

    DBG('Inside FN_PICKUP_MICCUSTM');

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Error Inside Function fn_pickup' || SQLERRM);
      P_ERRS := 'ST-OTHR-001';
      P_PRMS := NULL;
      RETURN FALSE;

  END FN_PICKUP_MICCUSTM;

  FUNCTION FN_MANDATORY_FOR_MODIFY(P_CUST_REC   IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                   P_ERR_CODE   IN OUT VARCHAR2,
                                   P_ERR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('calling stpks_stdcif_utils_0_cluster.Fn_Pre_Mandatory_For_Modify');
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_PRE_MANDATORY_FOR_MODIFY(P_CUST_REC,
                                                                   P_ERR_CODE,
                                                                   P_ERR_PARAMS) THEN
        DBG('Failed in call to stpks_stdcif_utils_0_cluster.Fn_Pre_Mandatory_For_Modify');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('Entered the function fn_mandatory_for_modify');

      IF P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE1 IS NULL THEN

        DBG('The mandatory element address line 1 is missing ');
        P_ERR_CODE   := 'ST-MAN01';
        P_ERR_PARAMS := 'Address line 1~';
        RETURN FALSE;
      END IF;

    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    DBG('fn_mandatory_for_modify: About to RETURN TRUE');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_mandatory_for_modify as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := 'Failed while checking the presence of the mandatory fields~';
      RETURN FALSE;
  END FN_MANDATORY_FOR_MODIFY;

  FUNCTION FN_DEFAULTING_CUST_NO(P_CUST_REC     IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                 P_CUST_REC_REG IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                 P_ERR_CODE     OUT ERTB_MSGS.ERR_CODE%TYPE,
                                 P_ERR_PARAMS   OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS

  BEGIN
    DBG('Inside the function fn_defaulting_cust_no');

    IF P_CUST_REC_REG.V_STTMS_CUSTOMER.CUSTOMER_NO IS NULL AND
       P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO IS NOT NULL THEN

      P_CUST_REC_REG.V_STTMS_CUSTOMER.CUSTOMER_NO := P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
    ELSIF P_CUST_REC_REG.V_STTMS_CUSTOMER.CUSTOMER_NO IS NULL AND
          P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO IS NULL AND
          P_CUST_REC.V_STTMS_CUSTOMER.EXT_REF_NO IS NOT NULL THEN

      DBG('while selecting the customer no');
      BEGIN
        SELECT CUSTOMER_NO
          INTO P_CUST_REC_REG.V_STTMS_CUSTOMER.CUSTOMER_NO
          FROM STTMS_CUSTOMER
         WHERE EXT_REF_NO = P_CUST_REC.V_STTMS_CUSTOMER.EXT_REF_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Invalid EXT REF NO ');
          P_ERR_CODE   := 'ST-CUST0040';
          P_ERR_PARAMS := '';
          RETURN FALSE;
      END;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_defaulting_cust_no as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := 'Failed while defaulting customer no~';
      RETURN FALSE;
  END FN_DEFAULTING_CUST_NO;

  FUNCTION FN_DEFAULTING_FOR_MODIFY_CUST(P_CUST_REC     IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                         P_CUST_REC_REG IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                         P_USER_ID      IN VARCHAR2,
                                         P_ERR_CODE     OUT ERTB_MSGS.ERR_CODE%TYPE,
                                         P_ERR_PARAMS   OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS

  BEGIN
    DBG('ext ref no is ' || P_CUST_REC.V_STTMS_CUSTOMER.EXT_REF_NO);

    DBG('the selected customer no is ' ||
        P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO);

    IF P_CUST_REC_REG.V_STTMS_CUSTOMER.AML_REQUIRED = 'Y' THEN

      P_CUST_REC_REG.V_STTMS_CUSTOMER.AML_CUSTOMER_GRP := P_CUST_REC_REG.V_STTMS_CUSTOMER.CUSTOMER_NO;
    ELSE
      P_CUST_REC_REG.V_STTMS_CUSTOMER.AML_CUSTOMER_GRP := NULL;
    END IF;
    DBG('AML CUSTOMER GRP Defaulted');

    IF P_CUST_REC_REG.V_STTMS_CUSTOMER.UTILITY_PROVIDER <> 'Y' THEN

      P_CUST_REC_REG.V_STTMS_CUSTOMER.CHK_DIGIT_VALID_REQD := 'N';
      P_CUST_REC_REG.V_STTMS_CUSTOMER.ALG_ID               := NULL;
    END IF;

    IF P_CUST_REC_REG.V_STTMS_CUSTOMER.CHK_DIGIT_VALID_REQD <> 'Y' THEN

      P_CUST_REC_REG.V_STTMS_CUSTOMER.ALG_ID := NULL;
    END IF;

    IF P_CUST_REC_REG.V_STTMS_CUST_DOMESTIC.MARITAL_STATUS = 'S' THEN

      P_CUST_REC_REG.V_STTMS_CUST_DOMESTIC.SPOUSE_NAME       := NULL;
      P_CUST_REC_REG.V_STTMS_CUST_DOMESTIC.SPOUSE_EMP_STATUS := 'O';
    END IF;

    DBG('End of Defaulting');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_defaulting_for_modify_cust as ' || SQLERRM);

      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := 'Failed while defaulting data for amendment of customer~';
      RETURN FALSE;
  END FN_DEFAULTING_FOR_MODIFY_CUST;

  FUNCTION FN_CHK_NOT_NULL(P_FUNCTION_ID IN VARCHAR2,
                           P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                           P_ERR_CODE    IN OUT VARCHAR2,
                           P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

  BEGIN

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('calling stpks_stdcif_utils_0_cluster.Fn_Pre_Chk_Not_Null');
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_PRE_CHK_NOT_NULL(P_FUNCTION_ID,
                                                           P_CUST_REC,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
        DBG('Failed in call to stpks_stdcif_utils_0_cluster.Fn_Pre_Chk_Not_Null');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('Inside the function fn_chk_not_null');

      IF P_CUST_REC.V_STTMS_CUSTOMER.LANGUAGE IS NULL THEN

        DBG('Language is null');
        P_ERR_CODE := 'ST-MAN013';

        P_ERR_PARAMS := '@STTMS_CUSTOMER.LANGUAGE~';
        RETURN FALSE;
      END IF;
      IF P_CUST_REC.V_STTMS_CUSTOMER.COUNTRY IS NULL THEN

        DBG('Country is null');
        P_ERR_CODE := 'ST-MAN014';

        P_ERR_PARAMS := '@STTMS_CUSTOMER.COUNTRY~';
        RETURN FALSE;
      END IF;
      IF NVL(P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE, 'I') = 'I' THEN
        IF P_CUST_REC.V_STTMS_CUSTOMER.NATIONALITY IS NULL THEN

          DBG('Nationality is null');
          P_ERR_CODE := 'ST-MAN015';

          P_ERR_PARAMS := '@STTMS_CUSTOMER.NATIONALITY~';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        END IF;
      END IF;
      IF P_CUST_REC.V_STTMS_CUSTOMER.EXPOSURE_COUNTRY IS NULL THEN

        DBG('Exposure_Country is null');

        P_ERR_CODE   := 'ST-EXPCNT01';
        P_ERR_PARAMS := '@STTMS_CUSTOMER.EXPOSURE_COUNTRY~';

      END IF;
      IF P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE1 IS NULL THEN

        DBG('Address_Line1 is null');
        P_ERR_CODE := 'ST-MAN017';

        P_ERR_PARAMS := '@STTMS_CUSTOMER.ADDRESS_LINE1~';
        RETURN FALSE;
      END IF;

      IF (P_ERR_CODE IS NOT NULL) THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        DBG('coyote');
      END IF;

    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    DBG('fn_chk_not_null: About to RETURN TRUE');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while chking the fields for not null before updating ~';
      RETURN FALSE;
  END FN_CHK_NOT_NULL;

  FUNCTION FN_UPLOAD_MODIFY_CUSTOMER(P_FUNCTION_ID      IN VARCHAR2,
                                     P_CUST_REC         IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                     P_SOURCE           IN VARCHAR2,
                                     P_SOURCE_OPERATION IN VARCHAR2,
                                     P_REC_MSG_HEADER   IN GWPKS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                                     P_AUTO_AUTH_FLAG   OUT VARCHAR2,
                                     P_CUST_BASE_REC    IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                     P_ERR_CODE         IN OUT VARCHAR2,
                                     P_OVERRIDE_FLAG    IN OUT VARCHAR2,
                                     P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_INVALID_CHAR VARCHAR2(50);

    L_CUST_REC STPKS_STDCIF_MAIN.TY_STDCIF;
  BEGIN

    PR_SKIP_HANDLER('Pre_Upload_Modify_Customer');
    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CUSTOM THEN
      DBG('Calling stpks_stdcif_utils_0_custom.Fn_Pre_Upload_Modify_Customer..');
      IF NOT
          STPKS_STDCIF_UTILS_0_CUSTOM.FN_PRE_UPLOAD_MODIFY_CUSTOMER(P_FUNCTION_ID,
                                                                    P_CUST_REC,
                                                                    P_SOURCE,
                                                                    P_SOURCE_OPERATION,
                                                                    P_REC_MSG_HEADER,
                                                                    P_AUTO_AUTH_FLAG,
                                                                    P_CUST_BASE_REC,
                                                                    P_ERR_CODE,
                                                                    P_OVERRIDE_FLAG,
                                                                    P_ERR_PARAMS) THEN
        DBG('Failed in stpks_stdcif_utils_0_custom.Fn_Pre_Upload_Modify_Customer..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CLUSTER THEN
      DBG('Calling stpks_stdcif_utils_0_cluster.Fn_Pre_Upload_Modify_Customer..');
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_PRE_UPLOAD_MODIFY_CUSTOMER(P_FUNCTION_ID,
                                                                     P_CUST_REC,
                                                                     P_SOURCE,
                                                                     P_SOURCE_OPERATION,
                                                                     P_REC_MSG_HEADER,
                                                                     P_AUTO_AUTH_FLAG,
                                                                     P_CUST_BASE_REC,
                                                                     P_ERR_CODE,
                                                                     P_OVERRIDE_FLAG,
                                                                     P_ERR_PARAMS) THEN
        DBG('Failed in stpks_stdcif_utils_0_cluster.Fn_Pre_Upload_Modify_Customer..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_KERNEL THEN

      DBG('Entered fn_upload_modify_customer..');
      DBG('in the begin p_cust_rec.v_sttms_customer.LANGUAGE  ' ||
          P_CUST_REC.V_STTMS_CUSTOMER.LANGUAGE);

      IF NOT FN_MANDATORY_FOR_MODIFY(P_CUST_REC, P_ERR_CODE, P_ERR_PARAMS) THEN

        DBG('fn_mandatory_for_modify returned false');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        RETURN FALSE;
      END IF;
      DBG('in the begin p_cust_rec.v_sttms_customer.LANGUAGE 3 ' ||
          P_CUST_REC.V_STTMS_CUSTOMER.LANGUAGE);
      IF NOT FN_DEFAULTING_CUST_NO(P_CUST_REC,
                                   L_CUST_REC,
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN

        DBG('Failed in fn_defaulting_cust_no');
        RETURN FALSE;
      END IF;
      P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO := L_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      DBG('in the begin p_cust_rec.v_sttms_customer.LANGUAGE 4 ' ||
          P_CUST_REC.V_STTMS_CUSTOMER.LANGUAGE);
      IF NOT FN_VALIDATE_RECORDS(P_FUNCTION_ID,
                                 P_CUST_REC,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN

        DBG('Failed in fn_validate_records');
        RETURN FALSE;
      END IF;
      DBG('in the begin p_cust_rec.v_sttms_customer.LANGUAGE5  ' ||
          P_CUST_REC.V_STTMS_CUSTOMER.LANGUAGE);

      DBG('in the begin p_cust_rec.v_sttms_customer.LANGUAGE5  ' ||
          P_CUST_REC.V_STTMS_CUSTOMER.LANGUAGE);
      DBG(' p_cust_base_rec.v_sttms_customer.customer_no... ' ||
          P_CUST_BASE_REC.V_STTMS_CUSTOMER.CUSTOMER_NO);

      IF (P_CUST_REC.V_STTMS_CUSTOMER.DEFAULT_MEDIA = 'SWIFT' AND
         P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE <> 'I' AND

         P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE1 IS NOT NULL AND
         (LENGTH(P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE1) <> 8 AND
         LENGTH(P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE1) <> 11)) THEN

        DBG('Address1 not compatible with Swift Format.');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'MS-00029', NULL);
        RETURN FALSE;
      END IF;

      IF P_CUST_REC.V_STTMS_CUSTOMER.DEFAULT_MEDIA = 'SWIFT' THEN
        L_INVALID_CHAR := STPKS_FCMAINT_UTILS.FN_VALIDATE_RESTR_TEXT(P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE1);
        IF L_INVALID_CHAR IS NOT NULL THEN

          IF L_INVALID_CHAR = '@' THEN
            L_INVALID_CHAR := '@@';
          END IF;
          DBG('Invalid Character....:' || L_INVALID_CHAR);
          P_ERR_CODE   := 'ST-VALS-014';
          P_ERR_PARAMS := L_INVALID_CHAR || '~' ||
                          P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE1 || '~' ||
                          '@STTMS_CUSTOMER.ADDRESS_LINE1';

          RETURN FALSE;
        END IF;
      END IF;

      IF NOT FN_DEFAULTING_FOR_MODIFY_CUST(P_CUST_REC,
                                           P_CUST_REC,
                                           P_REC_MSG_HEADER.USER_ID,
                                           P_ERR_CODE,
                                           P_ERR_PARAMS) THEN

        DBG('Failed in fn_defaulting_for_modify_cust');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        RETURN FALSE;
      END IF;

      IF NOT FN_CHK_NOT_NULL(P_FUNCTION_ID,
                             P_CUST_REC,
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN

        DBG('Failed while forming the final data for modification');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        RETURN FALSE;
      END IF;
      DBG('writhing in pain');
      DBG('fn_upload_modify_customer: About to RETURN TRUE');
      P_CUST_REC := L_CUST_REC;
      RETURN TRUE;

    END IF;
    PR_SKIP_HANDLER('Post_Upload_Modify_Customer');
    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CLUSTER THEN
      DBG('Calling stpks_stdcif_utils_0_cluster.Fn_Post_Upload_Modify_Customer..');
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_POST_UPLOAD_MODIFY_CUSTOMER(P_FUNCTION_ID,
                                                                      P_CUST_REC,
                                                                      P_SOURCE,
                                                                      P_SOURCE_OPERATION,
                                                                      P_REC_MSG_HEADER,
                                                                      P_AUTO_AUTH_FLAG,
                                                                      P_CUST_BASE_REC,
                                                                      P_ERR_CODE,
                                                                      P_OVERRIDE_FLAG,
                                                                      P_ERR_PARAMS) THEN
        DBG('Failed in stpks_stdcif_utils_0_cluster.Fn_Post_Upload_Modify_Customer..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CUSTOM THEN
      DBG('Calling stpks_stdcif_utils_0_custom.Fn_Post_Upload_Modify_Customer..');
      IF NOT
          STPKS_STDCIF_UTILS_0_CUSTOM.FN_POST_UPLOAD_MODIFY_CUSTOMER(P_FUNCTION_ID,
                                                                     P_CUST_REC,
                                                                     P_SOURCE,
                                                                     P_SOURCE_OPERATION,
                                                                     P_REC_MSG_HEADER,
                                                                     P_AUTO_AUTH_FLAG,
                                                                     P_CUST_BASE_REC,
                                                                     P_ERR_CODE,
                                                                     P_OVERRIDE_FLAG,
                                                                     P_ERR_PARAMS) THEN
        DBG('Failed in stpks_stdcif_utils_0_custom.Fn_Post_Upload_Modify_Customer..');
        RETURN FALSE;
      END IF;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_upload_modify_customer as ' || SQLERRM);

      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := 'Failed in modifying the customer details~';
      RETURN FALSE;
  END FN_UPLOAD_MODIFY_CUSTOMER;

  FUNCTION FN_DEFAULT_MIS_CHANGELOG(P_WRK_MICCUSTM  IN OUT MIPKS_MICCUSTM_MAIN.TY_MICCUSTM,
                                    P_PREV_MICCUSTM IN MIPKS_MICCUSTM_MAIN.TY_MICCUSTM)
    RETURN BOOLEAN IS

    L_MIS_TYPE     GLTMS_MIS_CLASS.MIS_TYPE%TYPE;
    L_CLASS_NUM    GLTMS_MIS_CLASS.CLASS_NUM%TYPE;
    L_OLD_MIS_CODE MITBS_CLASS_MAPPING.COMP_MIS_1%TYPE;
    L_NEW_MIS_CODE MITBS_CLASS_MAPPING.COMP_MIS_1%TYPE;

    FUNCTION FN_UPDATE_CHANGE_LOG(P_MIS_TYPE     IN GLTMS_MIS_CLASS.MIS_TYPE%TYPE,
                                  P_CLASS_NUM    IN GLTMS_MIS_CLASS.CLASS_NUM%TYPE,
                                  P_OLD_MIS_CODE IN MITMS_CUSTOMER_DEFAULT.COMP_MIS_1%TYPE,
                                  P_NEW_MIS_CODE IN MITMS_CUSTOMER_DEFAULT.COMP_MIS_1%TYPE)
      RETURN BOOLEAN IS

      L_MIS_CLASS GLTMS_MIS_CLASS.MIS_CLASS%TYPE;
      L_INDEX     PLS_INTEGER;

    BEGIN

      DEBUG.PR_DEBUG('MI',
                     'p_old_mis_code is :' || P_OLD_MIS_CODE ||
                     ' p_new_mis_code is :' || P_NEW_MIS_CODE);

      BEGIN
        SELECT MIS_CLASS
          INTO L_MIS_CLASS
          FROM GLTMS_MIS_CLASS
         WHERE MIS_TYPE = P_MIS_TYPE
           AND CLASS_NUM = P_CLASS_NUM;

        DEBUG.PR_DEBUG('MI',
                       'p_mis_type is :' || P_MIS_TYPE ||
                       ' p_class_num is :' || P_CLASS_NUM ||
                       ' l_mis_class is : ' || L_MIS_CLASS);

      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('MI', 'Bombed in SELECT of fn_update_change_log ');

          DEBUG.PR_DEBUG('MI', 'p_mis_type is :' || P_MIS_TYPE);
          DEBUG.PR_DEBUG('MI', 'p_class_num is :' || P_CLASS_NUM);
      END;

      L_INDEX := P_WRK_MICCUSTM.V_MITBS_CUSTOMER_CHANGE_LOG.COUNT + 1;
      P_WRK_MICCUSTM.V_MITBS_CUSTOMER_CHANGE_LOG(L_INDEX).CUSTOMER := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUSTOMER;
      P_WRK_MICCUSTM.V_MITBS_CUSTOMER_CHANGE_LOG(L_INDEX).MIS_CLASS := L_MIS_CLASS;
      P_WRK_MICCUSTM.V_MITBS_CUSTOMER_CHANGE_LOG(L_INDEX).TXN_DATE := GLOBAL.APPLICATION_DATE;
      P_WRK_MICCUSTM.V_MITBS_CUSTOMER_CHANGE_LOG(L_INDEX).OLD_MIS_CODE := NVL(P_OLD_MIS_CODE,
                                                                              'UNDEFINED');

      P_WRK_MICCUSTM.V_MITBS_CUSTOMER_CHANGE_LOG(L_INDEX).NEW_MIS_CODE := P_NEW_MIS_CODE;

      RETURN TRUE;
    END FN_UPDATE_CHANGE_LOG;

  BEGIN
    P_WRK_MICCUSTM.V_MITBS_CUSTOMER_CHANGE_LOG.DELETE;
    DEBUG.PR_DEBUG('MI', 'composite mis code 1********************** ');
    L_MIS_TYPE  := 'O';
    L_CLASS_NUM := 1;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_1;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_1;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;

    DEBUG.PR_DEBUG('MI', 'composite mis code 2********************** ');

    L_CLASS_NUM := 2;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_2;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_2;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;
    DEBUG.PR_DEBUG('MI', 'composite mis code 3********************** ');

    L_CLASS_NUM := 3;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_3;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_3;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;
    DEBUG.PR_DEBUG('MI', 'composite mis code 4********************** ');

    L_CLASS_NUM := 4;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_4;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_4;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;

    DEBUG.PR_DEBUG('MI', 'composite mis code 5********************** ');

    L_CLASS_NUM := 5;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_5;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_5;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;
    DEBUG.PR_DEBUG('MI', 'composite mis code 6********************** ');

    L_CLASS_NUM := 6;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_6;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_6;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;
    DEBUG.PR_DEBUG('MI', 'composite mis code 7********************** ');

    L_CLASS_NUM := 7;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_7;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_7;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;
    DEBUG.PR_DEBUG('MI', 'COMPOSITE  mis code 8********************** ');

    L_CLASS_NUM := 8;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_8;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_8;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;
    DEBUG.PR_DEBUG('MI', 'COMPOSITE mis code 9********************** ');

    L_CLASS_NUM := 9;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_9;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_9;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;
    DEBUG.PR_DEBUG('MI', 'COMPOSITE mis code 10********************** ');

    L_CLASS_NUM    := 10;
    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_10;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.COMP_MIS_10;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;

    DEBUG.PR_DEBUG('MI', 'cust mis 1********************** ');
    L_MIS_TYPE  := 'C';
    L_CLASS_NUM := 1;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_1;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_1;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;
    DEBUG.PR_DEBUG('MI', 'cust mis 2********************** ');

    L_CLASS_NUM := 2;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_2;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_2;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;
    DEBUG.PR_DEBUG('MI', 'cust mis 3********************** ');
    L_CLASS_NUM := 3;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_3;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_3;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;

    DEBUG.PR_DEBUG('MI', 'cust mis 4********************** ');
    L_CLASS_NUM := 4;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_4;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_4;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;

    DEBUG.PR_DEBUG('MI', 'cust mis 5********************** ');
    L_CLASS_NUM := 5;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_5;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_5;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;

    DEBUG.PR_DEBUG('MI', 'cust mis 6********************** ');
    L_CLASS_NUM := 6;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_6;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_6;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;

    DEBUG.PR_DEBUG('MI', 'cust mis 7********************** ');
    L_CLASS_NUM := 7;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_7;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_7;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;

    DEBUG.PR_DEBUG('MI', 'cust mis 8********************** ');
    L_CLASS_NUM := 8;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_8;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_8;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;

    DEBUG.PR_DEBUG('MI', 'cust mis 9********************** ');

    L_CLASS_NUM := 9;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_9;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_9;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;

    END IF;

    DEBUG.PR_DEBUG('MI', 'cust mis 10   ********************** ');

    L_CLASS_NUM := 10;

    L_OLD_MIS_CODE := P_PREV_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_10;
    L_NEW_MIS_CODE := P_WRK_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_10;

    IF (NVL(L_OLD_MIS_CODE, '?') <> NVL(L_NEW_MIS_CODE, '?')) THEN
      IF NOT FN_UPDATE_CHANGE_LOG(L_MIS_TYPE,
                                  L_CLASS_NUM,
                                  L_OLD_MIS_CODE,
                                  L_NEW_MIS_CODE) THEN

        DEBUG.PR_DEBUG('MI', 'Bombed in fn_update_change_log');
        DEBUG.PR_DEBUG('MI', 'l_mis_type is :' || L_MIS_TYPE);
        DEBUG.PR_DEBUG('MI', 'l_class_num is :' || L_CLASS_NUM);
        RETURN FALSE;
      END IF;
    END IF;
    RETURN TRUE;
  END FN_DEFAULT_MIS_CHANGELOG;

  FUNCTION FN_ACCOUNT_TO_UPLD(P_WRK_STDCIF         IN STPKS_STDCIF_MAIN.TY_STDCIF,
                              L_TY_REC_CUSTACC_UPD IN OUT NOCOPY STPKS_ACCOUNT_UPLOAD_TYPE.TY_REC_CUSTACC_UPD,
                              P_SOURCE             IN VARCHAR2,
                              P_ERR_CODE           IN OUT VARCHAR2,
                              P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_TY_REC_CUSTACC STPKS_ACCOUNT_UPLOAD_TYPE.TY_REC_CUSTACC;
    L_ACC_JOINT_UPD  STPKS_ACCOUNT_UPLOAD_TYPE.TY_TB_ACC_JOINT_UPD;
    L_INDEX          NUMBER;
    L_LAST           NUMBER;
    L_NOMINEES       NUMBER;
    L_NOM_LAST       NUMBER;

    L_COUNT       NUMBER;
    L_UDF_DETAILS UVPKS_UDF_UPLOAD.TY_UPL_FUNC_UDF;
    L_COUNT2      NUMBER;
    L_REC_KEY     VARCHAR2(50);
    L_REC_KEY_ACC VARCHAR2(50);

    L_FUNCTION_ID STTB_RECORD_MASTER.FUNCTION_ID%TYPE;
  BEGIN
    DBG('In fn_stdcif_to_upld');

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CUSTOM THEN
      IF NOT
          STPKS_STDCIF_UTILS_0_CUSTOM.FN_PRE_ACCOUNT_TO_UPLD(P_WRK_STDCIF,
                                                             L_TY_REC_CUSTACC_UPD,
                                                             P_SOURCE,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS) THEN
        DBG('failed in stpks_stdcif_utils_0_custom.fn_Pre_account_to_upld');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CLUSTER THEN
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_PRE_ACCOUNT_TO_UPLD(P_WRK_STDCIF,
                                                              L_TY_REC_CUSTACC_UPD,
                                                              P_SOURCE,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
        DBG('failed in stpks_stdcif_utils_0_cluster.fn_Pre_account_to_upld');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Cutomer Account no in fn_stdcif_to_upld is :: ' ||
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO);
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.BRANCH_CODE                 := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CUST_AC_NO                  := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.AC_DESC                     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AC_DESC;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CUST_NO                     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CCY                         := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CCY;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.ACCOUNT_CLASS               := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.JOINT_AC_INDICATOR          := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.JOINT_AC_INDICATOR;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.AC_OPEN_DATE                := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AC_OPEN_DATE;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.ALT_AC_NO                   := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ALT_AC_NO;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CHEQUE_BOOK_FACILITY        := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHEQUE_BOOK_FACILITY;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.ATM_FACILITY                := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ATM_FACILITY;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.PASSBOOK_FACILITY           := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.PASSBOOK_FACILITY;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.DIRECT_BANKING              := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DIRECT_BANKING;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.DORMANCY_DAYS               := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DORMANCY_DAYS;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.ATM_CUST_AC_NO              := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ATM_CUST_AC_NO;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.ATM_DLY_AMT_LIMIT           := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ATM_DLY_AMT_LIMIT;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.ATM_DLY_COUNT_LIMIT         := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ATM_DLY_COUNT_LIMIT;
    L_TY_REC_CUSTACC.ACC_DETAILS.ACCOUNT_TYPE                        := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_TYPE;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.MIN_REQD_BAL                := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MIN_REQD_BAL;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CHECKBOOK_NAME_1            := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECKBOOK_NAME_1;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CHECKBOOK_NAME_2            := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECKBOOK_NAME_2;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.AUTO_REORDER_CHECK_REQUIRED := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AUTO_REORDER_CHECK_REQUIRED;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.AUTO_REORDER_CHECK_LEVEL    := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AUTO_REORDER_CHECK_LEVEL;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.AUTO_REORDER_CHECK_LEAVES   := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AUTO_REORDER_CHECK_LEAVES;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.DORMANT_PARAM               := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DORMANT_PARAM;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.LOCATION                    := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.LOCATION;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.MEDIA                       := P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA;
    L_TY_REC_CUSTACC.ACC_DETAILS.MODE_OF_OPERATION                   := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MODE_OF_OPERATION;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.COUNTRY_CODE                := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.COUNTRY_CODE;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.AUTO_CHQBK_REQUEST          := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECK_BOOK_REQUEST;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.AUTO_DC_REQUEST             := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DEBIT_CARD_REQUEST;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.JOINT_AC_INDICATOR          := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.JOINT_AC_INDICATOR;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.MAX_NO_CHEQUE_REJECTIONS    := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MAX_NO_CHEQUE_REJECTIONS;

    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.INF_ACC_OPENING_AMT       := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_ACC_OPENING_AMT;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.INF_OFFSET_ACCOUNT        := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_OFFSET_ACCOUNT;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.INF_OFFSET_BRANCH         := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_OFFSET_BRANCH;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.INF_PAY_IN_OPTION         := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_PAY_IN_OPTION;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.INF_WAIVE_ACC_OPEN_CHARGE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_WAIVE_ACC_OPEN_CHARGE;

    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.ADDRESS1 := P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.ADDRESS2 := P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.ADDRESS3 := P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.ADDRESS4 := P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.PINCODE  := P_WRK_STDCIF.V_STTMS_CUSTOMER.PINCODE;
    DBG('p_wrk_stdcif.v_sttms_customer.pincode >' ||
        P_WRK_STDCIF.V_STTMS_CUSTOMER.PINCODE);

    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.COUNTRY_CODE := P_WRK_STDCIF.V_STTMS_CUSTOMER.COUNTRY;
    DBG('country_code :: ' ||
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.COUNTRY_CODE);

    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.REPL_CUST_SIG  := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.REPL_CUST_SIG;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.SALARY_ACCOUNT := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.SALARY_ACCOUNT;

    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.SPEND_ANALYSIS_REQD := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.SPEND_ANALYSIS_REQD;

    DBG('am hererererrerere');
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CONTRIBUTE_TO_PDM         := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CONTRIBUTE_TO_PDM;
    L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.EXCLUDE_FROM_DISTRIBUTION := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.EXCLUDE_FROM_DISTRIBUTION;
    DBG('here contribute_to_pdm is --->' ||
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CONTRIBUTE_TO_PDM);

    DBG('branch_code  :: ' ||
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.BRANCH_CODE);
    DBG('cust_ac_no  :: ' ||
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CUST_AC_NO);

    DBG('l_ty_rec_custacc_upd.acc_details_upd.mudarabah_accounts--->' ||
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.MUDARABAH_ACCOUNTS);
    IF NVL(L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.MUDARABAH_ACCOUNTS, 'N') = 'Y' THEN
      L_FUNCTION_ID := 'IADCUSAC';
    ELSE
      L_FUNCTION_ID := 'STDCUSAC';
    END IF;

    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST.COUNT > 0 THEN

      DECLARE
        L_CNT1 NUMBER := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST.FIRST;
      BEGIN
        LOOP
          L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_CHECK_LIST(L_CNT1).BRANCH_CODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST(L_CNT1)
                                                                            .BRANCH_CODE;
          L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_CHECK_LIST(L_CNT1).CUST_AC_NO := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST(L_CNT1)
                                                                           .CUST_AC_NO;
          L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_CHECK_LIST(L_CNT1).DOCUMENT_TYPE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST(L_CNT1)
                                                                              .DOCUMENT_TYPE;
          L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_CHECK_LIST(L_CNT1).MANDATORY := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST(L_CNT1)
                                                                          .MANDATORY;
          L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_CHECK_LIST(L_CNT1).CHECKED := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST(L_CNT1)
                                                                        .CHECKED;
          EXIT WHEN L_CNT1 = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST.LAST;
          L_CNT1 := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST.NEXT(L_CNT1);
        END LOOP;
      END;
    END IF;
    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.COUNT > 0 THEN

      DECLARE
        L_CNT2 NUMBER := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.FIRST;
      BEGIN
        LOOP
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).NOMINEE_NAME := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                       .NOMINEE_NAME;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).NOMINEE_DOB := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                      .NOMINEE_DOB;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).RELATIONSHIP := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                       .RELATIONSHIP;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).ADDRESS1 := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                   .ADDRESS1;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).ADDRESS2 := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                   .ADDRESS2;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).ADDRESS3 := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                   .ADDRESS3;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).ADDRESS4 := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                   .ADDRESS4;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).PINCODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                  .PINCODE;
          DBG('p_wrk_stdcif.ty_stccuacc.v_stvws_auto_acc_nominees(l_cnt2).pincode>' || P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
              .PINCODE);
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).NOMINEE_ID := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                     .NOMINEE_ID;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).IS_MINOR := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                   .IS_MINOR;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).CUST_AC_NO := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                     .CUST_AC_NO;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).BRANCH_CODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                      .BRANCH_CODE;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).GUARDIAN_NAME := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                        .GUARDIAN_NAME;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).GUARDIAN_RELATION := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                            .GUARDIAN_RELATION;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).GUARD_ADDR1 := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                      .GUARD_ADDR1;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).GUARD_ADDR2 := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                      .GUARD_ADDR2;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).GUARD_ADDR3 := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                      .GUARD_ADDR3;
          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).GUARD_ADDR4 := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                      .GUARD_ADDR4;

          L_TY_REC_CUSTACC_UPD.AC_ACC_NOMINEES(L_CNT2).GUARD_PINCODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_CNT2)
                                                                        .GUARD_PINCODE;

          EXIT WHEN L_CNT2 = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.LAST;
          L_CNT2 := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.NEXT(L_CNT2);
        END LOOP;
      END;
    END IF;
    L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_REMARKS.BRANCH_CODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE;
    L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_REMARKS.CUST_AC_NO  := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
    L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_REMARKS.REMARK1     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.REMARK1;
    L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_REMARKS.REMARK2     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.REMARK2;
    L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_REMARKS.REMARK3     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.REMARK3;
    L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_REMARKS.REMARK4     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.REMARK4;
    L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_REMARKS.REMARK5     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.REMARK5;
    L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_REMARKS.REMARK6     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.REMARK6;
    L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_REMARKS.REMARK7     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.REMARK7;
    L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_REMARKS.REMARK8     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.REMARK8;
    L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_REMARKS.REMARK9     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.REMARK9;
    L_TY_REC_CUSTACC_UPD.AC_DOCTYPE_REMARKS.REMARK10    := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.REMARK10;
    IF NVL(P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECK_BOOK_REQUEST,
           'N') = 'Y' THEN

      L_TY_REC_CUSTACC_UPD.AC_CHQBK_DETAILS_UPD.BRANCH           := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.BRANCH;
      L_TY_REC_CUSTACC_UPD.AC_CHQBK_DETAILS_UPD.ACCOUNT          := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.ACCOUNT;
      L_TY_REC_CUSTACC_UPD.AC_CHQBK_DETAILS_UPD.FIRST_CHECK_NO   := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.FIRST_CHECK_NO;
      L_TY_REC_CUSTACC_UPD.AC_CHQBK_DETAILS_UPD.CHECK_LEAVES     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.CHECK_LEAVES;
      L_TY_REC_CUSTACC_UPD.AC_CHQBK_DETAILS_UPD.CHEQUE_BOOK_TYPE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.CHEQUE_BOOK_TYPE;
      L_TY_REC_CUSTACC_UPD.AC_CHQBK_DETAILS_UPD.ORDER_DATE       := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.ORDER_DATE;
      L_TY_REC_CUSTACC_UPD.AC_CHQBK_DETAILS_UPD.ORDER_DETAILS    := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.ORDER_DETAILS;
      L_TY_REC_CUSTACC_UPD.AC_CHQBK_DETAILS_UPD.LANGUAGE_CODE    := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.LANGUAGE_CODE;
      L_TY_REC_CUSTACC_UPD.AC_CHQBK_DETAILS_UPD.REQUEST_STATUS   := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.REQUEST_STATUS;

      DBG('CHQ_TYPE in account to upload' ||
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.CHQ_TYPE);
      DBG('p_wrk_stdcif.ty_stccuacc.v_stvws_auto_chqbook.language_code' ||
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.LANGUAGE_CODE);
      L_TY_REC_CUSTACC_UPD.AC_CHQBK_DETAILS_UPD.CHQ_TYPE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.CHQ_TYPE;
      DBG('l_ty_rec_custacc_upd.ac_chqbk_details_upd.chq_type' ||
          L_TY_REC_CUSTACC_UPD.AC_CHQBK_DETAILS_UPD.CHQ_TYPE);

    END IF;
    IF NVL(P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DEBIT_CARD_REQUEST,
           'N') = 'Y' THEN

      L_TY_REC_CUSTACC_UPD.AC_DRCARD_DETAILS_UPD.BRANCH_CODE          := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.BRANCH_CODE;
      L_TY_REC_CUSTACC_UPD.AC_DRCARD_DETAILS_UPD.CUST_AC_NO           := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CUST_AC_NO;
      L_TY_REC_CUSTACC_UPD.AC_DRCARD_DETAILS_UPD.CUST_NO              := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CUST_NO;
      L_TY_REC_CUSTACC_UPD.AC_DRCARD_DETAILS_UPD.REQUEST_REFERENCE_NO := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.REQUEST_REFERENCE_NO;
      L_TY_REC_CUSTACC_UPD.AC_DRCARD_DETAILS_UPD.CARD_PRODUCT         := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_PRODUCT;
      L_TY_REC_CUSTACC_UPD.AC_DRCARD_DETAILS_UPD.CARD_BIN             := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_BIN;
      L_TY_REC_CUSTACC_UPD.AC_DRCARD_DETAILS_UPD.CUSTOMER_NAME        := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CUSTOMER_NAME;
      L_TY_REC_CUSTACC_UPD.AC_DRCARD_DETAILS_UPD.CARD_NO              := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_NO;
      L_TY_REC_CUSTACC_UPD.AC_DRCARD_DETAILS_UPD.CARD_APPL_DATE       := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_APPL_DATE;
      L_TY_REC_CUSTACC_UPD.AC_DRCARD_DETAILS_UPD.PRIMARY_CARD         := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.PRIMARY_CARD;
      L_TY_REC_CUSTACC_UPD.AC_DRCARD_DETAILS_UPD.CARD_STATUS          := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_STATUS;
    END IF;
    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.JOINT_AC_INDICATOR = 'Y' THEN

      IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.COUNT > 0 THEN

        DECLARE
          L_CNT NUMBER := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.FIRST;
        BEGIN

          LOOP
            L_TY_REC_CUSTACC_UPD.ACC_JOINT_HOLDERS_UPD(L_CNT).G_ACC_JOINT.BRANCH_CODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT(L_CNT)
                                                                                         .BRANCH_CODE;
            L_TY_REC_CUSTACC_UPD.ACC_JOINT_HOLDERS_UPD(L_CNT).G_ACC_JOINT.CUST_AC_NO := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT(L_CNT)
                                                                                        .CUST_AC_NO;
            L_TY_REC_CUSTACC_UPD.ACC_JOINT_HOLDERS_UPD(L_CNT).G_ACC_JOINT.JOINT_HOLDER_CODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT(L_CNT)
                                                                                               .JOINT_HOLDER_CODE;
            L_TY_REC_CUSTACC_UPD.ACC_JOINT_HOLDERS_UPD(L_CNT).G_ACC_JOINT.JOINT_HOLDER_DESCRIPTION := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT(L_CNT)
                                                                                                      .JOINT_HOLDER_DESCRIPTION;
            L_TY_REC_CUSTACC_UPD.ACC_JOINT_HOLDERS_UPD(L_CNT).G_ACC_JOINT.JOINT_HOLDER := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT(L_CNT)
                                                                                          .JOINT_HOLDER;
            L_TY_REC_CUSTACC_UPD.ACC_JOINT_HOLDERS_UPD(L_CNT).G_ACC_JOINT.START_DATE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT(L_CNT)
                                                                                        .START_DATE;
            L_TY_REC_CUSTACC_UPD.ACC_JOINT_HOLDERS_UPD(L_CNT).G_ACC_JOINT.END_DATE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT(L_CNT)
                                                                                      .END_DATE;

            EXIT WHEN L_CNT = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.LAST;
            L_CNT := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.NEXT(L_CNT);
          END LOOP;
        END;
      END IF;
    END IF;
    IF P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.COUNT > 0 THEN

      DECLARE
        L_CONT NUMBER := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.FIRST;

      BEGIN
        LOOP

          L_TY_REC_CUSTACC.ACC_UDF_DETAILS.G_UDF_FUNC_DETAIL(L_CONT).G_FUNC_UDF_DTLS.FUNCTION_ID := L_FUNCTION_ID;
          L_TY_REC_CUSTACC.ACC_UDF_DETAILS.G_UDF_FUNC_DETAIL(L_CONT).G_FUNC_UDF_DTLS.REC_KEY := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CONT)
                                                                                                .REC_KEY;
          L_TY_REC_CUSTACC.ACC_UDF_DETAILS.G_UDF_FUNC_DETAIL(L_CONT).G_FUNC_UDF_DTLS.FIELD_NAME := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CONT)
                                                                                                   .FIELD_NAME;
          L_TY_REC_CUSTACC.ACC_UDF_DETAILS.G_UDF_FUNC_DETAIL(L_CONT).G_FUNC_UDF_DTLS.FIELD_VAL := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CONT)
                                                                                                  .FIELD_VAL;
          L_TY_REC_CUSTACC.ACC_UDF_DETAILS.G_UDF_FUNC_DETAIL(L_CONT).G_FUNC_UDF_DTLS.DATA_TYPE := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CONT)
                                                                                                  .DATA_TYPE;
          L_TY_REC_CUSTACC.ACC_UDF_DETAILS.G_UDF_FUNC_DETAIL(L_CONT).G_FUNC_UDF_DTLS.VAL_TYPE := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CONT)
                                                                                                 .VAL_TYPE;

          EXIT WHEN L_CONT = P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.LAST;
          L_CONT := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.NEXT(L_CONT);
        END LOOP;
      END;
    END IF;

    BEGIN
      L_REC_KEY := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE || '~' ||
                   P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO || '~';

      SELECT COUNT(*)
        INTO L_COUNT
        FROM CSTM_FUNCTION_USERDEF_FIELDS

       WHERE FUNCTION_ID = L_FUNCTION_ID
         AND REC_KEY = L_REC_KEY;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_COUNT := 0;
      WHEN OTHERS THEN
        DBG('IN WOT of cstm_function_userdef_fields ' || SQLERRM);
        RETURN FALSE;
    END;
    DBG('udf count in fn_account_to_upld' || L_COUNT);

    IF NOT UVPKS_UDF_UPLOAD.FN_QUERY_FUNC_UDFDETAILS(L_FUNCTION_ID,
                                                     L_REC_KEY,
                                                     L_UDF_DETAILS,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;

    IF G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.COUNT > 0 THEN
      DECLARE
        L_COUNT1 NUMBER := G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.FIRST;
      BEGIN
        L_REC_KEY_ACC := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE || '~' ||
                         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO || '~';

        LOOP

          L_TY_REC_CUSTACC_UPD.ACC_UDF_DETAILS_UPD.G_UDF_FUNC_DETAIL(L_COUNT1).G_FUNC_UDF_DTLS.FUNCTION_ID := 'STDCUSAC';
          L_TY_REC_CUSTACC_UPD.ACC_UDF_DETAILS_UPD.G_UDF_FUNC_DETAIL(L_COUNT1).G_FUNC_UDF_DTLS.REC_KEY := L_REC_KEY_ACC;
          L_TY_REC_CUSTACC_UPD.ACC_UDF_DETAILS_UPD.G_UDF_FUNC_DETAIL(L_COUNT1).G_FUNC_UDF_DTLS.FIELD_NAME := G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_COUNT1)
                                                                                                             .FIELD_NAME;
          L_TY_REC_CUSTACC_UPD.ACC_UDF_DETAILS_UPD.G_UDF_FUNC_DETAIL(L_COUNT1).G_FUNC_UDF_DTLS.FIELD_VAL := G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_COUNT1)
                                                                                                            .FIELD_VAL;
          L_TY_REC_CUSTACC_UPD.ACC_UDF_DETAILS_UPD.G_UDF_FUNC_DETAIL(L_COUNT1).G_FUNC_UDF_DTLS.DATA_TYPE := G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_COUNT1)
                                                                                                            .DATA_TYPE;
          L_TY_REC_CUSTACC_UPD.ACC_UDF_DETAILS_UPD.G_UDF_FUNC_DETAIL(L_COUNT1).G_FUNC_UDF_DTLS.VAL_TYPE := G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_COUNT1)
                                                                                                           .VAL_TYPE;
          DBG('Field value  === ' || L_TY_REC_CUSTACC_UPD.ACC_UDF_DETAILS_UPD.G_UDF_FUNC_DETAIL(L_COUNT1)
              .G_FUNC_UDF_DTLS.FIELD_VAL);
          EXIT WHEN L_COUNT1 = G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.LAST;
          L_COUNT1 := G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.NEXT(L_COUNT1);
        END LOOP;
      END;
    END IF;
    BEGIN
      SELECT COUNT(*)
        INTO L_COUNT2
        FROM MITBS_CLASS_MAPPING
       WHERE BRANCH_CODE =
             P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.BRANCH_CODE
         AND UNIT_REF_NO =
             P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.UNIT_REF_NO;
      IF L_COUNT2 > 0 THEN
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.SOURCE_CODE := P_SOURCE;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.BRANCH_CODE := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.BRANCH_CODE;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.CALC_METHOD := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.CALC_METHOD;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.CCY         := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.CCY;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COMP_MIS_1  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COMP_MIS_1;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COMP_MIS_10 := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COMP_MIS_10;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COMP_MIS_2  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COMP_MIS_2;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COMP_MIS_3  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COMP_MIS_3;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COMP_MIS_4  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COMP_MIS_4;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COMP_MIS_5  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COMP_MIS_5;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COMP_MIS_6  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COMP_MIS_6;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COMP_MIS_7  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COMP_MIS_7;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COMP_MIS_8  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COMP_MIS_8;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COMP_MIS_9  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COMP_MIS_9;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COST_CODE1  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COST_CODE1;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COST_CODE2  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COST_CODE2;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COST_CODE3  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COST_CODE3;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COST_CODE4  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COST_CODE4;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.COST_CODE5  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.COST_CODE5;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.CUSTOMER    := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.CUSTOMER;

        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.FUND_MIS_1      := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.FUND_MIS_1;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.FUND_MIS_10     := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.FUND_MIS_10;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.FUND_MIS_2      := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.FUND_MIS_2;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.FUND_MIS_3      := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.FUND_MIS_3;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.FUND_MIS_4      := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.FUND_MIS_4;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.FUND_MIS_5      := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.FUND_MIS_5;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.FUND_MIS_6      := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.FUND_MIS_6;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.FUND_MIS_7      := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.FUND_MIS_7;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.FUND_MIS_8      := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.FUND_MIS_8;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.FUND_MIS_9      := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.FUND_MIS_9;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.MIS_GROUP       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.MIS_GROUP;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.MIS_GROUP_COMP  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.MIS_GROUP_COMP;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.MIS_GROUP_TXN   := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.MIS_GROUP_TXN;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.MIS_HEAD        := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.MIS_HEAD;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.POOL_CODE       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.POOL_CODE;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.PROCESSED_FLAG  := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.PROCESSED_FLAG;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.RATE_FLAG       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.RATE_FLAG;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.REF_RATE        := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.REF_RATE;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.REF_RATE_CODE   := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.REF_RATE_CODE;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.REF_RATE_TYPE   := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.REF_RATE_TYPE;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.REF_SPREAD      := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.REF_SPREAD;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.RELATED_ACCOUNT := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.RELATED_ACCOUNT;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.RELATED_REF     := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.RELATED_REF;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.TXN_MIS_1       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.TXN_MIS_1;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.TXN_MIS_10      := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.TXN_MIS_10;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.TXN_MIS_2       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.TXN_MIS_2;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.TXN_MIS_3       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.TXN_MIS_3;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.TXN_MIS_4       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.TXN_MIS_4;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.TXN_MIS_5       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.TXN_MIS_5;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.TXN_MIS_6       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.TXN_MIS_6;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.TXN_MIS_7       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.TXN_MIS_7;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.TXN_MIS_8       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.TXN_MIS_8;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.TXN_MIS_9       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.TXN_MIS_9;
        L_TY_REC_CUSTACC_UPD.ACC_MIS_DETAILS_UPD.UNIT_TYPE       := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.UNIT_TYPE;
      END IF;
    END;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CUSTOM THEN
      IF NOT
          STPKS_STDCIF_UTILS_0_CUSTOM.FN_POST_ACCOUNT_TO_UPLD(P_WRK_STDCIF,
                                                              L_TY_REC_CUSTACC_UPD,
                                                              P_SOURCE,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
        DBG('failed in stpks_stdcif_utils_0_custom.fn_Post_account_to_upld');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CLUSTER THEN
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_POST_ACCOUNT_TO_UPLD(P_WRK_STDCIF,
                                                               L_TY_REC_CUSTACC_UPD,
                                                               P_SOURCE,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAMS) THEN
        DBG('failed in stpks_stdcif_utils_0_cluster.fn_Post_account_to_upld');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Returning success from fn_account_to_upld');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_account_to_upld' || SQLERRM);
      DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

      RETURN FALSE;
  END FN_ACCOUNT_TO_UPLD;

  FUNCTION FN_CUST_AUTO_ACCOUNT(P_FUNCTION_ID IN VARCHAR2,
                                P_SOURCE      IN VARCHAR2,
                                P_ACTION_CODE IN VARCHAR2,
                                P_WRK_STDCIF  IN OUT NOCOPY STPKS_STDCIF_MAIN.TY_STDCIF,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_NOMINEES    NUMBER := 0;
    L_CHECKLIST   NUMBER := 0;
    L_JOINTHOLDER NUMBER := 0;

    L_COUNT1 NUMBER := 0;
    L_COUNT2 NUMBER := 0;

    PSERIAL          VARCHAR2(20);
    PREFERENCENO     VARCHAR2(16);
    L_FIRST_CHECK_NO STVWS_AUTO_CHQBOOK.FIRST_CHECK_NO%TYPE;

    --Auto CIF Account Changes for Mobile Banking Starts
    L_COUNT NUMBER := 0;
    --Auto CIF Account Changes for Mobile Banking Ends
  BEGIN
    L_NOMINEES    := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.COUNT;
    L_CHECKLIST   := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST.COUNT;
    L_JOINTHOLDER := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.COUNT;
    DBG('customer branch code before insert is --> ' ||
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE);
    DBG('customer account no before insert is --> ' ||
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO);
    DBG('customer no before insert is --> ' ||
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO);
    DBG('JOINT_AC_INDICATOR before insert is --> ' ||
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.JOINT_AC_INDICATOR);

    P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE := NVL(P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE,
                                                                     P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);

    P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE IS NULL OR
       P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO IS NULL OR
       P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO IS NULL THEN
      P_ERR_CODE   := 'ST-CIF-111';
      P_ERR_PARAMS := '';
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;

    BEGIN
      INSERT INTO STTMS_AUTO_ACCOUNT
        (BRANCH_CODE,
         CUST_AC_NO,
         AC_DESC,
         CUST_NAME,
         CUST_NO,
         CCY,
         ACCOUNT_CLASS,
         AC_OPEN_DATE,
         ALT_AC_NO,
         CHEQUE_BOOK_FACILITY,
         ATM_FACILITY,
         PASSBOOK_FACILITY,
         DIRECT_BANKING,
         DORMANCY_DAYS,
         ATM_CUST_AC_NO,
         ATM_DLY_AMT_LIMIT,
         ATM_DLY_COUNT_LIMIT,
         ACCOUNT_TYPE,
         MIN_REQD_BAL,
         CHECKBOOK_NAME_1,
         CHECKBOOK_NAME_2,
         AUTO_REORDER_CHECK_REQUIRED,
         AUTO_REORDER_CHECK_LEVEL,
         AUTO_REORDER_CHECK_LEAVES,
         DORMANT_PARAM,
         LOCATION,
         MEDIA,
         MODE_OF_OPERATION,
         COUNTRY_CODE,
         CHECK_BOOK_REQUEST,
         DEBIT_CARD_REQUEST,
         JOINT_AC_INDICATOR,
         MAX_NO_CHEQUE_REJECTIONS,
         INF_ACC_OPENING_AMT,
         INF_OFFSET_ACCOUNT,
         INF_OFFSET_BRANCH,
         INF_PAY_IN_OPTION,
         INF_WAIVE_ACC_OPEN_CHARGE

        ,
         FUNCTION_ID,
         REPL_CUST_SIG,
         SALARY_ACCOUNT,
         SPEND_ANALYSIS_REQD,
         TYPE_OF_CHQ,
         MULTI_CCY_AC_NO,
         CONTRIBUTE_TO_PDM,
         EXCLUDE_FROM_DISTRIBUTION)

      VALUES
        (P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AC_DESC,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NAME,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CCY,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AC_OPEN_DATE,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ALT_AC_NO,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHEQUE_BOOK_FACILITY,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ATM_FACILITY,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.PASSBOOK_FACILITY,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DIRECT_BANKING,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DORMANCY_DAYS,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ATM_CUST_AC_NO,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ATM_DLY_AMT_LIMIT,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ATM_DLY_COUNT_LIMIT,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_TYPE,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MIN_REQD_BAL,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECKBOOK_NAME_1,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECKBOOK_NAME_2,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AUTO_REORDER_CHECK_REQUIRED,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AUTO_REORDER_CHECK_LEVEL,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AUTO_REORDER_CHECK_LEAVES,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DORMANT_PARAM,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.LOCATION,
         P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MODE_OF_OPERATION,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.COUNTRY_CODE,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECK_BOOK_REQUEST,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DEBIT_CARD_REQUEST,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.JOINT_AC_INDICATOR,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MAX_NO_CHEQUE_REJECTIONS,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_ACC_OPENING_AMT,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_OFFSET_ACCOUNT,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_OFFSET_BRANCH,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_PAY_IN_OPTION,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_WAIVE_ACC_OPEN_CHARGE

        ,
         P_FUNCTION_ID,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.REPL_CUST_SIG,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.SALARY_ACCOUNT,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.SPEND_ANALYSIS_REQD,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.TYPE_OF_CHQ,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MULTI_CCY_AC_NO,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CONTRIBUTE_TO_PDM,
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.EXCLUDE_FROM_DISTRIBUTION);

      DBG('p_wrk_stdcif.ty_stccuacc.v_stvws_auto_account.type_of_chq' ||
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.TYPE_OF_CHQ);
      DBG('rows inserted in sttms_auto_account is  ' || SQL%ROWCOUNT);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        DBG('The error is ' || SQLERRM);
        RETURN FALSE;

    END;

    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.JOINT_AC_INDICATOR = 'Y' THEN

      DBG('Joint Holder count is : ' ||
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.COUNT);
      IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.COUNT > 0 THEN

        BEGIN

          FORALL L_JOINT IN 1 .. L_JOINTHOLDER
            INSERT INTO STTMS_AUTO_ACC_JOINT
              (BRANCH_CODE,
               CUST_AC_NO,
               JOINT_HOLDER_CODE,
               JOINT_HOLDER_DESCRIPTION,
               JOINT_HOLDER,
               START_DATE,
               END_DATE)
            VALUES
              (P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE,
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO,
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT          (L_JOINT)
               .JOINT_HOLDER_CODE,
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT          (L_JOINT)
               .JOINT_HOLDER_DESCRIPTION,
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT          (L_JOINT)
               .JOINT_HOLDER,
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT          (L_JOINT)
               .START_DATE,
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT          (L_JOINT)
               .END_DATE);
          DBG('rows inserted in sttms_auto_acc_joint is  ' || SQL%ROWCOUNT);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('the error is here ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

            DBG('The error is ' || SQLERRM);
            RETURN FALSE;
        END;
      END IF;
    END IF;
    DBG('Nominees count is : ' ||
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.COUNT);

    IF NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.MINOR, 'N') = 'Y' AND
       P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.COUNT = 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF45', '');
    END IF;

    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.COUNT > 0 THEN

      BEGIN

        FOR L_NOM IN P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.FIRST .. P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.LAST LOOP
          INSERT INTO STTMS_AUTO_ACC_NOMINEES
            (BRANCH_CODE,
             CUST_AC_NO,
             NOMINEE_NAME,
             NOMINEE_DOB,
             RELATIONSHIP,
             ADDRESS1,
             ADDRESS2,
             ADDRESS3,
             ADDRESS4,
             PINCODE,
             NOMINEE_ID,
             IS_MINOR,
             GUARDIAN_NAME,
             GUARDIAN_RELATION,
             GUARD_ADDR1,
             GUARD_ADDR2,
             GUARD_ADDR3,
             GUARD_ADDR4,
             GUARD_PINCODE)
          VALUES
            (P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .NOMINEE_NAME,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .NOMINEE_DOB,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .RELATIONSHIP,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .ADDRESS1,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .ADDRESS2,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .ADDRESS3,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .ADDRESS4,

             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .PINCODE,

             (L_NOM),
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .IS_MINOR,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARDIAN_NAME,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARDIAN_RELATION,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARD_ADDR1,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARD_ADDR2,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARD_ADDR3,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARD_ADDR4,

             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARD_PINCODE);

          DBG('rows inserted in sttms_auto_acc_nominees is  ' ||
              SQL%ROWCOUNT);
        END LOOP;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

          DBG('The error is ' || SQLERRM);
          RETURN FALSE;
      END;
    END IF;
    DBG('Checklist count is : ' ||
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST.COUNT);
    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST.COUNT > 0 THEN

      BEGIN
        FORALL L_CKLIST IN 1 .. L_CHECKLIST
          INSERT INTO STTMS_AUTO_DOC_CHECKLIST
            (BRANCH_CODE, CUST_AC_NO, DOCUMENT_TYPE, MANDATORY, CHECKED)
          VALUES
            (P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST      (L_CKLIST)
             .DOCUMENT_TYPE,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST      (L_CKLIST)
             .MANDATORY,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST      (L_CKLIST)
             .CHECKED);
        DBG('rows inserted in sttms_auto_doc_checklist is  ' ||
            SQL%ROWCOUNT);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

          DBG('The error is ' || SQLERRM);
          RETURN FALSE;
      END;

      BEGIN

        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.BRANCH_CODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE;
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.CUST_AC_NO  := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;

        INSERT INTO STTMS_AUTO_DOC_REMARKS
        VALUES P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS;
        DBG('rows inserted in sttms_auto_doc_remarks is  ' || SQL%ROWCOUNT);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

          DBG('The error is ' || SQLERRM);
          RETURN FALSE;
      END;

    END IF;

    IF NVL(P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECK_BOOK_REQUEST,
           'N') = 'Y'

     THEN
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.BRANCH  := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE;
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.ACCOUNT := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;

      L_FIRST_CHECK_NO := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.FIRST_CHECK_NO;
      IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.BRANCH IS NULL OR
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.ACCOUNT IS NULL

       THEN
        P_ERR_CODE   := 'ST-CHQ-01';
        P_ERR_PARAMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;

      BEGIN
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.REQUEST_STATUS := 'Requested';

        DBG('first check no ' ||
            P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.FIRST_CHECK_NO);
        IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.FIRST_CHECK_NO IS NULL THEN
          INSERT INTO STTMS_AUTO_CHQBOOK
            (BRANCH,
             ACCOUNT,
             FIRST_CHECK_NO,
             CHECK_LEAVES,
             CHEQUE_BOOK_TYPE,
             ORDER_DATE,
             ORDER_DETAILS,
             LANGUAGE_CODE,
             REQUEST_STATUS,
             CHQ_TYPE)
          VALUES
            (P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.BRANCH,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.ACCOUNT,
             '11111',
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.CHECK_LEAVES,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.CHEQUE_BOOK_TYPE,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.ORDER_DATE,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.ORDER_DETAILS,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.LANGUAGE_CODE,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.REQUEST_STATUS,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.CHQ_TYPE);
          DBG('fist check num after insert into table' ||
              P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.FIRST_CHECK_NO);
        ELSE
          INSERT INTO STTMS_AUTO_CHQBOOK
          VALUES P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK;
          DBG('fist check num INSIDE ELSE' ||
              P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.FIRST_CHECK_NO);
        END IF;

        DBG('rows inserted is sttms_auto_chqbook ' || SQL%ROWCOUNT);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          DBG('The error is ' || SQLERRM);
          RETURN FALSE;
      END;
    END IF;
    IF NVL(P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DEBIT_CARD_REQUEST,
           'N') = 'Y' THEN

      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.BRANCH_CODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE;
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CUST_AC_NO  := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CUST_NO     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO;
      IF P_SOURCE <> 'FLEXCUBE' THEN
        IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.REQUEST_REFERENCE_NO IS NULL THEN
          IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_PRODUCT IS NULL THEN
            DBG('Card Product cannot be null');
            P_ERR_CODE   := 'ST-CRDM07';
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         P_ERR_CODE,
                         P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
          DBG('INSIDE IF---');

          IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_PRODUCT,
                                             GLOBAL.APPLICATION_DATE,
                                             PSERIAL,
                                             PREFERENCENO,
                                             P_ERR_CODE) THEN
            DBG('Failed in generating internal reference number with error code ' ||
                P_ERR_CODE);
            ROLLBACK;
            RETURN FALSE;
          END IF;
          DBG('Came out of this');
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.REQUEST_REFERENCE_NO := PREFERENCENO;
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_APPL_DATE       := GLOBAL.APPLICATION_DATE;
        END IF;
      END IF;

      IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.BRANCH_CODE IS NULL OR
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CUST_AC_NO IS NULL OR
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CUST_NO IS NULL OR
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.REQUEST_REFERENCE_NO IS NULL THEN
        P_ERR_CODE   := 'ST-CRD-01';
        P_ERR_PARAMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;

      BEGIN
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_STATUS  := 'R';
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.PRIMARY_CARD := 'Y';
        INSERT INTO STTMS_AUTO_DEBITCARD
        VALUES P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD;
        DBG('rows inserted in sttms_auto_debitcard is   ' || SQL%ROWCOUNT);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

          DBG('The error is ' || SQLERRM);
          RETURN FALSE;
      END;
    END IF;

    BEGIN

      P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.BRANCH_CODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE;
      P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.UNIT_REF_NO := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
      P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.UNIT_TYPE   := 'A';

      --Auto CIF Account Changes for Mobile Banking Starts
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO =
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;
      --Auto CIF Account Changes for Mobile Banking Ends

      IF L_COUNT = 0 THEN
      --Auto CIF Account Changes for Mobile Banking

      INSERT INTO MITBS_CLASS_MAPPING
      VALUES P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING;

      ELSE
        --Auto CIF Account Changes for Mobile Banking
        DELETE FROM MITBS_CLASS_MAPPING
         WHERE P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.UNIT_REF_NO =
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
        INSERT INTO MITBS_CLASS_MAPPING
        VALUES P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING;
      END IF; --Auto CIF Account Changes for Mobile Banking
      DBG('The no of rows inserted is ' || SQL%ROWCOUNT);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('in WOT of mitbs_class_mapping ' || SQLERRM);
        DBG('The erros is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

        RETURN FALSE;
    END;
    BEGIN
      IF P_WRK_STDCIF.TY_STCCUACC.V_MITBS_ACCOUNT_CHANGE_LOG.COUNT > 0 THEN

        L_COUNT1 := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_ACCOUNT_CHANGE_LOG.COUNT;
        FOR REC IN 1 .. L_COUNT1 LOOP

          P_WRK_STDCIF.TY_STCCUACC.V_MITBS_ACCOUNT_CHANGE_LOG(REC).BRANCH := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE;
          P_WRK_STDCIF.TY_STCCUACC.V_MITBS_ACCOUNT_CHANGE_LOG(REC).ACCOUNT_NO := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;

          INSERT INTO MITBS_ACCOUNT_CHANGE_LOG
          VALUES P_WRK_STDCIF.TY_STCCUACC.V_MITBS_ACCOUNT_CHANGE_LOG
            (REC);

          DBG('The no of rows inserted is ' || SQL%ROWCOUNT);
        END LOOP;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('in WOT of mitbs_account_change_log ' || SQLERRM);
        DBG('The erros is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

        RETURN FALSE;
    END;
    BEGIN
      IF P_WRK_STDCIF.TY_STCCUACC.V_MITBS_BAL_TRANSFER_LOG.COUNT > 0 THEN

        L_COUNT2 := P_WRK_STDCIF.TY_STCCUACC.V_MITBS_BAL_TRANSFER_LOG.COUNT;
        FOR REC IN 1 .. L_COUNT2 LOOP

          INSERT INTO MITBS_BAL_TRANSFER_LOG
          VALUES P_WRK_STDCIF.TY_STCCUACC.V_MITBS_BAL_TRANSFER_LOG
            (REC);

          DBG('The no of rows inserted is ' || SQL%ROWCOUNT);
        END LOOP;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('in WOT of mitbs_bal_transfer_log ' || SQLERRM);
        DBG('The erros is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

        RETURN FALSE;

    END;
    IF P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.COUNT > 0 THEN
      DECLARE
        L_CNT1 NUMBER := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.FIRST;
      BEGIN
        LOOP
          DBG('field_name is ;;;;,,,....' || P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1)
              .FIELD_NAME);
          DBG('field_val is ;;;;,,,....' || P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1)
              .FIELD_VAL);
          G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1).FIELD_NAME := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1)
                                                                              .FIELD_NAME;
          G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1).FIELD_VAL := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1)
                                                                             .FIELD_VAL;
          G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1).DATA_TYPE := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1)
                                                                             .DATA_TYPE;
          G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1).VAL_TYPE := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1)
                                                                            .VAL_TYPE;
          DBG('field_val is ;;;;,,.' || G_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1)
              .FIELD_VAL);

          EXIT WHEN L_CNT1 = P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.LAST;
          L_CNT1 := P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.NEXT(L_CNT1);
        END LOOP;
      END;
    END IF;

    DBG('Returning success from fn_cust_auto_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_cust_auto_account' || SQLERRM);
      DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

      RETURN FALSE;
  END FN_CUST_AUTO_ACCOUNT;

  FUNCTION FN_CUST_MOD_AUTO_ACC(P_FUNCTION_ID IN VARCHAR2,
                                P_SOURCE      IN VARCHAR2,
                                P_ACTION_CODE IN VARCHAR2,
                                P_WRK_STDCIF  IN OUT NOCOPY STPKS_STDCIF_MAIN.TY_STDCIF,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_NOMINEES_UPD    NUMBER := 0;
    L_CHECKLIST_UPD   NUMBER := 0;
    L_JOINTHOLDER_UPD NUMBER := 0;
    PSERIAL           VARCHAR2(20);
    PREFERENCENO      VARCHAR2(16);
  BEGIN
    L_NOMINEES_UPD    := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.COUNT;
    L_CHECKLIST_UPD   := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST.COUNT;
    L_JOINTHOLDER_UPD := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.COUNT;
    DBG('In fn_cust_mod_auto_acc');
    P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE := P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
    P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO     := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;

    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE IS NULL OR
       P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO IS NULL OR
       P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO IS NULL THEN
      P_ERR_CODE   := 'ST-CIF-111';
      P_ERR_PARAMS := '';
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;

    BEGIN
      UPDATE STTMS_AUTO_ACCOUNT
         SET AC_DESC                     = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AC_DESC,
             ALT_AC_NO                   = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ALT_AC_NO,
             CHEQUE_BOOK_FACILITY        = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHEQUE_BOOK_FACILITY,
             ATM_FACILITY                = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ATM_FACILITY,
             PASSBOOK_FACILITY           = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.PASSBOOK_FACILITY,
             DIRECT_BANKING              = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DIRECT_BANKING,
             ATM_CUST_AC_NO              = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ATM_CUST_AC_NO,
             ATM_DLY_AMT_LIMIT           = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ATM_DLY_AMT_LIMIT,
             ATM_DLY_COUNT_LIMIT         = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ATM_DLY_COUNT_LIMIT,
             ACCOUNT_TYPE                = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_TYPE,
             CHECKBOOK_NAME_1            = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECKBOOK_NAME_1,
             CHECKBOOK_NAME_2            = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECKBOOK_NAME_2,
             AUTO_REORDER_CHECK_REQUIRED = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AUTO_REORDER_CHECK_REQUIRED,
             AUTO_REORDER_CHECK_LEVEL    = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AUTO_REORDER_CHECK_LEVEL,
             AUTO_REORDER_CHECK_LEAVES   = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AUTO_REORDER_CHECK_LEAVES,
             DORMANT_PARAM               = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DORMANT_PARAM,
             COUNTRY_CODE                = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.COUNTRY_CODE,
             CHECK_BOOK_REQUEST          = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECK_BOOK_REQUEST,
             DEBIT_CARD_REQUEST          = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DEBIT_CARD_REQUEST,
             JOINT_AC_INDICATOR          = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.JOINT_AC_INDICATOR,
             MAX_NO_CHEQUE_REJECTIONS    = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MAX_NO_CHEQUE_REJECTIONS,
             INF_ACC_OPENING_AMT         = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_ACC_OPENING_AMT,
             INF_OFFSET_ACCOUNT          = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_OFFSET_ACCOUNT,
             INF_OFFSET_BRANCH           = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_OFFSET_BRANCH,
             INF_PAY_IN_OPTION           = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_PAY_IN_OPTION,
             INF_WAIVE_ACC_OPEN_CHARGE   = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.INF_WAIVE_ACC_OPEN_CHARGE,
             MEDIA                       = P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA,
             LOCATION                    = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.LOCATION,
             FUNCTION_ID                 = P_FUNCTION_ID,
             REPL_CUST_SIG               = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.REPL_CUST_SIG,
             SALARY_ACCOUNT              = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.SALARY_ACCOUNT,
             SPEND_ANALYSIS_REQD         = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.SPEND_ANALYSIS_REQD,
             CONTRIBUTE_TO_PDM           = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CONTRIBUTE_TO_PDM,
             EXCLUDE_FROM_DISTRIBUTION   = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.EXCLUDE_FROM_DISTRIBUTION
       WHERE CUST_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      DBG('rows updated in sttms_auto_account is  ' || SQL%ROWCOUNT);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        DBG('The error is ' || SQLERRM);
        RETURN FALSE;
    END;

    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST.COUNT > 0 THEN
      BEGIN
        DELETE FROM STTMS_AUTO_DOC_CHECKLIST
         WHERE CUST_AC_NO =
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
        DBG('rows deleted in sttms_auto_doc_checklist is  ' ||
            SQL%ROWCOUNT);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          DBG('The error is ' || SQLERRM);
          RETURN FALSE;
      END;
      BEGIN
        FORALL L_CKLIST IN 1 .. L_CHECKLIST_UPD
          INSERT INTO STTMS_AUTO_DOC_CHECKLIST
            (BRANCH_CODE, CUST_AC_NO, DOCUMENT_TYPE, MANDATORY, CHECKED)
          VALUES
            (P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST      (L_CKLIST)
             .DOCUMENT_TYPE,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST      (L_CKLIST)
             .MANDATORY,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST      (L_CKLIST)
             .CHECKED);
        DBG('rows updated in sttms_auto_doc_checklist is  ' ||
            SQL%ROWCOUNT);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

          DBG('The error is ' || SQLERRM);
          RETURN FALSE;
      END;

      BEGIN

        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.BRANCH_CODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE;
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.CUST_AC_NO  := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;

        DELETE FROM STTMS_AUTO_DOC_REMARKS
         WHERE CUST_AC_NO =
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
        DBG('rows deleted in sttms_auto_doc_remarks is  ' || SQL%ROWCOUNT);

        INSERT INTO STTMS_AUTO_DOC_REMARKS
        VALUES P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

          DBG('The error is ' || SQLERRM);
          RETURN FALSE;
      END;

    END IF;
    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.JOINT_AC_INDICATOR = 'Y' THEN

      IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.COUNT > 0 THEN
        BEGIN
          DELETE FROM STTMS_AUTO_ACC_JOINT
           WHERE CUST_AC_NO =
                 P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
          DBG('rows deleted in sttms_auto_acc_joint  is  ' || SQL%ROWCOUNT);
        END;
        BEGIN

          FORALL L_JOINT IN 1 .. L_JOINTHOLDER_UPD
            INSERT INTO STTMS_AUTO_ACC_JOINT
              (BRANCH_CODE,
               CUST_AC_NO,
               JOINT_HOLDER_CODE,
               JOINT_HOLDER_DESCRIPTION,
               JOINT_HOLDER,
               START_DATE,
               END_DATE)
            VALUES
              (P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE,
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO,
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT          (L_JOINT)
               .JOINT_HOLDER_CODE,
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT          (L_JOINT)
               .JOINT_HOLDER_DESCRIPTION,
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT          (L_JOINT)
               .JOINT_HOLDER,
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT          (L_JOINT)
               .START_DATE,
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT          (L_JOINT)
               .END_DATE);
          DBG('rows updated in sttms_auto_acc_joint is  ' || SQL%ROWCOUNT);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('the error is here ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

            DBG('The error is ' || SQLERRM);
            RETURN FALSE;
        END;
      END IF;
    END IF;
    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.COUNT > 0 THEN

      BEGIN
        DELETE FROM STTMS_AUTO_ACC_NOMINEES
         WHERE CUST_AC_NO =
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
        DBG('rows deleted in sttms_auto_acc_nominees is  ' || SQL%ROWCOUNT);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          DBG('The error is ' || SQLERRM);
          RETURN FALSE;
      END;
      BEGIN

        FOR L_NOM IN P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.FIRST .. P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.LAST LOOP
          INSERT INTO STTMS_AUTO_ACC_NOMINEES
            (BRANCH_CODE,
             CUST_AC_NO,
             NOMINEE_NAME,
             NOMINEE_DOB,
             RELATIONSHIP,
             ADDRESS1,
             ADDRESS2,
             ADDRESS3,
             ADDRESS4,
             PINCODE,
             NOMINEE_ID,
             IS_MINOR,
             GUARDIAN_NAME,
             GUARDIAN_RELATION,
             GUARD_ADDR1,
             GUARD_ADDR2,
             GUARD_ADDR3,
             GUARD_ADDR4,
             GUARD_PINCODE)
          VALUES
            (P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .NOMINEE_NAME,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .NOMINEE_DOB,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .RELATIONSHIP,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .ADDRESS1,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .ADDRESS2,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .ADDRESS3,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES       (L_NOM)
             .ADDRESS4,

             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .PINCODE,

             (L_NOM),
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .IS_MINOR,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARDIAN_NAME,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARDIAN_RELATION,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARD_ADDR1,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARD_ADDR2,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARD_ADDR3,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARD_ADDR4,

             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES(L_NOM)
             .GUARD_PINCODE);

          DBG('rows inserted in sttms_auto_acc_nominees is  ' ||
              SQL%ROWCOUNT);
        END LOOP;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          DBG('The error is ' || SQLERRM);
          RETURN FALSE;
      END;
    END IF;

    IF NVL(P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECK_BOOK_REQUEST,
           'N') = 'Y' THEN
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.BRANCH_CODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE;
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS.CUST_AC_NO  := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
      IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.BRANCH IS NULL OR
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.ACCOUNT IS NULL

       THEN
        P_ERR_CODE   := 'ST-CHQ-01';
        P_ERR_PARAMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      BEGIN

        DELETE FROM STTMS_AUTO_CHQBOOK
         WHERE ACCOUNT =
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.REQUEST_STATUS := 'Requested';
        INSERT INTO STTMS_AUTO_CHQBOOK
        VALUES P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK;
        DBG('rows inserted is sttms_auto_chqbook ' || SQL%ROWCOUNT);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          DBG('The error is ' || SQLERRM);
          RETURN FALSE;
      END;
    END IF;
    IF NVL(P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DEBIT_CARD_REQUEST,
           'N') = 'Y' THEN
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.BRANCH_CODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE;
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CUST_AC_NO  := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CUST_NO     := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO;
      IF P_SOURCE <> 'FLEXCUBE' THEN
        IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.REQUEST_REFERENCE_NO IS NULL THEN
          IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_PRODUCT IS NULL THEN
            DBG('Card Product cannot be null');
            P_ERR_CODE   := 'ST-CRDM07';
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         P_ERR_CODE,
                         P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
          DBG('INSIDE IF---');

          IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_PRODUCT,
                                             GLOBAL.APPLICATION_DATE,
                                             PSERIAL,
                                             PREFERENCENO,
                                             P_ERR_CODE) THEN
            DBG('Failed in generating internal reference number with error code ' ||
                P_ERR_CODE);
            ROLLBACK;
            RETURN FALSE;
          END IF;
          DBG('Came out of this');
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.REQUEST_REFERENCE_NO := PREFERENCENO;
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_APPL_DATE       := GLOBAL.APPLICATION_DATE;
        END IF;
      END IF;
      IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.BRANCH_CODE IS NULL OR
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CUST_AC_NO IS NULL OR
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CUST_NO IS NULL OR
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.REQUEST_REFERENCE_NO IS NULL THEN
        P_ERR_CODE   := 'ST-CRD-01';
        P_ERR_PARAMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      BEGIN

        DELETE FROM STTM_AUTO_DEBITCARD
         WHERE CUST_AC_NO =
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.CARD_STATUS  := 'R';
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD.PRIMARY_CARD := 'Y';
        INSERT INTO STTMS_AUTO_DEBITCARD
        VALUES P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD;
        DBG('rows inserted in sttms_auto_debitcard is   ' || SQL%ROWCOUNT);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          DBG('The error is ' || SQLERRM);
          RETURN FALSE;
      END;
    END IF;

    BEGIN
      DELETE FROM MITB_CLASS_MAPPING
       WHERE UNIT_REF_NO =
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
      DBG('rows deleted in mitbs_class_mapping is  ' || SQL%ROWCOUNT);

      P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.BRANCH_CODE := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE;
      P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.UNIT_REF_NO := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
      P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.UNIT_TYPE   := 'A';

      INSERT INTO MITBS_CLASS_MAPPING
      VALUES P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING;
      DBG('rows inserted in mitbs_class_mapping is  ' || SQL%ROWCOUNT);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        DBG('The error is ' || SQLERRM);
        RETURN FALSE;

    END;

    DBG('Returning Success from fn_cust_mod_auto_acc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_cust_mod_auto_acc' || SQLERRM);
      DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

      RETURN FALSE;
  END FN_CUST_MOD_AUTO_ACC;

  FUNCTION FN_QUERY_STTMS_ACCOUNT(P_FUNCTION_ID IN VARCHAR2,
                                  P_SOURCE      IN VARCHAR2,
                                  P_ACTION_CODE IN VARCHAR2,
                                  P_WRK_STDCIF  IN OUT NOCOPY STPKS_STDCIF_MAIN.TY_STDCIF,
                                  P_ERR_CODE    IN OUT VARCHAR2,
                                  P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    ACC_NO       VARCHAR2(20);
    L_WRK_STDCIF STPKS_STDCIF_MAIN.TY_STDCIF;
  BEGIN
    DBG('Inside fn_query_sttms_account');

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CUSTOM THEN
      IF NOT
          STPKS_STDCIF_UTILS_0_CUSTOM.FN_PRE_QUERY_STTMS_ACCOUNT(P_FUNCTION_ID,
                                                                 P_SOURCE,
                                                                 P_ACTION_CODE,
                                                                 P_WRK_STDCIF,
                                                                 P_ERR_CODE,
                                                                 P_ERR_PARAMS) THEN
        DBG('failed in stpks_stdcif_utils_0_custom.fn_Pre_query_sttms_account');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CLUSTER THEN
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_PRE_QUERY_STTMS_ACCOUNT(P_FUNCTION_ID,
                                                                  P_SOURCE,
                                                                  P_ACTION_CODE,
                                                                  P_WRK_STDCIF,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
        DBG('failed in stpks_stdcif_utils_0_cluster.fn_Pre_query_sttms_account');
        RETURN FALSE;
      END IF;
    END IF;

    L_WRK_STDCIF.TY_STCCUACC.V_CSTBS_UI_COLUMNS.CHAR_FIELD46 := P_WRK_STDCIF.TY_STCCUACC.V_CSTBS_UI_COLUMNS.CHAR_FIELD46;
    L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.CHQ_TYPE   := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.CHQ_TYPE;

    DBG('customer no IS ' || P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
    IF ACC_NO IS NULL THEN
      BEGIN
        SELECT CUST_AC_NO
          INTO ACC_NO
          FROM STVWS_AUTO_ACCOUNT
         WHERE CUST_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO

           AND BRANCH_CODE =
               NVL(P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                   P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('In WOT of acc_no' || SQLERRM);
          RETURN FALSE;
      END;
    END IF;
    BEGIN
      SELECT *
        INTO L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT
        FROM STVWS_AUTO_ACCOUNT
       WHERE CUST_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO

         AND BRANCH_CODE =
             NVL(P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found in stvws_auto_account' || SQLERRM);
    END;
    BEGIN
      SELECT *
        BULK COLLECT
        INTO L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES
        FROM STVWS_AUTO_ACC_NOMINEES
       WHERE CUST_AC_NO = ACC_NO

         AND BRANCH_CODE =
             NVL(P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found in stvws_auto_account' || SQLERRM);
    END;

    BEGIN
      SELECT *
        BULK COLLECT
        INTO L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT
        FROM STVWS_AUTO_ACC_JOINT
       WHERE CUST_AC_NO = ACC_NO

         AND BRANCH_CODE =
             NVL(P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found in stvws_auto_account' || SQLERRM);
    END;

    BEGIN
      SELECT *
        BULK COLLECT
        INTO L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST
        FROM STVWS_AUTO_DOC_CHECKLIST
       WHERE CUST_AC_NO = ACC_NO

         AND BRANCH_CODE =
             NVL(P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found in stvws_auto_account' || SQLERRM);
    END;

    BEGIN
      SELECT *
        INTO L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS
        FROM STVWS_AUTO_DOC_REMARKS
       WHERE CUST_AC_NO = ACC_NO

         AND BRANCH_CODE =
             NVL(P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found in stvws_auto_doc_remarks' || SQLERRM);
    END;

    IF NVL(L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DEBIT_CARD_REQUEST,
           'N') = 'Y' THEN
      BEGIN
        SELECT *
          INTO L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD
          FROM STVWS_AUTO_DEBITCARD
         WHERE CUST_AC_NO = ACC_NO

           AND BRANCH_CODE =
               NVL(P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                   P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found in stvws_auto_debitcard' || SQLERRM);
      END;
    END IF;
    IF NVL(L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECK_BOOK_REQUEST,
           'N') = 'Y' THEN
      BEGIN
        SELECT *
          INTO L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK
          FROM STVWS_AUTO_CHQBOOK
         WHERE ACCOUNT = ACC_NO

           AND BRANCH =
               NVL(P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                   P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found in stvws_auto_chqbook' || SQLERRM);
      END;
    END IF;

    BEGIN
      BEGIN
        SELECT *
          INTO L_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING
          FROM MITBS_CLASS_MAPPING
         WHERE UNIT_REF_NO = ACC_NO

           AND BRANCH_CODE =
               NVL(P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                   P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found in mitbs_class_mapping' || SQLERRM);
      END;
    END;
    BEGIN
      SELECT *
        BULK COLLECT
        INTO L_WRK_STDCIF.TY_STCCUACC.V_MITBS_ACCOUNT_CHANGE_LOG
        FROM MITBS_ACCOUNT_CHANGE_LOG
       WHERE ACCOUNT_NO = ACC_NO

         AND BRANCH =
             NVL(P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found in mitbs_class_mapping' || SQLERRM);

    END;
    BEGIN
      SELECT *
        BULK COLLECT
        INTO L_WRK_STDCIF.TY_STCCUACC.V_MITBS_BAL_TRANSFER_LOG
        FROM MITBS_BAL_TRANSFER_LOG
       WHERE REFERENCE_NO = ACC_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found in mitbs_class_mapping' || SQLERRM);

    END;

    P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE     := L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE;
    P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO      := L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
    P_WRK_STDCIF.TY_STCCUACC                                      := L_WRK_STDCIF.TY_STCCUACC;
    P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO := L_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MULTI_CCY_AC_NO;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CUSTOM THEN
      IF NOT
          STPKS_STDCIF_UTILS_0_CUSTOM.FN_POST_QUERY_STTMS_ACCOUNT(P_FUNCTION_ID,
                                                                  P_SOURCE,
                                                                  P_ACTION_CODE,
                                                                  P_WRK_STDCIF,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
        DBG('failed in stpks_stdcif_utils_0_custom.fn_Post_query_sttms_account');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CLUSTER THEN
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_POST_QUERY_STTMS_ACCOUNT(P_FUNCTION_ID,
                                                                   P_SOURCE,
                                                                   P_ACTION_CODE,
                                                                   P_WRK_STDCIF,
                                                                   P_ERR_CODE,
                                                                   P_ERR_PARAMS) THEN
        DBG('failed in stpks_stdcif_utils_0_cluster.fn_Post_query_sttms_account');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Returning success from fn_query_sttms_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_query_sttms_account' || SQLERRM);
      DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

      RETURN FALSE;
  END FN_QUERY_STTMS_ACCOUNT;

  FUNCTION FN_AUTO_CREATE_ACCOUNT(P_FUNCTION_ID IN VARCHAR2,
                                  P_ACTION_CODE IN VARCHAR2,
                                  P_SOURCE      IN VARCHAR2,
                                  P_WRK_STDCIF  IN OUT NOCOPY STPKS_STDCIF_MAIN.TY_STDCIF,
                                  P_PREV_STDCIF IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                  P_STATUS      IN VARCHAR2,
                                  P_ERR_CODE    IN OUT VARCHAR2,
                                  P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_TY_REC_CUSTACC_UPD STPKS_ACCOUNT_UPLOAD_TYPE.TY_REC_CUSTACC_UPD;
    L_TY_CHKSUBSYS       STPKS_ACCOUNT_UPLOAD_TYPE.TY_TB_EXIST_SUBSYS;
    L_ROWID              ROWID;
    L_OVERRIDE_FLAG      VARCHAR2(3);
    L_STDCIF             STPKS_STDCIF_MAIN.TY_STDCIF;
    L_INDEX              NUMBER;
    L_LAST               NUMBER;
    L_COUNT_1            NUMBER;
    L_COUNT_2            NUMBER;
    L_UDF_DETAILS        UVPKS_UDF_UPLOAD.TY_UPL_FUNC_UDF;
    L_COUNT_3            NUMBER;
    I_INDEX              NUMBER := 1;
    L_ACC_NO             VARCHAR2(20);
    L_REC_KEY            VARCHAR2(50);

    L_STATUS           VARCHAR2(20);
    P_SOURCE_OPERATION VARCHAR2(20);
    P_MULTI_TRIP_ID    VARCHAR2(20);

    L_CUST_CAT VARCHAR2(20);
    L_ACCLASS  VARCHAR2(20);
    CURSOR CR_CUST_ACC_CAT(ACCLASS VARCHAR2) IS
      SELECT B.CUST_CAT
        FROM STTMS_ACCOUNT_CLASS A, STTMS_ACCLS_CAT_RESTR B
       WHERE A.CUSCAT_LIST = 'D'
         AND A.ACCOUNT_CLASS = ACCLASS
         AND A.ACCOUNT_CLASS = B.ACCOUNT_CLASS;

    L_USERROLE_COUNT      NUMBER;
    L_USERROLE_COUNT2     NUMBER;
    L_USERROLE_COUNT3     NUMBER;
    L_FIRST_CHECK_NO      STVWS_AUTO_CHQBOOK.FIRST_CHECK_NO%TYPE;
    L_CHQ_NUM             STTM_BANK.CHQ_NUMBERING%TYPE;
    L_CUST_CAT_COUNT      NUMBER := 0;
    L_MUDARABAH_ACC_CLASS VARCHAR2(1);
    L_FUNCTION_ID         STTB_RECORD_MASTER.FUNCTION_ID%TYPE;
  BEGIN
    DBG('In fn_auto_create_account');

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CUSTOM THEN
      IF NOT
          STPKS_STDCIF_UTILS_0_CUSTOM.FN_PRE_AUTO_CREATE_ACCOUNT(P_FUNCTION_ID,
                                                                 P_ACTION_CODE,
                                                                 P_SOURCE,
                                                                 P_WRK_STDCIF,
                                                                 P_PREV_STDCIF,
                                                                 P_STATUS,
                                                                 P_ERR_CODE,
                                                                 P_ERR_PARAMS) THEN
        DBG('failed in stpks_stdcif_utils_0_custom.fn_Pre_auto_create_account');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CLUSTER THEN
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_PRE_AUTO_CREATE_ACCOUNT(P_FUNCTION_ID,
                                                                  P_ACTION_CODE,
                                                                  P_SOURCE,
                                                                  P_WRK_STDCIF,
                                                                  P_PREV_STDCIF,
                                                                  P_STATUS,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
        DBG('failed in stpks_stdcif_utils_0_cluster.fn_Pre_auto_create_account');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS='||P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS);
    DBG('P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY='||P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY);
    DBG('P_SOURCE_OPERATION='||P_SOURCE_OPERATION);
    DBG('P_ACTION_CODE='||P_ACTION_CODE);
    
    --EKYC EOD Changes Starts sampath
    IF P_SOURCE = 'DIGIKYC' AND P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY = 'IND_ECIF'
      AND P_ACTION_CODE = 'VERSIONDELETE' THEN
    
    P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS := 'EA01';  
    
    END IF;
    --EKYC EOD Changes Ends sampath
  
    SELECT COUNT(1)
      INTO L_CUST_CAT_COUNT
      FROM STVW_ACLASS_CATEGORIES T
     WHERE T.ACCOUNT_CLASS =
           P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS
       AND T.CUST_CAT = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY;
    IF L_CUST_CAT_COUNT = 0 THEN
      DBG('Customer Category is invalid or restricted to the account class ');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'ST-CAT-03',
                   P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY || '~' ||
                   P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS || '~');
    END IF;

    DBG('user: ' || GLOBAL.USER_ID);
    DBG('Branch: ' || GLOBAL.CURRENT_BRANCH);

    BEGIN
      SELECT COUNT(*)
        INTO L_USERROLE_COUNT
        FROM (SELECT 1
                FROM SMVW_BROWSER_FUNCTIONS F
               WHERE F.USER_ID = GLOBAL.USER_ID
                 AND F.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                 AND F.FUNCTION_ID = 'STDCUSAC');
    END;
    IF L_USERROLE_COUNT < 1 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-USR-03', '');
      RETURN FALSE;
    END IF;
    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECK_BOOK_REQUEST = 'Y' THEN

      BEGIN
        SELECT COUNT(*)
          INTO L_USERROLE_COUNT2
          FROM (SELECT 1
                  FROM SMVW_BROWSER_FUNCTIONS F
                 WHERE F.USER_ID = GLOBAL.USER_ID
                   AND F.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                   AND F.FUNCTION_ID = 'CADCHBOO');
      END;
      IF L_USERROLE_COUNT2 < 1 THEN
        OVPKSS.PR_APPENDTBL('ST-USR-04', P_ERR_PARAMS);
        RETURN FALSE;
      END IF;

    END IF;
    IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DEBIT_CARD_REQUEST = 'Y' THEN

      BEGIN
        SELECT COUNT(*)
          INTO L_USERROLE_COUNT3
          FROM (SELECT 1
                  FROM SMVW_BROWSER_FUNCTIONS F
                 WHERE F.USER_ID = GLOBAL.USER_ID
                   AND F.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                   AND F.FUNCTION_ID = 'STDCRDMS');
      END;
      IF L_USERROLE_COUNT3 < 1 THEN
        OVPKSS.PR_APPENDTBL('ST-USR-05', P_ERR_PARAMS);
        RETURN FALSE;
      END IF;

    END IF;
    IF P_STATUS <> 'A' THEN
      RETURN TRUE;
    END IF;
    DBG('p_status' || P_STATUS);
    IF P_ACTION_CODE = 'AUTH' THEN

      DBG('cust_ac_no ' ||
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO);
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT_1
          FROM STVWS_AUTO_ACCOUNT
         WHERE CUST_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In WOT of STVWS_AUTO_ACCOUNT ' || SQLERRM);
          RETURN FALSE;
      END;
      DBG('count is ' || L_COUNT_1);
      IF L_COUNT_1 > 0 THEN
        DBG('Calling stpks_stdcif_utils_0.fn_query_sttms_account');
        IF NOT FN_QUERY_STTMS_ACCOUNT(P_FUNCTION_ID,
                                      P_SOURCE,
                                      P_ACTION_CODE,
                                      P_WRK_STDCIF,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
          DBG('Failed in stpks_stdcif_utils_0.fn_query_sttms_account ' ||
              SQLERRM);
          RETURN FALSE;
        END IF;

        IF L_ACC_NO IS NULL THEN
          L_ACC_NO := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
        END IF;
        IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.COUNT > 0 THEN
          IF NOT L_TY_CHKSUBSYS.EXISTS('Jointholders') THEN
            L_TY_CHKSUBSYS('Jointholders') := 'Jointholders';
          END IF;
        END IF;
        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT_3
            FROM MITBS_CLASS_MAPPING
           WHERE UNIT_REF_NO =
                 P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
        END;
        IF L_COUNT_3 > 0 THEN
          IF NOT L_TY_CHKSUBSYS.EXISTS('Misdetails') THEN

            L_TY_CHKSUBSYS('Misdetails') := 'Misdetails';

          END IF;
        END IF;
        IF P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL.COUNT > 0 THEN
          IF NOT L_TY_CHKSUBSYS.EXISTS('Udfdetails') THEN
            L_TY_CHKSUBSYS('Udfdetails') := 'Udfdetails';
          END IF;
        END IF;

      END IF;

      BEGIN
        SELECT NVL(MUDARABAH_ACC_CLASS, 'N')
          INTO L_MUDARABAH_ACC_CLASS
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('in when no data found');
      END;
      DBG('l_mudarabah_acc_class--->' || L_MUDARABAH_ACC_CLASS);

      BEGIN
        DBG('unit ref no ' ||
            P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.UNIT_REF_NO);
        DBG('pool_code ' ||
            P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING.POOL_CODE);
        DBG('Authorising with non auto auth user');
        DBG('cUSTOMER NO IN STTM_CUSTOMER ISsssssssssss ;;; ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
        DBG(' p_wrk_stdcif CUSTOMER NO IN AUTO ACCOUNT ISssssssssssss   ' ||
            P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO);
        DBG(' p_wrk_stdcif customer account no before auth isssssssss --> ' ||
            P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO);
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.BRANCH_CODE     := P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CUST_NO         := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO;
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CUST_AC_NO      := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CCY             := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CCY;
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.ACCOUNT_CLASS   := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS;
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.MULTI_CCY_AC_NO := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MULTI_CCY_AC_NO;

        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.MAKER_ID         := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.MAKER_ID,
                                                                     P_PREV_STDCIF.V_STTMS_CUSTOMER.MAKER_ID);
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.MAKER_DT_STAMP   := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.MAKER_DT_STAMP,
                                                                     P_PREV_STDCIF.V_STTMS_CUSTOMER.MAKER_DT_STAMP);
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CHECKER_ID       := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CHECKER_ID,
                                                                     P_PREV_STDCIF.V_STTMS_CUSTOMER.CHECKER_ID);
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.CHECKER_DT_STAMP := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CHECKER_DT_STAMP,
                                                                     P_PREV_STDCIF.V_STTMS_CUSTOMER.CHECKER_DT_STAMP);
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.MOD_NO           := P_WRK_STDCIF.V_STTMS_CUSTOMER.MOD_NO;
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.AUTH_STAT        := 'A';
        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.RECORD_STAT      := 'O';

        L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.SPL_AC_GEN := 'N';

        IF L_MUDARABAH_ACC_CLASS = 'Y' THEN
          L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.MUDARABAH_ACCOUNTS := 'Y';
          L_FUNCTION_ID                                           := 'IADCUSAC';
        ELSE
          L_TY_REC_CUSTACC_UPD.ACC_DETAILS_UPD.MUDARABAH_ACCOUNTS := 'N';
          L_FUNCTION_ID                                           := 'STDCUSAC';
        END IF;

        L_REC_KEY := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE || '~' ||
                     P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO || '~' ||
                     P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO || '~';
        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT_2
            FROM CSTM_FUNCTION_USERDEF_FIELDS

           WHERE FUNCTION_ID = L_FUNCTION_ID
             AND REC_KEY = L_REC_KEY;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_COUNT_2 := 0;
          WHEN OTHERS THEN
            DBG('IN WOT of cstm_function_userdef_fields ' || SQLERRM);
            RETURN FALSE;
        END;
        IF L_COUNT_2 > 0 THEN

          IF NOT UVPKS_UDF_UPLOAD.FN_QUERY_FUNC_UDFDETAILS(L_FUNCTION_ID,
                                                           L_REC_KEY,
                                                           L_UDF_DETAILS,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
            RETURN FALSE;
          END IF;
          IF L_UDF_DETAILS.COUNT > 0 THEN
            DECLARE
              L_CONT NUMBER := L_UDF_DETAILS.FIRST;

            BEGIN
              LOOP

                P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CONT).FUNCTION_ID := L_FUNCTION_ID;
                P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CONT).REC_KEY := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE || '~' ||
                                                                                     P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO || '~';
                P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CONT).FIELD_NAME := L_UDF_DETAILS(L_CONT)
                                                                                        .FIELD_NAME;
                P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CONT).FIELD_VAL := L_UDF_DETAILS(L_CONT)
                                                                                       .FIELD_VAL;
                P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CONT).DATA_TYPE := L_UDF_DETAILS(L_CONT)
                                                                                       .DATA_TYPE;
                P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CONT).VAL_TYPE := L_UDF_DETAILS(L_CONT)
                                                                                      .VAL_TYPE;
                EXIT WHEN L_CONT = L_UDF_DETAILS.LAST;
                L_CONT := L_UDF_DETAILS.NEXT(L_CONT);
              END LOOP;
            END;
          END IF;
        END IF;
        STPKS_ACCOUNT_UPLOAD_TYPE.PR_SET_CIF_FLAG('Y', P_WRK_STDCIF);
        DBG('Calling stpks_stdcif_utils_0.fn_stdcif_to_upld');
        IF NOT STPKS_STDCIF_UTILS_0.FN_ACCOUNT_TO_UPLD(P_WRK_STDCIF,
                                                       L_TY_REC_CUSTACC_UPD,
                                                       P_SOURCE,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS) THEN
          DBG('failed in stpks_stdcif_utils_0.fn_stdcif_to_upld' ||
              SQLERRM);
        ELSE
          DBG('Calling stpks_account_upload_type.fn_upload_an_account');
          IF NOT
              STPKS_ACCOUNT_UPLOAD_TYPE.FN_UPLOAD_AN_ACCOUNT(L_TY_REC_CUSTACC_UPD,
                                                             L_TY_CHKSUBSYS,
                                                             P_SOURCE,
                                                             GLOBAL.USER_ID,
                                                             'FSFS',
                                                             L_ROWID,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS,
                                                             L_OVERRIDE_FLAG) THEN
            DBG('failed in stpks_account_upload_type.fn_upload_an_account' ||
                SQLERRM);
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         NVL(P_ERR_CODE, 'ST-CUS-01'),
                         NULL);
            RETURN FALSE;

          END IF;
        END IF;
        STPKS_ACCOUNT_UPLOAD_TYPE.PR_SET_CIF_FLAG('N', P_WRK_STDCIF);
      END;
    END IF;

    BEGIN
      SELECT CHQ_NUMBERING INTO L_CHQ_NUM FROM STTM_BANK;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('CHEQUE NUMBERING IS NULL..');
    END;
    L_FIRST_CHECK_NO := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK.FIRST_CHECK_NO;
    DBG('first check no is :' || L_FIRST_CHECK_NO);
    IF ((L_FIRST_CHECK_NO = '11111') AND (L_CHQ_NUM = 'U')) THEN

      DBG('Do you want the system to generate the cheque number automatically?');
      P_ERR_CODE   := 'CA-CHQ-002';
      P_ERR_PARAMS := '';
      DBG('ERROR code  here' || P_ERR_CODE);
      DBG(P_ERR_PARAMS);

      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CUSTOM THEN
      IF NOT
          STPKS_STDCIF_UTILS_0_CUSTOM.FN_POST_AUTO_CREATE_ACCOUNT(P_FUNCTION_ID,
                                                                  P_ACTION_CODE,
                                                                  P_SOURCE,
                                                                  P_WRK_STDCIF,
                                                                  P_PREV_STDCIF,
                                                                  P_STATUS,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
        DBG('failed in stpks_stdcif_utils_0_custom.fn_Post_auto_create_account');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT STPKS_STDCIF_UTILS_0.FN_SKIP_CLUSTER THEN
      IF NOT
          STPKS_STDCIF_UTILS_0_CLUSTER.FN_POST_AUTO_CREATE_ACCOUNT(P_FUNCTION_ID,
                                                                   P_ACTION_CODE,
                                                                   P_SOURCE,
                                                                   P_WRK_STDCIF,
                                                                   P_PREV_STDCIF,
                                                                   P_STATUS,
                                                                   P_ERR_CODE,
                                                                   P_ERR_PARAMS) THEN
        DBG('failed in stpks_stdcif_utils_0_cluster.fn_Post_auto_create_account');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Returning success from fn_auto_create_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_auto_create_account' || SQLERRM);
      DBG('the error is here ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

      RETURN FALSE;
  END FN_AUTO_CREATE_ACCOUNT;

  FUNCTION FN_PARSE_SUBSYSSTATS(P_FUNCTION_ID       IN VARCHAR2,
                                P_SUBSYS_LIST       IN VARCHAR2,
                                P_SUBSYSTEM_TY_FLDS IN OUT GWPKS_UTIL.TY_SUBSYSTEM_FLDS)
    RETURN BOOLEAN IS
    L_SUBSYS_LIST VARCHAR2(1000);
    L_SUBSYSSTAT  VARCHAR2(1000);
    L_SUBSYS      VARCHAR2(1000);
    L_STAT        VARCHAR2(1);
    L_NUM         NUMBER;
    L_NUM1        NUMBER;
    I             NUMBER;
    J             NUMBER;
    K             NUMBER;
  BEGIN
    DBG('Inside fn_parse_subsysstats');
    DBG('p_subsys_list:  ' || P_SUBSYS_LIST);
    I     := 1;
    L_NUM := 1;
    WHILE (I > 0) LOOP
      J     := L_NUM;
      L_NUM := INSTR(P_SUBSYS_LIST, ';', 1, I);
      DBG(L_NUM);
      IF L_NUM = 0 THEN

        DBG('Exiting subsys loop');
        EXIT;
      END IF;
      K := L_NUM - J;
      IF J > 1 THEN

        J := J + 1;
        K := K - 1;
      END IF;
      L_SUBSYSSTAT := SUBSTR(P_SUBSYS_LIST, J, K);
      DBG(L_SUBSYSSTAT);
      L_NUM1 := INSTR(L_SUBSYSSTAT, ':', 1, 1);
      L_SUBSYS := SUBSTR(L_SUBSYSSTAT, 1, L_NUM1 - 1);
      L_STAT := SUBSTR(L_SUBSYSSTAT, L_NUM1 + 1);
      P_SUBSYSTEM_TY_FLDS(L_SUBSYS).STAT := L_STAT;
      I := I + 1;
    END LOOP;
    DBG('fn_parse_subsysstats returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_parse_subsysstats with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_PARSE_SUBSYSSTATS;

  FUNCTION FN_BUILD_SUBSYSSTAT(P_FUNCTION_ID       IN VARCHAR2,
                               P_SUBSYSTEM_TY_FLDS IN GWPKS_UTIL.TY_SUBSYSTEM_FLDS)
    RETURN VARCHAR2 IS

    L_SUBSYSSTAT VARCHAR2(1000);
  BEGIN
    DBG('Inside fn_build_subsysstat');
    L_SUBSYSSTAT := 'UDFDETAILS:' || P_SUBSYSTEM_TY_FLDS('UDFDETAILS').STAT || ';';
    L_SUBSYSSTAT := L_SUBSYSSTAT || 'MISDETAILS:' || P_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT || ';';
    DBG('fn_build_subsysstat returning');
    RETURN L_SUBSYSSTAT;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_build_subsysstat with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      L_SUBSYSSTAT := '';
      RETURN L_SUBSYSSTAT;
  END FN_BUILD_SUBSYSSTAT;

  PROCEDURE PR_STDCIF_TO_EXPOSURE(P_STDCIF   IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                  L_EXPOSURE IN OUT NOCOPY ELPKS_LIABILITY_SERVICE.TY_TBL_ELVW_LIAB_CUST_EXPOSURE) IS
    L_IDX        NUMBER;
    L_LAST       NUMBER;
    L_FUNCTIONID VARCHAR2(8);
  BEGIN
    DBG('inside stpks_stdcif_utils_0.pr_stdcif_to_exposure');
    IF P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE.COUNT > 0 THEN
      L_IDX  := P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE.FIRST;
      L_LAST := P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE.LAST;
      LOOP

        L_EXPOSURE(L_IDX).EXPOSURE_ID := P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE(L_IDX)
                                         .EXPOSURE_ID;
        L_EXPOSURE(L_IDX).MOD_NO := P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE(L_IDX)
                                    .MOD_NO;
        L_EXPOSURE(L_IDX).EXPOSURE_NAME := P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE(L_IDX)
                                           .EXPOSURE_NAME;
        L_EXPOSURE(L_IDX).EXPOSURE_DESC := P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE(L_IDX)
                                           .EXPOSURE_DESC;
        L_EXPOSURE(L_IDX).EXPOSURE_TYPE := P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE(L_IDX)
                                           .EXPOSURE_TYPE;
        EXIT WHEN L_IDX = L_LAST;
        L_IDX := P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE.NEXT(L_IDX);
      END LOOP;
    END IF;
    DBG('returning from stpks_stdcif_utils_0.pr_stdcif_to_exposure');
  END PR_STDCIF_TO_EXPOSURE;

  PROCEDURE PR_STDCIF_TO_GEDLCCKL(P_STDCIF    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                  P_LIABILITY IN OUT ELTMS_LIAB%ROWTYPE) IS
    L_IDX        NUMBER;
    L_LAST       NUMBER;
    L_FUNCTIONID VARCHAR2(8);
    L_LIAB_ID    NUMBER(20);
  BEGIN
    DBG('inside stpks_stdcif_utils_0.pr_stdcif_to_gedlcckl');

    BEGIN
      SELECT ID
        INTO L_LIAB_ID
        FROM GETM_LIAB
       WHERE LIAB_NO = P_STDCIF.V_STVWS_CUST_LIAB.MAIN_LIAB_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('EXCEPTION:2: stpks_stdcif_utils_0.pr_stdcif_to_gedlcckl: no return false. code, after if, will run');
    END;

    P_LIABILITY.LIAB_NO              := P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO;
    P_LIABILITY.LIAB_NAME            := P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NAME;
    P_LIABILITY.LIAB_BRANCH          := P_STDCIF.V_STVWS_CUST_LIAB.LIAB_BRANCH;
    P_LIABILITY.LIAB_CCY             := P_STDCIF.V_STVWS_CUST_LIAB.LIAB_CCY;
    P_LIABILITY.OVERALL_LIMIT        := P_STDCIF.V_STVWS_CUST_LIAB.OVERALL_LIMIT;
    P_LIABILITY.REVISION_DATE        := P_STDCIF.V_STVWS_CUST_LIAB.REVISION_DATE;
    P_LIABILITY.CATEGORY             := P_STDCIF.V_STVWS_CUST_LIAB.CATEGORY;
    P_LIABILITY.USER_DEFINE_STATUS   := P_STDCIF.V_STVWS_CUST_LIAB.USER_DEFINE_STATUS;
    P_LIABILITY.UNADVISED            := P_STDCIF.V_STVWS_CUST_LIAB.UNADVISED;
    P_LIABILITY.NETTING_REQUIRED     := P_STDCIF.V_STVWS_CUST_LIAB.NETTING_REQUIRED;
    P_LIABILITY.OVERALL_SCORE        := P_STDCIF.V_STVWS_CUST_LIAB.OVERALL_SCORE;
    P_LIABILITY.FX_CLEAN_RISK_LIMIT  := P_STDCIF.V_STVWS_CUST_LIAB.FX_CLEAN_RISK_LIMIT;
    P_LIABILITY.SEC_CLEAN_RISK_LIMIT := P_STDCIF.V_STVWS_CUST_LIAB.SEC_CLEAN_RISK_LIMIT;
    P_LIABILITY.SEC_PSTL_RISK_LIMIT  := P_STDCIF.V_STVWS_CUST_LIAB.SEC_PSTL_RISK_LIMIT;

    P_LIABILITY.MAIN_LIAB_ID  := L_LIAB_ID;
    P_LIABILITY.UTIL_AMT      := P_STDCIF.V_STVWS_CUST_LIAB.UTIL_AMOUNT;
    P_LIABILITY.CREDIT_RATING := P_STDCIF.V_STVWS_CUST_LIAB.CR_RATING;
    DBG('returning from stpks_stdcif_utils_0.pr_stdcif_to_gedlcckl');
  END PR_STDCIF_TO_GEDLCCKL;

  PROCEDURE PR_STDCIF_TO_ELDCULIK(P_STDCIF   IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                  P_ELDCULIK IN OUT ELPKS_LIABILITY_SERVICE.TY_ELDCULIK) IS
    L_IDX        NUMBER;
    L_LAST       NUMBER;
    L_FUNCTIONID VARCHAR2(8);
  BEGIN
    P_ELDCULIK.LIAB_CUST.BRANCH_CODE := P_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
    P_ELDCULIK.LIAB_CUST.LIAB_ID     := P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO;
    P_ELDCULIK.LIAB_CUST.CUSTOMER_NO := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
    DBG('xxx p_eldculik.liab_cust.branch_code:' ||
        P_ELDCULIK.LIAB_CUST.BRANCH_CODE);
    DBG('xxx p_eldculik.liab_cust.liab_id:' ||
        P_ELDCULIK.LIAB_CUST.LIAB_ID);
    DBG('xxx p_eldculik.liab_cust.customer_no:' ||
        P_ELDCULIK.LIAB_CUST.CUSTOMER_NO);

    PR_STDCIF_TO_EXPOSURE(P_STDCIF, P_ELDCULIK.LIAB_CUST_EXPOSURE);

    DBG('returning from stpks_stdcif_utils_0.pr_stdcif_to_eldculik');
  END PR_STDCIF_TO_ELDCULIK;

  PROCEDURE PR_STDCIF_TO_CUSTLIABLINK(P_STDCIF       IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                      P_CUSTLIABLINK IN OUT ELPKS_LIABILITY_SERVICE.TY_CUSTLIABLINK) IS
    L_IDX        NUMBER;
    L_LAST       NUMBER;
    L_FUNCTIONID VARCHAR2(8);
  BEGIN
    DBG('inside stpks_stdcif_utils_0.pr_stdcif_to_eldliab_eldculik');

    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.LIABILITY_NO   := P_STDCIF.V_STTMS_CUSTOMER.LIABILITY_NO;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.LOCAL_BRANCH   := P_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.CUSTOMER_NO    := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.SHORT_NAME     := P_STDCIF.V_STTMS_CUSTOMER.SHORT_NAME;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.CUSTOMER_TYPE  := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.CUSTOMER_NAME1 := SUBSTR(P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NAME1,
                                                              1,
                                                              35);

    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.ADDRESS_LINE1 := SUBSTRB(P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1,
                                                              1,
                                                              35);
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.ADDRESS_LINE2 := SUBSTRB(P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2,
                                                              1,
                                                              35);
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.ADDRESS_LINE3 := SUBSTRB(P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3,
                                                              1,
                                                              35);
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.ADDRESS_LINE4 := SUBSTRB(P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4,
                                                              1,
                                                              35);

    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.COUNTRY             := P_STDCIF.V_STTMS_CUSTOMER.COUNTRY;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.LANGUAGE            := P_STDCIF.V_STTMS_CUSTOMER.LANGUAGE;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.DECEASED            := P_STDCIF.V_STTMS_CUSTOMER.DECEASED;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.FROZEN              := P_STDCIF.V_STTMS_CUSTOMER.FROZEN;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.WHEREABOUTS_UNKNOWN := P_STDCIF.V_STTMS_CUSTOMER.WHEREABOUTS_UNKNOWN;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.PINCODE             := P_STDCIF.V_STTMS_CUSTOMER.PINCODE;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.NATIONALITY         := P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.CUSTOMER_CATEGORY   := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.RM_ID               := P_STDCIF.V_STTMS_CUSTOMER.RM_ID;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.RECORD_STAT         := P_STDCIF.V_STTMS_CUSTOMER.RECORD_STAT;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.AUTH_STAT           := P_STDCIF.V_STTMS_CUSTOMER.AUTH_STAT;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.MOD_NO              := P_STDCIF.V_STTMS_CUSTOMER.MOD_NO;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.MAKER_ID            := P_STDCIF.V_STTMS_CUSTOMER.MAKER_ID;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.MAKER_DT_STAMP      := P_STDCIF.V_STTMS_CUSTOMER.MAKER_DT_STAMP;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.CHECKER_ID          := P_STDCIF.V_STTMS_CUSTOMER.CHECKER_ID;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.CHECKER_DT_STAMP    := P_STDCIF.V_STTMS_CUSTOMER.CHECKER_DT_STAMP;
    P_CUSTLIABLINK.CODCIFDF.CUSTOMER.ONCE_AUTH           := P_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH;

    P_CUSTLIABLINK.CUST_UDF := P_STDCIF.UDF_DETAILS;

    PR_STDCIF_TO_GEDLCCKL(P_STDCIF, P_CUSTLIABLINK.LIAB.LIABILITY);

    IF P_STDCIF.V_STVWS_CUST_LIAB_SCORE.COUNT > 0 THEN
      L_IDX  := P_STDCIF.V_STVWS_CUST_LIAB_SCORE.FIRST;
      L_LAST := P_STDCIF.V_STVWS_CUST_LIAB_SCORE.LAST;
      LOOP
        P_CUSTLIABLINK.LIAB.LIAB_SCORE(L_IDX).SCORE := P_STDCIF.V_STVWS_CUST_LIAB_SCORE(L_IDX)
                                                       .SCORE;
        P_CUSTLIABLINK.LIAB.LIAB_SCORE(L_IDX).SCORE_NAME := P_STDCIF.V_STVWS_CUST_LIAB_SCORE(L_IDX)
                                                            .SCORE_NAME;
        P_CUSTLIABLINK.LIAB.LIAB_SCORE(L_IDX).SCORE_ID := P_STDCIF.V_STVWS_CUST_LIAB_SCORE(L_IDX)
                                                          .SCORE_ID;
        EXIT WHEN L_IDX = L_LAST;
        L_IDX := P_STDCIF.V_STVWS_CUST_LIAB_SCORE.NEXT(L_IDX);
      END LOOP;
    ELSE
      DBG('No records in p_stdcif.v_stvws_cust_liab_score');
    END IF;

    IF P_STDCIF.V_STVWS_CUST_LIAB_RATING.COUNT > 0 THEN
      L_IDX  := P_STDCIF.V_STVWS_CUST_LIAB_RATING.FIRST;
      L_LAST := P_STDCIF.V_STVWS_CUST_LIAB_RATING.LAST;
      LOOP
        P_CUSTLIABLINK.LIAB.LIAB_CREDIT_RATING(L_IDX).AGENCY_ID := P_STDCIF.V_STVWS_CUST_LIAB_RATING(L_IDX)
                                                                   .AGENCY_ID;
        P_CUSTLIABLINK.LIAB.LIAB_CREDIT_RATING(L_IDX).CREDIT_RATING_ID := P_STDCIF.V_STVWS_CUST_LIAB_RATING(L_IDX)
                                                                          .CREDIT_RATING_ID;
        P_CUSTLIABLINK.LIAB.LIAB_CREDIT_RATING(L_IDX).PRIMARY := P_STDCIF.V_STVWS_CUST_LIAB_RATING(L_IDX)
                                                                 .PRIMARY;
        P_CUSTLIABLINK.LIAB.LIAB_CREDIT_RATING(L_IDX).AGENCY_NAME := P_STDCIF.V_STVWS_CUST_LIAB_RATING(L_IDX)
                                                                     .AGENCY_NAME;
        P_CUSTLIABLINK.LIAB.LIAB_CREDIT_RATING(L_IDX).CREDIT_RATING := P_STDCIF.V_STVWS_CUST_LIAB_RATING(L_IDX)
                                                                       .CREDIT_RATING;
        EXIT WHEN L_IDX = L_LAST;
        L_IDX := P_STDCIF.V_STVWS_CUST_LIAB_RATING.NEXT(L_IDX);
      END LOOP;
    ELSE
      DBG('No records in p_stdcif.v_stvws_cust_liab_rating');
    END IF;

    IF P_STDCIF.V_STVWS_CUST_LIAB_UDF.COUNT > 0 THEN
      L_IDX        := P_STDCIF.V_STVWS_CUST_LIAB_UDF.FIRST;
      L_LAST       := P_STDCIF.V_STVWS_CUST_LIAB_UDF.LAST;
      L_FUNCTIONID := 'GEDMLIAB';
      LOOP
        P_CUSTLIABLINK.LIAB.LIAB_UDF(L_IDX).FUNCTION_ID := L_FUNCTIONID;
        P_CUSTLIABLINK.LIAB.LIAB_UDF(L_IDX).FIELD_NAME := P_STDCIF.V_STVWS_CUST_LIAB_UDF(L_IDX)
                                                          .FIELD_NAME;
        P_CUSTLIABLINK.LIAB.LIAB_UDF(L_IDX).DATA_TYPE := P_STDCIF.V_STVWS_CUST_LIAB_UDF(L_IDX)
                                                         .DATA_TYPE;
        P_CUSTLIABLINK.LIAB.LIAB_UDF(L_IDX).FIELD_VAL := P_STDCIF.V_STVWS_CUST_LIAB_UDF(L_IDX)
                                                         .FIELD_VAL;
        P_CUSTLIABLINK.LIAB.LIAB_UDF(L_IDX).VAL_TYPE := P_STDCIF.V_STVWS_CUST_LIAB_UDF(L_IDX)
                                                        .VAL_TYPE;
        EXIT WHEN L_IDX = L_LAST;
        L_IDX := P_STDCIF.V_STVWS_CUST_LIAB_UDF.NEXT(L_IDX);
      END LOOP;
    END IF;

    PR_STDCIF_TO_ELDCULIK(P_STDCIF, P_CUSTLIABLINK.LINK);

    DBG('returning from stpks_stdcif_utils_0.pr_stdcif_to_custliablink');
  END PR_STDCIF_TO_CUSTLIABLINK;

  FUNCTION FN_PICK_LIAB_UDF(P_STDCIF     IN OUT NOCOPY STPKS_STDCIF_MAIN.TY_STDCIF,
                            P_ERR_CODE   IN OUT VARCHAR2,
                            P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN AS
    L_FUNCTION_ID VARCHAR2(20);
    L_REC_KEY     VARCHAR2(100);

    CURSOR CR_UDF_FIELDS_MAP(P_FN_ID VARCHAR2) IS
      SELECT UFM.FIELD_NAME, F.FIELD_TYPE, F.VAL_TYPE
        FROM CSTM_FUNCTION_UDF_FIELDS_MAP UFM, UDTMS_FIELDS F
       WHERE UFM.FUNCTION_ID = P_FN_ID
         AND UFM.AUTH_STAT = 'A'
         AND UFM.FIELD_NAME = F.FIELD_NAME
       ORDER BY UFM.FIELD_NUM;

    L_STDCIF STPKS_STDCIF_MAIN.TY_STDCIF;
    I_INDEX  NUMBER := 1;
  BEGIN
    L_FUNCTION_ID := 'GEDMLIAB';
    L_REC_KEY     := P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO || '~';
    BEGIN
      IF UVPKS_UDF_UPLOAD.FN_PICKUP_FUNC_UDF(L_FUNCTION_ID,
                                             L_REC_KEY,
                                             P_ERR_CODE,
                                             P_ERR_PARAMS) THEN
        BEGIN
          FOR EACH_REC IN CR_UDF_FIELDS_MAP(L_FUNCTION_ID) LOOP
            L_STDCIF.V_STVWS_CUST_LIAB_UDF(I_INDEX).FIELD_NAME := EACH_REC.FIELD_NAME;
            L_STDCIF.V_STVWS_CUST_LIAB_UDF(I_INDEX).DATA_TYPE := EACH_REC.FIELD_TYPE;
            L_STDCIF.V_STVWS_CUST_LIAB_UDF(I_INDEX).VAL_TYPE := EACH_REC.VAL_TYPE;
            I_INDEX := I_INDEX + 1;
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in WOE' || SQLCODE || SQLERRM);
            DBG('The error is here ---> ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        END;
      ELSE
        DBG('LIMITS_11.3.1 Failed in Uvpks_Udf_Upload.Fn_Pickup_Func_Udf..');
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN FALSE;
    END;
    P_STDCIF.V_STVWS_CUST_LIAB_UDF := L_STDCIF.V_STVWS_CUST_LIAB_UDF;
    RETURN TRUE;
  END FN_PICK_LIAB_UDF;

  FUNCTION FN_QUERY_LIAB_UDFDETAILS(P_LIAB_NO IN VARCHAR2,
                                    P_STDCIF  IN OUT NOCOPY STPKS_STDCIF_MAIN.TY_STDCIF)
    RETURN BOOLEAN AS
  BEGIN
    SELECT NULL,
           NULL,
           P.FIELD_NAME,
           DECODE(P.FIELD_NUM,
                  1,
                  U.UDF_VALUE_1,
                  2,
                  U.UDF_VALUE_2,
                  3,
                  U.UDF_VALUE_3,
                  4,
                  U.UDF_VALUE_4,
                  5,
                  U.UDF_VALUE_5,
                  6,
                  U.UDF_VALUE_6,
                  7,
                  U.UDF_VALUE_7,
                  8,
                  U.UDF_VALUE_8,
                  9,
                  U.UDF_VALUE_9,
                  10,
                  U.UDF_VALUE_10,
                  11,
                  U.UDF_VALUE_11,
                  12,
                  U.UDF_VALUE_12,
                  13,
                  U.UDF_VALUE_13,
                  14,
                  U.UDF_VALUE_14,
                  15,
                  U.UDF_VALUE_15,
                  16,
                  U.UDF_VALUE_16,
                  17,
                  U.UDF_VALUE_17,
                  18,
                  U.UDF_VALUE_18,
                  19,
                  U.UDF_VALUE_19,
                  20,
                  U.UDF_VALUE_20,
                  21,
                  U.UDF_VALUE_21,
                  22,
                  U.UDF_VALUE_22,
                  23,
                  U.UDF_VALUE_23,
                  24,
                  U.UDF_VALUE_24,
                  25,
                  U.UDF_VALUE_25,
                  26,
                  U.UDF_VALUE_26,
                  27,
                  U.UDF_VALUE_27,
                  28,
                  U.UDF_VALUE_28,
                  29,
                  U.UDF_VALUE_29,
                  30,
                  U.UDF_VALUE_30,
                  31,
                  U.UDF_VALUE_31,
                  32,
                  U.UDF_VALUE_32,
                  33,
                  U.UDF_VALUE_33,
                  34,
                  U.UDF_VALUE_34,
                  35,
                  U.UDF_VALUE_35,
                  36,
                  U.UDF_VALUE_36,
                  37,
                  U.UDF_VALUE_37,
                  38,
                  U.UDF_VALUE_38,
                  39,
                  U.UDF_VALUE_39,
                  40,
                  U.UDF_VALUE_40,
                  41,
                  U.UDF_VALUE_41,
                  42,
                  U.UDF_VALUE_42,
                  43,
                  U.UDF_VALUE_43,
                  44,
                  U.UDF_VALUE_44,
                  45,
                  U.UDF_VALUE_45,
                  46,
                  U.UDF_VALUE_46,
                  47,
                  U.UDF_VALUE_47,
                  48,
                  U.UDF_VALUE_48,
                  49,
                  U.UDF_VALUE_49,
                  50,
                  U.UDF_VALUE_50) AS FIELD_VALUE,
           NULL,
           F.FIELD_TYPE AS DATA_TYPE,
           F.VAL_TYPE AS VAL_TYPE,
           0,
           NULL,
           NULL
      BULK COLLECT
      INTO P_STDCIF.V_STVWS_CUST_LIAB_UDF
      FROM GETM_LIAB U, CSTMS_FUNCTION_UDF_FIELDS_MAP P, UDTM_FIELDS F
     WHERE P.FUNCTION_ID = 'GEDMLIAB'
       AND P.AUTH_STAT = 'A'
       AND F.FIELD_NAME = P.FIELD_NAME
       AND U.LIAB_NO = P_LIAB_NO
       AND P.FIELD_NUM <= 50;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END FN_QUERY_LIAB_UDFDETAILS;

  FUNCTION FN_LOAD_LIAB_UDF(P_MODE       IN VARCHAR2,
                            P_STDCIF     IN OUT NOCOPY STPKS_STDCIF_MAIN.TY_STDCIF,
                            P_ERR_CODE   IN OUT VARCHAR2,
                            P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN AS
    L_FUNCTION_ID VARCHAR2(20);
    L_REC_KEY     VARCHAR2(50);
    L_INDEX       NUMBER;
    L_LAST        NUMBER;
    L_LIAB_UDF    UVPKS_UDF_UPLOAD.TY_UPL_FUNC_UDF;
    L_STDCIF      STPKS_STDCIF_MAIN.TY_STDCIF;
  BEGIN
    L_FUNCTION_ID := 'GEDMLIAB';
    L_REC_KEY     := P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO || '~';

    IF P_MODE = 'PICKLIABUDF' AND
       FN_PICK_LIAB_UDF(P_STDCIF, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('PICKUP happened HERE');
    ELSIF UVPKS_UDF_UPLOAD.FN_QUERY_FUNC_UDFDETAILS(L_FUNCTION_ID,
                                                    L_REC_KEY,
                                                    L_LIAB_UDF,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
      IF L_LIAB_UDF.COUNT > 0 THEN
        L_INDEX := L_LIAB_UDF.FIRST;
        L_LAST  := L_LIAB_UDF.LAST;
        LOOP
          L_STDCIF.V_STVWS_CUST_LIAB_UDF(L_INDEX).FIELD_NAME := L_LIAB_UDF(L_INDEX)
                                                                .FIELD_NAME;
          L_STDCIF.V_STVWS_CUST_LIAB_UDF(L_INDEX).FIELD_VAL := L_LIAB_UDF(L_INDEX)
                                                               .FIELD_VAL;
          L_STDCIF.V_STVWS_CUST_LIAB_UDF(L_INDEX).DATA_TYPE := L_LIAB_UDF(L_INDEX)
                                                               .DATA_TYPE;
          L_STDCIF.V_STVWS_CUST_LIAB_UDF(L_INDEX).VAL_TYPE := L_LIAB_UDF(L_INDEX)
                                                              .VAL_TYPE;
          EXIT WHEN L_INDEX = L_LAST;
          L_INDEX := L_LIAB_UDF.NEXT(L_INDEX);
        END LOOP;
      END IF;
      P_STDCIF.V_STVWS_CUST_LIAB_UDF := L_STDCIF.V_STVWS_CUST_LIAB_UDF;
    ELSIF FN_PICK_LIAB_UDF(P_STDCIF, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('PICKUP happened IN2 HERE');
    ELSE
      DBG('failed again in pickup');
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END FN_LOAD_LIAB_UDF;

  FUNCTION FN_LOAD_LIAB_LINK(P_STDCIF     IN OUT NOCOPY STPKS_STDCIF_MAIN.TY_STDCIF,
                             P_MODE       IN VARCHAR2,
                             P_ERR_CODE   IN OUT VARCHAR2,
                             P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_STDCIF       STPKS_STDCIF_MAIN.TY_STDCIF;
    L_LIAB_ID      NUMBER(20);
    L_LIAB_CUST_ID VARCHAR2(20);
    IDX            NUMBER;
  BEGIN
    DBG('START: stpks_stdcif_utils_0.fn_load_liab_link');
    DBG('25152096 :: p_mode :: ' || P_MODE);
    DBG('p_stdcif.v_sttms_customer.once_auth :: ' ||
        P_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH);

    IF P_MODE IN ('LOADLIAB', 'POSTQUERY') AND
       NVL(P_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH, 'N') = 'Y' THEN

      BEGIN
        SELECT ID
          INTO L_LIAB_ID
          FROM GETM_LIAB
         WHERE LIAB_NO = P_STDCIF.V_STTMS_CUSTOMER.LIABILITY_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('EXCEPTION:1: stpks_stdcif_utils_0.fn_load_liab_link: no return false. code, after if, will run');
      END;

      DBG('1 :: l_liab_id :: ' || L_LIAB_ID);
      L_LIAB_CUST_ID := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      DBG('l_liab_cust_id :: ' || L_LIAB_CUST_ID);
      BEGIN
        SELECT LIAB_ID
          INTO L_LIAB_ID
          FROM GETM_LIAB_CUST
         WHERE CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO

           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A'

        ;
        DBG('#28573870 l_liab_id  ' || L_LIAB_ID);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('EXCEPTION:2: stpks_stdcif_utils_0.fn_load_liab_link: no return false. code, after if, will run');
      END;
      DBG('2 :: l_liab_id :: ' || L_LIAB_ID);

      IF L_LIAB_ID IS NOT NULL THEN
        BEGIN
          SELECT GL.LIAB_NO,
                 GL.LIAB_NAME,
                 (SELECT ML.LIAB_NO
                    FROM GETM_LIAB ML
                   WHERE ML.ID = GL.MAIN_LIAB_ID) MAIN_LIAB_NO,
                 GL.LIAB_BRANCH,
                 GL.LIAB_CCY,
                 GL.OVERALL_LIMIT,
                 GL.UTIL_AMT,
                 GL.REVISION_DATE,
                 GL.CREDIT_RATING,
                 GL.OVERALL_SCORE,
                 GL.USER_DEFINE_STATUS,
                 GL.CATEGORY,
                 GL.FX_CLEAN_RISK_LIMIT,
                 GL.SEC_CLEAN_RISK_LIMIT,
                 GL.SEC_PSTL_RISK_LIMIT,
                 GL.UNADVISED,
                 GL.NETTING_REQUIRED,
                 GL.USER_REFNO

                ,
                 (SELECT ML.LIAB_NO
                    FROM GETM_LIAB ML
                   WHERE ML.ID = GL.MAIN_LIAB_ID) MAIN_LIAB_ID
            INTO L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO,
                 L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NAME,
                 L_STDCIF.V_STVWS_CUST_LIAB.MAIN_LIAB_NO,
                 L_STDCIF.V_STVWS_CUST_LIAB.LIAB_BRANCH,
                 L_STDCIF.V_STVWS_CUST_LIAB.LIAB_CCY,
                 L_STDCIF.V_STVWS_CUST_LIAB.OVERALL_LIMIT,
                 L_STDCIF.V_STVWS_CUST_LIAB.UTIL_AMOUNT,
                 L_STDCIF.V_STVWS_CUST_LIAB.REVISION_DATE,
                 L_STDCIF.V_STVWS_CUST_LIAB.CR_RATING,
                 L_STDCIF.V_STVWS_CUST_LIAB.OVERALL_SCORE,
                 L_STDCIF.V_STVWS_CUST_LIAB.USER_DEFINE_STATUS,
                 L_STDCIF.V_STVWS_CUST_LIAB.CATEGORY,
                 L_STDCIF.V_STVWS_CUST_LIAB.FX_CLEAN_RISK_LIMIT,
                 L_STDCIF.V_STVWS_CUST_LIAB.SEC_CLEAN_RISK_LIMIT,
                 L_STDCIF.V_STVWS_CUST_LIAB.SEC_PSTL_RISK_LIMIT,
                 L_STDCIF.V_STVWS_CUST_LIAB.UNADVISED,
                 L_STDCIF.V_STVWS_CUST_LIAB.NETTING_REQUIRED,
                 L_STDCIF.V_STVWS_CUST_LIAB.REMARKS,
                 L_STDCIF.V_STVWS_CUST_LIAB.MAIN_LIAB_NO
            FROM GETM_LIAB GL
           WHERE GL.ID = L_LIAB_ID;

          SELECT L.LIAB_NO,
                 LS.SCORE_ID,
                 LS.SCORE,
                 LS.MOD_NO,
                 S.SCORE_NAME,
                 S.SCORE_DESC
            BULK COLLECT
            INTO L_STDCIF.V_STVWS_CUST_LIAB_SCORE
            FROM GETM_LIAB L, GETM_LIAB_SCORE LS, GETM_SCORE S
           WHERE L.ID = L_LIAB_ID
             AND L.ID = LS.LIAB_ID
             AND LS.SCORE_ID = S.ID;

          SELECT L.LIAB_NO,
                 LR.AGENCY_ID,
                 LR.CREDIT_RATING_ID,
                 LR.PRIMARY,
                 LR.MOD_NO,
                 CA.AGENCY_NAME,
                 CR.CREDIT_RATING
            BULK COLLECT
            INTO L_STDCIF.V_STVWS_CUST_LIAB_RATING
            FROM GETM_LIAB               L,
                 GETM_LIAB_CREDIT_RATING LR,
                 GETM_CREDIT_AGENCY      CA,
                 GETM_CREDIT_RATING      CR
           WHERE L.ID = L_LIAB_ID
             AND L.ID = LR.LIAB_ID
             AND LR.AGENCY_ID = CA.ID

             AND CA.ID = CR.AGENCY_ID
             AND CR.ID = LR.CREDIT_RATING_ID;

          SELECT CLE.LIAB_CUST_ID,
                 CLE.EXPOSURE_ID,
                 CLE.MOD_NO,
                 TE.EXPOSURE_NAME EXPOSURE_NAME,
                 TE.EXPOSURE_DESC EXPOSURE_DESC,
                 TE.EXPOSURE_TYPE EXPOSURE_TYPE
            BULK COLLECT
            INTO L_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE
            FROM GETM_LIAB_CUST_EXPOSURE CLE,
                 GETM_LIAB_CUST          LC,
                 GETM_TRACK_EXPOSURE     TE
           WHERE CLE.LIAB_CUST_ID = LC.ID
             AND CLE.EXPOSURE_ID = TE.ID
             AND LC.CUSTOMER_NO = L_LIAB_CUST_ID;

          IF NOT FN_QUERY_LIAB_UDFDETAILS(P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO,
                                          L_STDCIF) THEN
            DBG('Failed in fn_query_liab_udfdetails..');
          END IF;

          P_STDCIF.V_STVWS_CUST_LIAB := L_STDCIF.V_STVWS_CUST_LIAB;
          DBG('RETURN TRUE:1: ' || P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NAME);
          P_STDCIF.V_STVWS_CUST_LIAB.CUST_NO  := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
          P_STDCIF.V_STVWS_CUST_LIAB_SCORE    := L_STDCIF.V_STVWS_CUST_LIAB_SCORE;
          P_STDCIF.V_STVWS_CUST_LIAB_RATING   := L_STDCIF.V_STVWS_CUST_LIAB_RATING;
          P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE := L_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE;
          P_STDCIF.V_STVWS_CUST_LIAB_UDF      := L_STDCIF.V_STVWS_CUST_LIAB_UDF;
          DBG('RETURN TRUE:1: stpks_stdcif_utils_0.fn_load_liab_link');
          RETURN TRUE;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('EXCEPTION: stpks_stdcif_utils_0.fn_load_liab_link: l_liab_id not null, SELECT error: ' ||
                SQLERRM);
        END;
      END IF;
      DBG('CHECK: stpks_stdcif_utils_0.fn_load_liab_link: l_liab_id: ' ||
          L_LIAB_ID);
    END IF;
    BEGIN
      SELECT *
        INTO L_STDCIF.V_STVWS_CUST_LIAB
        FROM STVWS_CUST_LIAB
       WHERE CUST_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found>>>>');
    END;

    BEGIN
      SELECT GL.OVERALL_LIMIT
        INTO L_STDCIF.V_STVWS_CUST_LIAB.OVERALL_LIMIT
        FROM GETM_LIAB GL
       WHERE GL.LIAB_NO = L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found>>>>');
    END;
    DBG('l_stdcif.v_stvws_cust_liab.overall_limit>>>>' ||
        L_STDCIF.V_STVWS_CUST_LIAB.OVERALL_LIMIT);

    SELECT *
      BULK COLLECT
      INTO L_STDCIF.V_STVWS_CUST_LIAB_SCORE
      FROM STVWS_CUST_LIAB_SCORE
     WHERE LIAB_NO = L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO;

    DBG('p_stdcif.v_stvws_cust_liab.liab_no: ' ||
        L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO);

    SELECT *
      BULK COLLECT
      INTO L_STDCIF.V_STVWS_CUST_LIAB_RATING
      FROM STVWS_CUST_LIAB_RATING
     WHERE LIAB_NO = L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO;

    DBG('---------------------------------------' ||
        L_STDCIF.V_STVWS_CUST_LIAB_RATING.COUNT);

    SELECT *
      BULK COLLECT
      INTO L_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE
      FROM STVWS_CUST_LIAB_EXPOSURE
     WHERE LIAB_CUST_NO = L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO;

    IF NOT FN_LOAD_LIAB_UDF(P_MODE, L_STDCIF, P_ERR_CODE, P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;

    P_STDCIF.V_STVWS_CUST_LIAB          := L_STDCIF.V_STVWS_CUST_LIAB;
    P_STDCIF.V_STVWS_CUST_LIAB_SCORE    := L_STDCIF.V_STVWS_CUST_LIAB_SCORE;
    P_STDCIF.V_STVWS_CUST_LIAB_RATING   := L_STDCIF.V_STVWS_CUST_LIAB_RATING;
    P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE := L_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE;
    P_STDCIF.V_STVWS_CUST_LIAB_UDF      := L_STDCIF.V_STVWS_CUST_LIAB_UDF;
    DBG('p_stdcif.v_stvws_cust_liab.overall_limit>>>>' ||
        P_STDCIF.V_STVWS_CUST_LIAB.OVERALL_LIMIT);
    DBG('RETURN TRUE:2: stpks_stdcif_utils_0.fn_load_liab_link');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE   := 'ST-CIF-L005';
      P_ERR_PARAMS := '';
      DBG('RETURN FALSE:1: stpks_stdcif_utils_0.fn_load_liab_link' ||
          SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_LOAD_LIAB_LINK;

  FUNCTION FN_STORE_LIAB_LINK(P_SOURCE      IN VARCHAR2,
                              P_STDCIF      IN STPKS_STDCIF_MAIN.TY_STDCIF,
                              P_ACTION_CODE IN VARCHAR2,
                              P_ERR_CODE    IN OUT VARCHAR2,
                              P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_COUNT     NUMBER;
    L_CUST_LIAB STVWS_CUST_LIAB%ROWTYPE;
  BEGIN
    DBG('START: stpks_stdcif_utils_0.fn_store_liab_link: ' ||
        P_ACTION_CODE);

    IF P_ACTION_CODE <> 'CLEANLIAB' THEN
      IF P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO IS NULL THEN
        P_ERR_CODE := 'ST-CIF-L003';
        RETURN FALSE;
      END IF;
      IF P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NAME IS NULL THEN
        P_ERR_CODE := 'ST-CIF-L007';
        RETURN FALSE;
      END IF;
      IF P_STDCIF.V_STVWS_CUST_LIAB.LIAB_BRANCH IS NULL THEN
        P_ERR_CODE := 'ST-CIF-L008';
        RETURN FALSE;
      END IF;
      IF P_STDCIF.V_STVWS_CUST_LIAB.LIAB_CCY IS NULL THEN
        P_ERR_CODE := 'ST-CIF-L009';
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY OR
       P_ACTION_CODE = 'CLEANLIAB' THEN
      BEGIN
        DELETE FROM STTM_AUTO_LIAB_DETAILS LD
         WHERE LD.CUST_NO = P_STDCIF.V_STVWS_CUST_LIAB.CUST_NO;
        DELETE FROM STTM_AUTO_LIAB_SCORE LS
         WHERE LS.LIAB_NO = P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO;
        DELETE FROM STTM_AUTO_LIAB_RATING LC
         WHERE LC.LIAB_NO = P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO;
        DELETE FROM STTM_AUTO_LIAB_EXPOSURE LE
         WHERE LE.LIAB_CUST_NO = P_STDCIF.V_STVWS_CUST_LIAB.CUST_NO;

      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END IF;

    IF P_ACTION_CODE = 'CLEANLIAB' THEN
      BEGIN
        UPDATE STTMS_CUSTOMER
           SET LIABILITY_NO = ''
         WHERE CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;

      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
      RETURN TRUE;
    END IF;
    DBG('p_stdcif.v_stvws_cust_liab.cust_no>>>' ||
        P_STDCIF.V_STVWS_CUST_LIAB.CUST_NO);

    IF P_STDCIF.V_STVWS_CUST_LIAB.OVERALL_LIMIT IS NOT NULL THEN
      DBG('p_stdcif.v_stvws_cust_liab.overall_limit>>>' ||
          P_STDCIF.V_STVWS_CUST_LIAB.OVERALL_LIMIT);

      IF P_STDCIF.V_STVWS_CUST_LIAB.OVERALL_LIMIT < 0 THEN
        P_ERR_CODE := 'GEDMLIAB-41';
        RETURN FALSE;
      END IF;

      DECLARE
        L_BC             NUMBER;
        L_LC             CHAR(3);
        L_CB_LP          NUMBER;
        L_IN_LP          NUMBER;
        L_ALLOWED        NUMBER;
        L_ALLOWED_IN_LCY NUMBER;
      BEGIN
        SELECT BANK_CAPITAL,
               LIMIT_CURRENCY,
               CB_LENDING_PERCENT,
               INT_LENDING_PERCENT
          INTO L_BC, L_LC, L_CB_LP, L_IN_LP
          FROM GETM_PARAMETER;

        L_ALLOWED := (L_BC * L_CB_LP / 100) * L_IN_LP / 100;
        DBG('l_allowed>>' || L_ALLOWED);

        IF L_LC = P_STDCIF.V_STVWS_CUST_LIAB.LIAB_CCY THEN
          L_ALLOWED_IN_LCY := L_ALLOWED;
        ELSE
          DECLARE
            L_BRN      STTMS_BRANCH.BRANCH_CODE%TYPE := P_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
            L_CCY1     CYTMS_CCY_DEFN.CCY_CODE%TYPE := L_LC;
            L_CCY2     CYTMS_CCY_DEFN.CCY_CODE%TYPE := P_STDCIF.V_STVWS_CUST_LIAB.LIAB_CCY;
            L_MIDRATE  CYTMS_RATES.MID_RATE%TYPE;
            L_ERR_CODE ERTBS_MSGS.ERR_CODE%TYPE;
          BEGIN
            IF NOT CYPKS.FN_AMT1_TO_AMT2(L_BRN,
                                         L_CCY1,
                                         L_CCY2,
                                         L_ALLOWED,
                                         'N',
                                         L_ALLOWED_IN_LCY,
                                         L_MIDRATE,
                                         L_ERR_CODE) THEN
              P_ERR_CODE := L_ERR_CODE;
              DBG('l_allowed p_err_code>>' || P_ERR_CODE);
              RETURN FALSE;
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('l_allowed p_err_code2>>' || SQLERRM);
              RETURN FALSE;
          END;
        END IF;
        DBG('l_allowed_in_lcy>>' || L_ALLOWED_IN_LCY);
        IF L_ALLOWED_IN_LCY < P_STDCIF.V_STVWS_CUST_LIAB.OVERALL_LIMIT THEN
          DBG('l_allowed_in_lcy<<>>' || L_ALLOWED_IN_LCY);
          P_ERR_CODE   := 'GEDMLIAB-06';
          P_ERR_PARAMS := P_STDCIF.V_STVWS_CUST_LIAB.OVERALL_LIMIT || '~' ||
                          L_ALLOWED_IN_LCY || '~';
          OVPKS.PR_APPENDTBL(PERRCODE => P_ERR_CODE,
                             PPARAMS  => P_ERR_PARAMS);
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('l_allowed others>>' || SQLERRM);
          P_ERR_CODE   := 'GEDMLIAB-06';
          P_ERR_PARAMS := P_STDCIF.V_STVWS_CUST_LIAB.OVERALL_LIMIT || '~' ||
                          L_ALLOWED_IN_LCY || '~';
          OVPKS.PR_APPENDTBL(PERRCODE => P_ERR_CODE,
                             PPARAMS  => P_ERR_PARAMS);
      END;
    END IF;

    UPDATE STTMS_CUSTOMER
       SET LIABILITY_NO = P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO
     WHERE CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;

    IF P_SOURCE IS NULL THEN
      SELECT P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
             LIAB_NO,
             LIAB_NAME,
             LIAB_BRANCH,
             LIAB_CCY,
             OVERALL_LIMIT,
             REVISION_DATE,
             CATEGORY,
             USER_DEFINE_STATUS,
             UNADVISED,
             NETTING_REQUIRED,
             OVERALL_SCORE,
             FX_CLEAN_RISK_LIMIT,
             SEC_CLEAN_RISK_LIMIT,
             SEC_PSTL_RISK_LIMIT,
             USER_REFNO,
             (SELECT ML.LIAB_NO
                FROM GETM_LIAB ML
               WHERE ML.ID = GL.MAIN_LIAB_ID) MAIN_LIAB_NO,
             UTIL_AMT UTIL_AMOUNT,
             CREDIT_RATING CR_RATING
        INTO L_CUST_LIAB
        FROM GETM_LIAB GL
       WHERE GL.LIAB_NO = P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO;
    ELSE
      L_CUST_LIAB := P_STDCIF.V_STVWS_CUST_LIAB;
    END IF;

    L_CUST_LIAB.OVERALL_SCORE := 0;
    FOR I IN 1 .. P_STDCIF.V_STVWS_CUST_LIAB_SCORE.COUNT LOOP
      L_CUST_LIAB.OVERALL_SCORE := L_CUST_LIAB.OVERALL_SCORE + P_STDCIF.V_STVWS_CUST_LIAB_SCORE(I)
                                  .SCORE;
    END LOOP;

    FOR I IN 1 .. P_STDCIF.V_STVWS_CUST_LIAB_RATING.COUNT LOOP
      IF P_STDCIF.V_STVWS_CUST_LIAB_RATING(I).PRIMARY = 'Y' THEN
        L_CUST_LIAB.CR_RATING := P_STDCIF.V_STVWS_CUST_LIAB_RATING(I)
                                 .CREDIT_RATING;
      END IF;
    END LOOP;

    INSERT INTO STTM_AUTO_LIAB_DETAILS
      (CUST_NO,
       LIAB_NO,
       LIAB_NAME,
       LIAB_BRANCH,
       LIAB_CCY,
       OVERALL_LIMIT,
       REVISION_DATE,
       CATEGORY,
       USER_DEFINE_STATUS,
       UNADVISED,
       NETTING_REQUIRED,
       OVERALL_SCORE,
       FX_CLEAN_RISK_LIMIT,
       SEC_CLEAN_RISK_LIMIT,
       SEC_PSTL_RISK_LIMIT,
       USER_REF_NO,
       CREDIT_RATING,
       MAIN_LIAB_NO)
    VALUES
      (L_CUST_LIAB.CUST_NO,
       L_CUST_LIAB.LIAB_NO,
       L_CUST_LIAB.LIAB_NAME,
       L_CUST_LIAB.LIAB_BRANCH,
       L_CUST_LIAB.LIAB_CCY,
       L_CUST_LIAB.OVERALL_LIMIT,
       L_CUST_LIAB.REVISION_DATE,
       L_CUST_LIAB.CATEGORY,
       L_CUST_LIAB.USER_DEFINE_STATUS,
       L_CUST_LIAB.UNADVISED,
       L_CUST_LIAB.NETTING_REQUIRED,
       L_CUST_LIAB.OVERALL_SCORE,
       L_CUST_LIAB.FX_CLEAN_RISK_LIMIT,
       L_CUST_LIAB.SEC_CLEAN_RISK_LIMIT,
       L_CUST_LIAB.SEC_PSTL_RISK_LIMIT,
       L_CUST_LIAB.REMARKS,
       L_CUST_LIAB.CR_RATING,
       L_CUST_LIAB.MAIN_LIAB_NO);

    IF P_SOURCE IS NOT NULL THEN
      L_COUNT := P_STDCIF.V_STVWS_CUST_LIAB_SCORE.COUNT;
      FORALL I IN 1 .. L_COUNT
        INSERT INTO STTM_AUTO_LIAB_SCORE
          (LIAB_NO, SCORE_ID, SCORE)
        VALUES
          (P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO,
           NVL(P_STDCIF.V_STVWS_CUST_LIAB_SCORE(I).SCORE_ID,
               (SELECT ID
                  FROM GETM_SCORE
                 WHERE SCORE_NAME = P_STDCIF.V_STVWS_CUST_LIAB_SCORE(I)
                      .SCORE_NAME)),
           P_STDCIF.V_STVWS_CUST_LIAB_SCORE(I).SCORE);

      L_COUNT := P_STDCIF.V_STVWS_CUST_LIAB_RATING.COUNT;
      FORALL I IN 1 .. L_COUNT
        INSERT INTO STTM_AUTO_LIAB_RATING
          (LIAB_NO, AGENCY_ID, CREDIT_RATING_ID, PRIMARY)
        VALUES
          (P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO,
           NVL(P_STDCIF.V_STVWS_CUST_LIAB_RATING(I).AGENCY_ID,
               (SELECT ID
                  FROM GETM_CREDIT_AGENCY
                 WHERE AGENCY_NAME = P_STDCIF.V_STVWS_CUST_LIAB_RATING(I)
                      .AGENCY_NAME)),
           NVL(P_STDCIF.V_STVWS_CUST_LIAB_RATING(I).CREDIT_RATING_ID,
               (SELECT R.ID
                  FROM GETM_CREDIT_RATING R, GETM_CREDIT_AGENCY A
                 WHERE R.AGENCY_ID = A.ID
                   AND R.CREDIT_RATING = P_STDCIF.V_STVWS_CUST_LIAB_RATING(I)
                      .CREDIT_RATING

                   AND A.AGENCY_NAME = P_STDCIF.V_STVWS_CUST_LIAB_RATING(I)
                      .AGENCY_NAME

                )),
           P_STDCIF.V_STVWS_CUST_LIAB_RATING(I).PRIMARY);
    END IF;

    L_COUNT := P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE.COUNT;
    FORALL I IN 1 .. L_COUNT
      INSERT INTO STTM_AUTO_LIAB_EXPOSURE
        (LIAB_CUST_NO, EXPOSURE_ID)
      VALUES
        (P_STDCIF.V_STVWS_CUST_LIAB.CUST_NO,
         NVL(P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE(I).EXPOSURE_ID,
             (SELECT ID
                FROM GETM_TRACK_EXPOSURE
               WHERE EXPOSURE_NAME = P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE(I)
                    .EXPOSURE_NAME

                 AND UTILISATION_TYPE = 'C'
                 AND EXPOSURE_TYPE =
                     NVL(P_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE(I).EXPOSURE_TYPE,
                         '*'))));

    IF P_SOURCE IS NOT NULL THEN
      DECLARE
        L_LIAB_UDF    UVPKS_UDF_UPLOAD.TY_UPL_FUNC_UDF;
        L_IDX         NUMBER;
        L_LAST        NUMBER;
        L_FUNCTION_ID VARCHAR2(20);
        L_REC_KEY     VARCHAR2(50);
        L_STDCIF      STPKS_STDCIF_MAIN.TY_STDCIF;
      BEGIN

        L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO := P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO;
        DBG('Calling fn_store_liab_link > uvpks_udf_upload.fn_pickup_func_udf.');
        IF NOT FN_PICK_LIAB_UDF(L_STDCIF, P_ERR_CODE, P_ERR_PARAMS) THEN
          RETURN FALSE;
        END IF;

        IF L_STDCIF.V_STVWS_CUST_LIAB_UDF.COUNT > 0 THEN
          L_FUNCTION_ID := 'GEDMLIAB';
          L_REC_KEY     := P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO || '~';
          L_IDX         := L_STDCIF.V_STVWS_CUST_LIAB_UDF.FIRST;
          L_LAST        := L_STDCIF.V_STVWS_CUST_LIAB_UDF.LAST;
          LOOP
            L_LIAB_UDF(L_IDX).FIELD_NAME := L_STDCIF.V_STVWS_CUST_LIAB_UDF(L_IDX)
                                            .FIELD_NAME;
            L_LIAB_UDF(L_IDX).DATA_TYPE := L_STDCIF.V_STVWS_CUST_LIAB_UDF(L_IDX)
                                           .DATA_TYPE;
            L_LIAB_UDF(L_IDX).VAL_TYPE := L_STDCIF.V_STVWS_CUST_LIAB_UDF(L_IDX)
                                          .VAL_TYPE;
            IF P_STDCIF.V_STVWS_CUST_LIAB_UDF.COUNT > 0 THEN
              FOR I IN 1 .. P_STDCIF.V_STVWS_CUST_LIAB_UDF.COUNT LOOP
                IF L_LIAB_UDF(L_IDX).FIELD_NAME = P_STDCIF.V_STVWS_CUST_LIAB_UDF(I)
                   .FIELD_NAME THEN
                  L_LIAB_UDF(L_IDX).FIELD_VAL := P_STDCIF.V_STVWS_CUST_LIAB_UDF(I)
                                                 .FIELD_VAL;
                  EXIT;
                END IF;
              END LOOP;
            ELSE
              L_LIAB_UDF(L_IDX).FIELD_VAL := '';
            END IF;
            EXIT WHEN L_IDX = L_LAST;
            L_IDX := L_STDCIF.V_STVWS_CUST_LIAB_UDF.NEXT(L_IDX);
          END LOOP;

          IF P_STDCIF.V_STVWS_CUST_LIAB_UDF.COUNT > 0 THEN
            DBG('Calling Uvpks_Udf_Upload.fn_function_udf_upload_type.');
            IF NOT
                UVPKS_UDF_UPLOAD.FN_FUNCTION_UDF_UPLOAD_TYPE(P_SOURCE,
                                                             L_FUNCTION_ID,
                                                             L_REC_KEY,
                                                             P_ACTION_CODE,
                                                             L_LIAB_UDF,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS) THEN
              DBG('Failed in Uvpks_Udf_Upload.Fn_Function_Udf_Upload_Type..');
              RETURN FALSE;
            END IF;
          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_CODE   := 'ST-CIF-L006';
          P_ERR_PARAMS := '';
          DBG('RETURN FALSE:2: error stpks_stdcif_utils_0.fn_store_liab_link: ' ||
              SQLERRM);
          RETURN FALSE;
      END;
    END IF;
    DBG('RETURN TRUE:1: stpks_stdcif_utils_0.fn_store_liab_link');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE   := 'ST-CIF-L006';
      P_ERR_PARAMS := '';
      DBG('RETURN FALSE:1: stpks_stdcif_utils_0.fn_store_liab_link: ' ||
          SQLERRM);
      RETURN FALSE;
  END FN_STORE_LIAB_LINK;

  FUNCTION FN_CUST_LIAB_LINK_PROCESS(P_SOURCE           IN VARCHAR2,
                                     P_SOURCE_OPERATION IN VARCHAR2,
                                     P_ACTION_CODE      IN VARCHAR2,
                                     P_MULTI_TRIP_ID    IN VARCHAR2,
                                     P_STDCIF           IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                     P_FUNCTION_ID      IN VARCHAR2,
                                     P_STATUS           IN VARCHAR2,
                                     P_ERR_CODE         IN OUT VARCHAR2,
                                     P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    E_FAILURE_EXCEPTION EXCEPTION;
    L_ONCE_AUTH     CHAR(1);
    L_STDCIF        STPKS_STDCIF_MAIN.TY_STDCIF;
    L_ELDCULIK      ELPKS_LIABILITY_SERVICE.TY_ELDCULIK;
    L_GEDLCCKL      ELPKS_LIABILITY_SERVICE.TY_GEDLCCKL;
    L_CUSTLIABLINK  ELPKS_LIABILITY_SERVICE.TY_CUSTLIABLINK;
    L_SOURCE        VARCHAR2(20);
    L_ACTION_CODE   VARCHAR2(20) := 'NEW';
    L_MULTI_TRIP_ID VARCHAR2(20) := P_MULTI_TRIP_ID;
    L_LIAB_COUNT    NUMBER;
    L_AUTH_STAT     STTMS_CUSTOMER.AUTH_STAT%TYPE;

    L_ELCM_SETUP_MODE VARCHAR2(2);
  BEGIN
    DBG('START: stpks_stdcif_utils_0.fn_cust_liab_link_process: p_action_code: ' ||
        P_ACTION_CODE || ', p_function_id: ' || P_FUNCTION_ID);

    L_ELCM_SETUP_MODE := ELPKS.ELCM_SETUP_MODE;
    DECLARE
      L_USERROLE_COUNT NUMBER;
    BEGIN
      IF L_ELCM_SETUP_MODE = 'E' THEN
        SELECT COUNT(*)
          INTO L_USERROLE_COUNT
          FROM (SELECT 1
                  FROM SMVW_BROWSER_FUNCTIONS F
                 WHERE F.USER_ID = GLOBAL.USER_ID
                   AND F.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                   AND F.FUNCTION_ID IN ('GEDMLIAB', 'GEDCULIK')
                 HAVING COUNT(1) >= 2);
      ELSE
        SELECT COUNT(*)
          INTO L_USERROLE_COUNT
          FROM SMTB_USER
         WHERE USER_ID = GLOBAL.USER_ID
           AND EL_USER_ID IS NOT NULL;
      END IF;

      IF L_USERROLE_COUNT < 1 THEN
        P_ERR_CODE := 'ST-CIF-L004';
        RETURN FALSE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('RARE ERROR -_-');
        P_ERR_CODE := 'ST-CIF-L004';
        RETURN FALSE;
    END;

    DBG('LIMITS_11.3.1:7: came inside in stpks_stdcif_utils_0..');

    L_STDCIF := P_STDCIF;
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW OR
       P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      L_STDCIF.V_STVWS_CUST_LIAB.CUST_NO := L_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      IF L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO IS NULL THEN
        L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO := L_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      END IF;

      DBG('p_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NAME1' ||
          P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NAME1);

      IF L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NAME IS NULL THEN
        BEGIN

          SELECT FULL_NAME
            INTO L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NAME
            FROM STTM_CUSTOMER
           WHERE CUSTOMER_NO = L_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('liab name is null');
        END;
        DBG('here liab_name' || L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NAME);
      END IF;

      IF L_STDCIF.V_STVWS_CUST_LIAB.LIAB_BRANCH IS NULL THEN
        BEGIN
          SELECT LOCAL_BRANCH
            INTO L_STDCIF.V_STVWS_CUST_LIAB.LIAB_BRANCH
            FROM STTM_CUSTOMER
           WHERE CUSTOMER_NO = L_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('liab branch is null');
        END;
        DBG('here branch' || L_STDCIF.V_STVWS_CUST_LIAB.LIAB_BRANCH);
      END IF;
      IF L_STDCIF.V_STVWS_CUST_LIAB.LIAB_CCY IS NULL THEN
        BEGIN
          SELECT BRANCH_LCY
            INTO L_STDCIF.V_STVWS_CUST_LIAB.LIAB_CCY
            FROM STTM_BRANCH
           WHERE BRANCH_CODE = L_STDCIF.V_STVWS_CUST_LIAB.LIAB_BRANCH;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('liab ccy is null');
        END;
        DBG(' here ccy' || L_STDCIF.V_STVWS_CUST_LIAB.LIAB_CCY);
      END IF;

      DBG('<<<l_stdcif.v_sttms_customer.customer_no>>>' ||
          L_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
      IF L_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO =
         L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO THEN
        L_SOURCE := P_SOURCE;
      END IF;
      IF NOT FN_STORE_LIAB_LINK(L_SOURCE,
                                L_STDCIF,
                                P_ACTION_CODE,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
        DBG('RETURN FALSE:3: stpks_stdcif_utils_0.fn_cust_liab_link_process: stpks_stdcif_utils_0.fn_store_liab_link FAILED');
        RETURN FALSE;
      END IF;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      BEGIN
        SELECT ONCE_AUTH
          INTO L_ONCE_AUTH
          FROM STTMS_CUSTOMER
         WHERE CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      EXCEPTION
        WHEN OTHERS THEN
          L_ONCE_AUTH := 'N';
          DBG('EXCEPTION:1: stpks_stdcif_utils_0.fn_cust_liab_link_process');
      END;
      IF L_ONCE_AUTH = 'Y' THEN
        L_STDCIF.V_STTMS_CUSTOMER := P_STDCIF.V_STTMS_CUSTOMER;
        IF STPKS_STDCIF_UTILS_0.FN_LOAD_LIAB_LINK(L_STDCIF,
                                                  'QUERY',
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN

          DBG('DDDDDDDDDDBG----> p_status:' || P_STATUS);

          IF P_STATUS = 'A' THEN
            PR_STDCIF_TO_CUSTLIABLINK(L_STDCIF, L_CUSTLIABLINK);
            IF L_ELCM_SETUP_MODE = 'E' THEN
              L_CUSTLIABLINK.SKIP_CUSTOMER := 'Y';
            ELSE
              L_CUSTLIABLINK.SKIP_CUSTOMER := 'N';
            END IF;
            IF L_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO =
               L_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO THEN
              L_CUSTLIABLINK.SKIP_LIAB := 'N';
            ELSE
              L_CUSTLIABLINK.SKIP_LIAB := 'Y';
            END IF;

            SELECT COUNT(1)
              INTO L_LIAB_COUNT
              FROM GETM_LIAB
             WHERE LIAB_NO = L_CUSTLIABLINK.LIAB.LIABILITY.LIAB_NO;
            IF L_LIAB_COUNT = 0 THEN

              L_CUSTLIABLINK.LIAB_ACTION := 'NEW';
              L_CUSTLIABLINK.LINK_ACTION := 'NEW';

            ELSE
              L_CUSTLIABLINK.LIAB_ACTION := 'MODIFY';
              L_CUSTLIABLINK.LINK_ACTION := 'MODIFY';
            END IF;

            SELECT AUTH_STAT
              INTO L_AUTH_STAT
              FROM STTMS_CUSTOMER
             WHERE CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
            IF L_AUTH_STAT = 'A' THEN

              IF NOT
                  ELPKS_LIABILITY_SERVICE.FN_CUSTLIABLINK_PROCESS(P_SOURCE,
                                                                  P_SOURCE_OPERATION,
                                                                  L_ACTION_CODE,
                                                                  L_MULTI_TRIP_ID,
                                                                  L_CUSTLIABLINK,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
                DBG('RETURN FALSE:0: stpks_stdcif_utils_0.fn_cust_liab_link_process: elpks_liability_service.fn_customer_process FAILED');

                DBG('RETURN FALSE:0.2: p_err_code: ' || P_ERR_CODE);
                DBG('RETURN FALSE:0.3: p_err_params: ' || P_ERR_PARAMS);
                RETURN FALSE;
              END IF;
            END IF;
            DBG('STALIN:1.1: SUCCESS:: elpks_liability_service.fn_liab_process ');
            G_LIABILITY_LINKED := TRUE;
          END IF;
        ELSE
          DBG('RETUR FALSE:4: stpks_stdcif_utils_0.fn_cust_liab_link_process: QUERY failed');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
    DBG('RETURN TRUE:1: stpks_stdcif_utils_0.fn_cust_liab_link_process');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN

      DBG('EXCEPTION:2: RETURN FALSE:4: stpks_stdcif_utils_0.fn_cust_liab_link_process' ||
          SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE := NVL(P_ERR_CODE, 'ST-CIF-L006');
      RETURN FALSE;
  END FN_CUST_LIAB_LINK_PROCESS;

  FUNCTION FN_UPDATE_COMB_STMT(P_FUNCTION_ID IN VARCHAR2,
                               P_STDCIF      IN OUT NOCOPY STPKS_STDCIF_MAIN.TY_STDCIF,
                               P_ERR_CODE    IN OUT VARCHAR2,
                               P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

  BEGIN

    DBG('Just entered fn_update_comb_stmt');
    IF P_STDCIF.V_STTMS_CUSTOMER.AUTOGEN_STMTPLAN = 'Y' THEN
      IF P_STDCIF.V_STTMS_CUSTOMER.FREQUENCY IS NOT NULL AND
         P_STDCIF.V_STTMS_CUSTOMER.STMT_DAY IS NOT NULL THEN

        INSERT INTO STTM_COMB_STMT_MAINT
          (STMT_ID,
           CUST_NO,
           ALL_ACCOUNTS,
           BD_VD_BAL,
           STMT_FORMAT,
           FREQUENCY,
           STMT_DAY,
           APPLY_CHARGE,
           MOD_NO,
           MAKER_ID,
           MAKER_DT_STAMP,
           CHECKER_ID,
           CHECKER_DT_STAMP,
           RECORD_STAT,
           AUTH_STAT,
           ONCE_AUTH)
        VALUES
          ('PLAN_1',
           P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
           'Y',
           'B',
           'COMB_STMNT_FMT',
           P_STDCIF.V_STTMS_CUSTOMER.FREQUENCY,
           P_STDCIF.V_STTMS_CUSTOMER.STMT_DAY,
           'N',
           '1',
           'SYSTEM',
           FN_MNTSTAMP,
           'SYSTEM',
           FN_MNTSTAMP,
           'O',
           'A',
           'Y');

      ELSE
        INSERT INTO STTM_COMB_STMT_MAINT
          (STMT_ID,
           CUST_NO,
           ALL_ACCOUNTS,
           BD_VD_BAL,
           STMT_FORMAT,
           FREQUENCY,
           APPLY_CHARGE,
           MOD_NO,
           MAKER_ID,
           MAKER_DT_STAMP,
           CHECKER_ID,
           CHECKER_DT_STAMP,
           RECORD_STAT,
           AUTH_STAT,
           ONCE_AUTH)
        VALUES
          ('PLAN_1',
           P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
           'Y',
           'B',
           'COMB_STMNT_FMT',
           P_STDCIF.V_STTMS_CUSTOMER.FREQUENCY,
           'N',
           '1',
           'SYSTEM',
           FN_MNTSTAMP,
           'SYSTEM',
           FN_MNTSTAMP,
           'O',
           'A',
           'Y');
      END IF;
    ELSE
      P_STDCIF.V_STTMS_CUSTOMER.FREQUENCY := '';
      P_STDCIF.V_STTMS_CUSTOMER.STMT_DAY  := '';
    END IF;
    DBG('Successfully completed fn_update_comb_stmt');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT in fn_update_comb_stmt: ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- fn_update_comb_stmt';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_UPDATE_COMB_STMT;

  FUNCTION FNGETVAL(VAR_TYPE IN VARCHAR2)

   RETURN STPKS_STDCIF_MAIN.TY_STDCIF IS

  BEGIN
    IF VAR_TYPE <> 'p' THEN
      RETURN G_WRK_STDCIF;

    ELSE
      RETURN G_PREV_STDCIF;
    END IF;
  END FNGETVAL;

  FUNCTION FN_BUILD_SNCK_DATA(P_SOURCE           IN VARCHAR2,
                              P_SOURCE_OPERATION IN VARCHAR2,
                              P_FUNCTION_ID      IN VARCHAR2,
                              P_ACTION_CODE      IN VARCHAR2,
                              P_CHILD_FUNCTION   IN VARCHAR2,
                              P_STDCIF           IN STPKS_STDCIF_MAIN.TY_STDCIF,
                              P_PREV_STDCIF      IN STPKS_STDCIF_MAIN.TY_STDCIF,
                              P_WRK_STDCIF       IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                              P_ERR_CODE         IN OUT VARCHAR2,
                              P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_SERIAL_NO           CSTB_CONTRACT.SERIAL_NO%TYPE;
    L_REF_NO              CSTB_CONTRACT.CONTRACT_REF_NO%TYPE;
    L_PARTY_TYPE          CSTB_SNCK_DETAIL.PARTY_TYPE%TYPE;
    L_PARTY_NAME          CSTB_SNCK_DETAIL.PARTY_NAME%TYPE;
    L_ADDRESS             CSTB_SNCK_DETAIL.ADDRESS%TYPE;
    L_FAX                 CSTB_SNCK_DETAIL.FAX%TYPE;
    L_PHONE_NUM           CSTB_SNCK_DETAIL.PHONE_NUMBER%TYPE;
    L_MOBILE_NUM          CSTB_SNCK_DETAIL.MOBILE_NUMBER%TYPE;
    L_NATIONAL_ID         CSTB_SNCK_DETAIL.NATIONAL_ID%TYPE;
    L_PASSPORT_NO         CSTB_SNCK_DETAIL.PASSPORT_NO%TYPE;
    L_SSN                 CSTB_SNCK_DETAIL.SSN%TYPE;
    L_TAX_ID              CSTB_SNCK_DETAIL.TAX_ID%TYPE;
    L_DOB                 CSTB_SNCK_DETAIL.DOB%TYPE;
    L_EMAIL               CSTB_SNCK_DETAIL.EMAIL%TYPE;
    L_INDEX               NUMBER := 1;
    L_CUSTOMER            BOOLEAN := FALSE;
    L_CORP_DIRECTORS      BOOLEAN := FALSE;
    L_CUST_PERSONAL_JOINT BOOLEAN := FALSE;
    L_AUTO_ACC_NOMINEES   BOOLEAN := FALSE;

    L_CSTB_SNCK_MASTER CSTB_SNCK_MASTER%ROWTYPE;
    L_CSTB_SNCK_DETAIL CSTB_SNCK_DETAIL%ROWTYPE;
    P_SNCK             STPKS_STDCIF_MAIN.TY_STDCIF;
    L_SNCK_SYSTEM_CODE CSTM_SNCK_BRN_PARAM.SANCTIONS_CHECKS_SYSTEM%TYPE;

    L_SQL      CLOB := ' ';
    L_FIELD    VARCHAR2(50) := '~~';
    L_SQL1     VARCHAR2(4000);
    L_COUNT    NUMBER;
    L_ADDR_FLD VARCHAR2(50);

    CURSOR C_SNCK_PARAMS1 IS
      SELECT *
        FROM CSTB_CUST_SNCK_FIELDS
       WHERE CALLFORM_NAME IS NULL
       ORDER BY DATASOURCE_NAME, TARGET_FIELD, FIELD_SEQ;

    CURSOR C_SNCK_PARAMS2 IS
      SELECT *
        FROM CSTB_CUST_SNCK_FIELDS
       WHERE CALLFORM_NAME IS NOT NULL
       ORDER BY DATASOURCE_NAME, TARGET_FIELD, FIELD_SEQ;

  BEGIN
    DBG('Inside fn_build_snck_data...');

    IF P_ACTION_CODE IN ('NEW', 'MODIFY', 'REOPEN') THEN

      IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                         'SNCK',
                                         GLOBAL.APPLICATION_DATE,
                                         L_SERIAL_NO,
                                         L_REF_NO,
                                         P_ERR_CODE) THEN
        DBG('Failed in TRPKS !!');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('p_prev_stdcif.v_sttms_customer.ADDRESS_LINE1' ||
        P_PREV_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
    DBG('p_wrk_stdcif.v_sttms_customer.ADDRESS_LINE1' ||
        P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
    IF P_ACTION_CODE = 'MODIFY' THEN
      DBG('i am inside MODIFY');

      G_PREV_STDCIF := P_PREV_STDCIF;
      G_WRK_STDCIF  := P_WRK_STDCIF;

      BEGIN

        SELECT COUNT(1)
          INTO L_COUNT
          FROM CSTB_CUST_SNCK_FIELDS
         WHERE FIELD_TYPE IN ('B', 'P')
           AND TARGET_FIELD IS NULL;

        IF L_COUNT > 0 THEN
          DBG('Sanction Check error: Please maintain the Sanction check metadata correctly');
          P_ERR_CODE   := 'ST-CIF-312';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;

        FOR L_SNCK_FEILDS IN C_SNCK_PARAMS1

         LOOP

          IF NVL(L_SNCK_FEILDS.MULTY_ENTRY, 'N') <> 'Y' AND
             L_SNCK_FEILDS.FIELD_TYPE IN ('V', 'B') THEN
            L_SQL := ' declare

              l_wrk_stdcif stpks_stdcif_main.ty_stdcif;
              l_prev_stdcif stpks_stdcif_main.ty_stdcif;
              begin
              l_prev_stdcif :=  stpks_stdcif_utils_0.fngetval(''p'');
              l_wrk_stdcif := stpks_stdcif_utils_0.fngetval(''w'');

                if ( NVL(l_wrk_stdcif.v_' ||
                     L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                     L_SNCK_FEILDS.FIELD_NAME || (CASE
                       WHEN L_SNCK_FEILDS.FIELD_NUMBERTYPE_FLAG = 'Y' THEN
                        ',999999)<> NVL(l_prev_stdcif.v_'
                       ELSE
                        ',''01-jan-1400'')<> NVL(l_prev_stdcif.v_'
                     END) || L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                     L_SNCK_FEILDS.FIELD_NAME || (CASE
                       WHEN L_SNCK_FEILDS.FIELD_NUMBERTYPE_FLAG = 'Y' THEN
                        ',999999)'
                       ELSE
                        ',''01-jan-1400'')'
                     END) || ') THEN

                   stpks_stdcif_utils_0.g_snck_status :=TRUE;

                END IF;
                end;';

            EXECUTE IMMEDIATE L_SQL;

          ELSIF NVL(L_SNCK_FEILDS.MULTY_ENTRY, 'N') = 'Y' AND
                L_SNCK_FEILDS.FIELD_TYPE IN ('V', 'B') THEN

            L_SQL := ' declare

                l_wrk_stdcif stpks_stdcif_main.ty_stdcif;
                l_prev_stdcif stpks_stdcif_main.ty_stdcif;

              begin

              l_prev_stdcif :=  stpks_stdcif_utils_0.fngetval(''p'');
              l_wrk_stdcif := stpks_stdcif_utils_0.fngetval(''w'');
            if (l_wrk_stdcif.v_' || L_SNCK_FEILDS.DATASOURCE_NAME ||
                     '.count>0 and  (l_prev_stdcif.v_' ||
                     L_SNCK_FEILDS.DATASOURCE_NAME ||
                     '.count>0) and (l_wrk_stdcif.v_' ||
                     L_SNCK_FEILDS.DATASOURCE_NAME || '.count =  l_prev_stdcif.v_' ||
                     L_SNCK_FEILDS.DATASOURCE_NAME ||
                     '.count))then

              for i in  l_wrk_stdcif.v_' ||
                     L_SNCK_FEILDS.DATASOURCE_NAME || '.first..
              l_wrk_stdcif.v_' || L_SNCK_FEILDS.DATASOURCE_NAME ||
                     '.last
              loop

                    if ( NVL(l_wrk_stdcif.v_' ||
                     L_SNCK_FEILDS.DATASOURCE_NAME || '(i).' ||
                     L_SNCK_FEILDS.FIELD_NAME || (CASE
                       WHEN L_SNCK_FEILDS.FIELD_NUMBERTYPE_FLAG = 'Y' THEN
                        ',999999)<> NVL(l_prev_stdcif.v_'
                       ELSE
                        ',''01-jan-1400'')<> NVL(l_prev_stdcif.v_'
                     END) || L_SNCK_FEILDS.DATASOURCE_NAME || '(i).' ||
                     L_SNCK_FEILDS.FIELD_NAME || (CASE
                       WHEN L_SNCK_FEILDS.FIELD_NUMBERTYPE_FLAG = 'Y' THEN
                        ',999999)'
                       ELSE
                        ',''01-jan-1400'')'
                     END) || ') THEN

                      stpks_stdcif_utils_0.g_snck_status :=TRUE;
                      exit;
                    END IF;
                    end loop;

                     elsif (l_wrk_stdcif.v_' ||
                     L_SNCK_FEILDS.DATASOURCE_NAME ||
                     '.count>0) and  (l_prev_stdcif.v_' ||
                     L_SNCK_FEILDS.DATASOURCE_NAME ||
                     '.count=0)then
                     stpks_stdcif_utils_0.g_snck_status :=TRUE;

                     elsif (l_wrk_stdcif.v_' ||
                     L_SNCK_FEILDS.DATASOURCE_NAME ||
                     '.count>0 and  l_prev_stdcif.v_' ||
                     L_SNCK_FEILDS.DATASOURCE_NAME ||
                     '.count>0) and (l_wrk_stdcif.v_' ||
                     L_SNCK_FEILDS.DATASOURCE_NAME || '.count >  l_prev_stdcif.v_' ||
                     L_SNCK_FEILDS.DATASOURCE_NAME || '.count) then
                     stpks_stdcif_utils_0.g_snck_status :=TRUE;
                     end if ;


                    end;';

            EXECUTE IMMEDIATE L_SQL;

          END IF;

          IF (STPKS_STDCIF_UTILS_0.G_SNCK_STATUS) THEN
            DBG('value changes!!!sanction request to be built  ');
            EXIT;

          END IF;
        END LOOP;

        DBG('callform check');

        IF NOT STPKS_STDCIF_UTILS_0.G_SNCK_STATUS THEN

          FOR L_SNCK_FEILDS IN C_SNCK_PARAMS2

           LOOP

            IF NVL(L_SNCK_FEILDS.MULTY_ENTRY, 'N') <> 'Y' AND
               L_SNCK_FEILDS.FIELD_TYPE IN ('V', 'B') THEN
              DBG('callform val');
              L_SQL := ' declare

              l_wrk_stdcif stpks_stdcif_main.ty_stdcif;
              l_prev_stdcif stpks_stdcif_main.ty_stdcif;
              begin
              l_prev_stdcif :=  stpks_stdcif_utils_0.fngetval(''p'');
              l_wrk_stdcif := stpks_stdcif_utils_0.fngetval(''w'');

                   if ( NVL(l_wrk_stdcif.ty_' ||
                       L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                       L_SNCK_FEILDS.DATASOURCE_NAME || '.' || L_SNCK_FEILDS.FIELD_NAME ||
                       (CASE
                         WHEN L_SNCK_FEILDS.FIELD_NUMBERTYPE_FLAG = 'Y' THEN
                          ',999999)<> NVL(l_prev_stdcif.v_'
                         ELSE
                          ',''01-jan-1400'')<> NVL(l_prev_stdcif.ty_'
                       END) || L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                       L_SNCK_FEILDS.DATASOURCE_NAME || '.' || L_SNCK_FEILDS.FIELD_NAME ||
                       (CASE
                         WHEN L_SNCK_FEILDS.FIELD_NUMBERTYPE_FLAG = 'Y' THEN
                          ',999999)'
                         ELSE
                          ',''01-jan-1400'')'
                       END) || ') THEN

                   stpks_stdcif_utils_0.g_snck_status :=TRUE;

                END IF;
                end;';

              DBG('My l_sql statement is ' || L_SQL);

              EXECUTE IMMEDIATE L_SQL;

            ELSIF NVL(L_SNCK_FEILDS.MULTY_ENTRY, 'N') = 'Y' AND
                  L_SNCK_FEILDS.FIELD_TYPE IN ('V', 'B') THEN

              L_SQL := ' declare

                l_wrk_stdcif stpks_stdcif_main.ty_stdcif;
                l_prev_stdcif stpks_stdcif_main.ty_stdcif;

              begin

              l_prev_stdcif :=  stpks_stdcif_utils_0.fngetval(''p'');
              l_wrk_stdcif := stpks_stdcif_utils_0.fngetval(''w'');

               if (l_wrk_stdcif.ty_' ||
                       L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                       L_SNCK_FEILDS.DATASOURCE_NAME ||
                       '.count>0 and  (l_prev_stdcif.ty_' ||
                       L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                       L_SNCK_FEILDS.DATASOURCE_NAME ||
                       '.count>0) and (l_wrk_stdcif.ty_' || L_SNCK_FEILDS.CALLFORM_NAME ||
                       '.v_' || L_SNCK_FEILDS.DATASOURCE_NAME ||
                       '.count =  l_prev_stdcif.ty_' || L_SNCK_FEILDS.CALLFORM_NAME ||
                       '.v_' || L_SNCK_FEILDS.DATASOURCE_NAME ||
                       '.count))then

              for i in  l_wrk_stdcif.ty_' ||
                       L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                       L_SNCK_FEILDS.DATASOURCE_NAME || '.first..
              l_wrk_stdcif.ty_' || L_SNCK_FEILDS.CALLFORM_NAME ||
                       '.v_' || L_SNCK_FEILDS.DATASOURCE_NAME ||
                       '.last
              loop

                    if ( NVL(l_wrk_stdcif.ty_' ||
                       L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                       L_SNCK_FEILDS.DATASOURCE_NAME || '(i).' ||
                       L_SNCK_FEILDS.FIELD_NAME || (CASE
                         WHEN L_SNCK_FEILDS.FIELD_NUMBERTYPE_FLAG = 'Y' THEN
                          ',999999)<> NVL(l_prev_stdcif.v_'
                         ELSE
                          ',''01-jan-1400'')<> NVL(l_prev_stdcif.ty_'
                       END) || L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                       L_SNCK_FEILDS.DATASOURCE_NAME || '(i).' ||
                       L_SNCK_FEILDS.FIELD_NAME || (CASE
                         WHEN L_SNCK_FEILDS.FIELD_NUMBERTYPE_FLAG = 'Y' THEN
                          ',999999)'
                         ELSE
                          ',''01-jan-1400'')'
                       END) || ') THEN

                      stpks_stdcif_utils_0.g_snck_status :=TRUE;
                      exit;
                    END IF;
                    end loop;
                     elsif (l_wrk_stdcif.ty_' ||
                       L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                       L_SNCK_FEILDS.DATASOURCE_NAME ||
                       '.count>0) and  (l_prev_stdcif.ty_' ||
                       L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                       L_SNCK_FEILDS.DATASOURCE_NAME ||
                       '.count=0)then
                     stpks_stdcif_utils_0.g_snck_status :=TRUE;

                     elsif (l_wrk_stdcif.ty_' ||
                       L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                       L_SNCK_FEILDS.DATASOURCE_NAME ||
                       '.count>0 and  l_prev_stdcif.ty_' || L_SNCK_FEILDS.CALLFORM_NAME ||
                       '.v_' || L_SNCK_FEILDS.DATASOURCE_NAME ||
                       '.count>0) and (l_wrk_stdcif.ty_' || L_SNCK_FEILDS.CALLFORM_NAME ||
                       '.v_' || L_SNCK_FEILDS.DATASOURCE_NAME ||
                       '.count >  l_prev_stdcif.ty_' || L_SNCK_FEILDS.CALLFORM_NAME ||
                       '.v_' || L_SNCK_FEILDS.DATASOURCE_NAME ||
                       '.count) then
                     stpks_stdcif_utils_0.g_snck_status :=TRUE;
                     end if ;


                    end;';

              DBG('My l_sql statement fro multi entry is  ' || L_SQL);

              EXECUTE IMMEDIATE L_SQL;

            END IF;
            IF (STPKS_STDCIF_UTILS_0.G_SNCK_STATUS) THEN
              DBG('Sanction check is true');
              EXIT;

            END IF;
          END LOOP;

        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('oops..!!exception for sanction check!!' || SQLERRM);

          DBG('error is at ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          DEBUG.PR_DEBUG('**', SQLERRM);
          P_ERR_CODE   := 'ST-CIF-311';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;

      END;

    END IF;

    DBG('I AM checking action codes' || P_ACTION_CODE);

    BEGIN

      IF (P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_REOPEN)) OR
         (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
         (L_CUSTOMER OR L_CORP_DIRECTORS OR L_CUST_PERSONAL_JOINT OR
         L_AUTO_ACC_NOMINEES OR STPKS_STDCIF_UTILS_0.G_SNCK_STATUS)) THEN

        G_WRK_STDCIF := P_WRK_STDCIF;
        DBG('For new and Re-open actions, sending the request is manadatory');

        DBG('Building SNCK Master.. ');
        DBG('l_Ref_No' || L_REF_NO);
        DBG('p_wrk_stdcif.v_sttms_customer.local_branch' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);

        BEGIN
          SELECT SANCTIONS_CHECKS_SYSTEM
            INTO L_SNCK_SYSTEM_CODE
            FROM CSTM_SNCK_BRN_PARAM
           WHERE BRANCH_CODE = P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('l_snck_system_code is not maintained at branch level');
        END;

        P_SNCK.V_CSTBS_SNCK_MASTER.SNCK_REF_NO := L_REF_NO;
        P_SNCK.V_CSTBS_SNCK_MASTER.BRANCH_CODE := P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;

        P_SNCK.V_CSTBS_SNCK_MASTER.ALT_CONTRACT_REF_NO := L_REF_NO;
        P_SNCK.V_CSTBS_SNCK_MASTER.CONTRACT_REF_NO     := L_REF_NO;
        P_SNCK.V_CSTBS_SNCK_MASTER.CUSTOMER_NO         := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        P_SNCK.V_CSTBS_SNCK_MASTER.MODULE              := 'CO';

        P_SNCK.V_CSTBS_SNCK_MASTER.SNCK_CURRENT_STATUS  := 'P';
        P_SNCK.V_CSTBS_SNCK_MASTER.SNCK_SYSTEM_CODE     := L_SNCK_SYSTEM_CODE;
        P_SNCK.V_CSTBS_SNCK_MASTER.REQUEST_DATE         := GLOBAL.APPLICATION_DATE;
        P_SNCK.V_CSTBS_SNCK_MASTER.SNCK_RESPONSE_STATUS := '';

        P_SNCK.V_CSTBS_SNCK_MASTER.QUEUE_AUTH_STATUS := '';
        P_SNCK.V_CSTBS_SNCK_MASTER.VERSION_NO        := P_WRK_STDCIF.V_STTMS_CUSTOMER.MOD_NO;

        P_SNCK.V_CSTBS_SNCK_MASTER.PREV_SNCK_STATUS   := '';
        P_SNCK.V_CSTBS_SNCK_MASTER.SNCK_RESPONSE_DATE := '';
        P_SNCK.V_CSTBS_SNCK_MASTER.ENTITY             := 'CO';
        P_SNCK.V_CSTBS_SNCK_MASTER.ENTITY_TYPE        := 'M';

        DBG('Building SNCK Detail.. ' || P_FUNCTION_ID);
        DBG('p_wrk_stdcif.v_sttms_customer.customer_no' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
        DBG('p_wrk_stdcif.v_sttms_customer.SNCK_STATUS' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD36);

        L_PARTY_TYPE := 'CUST_PRIM';

        L_SQL                          := NULL;
        G_CSTB_SNCK_DETAIL.SNCK_REF_NO := L_REF_NO;
        G_CSTB_SNCK_DETAIL.PARTY_TYPE  := L_PARTY_TYPE;
        G_CSTB_SNCK_DETAIL.BRANCH_CODE := P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
        G_CSTB_SNCK_DETAIL.SNCK_SEQ    := L_INDEX;

        L_SQL1 := ' declare
              l_wrk_stdcif stpks_stdcif_main.ty_stdcif;
              begin
              l_wrk_stdcif := stpks_stdcif_utils_0.fngetval(''w'');
              ';
        FOR L_SNCK_FEILDS IN C_SNCK_PARAMS1 LOOP

          IF UPPER(L_SNCK_FEILDS.DATASOURCE_NAME) = 'STTMS_CUSTOMER' AND
             L_SNCK_FEILDS.TARGET_FIELD IS NOT NULL AND
             L_SNCK_FEILDS.FIELD_TYPE IN ('P', 'B') THEN

            IF L_FIELD <> L_SNCK_FEILDS.TARGET_FIELD THEN
              L_SQL := L_SQL || 'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                       L_SNCK_FEILDS.TARGET_FIELD || ':=  l_wrk_stdcif.v_' ||
                       L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                       L_SNCK_FEILDS.FIELD_NAME || ';
                     ';
            ELSE
              L_SQL := L_SQL || 'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                       L_SNCK_FEILDS.TARGET_FIELD ||
                       ':= stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                       L_SNCK_FEILDS.TARGET_FIELD ||
                       '||'',''|| l_wrk_stdcif.v_' ||
                       L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                       L_SNCK_FEILDS.FIELD_NAME || ';
                     ';

            END IF;

            L_FIELD := L_SNCK_FEILDS.TARGET_FIELD;

          END IF;
        END LOOP;
        L_SQL := L_SQL || '
                 end;';
        L_SQL := L_SQL1 || L_SQL;
        DBG('My l_sql statement is ' || L_SQL);
        EXECUTE IMMEDIATE L_SQL;
        L_SQL := NULL;
        L_FIELD := '~';
        P_SNCK.V_CSTBS_SNCK_DETAIL(L_INDEX) := G_CSTB_SNCK_DETAIL;
        DBG('party type' || G_CSTB_SNCK_DETAIL.PARTY_TYPE || '  ' ||
            G_CSTB_SNCK_DETAIL.PARTY_NAME);

        L_INDEX            := L_INDEX + 1;
        G_CSTB_SNCK_DETAIL := NULL;

        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
          L_PARTY_TYPE                   := 'CUST_PERS';
          G_CSTB_SNCK_DETAIL.SNCK_REF_NO := L_REF_NO;
          G_CSTB_SNCK_DETAIL.PARTY_TYPE  := L_PARTY_TYPE;
          G_CSTB_SNCK_DETAIL.BRANCH_CODE := P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
          G_CSTB_SNCK_DETAIL.SNCK_SEQ    := L_INDEX;
          L_SQL1                         := ' declare
              l_wrk_stdcif stpks_stdcif_main.ty_stdcif;
              begin
              l_wrk_stdcif := stpks_stdcif_utils_0.fngetval(''w'');
              ';
          FOR L_SNCK_FEILDS IN C_SNCK_PARAMS1 LOOP

            IF UPPER(L_SNCK_FEILDS.DATASOURCE_NAME) = 'STTMS_CUST_PERSONAL' AND
               L_SNCK_FEILDS.TARGET_FIELD IS NOT NULL AND
               L_SNCK_FEILDS.FIELD_TYPE IN ('P', 'B') THEN

              IF L_FIELD <> L_SNCK_FEILDS.TARGET_FIELD THEN
                L_ADDR_FLD := L_SNCK_FEILDS.FIELD_NAME;
                L_SQL      := L_SQL ||
                              'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                              L_SNCK_FEILDS.TARGET_FIELD ||
                              ':=  l_wrk_stdcif.v_' ||
                              L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                              L_SNCK_FEILDS.FIELD_NAME || ';
                     ';

                IF L_SNCK_FEILDS.PRE_CONCAT IS NOT NULL THEN
                  L_SQL := L_SQL || '
                         IF  l_wrk_stdcif.v_' ||
                           L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                           L_SNCK_FEILDS.PRE_CONCAT ||
                           ' IS NOT NULL THEN
                           ';

                  L_SQL := L_SQL ||
                           'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                           L_SNCK_FEILDS.TARGET_FIELD ||
                           ':= to_char(l_wrk_stdcif.v_' ||
                           L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                           L_SNCK_FEILDS.PRE_CONCAT || ')' || '||''-''||' ||
                           'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                           L_SNCK_FEILDS.TARGET_FIELD ||
                           ';
                         ';

                  L_SQL := L_SQL || ' END IF;';
                END IF;
              ELSE
                L_SQL := L_SQL ||
                         'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                         L_SNCK_FEILDS.TARGET_FIELD ||
                         ':= stpks_stdcif_utils_0.g_cstb_snck_detail.' ||

                         L_SNCK_FEILDS.TARGET_FIELD;
                IF SUBSTR(L_ADDR_FLD, 0, 2) <>
                   SUBSTR(L_SNCK_FEILDS.FIELD_NAME, 0, 2) AND
                   L_SNCK_FEILDS.TARGET_FIELD = 'ADDRESS' THEN
                  L_SQL := L_SQL || '||'';''|| l_wrk_stdcif.v_';
                ELSE
                  L_SQL := L_SQL || '||'',''|| l_wrk_stdcif.v_';
                END IF;
                L_SQL      := L_SQL ||

                              L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                              L_SNCK_FEILDS.FIELD_NAME || ';
                     ';
                L_ADDR_FLD := L_SNCK_FEILDS.FIELD_NAME;
              END IF;

              L_FIELD := L_SNCK_FEILDS.TARGET_FIELD;

            END IF;
          END LOOP;
          L_SQL := L_SQL || '
                 end;';
          L_SQL := L_SQL1 || L_SQL;
          DBG('My l_sql statement is ' || L_SQL);
          EXECUTE IMMEDIATE L_SQL;
          L_SQL := NULL;
          L_FIELD := '~';
          P_SNCK.V_CSTBS_SNCK_DETAIL(L_INDEX) := G_CSTB_SNCK_DETAIL;
          DBG('party type' || P_SNCK.V_CSTBS_SNCK_DETAIL(L_INDEX)
              .PARTY_TYPE || '  ' || G_CSTB_SNCK_DETAIL.PARTY_NAME);
          DBG('ADDRESS' || G_CSTB_SNCK_DETAIL.PARTY_TYPE || '  ' ||
              G_CSTB_SNCK_DETAIL.ADDRESS);
          L_INDEX            := L_INDEX + 1;
          G_CSTB_SNCK_DETAIL := NULL;

        END IF;

        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C', 'B') THEN
          L_PARTY_TYPE := 'CUST_CORP';

          G_CSTB_SNCK_DETAIL.SNCK_REF_NO := L_REF_NO;
          G_CSTB_SNCK_DETAIL.PARTY_TYPE  := L_PARTY_TYPE;
          G_CSTB_SNCK_DETAIL.BRANCH_CODE := P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
          G_CSTB_SNCK_DETAIL.SNCK_SEQ    := L_INDEX;

          L_SQL1 := ' declare
              l_wrk_stdcif stpks_stdcif_main.ty_stdcif;
              begin
              l_wrk_stdcif := stpks_stdcif_utils_0.fngetval(''w'');
              ';
          FOR L_SNCK_FEILDS IN C_SNCK_PARAMS1 LOOP

            IF UPPER(L_SNCK_FEILDS.DATASOURCE_NAME) =
               'STTMS_CUST_CORPORATE' AND
               L_SNCK_FEILDS.TARGET_FIELD IS NOT NULL AND
               L_SNCK_FEILDS.FIELD_TYPE IN ('P', 'B') THEN

              IF L_FIELD <> L_SNCK_FEILDS.TARGET_FIELD THEN
                L_SQL := L_SQL ||
                         'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                         L_SNCK_FEILDS.TARGET_FIELD ||
                         ':=  l_wrk_stdcif.v_' ||
                         L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                         L_SNCK_FEILDS.FIELD_NAME || ';
                     ';
              ELSE
                L_SQL := L_SQL ||
                         'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                         L_SNCK_FEILDS.TARGET_FIELD ||
                         ':= stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                         L_SNCK_FEILDS.TARGET_FIELD ||
                         '||'',''|| l_wrk_stdcif.v_' ||
                         L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                         L_SNCK_FEILDS.FIELD_NAME || ';
                     ';

              END IF;

              L_FIELD := L_SNCK_FEILDS.TARGET_FIELD;

            END IF;
          END LOOP;
          L_SQL := L_SQL || '
                 end;';
          L_SQL := L_SQL1 || L_SQL;
          DBG('My director  statement is ' || L_SQL);
          EXECUTE IMMEDIATE L_SQL;
          L_SQL := NULL;
          L_FIELD := '~';
          P_SNCK.V_CSTBS_SNCK_DETAIL(L_INDEX) := G_CSTB_SNCK_DETAIL;
          DBG('party type' || G_CSTB_SNCK_DETAIL.PARTY_TYPE || '  ' ||
              G_CSTB_SNCK_DETAIL.PARTY_NAME);
          L_INDEX            := L_INDEX + 1;
          G_CSTB_SNCK_DETAIL := NULL;

        END IF;

        IF P_FUNCTION_ID = 'STDCIF' THEN

          IF P_WRK_STDCIF.V_STTMS_CORP_DIRECTORS.COUNT > 0 THEN
            DBG('Director start ' ||
                P_WRK_STDCIF.V_STTMS_CORP_DIRECTORS.COUNT);
            FOR I IN P_WRK_STDCIF.V_STTMS_CORP_DIRECTORS.FIRST .. P_WRK_STDCIF.V_STTMS_CORP_DIRECTORS.LAST LOOP
              L_PARTY_TYPE                   := 'CUST_DIRE';
              G_CSTB_SNCK_DETAIL.SNCK_REF_NO := L_REF_NO;
              G_CSTB_SNCK_DETAIL.PARTY_TYPE  := L_PARTY_TYPE;
              G_CSTB_SNCK_DETAIL.BRANCH_CODE := P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
              G_CSTB_SNCK_DETAIL.SNCK_SEQ    := L_INDEX;

              L_SQL1 := ' declare
              l_wrk_stdcif stpks_stdcif_main.ty_stdcif;
              begin
              l_wrk_stdcif := stpks_stdcif_utils_0.fngetval(''w'');
           ';

              FOR L_SNCK_FEILDS IN C_SNCK_PARAMS1 LOOP

                IF UPPER(L_SNCK_FEILDS.DATASOURCE_NAME) =
                   'STTMS_CORP_DIRECTORS' AND
                   L_SNCK_FEILDS.TARGET_FIELD IS NOT NULL AND
                   L_SNCK_FEILDS.FIELD_TYPE IN ('P', 'B') THEN

                  IF L_FIELD <> L_SNCK_FEILDS.TARGET_FIELD THEN
                    L_ADDR_FLD := L_SNCK_FEILDS.FIELD_NAME;
                    L_SQL      := L_SQL ||
                                  'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                                  L_SNCK_FEILDS.TARGET_FIELD ||
                                  ':=  l_wrk_stdcif.v_' ||
                                  L_SNCK_FEILDS.DATASOURCE_NAME || '(' || I || ').' ||
                                  L_SNCK_FEILDS.FIELD_NAME || ';
                           ';

                    IF L_SNCK_FEILDS.PRE_CONCAT IS NOT NULL THEN
                      L_SQL := L_SQL || '
                         IF  l_wrk_stdcif.v_' ||
                               L_SNCK_FEILDS.DATASOURCE_NAME || '(' || I || ').' ||
                               L_SNCK_FEILDS.PRE_CONCAT ||
                               ' IS NOT NULL THEN
                           ';

                      L_SQL := L_SQL ||
                               'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                               L_SNCK_FEILDS.TARGET_FIELD ||
                               ':= to_char(l_wrk_stdcif.v_' ||
                               L_SNCK_FEILDS.DATASOURCE_NAME || '(' || I || ').' ||
                               L_SNCK_FEILDS.PRE_CONCAT || ')' ||
                               '||''-''||' ||
                               'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                               L_SNCK_FEILDS.TARGET_FIELD ||
                               ';
                         ';

                      L_SQL := L_SQL || ' END IF;';
                    END IF;

                  ELSE
                    L_SQL := L_SQL ||
                             'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                             L_SNCK_FEILDS.TARGET_FIELD ||
                             ':= stpks_stdcif_utils_0.g_cstb_snck_detail.' ||

                             L_SNCK_FEILDS.TARGET_FIELD;
                    IF SUBSTR(L_ADDR_FLD, 0, 2) <>
                       SUBSTR(L_SNCK_FEILDS.FIELD_NAME, 0, 2) AND
                       L_SNCK_FEILDS.TARGET_FIELD = 'ADDRESS' THEN
                      L_SQL := L_SQL || '||'';''|| l_wrk_stdcif.v_';
                    ELSE
                      L_SQL := L_SQL || '||'',''|| l_wrk_stdcif.v_';
                    END IF;
                    L_SQL      := L_SQL ||

                                  L_SNCK_FEILDS.DATASOURCE_NAME || '(' || I || ').' ||
                                  L_SNCK_FEILDS.FIELD_NAME || ';
                           ';
                    L_ADDR_FLD := L_SNCK_FEILDS.FIELD_NAME;
                  END IF;

                  L_FIELD := L_SNCK_FEILDS.TARGET_FIELD;

                END IF;
              END LOOP;
              L_SQL := L_SQL || '
                 end;';
              L_SQL := L_SQL1 || L_SQL;
              DBG('My director l_sql statement is ' || L_SQL);
              EXECUTE IMMEDIATE L_SQL;

              L_SQL := NULL;
              L_FIELD := '~';
              P_SNCK.V_CSTBS_SNCK_DETAIL(L_INDEX) := G_CSTB_SNCK_DETAIL;
              DBG('party type' || G_CSTB_SNCK_DETAIL.PARTY_TYPE || '  ' ||
                  G_CSTB_SNCK_DETAIL.PARTY_NAME);
              L_INDEX            := L_INDEX + 1;
              G_CSTB_SNCK_DETAIL := NULL;
            END LOOP;
          END IF;

          IF P_WRK_STDCIF.V_STTMS_CUST_PROFESSIONAL.CUSTOMER_NO IS NOT NULL THEN
            L_PARTY_TYPE := 'CUST_PROF';

            G_CSTB_SNCK_DETAIL.SNCK_REF_NO := L_REF_NO;
            G_CSTB_SNCK_DETAIL.PARTY_TYPE  := L_PARTY_TYPE;
            G_CSTB_SNCK_DETAIL.BRANCH_CODE := P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
            G_CSTB_SNCK_DETAIL.SNCK_SEQ    := L_INDEX;

            L_SQL1 := ' declare
              l_wrk_stdcif stpks_stdcif_main.ty_stdcif;
              begin
              l_wrk_stdcif := stpks_stdcif_utils_0.fngetval(''w'');
              ';
            FOR L_SNCK_FEILDS IN C_SNCK_PARAMS1 LOOP

              IF UPPER(L_SNCK_FEILDS.DATASOURCE_NAME) =
                 'STTMS_CUST_PROFESSIONAL' AND
                 L_SNCK_FEILDS.TARGET_FIELD IS NOT NULL AND
                 L_SNCK_FEILDS.FIELD_TYPE IN ('P', 'B') THEN

                IF L_FIELD <> L_SNCK_FEILDS.TARGET_FIELD THEN
                  L_SQL := L_SQL ||
                           'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                           L_SNCK_FEILDS.TARGET_FIELD ||
                           ':=  l_wrk_stdcif.v_' ||
                           L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                           L_SNCK_FEILDS.FIELD_NAME || ';
                     ';
                ELSE
                  L_SQL := L_SQL ||
                           'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                           L_SNCK_FEILDS.TARGET_FIELD ||
                           ':= stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                           L_SNCK_FEILDS.TARGET_FIELD ||
                           '||'',''|| l_wrk_stdcif.v_' ||
                           L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                           L_SNCK_FEILDS.FIELD_NAME || ';
                     ';

                END IF;

                L_FIELD := L_SNCK_FEILDS.TARGET_FIELD;

              END IF;
            END LOOP;
            L_SQL := L_SQL || '
                 end;';
            L_SQL := L_SQL1 || L_SQL;
            DBG('My director l_sql statement is ' || L_SQL);
            EXECUTE IMMEDIATE L_SQL;
            L_SQL := NULL;
            L_FIELD := '~';
            P_SNCK.V_CSTBS_SNCK_DETAIL(L_INDEX) := G_CSTB_SNCK_DETAIL;
            DBG('party type' || G_CSTB_SNCK_DETAIL.PARTY_TYPE || '  ' ||
                G_CSTB_SNCK_DETAIL.PARTY_NAME);
            L_INDEX            := L_INDEX + 1;
            G_CSTB_SNCK_DETAIL := NULL;

          END IF;

          IF P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD8 = 'Y' THEN
            IF P_WRK_STDCIF.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.COUNT > 0 THEN
              FOR I IN P_WRK_STDCIF.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.FIRST .. P_WRK_STDCIF.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.LAST LOOP
                L_PARTY_TYPE                   := 'CUST_JOIN';
                G_CSTB_SNCK_DETAIL.SNCK_REF_NO := L_REF_NO;
                G_CSTB_SNCK_DETAIL.PARTY_TYPE  := L_PARTY_TYPE;
                G_CSTB_SNCK_DETAIL.BRANCH_CODE := P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
                G_CSTB_SNCK_DETAIL.SNCK_SEQ    := L_INDEX;

                L_SQL1 := ' declare
              l_wrk_stdcif stpks_stdcif_main.ty_stdcif;
              begin
              l_wrk_stdcif := stpks_stdcif_utils_0.fngetval(''w'');
           ';

                FOR L_SNCK_FEILDS IN C_SNCK_PARAMS2 LOOP

                  IF UPPER(L_SNCK_FEILDS.DATASOURCE_NAME) =
                     'STTMS_CUST_PERSONAL_JOINT' AND
                     L_SNCK_FEILDS.TARGET_FIELD IS NOT NULL AND
                     L_SNCK_FEILDS.FIELD_TYPE IN ('P', 'B') THEN

                    IF L_FIELD <> L_SNCK_FEILDS.TARGET_FIELD THEN
                      L_SQL := L_SQL ||
                               'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                               L_SNCK_FEILDS.TARGET_FIELD ||
                               ':=  l_wrk_stdcif.ty_' ||
                               L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                               L_SNCK_FEILDS.DATASOURCE_NAME || '(' || I || ').' ||
                               L_SNCK_FEILDS.FIELD_NAME || ';
                     ';

                    ELSE
                      L_SQL := L_SQL ||
                               'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                               L_SNCK_FEILDS.TARGET_FIELD ||
                               ':= stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                               L_SNCK_FEILDS.TARGET_FIELD ||
                               '||'',''|| l_wrk_stdcif.ty_' ||
                               L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                               L_SNCK_FEILDS.DATASOURCE_NAME || '(' || I || ').' ||
                               L_SNCK_FEILDS.FIELD_NAME || ';
                     ';

                    END IF;

                    L_FIELD := L_SNCK_FEILDS.TARGET_FIELD;

                  END IF;
                END LOOP;
                L_SQL := L_SQL || '
                 end;';
                L_SQL := L_SQL1 || L_SQL;
                DBG('My director l_sql statement is ' || L_SQL);
                EXECUTE IMMEDIATE L_SQL;
                L_SQL := NULL;
                L_FIELD := '~';
                P_SNCK.V_CSTBS_SNCK_DETAIL(L_INDEX) := G_CSTB_SNCK_DETAIL;
                DBG('party type' || G_CSTB_SNCK_DETAIL.PARTY_TYPE || '  ' ||
                    G_CSTB_SNCK_DETAIL.PARTY_NAME);
                L_INDEX            := L_INDEX + 1;
                G_CSTB_SNCK_DETAIL := NULL;

              END LOOP;
            END IF;
          END IF;
        END IF;
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT = 'Y' THEN
          L_PARTY_TYPE                   := 'CUST_AUTO';
          G_CSTB_SNCK_DETAIL.SNCK_REF_NO := L_REF_NO;
          G_CSTB_SNCK_DETAIL.PARTY_TYPE  := L_PARTY_TYPE;
          G_CSTB_SNCK_DETAIL.BRANCH_CODE := P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
          G_CSTB_SNCK_DETAIL.SNCK_SEQ    := L_INDEX;
          L_SQL1                         := ' declare
              l_wrk_stdcif stpks_stdcif_main.ty_stdcif;
              begin
              l_wrk_stdcif := stpks_stdcif_utils_0.fngetval(''w'');
              ';
          FOR L_SNCK_FEILDS IN C_SNCK_PARAMS2 LOOP

            IF UPPER(L_SNCK_FEILDS.DATASOURCE_NAME) = 'STVWS_AUTO_ACCOUNT' AND
               L_SNCK_FEILDS.TARGET_FIELD IS NOT NULL AND
               L_SNCK_FEILDS.FIELD_TYPE IN ('P', 'B') THEN

              IF L_FIELD <> L_SNCK_FEILDS.TARGET_FIELD THEN
                L_SQL := L_SQL ||
                         'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                         L_SNCK_FEILDS.TARGET_FIELD ||
                         ':=  l_wrk_stdcif.ty_' ||
                         L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                         L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                         L_SNCK_FEILDS.FIELD_NAME || ';
                     ';
              ELSE
                L_SQL := L_SQL ||
                         'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                         L_SNCK_FEILDS.TARGET_FIELD ||
                         ':= stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                         L_SNCK_FEILDS.TARGET_FIELD ||
                         '||'',''|| l_wrk_stdcif.ty_' ||
                         L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                         L_SNCK_FEILDS.DATASOURCE_NAME || '.' ||
                         L_SNCK_FEILDS.FIELD_NAME || ';
                     ';

              END IF;

              L_FIELD := L_SNCK_FEILDS.TARGET_FIELD;

            END IF;
          END LOOP;
          L_SQL := L_SQL || '
                 end;';
          L_SQL := L_SQL1 || L_SQL;
          DBG('My  l_sql statement is ' || L_SQL);
          EXECUTE IMMEDIATE L_SQL;
          L_SQL := NULL;
          L_FIELD := '~';
          P_SNCK.V_CSTBS_SNCK_DETAIL(L_INDEX) := G_CSTB_SNCK_DETAIL;
          L_INDEX := L_INDEX + 1;
          G_CSTB_SNCK_DETAIL := NULL;

        END IF;

        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT = 'Y' THEN
          IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.COUNT > 0 THEN
            FOR I IN P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.FIRST .. P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES.LAST LOOP
              L_PARTY_TYPE                   := 'CUST_ANOM';
              G_CSTB_SNCK_DETAIL.SNCK_REF_NO := L_REF_NO;
              G_CSTB_SNCK_DETAIL.PARTY_TYPE  := L_PARTY_TYPE;
              G_CSTB_SNCK_DETAIL.BRANCH_CODE := P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
              G_CSTB_SNCK_DETAIL.SNCK_SEQ    := L_INDEX;

              L_SQL1 := ' declare
              l_wrk_stdcif stpks_stdcif_main.ty_stdcif;
              begin
              l_wrk_stdcif := stpks_stdcif_utils_0.fngetval(''w'');
           ';

              FOR L_SNCK_FEILDS IN C_SNCK_PARAMS2 LOOP

                IF UPPER(L_SNCK_FEILDS.DATASOURCE_NAME) =
                   'STVWS_AUTO_ACC_NOMINEES' AND
                   L_SNCK_FEILDS.TARGET_FIELD IS NOT NULL AND
                   L_SNCK_FEILDS.FIELD_TYPE IN ('P', 'B') THEN

                  IF L_FIELD <> L_SNCK_FEILDS.TARGET_FIELD THEN
                    L_SQL := L_SQL ||
                             'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                             L_SNCK_FEILDS.TARGET_FIELD ||
                             ':=  l_wrk_stdcif.ty_' ||
                             L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                             L_SNCK_FEILDS.DATASOURCE_NAME || '(' || I || ').' ||
                             L_SNCK_FEILDS.FIELD_NAME || ';
                     ';

                  ELSE
                    L_SQL := L_SQL ||
                             'stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                             L_SNCK_FEILDS.TARGET_FIELD ||
                             ':= stpks_stdcif_utils_0.g_cstb_snck_detail.' ||
                             L_SNCK_FEILDS.TARGET_FIELD ||
                             '||'',''|| l_wrk_stdcif.ty_' ||
                             L_SNCK_FEILDS.CALLFORM_NAME || '.v_' ||
                             L_SNCK_FEILDS.DATASOURCE_NAME || '(' || I || ').' ||
                             L_SNCK_FEILDS.FIELD_NAME || ';
                     ';

                  END IF;

                  L_FIELD := L_SNCK_FEILDS.TARGET_FIELD;

                END IF;
              END LOOP;
              L_SQL := L_SQL || '
                 end;';
              L_SQL := L_SQL1 || L_SQL;
              DBG('My director l_sql statement is ' || L_SQL);
              EXECUTE IMMEDIATE L_SQL;
              L_SQL := NULL;
              L_FIELD := '~';
              P_SNCK.V_CSTBS_SNCK_DETAIL(L_INDEX) := G_CSTB_SNCK_DETAIL;
              L_INDEX := L_INDEX + 1;
              G_CSTB_SNCK_DETAIL := NULL;

            END LOOP;

          END IF;
        END IF;

      ELSE
        RETURN TRUE;
        DBG('No modification of sanction check relevant fields done..');
      END IF;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('oops..!!exception for sanction check request data build!!' ||
            SQLERRM);

        DBG('error is at ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        DEBUG.PR_DEBUG('**', SQLERRM);
        P_ERR_CODE   := 'ST-CIF-311';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;

    END;

    P_WRK_STDCIF.V_CSTBS_SNCK_MASTER := P_SNCK.V_CSTBS_SNCK_MASTER;
    DBG('snck detail count ' || P_SNCK.V_CSTBS_SNCK_DETAIL.COUNT);

    FOR I IN P_SNCK.V_CSTBS_SNCK_DETAIL.FIRST .. P_SNCK.V_CSTBS_SNCK_DETAIL.LAST LOOP
      P_WRK_STDCIF.V_CSTBS_SNCK_DETAIL(I) := P_SNCK.V_CSTBS_SNCK_DETAIL(I);
    END LOOP;

    P_SNCK.V_CSTBS_SNCK_STATUS.SNCK_REF_NO := P_SNCK.V_CSTBS_SNCK_MASTER.SNCK_REF_NO;
    P_SNCK.V_CSTBS_SNCK_STATUS.KEY_COLS    := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
    P_SNCK.V_CSTBS_SNCK_STATUS.MOD_NO      := P_WRK_STDCIF.V_STTMS_CUSTOMER.MOD_NO;
    P_SNCK.V_CSTBS_SNCK_STATUS.SNCK_STATUS := 'P';

    P_WRK_STDCIF.V_CSTBS_SNCK_STATUS := P_SNCK.V_CSTBS_SNCK_STATUS;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of fn_build_snck_data..');
      DBG('error is at ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_BUILD_SNCK_DATA;

  FUNCTION FN_SNCK_STATUS_UPLOAD(P_FUNCTION_ID IN VARCHAR2,
                                 P_ACTION_CODE IN VARCHAR2,
                                 P_WRK_STDCIF  IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                 P_ERR_CODE    IN OUT VARCHAR2,
                                 P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_ACTION_CODE    VARCHAR2(20);
    L_COUNT          NUMBER := 0;
    L_TANKING_STATUS VARCHAR2(10);
  BEGIN
    DBG('inside Fn_Snck_Status_Upload....');
    L_TANKING_STATUS := CSPKS_REQ_WRAPPER.FN_GET_TANKED_STAT(P_FUNCTION_ID);
    IF CSPKS_SNCK_UTILS.G_FROM_BPEL OR
       (L_TANKING_STATUS = 'T' AND

       P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                          CSPKS_REQ_GLOBAL.P_MODIFY,
                          CSPKS_REQ_GLOBAL.P_REOPEN)) OR
       ((NOT CSPKS_SNCK_UTILS.FN_IS_FUNCTION_ID_TANKED(P_FUNCTION_ID)) AND
       P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                          CSPKS_REQ_GLOBAL.P_MODIFY,
                          CSPKS_REQ_GLOBAL.P_REOPEN)) THEN
      BEGIN
        DBG('Enters for insert...');
        IF P_WRK_STDCIF.V_CSTBS_SNCK_MASTER.SNCK_REF_NO IS NOT NULL THEN

          DBG('Record Sent..');
          INSERT INTO CSTB_SNCK_MASTER
          VALUES P_WRK_STDCIF.V_CSTBS_SNCK_MASTER;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed In Insert into CSTB_SNCK_MASTER..');
          DBG(SQLERRM);
          RETURN FALSE;
      END;

      DBG('Inserting Into CSTB_SNCK_DETAIL..');
      BEGIN
        L_COUNT := P_WRK_STDCIF.V_CSTBS_SNCK_DETAIL.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO CSTB_SNCK_DETAIL
          VALUES P_WRK_STDCIF.V_CSTBS_SNCK_DETAIL
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed In Insert into CSTB_SNCK_DETAIL..');
          DBG(SQLERRM);
          RETURN FALSE;
      END;

      DBG('Inserting Into CSTB_SNCK_STATUS..');
      DBG('p_wrk_stdcif.V_CSTB_SNCK_MASTER.SNCK_REF_NO' ||
          P_WRK_STDCIF.V_CSTBS_SNCK_MASTER.SNCK_REF_NO);
      BEGIN
        IF P_WRK_STDCIF.V_CSTBS_SNCK_MASTER.SNCK_REF_NO IS NOT NULL THEN
          DBG('Record Sent..');
          DBG('l_wrk_stdcif.V_CSTB_SNCK_MASTER.SNCK_REF_NO' ||
              P_WRK_STDCIF.V_CSTBS_SNCK_MASTER.SNCK_REF_NO);
          DBG('l_wrk_stdcif.v_sttms_customer.customer_no' ||
              P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
          DBG('l_wrk_stdcif.v_sttms_customer.mod_no' ||
              P_WRK_STDCIF.V_STTMS_CUSTOMER.MOD_NO);

          INSERT INTO CSTB_SNCK_STATUS
          VALUES P_WRK_STDCIF.V_CSTBS_SNCK_STATUS;

        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed In Insert into CSTB_SNCK_STATUS..');
          DBG(SQLERRM);
          RETURN FALSE;
      END;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When others of stpks_stdcif_Kernel.Fn_Snck_Status_Upload ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_SNCK_STATUS_UPLOAD;

  FUNCTION FN_VALIDATE_SNCK_STATUS(P_SOURCE      IN VARCHAR2,
                                   P_FUNCTION_ID IN VARCHAR2,
                                   P_ACTION_CODE IN VARCHAR2,
                                   P_KEY_ID      IN VARCHAR2,
                                   P_MOD_NO      IN NUMBER,
                                   P_ERR_CODE    IN OUT VARCHAR2,
                                   P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_SNCK_STATUS CSTBS_SNCK_STATUS.SNCK_STATUS%TYPE;
    L_ACTION_CODE STTBS_RECORD_LOG.ACTION_CODE%TYPE;
    L_SNCK_MOD_NO NUMBER;
    L_REC_KEY     STTBS_RECORD_LOG.KEY_ID%TYPE;

  BEGIN
    DBG('In Fn_Validate_Snck_Status for the Action code ' || P_ACTION_CODE);
    DBG('Mod No is ' || P_MOD_NO);
    DBG('l_Key_Id is ' || P_KEY_ID);
    BEGIN
      SELECT MAX(MOD_NO)
        INTO L_SNCK_MOD_NO
        FROM CSTBS_SNCK_STATUS
       WHERE KEY_COLS = P_KEY_ID;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in getting the data from Status table');
        L_SNCK_MOD_NO := 0;
    END;

    DBG('l_Snck_Mod_No ' || L_SNCK_MOD_NO);
    DBG('Now building the Record log key');

    L_REC_KEY := '~STTM_CUSTOMER~' || P_KEY_ID || '~';
    DBG('Record log key is ' || L_REC_KEY);

    DBG('Correct Mod no is ' || L_SNCK_MOD_NO);

    DBG('For auth/delete case, picking the action code for which record is authorized');
    IF P_ACTION_CODE IN
       (CSPKS_REQ_GLOBAL.P_AUTH,
        CSPKS_REQ_GLOBAL.P_DELETE,
        CSPKS_REQ_GLOBAL.P_VERSION_DELETE) THEN
      BEGIN
        SELECT ACTION_CODE
          INTO L_ACTION_CODE
          FROM STTBS_RECORD_LOG
         WHERE KEY_ID = L_REC_KEY
           AND MOD_NO = P_MOD_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in picking the Action Code');
      END;
      DBG('l_Action_Code is ' || L_ACTION_CODE);
    END IF;

    DBG('p_Key_Id is:::' || P_KEY_ID);

    IF NOT CSPKS_SNCK_UTILS.FN_GET_SNCK_STATUS(P_KEY_ID,
                                               L_SNCK_MOD_NO,
                                               L_SNCK_STATUS) THEN
      DBG('Failed in getting the SC status ');
      P_ERR_CODE   := 'ST-CIF-308';
      P_ERR_PARAMS := NULL;
    END IF;
    DBG('Got the SC status as ' || L_SNCK_STATUS);

    DBG('p_Action_Code is -->' || P_ACTION_CODE);
    DBG('l_Action_Code is -->' || L_ACTION_CODE);
    IF P_MOD_NO > 1 AND P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW) AND
       L_SNCK_STATUS IN ('P') THEN
      DBG('Modifying the tanked records before auth');
      DBG('Status pending. Modification or Re-open is not allowed');
      P_ERR_CODE   := 'ST-SNCK-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY,
                            CSPKS_REQ_GLOBAL.P_AUTH,
                            CSPKS_REQ_GLOBAL.P_REOPEN) AND
          L_SNCK_STATUS IN ('P') THEN
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_AUTH) THEN
        IF L_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                             CSPKS_REQ_GLOBAL.P_MODIFY,
                             CSPKS_REQ_GLOBAL.P_REOPEN) THEN
          DBG('Going to authorize ' || L_ACTION_CODE ||
              ' action, so validating');
          DBG('Status is pending. Authorization of the customer is not allowed');
          P_ERR_CODE   := 'ST-CIF-301';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
      ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
        DBG('Status is pending. Modification of the customer is not allowed');
        P_ERR_CODE   := 'ST-CIF-306';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      ELSE
        DBG('Status is pending. Re-open of the customer is not allowed');
        P_ERR_CODE   := 'ST-CIF-303';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;
    ELSIF P_ACTION_CODE IN
          (CSPKS_REQ_GLOBAL.P_DELETE, CSPKS_REQ_GLOBAL.P_VERSION_DELETE) AND
          L_SNCK_STATUS IN ('P') THEN
      IF L_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                           CSPKS_REQ_GLOBAL.P_MODIFY,
                           CSPKS_REQ_GLOBAL.P_REOPEN) THEN
        DBG('Status is Pending. Allowing the deletion with an over-ride');
        P_ERR_CODE   := 'ST-CIF-304';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;
    ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_AUTH) AND
          L_SNCK_STATUS IN ('R') THEN
      DBG('Status is Rejected. Authorization of the customer is not allowed.');
      IF L_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_REOPEN) THEN
        P_ERR_CODE   := 'ST-CIF-305';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Returning success from Fn_Validate_Snck_Status');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of Fn_Validate_Snck_Status with ' || SQLERRM || 'Trace ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_VALIDATE_SNCK_STATUS;

END STPKS_STDCIF_UTILS_0;
