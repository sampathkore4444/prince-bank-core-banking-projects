select rownum R_no,
       branch,
       parent_branch,
       branch_name,
       status,
       maker,
       ID,
       user_name,
       user_email,
       telephone_number
  FROM (select br2.branch,
               brn.parent_branch,
               brn.branch_name,
               br2.status,
               br2.maker,
               br2.ID,
               br2.user_name,
               br2.user_email,
               br2.telephone_number
          from (SELECT Branch,
                       STATUS,
                       MAKER,
                       ID,
                       usr.user_name,
                       usr.user_email,
                       usr.telephone_number
                  FROM (SELECT a.Branch_Code Branch,
                               b.Module Module,
                               a.Maker_Id Maker,
                               a.Key_Id Ev,
                               a.Function_Id Id,
                               'PENDING UN-AUTH' Status
                          FROM Sttb_Record_Log a, Smtb_Menu b
                         WHERE a.Function_Id = b.Function_Id
                           AND a.Auth_Stat = 'U'
                        UNION
                        SELECT Br Branch,
                               Md Module,
                               Id,
                               Ev,
                               Rn Maker,
                               'PENDING ITEMS - '||(select event_descr from cstb_event where module='CL' and event_code=ev) Status
                          FROM eivw_pending_items
                        UNION
                        SELECT Branch_Code Branch,
                               Module_Id Module,
                               '' Maker,
                               Function_Name Ev,
                               Function_Id Id,
                               'PENDING PROGRAM' Status
                          FROM Eivw_Pending_Programs
                        UNION
                        SELECT Branch_Code Branch,
                               '' Module,
                               User_Id Maker,
                               '' Ev,
                               Til_Id Id,
                               'OPEN TILL' Status
                          FROM Fbtb_Till_Master
                         WHERE User_Id IS NOT NULL
                        UNION
                        SELECT Branchcode Branch,
                               'RT' Module,
                               MAKERID Maker,
                               Xrefid Ev,
                               Functionid Id,
                               'WATING FOR TELLER ATUH - ASSIGNED-' ||
                               Assignedto Status
                          FROM Fbtb_Txnlog_Master f
                         WHERE (Txnstatus = 'IPR' AND stagestatus IN ('WTS') --AND
                               --Postingdate = GLOBAL.application_date
                               )
                        UNION
                        SELECT Branchcode Branch,
                               'RT' Module,
                               MAKERID Maker,
                               Xrefid Ev,
                               Functionid Id,
                               'PENDING TELLER TXN - ASSIGNED-' || Assignedto Status
                          FROM Fbtb_Txnlog_Master f
                         WHERE (Txnstatus = 'IPR' AND Stagestatus IN ('IPR') --AND
                               --Postingdate = GLOBAL.application_date
                               )
                        UNION
                        SELECT Branchcode Branch,
                               'RT' Module,
                               MAKERID Maker,
                               Xrefid Ev,
                               Functionid Id,
                               'WATING FOR MULTI ATUH - ASSIGNED-' ||
                               Assignedto Status
                          FROM Fbtb_Txnlog_Master f
                         WHERE (Txnstatus = 'IPR' AND stagestatus IN ('MTS') --AND
                               --Postingdate = GLOBAL.application_date
                               )
                        UNION
                        SELECT Branchcode Branch,
                               'RT' Module,
                               MAKERID Maker,
                               Xrefid Ev,
                               Functionid Id,
                               'WATING FOR MANUAL ASSIG - ASSIGNED-' ||
                               Assignedto Status
                          FROM Fbtb_Txnlog_Master f
                         WHERE (Txnstatus = 'IPR' AND
                               Stagestatus IN ('WAA', 'WMA') --AND
                               --Postingdate = GLOBAL.application_date
                               )
                        UNION
                        select BRANCH_CODE Branch,
                               'PC' Module,
                               pct.maker_id Maker,
                               pct.contract_ref_no Ev,
                               pct.product_code Id,
                               pct.exception_queue || '-' ||
                               pct.contract_ref_no Status
                          from pctb_contract_master pct
                         where pct.contract_status = 'A'
                           and pct.exception_queue <> '##'
                        UNION
                        select branch,
                               'FT' Module,
                               MAKER_ID Maker,
                               reference_no Ev,
                               'CSSJOBBR' Id,
                               'FT Message Unauthorized' Status
                          from mstb_dly_msg_in msd
                         where msd.auth_status = 'U'
UNION
SELECT BRANCH_CODE,
       'ELCM' module,
       MAKER_ID MAKER,
       'GEDCOLAT',
       collateral_code,
       'COMMITMENT IS ATTACHED TO THE COLLATERAL' STATUS
  FROM GETM_COLLAT
 WHERE COMMITMENT_PRODUCT IS NOT NULL
   AND RECORD_STAT = 'O') PIT,
                       smtb_user USR
                 WHERE PIT.maker = usr.user_id
                 ORDER BY Status, Branch, Id) br2,
               sttm_branch brn
         where br2.branch = brn.branch_code
           AND br2.id not in
               (select FUNCTION_ID
                  from smtb_menu bb
                 where bb.tank_modifications = 'Y' AND FUNCTION_ID <> 'STDCIF')
         ORDER BY br2.branch);     