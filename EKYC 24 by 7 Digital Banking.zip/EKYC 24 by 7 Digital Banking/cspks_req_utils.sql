CREATE OR REPLACE PACKAGE BODY cspks_req_utils AS

  G_KEY_DEF               VARCHAR2(2000);
  G_MODIFY_CHANGED_TO_NEW BOOLEAN := FALSE;

  G_DUAL_AUTH_FOUND BOOLEAN := FALSE;
  G_REQ_SOURCE      VARCHAR2(100);

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS_CLUSTER.PR_SKIP_HANDLER(P_STAGE);
    CSPKS_REQ_UTILS_CUSTOM.PR_SKIP_HANDLER(P_STAGE);
  END PR_SKIP_HANDLER;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := P_MSG;
    L_MSG := 'Cspks_Req_Utils :: ' || L_MSG;
  
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
    
      DEBUG.PR_DEBUG('CS', L_MSG);
    
    END IF;
  
  END DBG;
  PROCEDURE CDBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := P_MSG;
    L_MSG := 'Cspks_Req_Utils :: ' || L_MSG;
    DEBUG.PR_CDEBUG('CS', L_MSG);
  END CDBG;

  PROCEDURE DT(X VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('**',
                   RPAD(X, 20, ' ') ||
                   TO_CHAR(SYSTIMESTAMP, 'HH:MI:SS.FF3'));
  END DT;

  FUNCTION FN_GETPARAM(P_TEXT_CLOB IN CLOB,
                       P_POS       IN NUMBER,
                       P_SEP       IN VARCHAR2 DEFAULT '~') RETURN VARCHAR2 IS
    L_POS      NUMBER;
    R_POS      NUMBER;
    L_TEXT_LEN NUMBER;
  BEGIN
    DBG('In Fn_Getparam.. ');
    L_TEXT_LEN := DBMS_LOB.GETLENGTH(P_TEXT_CLOB);
    IF P_TEXT_CLOB IS NULL THEN
      RETURN(NULL);
    END IF;
    IF P_POS <= 1 THEN
      L_POS := 1;
    ELSE
      L_POS := DBMS_LOB.INSTR(P_TEXT_CLOB, P_SEP, 1, P_POS - 1);
      IF L_POS <> 0 THEN
        L_POS := L_POS + 1;
      ELSE
        RETURN(TO_CLOB('EOPL'));
      END IF;
    END IF;
    IF P_POS <= 1 THEN
      R_POS := DBMS_LOB.INSTR(P_TEXT_CLOB, P_SEP, 1, L_POS);
    ELSE
      R_POS := DBMS_LOB.INSTR(P_TEXT_CLOB, P_SEP, 1, P_POS);
    END IF;
    IF R_POS = 0 THEN
      RETURN DBMS_LOB.SUBSTR(P_TEXT_CLOB, L_TEXT_LEN, L_POS);
    END IF;
    RETURN DBMS_LOB.SUBSTR(P_TEXT_CLOB, R_POS - L_POS, L_POS);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others Of Fn_Getparam.. ');
      RETURN(NULL);
  END FN_GETPARAM;
  FUNCTION FN_GEN_ERROR_MESSAGE(P_CODE   IN VARCHAR2,
                                P_PARAMS IN VARCHAR2,
                                P_MSG    OUT VARCHAR2) RETURN VARCHAR2 IS
    L_CODE        VARCHAR2(32767) := LTRIM(RTRIM(P_CODE, '~'), '~');
    L_PARAMS      VARCHAR2(32767) := LTRIM(RTRIM(P_PARAMS, ';'), ';') || '~';
    L_MSG         VARCHAR2(32767) := NULL;
    L_TYPE        VARCHAR2(32767) := NULL;
    I             INTEGER;
    L_PARAM_TYPES VARCHAR2(32767);
    L_PARAM_TYPE  VARCHAR2(50);
    L_CCY_PARAM   NUMBER;
    L_REL_CCY     VARCHAR2(100);
    L_PARAM       VARCHAR2(32767);
    L_CONF        CHAR(1);
  BEGIN
    DBG('In Fn_Gen_Error_Message..');
  
    CSPKSS_FUNCTION_CACHE_CORE.G_TBL_ERTB_MSGS_DEFN_REC := CSPKSS_FUNCTION_CACHE_CORE.FN_GET_ERTB_MSGS_REC_FRC(L_CODE,
                                                                                                               GLOBAL.LANG);
    IF CSPKSS_FUNCTION_CACHE_CORE.G_TBL_ERTB_MSGS_DEFN_REC.ERR_CODE IS NULL THEN
    
      L_MSG := OVPKSS.FN_FORMMSG(L_CODE, L_PARAMS, GLOBAL.LANG, L_CONF);
      IF L_MSG = 'Missing Error Code' THEN
      
        L_TYPE := 'E';
      
        L_MSG := OVPKSS.FN_FORMMSG('ST-ERR-050',
                                   L_CODE,
                                   GLOBAL.LANG,
                                   L_CONF);
        P_MSG := L_MSG;
        RETURN UPPER(L_TYPE);
      ELSE
        L_TYPE := 'O';
        P_MSG  := L_MSG;
        RETURN UPPER(L_TYPE);
      END IF;
    ELSE
      L_MSG         := CSPKSS_FUNCTION_CACHE_CORE.G_TBL_ERTB_MSGS_DEFN_REC.MESSAGE;
      L_PARAM_TYPES := CSPKSS_FUNCTION_CACHE_CORE.G_TBL_ERTB_MSGS_DEFN_REC.PARAM_TYPES;
      DBG('Got the Err Msg for actual err code..' || L_MSG || '~' ||
          L_PARAM_TYPES);
      L_TYPE := CSPKSS_FUNCTION_CACHE_CORE.G_TBL_ERTB_MSGS_DEFN_REC.TYPE;
    END IF;
    DBG('Err Type and param Types - ' || L_TYPE);
  
    I       := 1;
    L_PARAM := CSPKES_MISC.FN_GETPARAM(L_PARAMS, I, '~');
    WHILE (L_PARAM <> 'EOPL') LOOP
      L_PARAM_TYPE := CSPKES_MISC.FN_GETPARAM(L_PARAM_TYPES, I, '~');
      IF INSTR(L_PARAM_TYPE, 'AMT') > 0 THEN
        L_CCY_PARAM  := SUBSTR(L_PARAM_TYPE, INSTR(L_PARAM_TYPE, 'AMT') + 4);
        L_PARAM_TYPE := 'AMT';
        IF L_CCY_PARAM > 0 THEN
          L_REL_CCY := CSPKES_MISC.FN_GETPARAM(L_PARAMS, L_CCY_PARAM, '~');
          IF NVL(L_REL_CCY, 'EOPL') <> 'EOPL' THEN
            L_PARAM := L_REL_CCY || ':' || L_PARAM;
          END IF;
        END IF;
      END IF;
      IF NVL(L_PARAM_TYPE, 'EOPL') <> 'EOPL' AND
         L_PARAM_TYPE IN ('DT', 'AMT') THEN
        L_MSG := REPLACE(L_MSG,
                         '$' || I,
                         '<' || L_PARAM_TYPE || '>' || L_PARAM || '</' ||
                         L_PARAM_TYPE || '>');
      ELSE
        L_MSG := REPLACE(L_MSG, '$' || I, L_PARAM);
      END IF;
      I       := I + 1;
      L_PARAM := CSPKES_MISC.FN_GETPARAM(L_PARAMS, I, '~');
    END LOOP;
    P_MSG := L_MSG;
    DBG('Returning Success From Fn_Gen_Error_Message..');
    RETURN UPPER(L_TYPE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others Of Fn_Gen_Error_Message..' || SQLERRM);
      RETURN UPPER(L_TYPE);
  END FN_GEN_ERROR_MESSAGE;

  FUNCTION FN_EXISTS(P_TAG  IN VARCHAR2,
                     P_LIST IN VARCHAR2,
                     P_SEP  IN VARCHAR2) RETURN BOOLEAN IS
    L_SEP   VARCHAR2(1) := P_SEP;
    I       NUMBER := 1;
    L_FOUND BOOLEAN := FALSE;
  BEGIN
    DBG('In Fn_Exists..');
    IF L_SEP IS NULL THEN
      L_SEP := '~';
    END IF;
    WHILE CSPKES_MISC.FN_GETPARAM(P_LIST, I, L_SEP) <> 'EOPL' LOOP
      IF NVL(CSPKES_MISC.FN_GETPARAM(P_LIST, I, L_SEP), '*') =
         NVL(P_TAG, '*') THEN
        L_FOUND := TRUE;
      END IF;
      I := I + 1;
    END LOOP;
    RETURN L_FOUND;
  END FN_EXISTS;

  PROCEDURE PR_GET_LABEL(P_FUNCTION_ID IN SMTBS_MENU.FUNCTION_ID%TYPE,
                         P_ITEM        IN VARCHAR2,
                         P_LBL_CODE    OUT VARCHAR2) IS
    L_ITEM     VARCHAR2(100) := P_ITEM;
    L_ITEM1    VARCHAR2(100) := P_ITEM;
    L_LBL_TYPE VARCHAR2(100);
    L_DBT      VARCHAR2(100);
    L_DBC      VARCHAR2(100);
    L_OPTION   VARCHAR2(100);
    L_FIELD_ID VARCHAR2(500);
  BEGIN
    DBG('Fetching Label For :' || P_ITEM);
    IF SUBSTR(P_ITEM, 1, 1) = '@' THEN
      L_ITEM := SUBSTR(L_ITEM, 2, LENGTH(L_ITEM) - 1);
    END IF;
    IF INSTR(L_ITEM, '.') > 0 THEN
      DBG('Field Label');
      L_DBT := SUBSTR(L_ITEM, 1, INSTR(L_ITEM, '.') - 1);
      L_DBC := SUBSTR(L_ITEM, INSTR(L_ITEM, '.') + 1);
    
      IF INSTR(L_DBC, '.') > 0 THEN
        DBG('Option Label...');
        L_LBL_TYPE := 'OPT';
        L_ITEM1    := L_DBC;
        L_DBC      := SUBSTR(L_ITEM1, 1, INSTR(L_ITEM1, '.') - 1);
        L_OPTION   := SUBSTR(L_ITEM1, INSTR(L_ITEM1, '.') + 1);
      ELSE
        L_LBL_TYPE := 'FLD';
      END IF;
    ELSE
      DBG('Other Label..Mostly Block Label');
      L_LBL_TYPE := 'OTH';
      L_DBT      := L_ITEM;
    END IF;
    DBG('Item Details ..:' || L_DBT || '/' || L_DBC || '/' || L_OPTION || '/' ||
        L_LBL_TYPE);
    IF L_LBL_TYPE = 'FLD' THEN
      DBG('Fetching From  Field Labels..');
    
      CSPKSS_FUNCTION_CACHE_CORE.G_TBL_CSTB_FIELD_LABELS_REC := CSPKSS_FUNCTION_CACHE_CORE.FN_GET_CSTB_FIELD_LABELS_FRC(P_FUNCTION_ID,
                                                                                                                        L_DBT,
                                                                                                                        L_DBC);
      IF CSPKSS_FUNCTION_CACHE_CORE.G_TBL_CSTB_FIELD_LABELS_REC.LABEL_CODE IS NULL THEN
        DBG('Failed in obtaining the CSTB Field Labels..so assigning null value..');
        P_LBL_CODE := NULL;
      ELSE
        DBG('CSTB Field Labels rec exists .. ');
        P_LBL_CODE := CSPKSS_FUNCTION_CACHE_CORE.G_TBL_CSTB_FIELD_LABELS_REC.LABEL_CODE;
      END IF;
    
    ELSIF L_LBL_TYPE = 'OPT' THEN
      DBG('Fetching From  Field Labels..');
    
      CSPKSS_FUNCTION_CACHE_CORE.G_TBL_CSTB_FIELD_LABELS_REC := CSPKSS_FUNCTION_CACHE_CORE.FN_GET_CSTB_FIELD_LABELS_FRC(P_FUNCTION_ID,
                                                                                                                        L_DBT,
                                                                                                                        L_DBC);
      IF CSPKSS_FUNCTION_CACHE_CORE.G_TBL_CSTB_FIELD_LABELS_REC.LABEL_CODE IS NULL THEN
        DBG('Failed in obtaining the CSTB Field Labels..so assigning null value..');
        P_LBL_CODE := NULL;
      ELSE
        DBG('CSTB Field Labels rec exists .. ');
        P_LBL_CODE := CSPKSS_FUNCTION_CACHE_CORE.G_TBL_CSTB_FIELD_LABELS_REC.LABEL_CODE;
        L_FIELD_ID := CSPKSS_FUNCTION_CACHE_CORE.G_TBL_CSTB_FIELD_LABELS_REC.FIELD_ID;
      END IF;
    
      DBG('Field Id Is :' || L_FIELD_ID);
      IF L_FIELD_ID IS NOT NULL THEN
        BEGIN
          SELECT LABEL_CODE
            INTO P_LBL_CODE
            FROM CSTB_OTHER_LABELS
           WHERE FUNCTION_ID = P_FUNCTION_ID
             AND FIELD_ID = L_FIELD_ID || '.' || L_OPTION
             AND ROWNUM < 2;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Field Label Not Found In Cstb_Other_Labels..');
          
            P_LBL_CODE := NULL;
          
        END;
      END IF;
    ELSIF L_LBL_TYPE = 'OTH' THEN
      DBG('Fetching From  Other Labels..');
      BEGIN
        SELECT LABEL_CODE
          INTO P_LBL_CODE
          FROM CSTB_OTHER_LABELS
         WHERE FUNCTION_ID = P_FUNCTION_ID
           AND FIELD_ID = L_ITEM
           AND ROWNUM < 2;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Other  Label Not Found in Cstb_Other_Labels..');
        
          P_LBL_CODE := NULL;
        
      END;
    END IF;
    DBG('Returning Success From Pr_Get_Label..' || P_LBL_CODE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Pr_Get_Label..');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_LBL_CODE := NULL;
  END PR_GET_LABEL;
  FUNCTION FN_GET_ITEM_DESC(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                            P_FUNCTION_ID IN SMTBS_MENU.FUNCTION_ID%TYPE,
                            P_ITEM        IN VARCHAR2) RETURN VARCHAR2 IS
    L_SOURCE       COTMS_SOURCE.SOURCE_CODE%TYPE;
    L_FUNCTION_ID  SMTBS_MENU.FUNCTION_ID%TYPE;
    L_DESC         CSTB_ITEM_DESC.ITEM_DESC%TYPE;
    L_LBL_CODE     VARCHAR2(100);
    L_ITEM         VARCHAR2(100) := P_ITEM;
    L_TAG          VARCHAR2(100);
    L_IDENTIFIER_2 VARCHAR2(32767);
    L_IDENTIFIER_3 VARCHAR2(32767);
  BEGIN
    IF SUBSTR(P_ITEM, 1, 1) = '@' THEN
      L_ITEM := SUBSTR(L_ITEM, 2, LENGTH(L_ITEM) - 1);
    END IF;
    PR_GET_LABEL(P_FUNCTION_ID, P_ITEM, L_LBL_CODE);
  
    CSPKSS_FUNCTION_CACHE_CORE.G_TBL_CSTB_LABELS_REC := CSPKSS_FUNCTION_CACHE_CORE.FN_GET_CSTB_LABELS_FRC(GLOBAL.LANG,
                                                                                                          L_LBL_CODE);
    IF CSPKSS_FUNCTION_CACHE_CORE.G_TBL_CSTB_LABELS_REC.LABEL_DESCRIPTION IS NULL THEN
      DBG('Desc Not Found for :' || L_SOURCE || ':' || L_FUNCTION_ID);
      L_DESC := NULL;
    ELSE
      L_DESC := CSPKSS_FUNCTION_CACHE_CORE.G_TBL_CSTB_LABELS_REC.LABEL_DESCRIPTION;
      DBG('l_desc ::' || L_DESC);
    END IF;
  
    IF L_LBL_CODE IS NULL OR L_DESC IS NULL THEN
      IF INSTR(L_ITEM, '.') > 0 THEN
        L_TAG := SUBSTR(L_ITEM, INSTR(L_ITEM, '.') + 1, LENGTH(L_ITEM));
      ELSE
        L_TAG := L_ITEM;
      END IF;
    
      IF INSTR(L_TAG, '_') > 0 THEN
        L_IDENTIFIER_2 := UPPER(NVL(SUBSTR(L_TAG, 3, 3), '*'));
        L_IDENTIFIER_3 := UPPER(NVL(SUBSTR(L_TAG, 3, 4), '*'));
        IF L_IDENTIFIER_2 IN ('TB_', 'TM_', 'TW_', 'TU_', 'VW_') OR
           L_IDENTIFIER_3 IN ('TBS_', 'TMS_', 'TWS_', 'TUS_', 'VWS_') THEN
        
          L_TAG := ' ';
        END IF;
      
      END IF;
    
      L_DESC := INITCAP(REPLACE(L_TAG, '_', ' '));
    
    END IF;
    RETURN L_DESC;
  END FN_GET_ITEM_DESC;

  PROCEDURE PR_LOG_ERROR(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                         P_FUNCTION_ID IN SMTBS_MENU.FUNCTION_ID%TYPE,
                         P_ERR_CODE    IN VARCHAR2,
                         P_ERR_PARAMS  IN VARCHAR2) IS
  
    L_PARAMS VARCHAR2(32767);
    L_PRM    VARCHAR2(5000);
    I        NUMBER := 1;
  
    L_DESC VARCHAR2(1000);
  BEGIN
    DBG('In Pr_Log_Error :' || P_SOURCE || ' /' || P_ERR_CODE || '/' ||
        P_ERR_PARAMS || '/' || P_FUNCTION_ID);
    IF P_ERR_CODE IS NULL THEN
      RETURN;
    END IF;
    WHILE CSPKES_MISC.FN_GETPARAM(P_ERR_PARAMS, I, '~') <> 'EOPL' LOOP
      L_PRM := CSPKES_MISC.FN_GETPARAM(P_ERR_PARAMS, I, '~');
      IF SUBSTR(L_PRM, 1, 1) = '@' THEN
        L_DESC := FN_GET_ITEM_DESC(P_SOURCE, P_FUNCTION_ID, UPPER(L_PRM));
        L_PRM  := NVL(L_DESC, L_PRM);
        L_PRM  := L_DESC;
      END IF;
      IF L_PARAMS IS NOT NULL THEN
        L_PARAMS := L_PARAMS || '~' || L_PRM;
      ELSE
        L_PARAMS := L_PRM;
      END IF;
      I := I + 1;
    END LOOP;
    OVPKS.PR_APPENDTBL(P_ERR_CODE, L_PARAMS);
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLERRM);
  END PR_LOG_ERROR;

  FUNCTION FN_GET_TABLE_NAME(P_TABLE IN VARCHAR2) RETURN VARCHAR2 IS
    L_COUNT INTEGER;
    L_NAME  VARCHAR2(300) := UPPER(TRIM(P_TABLE));
  BEGIN
    DBG('In Fn_Get_Table_Name..');
    IF L_NAME IS NOT NULL THEN
      IF INSTR(L_NAME, '__') > 0 THEN
        L_NAME := SUBSTR(P_TABLE, 1, INSTR(P_TABLE, '__') - 1);
      END IF;
    
      CSPKSS_FUNCTION_CACHE_CORE.G_TBL_USER_SYNONYMS := CSPKSS_FUNCTION_CACHE_CORE.FN_GET_USER_SYNONMYS_FRC(L_NAME);
      IF CSPKSS_FUNCTION_CACHE_CORE.G_TBL_USER_SYNONYMS.TABLE_NAME IS NOT NULL THEN
      
        L_NAME := CSPKSS_FUNCTION_CACHE_CORE.G_TBL_USER_SYNONYMS.TABLE_NAME;
      END IF;
      DBG('Table name is - ' || L_NAME);
    
    END IF;
    RETURN L_NAME;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Fn_Get_Table_Name..');
      DBG(SQLERRM);
  END FN_GET_TABLE_NAME;

  PROCEDURE PR_FILTER_ERR_TYPE(P_TYPE IN ERTB_MSGS.TYPE%TYPE) IS
    L_ERR_TBL      OVPKSS.TBL_ERROR;
    I              NUMBER := 0;
    L_TYPE         VARCHAR2(1);
    L_ERRORS_FOUND BOOLEAN := FALSE;
  BEGIN
    DBG('In Pr_Filter_Err_Type..');
    IF OVPKSS.GL_TBLERROR.COUNT > 0 THEN
      FOR L_INDEX IN OVPKSS.GL_TBLERROR.FIRST .. OVPKSS.GL_TBLERROR.LAST LOOP
        L_TYPE := NVL(OVPKSS.FN_GETTYPE(OVPKSS.GL_TBLERROR(L_INDEX).ERR_CODE),
                      'X');
        IF L_TYPE = 'E' THEN
          L_ERRORS_FOUND := TRUE;
        END IF;
        IF L_TYPE <> NVL(P_TYPE, 'O') THEN
          DBG('Assigning Err codes To Err Table..' || L_TYPE);
          I := I + 1;
          L_ERR_TBL(I).ERR_CODE := OVPKSS.GL_TBLERROR(L_INDEX).ERR_CODE;
          L_ERR_TBL(I).PARAMS := OVPKSS.GL_TBLERROR(L_INDEX).PARAMS;
          DBG('No of Attacheed Errs..' || I);
        END IF;
      END LOOP;
      OVPKSS.GL_TBLERROR.DELETE;
      OVPKSS.GL_TBLERROR := L_ERR_TBL;
    END IF;
  END PR_FILTER_ERR_TYPE;

  PROCEDURE PR_GET_FINAL_ERR_CODE(P_FUNCTION_ID   IN VARCHAR2,
                                  P_ACTION_CODE   IN VARCHAR2,
                                  P_POST_UPL_STAT IN VARCHAR2,
                                  P_ERR_CODE      IN OUT VARCHAR2,
                                  P_ERR_PARAMS    IN OUT VARCHAR2) IS
    L_FUNCTION_TYPE VARCHAR2(10);
  BEGIN
    DBG('In  Pr_Get_Final_Err_Code..:' || P_FUNCTION_ID || '/' ||
        P_ACTION_CODE || '/' || P_POST_UPL_STAT || '/' || P_ERR_CODE);
  
    P_ERR_CODE   := NULL;
    P_ERR_PARAMS := NULL;
  
    PR_SKIP_HANDLER('PRE_GET_FINAL_ERR_CODE');
    IF NOT CSPKS_REQ_UTILS.FN_SKIP_CUSTOM THEN
      CSPKS_REQ_UTILS_CUSTOM.PR_PRE_GET_FINAL_ERR_CODE(P_FUNCTION_ID,
                                                       P_ACTION_CODE,
                                                       P_POST_UPL_STAT,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS);
    END IF;
  
    IF NOT CSPKS_REQ_UTILS.FN_SKIP_CLUSTER THEN
      CSPKS_REQ_UTILS_CLUSTER.PR_PRE_GET_FINAL_ERR_CODE(P_FUNCTION_ID,
                                                        P_ACTION_CODE,
                                                        P_POST_UPL_STAT,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS);
    END IF;
    IF NOT CSPKS_REQ_UTILS.FN_SKIP_KERNEL THEN
      IF CSPKS_REQ_GLOBAL.FN_GET_LOG_RESULT_ERROR_CODE THEN
      
        IF P_FUNCTION_ID IS NOT NULL THEN
        
          IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
            DBG('Failed in FRC bec of - ' || P_ERR_CODE);
            DBG('Exception was not raised previously..instead function type was assigned as M..dng the same..');
            L_FUNCTION_TYPE := 'M';
            P_ERR_CODE      := NULL;
            P_ERR_PARAMS    := NULL;
          ELSE
            DBG('Returned success from FRC..');
            L_FUNCTION_TYPE := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.TYPE_STRING;
          END IF;
          DBG('Value of l_Function_Type is - ' || L_FUNCTION_TYPE);
        
        ELSE
          L_FUNCTION_TYPE := 'M';
        END IF;
        IF L_FUNCTION_TYPE = 'M' THEN
          IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
            IF (P_POST_UPL_STAT = 'U') THEN
              P_ERR_CODE := 'ST-SAVE-001';
            ELSIF P_POST_UPL_STAT = 'A' THEN
              P_ERR_CODE := 'ST-SAVE-002';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-003';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-004';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
            IF P_POST_UPL_STAT = 'U' THEN
              P_ERR_CODE := 'ST-SAVE-005';
            ELSIF P_POST_UPL_STAT = 'A' THEN
              P_ERR_CODE := 'ST-SAVE-006';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-007';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-008';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
            IF P_POST_UPL_STAT = 'U' THEN
              P_ERR_CODE := 'ST-SAVE-009';
            ELSIF P_POST_UPL_STAT = 'A' THEN
              P_ERR_CODE := 'ST-SAVE-010';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-011';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-012';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
            IF P_POST_UPL_STAT = 'U' THEN
              P_ERR_CODE := 'ST-SAVE-013';
            ELSIF P_POST_UPL_STAT = 'A' THEN
              P_ERR_CODE := 'ST-SAVE-014';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-015';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-016';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
            IF P_POST_UPL_STAT IN ('A', 'U') THEN
              P_ERR_CODE := 'ST-SAVE-017';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-018';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-019';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_VERSION_DELETE THEN
            IF P_POST_UPL_STAT IN ('A', 'U') THEN
              P_ERR_CODE := 'ST-SAVE-091';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-092';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-093';
            END IF;
          
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
            IF P_POST_UPL_STAT IN ('A', 'U') THEN
              P_ERR_CODE := 'ST-SAVE-020';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-021';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-022';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN
            IF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-024';
            ELSE
              P_ERR_CODE := 'ST-SAVE-023';
            END IF;
          END IF;
        ELSE
          DBG('Non Maintenance Function..');
          IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
            IF P_POST_UPL_STAT = 'U' THEN
              P_ERR_CODE := 'ST-SAVE-051';
            ELSIF P_POST_UPL_STAT = 'A' THEN
              P_ERR_CODE := 'ST-SAVE-052';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-053';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-054';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
            IF P_POST_UPL_STAT = 'U' THEN
              P_ERR_CODE := 'ST-SAVE-055';
            ELSIF P_POST_UPL_STAT = 'A' THEN
              P_ERR_CODE := 'ST-SAVE-056';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-057';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-058';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
            IF P_POST_UPL_STAT = 'U' THEN
              P_ERR_CODE := 'ST-SAVE-059';
            ELSIF P_POST_UPL_STAT = 'A' THEN
              P_ERR_CODE := 'ST-SAVE-060';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-061';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-062';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
            IF P_POST_UPL_STAT = 'U' THEN
              P_ERR_CODE := 'ST-SAVE-063';
            ELSIF P_POST_UPL_STAT = 'A' THEN
              P_ERR_CODE := 'ST-SAVE-064';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-065';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-066';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
            IF P_POST_UPL_STAT IN ('A', 'U') THEN
              P_ERR_CODE := 'ST-SAVE-067';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-068';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-069';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
            IF P_POST_UPL_STAT IN ('A', 'U') THEN
              P_ERR_CODE := 'ST-SAVE-070';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-071';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-072';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN
            IF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-074';
            ELSE
              P_ERR_CODE := 'ST-SAVE-073';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REVERSE THEN
            IF P_POST_UPL_STAT = 'U' THEN
              P_ERR_CODE := 'ST-SAVE-075';
            ELSIF P_POST_UPL_STAT = 'A' THEN
              P_ERR_CODE := 'ST-SAVE-076';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-077';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-078';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_ROLLOVER THEN
            IF P_POST_UPL_STAT = 'U' THEN
              P_ERR_CODE := 'ST-SAVE-079';
            ELSIF P_POST_UPL_STAT = 'A' THEN
              P_ERR_CODE := 'ST-SAVE-080';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-081';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-082';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CONFIRM THEN
            IF P_POST_UPL_STAT = 'U' THEN
              P_ERR_CODE := 'ST-SAVE-083';
            ELSIF P_POST_UPL_STAT = 'A' THEN
              P_ERR_CODE := 'ST-SAVE-084';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-085';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-086';
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_LIQUIDATE THEN
            IF P_POST_UPL_STAT = 'U' THEN
              P_ERR_CODE := 'ST-SAVE-087';
            ELSIF P_POST_UPL_STAT = 'A' THEN
              P_ERR_CODE := 'ST-SAVE-088';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-089';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-090';
            END IF;
          
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_HOLD THEN
            IF P_POST_UPL_STAT IN ('A', 'U', 'S') THEN
              P_ERR_CODE := 'ST-SAVE-096';
            ELSIF P_POST_UPL_STAT = 'O' THEN
              P_ERR_CODE := 'ST-SAVE-097';
            ELSIF P_POST_UPL_STAT = 'F' THEN
              P_ERR_CODE := 'ST-SAVE-098';
            END IF;
          
          END IF;
        END IF;
      
        IF P_ERR_CODE IS NULL THEN
          DBG('action code::Function id' || P_ACTION_CODE || ':' ||
              P_FUNCTION_ID);
          IF P_POST_UPL_STAT IN ('A', 'U', 'S') THEN
            IF P_FUNCTION_ID <> 'FXDTRONL' AND P_ACTION_CODE <> 'LINKDEAL' THEN
              P_ERR_CODE := 'ST-SAVE-027';
            END IF;
          ELSIF P_POST_UPL_STAT = 'O' THEN
            P_ERR_CODE := 'ST-SAVE-029';
          
          ELSIF P_POST_UPL_STAT = 'H' THEN
            P_ERR_CODE := 'PC-00404';
          
          ELSE
            P_ERR_CODE := 'ST-SAVE-028';
          END IF;
        
        END IF;
      ELSE
        DBG('Result Error Message Not Required...');
        DBG('p_Err_Code 111' || P_ERR_CODE);
      END IF;
      DBG('p_Err_Code 111333' || P_ERR_CODE);
    END IF;
    PR_SKIP_HANDLER('POST_Pr_Get_Final_Err_Code');
    IF NOT CSPKS_REQ_UTILS.FN_SKIP_CLUSTER THEN
      CSPKS_REQ_UTILS_CLUSTER.PR_POST_GET_FINAL_ERR_CODE(P_FUNCTION_ID,
                                                         P_ACTION_CODE,
                                                         P_POST_UPL_STAT,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS);
    END IF;
    IF NOT CSPKS_REQ_UTILS.FN_SKIP_CUSTOM THEN
      CSPKS_REQ_UTILS_CUSTOM.PR_POST_GET_FINAL_ERR_CODE(P_FUNCTION_ID,
                                                        P_ACTION_CODE,
                                                        P_POST_UPL_STAT,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS);
    END IF;
  END PR_GET_FINAL_ERR_CODE;

  PROCEDURE PR_GET_MAINT_ERR(P_ACTION_CODE   IN VARCHAR2,
                             P_POST_UPL_STAT IN VARCHAR2,
                             P_ERR_CODE      IN OUT VARCHAR2,
                             P_ERR_PARAMS    IN OUT VARCHAR2) IS
  BEGIN
    DBG('In  Pr_Get_Maint_Err..:' || P_ACTION_CODE || '/' ||
        P_POST_UPL_STAT);
    P_ERR_CODE   := NULL;
    P_ERR_PARAMS := NULL;
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
      IF P_POST_UPL_STAT = 'U' THEN
        P_ERR_CODE := 'ST-SAVE-001';
      ELSIF P_POST_UPL_STAT = 'A' THEN
        P_ERR_CODE := 'ST-SAVE-002';
      ELSIF P_POST_UPL_STAT = 'O' THEN
        P_ERR_CODE := 'ST-SAVE-003';
      ELSIF P_POST_UPL_STAT = 'F' THEN
        P_ERR_CODE := 'ST-SAVE-004';
      END IF;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      IF P_POST_UPL_STAT = 'U' THEN
        P_ERR_CODE := 'ST-SAVE-005';
      ELSIF P_POST_UPL_STAT = 'A' THEN
        P_ERR_CODE := 'ST-SAVE-006';
      ELSIF P_POST_UPL_STAT = 'O' THEN
        P_ERR_CODE := 'ST-SAVE-007';
      ELSIF P_POST_UPL_STAT = 'F' THEN
        P_ERR_CODE := 'ST-SAVE-008';
      END IF;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
      IF P_POST_UPL_STAT = 'U' THEN
        P_ERR_CODE := 'ST-SAVE-009';
      ELSIF P_POST_UPL_STAT = 'A' THEN
        P_ERR_CODE := 'ST-SAVE-010';
      ELSIF P_POST_UPL_STAT = 'O' THEN
        P_ERR_CODE := 'ST-SAVE-011';
      ELSIF P_POST_UPL_STAT = 'F' THEN
        P_ERR_CODE := 'ST-SAVE-012';
      END IF;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
      IF P_POST_UPL_STAT = 'U' THEN
        P_ERR_CODE := 'ST-SAVE-013';
      ELSIF P_POST_UPL_STAT = 'A' THEN
        P_ERR_CODE := 'ST-SAVE-014';
      ELSIF P_POST_UPL_STAT = 'O' THEN
        P_ERR_CODE := 'ST-SAVE-015';
      ELSIF P_POST_UPL_STAT = 'F' THEN
        P_ERR_CODE := 'ST-SAVE-016';
      END IF;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
      IF P_POST_UPL_STAT IN ('A', 'U') THEN
        P_ERR_CODE := 'ST-SAVE-017';
      ELSIF P_POST_UPL_STAT = 'O' THEN
        P_ERR_CODE := 'ST-SAVE-018';
      ELSIF P_POST_UPL_STAT = 'F' THEN
        P_ERR_CODE := 'ST-SAVE-019';
      END IF;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      IF P_POST_UPL_STAT IN ('A', 'U') THEN
        P_ERR_CODE := 'ST-SAVE-020';
      ELSIF P_POST_UPL_STAT = 'O' THEN
        P_ERR_CODE := 'ST-SAVE-021';
      ELSIF P_POST_UPL_STAT = 'F' THEN
        P_ERR_CODE := 'ST-SAVE-022';
      END IF;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN
      IF P_POST_UPL_STAT = 'F' THEN
        P_ERR_CODE := 'ST-SAVE-024';
      ELSE
        P_ERR_CODE := 'ST-SAVE-023';
      END IF;
    END IF;
  
    IF P_ERR_CODE IS NULL THEN
      IF P_POST_UPL_STAT IN ('A', 'U') THEN
        P_ERR_CODE := 'ST-SAVE-027';
      ELSIF P_POST_UPL_STAT = 'O' THEN
        P_ERR_CODE := 'ST-SAVE-029';
      ELSE
        P_ERR_CODE := 'ST-SAVE-028';
      END IF;
    END IF;
  
  END PR_GET_MAINT_ERR;

  FUNCTION FN_SCAN_ERROR_LIST RETURN VARCHAR2 IS
  
    L_HALT_ON_EXCEPTION EXCEPTION;
    L_ERROR_CODE       VARCHAR2(1000) := NULL;
    L_ERROR_PARAMETER  VARCHAR2(1000) := NULL;
    L_ERROR_CODE_TYPE  ERTBS_MSGS.TYPE%TYPE;
    L_FINAL_ERROR_TYPE VARCHAR2(1) := 'I';
  BEGIN
    DBG('In Fn_Scan_Error_List..:' || OVPKSS.GL_TBLERROR.COUNT);
    G_DUAL_AUTH_FOUND := FALSE;
    IF (OVPKSS.GL_TBLERROR.COUNT > 0) THEN
      FOR OVERRIDE_COUNT IN OVPKSS.GL_TBLERROR.FIRST .. OVPKSS.GL_TBLERROR.LAST LOOP
        L_ERROR_CODE      := OVPKSS.GL_TBLERROR(OVERRIDE_COUNT).ERR_CODE;
        L_ERROR_CODE_TYPE := OVPKSS.FN_GETTYPE(L_ERROR_CODE);
        IF (L_ERROR_CODE_TYPE IN ('O', 'A', 'D')) THEN
          L_FINAL_ERROR_TYPE := 'O';
        
          IF L_ERROR_CODE_TYPE = 'D' THEN
            G_DUAL_AUTH_FOUND := TRUE;
          END IF;
        
        ELSIF (L_ERROR_CODE_TYPE IN ('E', 'X')) THEN
          RAISE L_HALT_ON_EXCEPTION;
        END IF;
      END LOOP;
    END IF;
    DBG('Returning Success From  Fn_Scan_Error_List..');
    RETURN L_FINAL_ERROR_TYPE;
  EXCEPTION
    WHEN L_HALT_ON_EXCEPTION THEN
      L_FINAL_ERROR_TYPE := 'E';
      RETURN L_FINAL_ERROR_TYPE;
    WHEN OTHERS THEN
      DBG('In  When Others Of Fn_Scan_Error_List..');
      DBG(SQLCODE || SQLERRM);
      RETURN 'E';
  END FN_SCAN_ERROR_LIST;

  FUNCTION FN_GET_REC_KEY(P_FUNCTION_ID  IN VARCHAR2,
                          P_MASTER_NODE  IN VARCHAR2,
                          P_PK_COLS      IN VARCHAR2,
                          P_PK_VALS      IN VARCHAR2,
                          P_REC_KEY      IN OUT VARCHAR2,
                          P_ERROR_CODE   IN OUT VARCHAR2,
                          P_ERROR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('In  Fn_Get_Rec_Key..');
  
    P_REC_KEY := P_MASTER_NODE || '~' || RTRIM(P_PK_VALS, '~') || '~';
    DBG('Returning Success From Fn_Get_Rec_Key..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Get_Rec_Key..');
      DBG(SQLERRM);
      P_ERROR_CODE   := 'ST-OTHR-001';
      P_ERROR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_REC_KEY;

  FUNCTION FN_PROCESS_OVDS(P_MULTI_TRIP_REF_NO IN VARCHAR2,
                           P_REQUEST_NO        IN NUMBER,
                           P_ERR_CODE          IN OUT VARCHAR2,
                           P_ERR_PARAMS        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_PREV_COUNT1       NUMBER;
    L_PREV_COUNT2       NUMBER;
    L_PREV_COUNT        NUMBER;
    L_CURR_COUNT        NUMBER;
    L_OVD_FOUND         BOOLEAN := FALSE;
    L_OVD_MATCHED       BOOLEAN := FALSE;
    L_TYPE              ERTB_MSGS.TYPE%TYPE;
    L_COMP_STR          VARCHAR2(32767);
    L_PARAMS_TO_MATCH   VARCHAR2(32767);
    L_PARAMS_TO_COMP    VARCHAR2(32767);
    L_IMPROVED          BOOLEAN;
    L_MATCHED           BOOLEAN;
    L_MATCHED_CODE      ERTB_MSGS.ERR_CODE%TYPE;
    L_MATCHED_PARAMS    VARCHAR2(32767);
    L_MATCH             VARCHAR2(10);
    L_PREV              VARCHAR2(32767);
    L_CURR              VARCHAR2(32767);
    L_COMP              VARCHAR2(32767);
    J                   NUMBER;
    L_DIR               VARCHAR2(10);
    L_PARAM_NO          VARCHAR2(10);
    L_DIRECTION_OF_COMP VARCHAR2(20);
    L_REQUEST_NO        NUMBER := 1;
  
    CURSOR C_PREV_OVDS(P_MSG_ID VARCHAR2, P_REQ_SEQ_NO NUMBER) IS
      SELECT ERROR_CODE, ERROR_PARAM
        FROM CSTB_REQUEST_OVD_DETAILS A
       WHERE MSG_ID = P_MSG_ID
         AND REQ_SEQ_NO = P_REQ_SEQ_NO;
  BEGIN
    DBG('In Fn_Process_Ovds..:' || P_MULTI_TRIP_REF_NO || '/' ||
        P_REQUEST_NO);
    L_REQUEST_NO := NVL(P_REQUEST_NO, 1);
    SELECT COUNT(*)
      INTO L_PREV_COUNT
      FROM CSTB_REQUEST_OVD_DETAILS A
     WHERE MSG_ID = P_MULTI_TRIP_REF_NO
       AND REQ_SEQ_NO = L_REQUEST_NO;
    L_CURR_COUNT := OVPKSS.GL_TBLERROR.COUNT;
    DBG('Error Counts :' || L_PREV_COUNT || '/' || L_CURR_COUNT);
    IF L_CURR_COUNT > 0 AND L_CURR_COUNT > L_PREV_COUNT THEN
      RETURN FALSE;
    ELSE
      DBG('Getting Into Comparision..:' || P_MULTI_TRIP_REF_NO);
      IF L_CURR_COUNT > 0 THEN
        FOR I IN OVPKSS.GL_TBLERROR.FIRST .. OVPKSS.GL_TBLERROR.LAST LOOP
        
          IF NOT
              CSPKSS_FUNCTION_CACHE_CORE.FN_GET_ERTB_MSGS_REC_WRP(OVPKSS.GL_TBLERROR(I)
                                                                  .ERR_CODE,
                                                                  GLOBAL.LANG,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
            DBG('Failed in the FRC bec of - ' || P_ERR_CODE);
            DBG('Exception is not raised instead handled by assigning type and comp_str as O and null resp..');
            L_TYPE       := 'O';
            L_COMP_STR   := NULL;
            P_ERR_CODE   := NULL;
            P_ERR_PARAMS := NULL;
          ELSE
            DBG('Returned success from Fn_Get_ertb_msgs_Rec_Wrp..');
            L_TYPE              := CSPKSS_FUNCTION_CACHE_CORE.G_TBL_ERTB_MSGS_DEFN_REC.TYPE;
            L_PARAMS_TO_MATCH   := CSPKSS_FUNCTION_CACHE_CORE.G_TBL_ERTB_MSGS_DEFN_REC.PARAMS_TO_MATCH;
            L_PARAMS_TO_COMP    := CSPKSS_FUNCTION_CACHE_CORE.G_TBL_ERTB_MSGS_DEFN_REC.PARAMS_TO_COMPARE;
            L_DIRECTION_OF_COMP := CSPKSS_FUNCTION_CACHE_CORE.G_TBL_ERTB_MSGS_DEFN_REC.DIRECTION_OF_COMPARISION;
          END IF;
        
          IF L_TYPE NOT IN ('E', 'I') THEN
            IF L_PARAMS_TO_COMP IS NULL THEN
              L_OVD_FOUND := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR OVD IN C_PREV_OVDS(P_MULTI_TRIP_REF_NO, L_REQUEST_NO) LOOP
                  DBG('Error Codes  :' || OVD.ERROR_CODE || '/' || OVPKSS.GL_TBLERROR(I)
                      .ERR_CODE);
                  DBG('Error Params :' || OVD.ERROR_PARAM || '/' || OVPKSS.GL_TBLERROR(I)
                      .PARAMS);
                  IF (OVD.ERROR_CODE = OVPKSS.GL_TBLERROR(I).ERR_CODE) AND
                     (NVL(OVD.ERROR_PARAM, '*') =
                     NVL(OVPKSS.GL_TBLERROR(I).PARAMS, '*')) THEN
                    L_OVD_FOUND := TRUE;
                  END IF;
                END LOOP;
                IF NOT L_OVD_FOUND THEN
                  DBG('New Override..');
                  RETURN FALSE;
                END IF;
              END IF;
            ELSE
              DBG('This Is a Case Of Override Amount Comparision..');
              DBG('Checking for :' || OVPKSS.GL_TBLERROR(I).ERR_CODE || ':' || OVPKSS.GL_TBLERROR(I)
                  .PARAMS);
              DBG('Params To Match :' || L_PARAMS_TO_MATCH ||
                  'And To Comp :' || L_PARAMS_TO_COMP);
              L_MATCHED   := FALSE;
              L_OVD_FOUND := FALSE;
              BEGIN
                FOR OVD IN C_PREV_OVDS(P_MULTI_TRIP_REF_NO, L_REQUEST_NO) LOOP
                  DBG('Old Override And Params :' || OVD.ERROR_CODE || ':' ||
                      OVD.ERROR_PARAM);
                  IF (OVD.ERROR_CODE = OVPKSS.GL_TBLERROR(I).ERR_CODE) THEN
                    L_MATCHED := TRUE;
                    J         := 1;
                    L_MATCH   := CSPKES_MISC.FN_GETPARAM(L_PARAMS_TO_MATCH,
                                                         J,
                                                         '~');
                    IF L_MATCH <> 'EOPL' THEN
                      WHILE (L_MATCH <> 'EOPL') LOOP
                        L_PREV := CSPKES_MISC.FN_GETPARAM(OVD.ERROR_PARAM,
                                                          L_MATCH,
                                                          '~');
                        L_CURR := CSPKES_MISC.FN_GETPARAM(OVPKSS.GL_TBLERROR(I)
                                                          .PARAMS,
                                                          L_MATCH,
                                                          '~');
                        IF L_PREV <> L_CURR THEN
                          L_MATCHED := FALSE;
                          EXIT;
                        END IF;
                        J       := J + 1;
                        L_MATCH := CSPKES_MISC.FN_GETPARAM(L_PARAMS_TO_MATCH,
                                                           J,
                                                           ';');
                      END LOOP;
                    ELSE
                      L_MATCHED := TRUE;
                    END IF;
                    L_OVD_FOUND := TRUE;
                    IF L_MATCHED THEN
                      L_MATCHED_CODE   := OVD.ERROR_CODE;
                      L_MATCHED_PARAMS := OVD.ERROR_PARAM;
                      EXIT;
                    END IF;
                  END IF;
                END LOOP;
                IF L_OVD_FOUND THEN
                  DBG('Override Found..');
                  IF L_MATCHED THEN
                    DBG('Override Matched..');
                    DBG('Current Error Code And Parameters Are :' || OVPKSS.GL_TBLERROR(I)
                        .ERR_CODE || '/' || OVPKSS.GL_TBLERROR(I).PARAMS);
                    DBG('Matched Error Code And Parameters Are :' ||
                        L_MATCHED_CODE || '/' || L_MATCHED_PARAMS);
                    J          := 1;
                    L_PARAM_NO := CSPKES_MISC.FN_GETPARAM(L_PARAMS_TO_COMP,
                                                          J,
                                                          '~');
                    IF L_PARAM_NO <> 'EOPL' THEN
                      WHILE (L_PARAM_NO <> 'EOPL') LOOP
                        L_DIR := CSPKES_MISC.FN_GETPARAM(L_DIRECTION_OF_COMP,
                                                         J,
                                                         '~');
                      
                        L_PREV := NVL(CSPKES_MISC.FN_GETPARAM(L_MATCHED_PARAMS,
                                                              L_PARAM_NO,
                                                              '~'),
                                      0);
                        L_CURR := NVL(CSPKES_MISC.FN_GETPARAM(OVPKSS.GL_TBLERROR(I)
                                                              .PARAMS,
                                                              L_PARAM_NO,
                                                              '~'),
                                      0);
                        DBG('Prev/Curr :' || L_PREV || '/' || L_CURR || '/' ||
                            L_DIR);
                      
                        IF L_DIR = 'D' THEN
                          DBG('Decrease is Better..');
                          IF TO_NUMBER(L_CURR) > TO_NUMBER(L_PREV) THEN
                            DBG('Current Value Is Greater Than The Previous Value..');
                            RETURN FALSE;
                          END IF;
                        ELSIF L_DIR = 'I' THEN
                          DBG('Increase is Better..');
                          IF TO_NUMBER(L_CURR) < TO_NUMBER(L_PREV) THEN
                            DBG('Current Value Is Less Than The Previous Value..');
                            RETURN FALSE;
                          END IF;
                        END IF;
                        J          := J + 1;
                        L_PARAM_NO := CSPKES_MISC.FN_GETPARAM(L_PARAMS_TO_COMP,
                                                              J,
                                                              '~');
                      END LOOP;
                    ELSE
                      DBG('No Comparision Of Overrides..');
                    END IF;
                  
                  ELSE
                    DBG('No Matching Error Code Found For ' || OVPKSS.GL_TBLERROR(I)
                        .ERR_CODE || '/' || OVPKSS.GL_TBLERROR(I).PARAMS);
                    RETURN FALSE;
                  END IF;
                ELSE
                  DBG('New Override ' || OVPKSS.GL_TBLERROR(I).ERR_CODE || '/' || OVPKSS.GL_TBLERROR(I)
                      .PARAMS);
                END IF;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Incorrect Error Setup..');
                  RETURN FALSE;
              END;
            END IF;
          END IF;
        END LOOP;
      END IF;
    END IF;
    DBG('Retrning Success From Fn_Process_Ovds..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of Fn_Process_Ovds ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE := 'ST-OTHR-001';
      RETURN FALSE;
  END FN_PROCESS_OVDS;

  FUNCTION FN_GET_AUTO_AUTH_STATUS(P_SOURCE            IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                   P_MODULE            IN COTMS_SOURCE_PREF.MODULE_CODE%TYPE,
                                   P_FUNCTION_ID       IN SMTBS_MENU.FUNCTION_ID%TYPE,
                                   P_ACTION_CODE       IN VARCHAR2,
                                   P_PREV_AUTH_STAT    IN VARCHAR2,
                                   P_MULTI_TRIP_REF_NO IN VARCHAR2,
                                   P_REQUEST_NO        IN NUMBER,
                                   P_POST_UPL_STAT     IN OUT VARCHAR2,
                                   P_ERROR_CODE        IN OUT VARCHAR2,
                                   P_ERROR_PARAMS      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_WHAT_TO_DO VARCHAR2(1);
    L_AUTH_STAT  VARCHAR2(1);
    L_AUTO_AUTH  VARCHAR2(1);
  
    L_ULT_TYPE      VARCHAR2(1);
    L_FUNCTION_TYPE VARCHAR2(10) := 'M';
    L_MODULE        VARCHAR2(10);
    L_UI_NAME       VARCHAR2(20);
  
    L_ON_OVERRIDE     VARCHAR2(1);
    L_ON_ERROR        VARCHAR2(1);
    L_UPLOADED_STATUS VARCHAR2(1);
  
    L_SQL     VARCHAR2(32767);
    L_MODULE1 VARCHAR2(10);
  
  BEGIN
    DBG('In  Fn_Get_Auto_Auth_Status..');
  
    L_ULT_TYPE := FN_SCAN_ERROR_LIST;
  
    IF P_SOURCE NOT IN ('FLEXCUBE', 'FLEXNOTIF') THEN
      DBG('Get Source Parameters..');
    
      IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                       P_ERROR_CODE,
                                                       P_ERROR_PARAMS) THEN
        DBG('Failed in the Smtb_menu FRC ebc of  -' || P_ERROR_CODE);
        DBG('Exception is not raised..instead handled..so dng the same.. by assignin values for module and uiname..');
        L_MODULE       := SUBSTR(P_FUNCTION_ID, 1, 2);
        L_UI_NAME      := P_FUNCTION_ID;
        P_ERROR_CODE   := NULL;
        P_ERROR_PARAMS := NULL;
      ELSE
        DBG('Returned success from the FRC function..');
        L_MODULE        := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.MODULE;
        L_UI_NAME       := NVL(GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.UI_NAME,
                               GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.FUNCTION_ID);
        L_FUNCTION_TYPE := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.TYPE_STRING;
      END IF;
      DBG('Module and Ui name - ' || L_MODULE || '~' || L_UI_NAME);
    
      IF L_UI_NAME <> P_FUNCTION_ID THEN
      
        IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(L_UI_NAME,
                                                         P_ERROR_CODE,
                                                         P_ERROR_PARAMS) THEN
          DBG('Failed in the fRC bec of - ' || P_ERROR_CODE);
          DBG('Exception is not raised ,.. handled by assigning value to module ..');
          L_MODULE       := SUBSTR(L_UI_NAME, 1, 2);
          P_ERROR_CODE   := NULL;
          P_ERROR_PARAMS := NULL;
        ELSE
          DBG('Success from FRC...');
          L_MODULE := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.MODULE;
        END IF;
        DBG('Module is - ' || L_MODULE);
      
      END IF;
    
      BEGIN
        SELECT B.ON_OVERRIDE, B.ON_ERROR, B.UPLOADED_STATUS
          INTO L_ON_OVERRIDE, L_ON_ERROR, L_UPLOADED_STATUS
          FROM COTMS_SOURCE_PREF A, COTMS_SOURCE_FUNCID_PREF B
         WHERE B.SOURCE_CODE = P_SOURCE
           AND B.MODULE_CODE = L_MODULE
           AND B.SOURCE_CODE = A.SOURCE_CODE
           AND B.MODULE_CODE = A.MODULE_CODE
           AND B.FUNCTION_ID = P_FUNCTION_ID
           AND A.AUTH_STAT = 'A'
           AND A.RECORD_STAT = 'O';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          BEGIN
            SELECT ON_OVERRIDE, ON_ERROR, UPLOADED_STATUS
              INTO L_ON_OVERRIDE, L_ON_ERROR, L_UPLOADED_STATUS
              FROM COTMS_SOURCE_PREF
             WHERE SOURCE_CODE = P_SOURCE
               AND MODULE_CODE = L_MODULE
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Invalid Source Code :' || P_SOURCE);
              P_ERROR_CODE   := 'ST-VALS-002';
              P_ERROR_PARAMS := P_SOURCE;
              RETURN FALSE;
          END;
      END;
    
      DBG('Calling Cspkss_Upload.Fn_What_To_Do...');
    
      IF NOT CSPKSS_UPLOAD_CORE.FN_WHAT_TO_DO(L_ON_OVERRIDE,
                                              L_ON_ERROR,
                                              L_UPLOADED_STATUS,
                                              L_WHAT_TO_DO,
                                              L_AUTH_STAT,
                                              P_ERROR_CODE,
                                              P_ERROR_PARAMS) THEN
      
        DBG('Failed in  Cspkss_Upload.Fn_What_To_Do..');
        RETURN FALSE;
      END IF;
      L_AUTH_STAT  := NVL(L_AUTH_STAT, 'U');
      L_WHAT_TO_DO := NVL(L_WHAT_TO_DO, 'R');
    ELSE
    
      IF L_ULT_TYPE = 'E' THEN
      
        L_WHAT_TO_DO := 'R';
      ELSIF L_ULT_TYPE = 'O' THEN
      
        L_WHAT_TO_DO := 'P';
      ELSE
      
        L_WHAT_TO_DO := 'P';
      END IF;
      DBG('23264040..' || L_AUTH_STAT || '-' || L_WHAT_TO_DO);
      GLOBAL.PR_SET_AUTO_AUTH_STATUS(GLOBAL.USER_ID,
                                     P_FUNCTION_ID,
                                     GLOBAL.CURRENT_BRANCH);
    
      L_AUTO_AUTH := NVL(GLOBAL.FN_GET_AUTO_AUTH_STATUS, 'N');
      GLOBAL.PR_RESET_AUTO_AUTH_STATUS;
      DBG('  l_Auto_Auth ' || L_AUTO_AUTH);
      IF L_AUTO_AUTH = 'Y' THEN
        L_AUTH_STAT := 'A';
      ELSE
        L_AUTH_STAT := 'U';
      END IF;
    END IF;
  
    DBG('23264040..ends...' || P_ACTION_CODE || '-' || L_AUTH_STAT || '-' ||
        L_WHAT_TO_DO);
  
    BEGIN
      L_SQL := 'SELECT depks_rtl_teller.fn_get_g_module FROM DUAL ';
      DBG('Dynamic Sql :' || L_SQL);
      EXECUTE IMMEDIATE L_SQL
        INTO L_MODULE1;
      DBG('l_MODULE1 :' || L_MODULE1);
      IF NVL(L_MODULE1, '**') = 'RT' THEN
        L_AUTH_STAT := 'A';
      END IF;
      DBG('l_Auth_Stat :' || L_AUTH_STAT);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('in exception block' || SQLERRM);
        NULL;
    END;
  
    IF L_WHAT_TO_DO IN ('P', 'O') THEN
      IF L_AUTH_STAT = 'A' AND
         P_ACTION_CODE NOT IN
         (CSPKS_REQ_GLOBAL.P_AUTH, CSPKS_REQ_GLOBAL.P_DELETE)
      
       THEN
        P_POST_UPL_STAT := 'A';
      ELSE
        P_POST_UPL_STAT := 'U';
      END IF;
    ELSIF L_WHAT_TO_DO = 'H' THEN
      IF P_ACTION_CODE = 'NEW' AND L_FUNCTION_TYPE = 'O' THEN
        P_POST_UPL_STAT := 'H';
      
        DBG('22559747..p_Action_Code ' || P_ACTION_CODE ||
            'l_Function_Type' || L_FUNCTION_TYPE);
      ELSIF P_ACTION_CODE = 'CLOSE' AND L_FUNCTION_TYPE = 'O' THEN
        P_POST_UPL_STAT := 'A';
      
      ELSE
        P_POST_UPL_STAT := 'R';
      END IF;
    ELSIF L_WHAT_TO_DO = 'R' THEN
      P_POST_UPL_STAT := 'R';
    ELSE
      P_POST_UPL_STAT := 'R';
    END IF;
  
    DBG('p_Post_Upl_Stat>>' || P_POST_UPL_STAT);
    IF P_POST_UPL_STAT IN ('A', 'U') THEN
      IF NVL(CSPKS_REQ_GLOBAL.FN_GET_POST_UPL_STAT, '*') IN ('A', 'U') THEN
        DBG('Setting it to User Defined Uplaod Status..');
        P_POST_UPL_STAT := NVL(CSPKS_REQ_GLOBAL.FN_GET_POST_UPL_STAT, 'U');
      END IF;
    END IF;
  
    DBG('p_Post_Upl_Stat<<' || P_POST_UPL_STAT);
  
    IF P_ACTION_CODE NOT IN (CSPKS_REQ_GLOBAL.P_NEW) THEN
      DBG('Before Adjusting Post Upload Status : ' || P_PREV_AUTH_STAT || ':' ||
          P_POST_UPL_STAT);
      IF NVL(P_PREV_AUTH_STAT, 'A') = 'U' AND P_POST_UPL_STAT = 'A' THEN
        P_POST_UPL_STAT := 'U';
        DBG('Auto Authorization Status Adjusted..');
      END IF;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.FN_UNTANKING THEN
      IF P_POST_UPL_STAT = 'A' THEN
        DBG('Adjusting The Auto Auth Status For Untanking Case..');
        P_POST_UPL_STAT := 'U';
      END IF;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.FN_GET_SNCK_ENABLED AND P_POST_UPL_STAT = 'A' THEN
      P_POST_UPL_STAT := 'U';
    END IF;
  
    IF P_POST_UPL_STAT = 'A' THEN
      CSPKS_REQ_GLOBAL.PR_SET_AUTO_AUTH(TRUE);
    ELSE
      CSPKS_REQ_GLOBAL.PR_SET_AUTO_AUTH(FALSE);
    END IF;
    DBG('Post Upload Status :' || P_POST_UPL_STAT);
    RETURN TRUE;
    DBG('Retuning Success From Fn_Get_Auto_Auth_Status..');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others Of  Fn_Get_Auto_Auth_Status..');
      DBG(SQLERRM);
      P_ERROR_CODE   := 'ST-OTHR-001';
      P_ERROR_PARAMS := 'Fn_Get_Auto_Auth_Status~' || SQLCODE;
      RETURN FALSE;
  END FN_GET_AUTO_AUTH_STATUS;

  FUNCTION FN_GET_RESULTANT_ERROR_TYPE RETURN VARCHAR2 IS
    L_ERROR_CODE           VARCHAR2(1000) := NULL;
    L_ERROR_PARAMS         VARCHAR2(1000) := NULL;
    L_ERROR_CODE_TYPE      ERTBS_MSGS.TYPE%TYPE;
    L_RESULTANT_ERROR_TYPE VARCHAR2(10) := 'I';
  
  BEGIN
    DBG('In Fn_Get_Resultant_Error_Type :' || OVPKSS.GL_TBLERROR.COUNT);
    L_RESULTANT_ERROR_TYPE := 'I';
    IF (OVPKSS.GL_TBLERROR.COUNT = 0) THEN
      L_RESULTANT_ERROR_TYPE := 'I';
    END IF;
    IF OVPKSS.GL_TBLERROR.COUNT > 0 THEN
      FOR OVERRIDE_COUNT IN OVPKSS.GL_TBLERROR.FIRST .. OVPKSS.GL_TBLERROR.LAST LOOP
        L_ERROR_CODE      := OVPKSS.GL_TBLERROR(OVERRIDE_COUNT).ERR_CODE;
        L_ERROR_PARAMS    := OVPKSS.GL_TBLERROR(OVERRIDE_COUNT).PARAMS;
        L_ERROR_CODE_TYPE := OVPKSS.FN_GETTYPE(L_ERROR_CODE);
        IF (L_ERROR_CODE_TYPE = 'X') THEN
          L_RESULTANT_ERROR_TYPE := 'E';
          EXIT;
        END IF;
        IF (L_ERROR_CODE_TYPE IN ('O', 'A', 'D')) THEN
          L_RESULTANT_ERROR_TYPE := 'O';
        ELSIF (L_ERROR_CODE_TYPE = 'E') THEN
          L_RESULTANT_ERROR_TYPE := 'E';
          EXIT;
        END IF;
      END LOOP;
    END IF;
    DBG('Returning Success From  Fn_Get_Resultant_Error_Type..');
    RETURN L_RESULTANT_ERROR_TYPE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('From When Others of  Fn_Get_Resultant_Error_Type..');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      L_RESULTANT_ERROR_TYPE := 'E';
      RETURN L_RESULTANT_ERROR_TYPE;
  END FN_GET_RESULTANT_ERROR_TYPE;

  FUNCTION FN_GET_UPLOAD_STATUS(P_SOURCE            IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                P_MODULE            IN COTMS_SOURCE_PREF.MODULE_CODE%TYPE,
                                P_FUNCTION_ID       IN SMTBS_MENU.FUNCTION_ID%TYPE,
                                P_ACTION_CODE       IN VARCHAR2,
                                P_MULTI_TRIP_REF_NO IN VARCHAR2,
                                P_REQUEST_NO        IN NUMBER,
                                P_POST_UPL_STAT     IN OUT VARCHAR2,
                                P_ERROR_CODE        IN OUT VARCHAR2,
                                P_ERROR_PARAMS      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_WHAT_TO_DO VARCHAR2(1);
    L_AUTH_STAT  VARCHAR2(1);
    L_AUTO_AUTH  VARCHAR2(1);
  
    L_ULT_TYPE      VARCHAR2(1);
    L_FUNCTION_TYPE VARCHAR2(10) := 'M';
    L_ERR_TBL       OVPKS.TBL_ERROR;
    L_ERR_COUNT     NUMBER := 0;
    L_START_COUNT   NUMBER := 0;
    L_ERR_FOUND     BOOLEAN := FALSE;
    L_ERR_COUNTER   NUMBER := 0;
    L_MODULE        VARCHAR2(10);
    L_UI_NAME       VARCHAR2(20);
  
    L_ON_OVERRIDE     VARCHAR2(1);
    L_ON_ERROR        VARCHAR2(1);
    L_UPLOADED_STATUS VARCHAR2(1);
  
  BEGIN
    DBG('In  Fn_Get_Upload_Status..');
    DBG('p_Function_Id :: ' || P_FUNCTION_ID);
    DBG('p_Action_Code :: ' || P_ACTION_CODE);
  
    L_ERR_COUNT := NVL(OVPKSS.GL_TBLERROR.COUNT, 0);
  
    IF L_ERR_COUNT > 0 THEN
    
      OVPKSS_ADDON.PR_INIT(GLOBAL.CURRENT_BRANCH, P_FUNCTION_ID, P_SOURCE);
      FOR L_ERR_INDEX IN 1 .. L_ERR_COUNT LOOP
        OVPKSS.GL_TBLERROR(L_ERR_INDEX).ERR_CODE := OVPKSS_ADDON.FN_RET_OVD_CODE(OVPKSS.GL_TBLERROR(L_ERR_INDEX)
                                                                                 .ERR_CODE);
      END LOOP;
    
      FOR OVERRIDE_COUNT IN 1 .. L_ERR_COUNT LOOP
        L_ERR_FOUND   := FALSE;
        L_START_COUNT := OVERRIDE_COUNT + 1;
        FOR DUP_COUNT IN L_START_COUNT .. L_ERR_COUNT LOOP
          IF NVL(OVPKSS.GL_TBLERROR(OVERRIDE_COUNT).ERR_CODE, '**') =
             NVL(OVPKSS.GL_TBLERROR(DUP_COUNT).ERR_CODE, '**') AND
             NVL(OVPKSS.GL_TBLERROR(OVERRIDE_COUNT).PARAMS, '**') =
             NVL(OVPKSS.GL_TBLERROR(DUP_COUNT).PARAMS, '**') THEN
            L_ERR_FOUND := TRUE;
            DBG('Duplicate Error Code Found :' || OVPKSS.GL_TBLERROR(OVERRIDE_COUNT)
                .ERR_CODE);
            EXIT;
          END IF;
        END LOOP;
        IF NOT L_ERR_FOUND THEN
          L_ERR_COUNTER := L_ERR_COUNTER + 1;
          L_ERR_TBL(L_ERR_COUNTER).ERR_CODE := OVPKSS.GL_TBLERROR(OVERRIDE_COUNT)
                                               .ERR_CODE;
          L_ERR_TBL(L_ERR_COUNTER).PARAMS := OVPKSS.GL_TBLERROR(OVERRIDE_COUNT)
                                             .PARAMS;
          L_ERR_TBL(L_ERR_COUNTER).REQID := OVPKSS.GL_TBLERROR(OVERRIDE_COUNT)
                                            .REQID;
        END IF;
      END LOOP;
      OVPKSS.GL_TBLERROR := L_ERR_TBL;
    END IF;
  
    L_ULT_TYPE := FN_SCAN_ERROR_LIST;
    IF P_SOURCE NOT IN ('FLEXCUBE', 'FLEXNOTIF') THEN
    
      IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                       P_ERROR_CODE,
                                                       P_ERROR_PARAMS) THEN
        DBG('Failed in FRC bec of - ' || P_ERROR_CODE);
        DBG('Exception was not raised previously..instead handled..dng the same..');
        L_MODULE       := SUBSTR(P_FUNCTION_ID, 1, 2);
        L_UI_NAME      := P_FUNCTION_ID;
        P_ERROR_CODE   := NULL;
        P_ERROR_PARAMS := NULL;
      ELSE
        DBG('Returned success from FRC..');
        L_MODULE        := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.MODULE;
        L_UI_NAME       := NVL(GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.UI_NAME,
                               GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.FUNCTION_ID);
        L_FUNCTION_TYPE := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.TYPE_STRING;
      END IF;
      DBG('Value of l_Module and l_Ui_Name  is - ' || L_MODULE || '~' ||
          L_UI_NAME);
    
      IF L_UI_NAME <> P_FUNCTION_ID THEN
      
        DBG('UI name and Function id are not the same..');
        IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(L_UI_NAME,
                                                         P_ERROR_CODE,
                                                         P_ERROR_PARAMS) THEN
          DBG('Failed in FRC bec of - ' || P_ERROR_CODE);
          DBG('Exception was not raised previously..instead handled..dng the same..');
          L_MODULE       := SUBSTR(L_UI_NAME, 1, 2);
          P_ERROR_CODE   := NULL;
          P_ERROR_PARAMS := NULL;
        ELSE
          DBG('Returned success from FRC..');
          L_MODULE := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.MODULE;
        END IF;
        DBG('Value of l_Module is - ' || L_MODULE);
      
      END IF;
    
      DBG('Get Source Parameters..');
    
      BEGIN
        SELECT B.ON_OVERRIDE, B.ON_ERROR, B.UPLOADED_STATUS
          INTO L_ON_OVERRIDE, L_ON_ERROR, L_UPLOADED_STATUS
          FROM COTMS_SOURCE_PREF A, COTMS_SOURCE_FUNCID_PREF B
         WHERE B.SOURCE_CODE = P_SOURCE
           AND B.MODULE_CODE = L_MODULE
           AND B.SOURCE_CODE = A.SOURCE_CODE
           AND B.MODULE_CODE = A.MODULE_CODE
           AND B.FUNCTION_ID = P_FUNCTION_ID
           AND A.AUTH_STAT = 'A'
           AND A.RECORD_STAT = 'O';
        DBG('Got Source Parameters..for ' || P_SOURCE || ' module ' ||
            L_MODULE);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          BEGIN
            SELECT ON_OVERRIDE, ON_ERROR, UPLOADED_STATUS
              INTO L_ON_OVERRIDE, L_ON_ERROR, L_UPLOADED_STATUS
              FROM COTMS_SOURCE_PREF
             WHERE SOURCE_CODE = P_SOURCE
               AND MODULE_CODE = L_MODULE
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';
            DBG('Got Source Parameters..for ' || P_SOURCE || ' module ' ||
                L_MODULE);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Invalid Source Code :' || P_SOURCE);
              P_ERROR_CODE   := 'ST-VALS-002';
              P_ERROR_PARAMS := P_SOURCE;
              RETURN FALSE;
          END;
      END;
    
      DBG('Calling Cspkss_Upload.Fn_What_To_Do...');
    
      IF NOT CSPKSS_UPLOAD_CORE.FN_WHAT_TO_DO(L_ON_OVERRIDE,
                                              L_ON_ERROR,
                                              L_UPLOADED_STATUS,
                                              L_WHAT_TO_DO,
                                              L_AUTH_STAT,
                                              P_ERROR_CODE,
                                              P_ERROR_PARAMS) THEN
      
        DBG('Failed in  Cspkss_Upload.Fn_What_To_Do..');
        RETURN FALSE;
      END IF;
      L_AUTH_STAT  := NVL(L_AUTH_STAT, 'U');
      L_WHAT_TO_DO := NVL(L_WHAT_TO_DO, 'R');
    ELSE
      IF L_ULT_TYPE = 'E' THEN
        L_WHAT_TO_DO := 'R';
      ELSIF L_ULT_TYPE = 'O' THEN
        L_WHAT_TO_DO := 'O';
      ELSE
        L_WHAT_TO_DO := 'P';
      END IF;
      GLOBAL.PR_SET_AUTO_AUTH_STATUS(GLOBAL.USER_ID,
                                     P_FUNCTION_ID,
                                     GLOBAL.CURRENT_BRANCH);
      L_AUTO_AUTH := NVL(GLOBAL.FN_GET_AUTO_AUTH_STATUS, 'N');
      GLOBAL.PR_RESET_AUTO_AUTH_STATUS;
      IF L_AUTO_AUTH = 'Y' THEN
        L_AUTH_STAT := 'A';
      ELSE
        L_AUTH_STAT := 'U';
      END IF;
    END IF;
  
    IF L_WHAT_TO_DO = 'O' THEN
      IF P_MULTI_TRIP_REF_NO IS NOT NULL THEN
        IF FN_PROCESS_OVDS(P_MULTI_TRIP_REF_NO,
                           P_REQUEST_NO,
                           P_ERROR_CODE,
                           P_ERROR_PARAMS) THEN
          PR_FILTER_ERR_TYPE('O');
        
          L_WHAT_TO_DO := 'P';
        ELSE
          L_WHAT_TO_DO := 'O';
        END IF;
      END IF;
    END IF;
    IF L_WHAT_TO_DO = 'P' THEN
      IF L_AUTH_STAT = 'A' AND
         P_ACTION_CODE NOT IN
         (CSPKS_REQ_GLOBAL.P_AUTH, CSPKS_REQ_GLOBAL.P_DELETE) AND
         CSPKSS_REQ_GLOBAL.G_FINAL_AUTH_STAT = 'Y' AND
         P_POST_UPL_STAT = 'A' AND NOT G_DUAL_AUTH_FOUND THEN
        P_POST_UPL_STAT := 'A';
      ELSE
        P_POST_UPL_STAT := 'U';
      END IF;
    ELSIF L_WHAT_TO_DO = 'O' THEN
      P_POST_UPL_STAT := 'O';
    ELSIF L_WHAT_TO_DO = 'H' THEN
      IF P_ACTION_CODE = 'NEW' AND L_FUNCTION_TYPE = 'O' THEN
        P_POST_UPL_STAT := 'H';
      
      ELSIF P_ACTION_CODE = 'HOLD' AND L_FUNCTION_TYPE = 'O' THEN
        P_POST_UPL_STAT := 'A';
      
        DBG('22559747..p_Action_Code ' || P_ACTION_CODE ||
            'l_Function_Type' || L_FUNCTION_TYPE);
      ELSIF P_ACTION_CODE = 'CLOSE' AND L_FUNCTION_TYPE = 'O' THEN
        P_POST_UPL_STAT := 'A';
      
      ELSE
        P_POST_UPL_STAT := 'R';
      END IF;
    ELSIF L_WHAT_TO_DO = 'R' THEN
      P_POST_UPL_STAT := 'R';
    ELSE
      P_POST_UPL_STAT := 'R';
    END IF;
  
    IF P_POST_UPL_STAT = 'O' THEN
      IF NVL(CSPKS_REQ_GLOBAL.FN_GET_ON_OVERRIDE_ACTION, 'E') = 'E' THEN
        DBG('On Override Error Case..');
        P_POST_UPL_STAT := 'R';
      ELSIF NVL(CSPKS_REQ_GLOBAL.FN_GET_ON_OVERRIDE_ACTION, 'E') = 'I' THEN
        DBG('On Override Ignore Case..');
        P_POST_UPL_STAT := NVL(CSPKS_REQ_GLOBAL.FN_GET_POST_UPL_STAT, 'U');
      END IF;
    ELSIF P_POST_UPL_STAT IN ('A', 'U') THEN
    
      IF NVL(CSPKS_REQ_GLOBAL.FN_GET_POST_UPL_STAT, '*') IN ('A', 'U') THEN
        P_POST_UPL_STAT := NVL(CSPKS_REQ_GLOBAL.FN_GET_POST_UPL_STAT, 'U');
      END IF;
    
    END IF;
  
    DBG('Post Upload Status :' || P_POST_UPL_STAT);
  
    DBG('P_SOURCE P_SOURCE P_SOURCE=' || P_SOURCE);
  
    DBG('Cspks_Req_Wrapper.g_source_operation=' ||
        Cspks_Req_Wrapper.g_source_operation);
    DBG('Cspks_Req_Wrapper.g_Action_Code=' ||
        Cspks_Req_Wrapper.g_Action_Code);
    DBG('Cspks_Req_Wrapper.g_tanked_stat=' ||
        Cspks_Req_Wrapper.g_tanked_stat);
    DBG('Cspks_Req_Wrapper.g_Status=' || Cspks_Req_Wrapper.g_Status);
    
    DBG('SOURCE='||CSPKS_REQ_GLOBAL.G_HEADER('SOURCE'));
    DBG('OPERATION='||CSPKS_REQ_GLOBAL.G_HEADER('OPERATION'));
    DBG('SERVICE='||CSPKS_REQ_GLOBAL.G_HEADER('SERVICE'));
    
    --sampath starts for E-Account EOD Issue Starts
    IF CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') = 'DIGIKYC' AND
       CSPKS_REQ_GLOBAL.G_HEADER('OPERATION') IN ('CreateCustomer', 'DeleteCustomer') AND
       CSPKS_REQ_GLOBAL.G_HEADER('SERVICE') = 'FCUBSCustomerService' THEN
    
      P_POST_UPL_STAT := 'U';

    
    END IF;
    
    IF CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') = 'DIGIBANK2' AND
       CSPKS_REQ_GLOBAL.G_HEADER('OPERATION') IN ('CreateCustomer', 'DeleteCustomer') AND
       CSPKS_REQ_GLOBAL.G_HEADER('SERVICE') = 'FCUBSCustomerService' THEN

      P_POST_UPL_STAT := 'U';


    END IF;
	
    --sampath ends for E-Account EOD Issue Ends
    
    DBG('Returning Success From Fn_Get_Upload_Status..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In  When Others Of  Fn_Get_Upload_Status..');
      DBG(SQLERRM);
      P_ERROR_CODE   := 'ST-OTHR-001';
      P_ERROR_PARAMS := 'Fn_Get_Upload_Status~' || SQLCODE;
      RETURN FALSE;
  END FN_GET_UPLOAD_STATUS;

  PROCEDURE PR_GET_AMENDABLE_DETAILS(P_ORIGIN_SOURCE IN VARCHAR2,
                                     P_FUNCTION_ID   IN VARCHAR2,
                                     P_ACTION_CODE   IN VARCHAR2,
                                     P_AMEND_DETAILS IN OUT VARCHAR2) IS
    L_SOURCE                     VARCHAR2(100) := 'FLEXCUBE';
    L_SOURCE_OPERATION           VARCHAR2(100);
    L_ORIGIN_SOURCE              VARCHAR2(100) := NVL(P_ORIGIN_SOURCE,
                                                      'FLEXCUBE');
    L_ORIGIN_SOURCE_OPERATION    VARCHAR2(100);
    L_ORIGIN_SRC_OPERATION_FOUND BOOLEAN := FALSE;
    L_INT_AMEND_FIELDS           CSPKS_REQ_GLOBAL.TY_INT_AMEND_FIELDS;
    L_CHR_AMEND_FIELDS           CSPKS_REQ_GLOBAL.TY_AMEND_FIELDS;
    L_COUNT                      NUMBER;
    L_FLAG                       VARCHAR2(1) := '0';
  
    CURSOR CR_AMENDABLE_FIELDS(L_SRC           VARCHAR2,
                               L_SRC_OPERATION VARCHAR2,
                               L_ORIGIN_SRC    VARCHAR2) IS
      SELECT *
        FROM GWTM_AMEND_FIELDS
       WHERE EXT_SYSTEM = L_SRC
         AND SOURCE_OPERATION = L_SRC_OPERATION
         AND ORIGIN_SYSTEM = L_ORIGIN_SRC
       ORDER BY NODE_NAME, FIELD_NAME;
  BEGIN
    P_AMEND_DETAILS := '';
    IF P_ACTION_CODE = 'UNLOCK' THEN
      L_SOURCE_OPERATION := P_FUNCTION_ID || '_' || 'MODIFY';
    ELSE
      L_SOURCE_OPERATION := P_FUNCTION_ID || '_' || P_ACTION_CODE;
    END IF;
  
    IF P_ORIGIN_SOURCE IS NULL THEN
      L_ORIGIN_SRC_OPERATION_FOUND := FALSE;
    ELSE
      BEGIN
        SELECT SOURCE_OPERATION
          INTO L_ORIGIN_SOURCE_OPERATION
          FROM GWTM_AMEND_MASTER
         WHERE EXT_SYSTEM = L_SOURCE
           AND ORIGIN_SYSTEM = L_ORIGIN_SOURCE
           AND (SERVICE_NAME, OPERATION_CODE) IN
               (SELECT SERVICE_NAME, OPERATION_CODE
                  FROM GWTM_AMEND_MASTER
                 WHERE EXT_SYSTEM = L_SOURCE
                   AND SOURCE_OPERATION = L_SOURCE_OPERATION
                   AND ORIGIN_SYSTEM = L_SOURCE);
        L_ORIGIN_SRC_OPERATION_FOUND := TRUE;
      EXCEPTION
        WHEN TOO_MANY_ROWS THEN
        
          BEGIN
            SELECT COUNT(*)
              INTO L_COUNT
              FROM GWTM_AMEND_MASTER
             WHERE EXT_SYSTEM = L_SOURCE
               AND ORIGIN_SYSTEM = L_ORIGIN_SOURCE
               AND SOURCE_OPERATION = L_SOURCE_OPERATION;
            IF L_COUNT > 0 THEN
              L_ORIGIN_SOURCE_OPERATION := L_SOURCE_OPERATION;
            ELSE
              SELECT SOURCE_OPERATION
                INTO L_ORIGIN_SOURCE_OPERATION
                FROM GWTM_AMEND_MASTER
               WHERE EXT_SYSTEM = L_SOURCE
                 AND ORIGIN_SYSTEM = L_ORIGIN_SOURCE
                 AND (SERVICE_NAME, OPERATION_CODE) IN
                     (SELECT SERVICE_NAME, OPERATION_CODE
                        FROM GWTM_AMEND_MASTER
                       WHERE EXT_SYSTEM = L_SOURCE
                         AND SOURCE_OPERATION = L_SOURCE_OPERATION
                         AND ORIGIN_SYSTEM = L_SOURCE)
                 AND ROWNUM < 2;
            
            END IF;
            L_ORIGIN_SRC_OPERATION_FOUND := TRUE;
          EXCEPTION
            WHEN OTHERS THEN
            
              L_ORIGIN_SRC_OPERATION_FOUND := FALSE;
          END;
        WHEN OTHERS THEN
        
          L_ORIGIN_SRC_OPERATION_FOUND := FALSE;
      END;
    END IF;
    IF NOT L_ORIGIN_SRC_OPERATION_FOUND THEN
      L_ORIGIN_SOURCE           := L_SOURCE;
      L_ORIGIN_SOURCE_OPERATION := L_SOURCE_OPERATION;
    END IF;
    OPEN CR_AMENDABLE_FIELDS(L_SOURCE,
                             L_ORIGIN_SOURCE_OPERATION,
                             L_ORIGIN_SOURCE);
    LOOP
      FETCH CR_AMENDABLE_FIELDS BULK COLLECT
        INTO L_INT_AMEND_FIELDS;
      EXIT WHEN CR_AMENDABLE_FIELDS%NOTFOUND;
    END LOOP;
    CLOSE CR_AMENDABLE_FIELDS;
    L_COUNT := L_INT_AMEND_FIELDS.COUNT;
    IF L_COUNT > 0 THEN
      FOR I IN 1 .. L_COUNT LOOP
        L_CHR_AMEND_FIELDS(L_INT_AMEND_FIELDS(I).NODE_NAME || '.' || L_INT_AMEND_FIELDS(I).FIELD_NAME) := L_INT_AMEND_FIELDS(I);
      END LOOP;
    END IF;
    L_INT_AMEND_FIELDS.DELETE;
  
    OPEN CR_AMENDABLE_FIELDS(L_SOURCE, L_SOURCE_OPERATION, 'FLEXCUBE');
    LOOP
      FETCH CR_AMENDABLE_FIELDS BULK COLLECT
        INTO L_INT_AMEND_FIELDS;
      EXIT WHEN CR_AMENDABLE_FIELDS%NOTFOUND;
    END LOOP;
    CLOSE CR_AMENDABLE_FIELDS;
    L_COUNT := L_INT_AMEND_FIELDS.COUNT;
    IF L_COUNT > 0 THEN
      FOR I IN 1 .. L_COUNT LOOP
        L_FLAG := '0';
        IF L_CHR_AMEND_FIELDS.EXISTS(L_INT_AMEND_FIELDS(I).NODE_NAME || '.' || L_INT_AMEND_FIELDS(I)
                                     .FIELD_NAME) THEN
          L_FLAG := '1';
        END IF;
        P_AMEND_DETAILS := P_AMEND_DETAILS || L_FLAG;
      END LOOP;
    END IF;
  END PR_GET_AMENDABLE_DETAILS;

  FUNCTION FN_GET_AMENDABLE_DETAILS(P_SOURCE_CODE      IN VARCHAR2,
                                    P_SOURCE_OPERATION IN GWTM_AMEND_DETAIL.SOURCE_OPERATION%TYPE,
                                    P_ORIGIN_SOURCE    IN VARCHAR2,
                                    P_AMENDABLE_NODES  IN OUT NOCOPY CSPKS_REQ_GLOBAL.TY_AMEND_NODES,
                                    P_AMENDABLE_FIELDS IN OUT NOCOPY CSPKS_REQ_GLOBAL.TY_AMEND_FIELDS,
                                    P_ERR_CODE         IN OUT VARCHAR2,
                                    P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_INT_AMEND_NODES            CSPKS_REQ_GLOBAL.TY_INT_AMEND_NODES;
    L_INT_AMEND_FIELDS           CSPKS_REQ_GLOBAL.TY_INT_AMEND_FIELDS;
    L_ORIGIN_SOURCE              VARCHAR2(100);
    L_ORIGIN_SOURCE_OPERATION    VARCHAR2(100);
    L_ORIGIN_SRC_OPERATION_FOUND BOOLEAN := FALSE;
    L_COUNT                      NUMBER;
  
    CURSOR CR_AMENDABLE_NODES(L_SRC           VARCHAR2,
                              L_SRC_OPERATION VARCHAR2,
                              L_ORIGIN_SRC    VARCHAR2) IS
      SELECT *
        FROM GWTM_AMEND_NODES
       WHERE EXT_SYSTEM = L_SRC
         AND SOURCE_OPERATION = L_SRC_OPERATION
         AND ORIGIN_SYSTEM = L_ORIGIN_SRC;
    CURSOR CR_AMENDABLE_FIELDS(L_SRC           VARCHAR2,
                               L_SRC_OPERATION VARCHAR2,
                               L_ORIGIN_SRC    VARCHAR2) IS
      SELECT *
        FROM GWTM_AMEND_FIELDS
       WHERE EXT_SYSTEM = L_SRC
         AND SOURCE_OPERATION = L_SRC_OPERATION
         AND ORIGIN_SYSTEM = L_ORIGIN_SRC;
  
  BEGIN
    DBG('In Fn_Get_Amendable_Details :' || P_SOURCE_CODE || '/' ||
        P_SOURCE_OPERATION || '/' || P_ORIGIN_SOURCE);
    P_AMENDABLE_NODES.DELETE;
    P_AMENDABLE_FIELDS.DELETE;
    IF P_ORIGIN_SOURCE IS NULL OR P_ORIGIN_SOURCE = P_SOURCE_CODE THEN
      L_ORIGIN_SRC_OPERATION_FOUND := FALSE;
    ELSE
      BEGIN
        SELECT SOURCE_OPERATION
          INTO L_ORIGIN_SOURCE_OPERATION
          FROM GWTM_AMEND_MASTER
         WHERE EXT_SYSTEM = P_SOURCE_CODE
           AND ORIGIN_SYSTEM = L_ORIGIN_SOURCE
           AND (SERVICE_NAME, OPERATION_CODE) IN
               (SELECT SERVICE_NAME, OPERATION_CODE
                  FROM GWTM_AMEND_MASTER
                 WHERE EXT_SYSTEM = P_SOURCE_CODE
                   AND SOURCE_OPERATION = P_SOURCE_OPERATION
                   AND ORIGIN_SYSTEM = P_SOURCE_CODE);
        L_ORIGIN_SRC_OPERATION_FOUND := TRUE;
      EXCEPTION
        WHEN TOO_MANY_ROWS THEN
          DBG('Same Operation maintained multiple times with diferent set of amendable fields  ');
        
          BEGIN
            SELECT COUNT(*)
              INTO L_COUNT
              FROM GWTM_AMEND_MASTER
             WHERE EXT_SYSTEM = P_SOURCE_CODE
               AND ORIGIN_SYSTEM = L_ORIGIN_SOURCE
               AND SOURCE_OPERATION = P_SOURCE_OPERATION;
            IF L_COUNT > 0 THEN
              L_ORIGIN_SOURCE_OPERATION := P_SOURCE_OPERATION;
            ELSE
              SELECT SOURCE_OPERATION
                INTO L_ORIGIN_SOURCE_OPERATION
                FROM GWTM_AMEND_MASTER
               WHERE EXT_SYSTEM = P_SOURCE_CODE
                 AND ORIGIN_SYSTEM = L_ORIGIN_SOURCE
                 AND (SERVICE_NAME, OPERATION_CODE) IN
                     (SELECT SERVICE_NAME, OPERATION_CODE
                        FROM GWTM_AMEND_MASTER
                       WHERE EXT_SYSTEM = P_SOURCE_CODE
                         AND SOURCE_OPERATION = P_SOURCE_OPERATION
                         AND ORIGIN_SYSTEM = P_SOURCE_CODE)
                 AND ROWNUM < 2;
            END IF;
            L_ORIGIN_SRC_OPERATION_FOUND := TRUE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Deriving Source Operation ');
              L_ORIGIN_SRC_OPERATION_FOUND := FALSE;
          END;
        WHEN OTHERS THEN
          DBG('Failed in Deriving Source Operation ');
          L_ORIGIN_SRC_OPERATION_FOUND := FALSE;
      END;
    END IF;
    IF NOT L_ORIGIN_SRC_OPERATION_FOUND THEN
      L_ORIGIN_SOURCE           := P_SOURCE_CODE;
      L_ORIGIN_SOURCE_OPERATION := P_SOURCE_OPERATION;
    END IF;
    DBG(' l_origin_source_operation:' || L_ORIGIN_SOURCE_OPERATION);
    OPEN CR_AMENDABLE_NODES(P_SOURCE_CODE,
                            L_ORIGIN_SOURCE_OPERATION,
                            L_ORIGIN_SOURCE);
    LOOP
      FETCH CR_AMENDABLE_NODES BULK COLLECT
        INTO L_INT_AMEND_NODES;
      EXIT WHEN CR_AMENDABLE_NODES%NOTFOUND;
    END LOOP;
    L_COUNT := L_INT_AMEND_NODES.COUNT;
    IF L_COUNT > 0 THEN
      FOR I IN 1 .. L_COUNT LOOP
        P_AMENDABLE_NODES(L_INT_AMEND_NODES(I).NODE_NAME) := L_INT_AMEND_NODES(I);
      END LOOP;
      OPEN CR_AMENDABLE_FIELDS(P_SOURCE_CODE,
                               L_ORIGIN_SOURCE_OPERATION,
                               L_ORIGIN_SOURCE);
      LOOP
        FETCH CR_AMENDABLE_FIELDS BULK COLLECT
          INTO L_INT_AMEND_FIELDS;
        EXIT WHEN CR_AMENDABLE_FIELDS%NOTFOUND;
      END LOOP;
      CLOSE CR_AMENDABLE_FIELDS;
      L_COUNT := L_INT_AMEND_FIELDS.COUNT;
      IF L_COUNT > 0 THEN
        FOR I IN 1 .. L_COUNT LOOP
          P_AMENDABLE_FIELDS(L_INT_AMEND_FIELDS(I).NODE_NAME || '.' || L_INT_AMEND_FIELDS(I).FIELD_NAME) := L_INT_AMEND_FIELDS(I);
        END LOOP;
      END IF;
    END IF;
    RETURN TRUE;
    DBG('Returning Success From Fn_Get_Amendable_Details..');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others Of Fn_Get_Amendable_Details..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_AMENDABLE_DETAILS;

  FUNCTION FN_GET_AMENDABLE_DETAILS(P_SOURCE_CODE      IN VARCHAR2,
                                    P_SOURCE_OPERATION IN GWTM_AMEND_DETAIL.SOURCE_OPERATION%TYPE,
                                    P_AMENDABLE_NODES  IN OUT NOCOPY CSPKS_REQ_GLOBAL.TY_AMEND_NODES,
                                    P_AMENDABLE_FIELDS IN OUT NOCOPY CSPKS_REQ_GLOBAL.TY_AMEND_FIELDS,
                                    P_ERR_CODE         IN OUT VARCHAR2,
                                    P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_COUNT            NUMBER;
    L_INT_AMEND_NODES  CSPKS_REQ_GLOBAL.TY_INT_AMEND_NODES;
    L_INT_AMEND_FIELDS CSPKS_REQ_GLOBAL.TY_INT_AMEND_FIELDS;
  
    CURSOR CR_AMENDABLE_NODES IS
      SELECT *
        FROM GWTM_AMEND_NODES
       WHERE EXT_SYSTEM = P_SOURCE_CODE
         AND SOURCE_OPERATION = P_SOURCE_OPERATION
         AND ORIGIN_SYSTEM = P_SOURCE_CODE;
  
    CURSOR CR_AMENDABLE_FIELDS IS
      SELECT *
        FROM GWTM_AMEND_FIELDS
       WHERE EXT_SYSTEM = P_SOURCE_CODE
         AND SOURCE_OPERATION = P_SOURCE_OPERATION
         AND ORIGIN_SYSTEM = P_SOURCE_CODE;
  
  BEGIN
    DBG('In Fn_Get_Amendable_Details :' || P_SOURCE_CODE || '/' ||
        P_SOURCE_OPERATION);
    P_AMENDABLE_NODES.DELETE;
    P_AMENDABLE_FIELDS.DELETE;
    OPEN CR_AMENDABLE_NODES;
    LOOP
      FETCH CR_AMENDABLE_NODES BULK COLLECT
        INTO L_INT_AMEND_NODES;
      EXIT WHEN CR_AMENDABLE_NODES%NOTFOUND;
    END LOOP;
    CLOSE CR_AMENDABLE_NODES;
  
    L_COUNT := L_INT_AMEND_NODES.COUNT;
    DBG('l_Count' || L_COUNT);
    IF L_COUNT > 0 THEN
      FOR I IN 1 .. L_COUNT LOOP
        P_AMENDABLE_NODES(L_INT_AMEND_NODES(I).NODE_NAME) := L_INT_AMEND_NODES(I);
      END LOOP;
      DBG('In Fn_Get_Amendable_Details 2 :' || P_SOURCE_CODE || '/' ||
          P_SOURCE_OPERATION);
      OPEN CR_AMENDABLE_FIELDS;
      LOOP
        FETCH CR_AMENDABLE_FIELDS BULK COLLECT
          INTO L_INT_AMEND_FIELDS;
        EXIT WHEN CR_AMENDABLE_FIELDS%NOTFOUND;
      END LOOP;
      CLOSE CR_AMENDABLE_FIELDS;
      L_COUNT := L_INT_AMEND_FIELDS.COUNT;
      IF L_COUNT > 0 THEN
        FOR I IN 1 .. L_COUNT LOOP
          DBG('In Fn_Get_Amendable_Details :' || L_INT_AMEND_FIELDS(I)
              .NODE_NAME || '.' || L_INT_AMEND_FIELDS(I).FIELD_NAME);
          P_AMENDABLE_FIELDS(L_INT_AMEND_FIELDS(I).NODE_NAME || '.' || L_INT_AMEND_FIELDS(I).FIELD_NAME) := L_INT_AMEND_FIELDS(I);
        END LOOP;
      END IF;
    END IF;
    DBG('In Fn_Get_Amendable_Details LAST:' || P_SOURCE_CODE || '/' ||
        P_SOURCE_OPERATION);
    RETURN TRUE;
    DBG('Returning Success From Fn_Get_Amendable_Details..');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others Of Fn_Get_Amendable_Details..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_AMENDABLE_DETAILS;

  FUNCTION FN_VALIDATE_RESTR_TEXT(P_VALUE IN VARCHAR2) RETURN VARCHAR2 IS
    L_LENGTH NUMBER(4);
    I        NUMBER;
  BEGIN
    DBG('In  Fn_Validate_Restr_Text..');
    L_LENGTH := LENGTH(P_VALUE);
    IF L_LENGTH = 0 THEN
      DBG('String is Null..');
    ELSE
      FOR I IN 1 .. L_LENGTH LOOP
        DBG('Character ' || SUBSTR(P_VALUE, I, 1));
        IF SUBSTR(P_VALUE, I, 1) NOT IN ('A',
                                         'B',
                                         'C',
                                         'D',
                                         'E',
                                         'F',
                                         'G',
                                         'H',
                                         'I',
                                         'J',
                                         'K',
                                         'L',
                                         'M',
                                         'N',
                                         'O',
                                         'P',
                                         'Q',
                                         'R',
                                         'S',
                                         'T',
                                         'U',
                                         'V',
                                         'W',
                                         'X',
                                         'Y',
                                         'Z',
                                         '0',
                                         '1',
                                         '2',
                                         '3',
                                         '4',
                                         '5',
                                         '6',
                                         '7',
                                         '8',
                                         '9',
                                         '_',
                                         '*') THEN
          DBG('Invalid Character....:' || SUBSTR(P_VALUE, I, 1));
          RETURN SUBSTR(P_VALUE, I, 1);
        END IF;
        DBG('Inside Of The Loop..');
      END LOOP;
    END IF;
    DBG('Returning Success From Fn_Close..');
    RETURN NULL;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of Fn_Close ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN '?';
  END FN_VALIDATE_RESTR_TEXT;

  FUNCTION FN_VALIDATE_RESTR_TEXT(P_VALUE      IN VARCHAR2,
                                  P_FIELD_NAME IN VARCHAR2,
                                  P_ERR_CODE   IN OUT VARCHAR2,
                                  P_ERR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_LENGTH   NUMBER(1);
    I          NUMBER;
    L_INV_CHAR VARCHAR2(32767);
  BEGIN
    DBG('In  Overloaded Fn_Validate_Restr_Text..');
    L_INV_CHAR := FN_VALIDATE_RESTR_TEXT(P_VALUE);
    IF L_INV_CHAR IS NOT NULL THEN
      P_ERR_CODE   := 'ST-VALS-014';
      P_ERR_PARAMS := L_INV_CHAR;
      RETURN FALSE;
    END IF;
    DBG('Returning Success From Overloaded Fn_Validate_Restr_Text..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of Fn_Validate_Restr_Text ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE := 'ST-OTHR-001';
      RETURN FALSE;
  END FN_VALIDATE_RESTR_TEXT;

  FUNCTION FN_MAINT_BASIC_VALIDATIONS(P_SOURCE           IN VARCHAR2,
                                      P_SOURCE_OPERATION IN VARCHAR2,
                                      P_FUNCTION_ID      IN VARCHAR2,
                                      P_ACTION_CODE      IN VARCHAR2,
                                      P_PREV_MOD_NO      IN NUMBER,
                                      P_SENT_MOD_NO      IN NUMBER,
                                      P_AUTH_STAT        IN VARCHAR2,
                                      P_RECORD_STAT      IN VARCHAR2,
                                      P_ONCE_AUTH        IN VARCHAR2,
                                      P_PREV_KEY_TAGS    IN VARCHAR2,
                                      P_PREV_KEY_VALS    IN VARCHAR2,
                                      P_KEY_ID           IN VARCHAR2,
                                      P_KEY              IN VARCHAR2,
                                      P_ERR_CODE         IN OUT VARCHAR2,
                                      P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_SQL               VARCHAR2(32767);
    L_BASE_DATA_FROM_FC VARCHAR2(1) := 'Y';
    L_MOD_NO            NUMBER;
    L_COUNT             NUMBER;
    L_MAKER             VARCHAR2(32767);
    L_TANKING_REQD      VARCHAR2(1) := 'N';
    L_AUTH_STAT         VARCHAR2(10) := 'A';
    L_PREV_KEY_TAGS     VARCHAR2(32767) := P_PREV_KEY_TAGS;
    L_PREV_KEY_VALS     VARCHAR2(32767) := P_PREV_KEY_VALS;
    L_EMPTY_ERR_TBL     OVPKS.TBL_ERROR;
    L_ERR_TBL           OVPKS.TBL_ERROR;
    L_ERR_COUNT         NUMBER;
    L_VALS_ERR_FOUND    BOOLEAN := FALSE;
    L_DUAL_AUTH_REQD    SMTB_MENU.DUAL_AUTH_REQD%TYPE;
  BEGIN
    DBG('In Fn_Maint_Basic_Validations..:' || P_SENT_MOD_NO || '/' ||
        P_PREV_MOD_NO);
    DBG(' Keys /Vals :' || P_PREV_KEY_TAGS || ':' || P_PREV_KEY_VALS);
    L_PREV_KEY_TAGS := LTRIM(RTRIM(L_PREV_KEY_TAGS, '~'), '~');
    L_PREV_KEY_VALS := LTRIM(RTRIM(L_PREV_KEY_VALS, '~'), '~');
  
    IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
      DBG('Failed in FRC bec of - ' || P_ERR_CODE);
      DBG('Exception was not raised previously..instead handled..dng the same..');
      L_TANKING_REQD := 'N';
      P_ERR_CODE     := NULL;
      P_ERR_PARAMS   := NULL;
    ELSE
      DBG('Returned success from FRC..');
      L_TANKING_REQD := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.TANK_MODIFICATIONS;
    END IF;
    DBG('Value of l_Tanking_Reqd is - ' || L_TANKING_REQD);
  
    L_TANKING_REQD := NVL(L_TANKING_REQD, 'N');
  
    IF P_SOURCE NOT IN ('FLEXCUBE', 'FLEXNOTIF') THEN
      BEGIN
        SELECT BASE_DATA_FROM_FC
          INTO L_BASE_DATA_FROM_FC
          FROM COTMS_SOURCE
         WHERE SOURCE_CODE = P_SOURCE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed in Selecting Source ' || P_SOURCE);
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-VALS-002';
          P_ERR_PARAMS := P_SOURCE;
          RETURN FALSE;
      END;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      IF P_SENT_MOD_NO IS NULL THEN
        IF NVL(L_BASE_DATA_FROM_FC, 'N') = 'Y' THEN
          PR_LOG_ERROR(P_SOURCE,
                       P_FUNCTION_ID,
                       'ST-MAND-004',
                       '@EDTMS_COMMODITY_PRICE_MASTER.MOD_NO');
        END IF;
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_CLOSE,
                         CSPKS_REQ_GLOBAL.P_REOPEN) THEN
      IF NVL(L_BASE_DATA_FROM_FC, 'N') = 'Y' THEN
        IF P_SENT_MOD_NO IS NOT NULL THEN
        
          IF NVL(P_SENT_MOD_NO, 1) <= NVL(P_PREV_MOD_NO, 1) THEN
            DBG('Mod Number Mismatch..');
            PR_LOG_ERROR(P_SOURCE,
                         P_FUNCTION_ID,
                         'ST-VALS-008',
                         P_SENT_MOD_NO || '~' || P_PREV_MOD_NO);
          END IF;
        END IF;
      ELSE
        IF P_SENT_MOD_NO IS NOT NULL THEN
        
          IF NVL(P_SENT_MOD_NO, 1) <= NVL(P_PREV_MOD_NO, 1) THEN
            DBG('Mod Number Mismatch..');
            PR_LOG_ERROR(P_SOURCE,
                         P_FUNCTION_ID,
                         'ST-VALS-008',
                         P_SENT_MOD_NO || '~' || P_SENT_MOD_NO);
          END IF;
        END IF;
      END IF;
    END IF;
  
    IF L_PREV_KEY_TAGS IS NOT NULL THEN
      DBG('Call From Newly generated Code..');
      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
        IF G_MODIFY_CHANGED_TO_NEW THEN
          DBG('Case of Modify Coming as New..');
          IF L_PREV_KEY_VALS IS NULL THEN
            DBG('Record Does not Exist..');
            PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-002', P_KEY);
          END IF;
        ELSE
          DBG('New..');
          IF L_PREV_KEY_VALS IS NOT NULL THEN
            DBG('Record Already Exists..');
            PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-001', P_KEY);
          END IF;
        END IF;
      
      ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                              CSPKS_REQ_GLOBAL.P_MODIFY,
                              CSPKS_REQ_GLOBAL.P_AUTH,
                              CSPKS_REQ_GLOBAL.P_CLOSE,
                              CSPKS_REQ_GLOBAL.P_REOPEN,
                              CSPKS_REQ_GLOBAL.P_QUERY,
                              CSPKS_REQ_GLOBAL.P_DELETE) THEN
      
        DBG('Other Actions..');
        IF L_PREV_KEY_VALS IS NULL THEN
          DBG('Record Does not Exist..');
          PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-002', P_KEY);
        END IF;
      END IF;
    ELSE
      DBG('Call From old generated Code, Overloaded Vals..');
      IF G_MODIFY_CHANGED_TO_NEW THEN
        DBG('Removing ST-VALS-001..');
        L_ERR_TBL         := OVPKS.GL_TBLERROR;
        OVPKS.GL_TBLERROR := L_EMPTY_ERR_TBL;
        L_ERR_COUNT       := L_ERR_TBL.COUNT;
        IF L_ERR_COUNT > 0 THEN
          FOR I IN 1 .. L_ERR_COUNT LOOP
            DBG('Error while Untanking :' || L_ERR_TBL(I).ERR_CODE);
            IF NVL(L_ERR_TBL(I).ERR_CODE, '*') <> 'ST-VALS-001' THEN
              OVPKS.PR_APPENDTBL(L_ERR_TBL(I).ERR_CODE,
                                 L_ERR_TBL(I).PARAMS);
            ELSE
              L_VALS_ERR_FOUND := TRUE;
            END IF;
          END LOOP;
        END IF;
      
        IF NOT L_VALS_ERR_FOUND THEN
          DBG('ST-VALS-001 Should have been there .. Missing means Record does not Exist..Raising ST-VALS-002..');
          DBG('Record Does not Exist..');
          PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-002', P_KEY);
        END IF;
      END IF;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      IF L_BASE_DATA_FROM_FC <> 'Y' THEN
        IF NVL(P_AUTH_STAT, 'X') <> 'A' THEN
          DBG('Record is Not in Authorized State..');
          PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-003', P_KEY);
        END IF;
      END IF;
      IF NVL(P_RECORD_STAT, 'X') <> 'O' THEN
        DBG('Record is Not in Open State..');
        PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-006', P_KEY);
      END IF;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      IF NVL(P_AUTH_STAT, 'X') <> 'U' THEN
        DBG('Record is Not in Unauthorized State..');
        PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-004', P_KEY);
      END IF;
    
      IF L_TANKING_REQD = 'Y' THEN
        SELECT AUTH_STAT
          INTO L_AUTH_STAT
          FROM STTB_RECORD_MASTER
         WHERE KEY_ID = P_KEY_ID;
        IF NVL(L_AUTH_STAT, 'U') <> 'U' THEN
          DBG('Record is Not in Unauthorized State..');
          PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-004', P_KEY);
        END IF;
      END IF;
    
      IF NVL(L_BASE_DATA_FROM_FC, 'N') = 'Y' THEN
        IF P_SENT_MOD_NO IS NULL THEN
          L_MOD_NO := P_PREV_MOD_NO;
        ELSE
          L_MOD_NO := P_SENT_MOD_NO;
        END IF;
      
        SELECT COUNT(*)
          INTO L_COUNT
          FROM STTBS_RECORD_LOG
         WHERE KEY_ID = P_KEY_ID
           AND NVL(AUTH_STAT, 'A') = 'U'
           AND NVL(MAKER_ID, '??') = GLOBAL.USER_ID
           AND MOD_NO <= L_MOD_NO;
        IF L_COUNT > 0 THEN
          DBG('Maker Cannot Authorize The Record..');
          PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-100', P_KEY_ID);
        END IF;
      
        SELECT COUNT(*)
          INTO L_COUNT
          FROM STTBS_RECORD_LOG
         WHERE KEY_ID = P_KEY_ID
           AND NVL(AUTH_STAT, 'A') = 'U'
              
           AND MOD_NO <= L_MOD_NO;
        IF L_COUNT = 0 THEN
          DBG('No Record Found for this combination');
          PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-129', P_KEY_ID);
        END IF;
      
        BEGIN
          SELECT NVL(DUAL_AUTH_REQD, 'N')
            INTO L_DUAL_AUTH_REQD
            FROM SMTB_MENU
           WHERE FUNCTION_ID = P_FUNCTION_ID;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Selecting Dual AUth required Flag..');
            L_DUAL_AUTH_REQD := 'N';
        END;
      
        DBG('Dual auth required? ' || L_DUAL_AUTH_REQD);
        IF L_DUAL_AUTH_REQD = 'Y' THEN
          DBG('Check for verifier coming to authorize the record');
          DBG('Global.User_Id>>' || GLOBAL.USER_ID);
          SELECT COUNT(*)
            INTO L_COUNT
            FROM STTBS_RECORD_LOG
           WHERE KEY_ID = P_KEY_ID
             AND NVL(AUTH_STAT, 'A') = 'U'
             AND NVL(FIRST_AUTH_STAT, 'A') = 'A'
             AND NVL(FIRST_CHECKER_ID, '??') = GLOBAL.USER_ID
             AND MOD_NO <= L_MOD_NO;
        
          IF L_COUNT > 0 THEN
            DBG('Verifier Cannot Authorize The Record..');
            PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-103', P_KEY_ID);
          END IF;
        
        END IF;
      
        SELECT COUNT(*)
          INTO L_COUNT
          FROM STTBS_RECORD_LOG
         WHERE KEY_ID = P_KEY_ID
              
           AND NVL(FIRST_AUTH_STAT, 'A') = 'U'
           AND MOD_NO <= L_MOD_NO;
      
        IF L_COUNT > 0 THEN
          DBG('Some Modifications are Pending For First Authorization..');
          PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-101', P_KEY_ID);
        END IF;
      
      END IF;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
      IF NVL(P_AUTH_STAT, 'X') <> 'A' THEN
        DBG('Record Is Not In Authorized State..');
        PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-003', P_KEY);
      END IF;
    
      IF NVL(P_RECORD_STAT, 'X') <> 'O' THEN
        DBG('Record Is Not In Open State..');
        PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-006', P_KEY);
      END IF;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
      IF NVL(P_AUTH_STAT, 'X') <> 'A' THEN
        DBG('Record Is Not In Authorized State..');
        PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-003', P_KEY);
      END IF;
      IF NVL(P_RECORD_STAT, 'X') <> 'C' THEN
        DBG('Record Is Not In Closed State..');
        PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-005', P_KEY);
      END IF;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
      IF NVL(P_ONCE_AUTH, 'Y') = 'Y' THEN
        DBG('Record Is Authorized Once And Hence Cannot Be Deleted..');
        PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-007', P_KEY);
      END IF;
      IF NVL(P_AUTH_STAT, 'X') <> 'U' THEN
        DBG('Record Is Not In Unauthorized State..');
        PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-004', P_KEY);
      END IF;
    
      IF L_TANKING_REQD = 'Y' THEN
        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM STTBS_RECORD_LOG
           WHERE KEY_ID = P_KEY_ID
             AND NVL(AUTH_STAT, 'A') = 'U'
             AND NVL(MAKER_ID, '??') <> GLOBAL.USER_ID
             AND MOD_NO <= P_PREV_MOD_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed In Selcting The Recent Maker..');
            L_COUNT := 1;
        END;
      
      ELSE
      
        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM STTBS_RECORD_LOG
           WHERE KEY_ID = P_KEY_ID
             AND NVL(AUTH_STAT, 'A') = 'U'
             AND NVL(MAKER_ID, '??') <> GLOBAL.USER_ID
             AND MOD_NO = P_PREV_MOD_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed In Selcting The Recent Maker..');
            L_COUNT := 1;
        END;
      END IF;
    
      IF L_COUNT > 0 THEN
        DBG('Only Maker Can Delete The Record..');
        PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-010', P_KEY);
      END IF;
    
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_VERSION_DELETE THEN
      IF P_SENT_MOD_NO IS NULL THEN
        L_MOD_NO := P_PREV_MOD_NO;
      ELSE
        L_MOD_NO := P_SENT_MOD_NO;
      END IF;
      SELECT COUNT(*)
        INTO L_COUNT
        FROM STTBS_RECORD_LOG
       WHERE KEY_ID = P_KEY_ID
         AND NVL(AUTH_STAT, 'A') = 'U'
         AND NVL(MAKER_ID, '??') <> GLOBAL.USER_ID
         AND MOD_NO >= L_MOD_NO;
      IF L_COUNT > 0 THEN
        DBG('Only Maker Can Delete The Record..');
        PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-VALS-010', P_KEY);
      END IF;
    END IF;
    DBG('Returning Success From Fn_Maint_Basic_Validations..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of Fn_Maint_Basic_Validations ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE := 'ST-OTHR-001';
      RETURN FALSE;
  END FN_MAINT_BASIC_VALIDATIONS;

  FUNCTION FN_MAINT_BASIC_VALIDATIONS(P_SOURCE           IN VARCHAR2,
                                      P_SOURCE_OPERATION IN VARCHAR2,
                                      P_FUNCTION_ID      IN VARCHAR2,
                                      P_ACTION_CODE      IN VARCHAR2,
                                      P_PREV_MOD_NO      IN NUMBER,
                                      P_SENT_MOD_NO      IN NUMBER,
                                      P_AUTH_STAT        IN VARCHAR2,
                                      P_RECORD_STAT      IN VARCHAR2,
                                      P_ONCE_AUTH        IN VARCHAR2,
                                      P_KEY_ID           IN VARCHAR2,
                                      P_KEY              IN VARCHAR2,
                                      P_ERR_CODE         IN OUT VARCHAR2,
                                      P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_PREV_KEY_TAGS VARCHAR2(32767);
    L_PREV_KEY_VALS VARCHAR2(32767);
  BEGIN
    DBG('In Fn_Maint_Basic_Validations Old..');
    IF NOT FN_MAINT_BASIC_VALIDATIONS(P_SOURCE,
                                      P_SOURCE_OPERATION,
                                      P_FUNCTION_ID,
                                      P_ACTION_CODE,
                                      P_PREV_MOD_NO,
                                      P_SENT_MOD_NO,
                                      P_AUTH_STAT,
                                      P_RECORD_STAT,
                                      P_ONCE_AUTH,
                                      L_PREV_KEY_TAGS,
                                      L_PREV_KEY_VALS,
                                      P_KEY_ID,
                                      P_KEY,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Maint_Basic_Validations..');
      RETURN FALSE;
    END IF;
  
    DBG('Returning Success From Fn_Maint_Basic_Validations Old..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of Fn_Maint_Basic_Validations Old ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE := 'ST-OTHR-001';
      RETURN FALSE;
  END FN_MAINT_BASIC_VALIDATIONS;

  FUNCTION FN_MAINT_OPERATIONS(P_SOURCE           IN VARCHAR2,
                               P_SOURCE_OPERATION IN VARCHAR2,
                               P_FUNCTION_ID      IN VARCHAR2,
                               P_ACTION_CODE      IN VARCHAR2,
                               P_MASTER_TABLE     IN VARCHAR2,
                               P_ROW_ID           IN ROWID,
                               P_MOD_NO           IN NUMBER,
                               P_MAKER_STAMP      IN DATE,
                               P_CHECKER_STAMP    IN DATE,
                               P_KEY_ID           IN VARCHAR2,
                               P_KEY              IN VARCHAR2,
                               P_ERR_CODE         IN OUT VARCHAR2,
                               P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_SQL          VARCHAR2(32767);
    L_COUNT        NUMBER;
    L_ONCE_AUTH    VARCHAR2(1) := 'Y';
    L_AUTH_STAT    VARCHAR2(1) := 'U';
    L_MAKER        VARCHAR2(100);
    L_MAKER_STAMP  DATE;
    L_TANKING_REQD VARCHAR2(1) := 'N';
  
  BEGIN
    DBG('In Fn_Maint_Operations..:' || P_ROW_ID || '/' || P_MOD_NO || '/' ||
        P_KEY_ID);
  
    IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
      DBG('Failed in FRC bec of - ' || P_ERR_CODE);
      DBG('Exception was not raised previously..instead handled..dng the same..');
      L_TANKING_REQD := 'N';
      P_ERR_CODE     := NULL;
      P_ERR_PARAMS   := NULL;
    ELSE
      DBG('Returned success from FRC..');
      L_TANKING_REQD := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.TANK_MODIFICATIONS;
    END IF;
    DBG('Value of l_Tanking_Reqd is - ' || L_TANKING_REQD);
  
    L_TANKING_REQD := NVL(L_TANKING_REQD, 'N');
    IF L_TANKING_REQD = 'Y' THEN
      IF CSPKS_REQ_GLOBAL.FN_UNTANKING THEN
        DBG('Untanking Case..');
        BEGIN
          SELECT MAKER_ID, MAKER_DT_STAMP
            INTO L_MAKER, L_MAKER_STAMP
            FROM STTB_RECORD_LOG
           WHERE KEY_ID = P_KEY_ID
             AND MOD_NO = P_MOD_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error While Selcting From Record Log..');
            L_MAKER       := GLOBAL.USER_ID;
            L_MAKER_STAMP := FN_MNTSTAMP;
        END;
        L_MAKER       := NVL(L_MAKER, GLOBAL.USER_ID);
        L_MAKER_STAMP := NVL(L_MAKER_STAMP, FN_MNTSTAMP);
      ELSE
        DBG('Normal Case ..');
        L_MAKER       := GLOBAL.USER_ID;
        L_MAKER_STAMP := FN_MNTSTAMP;
      END IF;
    ELSE
      DBG('Non Tanking Case ..');
      L_MAKER       := GLOBAL.USER_ID;
      L_MAKER_STAMP := FN_MNTSTAMP;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      L_SQL := 'SELECT COUNT(*) FROM sttb_record_log WHERE key_id = :1 and mod_no > :2  AND auth_stat = ''U''';
      DBG('Dynamic Sql :' || L_SQL);
      EXECUTE IMMEDIATE L_SQL
        INTO L_COUNT
        USING P_KEY_ID, NVL(P_MOD_NO, 1);
      DBG('Unauth Count :' || L_COUNT);
      IF L_TANKING_REQD = 'N' THEN
        IF L_COUNT > 0 THEN
          L_AUTH_STAT := 'U';
        ELSE
          L_AUTH_STAT := 'A';
        END IF;
      ELSE
        L_AUTH_STAT := 'A';
      END IF;
      DBG('Auth Stat Count :' || L_AUTH_STAT);
    
      L_SQL := 'UPDATE ' || DBMS_ASSERT.SQL_OBJECT_NAME(P_MASTER_TABLE) ||
               ' SET     auth_stat         = :1,' ||
               '        once_auth         = :2,' ||
               '        checker_id         = :3,' ||
               '        checker_dt_stamp   = :4  ' ||
               'WHERE   rowid            = :5';
      DBG('Dynamic Sql :' || L_SQL);
    
      IF L_AUTH_STAT = 'A' THEN
      
        EXECUTE IMMEDIATE L_SQL
          USING NVL(L_AUTH_STAT, 'U'), NVL(L_ONCE_AUTH, 'N'), GLOBAL.USER_ID, FN_MNTSTAMP, P_ROW_ID;
      
      ELSE
        EXECUTE IMMEDIATE L_SQL
          USING NVL(L_AUTH_STAT, 'U'), NVL(L_ONCE_AUTH, 'N'), '', '', P_ROW_ID;
      END IF;
    
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
    
      L_SQL := 'UPDATE ' || DBMS_ASSERT.SQL_OBJECT_NAME(P_MASTER_TABLE) ||
               ' SET     record_stat      =''C'' , mod_no = :1 ,' ||
               '        auth_stat         = ''U'',' ||
               '        maker_id         = :2,' ||
               '        maker_dt_stamp   = :3 ,checker_id = NULL , checker_dt_stamp = NULL ' ||
               'WHERE   rowid  = :4';
    
      DBG('Dynamic Sql :' || L_SQL);
      EXECUTE IMMEDIATE L_SQL
        USING P_MOD_NO, L_MAKER, L_MAKER_STAMP, P_ROW_ID;
    
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
    
      L_SQL := 'UPDATE ' || DBMS_ASSERT.SQL_OBJECT_NAME(P_MASTER_TABLE) ||
               ' SET     record_stat      =''O'' , mod_no = :1 ,' ||
               '        auth_stat         = ''U'',' ||
               '        maker_id         = :2,' ||
               '        maker_dt_stamp   = :3 ,checker_id = NULL , checker_dt_stamp = NULL ' ||
               'WHERE   rowid  = :4';
    
      DBG('Dynamic Sql :' || L_SQL);
      EXECUTE IMMEDIATE L_SQL
        USING P_MOD_NO, L_MAKER, L_MAKER_STAMP, P_ROW_ID;
    END IF;
    RETURN TRUE;
    DBG('Returning Success From Fn_Maint_Operations..');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of Fn_Maint_Operations ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE := 'ST-OTHR-001';
      RETURN FALSE;
  END FN_MAINT_OPERATIONS;

  FUNCTION FN_UPDATE_RESPONSE(P_MSG_ID       IN VARCHAR2,
                              P_MULTITRIP_ID IN VARCHAR2,
                              P_ERROR_CODE   IN OUT VARCHAR2,
                              P_ERROR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_XML    XMLTYPE;
    L_EXISTS NUMBER;
    L_LEN    NUMBER;
    L_AMT    NUMBER;
    L_RES    CLOB;
  BEGIN
    DBG('In Fn_Update_Response..');
  
    IF INSTR(CSPKS_REQ_GLOBAL.G_RES, '<?xml') = 0 THEN
    
      L_RES := '<?xml version="1.0" encoding="UTF-8"?>' ||
               CSPKS_REQ_GLOBAL.G_RES;
      L_XML := XMLTYPE(L_RES);
    
    ELSE
      DBG('In Mod No Fix..');
      L_XML := XMLTYPE(CSPKS_REQ_GLOBAL.G_RES);
      L_RES := L_XML.GETCLOBVAL();
    END IF;
    L_LEN := DBMS_LOB.GETLENGTH(L_RES);
    SELECT EXISTSNODE(L_XML, '/FCUBS_RES_ENV/FCUBS_HEADER/MULTITRIPID')
      INTO L_EXISTS
      FROM DUAL;
    IF L_EXISTS = 1 THEN
      SELECT UPDATEXML(L_XML,
                       '/FCUBS_RES_ENV/FCUBS_HEADER/MULTITRIPID',
                       XMLTYPE('<MULTITRIPID>' || P_MULTITRIP_ID ||
                               '</MULTITRIPID>'))
        INTO L_XML
        FROM DUAL;
    ELSE
      SELECT APPENDCHILDXML(L_XML,
                            '/FCUBS_RES_ENV/FCUBS_HEADER',
                            XMLTYPE('<MULTITRIPID>' || P_MULTITRIP_ID ||
                                    '</MULTITRIPID>'))
        INTO L_XML
        FROM DUAL;
    END IF;
    SELECT EXISTSNODE(L_XML, '/FCUBS_RES_ENV/FCUBS_HEADER/MSGID')
      INTO L_EXISTS
      FROM DUAL;
    IF L_EXISTS = 1 THEN
      SELECT UPDATEXML(L_XML,
                       '/FCUBS_RES_ENV/FCUBS_HEADER/MSGID',
                       XMLTYPE('<MSGID>' || P_MSG_ID || '</MSGID>'))
        INTO L_XML
        FROM DUAL;
    ELSE
      SELECT APPENDCHILDXML(L_XML,
                            '/FCUBS_RES_ENV/FCUBS_HEADER',
                            XMLTYPE('<MSGID>' || P_MSG_ID || '</MSGID>'))
        INTO L_XML
        FROM DUAL;
    END IF;
    CSPKS_REQ_GLOBAL.G_RES := L_XML.GETCLOBVAL();
    DBG('Returning Success From Fn_Update_Response..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others Of Fn_Update_Response  ..');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_UPDATE_RESPONSE;

  FUNCTION FN_UPDATE_REC_DATA(P_SOURCE           IN VARCHAR2,
                              P_SOURCE_OPERATION IN VARCHAR2,
                              P_FUNCTION_ID      IN VARCHAR2,
                              P_AUTH_STAT        IN VARCHAR2,
                              P_CHECKER_ID       IN VARCHAR2,
                              P_CHECKER_DT_STAMP IN DATE,
                              P_ACTION_CODE      IN VARCHAR2,
                              P_ERROR_CODE       IN OUT VARCHAR2,
                              P_ERROR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    E_FAILURE_EXCEPTION EXCEPTION;
    L_XML           XMLTYPE;
    L_MASTER_RECS   VARCHAR2(32767);
    L_POST_UPL_STAT VARCHAR2(20) := 'U';
    L_ERROR         CLOB;
    L_NODE_TYPE     VARCHAR2(20) := 'B';
    L_APPEND_TO_RES BOOLEAN := FALSE;
    L_STATUS        VARCHAR2(20) := 'S';
    L_POS_1         NUMBER;
    L_POS_2         NUMBER;
    L_RES           CLOB;
  BEGIN
    DBG('In Fn_Update_Rec_Data..');
  
    IF INSTR(CSPKS_REQ_GLOBAL.G_RES, '<?xml') = 0 THEN
    
      L_RES := '<?xml version="1.0" encoding="UTF-8"?>' ||
               CSPKS_REQ_GLOBAL.G_RES;
      L_XML := XMLTYPE(L_RES);
    
    ELSE
      DBG('In Mod No Fix..1');
      L_XML := XMLTYPE(CSPKS_REQ_GLOBAL.G_RES);
    END IF;
    SELECT UPDATEXML(L_XML,
                     '/FCUBS_RES_ENV/FCUBS_HEADER/ACTION',
                     XMLTYPE('<ACTION>' || P_ACTION_CODE || '</ACTION>'))
      INTO L_XML
      FROM DUAL;
    SELECT EXTRACTVALUE(L_XML, '/FCUBS_RES_ENV/FCUBS_BODY/REC/FV')
      INTO L_MASTER_RECS
      FROM DUAL;
  
    L_POS_1 := INSTR(L_MASTER_RECS, '~', -1, 1);
    L_POS_2 := INSTR(L_MASTER_RECS, '~', -1, 2);
  
    L_MASTER_RECS := SUBSTR(L_MASTER_RECS, 1, L_POS_2 - 1) || '~' ||
                     P_AUTH_STAT || '~' ||
                     SUBSTR(L_MASTER_RECS, L_POS_1 + 1);
  
    L_POS_1 := INSTR(L_MASTER_RECS, '~', -1, 4);
    L_POS_2 := INSTR(L_MASTER_RECS, '~', -1, 5);
  
    IF P_AUTH_STAT = 'R' THEN
      L_MASTER_RECS := SUBSTR(L_MASTER_RECS, 1, L_POS_2 - 1) || '~' ||
                       TO_CHAR(P_CHECKER_DT_STAMP,
                               CSPKS_REQ_GLOBAL.G_WS_DATE_TIME_FORMAT) || '~' ||
                       SUBSTR(L_MASTER_RECS, L_POS_1 + 1);
    ELSE
    
      L_MASTER_RECS := SUBSTR(L_MASTER_RECS, 1, L_POS_2 - 1) || '~' ||
                       P_CHECKER_DT_STAMP || '~' ||
                       SUBSTR(L_MASTER_RECS, L_POS_1 + 1);
    END IF;
  
    L_POS_1 := INSTR(L_MASTER_RECS, '~', -1, 5);
    L_POS_2 := INSTR(L_MASTER_RECS, '~', -1, 6);
  
    L_MASTER_RECS := SUBSTR(L_MASTER_RECS, 1, L_POS_2 - 1) || '~' ||
                     P_CHECKER_ID || '~' ||
                     SUBSTR(L_MASTER_RECS, L_POS_1 + 1);
  
    DBG('l_Master_Recs...' || L_MASTER_RECS);
    SELECT UPDATEXML(L_XML,
                     '/FCUBS_RES_ENV/FCUBS_BODY/REC/FV',
                     XMLTYPE('<FV><![CDATA[' || L_MASTER_RECS || ']]></FV>'))
      INTO L_XML
      FROM DUAL;
    DBG('Xml Updated 1 :' || SQL%ROWCOUNT);
  
    CSPKS_REQ_UTILS.PR_GET_FINAL_ERR_CODE(P_FUNCTION_ID,
                                          P_ACTION_CODE,
                                          L_POST_UPL_STAT,
                                          P_ERROR_CODE,
                                          P_ERROR_PARAMS);
    PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, P_ERROR_CODE, P_ERROR_PARAMS);
  
    L_NODE_TYPE := 'B';
    L_ERROR     := NULL;
    IF NOT CSPKS_CREATOR.FN_CREATE_ERROR_WARNING_NODES(L_STATUS,
                                                       L_NODE_TYPE,
                                                       L_APPEND_TO_RES,
                                                       L_ERROR,
                                                       P_ERROR_CODE,
                                                       P_ERROR_PARAMS) THEN
      DBG('Failed In ..');
      RETURN FALSE;
    END IF;
    CDBG('l_Error...' || L_ERROR);
    IF L_ERROR IS NOT NULL THEN
      IF INSTR(L_ERROR, '<FCUBS_WARNING_RESP>') > 0 THEN
        SELECT UPDATEXML(L_XML,
                         '/FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP',
                         XMLTYPE(L_ERROR))
          INTO L_XML
          FROM DUAL;
        DBG('Xml Updated 2 :' || SQL%ROWCOUNT);
      END IF;
    
      IF INSTR(L_ERROR, '<FCUBS_ERROR_RESP>') > 0 THEN
        SELECT UPDATEXML(L_XML,
                         '/FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP',
                         XMLTYPE(L_ERROR))
          INTO L_XML
          FROM DUAL;
        DBG('Xml Updated 3 :' || SQL%ROWCOUNT);
      END IF;
    
    END IF;
  
    CSPKS_REQ_GLOBAL.G_RES := L_XML.GETCLOBVAL();
  
    DBG('Returning Success From Fn_Update_Rec_Data..');
    RETURN TRUE;
  EXCEPTION
    WHEN E_FAILURE_EXCEPTION THEN
      DBG('In When Failure Exception Of Fn_Update_Rec_Data..');
      RETURN FALSE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of Fn_Update_Rec_Data ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERROR_CODE   := 'ST-MTLG-001';
      P_ERROR_PARAMS := NULL;
      RETURN FALSE;
  END FN_UPDATE_REC_DATA;

  FUNCTION FN_UPDATE_RECORD_LOG(P_SOURCE           IN VARCHAR2,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_MULTI_TRIP_ID    IN VARCHAR2,
                                P_POST_UPL_STAT    IN VARCHAR2,
                                P_ERROR_CODE       IN OUT VARCHAR2,
                                P_ERROR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    E_FAILURE_EXCEPTION EXCEPTION;
    L_ADDL_INFO        CSPKS_REQ_GLOBAL.TY_ADDL_INFO;
    L_MODULE           VARCHAR2(30);
    L_FUNCTION_ID      SMTBS_MENU.FUNCTION_ID%TYPE := P_FUNCTION_ID;
    L_ACTION_CODE      VARCHAR2(20);
    L_SERVICE_NAME     VARCHAR2(100);
    L_OPERATION_CODE   VARCHAR2(100);
    L_MULTI_TRIP_ID    VARCHAR2(30);
    L_MSG_ID           VARCHAR2(30);
    L_SOURCE_OPERATION VARCHAR2(50);
    L_EXCHANGE_PATTERN VARCHAR2(50);
    L_REPLY_TYPE       VARCHAR2(1) := 'F';
    L_TYPE_STRING      VARCHAR2(1);
    L_RESP_BACKUP      CLOB;
    L_BL_AVAILABLE     VARCHAR2(1);
    L_FUNC_TYPE        VARCHAR2(32767);
    L_KEY_ID           VARCHAR2(32767);
    L_MOD_NO           NUMBER;
    L_TANKING_REQD     VARCHAR2(1);
    L_STATUS           VARCHAR2(100) := 'S';
    L_SOURCE_CODE      VARCHAR2(100) := 'FLEXCUBE';
    L_BACKED_UP        BOOLEAN := FALSE;
  BEGIN
    DBG('In Fn_Update_Record_Log..');
    L_FUNC_TYPE := CSPKS_REQ_GLOBAL.FN_GET_FUNC_TYPE;
    L_KEY_ID    := CSPKS_REQ_GLOBAL.FN_GET_KEY_ID;
  
    IF L_FUNC_TYPE = 'FCCMAINTENANCE' AND P_SOURCE NOT IN ('FLEXBRANCH') THEN
      DBG('Flexcube Maintenance Function ..');
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                           CSPKS_REQ_GLOBAL.P_MODIFY,
                           CSPKS_REQ_GLOBAL.P_CLOSE,
                           CSPKS_REQ_GLOBAL.P_REOPEN) THEN
      
        IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                         P_ERROR_CODE,
                                                         P_ERROR_PARAMS) THEN
          DBG('Failed in FRC bec of - ' || P_ERROR_CODE);
          DBG('Exception was not raised previously..instead handled..dng the same..');
          L_TANKING_REQD := 'N';
          P_ERROR_CODE   := NULL;
          P_ERROR_PARAMS := NULL;
        ELSE
          DBG('Returned success from FRC..');
          L_TANKING_REQD := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.TANK_MODIFICATIONS;
        END IF;
        DBG('Value of l_Tanking_Reqd is - ' || L_TANKING_REQD);
      
        L_TANKING_REQD := NVL(L_TANKING_REQD, 'N');
      
        DBG('Record Log Updation Required..');
        CSPKS_REQ_GLOBAL.PR_RESET;
        DBG('Calling Cspks_Fidpkg_Wrapper.Fn_Process_Msg..');
        IF NOT CSPKS_REQ_WRAPPER.FN_REBUILD_TS_LIST(L_SOURCE_CODE,
                                                    P_SOURCE_OPERATION,
                                                    L_FUNCTION_ID,
                                                    P_ACTION_CODE,
                                                    L_EXCHANGE_PATTERN,
                                                    L_STATUS,
                                                    P_ERROR_CODE,
                                                    P_ERROR_PARAMS) THEN
          DBG('Failed In Cspks_Fidpkg_Wrapper_Ws.Fn_Process_Msg..');
          P_ERROR_CODE   := 'ST-MTLG-001';
          P_ERROR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
        CSPKS_REQ_GLOBAL.PR_CLOSE_TS;
      
        IF P_SOURCE <> 'FLEXCUBE' THEN
        
          IF NOT
              GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                        P_ERROR_CODE,
                                                        P_ERROR_PARAMS) THEN
            DBG('Failed in FRC bec of - ' || P_ERROR_CODE);
            DBG('Exception was not raised previously..instead handled..dng the same..');
            L_MODULE       := SUBSTR(P_FUNCTION_ID, 1, 2);
            P_ERROR_CODE   := NULL;
            P_ERROR_PARAMS := NULL;
          ELSE
            DBG('Returned success from FRC..');
            L_MODULE := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.MODULE;
          END IF;
          DBG('Value of l_Module is - ' || L_MODULE);
        
          CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') := P_FUNCTION_ID;
          CSPKS_REQ_GLOBAL.G_HEADER('MODULE') := L_MODULE;
          CSPKS_REQ_GLOBAL.G_HEADER('ACTION') := P_ACTION_CODE;
        END IF;
      
        IF NOT CSPKS_CREATOR.FN_CREATE(L_SOURCE_CODE,
                                       L_ACTION_CODE,
                                       L_STATUS,
                                       L_REPLY_TYPE,
                                       P_ERROR_CODE,
                                       P_ERROR_PARAMS) THEN
          DBG('Failed in Fn_Build_Fcresponse..');
        
          RETURN FALSE;
        END IF;
        IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS('FCUBS_MSG_ID') THEN
          L_MSG_ID := CSPKS_REQ_GLOBAL.G_HEADER('FCUBS_MSG_ID');
        ELSE
          L_MSG_ID := NULL;
        END IF;
        DBG('Calling Fn_Update_Response...');
        IF NOT FN_UPDATE_RESPONSE(L_MSG_ID,
                                  P_MULTI_TRIP_ID,
                                  P_ERROR_CODE,
                                  P_ERROR_PARAMS) THEN
          DBG('Failed in Fn_Update_Response ..');
          CSPKS_REQ_GLOBAL.G_RES := L_RESP_BACKUP;
          RETURN FALSE;
        END IF;
        CSPKS_REQ_GLOBAL.PR_SET_FC_RES_BUILT(TRUE);
      
        SELECT CURR_MOD_NO
          INTO L_MOD_NO
          FROM STTB_RECORD_MASTER
         WHERE KEY_ID = L_KEY_ID;
      
        DBG('Current Modification Number :' || L_MOD_NO);
      
        UPDATE STTB_RECORD_LOG
           SET REC_DATA = CSPKS_REQ_GLOBAL.G_RES
         WHERE KEY_ID = L_KEY_ID
           AND MOD_NO = L_MOD_NO;
      
        UPDATE STTB_RECORD_LOG_VWCHG
           SET REC_DATA = CSPKS_REQ_GLOBAL.G_RES
         WHERE KEY_ID = L_KEY_ID
           AND MOD_NO = L_MOD_NO;
      
        IF P_SOURCE = 'FLEXCUBE' THEN
          CSPKS_REQ_GLOBAL.PR_SET_BUILD_RESP(FALSE);
        ELSE
          CSPKS_REQ_GLOBAL.G_RES := '';
        END IF;
      END IF;
    END IF;
    DBG('Returning Success From Fn_Update_Record_Log..');
    RETURN TRUE;
  EXCEPTION
    WHEN E_FAILURE_EXCEPTION THEN
      DBG('In When Failure Exception Of Fn_Update_Record_Log..');
      RETURN FALSE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of Fn_Update_Record_Log ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERROR_CODE   := 'ST-MTLG-001';
      P_ERROR_PARAMS := NULL;
      RETURN FALSE;
  END FN_UPDATE_RECORD_LOG;

  FUNCTION FN_MAINT_LOG(P_SOURCE           IN VARCHAR2,
                        P_SOURCE_OPERATION IN VARCHAR2,
                        P_FUNCTION_ID      IN VARCHAR2,
                        P_ACTION_CODE      IN VARCHAR2,
                        P_MULTI_TRIP_ID    IN VARCHAR2,
                        P_REQUEST_NO       IN VARCHAR2,
                        P_MASTER_NODE      IN VARCHAR2,
                        P_KEY_ID           IN VARCHAR2,
                        P_MOD_NO           IN NUMBER,
                        P_POST_UPL_STAT    IN VARCHAR2,
                        P_TANKING_STATUS   IN VARCHAR2,
                        P_RECORD_MASTER    IN STTBS_RECORD_MASTER%ROWTYPE,
                        P_ERR_CODE         IN OUT VARCHAR2,
                        P_ERR_PARAM        IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    E_FAILURE_EXCEPTION EXCEPTION;
    L_STTB_REC_LOG         STTBS_RECORD_LOG%ROWTYPE;
    L_STTB_REC_MASTER      STTBS_RECORD_MASTER%ROWTYPE := P_RECORD_MASTER;
    L_PREV_STTB_REC_MASTER STTBS_RECORD_MASTER%ROWTYPE;
    L_MASTER_NODE          VARCHAR2(100) := P_MASTER_NODE;
    L_AUTH_STAT            VARCHAR2(100);
    L_RECORD_STAT          VARCHAR2(100);
    L_PREV_LOG_REC_FOUND   BOOLEAN := FALSE;
  
    L_REMARKS          VARCHAR2(1000);
    L_DUAL_AUTH_REQD   VARCHAR2(100);
    L_FIRST_AUTH_STAT  VARCHAR2(100) := 'A';
    L_FIRST_CHECKER_ID VARCHAR2(100);
  
    L_FIRST_CHECKER_DT_STAMP DATE;
    L_CHECKER_ID             VARCHAR2(100);
    L_CHECKER_DT_STAMP       VARCHAR2(100);
    L_CURR_MAKER_ID          VARCHAR2(100);
    L_ACTION_CODE            VARCHAR2(100) := P_ACTION_CODE;
    L_CURR_MAKER_DT          DATE;
    L_TIME_STAMP             DATE := FN_MNTSTAMP;
    L_USER                   VARCHAR2(100) := GLOBAL.USER_ID;
    L_REC_MAST_COUNT         NUMBER := 0;
    L_REC_MASTER_EXISTS      BOOLEAN := TRUE;
  
  BEGIN
    DBG('In Fn_Maint_Log..:' || P_MOD_NO || '/' || P_ACTION_CODE);
  
    IF G_MODIFY_CHANGED_TO_NEW THEN
      DBG('Case of Modify being Untanked as New..');
      CSPKS_REQ_GLOBAL.PR_SET_UNTANKING(FALSE);
      IF P_TANKING_STATUS <> 'T' THEN
        DBG('Current Modification is not Tanked..');
        UPDATE STTB_RECORD_LOG
           SET TANKING_STATUS = 'P'
         WHERE KEY_ID = P_KEY_ID
           AND MOD_NO <= P_MOD_NO
           AND TANKING_STATUS = 'T';
      
        UPDATE STTB_RECORD_LOG_VWCHG
           SET TANKING_STATUS = 'P'
         WHERE KEY_ID = P_KEY_ID
           AND MOD_NO <= P_MOD_NO
           AND TANKING_STATUS = 'T';
      
      END IF;
      IF L_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
        L_ACTION_CODE := CSPKS_REQ_GLOBAL.P_MODIFY;
      END IF;
    END IF;
  
    IF NOT CSPKS_REQ_GLOBAL.FN_UNTANKING THEN
      DBG('Normal Case..');
    
      BEGIN
        SELECT *
          INTO L_PREV_STTB_REC_MASTER
          FROM STTBS_RECORD_MASTER
         WHERE KEY_ID = P_KEY_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Record Master Does not Exist..');
          L_REC_MASTER_EXISTS := FALSE;
        WHEN OTHERS THEN
          DBG('When others while selcting Record Master ..:' || P_KEY_ID);
      END;
    
      L_STTB_REC_MASTER.LATEST_AUTH_MOD_NO := NVL(L_PREV_STTB_REC_MASTER.LATEST_AUTH_MOD_NO,
                                                  0);
    
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                           CSPKS_REQ_GLOBAL.P_MODIFY,
                           CSPKS_REQ_GLOBAL.P_CLOSE,
                           CSPKS_REQ_GLOBAL.P_REOPEN) THEN
      
        IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAM) THEN
          DBG('Failed in FRC bec of - ' || P_ERR_CODE);
          DBG('Exception was not raised previously..instead handled..dng the same..');
          L_DUAL_AUTH_REQD := 'N';
          P_ERR_CODE       := NULL;
          P_ERR_PARAM      := NULL;
        ELSE
          DBG('Returned success from FRC..');
          L_DUAL_AUTH_REQD := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.DUAL_AUTH_REQD;
        END IF;
        DBG('Value of l_Dual_Auth_Reqd is - ' || L_DUAL_AUTH_REQD);
      
        L_DUAL_AUTH_REQD := NVL(L_DUAL_AUTH_REQD, 'N');
      
        IF (L_DUAL_AUTH_REQD = 'N') THEN
          IF G_DUAL_AUTH_FOUND THEN
            L_DUAL_AUTH_REQD := 'Y';
          END IF;
        END IF;
      
        IF P_POST_UPL_STAT = 'A' THEN
          L_DUAL_AUTH_REQD := 'N';
        END IF;
      
        IF L_DUAL_AUTH_REQD = 'Y' THEN
          L_FIRST_AUTH_STAT        := 'U';
          L_FIRST_CHECKER_ID       := NULL;
          L_FIRST_CHECKER_DT_STAMP := NULL;
        ELSE
          L_FIRST_AUTH_STAT        := 'A';
          L_FIRST_CHECKER_ID       := L_USER;
          L_FIRST_CHECKER_DT_STAMP := L_TIME_STAMP;
        END IF;
      
        L_STTB_REC_LOG.KEY_ID                 := P_KEY_ID;
        L_STTB_REC_LOG.MOD_NO                 := P_MOD_NO;
        L_STTB_REC_LOG.ACTION_CODE            := L_ACTION_CODE;
        L_STTB_REC_LOG.BRANCH_CODE            := GLOBAL.CURRENT_BRANCH;
        L_STTB_REC_LOG.FUNCTION_ID            := P_FUNCTION_ID;
        L_STTB_REC_LOG.TABLE_NAME             := L_MASTER_NODE;
        L_STTB_REC_LOG.REMARKS                := NULL;
        L_STTB_REC_LOG.PRINT_STAT             := NULL;
        L_STTB_REC_LOG.REC_DATA               := CSPKS_REQ_GLOBAL.G_RES;
        L_STTB_REC_LOG.RECORD_STAT            := 'N';
        L_STTB_REC_LOG.MAKER_ID               := L_USER;
        L_STTB_REC_LOG.MAKER_DT_STAMP         := L_TIME_STAMP;
        L_STTB_REC_LOG.AUTH_STAT              := 'U';
        L_STTB_REC_LOG.FIRST_AUTH_STAT        := L_FIRST_AUTH_STAT;
        L_STTB_REC_LOG.FIRST_CHECKER_ID       := L_FIRST_CHECKER_ID;
        L_STTB_REC_LOG.FIRST_CHECKER_DT_STAMP := L_FIRST_CHECKER_DT_STAMP;
        L_STTB_REC_LOG.MSG_ID                 := P_MULTI_TRIP_ID;
        L_STTB_REC_LOG.REQ_NO                 := NVL(P_REQUEST_NO, 1);
        L_STTB_REC_LOG.TANKING_STATUS         := NVL(P_TANKING_STATUS, 'N');
      
        IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS(CSPKS_REQ_GLOBAL.G_MAKER_REMARKS) THEN
          L_REMARKS := CSPKS_REQ_GLOBAL.G_HEADER(CSPKS_REQ_GLOBAL.G_MAKER_REMARKS);
        ELSE
          L_REMARKS := NULL;
        END IF;
        L_STTB_REC_LOG.MAKER_REMARKS := L_REMARKS;
      
        L_STTB_REC_MASTER.KEY_ID                 := P_KEY_ID;
        L_STTB_REC_MASTER.KEY_DEF                := G_KEY_DEF;
        L_STTB_REC_MASTER.CURR_MOD_NO            := P_MOD_NO;
        L_STTB_REC_MASTER.BRANCH_CODE            := GLOBAL.CURRENT_BRANCH;
        L_STTB_REC_MASTER.FUNCTION_ID            := P_FUNCTION_ID;
        L_STTB_REC_MASTER.TABLE_NAME             := L_MASTER_NODE;
        L_STTB_REC_MASTER.CURR_MAKER_ID          := L_USER;
        L_STTB_REC_MASTER.CURR_MAKER_DT_STAMP    := FN_MNTSTAMP;
        L_STTB_REC_MASTER.FIRST_AUTH_STAT        := L_FIRST_AUTH_STAT;
        L_STTB_REC_MASTER.FIRST_CHECKER_ID       := L_FIRST_CHECKER_ID;
        L_STTB_REC_MASTER.FIRST_CHECKER_DT_STAMP := L_FIRST_CHECKER_DT_STAMP;
        L_STTB_REC_MASTER.AUTH_STAT              := 'U';
      
        IF NVL(P_POST_UPL_STAT, 'U') = 'A' THEN
          L_STTB_REC_LOG.AUTH_STAT             := 'A';
          L_STTB_REC_LOG.CHECKER_ID            := L_USER;
          L_STTB_REC_LOG.CHECKER_DT_STAMP      := L_TIME_STAMP;
          L_STTB_REC_MASTER.AUTH_STAT          := 'A';
          L_STTB_REC_MASTER.CHECKER_ID         := L_USER;
          L_STTB_REC_MASTER.CHECKER_DT_STAMP   := L_TIME_STAMP;
          L_STTB_REC_MASTER.LATEST_AUTH_MOD_NO := P_MOD_NO;
        END IF;
      
        IF L_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
          L_STTB_REC_LOG.RECORD_STAT    := 'N';
          L_STTB_REC_MASTER.RECORD_STAT := 'O';
        ELSIF L_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
          L_STTB_REC_LOG.RECORD_STAT    := 'M';
          L_STTB_REC_MASTER.RECORD_STAT := 'O';
        ELSIF L_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
          L_STTB_REC_LOG.RECORD_STAT    := 'C';
          L_STTB_REC_MASTER.RECORD_STAT := 'C';
        ELSIF L_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
          L_STTB_REC_LOG.RECORD_STAT    := 'O';
          L_STTB_REC_MASTER.RECORD_STAT := 'O';
        END IF;
      
        DBG('Key id/Mod No: ' || L_STTB_REC_LOG.KEY_ID || '/' ||
            L_STTB_REC_LOG.MOD_NO);
      
        IF P_ACTION_CODE IN
           (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        
          IF NOT L_REC_MASTER_EXISTS THEN
            BEGIN
              INSERT INTO STTBS_RECORD_MASTER VALUES L_STTB_REC_MASTER;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed In Inserting Into Sttbs_Record_Master..');
                DBG(SQLERRM);
                RAISE E_FAILURE_EXCEPTION;
            END;
          ELSE
            UPDATE STTBS_RECORD_MASTER
               SET CURR_MOD_NO        = P_MOD_NO,
                   AUTH_STAT          = L_STTB_REC_MASTER.AUTH_STAT,
                   RECORD_STAT        = L_STTB_REC_MASTER.RECORD_STAT,
                   FIRST_AUTH_STAT    = L_STTB_REC_MASTER.FIRST_AUTH_STAT,
                   LATEST_AUTH_MOD_NO = L_STTB_REC_MASTER.LATEST_AUTH_MOD_NO,
                   CHAR_FLD_1         = L_STTB_REC_MASTER.CHAR_FLD_1,
                   CHAR_FLD_2         = L_STTB_REC_MASTER.CHAR_FLD_2,
                   CHAR_FLD_3         = L_STTB_REC_MASTER.CHAR_FLD_3,
                   CHAR_FLD_4         = L_STTB_REC_MASTER.CHAR_FLD_4,
                   CHAR_FLD_5         = L_STTB_REC_MASTER.CHAR_FLD_5,
                   CHAR_FLD_6         = L_STTB_REC_MASTER.CHAR_FLD_6,
                   CHAR_FLD_7         = L_STTB_REC_MASTER.CHAR_FLD_7,
                   CHAR_FLD_8         = L_STTB_REC_MASTER.CHAR_FLD_8,
                   CHAR_FLD_9         = L_STTB_REC_MASTER.CHAR_FLD_9,
                   CHAR_FLD_10        = L_STTB_REC_MASTER.CHAR_FLD_10,
                   CHAR_FLD_11        = L_STTB_REC_MASTER.CHAR_FLD_11,
                   CHAR_FLD_12        = L_STTB_REC_MASTER.CHAR_FLD_12,
                   CHAR_FLD_13        = L_STTB_REC_MASTER.CHAR_FLD_13,
                   CHAR_FLD_14        = L_STTB_REC_MASTER.CHAR_FLD_14,
                   CHAR_FLD_15        = L_STTB_REC_MASTER.CHAR_FLD_15,
                   CHAR_FLD_16        = L_STTB_REC_MASTER.CHAR_FLD_16,
                   CHAR_FLD_17        = L_STTB_REC_MASTER.CHAR_FLD_17,
                   CHAR_FLD_18        = L_STTB_REC_MASTER.CHAR_FLD_18,
                   CHAR_FLD_19        = L_STTB_REC_MASTER.CHAR_FLD_19,
                   CHAR_FLD_20        = L_STTB_REC_MASTER.CHAR_FLD_20
                   
                  ,
                   CHAR_FLD_21 = L_STTB_REC_MASTER.CHAR_FLD_21,
                   CHAR_FLD_22 = L_STTB_REC_MASTER.CHAR_FLD_22,
                   CHAR_FLD_23 = L_STTB_REC_MASTER.CHAR_FLD_23,
                   CHAR_FLD_24 = L_STTB_REC_MASTER.CHAR_FLD_24,
                   CHAR_FLD_25 = L_STTB_REC_MASTER.CHAR_FLD_25
                   
                  ,
                   NUM_FLD_1              = L_STTB_REC_MASTER.NUM_FLD_1,
                   NUM_FLD_2              = L_STTB_REC_MASTER.NUM_FLD_2,
                   NUM_FLD_3              = L_STTB_REC_MASTER.NUM_FLD_3,
                   NUM_FLD_4              = L_STTB_REC_MASTER.NUM_FLD_4,
                   NUM_FLD_5              = L_STTB_REC_MASTER.NUM_FLD_5,
                   NUM_FLD_6              = L_STTB_REC_MASTER.NUM_FLD_6,
                   NUM_FLD_7              = L_STTB_REC_MASTER.NUM_FLD_7,
                   NUM_FLD_8              = L_STTB_REC_MASTER.NUM_FLD_8,
                   NUM_FLD_9              = L_STTB_REC_MASTER.NUM_FLD_9,
                   NUM_FLD_10             = L_STTB_REC_MASTER.NUM_FLD_10,
                   DATE_FLD_1             = L_STTB_REC_MASTER.DATE_FLD_1,
                   DATE_FLD_2             = L_STTB_REC_MASTER.DATE_FLD_2,
                   DATE_FLD_3             = L_STTB_REC_MASTER.DATE_FLD_3,
                   DATE_FLD_4             = L_STTB_REC_MASTER.DATE_FLD_4,
                   DATE_FLD_5             = L_STTB_REC_MASTER.DATE_FLD_5,
                   DATE_FLD_6             = L_STTB_REC_MASTER.DATE_FLD_6,
                   DATE_FLD_7             = L_STTB_REC_MASTER.DATE_FLD_7,
                   DATE_FLD_8             = L_STTB_REC_MASTER.DATE_FLD_8,
                   DATE_FLD_9             = L_STTB_REC_MASTER.DATE_FLD_9,
                   DATE_FLD_10            = L_STTB_REC_MASTER.DATE_FLD_10,
                   CURR_MAKER_ID          = L_STTB_REC_MASTER.CURR_MAKER_ID,
                   CURR_MAKER_DT_STAMP    = L_STTB_REC_MASTER.CURR_MAKER_DT_STAMP,
                   FIRST_CHECKER_ID       = L_STTB_REC_LOG.FIRST_CHECKER_ID,
                   FIRST_CHECKER_DT_STAMP = L_STTB_REC_LOG.FIRST_CHECKER_DT_STAMP,
                   CHECKER_ID             = L_STTB_REC_MASTER.CHECKER_ID,
                   CHECKER_DT_STAMP       = L_STTB_REC_MASTER.CHECKER_DT_STAMP
            
             WHERE KEY_ID = P_KEY_ID;
          END IF;
        ELSE
          UPDATE STTBS_RECORD_MASTER
             SET CURR_MOD_NO            = P_MOD_NO,
                 AUTH_STAT              = L_STTB_REC_MASTER.AUTH_STAT,
                 FIRST_AUTH_STAT        = L_STTB_REC_MASTER.FIRST_AUTH_STAT,
                 RECORD_STAT            = L_STTB_REC_MASTER.RECORD_STAT,
                 LATEST_AUTH_MOD_NO     = NVL(L_STTB_REC_MASTER.LATEST_AUTH_MOD_NO,
                                              LATEST_AUTH_MOD_NO),
                 CURR_MAKER_ID          = L_STTB_REC_MASTER.CURR_MAKER_ID,
                 CURR_MAKER_DT_STAMP    = L_STTB_REC_MASTER.CURR_MAKER_DT_STAMP,
                 FIRST_CHECKER_ID       = L_STTB_REC_LOG.FIRST_CHECKER_ID,
                 FIRST_CHECKER_DT_STAMP = L_STTB_REC_LOG.FIRST_CHECKER_DT_STAMP,
                 CHECKER_ID             = L_STTB_REC_MASTER.CHECKER_ID,
                 CHECKER_DT_STAMP       = L_STTB_REC_MASTER.CHECKER_DT_STAMP
           WHERE KEY_ID = P_KEY_ID;
        
          IF SQL%ROWCOUNT = 0 THEN
            DBG('No Record Found In Maintenance Master..???');
            BEGIN
              INSERT INTO STTBS_RECORD_MASTER VALUES L_STTB_REC_MASTER;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed In Inserting Into Sttbs_Record_Master..');
                DBG(SQLERRM);
                RAISE E_FAILURE_EXCEPTION;
            END;
          END IF;
        END IF;
      
        IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                             CSPKS_REQ_GLOBAL.P_MODIFY,
                             CSPKS_REQ_GLOBAL.P_CLOSE,
                             CSPKS_REQ_GLOBAL.P_REOPEN) THEN
          DBG('Setting Record Log With Latest Summary Fields..');
          L_STTB_REC_LOG.CHAR_FLD_1  := L_STTB_REC_MASTER.CHAR_FLD_1;
          L_STTB_REC_LOG.CHAR_FLD_2  := L_STTB_REC_MASTER.CHAR_FLD_2;
          L_STTB_REC_LOG.CHAR_FLD_3  := L_STTB_REC_MASTER.CHAR_FLD_3;
          L_STTB_REC_LOG.CHAR_FLD_4  := L_STTB_REC_MASTER.CHAR_FLD_4;
          L_STTB_REC_LOG.CHAR_FLD_5  := L_STTB_REC_MASTER.CHAR_FLD_5;
          L_STTB_REC_LOG.CHAR_FLD_6  := L_STTB_REC_MASTER.CHAR_FLD_6;
          L_STTB_REC_LOG.CHAR_FLD_7  := L_STTB_REC_MASTER.CHAR_FLD_7;
          L_STTB_REC_LOG.CHAR_FLD_8  := L_STTB_REC_MASTER.CHAR_FLD_8;
          L_STTB_REC_LOG.CHAR_FLD_9  := L_STTB_REC_MASTER.CHAR_FLD_9;
          L_STTB_REC_LOG.CHAR_FLD_10 := L_STTB_REC_MASTER.CHAR_FLD_10;
          L_STTB_REC_LOG.CHAR_FLD_11 := L_STTB_REC_MASTER.CHAR_FLD_11;
          L_STTB_REC_LOG.CHAR_FLD_12 := L_STTB_REC_MASTER.CHAR_FLD_12;
          L_STTB_REC_LOG.CHAR_FLD_13 := L_STTB_REC_MASTER.CHAR_FLD_13;
          L_STTB_REC_LOG.CHAR_FLD_14 := L_STTB_REC_MASTER.CHAR_FLD_14;
          L_STTB_REC_LOG.CHAR_FLD_15 := L_STTB_REC_MASTER.CHAR_FLD_15;
          L_STTB_REC_LOG.CHAR_FLD_16 := L_STTB_REC_MASTER.CHAR_FLD_16;
          L_STTB_REC_LOG.CHAR_FLD_17 := L_STTB_REC_MASTER.CHAR_FLD_17;
          L_STTB_REC_LOG.CHAR_FLD_18 := L_STTB_REC_MASTER.CHAR_FLD_18;
          L_STTB_REC_LOG.CHAR_FLD_19 := L_STTB_REC_MASTER.CHAR_FLD_19;
          L_STTB_REC_LOG.CHAR_FLD_20 := L_STTB_REC_MASTER.CHAR_FLD_20;
        
          L_STTB_REC_LOG.CHAR_FLD_21 := L_STTB_REC_MASTER.CHAR_FLD_21;
          L_STTB_REC_LOG.CHAR_FLD_22 := L_STTB_REC_MASTER.CHAR_FLD_22;
          L_STTB_REC_LOG.CHAR_FLD_23 := L_STTB_REC_MASTER.CHAR_FLD_23;
          L_STTB_REC_LOG.CHAR_FLD_24 := L_STTB_REC_MASTER.CHAR_FLD_24;
          L_STTB_REC_LOG.CHAR_FLD_25 := L_STTB_REC_MASTER.CHAR_FLD_25;
        
          L_STTB_REC_LOG.NUM_FLD_1   := L_STTB_REC_MASTER.NUM_FLD_1;
          L_STTB_REC_LOG.NUM_FLD_2   := L_STTB_REC_MASTER.NUM_FLD_2;
          L_STTB_REC_LOG.NUM_FLD_3   := L_STTB_REC_MASTER.NUM_FLD_3;
          L_STTB_REC_LOG.NUM_FLD_4   := L_STTB_REC_MASTER.NUM_FLD_4;
          L_STTB_REC_LOG.NUM_FLD_5   := L_STTB_REC_MASTER.NUM_FLD_5;
          L_STTB_REC_LOG.NUM_FLD_6   := L_STTB_REC_MASTER.NUM_FLD_6;
          L_STTB_REC_LOG.NUM_FLD_7   := L_STTB_REC_MASTER.NUM_FLD_7;
          L_STTB_REC_LOG.NUM_FLD_8   := L_STTB_REC_MASTER.NUM_FLD_8;
          L_STTB_REC_LOG.NUM_FLD_9   := L_STTB_REC_MASTER.NUM_FLD_9;
          L_STTB_REC_LOG.NUM_FLD_10  := L_STTB_REC_MASTER.NUM_FLD_10;
          L_STTB_REC_LOG.DATE_FLD_1  := L_STTB_REC_MASTER.DATE_FLD_1;
          L_STTB_REC_LOG.DATE_FLD_2  := L_STTB_REC_MASTER.DATE_FLD_2;
          L_STTB_REC_LOG.DATE_FLD_3  := L_STTB_REC_MASTER.DATE_FLD_3;
          L_STTB_REC_LOG.DATE_FLD_4  := L_STTB_REC_MASTER.DATE_FLD_4;
          L_STTB_REC_LOG.DATE_FLD_5  := L_STTB_REC_MASTER.DATE_FLD_5;
          L_STTB_REC_LOG.DATE_FLD_6  := L_STTB_REC_MASTER.DATE_FLD_6;
          L_STTB_REC_LOG.DATE_FLD_7  := L_STTB_REC_MASTER.DATE_FLD_7;
          L_STTB_REC_LOG.DATE_FLD_8  := L_STTB_REC_MASTER.DATE_FLD_8;
          L_STTB_REC_LOG.DATE_FLD_9  := L_STTB_REC_MASTER.DATE_FLD_9;
          L_STTB_REC_LOG.DATE_FLD_10 := L_STTB_REC_MASTER.DATE_FLD_10;
        END IF;
      
        BEGIN
          INSERT INTO STTB_RECORD_LOG VALUES L_STTB_REC_LOG;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Exception Raised While Populating Record Log ::' ||
                SQLERRM);
            RAISE E_FAILURE_EXCEPTION;
        END;
      
        BEGIN
          INSERT INTO STTB_RECORD_LOG_VWCHG VALUES L_STTB_REC_LOG;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Exception Raised While Populating Record Log View change::' ||
                SQLERRM);
            RAISE E_FAILURE_EXCEPTION;
        END;
      
      ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      
        IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS(CSPKS_REQ_GLOBAL.G_CHECKER_REMARKS) THEN
          L_REMARKS := CSPKS_REQ_GLOBAL.G_HEADER(CSPKS_REQ_GLOBAL.G_CHECKER_REMARKS);
        ELSE
          L_REMARKS := NULL;
        END IF;
      
        UPDATE STTB_RECORD_LOG
           SET AUTH_STAT        = 'A',
               TANKING_STATUS   = 'P',
               CHECKER_ID       = L_USER,
               CHECKER_DT_STAMP = L_TIME_STAMP,
               CHECKER_REMARKS  = L_REMARKS
         WHERE KEY_ID = P_KEY_ID
           AND AUTH_STAT = 'U'
           AND MOD_NO <= P_MOD_NO;
      
        UPDATE STTBS_RECORD_MASTER
           SET LATEST_AUTH_MOD_NO = P_MOD_NO
        
         WHERE KEY_ID = P_KEY_ID;
      
        UPDATE STTB_RECORD_LOG_VWCHG
           SET AUTH_STAT        = 'A',
               TANKING_STATUS   = 'P',
               CHECKER_ID       = L_USER,
               CHECKER_DT_STAMP = L_TIME_STAMP,
               CHECKER_REMARKS  = L_REMARKS
         WHERE KEY_ID = P_KEY_ID
           AND AUTH_STAT = 'U'
           AND MOD_NO <= P_MOD_NO;
      
        UPDATE STTBS_RECORD_MASTER
           SET AUTH_STAT        = 'A',
               CHECKER_ID       = L_USER,
               CHECKER_DT_STAMP = L_TIME_STAMP
         WHERE KEY_ID = P_KEY_ID
           AND CURR_MOD_NO = LATEST_AUTH_MOD_NO;
      
      ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
      
        DELETE STTB_RECORD_LOG WHERE KEY_ID = P_KEY_ID;
      
        DELETE STTB_RECORD_LOG_VWCHG WHERE KEY_ID = P_KEY_ID;
      
        DELETE STTB_FIELD_LOG WHERE KEY_ID = P_KEY_ID;
      
        DELETE STTBS_RECORD_MASTER WHERE KEY_ID = P_KEY_ID;
      
      ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_VERSION_DELETE THEN
        L_PREV_LOG_REC_FOUND := FALSE;
        DELETE STTB_RECORD_LOG
         WHERE KEY_ID = P_KEY_ID
           AND NVL(AUTH_STAT, 'U') IN ('U', 'R')
           AND MOD_NO >= NVL(P_MOD_NO, 0);
      
        DELETE STTB_RECORD_LOG_VWCHG
         WHERE KEY_ID = P_KEY_ID
           AND NVL(AUTH_STAT, 'U') IN ('U', 'R')
           AND MOD_NO >= NVL(P_MOD_NO, 0);
      
        DELETE STTB_FIELD_LOG
         WHERE KEY_ID = P_KEY_ID
           AND MOD_NO >= NVL(P_MOD_NO, 0);
      
        IF P_MOD_NO = 1 THEN
          DELETE STTB_RECORD_MASTER WHERE KEY_ID = P_KEY_ID;
        END IF;
      
        BEGIN
          SELECT *
            INTO L_STTB_REC_LOG
            FROM STTB_RECORD_LOG
           WHERE KEY_ID = P_KEY_ID
             AND MOD_NO = P_MOD_NO - 1;
          L_PREV_LOG_REC_FOUND := TRUE;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed In Selecting The Previous Status..');
            L_AUTH_STAT       := 'A';
            L_RECORD_STAT     := 'O';
            L_FIRST_AUTH_STAT := 'A';
        END;
      
        L_AUTH_STAT   := NVL(L_STTB_REC_LOG.AUTH_STAT, 'A');
        L_RECORD_STAT := NVL(L_STTB_REC_LOG.RECORD_STAT, 'O');
      
        IF L_RECORD_STAT <> 'C' THEN
          L_RECORD_STAT := 'O';
        END IF;
      
        L_FIRST_AUTH_STAT        := NVL(L_STTB_REC_LOG.FIRST_AUTH_STAT, 'A');
        L_FIRST_CHECKER_ID       := L_STTB_REC_LOG.FIRST_CHECKER_ID;
        L_FIRST_CHECKER_DT_STAMP := L_STTB_REC_LOG.FIRST_CHECKER_DT_STAMP;
        L_CURR_MAKER_ID          := L_STTB_REC_LOG.MAKER_ID;
        L_CURR_MAKER_DT          := L_STTB_REC_LOG.MAKER_DT_STAMP;
      
        DBG('Auth And Record Statuses After Version Delete..:' ||
            L_AUTH_STAT || '/' || L_RECORD_STAT);
      
        IF L_PREV_LOG_REC_FOUND THEN
          DBG('Updating Record Master With Prevuious Data..');
          UPDATE STTBS_RECORD_MASTER
             SET AUTH_STAT              = L_AUTH_STAT,
                 RECORD_STAT            = L_RECORD_STAT,
                 CURR_MAKER_ID          = L_CURR_MAKER_ID,
                 CURR_MAKER_DT_STAMP    = L_CURR_MAKER_DT,
                 FIRST_AUTH_STAT        = L_FIRST_AUTH_STAT,
                 FIRST_CHECKER_ID       = L_FIRST_CHECKER_ID,
                 FIRST_CHECKER_DT_STAMP = L_FIRST_CHECKER_DT_STAMP,
                 CURR_MOD_NO            = P_MOD_NO - 1,
                 CHAR_FLD_1             = L_STTB_REC_LOG.CHAR_FLD_1,
                 CHAR_FLD_2             = L_STTB_REC_LOG.CHAR_FLD_2,
                 CHAR_FLD_3             = L_STTB_REC_LOG.CHAR_FLD_3,
                 CHAR_FLD_4             = L_STTB_REC_LOG.CHAR_FLD_4,
                 CHAR_FLD_5             = L_STTB_REC_LOG.CHAR_FLD_5,
                 CHAR_FLD_6             = L_STTB_REC_LOG.CHAR_FLD_6,
                 CHAR_FLD_7             = L_STTB_REC_LOG.CHAR_FLD_7,
                 CHAR_FLD_8             = L_STTB_REC_LOG.CHAR_FLD_8,
                 CHAR_FLD_9             = L_STTB_REC_LOG.CHAR_FLD_9,
                 CHAR_FLD_10            = L_STTB_REC_LOG.CHAR_FLD_10,
                 CHAR_FLD_11            = L_STTB_REC_LOG.CHAR_FLD_11,
                 CHAR_FLD_12            = L_STTB_REC_LOG.CHAR_FLD_12,
                 CHAR_FLD_13            = L_STTB_REC_LOG.CHAR_FLD_13,
                 CHAR_FLD_14            = L_STTB_REC_LOG.CHAR_FLD_14,
                 CHAR_FLD_15            = L_STTB_REC_LOG.CHAR_FLD_15,
                 CHAR_FLD_16            = L_STTB_REC_LOG.CHAR_FLD_16,
                 CHAR_FLD_17            = L_STTB_REC_LOG.CHAR_FLD_17,
                 CHAR_FLD_18            = L_STTB_REC_LOG.CHAR_FLD_18,
                 CHAR_FLD_19            = L_STTB_REC_LOG.CHAR_FLD_19,
                 CHAR_FLD_20            = L_STTB_REC_LOG.CHAR_FLD_20
                 
                ,
                 CHAR_FLD_21 = L_STTB_REC_LOG.CHAR_FLD_21,
                 CHAR_FLD_22 = L_STTB_REC_LOG.CHAR_FLD_22,
                 CHAR_FLD_23 = L_STTB_REC_LOG.CHAR_FLD_23,
                 CHAR_FLD_24 = L_STTB_REC_LOG.CHAR_FLD_24,
                 CHAR_FLD_25 = L_STTB_REC_LOG.CHAR_FLD_25
                 
                ,
                 NUM_FLD_1   = L_STTB_REC_LOG.NUM_FLD_1,
                 NUM_FLD_2   = L_STTB_REC_LOG.NUM_FLD_2,
                 NUM_FLD_3   = L_STTB_REC_LOG.NUM_FLD_3,
                 NUM_FLD_4   = L_STTB_REC_LOG.NUM_FLD_4,
                 NUM_FLD_5   = L_STTB_REC_LOG.NUM_FLD_5,
                 NUM_FLD_6   = L_STTB_REC_LOG.NUM_FLD_6,
                 NUM_FLD_7   = L_STTB_REC_LOG.NUM_FLD_7,
                 NUM_FLD_8   = L_STTB_REC_LOG.NUM_FLD_8,
                 NUM_FLD_9   = L_STTB_REC_LOG.NUM_FLD_9,
                 NUM_FLD_10  = L_STTB_REC_LOG.NUM_FLD_10,
                 DATE_FLD_1  = L_STTB_REC_LOG.DATE_FLD_1,
                 DATE_FLD_2  = L_STTB_REC_LOG.DATE_FLD_2,
                 DATE_FLD_3  = L_STTB_REC_LOG.DATE_FLD_3,
                 DATE_FLD_4  = L_STTB_REC_LOG.DATE_FLD_4,
                 DATE_FLD_5  = L_STTB_REC_LOG.DATE_FLD_5,
                 DATE_FLD_6  = L_STTB_REC_LOG.DATE_FLD_6,
                 DATE_FLD_7  = L_STTB_REC_LOG.DATE_FLD_7,
                 DATE_FLD_8  = L_STTB_REC_LOG.DATE_FLD_8,
                 DATE_FLD_9  = L_STTB_REC_LOG.DATE_FLD_9,
                 DATE_FLD_10 = L_STTB_REC_LOG.DATE_FLD_10
           WHERE KEY_ID = P_KEY_ID;
        ELSE
          DBG('Previous Log Is Not found.. Summary May show Incorrect Data..');
          UPDATE STTBS_RECORD_MASTER
             SET AUTH_STAT   = L_AUTH_STAT,
                 RECORD_STAT = L_RECORD_STAT,
                 CURR_MOD_NO = P_MOD_NO - 1
           WHERE KEY_ID = P_KEY_ID;
        END IF;
      END IF;
    
    ELSE
      DBG('Untanking Case..');
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                           CSPKS_REQ_GLOBAL.P_MODIFY,
                           CSPKS_REQ_GLOBAL.P_CLOSE,
                           CSPKS_REQ_GLOBAL.P_REOPEN) THEN
        DBG('Updating Recorg To Processed  :' || P_MOD_NO);
        UPDATE STTB_RECORD_LOG
           SET TANKING_STATUS = 'P'
         WHERE KEY_ID = P_KEY_ID
           AND MOD_NO <= P_MOD_NO
           AND TANKING_STATUS = 'T';
        DBG('Number of Records Updated.. :' || SQL%ROWCOUNT);
      
        UPDATE STTB_RECORD_LOG_VWCHG
           SET TANKING_STATUS = 'P'
         WHERE KEY_ID = P_KEY_ID
           AND MOD_NO <= P_MOD_NO
           AND TANKING_STATUS = 'T';
        DBG('Number of Records Updated.. :' || SQL%ROWCOUNT);
      
      END IF;
    
    END IF;
  
    IF NOT CSPKS_REQ_GLOBAL.FN_UNTANKING THEN
      IF NOT FN_UPDATE_RECORD_LOG(P_SOURCE,
                                  P_SOURCE_OPERATION,
                                  P_FUNCTION_ID,
                                  P_ACTION_CODE,
                                  P_MULTI_TRIP_ID,
                                  P_POST_UPL_STAT,
                                  P_ERR_CODE,
                                  P_ERR_PARAM) THEN
        DBG('Failed in Fn_Update_Record_Log..');
        RETURN FALSE;
      END IF;
    END IF;
    DBG('Returning Success From Fn_Maint_Log..');
    RETURN TRUE;
  EXCEPTION
    WHEN E_FAILURE_EXCEPTION THEN
      DBG('In Failure Exception of Fn_Maint_Log..');
      RETURN FALSE;
    WHEN OTHERS THEN
      DBG('In When Others Of Fn_Maint_Log..' || SQLERRM);
      P_ERR_CODE := 'ST-SERV-002';
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_MAINT_LOG;

  FUNCTION FN_GET_KEY_DESC(P_SOURCE      IN VARCHAR2,
                           P_FUNCTION_ID IN VARCHAR2,
                           P_KEY_DEF     IN VARCHAR2,
                           P_KEY_ID      IN VARCHAR2)
  
   RETURN VARCHAR2 IS
    L_TABLE_NAME VARCHAR2(100);
    L_KEY_DESC   VARCHAR2(100);
    I            INTEGER := 2;
    L_ITEM_DESC  VARCHAR2(32767);
    L_VALS       VARCHAR2(2000);
    L_PARAM      VARCHAR2(32767);
  BEGIN
    DBG('In  Fn_Get_Key_Desc..');
  
    L_PARAM := CSPKES_MISC.FN_GETPARAM(P_KEY_DEF, I, '~');
    L_VALS  := CSPKES_MISC.FN_GETPARAM(P_KEY_ID, I, '~');
    WHILE (L_PARAM <> 'EOPL') LOOP
      L_ITEM_DESC := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC(P_SOURCE,
                                                      P_FUNCTION_ID,
                                                      UPPER(L_PARAM));
    
      IF I = 2 THEN
        L_KEY_DESC := L_KEY_DESC || L_ITEM_DESC || ' - ';
      ELSE
        L_KEY_DESC := L_KEY_DESC || L_ITEM_DESC || ' : ' || L_VALS ||
                      CHR(10);
      END IF;
    
      I       := I + 1;
      L_PARAM := CSPKES_MISC.FN_GETPARAM(P_KEY_DEF, I, '~');
      L_VALS  := CSPKES_MISC.FN_GETPARAM(P_KEY_ID, I, '~');
    END LOOP;
  
    RETURN NVL(L_KEY_DESC, P_KEY_ID);
    DBG('Returning Success From Fn_Get_Key_Desc..');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  Fn_Get_Key_Desc..');
      DBG(SQLERRM);
      RETURN NULL;
  END FN_GET_KEY_DESC;

  FUNCTION FN_GET_KEY_ID(P_FUNCTION_ID  IN VARCHAR2,
                         P_MASTER_NODE  IN VARCHAR2,
                         P_PK_COLS      IN VARCHAR2,
                         P_PK_VALS      IN VARCHAR2,
                         P_KEY_ID       IN OUT VARCHAR2,
                         P_ERROR_CODE   IN OUT VARCHAR2,
                         P_ERROR_PARAMS IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
    L_TABLE_NAME VARCHAR2(100);
  BEGIN
    DBG('In  Fn_Get_Key_Id..');
    L_TABLE_NAME := FN_GET_TABLE_NAME(P_MASTER_NODE);
    P_KEY_ID     := '~' || L_TABLE_NAME || '~' || P_PK_VALS;
    G_KEY_DEF    := '~' || L_TABLE_NAME || '~' || P_PK_COLS;
  
    RETURN TRUE;
    DBG('Returning Success From Fn_Get_Key_Id..');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  Fn_Get_Key_Id..');
      DBG(SQLERRM);
      P_ERROR_CODE   := 'ST-OTHR-001';
      P_ERROR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_KEY_ID;

  FUNCTION FN_GET_FUNC_UDF_KEY(P_FUNCTION_ID  IN VARCHAR2,
                               P_MASTER_NODE  IN VARCHAR2,
                               P_PK_COLS      IN VARCHAR2,
                               P_PK_VALS      IN VARCHAR2,
                               P_REC_KEY      IN OUT VARCHAR2,
                               P_ERROR_CODE   IN OUT VARCHAR2,
                               P_ERROR_PARAMS IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
  BEGIN
    DBG('In  Fn_Get_Func_Udf_Key..');
    P_REC_KEY := RTRIM(P_PK_VALS, '~') || '~';
    RETURN TRUE;
    DBG('Returning Success From Fn_Get_Func_Udf_Key..');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Get_Func_Udf_Key..');
      DBG(SQLERRM);
      P_ERROR_CODE   := 'ST-OTHR-001';
      P_ERROR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_FUNC_UDF_KEY;

  FUNCTION FN_GET_TXN_UDF_KEY(P_FUNCTION_ID  IN VARCHAR2,
                              P_MASTER_NODE  IN VARCHAR2,
                              P_PK_COLS      IN VARCHAR2,
                              P_PK_VALS      IN VARCHAR2,
                              P_REC_KEY      IN OUT VARCHAR2,
                              P_ERROR_CODE   IN OUT VARCHAR2,
                              P_ERROR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_REF_NO VARCHAR2(32767);
  BEGIN
    DBG('In  Fn_Get_Txn_Udf_Key..');
  
    L_REF_NO  := CSPKES_MISC.FN_GETPARAM(P_PK_VALS, 1, '~');
    P_REC_KEY := L_REF_NO;
  
    DBG('Returning Success From  Fn_Get_Txn_Udf_Key..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Get_Txn_Udf_Key..');
      DBG(SQLERRM);
      P_ERROR_CODE   := 'ST-OTHR-001';
      P_ERROR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_TXN_UDF_KEY;

  FUNCTION FN_GET_RECORD_KEY(P_FUNCTION_ID  IN VARCHAR2,
                             P_MASTER_NODE  IN VARCHAR2,
                             P_PK_COLS      IN VARCHAR2,
                             P_PK_VALS      IN VARCHAR2,
                             P_REC_KEY      IN OUT VARCHAR2,
                             P_ERROR_CODE   IN OUT VARCHAR2,
                             P_ERROR_PARAMS IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
  BEGIN
    DBG('In  Fn_Get_Record_Key..');
    P_REC_KEY := RTRIM(P_PK_VALS, '~') || '~';
    RETURN TRUE;
    DBG('Returning Success From Fn_Get_Record_Key..');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Get_Record_Key..');
      DBG(SQLERRM);
      P_ERROR_CODE   := 'ST-OTHR-001';
      P_ERROR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_RECORD_KEY;

  FUNCTION FN_GET_KEY_INFORMATION(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_FUNCTION_TYPE    IN VARCHAR2,
                                  P_MASTER_NODE      IN VARCHAR2,
                                  P_MASTER_BLOCK     IN VARCHAR2,
                                  P_MASTER_XSD_NODE  IN VARCHAR2,
                                  P_PK_COLS          IN VARCHAR2,
                                  P_PK_VALS          IN VARCHAR2,
                                  P_KEY_INFO         IN OUT CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                                  P_ERROR_CODE       IN OUT VARCHAR2,
                                  P_ERROR_PARAMS     IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
    L_KEY_ID       VARCHAR2(32767);
    L_FUNC_UDF_KEY VARCHAR2(32767);
    L_TXN_UDF_KEY  VARCHAR2(32767);
    L_RECORD_KEY   VARCHAR2(32767);
    L_MASTER_TABLE VARCHAR2(32767) := P_MASTER_NODE;
  BEGIN
    DBG('In  Fn_Get_Key_Information..');
    IF NOT FN_GET_KEY_ID(P_FUNCTION_ID,
                         L_MASTER_TABLE,
                         P_PK_COLS,
                         P_PK_VALS,
                         L_KEY_ID,
                         P_ERROR_CODE,
                         P_ERROR_PARAMS) THEN
      DBG('Failed in Fn_Get_Key_Id..');
      RETURN FALSE;
    END IF;
    IF NOT FN_GET_FUNC_UDF_KEY(P_FUNCTION_ID,
                               L_MASTER_TABLE,
                               P_PK_COLS,
                               P_PK_VALS,
                               L_FUNC_UDF_KEY,
                               P_ERROR_CODE,
                               P_ERROR_PARAMS) THEN
      DBG('Failed in Fn_Get_Func_Udf_Key..');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_GET_TXN_UDF_KEY(P_FUNCTION_ID,
                              L_MASTER_TABLE,
                              P_PK_COLS,
                              P_PK_VALS,
                              L_TXN_UDF_KEY,
                              P_ERROR_CODE,
                              P_ERROR_PARAMS) THEN
      DBG('Failed in Fn_Get_Func_Udf_Key..');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_GET_RECORD_KEY(P_FUNCTION_ID,
                             L_MASTER_TABLE,
                             P_PK_COLS,
                             P_PK_VALS,
                             L_RECORD_KEY,
                             P_ERROR_CODE,
                             P_ERROR_PARAMS) THEN
      DBG('Failed in Fn_Get_Record_Key..');
      RETURN FALSE;
    END IF;
  
    P_KEY_INFO('MASTER_BLOCK') := P_MASTER_BLOCK;
    P_KEY_INFO('MASTER_NODE') := P_MASTER_NODE;
    P_KEY_INFO('MASTER_XSD_NODE') := P_MASTER_XSD_NODE;
    P_KEY_INFO('MASTER_TABLE') := P_MASTER_NODE;
    P_KEY_INFO('RECORD_KEY') := L_RECORD_KEY;
    P_KEY_INFO('KEY_ID') := L_KEY_ID;
    P_KEY_INFO('FUNC_UDF_KEY') := L_FUNC_UDF_KEY;
    P_KEY_INFO('FUNCTION_TYPE') := P_FUNCTION_TYPE;
    P_KEY_INFO('TXN_UDF_KEY') := L_TXN_UDF_KEY;
  
    CSPKS_REQ_GLOBAL.PR_SET_REQ_KEY(L_RECORD_KEY);
    CSPKS_REQ_GLOBAL.PR_SET_FUNC_TYPE(P_FUNCTION_TYPE);
    CSPKS_REQ_GLOBAL.PR_SET_KEY_ID(L_KEY_ID);
  
    CSPKS_REQ_UTILS.PR_SET_ACTIVATE_KERNEL;
    PR_SKIP_HANDLER('Fn_Post_Get_Key_Information');
    IF NOT CSPKS_REQ_UTILS.FN_SKIP_CLUSTER THEN
      DBG('Calling  cspks_req_utils_Cluster.Fn_Post_Get_Key_Information');
      IF NOT
          CSPKS_REQ_UTILS_CLUSTER.FN_POST_GET_KEY_INFORMATION(P_SOURCE,
                                                              P_SOURCE_OPERATION,
                                                              P_FUNCTION_ID,
                                                              P_ACTION_CODE,
                                                              P_FUNCTION_TYPE,
                                                              P_MASTER_NODE,
                                                              P_MASTER_BLOCK,
                                                              P_MASTER_XSD_NODE,
                                                              P_PK_COLS,
                                                              P_PK_VALS,
                                                              P_KEY_INFO,
                                                              P_ERROR_CODE,
                                                              P_ERROR_PARAMS)
      
       THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT CSPKS_REQ_UTILS.FN_SKIP_CUSTOM THEN
      DBG('Calling  cspks_req_utils_Custom.Fn_Post_Get_Key_Information');
      IF NOT
          CSPKS_REQ_UTILS_CUSTOM.FN_POST_GET_KEY_INFORMATION(P_SOURCE,
                                                             P_SOURCE_OPERATION,
                                                             P_FUNCTION_ID,
                                                             P_ACTION_CODE,
                                                             P_FUNCTION_TYPE,
                                                             P_MASTER_NODE,
                                                             P_MASTER_BLOCK,
                                                             P_MASTER_XSD_NODE,
                                                             P_PK_COLS,
                                                             P_PK_VALS,
                                                             P_KEY_INFO,
                                                             P_ERROR_CODE,
                                                             P_ERROR_PARAMS)
      
       THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Returning  Success From  Fn_Get_Key_Information..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Get_Key_Information..');
      DBG(SQLERRM);
      P_ERROR_CODE   := 'ST-OTHR-001';
      P_ERROR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_KEY_INFORMATION;

  FUNCTION FN_FIELD_LOG_REQD(P_FUNCTION_ID IN VARCHAR2,
                             P_ACTION_CODE IN VARCHAR2) RETURN BOOLEAN IS
  
    L_REQD           BOOLEAN := FALSE;
    L_FIELD_LOG_REQD VARCHAR2(1);
  
    L_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM VARCHAR2(250);
  
  BEGIN
    DBG('In Fn_Field_Log_Reqd..');
    IF NOT CSPKS_REQ_GLOBAL.FN_UNTANKING OR G_MODIFY_CHANGED_TO_NEW THEN
    
      IF (P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_MODIFY, CSPKS_REQ_GLOBAL.P_NEW)) OR
         ((G_MODIFY_CHANGED_TO_NEW) AND
         (P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW))) THEN
      
        IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                         L_ERR_CODE,
                                                         L_ERR_PARAM) THEN
          DBG('Failed in FRC bec of - ' || L_ERR_CODE);
          DBG('Exception was not raised previously..instead handled..dng the same..');
          L_FIELD_LOG_REQD := 'N';
          L_ERR_CODE       := NULL;
          L_ERR_PARAM      := NULL;
        ELSE
          DBG('Returned success from FRC..');
          L_FIELD_LOG_REQD := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.FIELD_LOG_REQD;
        END IF;
        DBG('Value of l_Field_Log_Reqd is - ' || L_FIELD_LOG_REQD);
      
        L_FIELD_LOG_REQD := NVL(L_FIELD_LOG_REQD, 'N');
        IF L_FIELD_LOG_REQD = 'Y' THEN
          L_REQD := TRUE;
        ELSE
          L_REQD := FALSE;
        END IF;
      ELSE
        L_REQD := FALSE;
      END IF;
    
    ELSE
      L_REQD := FALSE;
      DBG('Untanking Case..');
    END IF;
  
    IF L_REQD THEN
      DBG('Returning Required From Fn_Field_Log_Reqd..');
    ELSE
      DBG('Returning Not Required From Fn_Field_Log_Reqd..');
    END IF;
    RETURN L_REQD;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of Fn_Field_Log_Reqd ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_FIELD_LOG_REQD;

  FUNCTION FN_LOG_FUNC_UDF_CHANGES(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_KEY_ID           IN VARCHAR2,
                                   P_MOD_NO           IN NUMBER,
                                   P_PREV_UDF         IN COPKSS_UDF_UPLOAD.TY_UPL_FUNC_UDF,
                                   P_CURR_UDF         IN COPKSS_UDF_UPLOAD.TY_UPL_FUNC_UDF,
                                   P_TB_FIELD_LOG     IN OUT NOCOPY CSPKS_REQ_GLOBAL.TY_TB_FLD_LOG,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_SQL               VARCHAR2(32767);
    L_BASE_DATA_FROM_FC VARCHAR2(1) := 'Y';
    L_MOD_NO            NUMBER;
    L_COUNT             NUMBER;
    L_MAKER             VARCHAR2(32767);
    L_FIELD_LOG         STTBS_FIELD_LOG%ROWTYPE;
    L_PREV_COUNT        NUMBER := 0;
    L_CURR_COUNT        NUMBER := 0;
    L_LOG_COUNT         NUMBER := 0;
    L_DTL_KEY           VARCHAR2(100) := 'UDFDETAILS';
    L_BLK               VARCHAR2(100) := 'UDFDETAILS';
    L_DBT               VARCHAR2(100) := 'UDFDETAILS';
    L_DBC               VARCHAR2(100) := 'FIELD_VAL';
    L_REC_FOUND         BOOLEAN;
  BEGIN
    DBG('In Fn_Log_Func_Udf_Changes..');
  
    L_LOG_COUNT             := P_TB_FIELD_LOG.COUNT;
    L_FIELD_LOG.KEY_ID      := P_KEY_ID;
    L_FIELD_LOG.MOD_NO      := P_MOD_NO;
    L_FIELD_LOG.FUNCTION_ID := P_FUNCTION_ID;
  
    L_PREV_COUNT := P_PREV_UDF.COUNT;
    L_CURR_COUNT := P_CURR_UDF.COUNT;
  
    IF L_CURR_COUNT > 0 THEN
      FOR I IN 1 .. L_CURR_COUNT LOOP
        L_REC_FOUND := FALSE;
        IF L_PREV_COUNT > 0 THEN
          FOR J IN 1 .. L_PREV_COUNT LOOP
            IF NVL(P_CURR_UDF(I).FIELD_NAME, '*') =
               NVL(P_PREV_UDF(J).FIELD_NAME, '*') THEN
              L_REC_FOUND := TRUE;
              IF NVL(P_CURR_UDF(I).FIELD_VAL, '*') <>
                 NVL(P_PREV_UDF(J).FIELD_VAL, '*') THEN
                L_LOG_COUNT            := L_LOG_COUNT + 1;
                L_FIELD_LOG.DETAIL_KEY := L_DTL_KEY;
                L_FIELD_LOG.BLOCK_NAME := L_BLK;
              
                L_FIELD_LOG.FIELD_NAME := P_CURR_UDF(I).FIELD_NAME;
                L_FIELD_LOG.TABLE_NAME := L_DBT;
                L_FIELD_LOG.ITEM_NO := L_LOG_COUNT;
                L_FIELD_LOG.RECORD_STAT := 'M';
                L_FIELD_LOG.OLD_VALUE := P_PREV_UDF(J).FIELD_VAL;
                L_FIELD_LOG.NEW_VALUE := P_CURR_UDF(I).FIELD_VAL;
                P_TB_FIELD_LOG(L_LOG_COUNT) := L_FIELD_LOG;
              END IF;
            END IF;
          
          END LOOP;
        END IF;
      
        IF NOT L_REC_FOUND THEN
          DBG('New Field Addedd..');
          L_LOG_COUNT            := L_LOG_COUNT + 1;
          L_FIELD_LOG.DETAIL_KEY := L_DTL_KEY;
          L_FIELD_LOG.BLOCK_NAME := L_BLK;
        
          L_FIELD_LOG.FIELD_NAME := P_CURR_UDF(I).FIELD_NAME;
          L_FIELD_LOG.TABLE_NAME := L_DBT;
          L_FIELD_LOG.ITEM_NO := L_LOG_COUNT;
          L_FIELD_LOG.RECORD_STAT := 'N';
          L_FIELD_LOG.OLD_VALUE := NULL;
          L_FIELD_LOG.NEW_VALUE := P_CURR_UDF(I).FIELD_VAL;
          P_TB_FIELD_LOG(L_LOG_COUNT) := L_FIELD_LOG;
        
        END IF;
      END LOOP;
    END IF;
  
    IF L_PREV_COUNT > 0 THEN
      FOR I IN 1 .. L_PREV_COUNT LOOP
        L_REC_FOUND := FALSE;
        IF L_CURR_COUNT > 0 THEN
          FOR J IN 1 .. L_CURR_COUNT LOOP
            IF NVL(P_PREV_UDF(I).FIELD_NAME, '*') =
               NVL(P_CURR_UDF(J).FIELD_NAME, '*') THEN
              L_REC_FOUND := TRUE;
              EXIT;
            END IF;
          
          END LOOP;
        END IF;
        IF NOT L_REC_FOUND THEN
          DBG('Field Deleted..');
          L_LOG_COUNT := L_LOG_COUNT + 1;
          L_FIELD_LOG.DETAIL_KEY := L_DTL_KEY;
          L_FIELD_LOG.BLOCK_NAME := L_BLK;
          L_FIELD_LOG.FIELD_NAME := L_DBC;
          L_FIELD_LOG.TABLE_NAME := L_DBT;
          L_FIELD_LOG.ITEM_NO := L_LOG_COUNT;
          L_FIELD_LOG.RECORD_STAT := 'D';
          L_FIELD_LOG.OLD_VALUE := NULL;
          L_FIELD_LOG.NEW_VALUE := P_PREV_UDF(I).FIELD_VAL;
          P_TB_FIELD_LOG(L_LOG_COUNT) := L_FIELD_LOG;
        END IF;
      END LOOP;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others Of Fn_Log_Func_Udf_Changes..' || SQLERRM);
      P_ERR_CODE := 'ST-SERV-002';
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_LOG_FUNC_UDF_CHANGES;

  FUNCTION FN_GET_FUNC_UDF_NODE_DATA(P_NODE_DATA  IN OUT CSPKS_REQ_GLOBAL.TY_TB_CHR_NODE_DATA,
                                     P_ERR_CODE   IN OUT VARCHAR2,
                                     P_ERR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_CNTR NUMBER := 0;
  BEGIN
  
    DBG('In Fn_Get_Func_Udf_Node_Data.. ');
    L_CNTR := NVL(P_NODE_DATA.COUNT, 0) + 1;
    P_NODE_DATA(L_CNTR).NODE_NAME := CSPKS_REQ_GLOBAL.P_FUNC_UDF_BLK;
    P_NODE_DATA(L_CNTR).XSD_NODE := CSPKS_REQ_GLOBAL.P_FUNC_UDF_NODE;
    P_NODE_DATA(L_CNTR).NODE_PARENT := NULL;
    P_NODE_DATA(L_CNTR).NODE_RELATION_TYPE := 'N';
    P_NODE_DATA(L_CNTR).QUERY_NODE := 'O';
    P_NODE_DATA(L_CNTR).NODE_FIELDS := 'FLDNAM~FLDVAL~DATATYP~VALTYP~';
    P_NODE_DATA(L_CNTR).NODE_TAGS := 'FLDNAM~FLDVAL~';
  
    DBG('Returning Success From Fn_Get_Func_Udf_Node_Data..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others of Fn_Get_Func_Udf_Node_Data..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_FUNC_UDF_NODE_DATA;

  FUNCTION FN_GET_TXN_UDF_NODE_DATA(P_NODE_DATA  IN OUT CSPKS_REQ_GLOBAL.TY_TB_CHR_NODE_DATA,
                                    P_ERR_CODE   IN OUT VARCHAR2,
                                    P_ERR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_CNTR NUMBER := 0;
  BEGIN
  
    DBG('In Fn_Get_Txn_Udf_Node_Data ');
    L_CNTR := NVL(P_NODE_DATA.COUNT, 0) + 1;
    P_NODE_DATA(L_CNTR).NODE_NAME := CSPKS_REQ_GLOBAL.P_TXN_UDF_BLK;
    P_NODE_DATA(L_CNTR).XSD_NODE := CSPKS_REQ_GLOBAL.P_TXN_UDF_NODE;
    P_NODE_DATA(L_CNTR).NODE_PARENT := NULL;
    P_NODE_DATA(L_CNTR).NODE_RELATION_TYPE := 'N';
    P_NODE_DATA(L_CNTR).QUERY_NODE := 'O';
    P_NODE_DATA(L_CNTR).NODE_FIELDS := 'FLDNAM~FLDVAL~DATATYP~VALTYP~';
    P_NODE_DATA(L_CNTR).NODE_TAGS := 'FLDNAM~FLDVAL~';
  
    DBG('Returning Success From Fn_Get_Txn_Udf_Node_Data ');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others of Fn_Get_Txn_Udf_Node_Data.. ');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_TXN_UDF_NODE_DATA;

  FUNCTION FN_GET_TANKED_DATA(P_SOURCE                    IN VARCHAR2,
                              P_SOURCE_OPERATION          IN VARCHAR2,
                              P_FUNCTION_ID               IN VARCHAR2,
                              P_ACTION_CODE               IN VARCHAR2,
                              P_KEY_ID                    IN VARCHAR2,
                              P_MOD_NO                    IN NUMBER,
                              P_WITH_LOCK                 IN VARCHAR2,
                              P_TANKED_DATA_FOUND         IN OUT BOOLEAN,
                              P_BLD_TYPE_FROM_TANKED_DATA IN OUT BOOLEAN,
                              P_ERROR_CODE                IN OUT VARCHAR2,
                              P_ERROR_PARAMS              IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    E_FAILURE_EXCEPTION EXCEPTION;
    L_TANKING_REQD          VARCHAR2(1);
    L_CURR_MOD_NO           NUMBER;
    L_LATEST_AUTH_MOD_NO    NUMBER;
    L_TANKED_DATA           CLOB;
    L_REQ_BACK              CLOB;
    L_SOURCE_CODE           VARCHAR2(100) := 'FLEXCUBE';
    L_MOD_NO                NUMBER;
    L_REC_MASTER            STTBS_RECORD_MASTER%ROWTYPE;
    L_GET_FROM_TANKED       BOOLEAN := FALSE;
    L_RECENT_MOD_AFTER_DELE NUMBER;
    L_XML                   XMLTYPE;
    L_BACKED_UP             BOOLEAN := FALSE;
    L_MAINT_MASTER_FOUND    BOOLEAN := TRUE;
    L_ERROR                 CLOB;
    L_NODE_TYPE             VARCHAR2(20) := 'B';
    L_APPEND_TO_RES         BOOLEAN := FALSE;
    L_STATUS                VARCHAR2(20) := 'S';
    L_POST_UPL_STAT         VARCHAR2(20) := 'U';
    L_CLOSE_REOPEN_MOD_NO   NUMBER := 0;
    RECORD_LOCKED EXCEPTION;
    L_AUTH_STAT        VARCHAR2(1);
    L_MASTER_RECS      VARCHAR2(32767);
    L_CHECKER_ID       VARCHAR2(30);
    L_CHECKER_DT_STAMP DATE;
    PRAGMA EXCEPTION_INIT(RECORD_LOCKED, -54);
  BEGIN
  
    DBG('In   Fn_Get_Tanked_Data ..:' || P_WITH_LOCK || '/' ||
        P_ACTION_CODE || '/' || P_MOD_NO);
    P_TANKED_DATA_FOUND         := FALSE;
    P_BLD_TYPE_FROM_TANKED_DATA := FALSE;
    CSPKS_REQ_GLOBAL.PR_SET_BUILD_RESP(TRUE);
    CSPKS_REQ_GLOBAL.PR_SET_TANKED_DATA_FOUND(FALSE);
  
    IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                     P_ERROR_CODE,
                                                     P_ERROR_PARAMS) THEN
      DBG('Failed in FRC bec of - ' || P_ERROR_CODE);
      DBG('Exception was not raised previously..instead handled..dng the same..');
      L_TANKING_REQD := 'N';
      P_ERROR_CODE   := NULL;
      P_ERROR_PARAMS := NULL;
    ELSE
      DBG('Returned success from FRC..');
      L_TANKING_REQD := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.TANK_MODIFICATIONS;
    END IF;
    DBG('Value of l_Tanking_Reqd is - ' || L_TANKING_REQD);
  
    L_TANKING_REQD := NVL(L_TANKING_REQD, 'N');
  
    IF NVL(SMPKS_MASK_USER.FN_SETUSRCTX(GLOBAL.USER_ID, P_FUNCTION_ID), 'N') = 'Y' THEN
      L_TANKING_REQD := 'N';
      DBG('l_Tanking_Reqd after mask - ' || L_TANKING_REQD);
    END IF;
  
    IF L_TANKING_REQD = 'Y' THEN
    
      BEGIN
        SELECT CURR_MOD_NO, LATEST_AUTH_MOD_NO
          INTO L_CURR_MOD_NO, L_LATEST_AUTH_MOD_NO
          FROM STTB_RECORD_MASTER
         WHERE KEY_ID = P_KEY_ID
           FOR UPDATE NOWAIT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed In Selecting The Master Recotrd..');
          L_MAINT_MASTER_FOUND := FALSE;
        
          RETURN TRUE;
      END;
    
      L_CURR_MOD_NO        := NVL(L_CURR_MOD_NO, 0);
      L_LATEST_AUTH_MOD_NO := NVL(L_LATEST_AUTH_MOD_NO, 0);
      DBG('Record Master Modification Numbers :' || L_CURR_MOD_NO || '/' ||
          L_LATEST_AUTH_MOD_NO);
    
      IF L_MAINT_MASTER_FOUND THEN
        IF P_WITH_LOCK = 'Y' THEN
        
          BEGIN
            SELECT CURR_MOD_NO, LATEST_AUTH_MOD_NO
              INTO L_CURR_MOD_NO, L_LATEST_AUTH_MOD_NO
              FROM STTB_RECORD_MASTER
             WHERE KEY_ID = P_KEY_ID
               FOR UPDATE NOWAIT;
          EXCEPTION
            WHEN RECORD_LOCKED THEN
              DBG('Failed To Obtain The Lock..');
              P_ERROR_CODE   := 'ST-LOCK-001';
              P_ERROR_PARAMS := NULL;
              RETURN FALSE;
          END;
        
          IF L_CURR_MOD_NO > L_LATEST_AUTH_MOD_NO THEN
            DBG('Untanked Entries Are Available..');
            IF NOT CSPKS_REQ_GLOBAL.FN_UNTANKING THEN
              DBG('Non Untanking Case.. Should Get From Tanked Data ..');
              L_MOD_NO          := L_CURR_MOD_NO;
              L_GET_FROM_TANKED := TRUE;
            ELSE
              DBG('Untanking Case..');
              IF G_MODIFY_CHANGED_TO_NEW THEN
                DBG('Case Untaking the Modify Request as New..');
                L_GET_FROM_TANKED := TRUE;
                L_MOD_NO          := L_CURR_MOD_NO;
              END IF;
            END IF;
          END IF;
        
          IF L_GET_FROM_TANKED THEN
            DBG('Trying To Get Tanked Data For Modification Number :' ||
                L_MOD_NO);
            P_BLD_TYPE_FROM_TANKED_DATA := TRUE;
            BEGIN
              SELECT REC_DATA, AUTH_STAT
                INTO L_TANKED_DATA, L_AUTH_STAT
                FROM STTB_RECORD_LOG
               WHERE KEY_ID = P_KEY_ID
                 AND MOD_NO = L_MOD_NO
                    
                 AND FUNCTION_ID = P_FUNCTION_ID
                    
                 AND TANKING_STATUS = 'T';
              P_TANKED_DATA_FOUND := TRUE;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in Secting From Sttb_Record_Log..');
                DBG(SQLERRM);
                P_TANKED_DATA_FOUND := FALSE;
            END;
          
            IF P_TANKED_DATA_FOUND THEN
              DBG('Parsing the Tanked Data..');
              CSPKS_REQ_GLOBAL.PR_BACKUP();
              GWPKS_SERVICE_ROUTER.PR_BACKUP();
              CSPKS_REQ_GLOBAL.G_REQ := REPLACE(L_TANKED_DATA,
                                                'FCUBS_RES_ENV',
                                                'FCUBS_REQ_ENV');
              CSPKS_REQ_GLOBAL.PR_RESET;
              IF NOT CSPKS_PARSER.FN_PARSER(L_SOURCE_CODE,
                                            P_ERROR_CODE,
                                            P_ERROR_PARAMS) THEN
                DBG('Failed in Parsing..');
                RAISE E_FAILURE_EXCEPTION;
              END IF;
              CSPKS_REQ_GLOBAL.PR_RESTORE();
              GWPKS_SERVICE_ROUTER.PR_RESTORE();
            END IF;
          
          END IF;
        
        ELSIF P_WITH_LOCK = 'N' THEN
          CSPKS_REQ_GLOBAL.PR_SET_BUILD_RESP(TRUE);
          IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_VERSION_DELETE THEN
            DBG('Adjusting The Modification Number For Query After Version Delete..');
            IF P_MOD_NO IS NOT NULL THEN
              L_MOD_NO := P_MOD_NO;
            ELSE
              L_MOD_NO := L_CURR_MOD_NO;
            END IF;
            IF L_MOD_NO >= 1 THEN
            
              L_MOD_NO := L_MOD_NO - 1;
            END IF;
            IF L_MOD_NO <= L_LATEST_AUTH_MOD_NO THEN
              DBG('The Only Tanked Modification is Deleted..');
              IF L_LATEST_AUTH_MOD_NO > 0 THEN
                DBG('Base Tables will Have Data..');
              ELSE
                DBG('Its a Complete Delete of All tanked modifications..');
              
                IF P_SOURCE = 'FLEXCUBE' THEN
                  P_TANKED_DATA_FOUND         := TRUE;
                  P_BLD_TYPE_FROM_TANKED_DATA := FALSE;
                  CSPKS_REQ_GLOBAL.PR_SET_BUILD_RESP(FALSE);
                  CSPKS_REQ_GLOBAL.PR_SET_TANKED_DATA_FOUND(TRUE);
                
                  CSPKS_REQ_GLOBAL.PR_RESET;
                  PR_LOG_ERROR(P_SOURCE, P_FUNCTION_ID, 'ST-SAVE-091', '');
                  CSPKS_REQ_GLOBAL.PR_WRITE('P', 'DUMMY', '');
                  CSPKS_REQ_GLOBAL.PR_WRITE('V', 'DUMMY', '');
                  IF NOT CSPKS_CREATOR.FN_CREATE(P_SOURCE,
                                                 CSPKS_REQ_GLOBAL.P_DELETE,
                                                 L_STATUS,
                                                 'F',
                                                 P_ERROR_CODE,
                                                 P_ERROR_PARAMS) THEN
                    DBG('Failed in Fn_Build_Fcresponse..');
                    RETURN FALSE;
                  END IF;
                ELSE
                  P_TANKED_DATA_FOUND := TRUE;
                END IF;
              
              END IF;
            ELSE
              SELECT MAX(MOD_NO)
                INTO L_RECENT_MOD_AFTER_DELE
                FROM STTB_RECORD_LOG
               WHERE KEY_ID = P_KEY_ID
                 AND MOD_NO <= L_MOD_NO
                    
                 AND FUNCTION_ID = P_FUNCTION_ID
                    
                 AND TANKING_STATUS = 'T';
            
              DBG('Recent Untanked Modification After Deleting :' ||
                  L_RECENT_MOD_AFTER_DELE);
            
              IF L_RECENT_MOD_AFTER_DELE > 0 THEN
                L_MOD_NO          := L_RECENT_MOD_AFTER_DELE;
                L_GET_FROM_TANKED := TRUE;
              END IF;
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN
            IF L_CURR_MOD_NO > L_LATEST_AUTH_MOD_NO THEN
              L_MOD_NO          := L_CURR_MOD_NO;
              L_GET_FROM_TANKED := TRUE;
            ELSE
              L_GET_FROM_TANKED := FALSE;
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
          
            IF P_MOD_NO IS NOT NULL THEN
              L_MOD_NO := P_MOD_NO;
            ELSE
              L_MOD_NO := L_CURR_MOD_NO;
            END IF;
          
            IF L_CURR_MOD_NO = L_MOD_NO THEN
              L_GET_FROM_TANKED := FALSE;
            ELSE
              L_MOD_NO          := L_CURR_MOD_NO;
              L_GET_FROM_TANKED := TRUE;
            END IF;
          
          ELSIF P_ACTION_CODE IN
                (CSPKS_REQ_GLOBAL.P_NEW,
                 CSPKS_REQ_GLOBAL.P_MODIFY,
                 CSPKS_REQ_GLOBAL.P_CLOSE,
                 CSPKS_REQ_GLOBAL.P_REOPEN) THEN
            L_GET_FROM_TANKED := FALSE;
          END IF;
        
          IF L_GET_FROM_TANKED THEN
            DBG('Trying To Get Tanked Data For Modification Number :' ||
                L_MOD_NO);
            BEGIN
              SELECT REC_DATA, AUTH_STAT, CHECKER_ID, CHECKER_DT_STAMP
                INTO L_TANKED_DATA,
                     L_AUTH_STAT,
                     L_CHECKER_ID,
                     L_CHECKER_DT_STAMP
                FROM STTB_RECORD_LOG
               WHERE KEY_ID = P_KEY_ID
                    
                 AND FUNCTION_ID = P_FUNCTION_ID
                    
                 AND MOD_NO = L_MOD_NO;
              P_TANKED_DATA_FOUND := TRUE;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in Secting From Sttb_Record_Log..');
                DBG(SQLERRM);
                P_TANKED_DATA_FOUND := FALSE;
            END;
          
            IF L_TANKED_DATA IS NULL THEN
              P_TANKED_DATA_FOUND := FALSE;
            END IF;
          
            IF P_TANKED_DATA_FOUND THEN
              DBG('Tanked Data Found..');
              IF P_SOURCE = L_SOURCE_CODE THEN
                IF P_ACTION_CODE IN
                   (CSPKS_REQ_GLOBAL.P_QUERY,
                    CSPKS_REQ_GLOBAL.P_AUTH,
                    CSPKS_REQ_GLOBAL.P_VERSION_DELETE) THEN
                
                  IF CSPKS_REQ_GLOBAL.FN_IS_TANK_QUERY_HOOK_REQD THEN
                    P_BLD_TYPE_FROM_TANKED_DATA := TRUE;
                    CSPKS_REQ_GLOBAL.PR_SET_BUILD_RESP(TRUE);
                  ELSE
                    P_BLD_TYPE_FROM_TANKED_DATA := FALSE;
                    CSPKS_REQ_GLOBAL.PR_SET_BUILD_RESP(FALSE);
                  END IF;
                
                ELSE
                  P_BLD_TYPE_FROM_TANKED_DATA := TRUE;
                  CSPKS_REQ_GLOBAL.PR_SET_BUILD_RESP(TRUE);
                END IF;
              ELSE
                P_BLD_TYPE_FROM_TANKED_DATA := TRUE;
                CSPKS_REQ_GLOBAL.PR_SET_BUILD_RESP(TRUE);
              END IF;
            
              IF P_BLD_TYPE_FROM_TANKED_DATA THEN
                CSPKS_REQ_GLOBAL.PR_BACKUP();
                GWPKS_SERVICE_ROUTER.PR_BACKUP();
                CSPKS_REQ_GLOBAL.G_REQ := REPLACE(L_TANKED_DATA,
                                                  'FCUBS_RES_ENV',
                                                  'FCUBS_REQ_ENV');
                IF NOT CSPKS_PARSER.FN_PARSER(L_SOURCE_CODE,
                                              P_ERROR_CODE,
                                              P_ERROR_PARAMS) THEN
                  DBG('Failed In Parsing..');
                  RAISE E_FAILURE_EXCEPTION;
                END IF;
                CSPKS_REQ_GLOBAL.PR_RESTORE();
                GWPKS_SERVICE_ROUTER.PR_RESTORE();
              END IF;
            
              IF NOT CSPKS_REQ_GLOBAL.FN_BUILD_RESP THEN
                CSPKS_REQ_GLOBAL.G_RES := L_TANKED_DATA;
              
                IF NOT FN_UPDATE_REC_DATA(P_SOURCE,
                                          P_SOURCE_OPERATION,
                                          P_FUNCTION_ID,
                                          L_AUTH_STAT,
                                          L_CHECKER_ID,
                                          L_CHECKER_DT_STAMP,
                                          P_ACTION_CODE,
                                          P_ERROR_CODE,
                                          P_ERROR_PARAMS) THEN
                  DBG('Failed in Fn_Update_Rec_Data');
                END IF;
              END IF;
            END IF;
          END IF;
        END IF;
      ELSE
        P_TANKED_DATA_FOUND         := FALSE;
        P_BLD_TYPE_FROM_TANKED_DATA := FALSE;
        CSPKS_REQ_GLOBAL.PR_SET_BUILD_RESP(TRUE);
        CSPKS_REQ_GLOBAL.PR_SET_TANKED_DATA_FOUND(P_TANKED_DATA_FOUND);
      END IF;
    ELSE
      DBG('Tanking Not Required For The Function Id..');
      P_TANKED_DATA_FOUND         := FALSE;
      P_BLD_TYPE_FROM_TANKED_DATA := FALSE;
      CSPKS_REQ_GLOBAL.PR_SET_BUILD_RESP(TRUE);
      CSPKS_REQ_GLOBAL.PR_SET_TANKED_DATA_FOUND(P_TANKED_DATA_FOUND);
    END IF;
  
    CSPKS_REQ_GLOBAL.PR_SET_TANKED_DATA_FOUND(P_TANKED_DATA_FOUND);
    DBG('Returning Succss From Fn_Get_Tanked_Data..');
    RETURN TRUE;
  EXCEPTION
    WHEN E_FAILURE_EXCEPTION THEN
      DBG('In When Failure Exception Of Fn_Get_Tanked_Data..');
      CSPKS_REQ_GLOBAL.PR_RESTORE();
      GWPKS_SERVICE_ROUTER.PR_RESTORE();
      RETURN FALSE;
    
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of Fn_Get_Tanked_Data ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      CSPKS_REQ_GLOBAL.PR_RESTORE();
      GWPKS_SERVICE_ROUTER.PR_RESTORE();
      RETURN FALSE;
    
  END FN_GET_TANKED_DATA;

  FUNCTION FN_TANK_MODIFICATION(P_SOURCE           IN VARCHAR2,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_ERROR_CODE       IN OUT VARCHAR2,
                                P_ERROR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    E_FAILURE_EXCEPTION EXCEPTION;
    L_TANKING_REQD       VARCHAR2(1);
    L_CURR_MOD_NO        NUMBER;
    L_LATEST_AUTH_MOD_NO NUMBER;
    L_MOD_NO             NUMBER;
    L_TANK               BOOLEAN := FALSE;
  
  BEGIN
    DBG('In Fn_Tank_Modification..');
  
    IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                     P_ERROR_CODE,
                                                     P_ERROR_PARAMS) THEN
      DBG('Failed in FRC bec of - ' || P_ERROR_CODE);
      DBG('Exception was not raised previously..instead handled..dng the same..');
      L_TANKING_REQD := 'N';
      P_ERROR_CODE   := NULL;
      P_ERROR_PARAMS := NULL;
    ELSE
      DBG('Returned success from FRC..');
      L_TANKING_REQD := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.TANK_MODIFICATIONS;
    END IF;
    DBG('Value of l_Tanking_Reqd is - ' || L_TANKING_REQD);
  
    L_TANKING_REQD := NVL(L_TANKING_REQD, 'N');
  
    DBG('Action Code/Tanking Required :' || P_ACTION_CODE || '/' ||
        L_TANKING_REQD);
  
    IF L_TANKING_REQD = 'Y' THEN
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                           CSPKS_REQ_GLOBAL.P_MODIFY,
                           CSPKS_REQ_GLOBAL.P_CLOSE,
                           CSPKS_REQ_GLOBAL.P_REOPEN) THEN
        IF NOT CSPKS_REQ_GLOBAL.FN_UNTANKING THEN
          L_TANK := TRUE;
        ELSE
          IF G_MODIFY_CHANGED_TO_NEW THEN
            L_TANK := TRUE;
          ELSE
            L_TANK := FALSE;
          END IF;
        END IF;
      ELSE
        L_TANK := FALSE;
      END IF;
    ELSE
      L_TANK := FALSE;
    END IF;
  
    IF L_TANK THEN
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                           CSPKS_REQ_GLOBAL.P_MODIFY,
                           CSPKS_REQ_GLOBAL.P_CLOSE,
                           CSPKS_REQ_GLOBAL.P_REOPEN) THEN
        IF CSPKS_REQ_GLOBAL.FN_GET_AUTO_AUTH THEN
          DBG('Auto Authorized ..So should Not Be Tanked..');
          L_TANK := FALSE;
        END IF;
      END IF;
    END IF;
  
    IF L_TANK THEN
      DBG('Tank The Modfication..');
    ELSE
      DBG('Dont Tank The Modification..');
    END IF;
  
    RETURN L_TANK;
  EXCEPTION
  
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of Fn_Tank_Modification ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_TANK_MODIFICATION;

  FUNCTION FN_APPLY_MODIFICATION(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_KEY_ID           IN VARCHAR2,
                                 P_MOD_NO           IN NUMBER,
                                 P_ERROR_CODE       IN OUT VARCHAR2,
                                 P_ERROR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    E_FAILURE_EXCEPTION EXCEPTION;
  
    L_REQ_XML_TYPE     XMLTYPE;
    L_REC_LOG          STTBS_RECORD_LOG%ROWTYPE;
    L_ADDL_INFO        CSPKS_REQ_GLOBAL.TY_ADDL_INFO;
    L_MODULE           VARCHAR2(30);
    L_FUNCTION_ID      SMTBS_MENU.FUNCTION_ID%TYPE;
    L_ACTION_CODE      VARCHAR2(20);
    L_SERVICE_NAME     VARCHAR2(100);
    L_OPERATION_CODE   VARCHAR2(100);
    L_MULTI_TRIP_ID    VARCHAR2(30);
    L_REQUEST_NO_CHR   VARCHAR2(30);
    L_REQUEST_NO       NUMBER;
    L_SOURCE_CODE      VARCHAR2(50) := 'FLEXCUBE';
    L_SOURCE_OPERATION VARCHAR2(50);
    L_EXCHANGE_PATTERN VARCHAR2(50) := 'FSFS';
    L_REPLY_TYPE       VARCHAR2(1) := 'F';
    L_STATUS           VARCHAR2(1) := 'F';
    L_MAIN_ERR_TBL     OVPKS.TBL_ERROR;
    L_UNTANK_ERR_TBL   OVPKS.TBL_ERROR;
    L_ERR_COUNT        NUMBER;
    L_ERROR_CODE       VARCHAR2(32767);
    L_ERROR_PARAMS     VARCHAR2(32767);
    L_PROCESS_TYPE     VARCHAR2(1) := 'I';
    L_HEADER_BACK      GWPKS_SERVICE_ROUTER.TY_HEADER;
  
  BEGIN
  
    SAVEPOINT SP_APPLY_MODIFICATION;
    DBG('In Fn_Apply_Modification..:' || P_ACTION_CODE || '/' || P_MOD_NO);
  
    BEGIN
      SELECT *
        INTO L_REC_LOG
        FROM STTB_RECORD_LOG
       WHERE KEY_ID = P_KEY_ID
         AND MOD_NO = P_MOD_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in Secting From Sttb_Record_Log..');
        DBG(SQLERRM);
        P_ERROR_CODE   := 'ST-TANK-001';
        P_ERROR_PARAMS := P_KEY_ID || '~' || P_MOD_NO;
        RAISE E_FAILURE_EXCEPTION;
    END;
    L_REC_LOG.REC_DATA := REPLACE(L_REC_LOG.REC_DATA,
                                  'FCUBS_RES_ENV',
                                  'FCUBS_REQ_ENV');
  
    L_REQUEST_NO := NVL(L_REC_LOG.REQ_NO, 1);
  
    L_HEADER_BACK := CSPKS_REQ_GLOBAL.G_HEADER;
  
    CSPKS_REQ_GLOBAL.PR_INIT;
  
    CSPKS_REQ_GLOBAL.G_HEADER := L_HEADER_BACK;
  
    L_REQ_XML_TYPE := XMLTYPE(L_REC_LOG.REC_DATA);
    SELECT EXTRACTVALUE(L_REQ_XML_TYPE,
                        '/FCUBS_REQ_ENV/FCUBS_HEADER/SERVICE'),
           EXTRACTVALUE(L_REQ_XML_TYPE,
                        '/FCUBS_REQ_ENV/FCUBS_HEADER/OPERATION'),
           EXTRACTVALUE(L_REQ_XML_TYPE,
                        '/FCUBS_REQ_ENV/FCUBS_HEADER/FUNCTIONID'),
           EXTRACTVALUE(L_REQ_XML_TYPE,
                        '/FCUBS_REQ_ENV/FCUBS_HEADER/ACTION'),
           EXTRACTVALUE(L_REQ_XML_TYPE, '/FCUBS_REQ_ENV/SOURCE_OPERATION'),
           EXTRACTVALUE(L_REQ_XML_TYPE, '/FCUBS_REQ_ENV/BRANCH'),
           EXTRACTVALUE(L_REQ_XML_TYPE,
                        '/FCUBS_REQ_ENV/FCUBS_HEADER/USERID'),
           EXTRACTVALUE(L_REQ_XML_TYPE,
                        '/FCUBS_REQ_ENV/FCUBS_HEADER/MODULEID'),
           EXTRACTVALUE(L_REQ_XML_TYPE,
                        '/FCUBS_REQ_ENV/FCUBS_HEADER/MULTITRIPID')
      INTO CSPKS_REQ_GLOBAL.G_HEADER('SERVICE'),
           CSPKS_REQ_GLOBAL.G_HEADER('OPERATION'),
           CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID'),
           CSPKS_REQ_GLOBAL.G_HEADER('ACTION'),
           CSPKS_REQ_GLOBAL.G_HEADER('SOURCE_OPERATION'),
           CSPKS_REQ_GLOBAL.G_HEADER('BRANCH'),
           CSPKS_REQ_GLOBAL.G_HEADER('USERID'),
           CSPKS_REQ_GLOBAL.G_HEADER('MODULE'),
           CSPKS_REQ_GLOBAL.G_HEADER('MULTITRIPID')
      FROM DUAL;
  
    CSPKS_REQ_GLOBAL.G_HEADER('ACTION') := P_ACTION_CODE;
  
    CSPKS_REQ_GLOBAL.G_REQ := L_REC_LOG.REC_DATA;
  
    L_FUNCTION_ID      := CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID');
    L_ACTION_CODE      := CSPKS_REQ_GLOBAL.G_HEADER('ACTION');
    L_SERVICE_NAME     := CSPKS_REQ_GLOBAL.G_HEADER('SERVICE');
    L_OPERATION_CODE   := CSPKS_REQ_GLOBAL.G_HEADER('OPERATION');
    L_SOURCE_CODE      := 'FLEXCUBE';
    L_MULTI_TRIP_ID    := CSPKS_REQ_GLOBAL.G_HEADER('MULTITRIPID');
    L_SOURCE_OPERATION := CSPKS_REQ_GLOBAL.G_HEADER('SOURCE_OPERATION');
    L_EXCHANGE_PATTERN := NVL(CSPKS_REQ_GLOBAL.G_HEADER('MSG_XCHANGE_PATTERN'),
                              'FSFS');
  
    L_MULTI_TRIP_ID    := NVL(L_MULTI_TRIP_ID, L_REC_LOG.MSG_ID);
    L_SOURCE_OPERATION := L_FUNCTION_ID || '_' || P_ACTION_CODE;
  
    L_MAIN_ERR_TBL.DELETE;
    L_MAIN_ERR_TBL := OVPKS.GL_TBLERROR;
    DBG('Error Count Before :' || L_MAIN_ERR_TBL.COUNT);
    OVPKS.PR_INITERRTBL;
    IF NOT
        CSPKS_PARSER.FN_PARSER(L_SOURCE_CODE, P_ERROR_CODE, P_ERROR_PARAMS) THEN
      DBG('Failed in Parsing..');
      RAISE E_FAILURE_EXCEPTION;
    END IF;
  
    DBG('MULTi :' || L_MULTI_TRIP_ID);
  
    DBG('Calling Cspks_Fidpkg_Wrapper.Fn_Process_Msg..');
    IF NOT CSPKS_REQ_WRAPPER.FN_PROCESS_MSG(L_SOURCE_CODE,
                                            L_SOURCE_OPERATION,
                                            L_FUNCTION_ID,
                                            L_ACTION_CODE,
                                            L_EXCHANGE_PATTERN,
                                            L_MULTI_TRIP_ID,
                                            L_REQUEST_NO,
                                            L_ADDL_INFO,
                                            L_STATUS,
                                            L_ERROR_CODE,
                                            L_ERROR_PARAMS) THEN
      DBG('Failed in Cspks_Fidpkg_Wrapper_Ws.Fn_Process_Msg..');
      P_ERROR_CODE   := 'ST-TANK-001';
      P_ERROR_PARAMS := P_KEY_ID || '~' || P_MOD_NO;
      RAISE E_FAILURE_EXCEPTION;
    END IF;
    DBG('Status After Untanking..' || L_STATUS);
  
    IF L_STATUS IN ('F', 'E') THEN
      DBG('Untanking Failed ..');
      P_ERROR_CODE   := 'ST-TANK-003';
      P_ERROR_PARAMS := P_KEY_ID || '~' || P_MOD_NO;
      RAISE E_FAILURE_EXCEPTION;
    ELSIF L_STATUS IN ('O', 'M') THEN
      DBG('Overrides in Untanking..');
    ELSE
      DBG('Untanking Successful..');
      OVPKS.PR_INITERRTBL;
    END IF;
  
    L_UNTANK_ERR_TBL  := OVPKS.GL_TBLERROR;
    OVPKS.GL_TBLERROR := L_MAIN_ERR_TBL;
    L_ERR_COUNT       := L_UNTANK_ERR_TBL.COUNT;
    IF L_ERR_COUNT > 0 THEN
      FOR I IN 1 .. L_ERR_COUNT LOOP
        DBG('Error while Untanking :' || L_UNTANK_ERR_TBL(I).ERR_CODE);
        IF NVL(SUBSTR(L_UNTANK_ERR_TBL(I).ERR_CODE, 1, 8), '*') <>
           'ST-SAVE-' THEN
          OVPKS.PR_APPENDTBL(L_UNTANK_ERR_TBL(I).ERR_CODE,
                             L_UNTANK_ERR_TBL(I).PARAMS);
        END IF;
      END LOOP;
    END IF;
  
    DBG('Returning Success From Fn_Apply_Modification..');
  
    RETURN TRUE;
  EXCEPTION
  
    WHEN E_FAILURE_EXCEPTION THEN
      DBG('In When Failure Exception Of Fn_Apply_Modification..');
    
      RETURN FALSE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of Fn_Apply_Modification ..');
      DBG('Err: ' || SQLERRM || ' trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_APPLY_MODIFICATION;

  FUNCTION FN_PROCESS_TANKED_ENTRIES(P_SOURCE           IN VARCHAR2,
                                     P_SOURCE_OPERATION IN VARCHAR2,
                                     P_FUNCTION_ID      IN VARCHAR2,
                                     P_ACTION_CODE      IN VARCHAR2,
                                     P_KEY_ID           IN VARCHAR2,
                                     P_MOD_NO           IN NUMBER,
                                     P_NEW_ACTION       IN OUT VARCHAR2,
                                     P_ERROR_CODE       IN OUT VARCHAR2,
                                     P_ERROR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    E_FAILURE_EXCEPTION EXCEPTION;
  
    L_TANKING_REQD        VARCHAR2(1);
    L_CURR_MOD_NO         NUMBER;
    L_LATEST_AUTH_MOD_NO  NUMBER;
    L_MOD_NO              NUMBER;
    L_TANKED_DATA         CLOB;
    L_REQ_BACK            CLOB;
    L_FLD_TAG_BACK        CLOB;
    L_TANKED_DATA_FOUND   BOOLEAN := FALSE;
    L_HEADER_BACK         GWPKS_SERVICE_ROUTER.TY_HEADER;
    L_REQ_XML_TYPE        XMLTYPE;
    L_REC_LOG             STTBS_RECORD_LOG%ROWTYPE;
    L_ADDL_INFO           CSPKS_REQ_GLOBAL.TY_ADDL_INFO;
    L_MODULE              VARCHAR2(30);
    L_FUNCTION_ID         SMTBS_MENU.FUNCTION_ID%TYPE;
    L_ACTION_CODE         VARCHAR2(20);
    L_SERVICE_NAME        VARCHAR2(100);
    L_OPERATION_CODE      VARCHAR2(100);
    L_MULTI_TRIP_ID       VARCHAR2(30);
    L_SOURCE_CODE         VARCHAR2(50) := 'FLEXCUBE';
    L_SOURCE_OPERATION    VARCHAR2(50);
    L_EXCHANGE_PATTERN    VARCHAR2(50) := 'FSFS';
    L_REPLY_TYPE          VARCHAR2(1) := 'F';
    L_STATUS              VARCHAR2(1) := 'F';
    L_BACKED_UP           BOOLEAN := FALSE;
    L_MAIN_ERR_TBL        OVPKS.TBL_ERROR;
    L_ERR_COUNT           NUMBER;
    L_FROM_MOD_NO         NUMBER;
    L_TO_MOD_NO           NUMBER;
    L_ONCE_AUTH           BOOLEAN := FALSE;
    L_RECENT_ACTION       VARCHAR2(50);
    L_CLOSE_REOPEN_MOD_NO NUMBER := 0;
    L_CLOSE_REOPEN_ACTION VARCHAR2(50);
  
    CURSOR C_TANKED_MODIFICATIONS(P_FROM_MOD_NO NUMBER, P_TO_MOD_NO NUMBER) IS
      SELECT *
        FROM STTB_RECORD_LOG
       WHERE KEY_ID = P_KEY_ID
         AND MOD_NO >= P_FROM_MOD_NO
         AND MOD_NO <= P_TO_MOD_NO
         AND TANKING_STATUS = 'T';
  BEGIN
  
    DBG('In Fn_Process_Tanked_Entries..:' || P_KEY_ID);
    SAVEPOINT SP_UNTANK;
    P_NEW_ACTION            := P_ACTION_CODE;
    G_MODIFY_CHANGED_TO_NEW := FALSE;
    IF NOT CSPKS_REQ_GLOBAL.FN_UNTANKING THEN
      DBG('Not Untanking..');
    
      IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                       P_ERROR_CODE,
                                                       P_ERROR_PARAMS) THEN
        DBG('Failed in FRC bec of - ' || P_ERROR_CODE);
        DBG('Exception was not raised previously..instead handled..dng the same..');
        L_TANKING_REQD := 'N';
        P_ERROR_CODE   := NULL;
        P_ERROR_PARAMS := NULL;
      ELSE
        DBG('Returned success from FRC..');
        L_TANKING_REQD := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.TANK_MODIFICATIONS;
      END IF;
    
      IF NVL(SMPKS_MASK_USER.FN_SETUSRCTX(GLOBAL.USER_ID, P_FUNCTION_ID),
             'N') = 'Y' THEN
        L_TANKING_REQD := 'N';
        DBG('l_Tanking_Reqd after mask1 - ' || L_TANKING_REQD);
      END IF;
    
      DBG('Value of l_Tanking_Reqd is - ' || L_TANKING_REQD);
    
      L_TANKING_REQD := NVL(L_TANKING_REQD, 'N');
    
      DBG('Tanking Required/Action Code/Mod No :' || L_TANKING_REQD || '/' ||
          P_ACTION_CODE || '/' || P_MOD_NO);
    
      IF L_TANKING_REQD = 'Y' THEN
      
        BEGIN
          SELECT CURR_MOD_NO, LATEST_AUTH_MOD_NO
            INTO L_CURR_MOD_NO, L_LATEST_AUTH_MOD_NO
            FROM STTB_RECORD_MASTER
           WHERE KEY_ID = P_KEY_ID;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('No Record Found in Record Master Table..');
        END;
      
        L_CURR_MOD_NO        := NVL(L_CURR_MOD_NO, 0);
        L_LATEST_AUTH_MOD_NO := NVL(L_LATEST_AUTH_MOD_NO, 0);
        DBG('Record Master Modification Numbers :' || L_CURR_MOD_NO || '/' ||
            L_LATEST_AUTH_MOD_NO);
      
        IF L_CURR_MOD_NO <> L_LATEST_AUTH_MOD_NO THEN
          DBG('There Are Some Tanked Modifications..');
          IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
            IF P_MOD_NO IS NOT NULL THEN
              L_MOD_NO := P_MOD_NO;
            ELSE
              L_MOD_NO := L_CURR_MOD_NO;
            END IF;
            DBG('Modification Number For Delete  :' || L_MOD_NO);
          
            P_NEW_ACTION := CSPKS_REQ_GLOBAL.P_VERSION_DELETE;
          
          ELSIF P_ACTION_CODE IN
                (CSPKS_REQ_GLOBAL.P_AUTH,
                 CSPKS_REQ_GLOBAL.P_MODIFY,
                 CSPKS_REQ_GLOBAL.P_CLOSE,
                 CSPKS_REQ_GLOBAL.P_REOPEN) THEN
          
            IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
              IF P_MOD_NO IS NOT NULL THEN
                L_MOD_NO := P_MOD_NO;
              ELSE
                L_MOD_NO := L_CURR_MOD_NO;
              END IF;
            ELSE
              L_MOD_NO := L_CURR_MOD_NO;
            END IF;
          
            DBG('Modification Number For Auth/Modify/Close/Reopen  :' ||
                L_MOD_NO);
            BEGIN
              SELECT ACTION_CODE
                INTO L_RECENT_ACTION
                FROM STTB_RECORD_LOG
               WHERE KEY_ID = P_KEY_ID
                 AND MOD_NO = L_MOD_NO
                 AND TANKING_STATUS = 'T';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('Failed In Fetching The Tanked Data..');
                P_ERROR_CODE   := 'ST-TANK-002';
                P_ERROR_PARAMS := P_KEY_ID || '~' || P_MOD_NO;
                BEGIN
                  SELECT ACTION_CODE
                    INTO L_RECENT_ACTION
                    FROM STTB_RECORD_LOG
                   WHERE KEY_ID = P_KEY_ID
                     AND MOD_NO = L_MOD_NO
                     AND NVL(TANKING_STATUS, 'N') = 'N';
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    DBG('Failed In Fetching The Tanked Data..');
                    P_ERROR_CODE   := 'ST-TANK-002';
                    P_ERROR_PARAMS := P_KEY_ID || '~' || P_MOD_NO;
                    RETURN FALSE;
                END;
                RETURN TRUE;
            END;
            IF L_LATEST_AUTH_MOD_NO > 0 THEN
              DBG('Record Is Authorized Once..');
            ELSE
              DBG('Record is not yet Authorized..');
              IF L_RECENT_ACTION IN
                 (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) AND
                 P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
                 P_SOURCE = 'FLEXCUBE' THEN
                DBG('Skipping Untanking of New and Processing the Current Modification as New.');
                G_MODIFY_CHANGED_TO_NEW := TRUE;
                P_NEW_ACTION            := CSPKS_REQ_GLOBAL.P_NEW;
              ELSIF L_RECENT_ACTION = CSPKS_REQ_GLOBAL.P_MODIFY THEN
                L_RECENT_ACTION := CSPKS_REQ_GLOBAL.P_NEW;
              END IF;
            END IF;
          
            CSPKS_REQ_GLOBAL.PR_SET_UNTANKING(TRUE);
          
            IF NOT G_MODIFY_CHANGED_TO_NEW THEN
              CSPKS_REQ_GLOBAL.PR_BACKUP();
              GWPKS_SERVICE_ROUTER.PR_BACKUP();
              SELECT MAX(MOD_NO)
                INTO L_CLOSE_REOPEN_MOD_NO
                FROM STTB_RECORD_LOG
               WHERE KEY_ID = P_KEY_ID
                 AND MOD_NO < L_MOD_NO
                 AND TANKING_STATUS = 'T'
                 AND ACTION_CODE IN ('CLOSE', 'REOPEN');
              DBG('Mod Number :' || L_CLOSE_REOPEN_MOD_NO);
              IF NVL(L_CLOSE_REOPEN_MOD_NO, 0) > 0 THEN
                SELECT ACTION_CODE
                  INTO L_CLOSE_REOPEN_ACTION
                  FROM STTB_RECORD_LOG
                 WHERE KEY_ID = P_KEY_ID
                   AND MOD_NO = L_CLOSE_REOPEN_MOD_NO;
                DBG('Untanking Modification ' || L_MOD_NO ||
                    ' with Close/Reopen Action Code ' || L_RECENT_ACTION);
                IF NOT FN_APPLY_MODIFICATION(P_SOURCE,
                                             P_SOURCE_OPERATION,
                                             P_FUNCTION_ID,
                                             L_CLOSE_REOPEN_ACTION,
                                             P_KEY_ID,
                                             L_CLOSE_REOPEN_MOD_NO,
                                             P_ERROR_CODE,
                                             P_ERROR_PARAMS) THEN
                  DBG('Failed In Fn_Apply_Modification..');
                  RAISE E_FAILURE_EXCEPTION;
                END IF;
              
              END IF;
            
              DBG('Untanking Modification ' || L_MOD_NO ||
                  ' With Action Code ' || L_RECENT_ACTION);
              IF NOT FN_APPLY_MODIFICATION(P_SOURCE,
                                           P_SOURCE_OPERATION,
                                           P_FUNCTION_ID,
                                           L_RECENT_ACTION,
                                           P_KEY_ID,
                                           L_MOD_NO,
                                           P_ERROR_CODE,
                                           P_ERROR_PARAMS) THEN
                DBG('Failed In Fn_Apply_Modification..');
                RAISE E_FAILURE_EXCEPTION;
              END IF;
              CSPKS_REQ_GLOBAL.PR_RESTORE();
              GWPKS_SERVICE_ROUTER.PR_RESTORE();
              CSPKS_REQ_GLOBAL.PR_SET_UNTANKING(FALSE);
            END IF;
          END IF;
        END IF;
      END IF;
    ELSE
      DBG('Untanking So Nothing Needs to Be Done..');
    END IF;
    DBG('Returning Success From Fn_Process_Tanked_Entries..');
    RETURN TRUE;
  EXCEPTION
    WHEN E_FAILURE_EXCEPTION THEN
      DBG('In When Failure Exception Of Fn_Process_Tanked_Entries..');
      ROLLBACK TO SAVEPOINT SP_UNTANK;
    
      CSPKS_REQ_GLOBAL.PR_RESTORE();
      GWPKS_SERVICE_ROUTER.PR_RESTORE();
    
      RETURN FALSE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of Fn_Process_Tanked_Entries ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      ROLLBACK TO SAVEPOINT SP_UNTANK;
      CSPKS_REQ_GLOBAL.PR_RESTORE();
      GWPKS_SERVICE_ROUTER.PR_RESTORE();
      RETURN FALSE;
  END FN_PROCESS_TANKED_ENTRIES;

  FUNCTION FN_COMPLETE_PENDING_TASKS(P_SOURCE           IN VARCHAR2,
                                     P_SOURCE_OPERATION IN VARCHAR2,
                                     P_FUNCTION_ID      IN VARCHAR2,
                                     P_ACTION_CODE      IN VARCHAR2,
                                     P_ERROR_CODE       IN OUT VARCHAR2,
                                     P_ERROR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In Fn_Complete_Pending_Tasks..');
    DBG('Returning Success From Fn_Complete_Pending_Tasks..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of Fn_Complete_Pending_Tasks ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERROR_CODE   := 'ST-PEND-001';
      P_ERROR_PARAMS := NULL;
      RETURN FALSE;
  END FN_COMPLETE_PENDING_TASKS;

  FUNCTION FN_LOG_OVERRIDES(P_MSG_ID      IN VARCHAR2,
                            P_REQ_SEQ_NO  IN VARCHAR2,
                            P_ERROR_CODE  IN OUT VARCHAR2,
                            P_ERROR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_ERROR_CODE VARCHAR2(255);
  
    L_ERROR_PARAMETER VARCHAR2(1000);
  
    L_OVD_COUNT       NUMBER;
    L_COUNTER         NUMBER := 0;
    L_REQ_ID          VARCHAR2(255);
    L_MAKER_REMARKS   VARCHAR2(4000);
    L_CHECKER_REMARKS VARCHAR2(4000);
  BEGIN
    DBG('In Fn_Log_Overrides..:' || P_MSG_ID || '/' ||
        NVL(P_REQ_SEQ_NO, 1));
    IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS(CSPKS_REQ_GLOBAL.G_MAKER_OVD_REMARKS) THEN
      L_MAKER_REMARKS := CSPKS_REQ_GLOBAL.G_HEADER(CSPKS_REQ_GLOBAL.G_MAKER_OVD_REMARKS);
    END IF;
    IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS(CSPKS_REQ_GLOBAL.G_CHECKER_OVD_REMARKS) THEN
      L_CHECKER_REMARKS := CSPKS_REQ_GLOBAL.G_HEADER(CSPKS_REQ_GLOBAL.G_CHECKER_OVD_REMARKS);
    END IF;
    BEGIN
      INSERT INTO CSTB_REQUEST_OVD_MASTER
        (MSG_ID, REQ_SEQ_NO, REQ_ID, MAKER_REMARKS, CHECKER_REMARKS)
      VALUES
        (P_MSG_ID,
         NVL(P_REQ_SEQ_NO, 1),
         L_REQ_ID,
         L_MAKER_REMARKS,
         L_CHECKER_REMARKS);
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        DBG('Not First time.. So Updating..');
        UPDATE CSTB_REQUEST_OVD_MASTER
           SET MAKER_REMARKS   = NVL(L_MAKER_REMARKS, MAKER_REMARKS),
               CHECKER_REMARKS = NVL(L_CHECKER_REMARKS, CHECKER_REMARKS)
         WHERE MSG_ID = P_MSG_ID
           AND REQ_SEQ_NO = NVL(P_REQ_SEQ_NO, 1);
      
    END;
  
    SELECT COUNT(*)
      INTO L_COUNTER
      FROM CSTB_REQUEST_OVD_DETAILS
     WHERE MSG_ID = P_MSG_ID
       AND REQ_SEQ_NO = NVL(P_REQ_SEQ_NO, 1);
    L_OVD_COUNT := OVPKSS.GL_TBLERROR.COUNT;
    DBG('LOGCNT :' || L_OVD_COUNT);
    IF OVPKSS.GL_TBLERROR.COUNT > 0 THEN
      FOR I IN 1 .. L_OVD_COUNT LOOP
        L_COUNTER         := L_COUNTER + 1;
        L_ERROR_CODE      := OVPKSS.GL_TBLERROR(I).ERR_CODE;
        L_ERROR_PARAMETER := OVPKSS.GL_TBLERROR(I).PARAMS;
        L_REQ_ID          := NVL(OVPKSS.GL_TBLERROR(I).REQID,
                                 NVL(P_REQ_SEQ_NO, 1));
        INSERT INTO CSTB_REQUEST_OVD_DETAILS
          (MSG_ID, REQ_SEQ_NO, REQ_ID, OVD_SEQ_NO, ERROR_CODE, ERROR_PARAM)
        VALUES
          (P_MSG_ID,
           NVL(P_REQ_SEQ_NO, 1),
           L_REQ_ID,
           L_COUNTER,
           L_ERROR_CODE,
           L_ERROR_PARAMETER);
      END LOOP;
    END IF;
    COMMIT;
    DBG('Returning Success From Fn_Log_Overrides..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in Fn_Log_Overrides..');
      DBG(SQLERRM);
      ROLLBACK;
      RETURN FALSE;
  END FN_LOG_OVERRIDES;

  FUNCTION FN_UPDATE_OVD_REMARKS(P_MSG_ID      IN VARCHAR2,
                                 P_REQ_SEQ_NO  IN VARCHAR2,
                                 P_ACTION_CODE IN VARCHAR2,
                                 P_ERROR_CODE  IN OUT VARCHAR2,
                                 P_ERROR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_MAKER_REMARKS   VARCHAR2(4000);
    L_CHECKER_REMARKS VARCHAR2(4000);
  BEGIN
    DBG('In Fn_Update_Ovd_Remarks..:' || P_MSG_ID || '/' || P_REQ_SEQ_NO || '/' ||
        P_ACTION_CODE);
    IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS(CSPKS_REQ_GLOBAL.G_MAKER_OVD_REMARKS) THEN
      L_MAKER_REMARKS := CSPKS_REQ_GLOBAL.G_HEADER(CSPKS_REQ_GLOBAL.G_MAKER_OVD_REMARKS);
    END IF;
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS(CSPKS_REQ_GLOBAL.G_CHECKER_OVD_REMARKS) THEN
        L_CHECKER_REMARKS := CSPKS_REQ_GLOBAL.G_HEADER(CSPKS_REQ_GLOBAL.G_CHECKER_OVD_REMARKS);
      END IF;
    END IF;
  
    DBG('Maker/Checkler Remarks :' || L_MAKER_REMARKS || '/' ||
        L_CHECKER_REMARKS);
    UPDATE CSTB_REQUEST_OVD_MASTER
       SET MAKER_REMARKS   = NVL(L_MAKER_REMARKS, MAKER_REMARKS),
           CHECKER_REMARKS = NVL(L_CHECKER_REMARKS, CHECKER_REMARKS)
     WHERE MSG_ID = P_MSG_ID
       AND REQ_SEQ_NO = P_REQ_SEQ_NO;
  
    DBG('Returning Success From ,p_Action_Code IN VARCHAR2..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in ,p_Action_Code IN VARCHAR2..');
      DBG(SQLERRM);
      ROLLBACK;
      RETURN FALSE;
  END FN_UPDATE_OVD_REMARKS;

  FUNCTION FN_POPULATE_AUDIT_LOG(P_ACTION_CODE IN VARCHAR2,
                                 P_ERROR_CODE  IN OUT VARCHAR2,
                                 P_ERROR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_MSG_ID     VARCHAR2(32767);
    L_SEQ_NO     NUMBER;
    L_REQ_KEY    VARCHAR2(32767);
    L_REQUEST_NO NUMBER;
  BEGIN
    DBG('In Fn_Populate_Audit_Log..');
    L_MSG_ID     := CSPKS_REQ_GLOBAL.G_HEADER('FCUBS_MSG_ID');
    L_REQ_KEY    := CSPKS_REQ_GLOBAL.FN_GET_REQ_KEY;
    L_REQUEST_NO := CSPKS_REQ_GLOBAL.FN_GET_REQ_NO;
    IF L_REQ_KEY IS NOT NULL THEN
      IF P_ACTION_CODE NOT IN (CSPKS_REQ_GLOBAL.P_DELETE) THEN
        DBG('Request Key Is Not Null..Populating Audit Log..');
        BEGIN
          SELECT LATEST_SEQ_NO
            INTO L_SEQ_NO
            FROM CSTB_AUDIT_MASTER
           WHERE REQ_KEY = L_REQ_KEY;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No Record in Audit Master ..');
            L_SEQ_NO := 0;
          WHEN OTHERS THEN
            DBG('Error While Fetching Audit Mater Record..');
            P_ERROR_CODE  := 'ST-OTHR-001';
            P_ERROR_PARAM := L_REQ_KEY;
            RETURN FALSE;
        END;
        L_SEQ_NO := L_SEQ_NO + 1;
        IF L_SEQ_NO > 1 THEN
          UPDATE CSTB_AUDIT_MASTER
             SET LATEST_SEQ_NO = L_SEQ_NO
           WHERE REQ_KEY = L_REQ_KEY;
        ELSE
          BEGIN
            INSERT INTO CSTB_AUDIT_MASTER
              (REQ_KEY, LATEST_SEQ_NO, LATEST_AUTH_SEQ_NO)
            VALUES
              (L_REQ_KEY, L_SEQ_NO, L_SEQ_NO);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed In Audit Logging..');
              DBG(SQLERRM);
              P_ERROR_CODE  := 'ST-OTHR-001';
              P_ERROR_PARAM := L_REQ_KEY;
              RETURN FALSE;
          END;
        END IF;
        BEGIN
          INSERT INTO CSTB_AUDIT_LOG
            (REQ_KEY, SEQ_NO, MSG_ID, REQ_SEQ_NO)
          VALUES
            (L_REQ_KEY, L_SEQ_NO, L_MSG_ID, L_REQUEST_NO);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Audit Logging..');
            DBG(SQLERRM);
            P_ERROR_CODE  := 'ST-OTHR-001';
            P_ERROR_PARAM := L_REQ_KEY;
            RETURN FALSE;
        END;
        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH OR
           CSPKS_REQ_GLOBAL.FN_GET_POST_UPL_STAT = 'A' THEN
          UPDATE CSTB_AUDIT_MASTER
             SET LATEST_AUTH_SEQ_NO = L_SEQ_NO
           WHERE REQ_KEY = L_REQ_KEY;
        END IF;
      END IF;
    END IF;
    DBG('Returning Success From Fn_Populate_Audit_Log..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Fn_Populate_Audit_Log ..');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN TRUE;
  END FN_POPULATE_AUDIT_LOG;

  FUNCTION FN_IS_REQ_FC_FORMAT(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                               P_FUNCTION_ID IN VARCHAR2) RETURN BOOLEAN IS
    L_FC_FORMAT BOOLEAN := FALSE;
  BEGIN
    DBG('In Fn_Is_Req_Fc_Format..');
    IF P_SOURCE = 'FLEXCUBE' OR G_REQ_SOURCE = 'FLEXCUBE' THEN
    
      L_FC_FORMAT := TRUE;
    ELSE
      L_FC_FORMAT := FALSE;
    END IF;
    RETURN L_FC_FORMAT;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of Fn_Is_Req_Fc_Format ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_IS_REQ_FC_FORMAT;

  FUNCTION FN_IS_RES_FC_FORMAT(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                               P_FUNCTION_ID IN VARCHAR2) RETURN BOOLEAN IS
  
    L_FC_FORMAT BOOLEAN := FALSE;
  BEGIN
    DBG('In Fn_Is_Res_Fc_Format..');
    IF P_SOURCE = 'FLEXCUBE' THEN
      L_FC_FORMAT := TRUE;
    ELSE
      L_FC_FORMAT := FALSE;
    END IF;
    RETURN L_FC_FORMAT;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of Fn_Is_Res_Fc_Format ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_IS_RES_FC_FORMAT;

  FUNCTION FN_GET_REPORT_PARAMS(P_BRANCH_CODE   IN VARCHAR2,
                                P_USER_ID       IN VARCHAR2,
                                P_GEN_MODE      IN VARCHAR2,
                                P_MAIN_FUNCTION IN VARCHAR2,
                                P_FUNCTION_ID   IN VARCHAR2,
                                P_CHR_PARAMS    IN OUT CSPKS_REQ_GLOBAL.TY_TB_CHR_FUNC_PARAMS,
                                P_ERROR_CODE    IN OUT VARCHAR2,
                                P_ERROR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_CALL_FORM       BOOLEAN := FALSE;
    L_BRN             VARCHAR2(32767);
    L_FID             VARCHAR2(32767);
    L_COUNT           NUMBER := 0;
    L_SPOOL_PATH      VARCHAR2(32767);
    L_REPORTPATH      VARCHAR2(32767);
    L_SPOOL_FILE_NAME VARCHAR2(32767);
    L_EOCDATE         VARCHAR2(200);
    L_SEPERATOR       VARCHAR2(1) := '/';
    L_NEXTREP         VARCHAR2(12);
    L_INT_PARAMS      CSPKS_REQ_GLOBAL.TY_TB_INT_FUNC_PARAMS;
  
    CURSOR C_REP_PARAMS(P_BRN          VARCHAR2,
                        P_FID          VARCHAR2,
                        P_END_OF_INPUT CHAR) IS
      SELECT *
        FROM AETB_FUNC_DETAIL
       WHERE BRANCH_CODE = P_BRN
         AND FUNCTION_ID = P_FID
         AND EOC_GROUP = P_END_OF_INPUT;
  
    L_END_OF_INPUT STTM_CORE_BRANCH_STATUS.END_OF_INPUT%TYPE;
  
  BEGIN
    DBG('In Fn_Get_Report_Params..');
    IF SUBSTR(P_FUNCTION_ID, 3, 1) = 'C' THEN
      L_CALL_FORM := TRUE;
    END IF;
  
    L_BRN := NVL(P_BRANCH_CODE, GLOBAL.CURRENT_BRANCH);
    L_FID := P_FUNCTION_ID;
  
    IF NOT GLOBALS_FRC_CORE.FN_GET_BRN_STATUS_REC_WRP(L_BRN,
                                                      P_ERROR_CODE,
                                                      P_ERROR_PARAMS) THEN
      DBG('Failed in the FRC bec of - ' || P_ERROR_CODE);
      L_END_OF_INPUT := NULL;
      P_ERROR_CODE   := NULL;
      P_ERROR_PARAMS := NULL;
    ELSE
      DBG('Success from FRC..');
      L_END_OF_INPUT := GLOBALS_FRC_CORE.G_TBL_STTM_BRANCH_STATUS_REC.END_OF_INPUT;
    END IF;
    DBG('l_end_of_input is - ' || L_END_OF_INPUT);
  
    OPEN C_REP_PARAMS(L_BRN, L_FID, L_END_OF_INPUT);
  
    LOOP
      FETCH C_REP_PARAMS BULK COLLECT
        INTO L_INT_PARAMS;
      EXIT WHEN C_REP_PARAMS%NOTFOUND;
    END LOOP;
    CLOSE C_REP_PARAMS;
  
    L_COUNT := L_INT_PARAMS.COUNT;
  
    IF L_COUNT = 0 THEN
      L_BRN := 'ALL';
      L_FID := P_FUNCTION_ID;
    
      OPEN C_REP_PARAMS(L_BRN, L_FID, L_END_OF_INPUT);
    
      LOOP
        FETCH C_REP_PARAMS BULK COLLECT
          INTO L_INT_PARAMS;
        EXIT WHEN C_REP_PARAMS%NOTFOUND;
      END LOOP;
      CLOSE C_REP_PARAMS;
    END IF;
    L_COUNT := L_INT_PARAMS.COUNT;
  
    BEGIN
      SELECT SPOOL_PATH
        INTO L_REPORTPATH
        FROM RPTMS_PARAMETERS
       WHERE BRANCH_CODE = P_BRANCH_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in Selecting Report Spool Path..');
        L_REPORTPATH := NULL;
        RETURN FALSE;
    END;
  
    SELECT TO_CHAR(GLOBAL.APPLICATION_DATE, 'DD-MM-YYYY')
      INTO L_EOCDATE
      FROM DUAL;
  
    IF SUBSTR(L_REPORTPATH, LENGTH(L_REPORTPATH), LENGTH(L_REPORTPATH)) IN
       ('/', '\') THEN
    
      L_SPOOL_PATH := L_REPORTPATH || P_BRANCH_CODE || L_SEPERATOR ||
                      L_EOCDATE || L_SEPERATOR;
    ELSE
      L_SPOOL_PATH := L_REPORTPATH || L_SEPERATOR || P_BRANCH_CODE ||
                      L_SEPERATOR || L_EOCDATE || L_SEPERATOR;
    END IF;
  
    L_COUNT := L_COUNT + 1;
    L_INT_PARAMS(L_COUNT).PARAM_NAME := 'FILEPATH';
    DBG('l_Spool_Path' || L_SPOOL_PATH);
    L_INT_PARAMS(L_COUNT).PARAM_VALUE := L_SPOOL_PATH;
  
    SELECT LTRIM(TO_CHAR(RPSQS_SERVERADV.NEXTVAL, '00000000'))
      INTO L_NEXTREP
      FROM DUAL;
  
    L_SPOOL_FILE_NAME := P_BRANCH_CODE || '_' || P_FUNCTION_ID || '_' ||
                         L_NEXTREP;
  
    L_COUNT := L_COUNT + 1;
    L_INT_PARAMS(L_COUNT).PARAM_NAME := 'FILENAME';
    L_INT_PARAMS(L_COUNT).PARAM_VALUE := L_SPOOL_FILE_NAME;
  
    IF L_COUNT > 0 THEN
      FOR I IN 1 .. L_COUNT LOOP
      
        L_INT_PARAMS(I).PARAM_VALUE := AEPKS_EOC_REPORTS.FN_GETPARM_VALUE(L_INT_PARAMS(I)
                                                                          .PARAM_VALUE,
                                                                          '',
                                                                          L_BRN,
                                                                          P_ERROR_CODE);
        P_CHR_PARAMS(L_INT_PARAMS(I).PARAM_NAME) := L_INT_PARAMS(I);
      
      END LOOP;
    
    END IF;
  
    DBG('Returning From  Fn_Get_Report_Params..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others Of  Fn_Get_Report_Params..');
      DBG(SQLERRM);
      IF C_REP_PARAMS%ISOPEN THEN
        CLOSE C_REP_PARAMS;
      END IF;
      P_ERROR_CODE   := 'RP-OTHR-001';
      P_ERROR_PARAMS := 'Fn_Get_Report_Params~' || SQLCODE;
      RETURN FALSE;
  END FN_GET_REPORT_PARAMS;

  FUNCTION FN_CHECK_BRANCH_RIGHTS(P_BRANCH_CODE  IN VARCHAR2,
                                  P_USER_ID      IN VARCHAR2,
                                  P_FUNCTION_ID  IN VARCHAR2,
                                  P_ERROR_CODE   IN OUT VARCHAR2,
                                  P_ERROR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_SMTB_MENU          BOOLEAN := FALSE;
    L_SMTB_USER          BOOLEAN := FALSE;
    L_SMVW_USER_BRANCHES BOOLEAN := FALSE;
    L_USER_MB_REQD       VARCHAR2(1);
    L_MENU_MB_REQD       VARCHAR2(1);
    L_COUNT              NUMBER := 0;
    RIGHTS_EXCEPTION EXCEPTION;
  
  BEGIN
  
    IF P_FUNCTION_ID NOT IN ('CLDPYMNT', 'CLDBLKPT', 'CLDPMNT') THEN
      IF P_BRANCH_CODE <> GLOBAL.CURRENT_BRANCH THEN
        SELECT NVL(MULTIBRANCH_ACCESS, 'N')
          INTO L_USER_MB_REQD
          FROM SMTB_USER
         WHERE USER_ID = P_USER_ID;
      
        IF L_USER_MB_REQD = 'Y' THEN
          DBG('fn_check_branch_rights --> User Right is there..');
        
          IF NOT
              GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                        P_ERROR_CODE,
                                                        P_ERROR_PARAMS) THEN
            DBG('Failed in FRC bec of - ' || P_ERROR_CODE);
            DBG('Exception was not handled for the query...so raising the final exception..');
            P_ERROR_CODE   := 'ST-MTLG-001';
            P_ERROR_PARAMS := NULL;
            RETURN FALSE;
          ELSE
            DBG('Returned success from FRC..');
            L_MENU_MB_REQD := NVL(GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.MULTIBRANCH_ACCESS,
                                  'N');
          END IF;
          DBG('Value of l_menu_mb_reqd is - ' || L_MENU_MB_REQD);
        
        ELSE
          RAISE RIGHTS_EXCEPTION;
        END IF;
      
        IF L_MENU_MB_REQD = 'Y' THEN
          DBG('fn_check_branch_rights --> Menu Right is there..');
          SELECT COUNT(*)
            INTO L_COUNT
            FROM SMVW_USER_BRANCHES
           WHERE BRANCH_CODE = P_BRANCH_CODE
             AND USER_ID = P_USER_ID;
        ELSE
          RAISE RIGHTS_EXCEPTION;
        END IF;
      
        IF L_COUNT = 0 THEN
          DBG('fn_check_branch_rights --> no rights available..');
          RAISE RIGHTS_EXCEPTION;
        END IF;
      END IF;
    END IF;
    RETURN TRUE;
  
  EXCEPTION
    WHEN RIGHTS_EXCEPTION THEN
      DEBUG.PR_DEBUG('**',
                     'In When rights_exception Of fn_chck_branch_rights ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERROR_CODE   := 'ST-QRY-101';
      P_ERROR_PARAMS := NULL;
      RETURN FALSE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others Of fn_chck_branch_rights ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERROR_CODE   := 'ST-MTLG-001';
      P_ERROR_PARAMS := NULL;
      RETURN FALSE;
  END FN_CHECK_BRANCH_RIGHTS;

  PROCEDURE PR_RESET_SKIP_VAR(P_SKIP_KERNEL      OUT BOOLEAN,
                              P_SKIP_PRECLUSTER  OUT BOOLEAN,
                              P_SKIP_POSTCLUSTER OUT BOOLEAN,
                              P_SKIP_CUSTOM      OUT BOOLEAN) IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      P_SKIP_KERNEL      := FALSE;
      P_SKIP_PRECLUSTER  := TRUE;
      P_SKIP_POSTCLUSTER := TRUE;
      P_SKIP_CUSTOM      := TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CLUSTER THEN
    
      P_SKIP_KERNEL      := FALSE;
      P_SKIP_PRECLUSTER  := FALSE;
      P_SKIP_POSTCLUSTER := FALSE;
      P_SKIP_CUSTOM      := TRUE;
    
    ELSE
      P_SKIP_KERNEL      := FALSE;
      P_SKIP_PRECLUSTER  := FALSE;
      P_SKIP_POSTCLUSTER := FALSE;
      P_SKIP_CUSTOM      := FALSE;
    
    END IF;
  END PR_RESET_SKIP_VAR;

  PROCEDURE PR_SET_SKIP_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := TRUE;
  END PR_SET_SKIP_KERNEL;

  PROCEDURE PR_SET_ACTIVATE_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := FALSE;
  END PR_SET_ACTIVATE_KERNEL;

  PROCEDURE PR_SET_SKIP_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := TRUE;
  END PR_SET_SKIP_CLUSTER;

  PROCEDURE PR_SET_ACTIVATE_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := FALSE;
  END PR_SET_ACTIVATE_CLUSTER;

  PROCEDURE PR_SET_SKIP_CUSTOM IS
  BEGIN
    G_SKIP_CUSTOM := TRUE;
  END PR_SET_SKIP_CUSTOM;

  PROCEDURE PR_SET_ACTIVATE_CUSTOM IS
  BEGIN
    G_SKIP_CUSTOM := FALSE;
  END PR_SET_ACTIVATE_CUSTOM;

  FUNCTION FN_SKIP_CUSTOM RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_KERNEL, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      RETURN TRUE;
    ELSE
      RETURN G_SKIP_CUSTOM;
    END IF;
  END FN_SKIP_CUSTOM;

  FUNCTION FN_SKIP_KERNEL RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_KERNEL;
    END IF;
  END FN_SKIP_KERNEL;

  FUNCTION FN_SKIP_CLUSTER RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN TRUE;
    ELSE
      RETURN G_SKIP_CLUSTER;
    END IF;
  END FN_SKIP_CLUSTER;

  FUNCTION FN_INSERT_SNAPSHOT(P_KEY_ID      IN SMTB_KEY_SNAPSHOT_LOG.KEY_ID%TYPE,
                              P_FUNCTION_ID IN OUT SMTB_KEY_SNAPSHOT_LOG.FUNCTION_ID%TYPE,
                              P_ACTION      IN SMTB_KEY_SNAPSHOT_LOG.ACTION%TYPE,
                              P_USER_ID     IN SMTB_KEY_SNAPSHOT_LOG.USER_ID%TYPE,
                              P_SNAPSHOT_ID OUT SMTB_KEY_SNAPSHOT_LOG.SNAPSHOT_ID%TYPE)
    RETURN BOOLEAN IS
  
    L_CURR_SNAPSHOT_ID   NUMBER := 0;
    L_COUNT              NUMBER := 0;
    L_PARENT_FUNCTION_ID SMTB_KEY_FUNCTION_ID.PARENT_FUNCTION_ID%TYPE;
  BEGIN
    DBG('Inside Fn_Insert_Snapshot ..');
    DBG('P_KEY_ID IS :' || P_KEY_ID);
    IF P_KEY_ID IS NOT NULL THEN
      BEGIN
      
        BEGIN
          SELECT PARENT_FUNCTION_ID
            INTO L_PARENT_FUNCTION_ID
            FROM SMTB_KEY_FUNCTION_ID
           WHERE FUNCTION_ID = P_FUNCTION_ID;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_PARENT_FUNCTION_ID := NULL;
        END;
      
        IF L_PARENT_FUNCTION_ID IS NULL THEN
          DBG('Selecting current max snapshot id.');
          SELECT MAX(SNAPSHOT_ID)
            INTO L_CURR_SNAPSHOT_ID
            FROM SMTB_KEY_SNAPSHOT_LOG
           WHERE KEY_ID = P_KEY_ID
             AND FUNCTION_ID = P_FUNCTION_ID;
        
          L_PARENT_FUNCTION_ID := P_FUNCTION_ID;
        ELSE
          DBG('Selecting current max snapshot id.');
          SELECT MAX(SNAPSHOT_ID)
            INTO L_CURR_SNAPSHOT_ID
            FROM SMTB_KEY_SNAPSHOT_LOG
           WHERE KEY_ID = P_KEY_ID
             AND FUNCTION_ID = L_PARENT_FUNCTION_ID;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Inside When Others of while selecting max ');
          L_CURR_SNAPSHOT_ID := 0;
      END;
    
      INSERT INTO SMTB_KEY_SNAPSHOT_LOG
        (KEY_ID, SNAPSHOT_ID, FUNCTION_ID, ACTION, USER_ID)
      
      VALUES
        (P_KEY_ID,
         NVL(L_CURR_SNAPSHOT_ID, 0) + 1,
         L_PARENT_FUNCTION_ID,
         P_ACTION,
         P_USER_ID);
    
      P_SNAPSHOT_ID := NVL(L_CURR_SNAPSHOT_ID, 0) + 1;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Inside When Others of Fn_Insert_Snapshot.. ');
      DBG('SQLERRM : ' || SQLERRM);
      DBG('Trace : ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_INSERT_SNAPSHOT;

  FUNCTION FN_CHECK_SNAPSHOT(P_KEY_ID      IN SMTB_KEY_SNAPSHOT_LOG.KEY_ID%TYPE,
                             P_FUNCTION_ID IN OUT SMTB_KEY_SNAPSHOT_LOG.FUNCTION_ID%TYPE,
                             P_SNAPSHOT_ID IN SMTB_KEY_SNAPSHOT_LOG.SNAPSHOT_ID%TYPE)
    RETURN BOOLEAN IS
  
    L_CURR_SNAPSHOT_ID   NUMBER := 0;
    L_COUNT              NUMBER := 0;
    L_PARENT_FUNCTION_ID SMTB_KEY_FUNCTION_ID.PARENT_FUNCTION_ID%TYPE;
  BEGIN
    DBG('Inside Fn_Check_Snapshot ..');
  
    BEGIN
      BEGIN
        SELECT PARENT_FUNCTION_ID
          INTO L_PARENT_FUNCTION_ID
          FROM SMTB_KEY_FUNCTION_ID
         WHERE FUNCTION_ID = P_FUNCTION_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_PARENT_FUNCTION_ID := NULL;
      END;
      IF L_PARENT_FUNCTION_ID IS NULL THEN
        DBG('Selecting current max snapshot id.');
        SELECT MAX(SNAPSHOT_ID)
          INTO L_CURR_SNAPSHOT_ID
          FROM SMTB_KEY_SNAPSHOT_LOG
         WHERE KEY_ID = P_KEY_ID
           AND FUNCTION_ID = P_FUNCTION_ID;
        L_PARENT_FUNCTION_ID := P_FUNCTION_ID;
      ELSE
        DBG('Selecting current max snapshot id.');
        SELECT MAX(SNAPSHOT_ID)
          INTO L_CURR_SNAPSHOT_ID
          FROM SMTB_KEY_SNAPSHOT_LOG
         WHERE KEY_ID = P_KEY_ID
           AND FUNCTION_ID = L_PARENT_FUNCTION_ID;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Inside When Others of while selecting max ');
        L_CURR_SNAPSHOT_ID := 0;
    END;
  
    IF L_CURR_SNAPSHOT_ID <> NVL(P_SNAPSHOT_ID, 0) THEN
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Inside When Others of Fn_Check_Snapshot.. ');
      DBG('SQLERRM : ' || SQLERRM);
      DBG('Trace : ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_CHECK_SNAPSHOT;

  FUNCTION FN_GET_SNAPSHOT(P_KEY_ID      IN SMTB_KEY_SNAPSHOT_LOG.KEY_ID%TYPE,
                           P_FUNCTION_ID IN OUT SMTB_KEY_SNAPSHOT_LOG.FUNCTION_ID%TYPE)
    RETURN VARCHAR2 IS
    L_SNAPSHOT_ID        SMTB_KEY_SNAPSHOT_LOG.SNAPSHOT_ID%TYPE;
    L_COUNT              NUMBER := 0;
    L_PARENT_FUNCTION_ID SMTB_KEY_FUNCTION_ID.PARENT_FUNCTION_ID%TYPE;
  BEGIN
    DBG('Inside Fn_Get_Snapshot ..');
  
    BEGIN
      BEGIN
        SELECT PARENT_FUNCTION_ID
          INTO L_PARENT_FUNCTION_ID
          FROM SMTB_KEY_FUNCTION_ID
         WHERE FUNCTION_ID = P_FUNCTION_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_PARENT_FUNCTION_ID := NULL;
      END;
      IF L_PARENT_FUNCTION_ID IS NULL THEN
        DBG('Selecting current max snapshot id.');
        SELECT MAX(SNAPSHOT_ID)
          INTO L_SNAPSHOT_ID
          FROM SMTB_KEY_SNAPSHOT_LOG
         WHERE KEY_ID = P_KEY_ID
           AND FUNCTION_ID = P_FUNCTION_ID;
        L_PARENT_FUNCTION_ID := P_FUNCTION_ID;
      ELSE
        DBG('Selecting current max snapshot id.');
        SELECT MAX(SNAPSHOT_ID)
          INTO L_SNAPSHOT_ID
          FROM SMTB_KEY_SNAPSHOT_LOG
         WHERE KEY_ID = P_KEY_ID
           AND FUNCTION_ID = L_PARENT_FUNCTION_ID;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Inside When Others of while selecting max ');
        L_SNAPSHOT_ID := 0;
    END;
  
    RETURN L_SNAPSHOT_ID;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Inside When Others of Fn_Check_Snapshot.. ');
      DBG('SQLERRM : ' || SQLERRM);
      DBG('Trace : ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN '';
  END FN_GET_SNAPSHOT;

  PROCEDURE PR_SET_REQ_SOURCE(P_REQ_SOURCE VARCHAR2) IS
  BEGIN
    G_REQ_SOURCE := P_REQ_SOURCE;
  END PR_SET_REQ_SOURCE;

END CSPKS_REQ_UTILS;
