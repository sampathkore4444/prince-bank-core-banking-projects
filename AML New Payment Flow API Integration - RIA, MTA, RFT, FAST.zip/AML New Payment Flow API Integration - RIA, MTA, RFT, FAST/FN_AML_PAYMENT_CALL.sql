CREATE OR REPLACE FUNCTION FN_AML_PAYMENT_CALL(P_USER_NAME               IN VARCHAR2,
                                               P_BRANCH_CODE             IN VARCHAR2,
                                               P_SYS_NAME                IN VARCHAR2,
                                               P_UNIQUE_NO               IN VARCHAR2,
                                               P_SEARCH_NAME             IN VARCHAR2,
                                               P_SEARCH_COUNTRY          IN VARCHAR2,
                                               P_SEARCH_F1               IN VARCHAR2,
                                               P_SEARCH_ID               IN VARCHAR2,
                                               P_PASSPORT_VERIFY         IN VARCHAR2,
                                               P_SECURITY_NO1            IN VARCHAR2,
                                               P_PASSPORT_EXPDATE_VERIFY IN VARCHAR2,
                                               P_PASSPORT_EXPDATE        IN VARCHAR2,
                                               P_SECURITY_NO2            IN VARCHAR2,
                                               P_RISK_FACTORS            IN VARCHAR2,
                                               P_SEARCH_F2               IN VARCHAR2,
                                               P_SEARCH_F3               IN VARCHAR2,
                                               P_SEARCH_F4               IN VARCHAR2,
                                               P_SEARCH_F5               IN VARCHAR2,
                                               P_SEARCH_F6               IN VARCHAR2,
                                               P_SEARCH_F7               IN VARCHAR2,
                                               P_SEARCH_F8               IN VARCHAR2,
                                               P_SEARCH_F9               IN VARCHAR2,
                                               P_PROD_CHANNEL            IN VARCHAR2,
                                               P_CONTENT                 IN VARCHAR2,
                                               P_RETURN_HIT              IN VARCHAR2,
                                               P_RETURN_SCANID           IN VARCHAR2,
                                               P_RETURN_ENCRYPT_SCANID   IN VARCHAR2,
                                               P_RESPONSE                OUT CLOB)
  RETURN BOOLEAN AS

  l_http_request  utl_http.req;
  l_http_response utl_http.resp;
  url             varchar2(4000) := 'http://10.80.80.9:80/AMLWSRMT/AMLWSRMT.svc/OnlineScan';
  name            varchar2(4000);
  buffer          varchar2(32767);
  buffer1         clob;
  buffer2         clob;
  l_resp_ok       BOOLEAN;
  l_resp_num      NUMBER;
  L_CONTENT       CLOB := '{
    "AuthUser": "AMLSVC",
    "AuthPswd": "AMLSVC",
    "Username": "$L_USER_NAME",
    "BrCode": "$L_BRANCH_CODE",
    "SysName": "$L_SYS_NAME",
    "ScanOption": "9",
    "UniqueNo": "$L_UNIQUE_NO",
    "SearchName":"$L_SEARCH_NAME",
    "SearchCountry": "$L_SEARCH_COUNTRY",
    "SearchF1": "$L_SEARCH_F1",
    "SearchID": "$L_SEARCH_ID",
    "PassportVerify": "$L_PASSPORT_VERIFY",
    "SecurityNo1": "$L_SECURITY_NO1",
    "PassExpiryDtVerify": "$L_PASSPORT_EXPDATE_VERIFY",
    "PassExpiryDate": "$L_PASSPORT_EXPDATE",
    "SecurityNo2": "$L_SECURITY_NO2",
    "RiskFactors": "$L_RISK_FACTORS",
    "SearchF2": "$L_SEARCH_F2",
    "SearchF3": "$L_SEARCH_F3",
    "SearchF4": "$L_SEARCH_F4",
    "SearchF5": "$L_SEARCH_F5",
    "SearchF6": "$L_SEARCH_F6",
    "SearchF7": "$L_SEARCH_F7",
    "SearchF8": "$L_SEARCH_F8",
    "SearchF9": "$L_SEARCH_F9",
    "ProdChannel": "$L_PROD_CHANNEL",
    "Content": "$L_CONTENT",
    "RtnHit": "$L_RETURN_HIT",
    "RtnScanID":"0",
    "RtnAlertID":"0",
    "RtnEnCryptScanID":"$L_RETURN_ENCRYPT_SCANID"
}';

  FUNCTION FN_GET_FORMATTED_MSG(P_RAW_CONTENT             IN VARCHAR2,
                                P_USER_NAME               IN VARCHAR2,
                                P_BRANCH_CODE             IN VARCHAR2,
                                P_SYS_NAME                IN VARCHAR2,
                                P_UNIQUE_NO               IN VARCHAR2,
                                P_SEARCH_NAME             IN VARCHAR2,
                                P_SEARCH_COUNTRY          IN VARCHAR2,
                                P_SEARCH_F1               IN VARCHAR2,
                                P_SEARCH_ID               IN VARCHAR2,
                                P_PASSPORT_VERIFY         IN VARCHAR2,
                                P_SECURITY_NO1            IN VARCHAR2,
                                P_PASSPORT_EXPDATE_VERIFY IN VARCHAR2,
                                P_PASSPORT_EXPDATE        IN VARCHAR2,
                                P_SECURITY_NO2            IN VARCHAR2,
                                P_RISK_FACTORS            IN VARCHAR2,
                                P_SEARCH_F2               IN VARCHAR2,
                                P_SEARCH_F3               IN VARCHAR2,
                                P_SEARCH_F4               IN VARCHAR2,
                                P_SEARCH_F5               IN VARCHAR2,
                                P_SEARCH_F6               IN VARCHAR2,
                                P_SEARCH_F7               IN VARCHAR2,
                                P_SEARCH_F8               IN VARCHAR2,
                                P_SEARCH_F9               IN VARCHAR2,
                                P_PROD_CHANNEL            IN VARCHAR2,
                                P_CONTENT                 IN VARCHAR2,
                                P_RETURN_HIT              IN VARCHAR2,
                                P_RETURN_SCANID           IN VARCHAR2,
                                P_RETURN_ENCRYPT_SCANID   IN VARCHAR2)
    RETURN CLOB AS
  
    L_FORMATTED_MSG VARCHAR2(32767);
  
  BEGIN
  
    L_FORMATTED_MSG := P_RAW_CONTENT;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_USER_NAME', P_USER_NAME);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BRANCH_CODE',
                               P_BRANCH_CODE);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SYS_NAME', P_SYS_NAME);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_UNIQUE_NO', P_UNIQUE_NO);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEARCH_NAME',
                               P_SEARCH_NAME);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEARCH_COUNTRY',
                               P_SEARCH_COUNTRY);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F1', P_SEARCH_F1);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_ID', P_SEARCH_ID);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PASSPORT_VERIFY',
                               P_PASSPORT_VERIFY);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SECURITY_NO1',
                               P_SECURITY_NO1);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PASSPORT_EXPDATE_VERIFY',
                               P_PASSPORT_EXPDATE_VERIFY);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PASSPORT_EXPDATE',
                               P_PASSPORT_EXPDATE);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SECURITY_NO2',
                               P_SECURITY_NO2);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RISK_FACTORS',
                               P_RISK_FACTORS);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F2', P_SEARCH_F2);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F3', P_SEARCH_F3);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F4', P_SEARCH_F4);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F5', P_SEARCH_F5);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F6', P_SEARCH_F6);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F7', P_SEARCH_F7);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F8', P_SEARCH_F8);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F9', P_SEARCH_F9);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PROD_CHANNEL',
                               P_PROD_CHANNEL);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CONTENT', P_CONTENT);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RETURN_HIT',
                               P_RETURN_HIT);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RETURN_SCANID',
                               P_RETURN_SCANID);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RETURN_SCANID',
                               P_RETURN_SCANID);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RETURN_ENCRYPT_SCANID',
                               P_RETURN_ENCRYPT_SCANID);
  
    RETURN L_FORMATTED_MSG;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED IN FN_GET_FORMATTED_MSG');
      DEBUG.PR_DEBUG('AC',
                     'ERROR CODE IN FN_GET_FORMATTED_MSG=' || SQLCODE);
      DEBUG.PR_DEBUG('AC',
                     'ERROR MESSAGE IN FN_GET_FORMATTED_MSG=' || SQLERRM);
    
  END FN_GET_FORMATTED_MSG;

begin

  L_CONTENT := FN_GET_FORMATTED_MSG(L_CONTENT,
                                    P_USER_NAME,
                                    P_BRANCH_CODE,
                                    P_SYS_NAME,
                                    P_UNIQUE_NO,
                                    P_SEARCH_NAME,
                                    P_SEARCH_COUNTRY,
                                    P_SEARCH_F1,
                                    P_SEARCH_ID,
                                    P_PASSPORT_VERIFY,
                                    P_SECURITY_NO1,
                                    P_PASSPORT_EXPDATE_VERIFY,
                                    P_PASSPORT_EXPDATE,
                                    P_SECURITY_NO2,
                                    P_RISK_FACTORS,
                                    P_SEARCH_F2,
                                    P_SEARCH_F3,
                                    P_SEARCH_F4,
                                    P_SEARCH_F5,
                                    P_SEARCH_F6,
                                    P_SEARCH_F7,
                                    P_SEARCH_F8,
                                    P_SEARCH_F9,
                                    P_PROD_CHANNEL,
                                    P_CONTENT,
                                    P_RETURN_HIT,
                                    P_RETURN_SCANID,
                                    P_RETURN_ENCRYPT_SCANID);

  l_http_request := utl_http.begin_request(url, 'POST', ' HTTP/1.1');
  utl_http.set_authentication(l_http_request,
                              'prince',
                              'qwer!@#$',
                              'Basic');
  utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
  utl_http.set_header(l_http_request, 'content-type', 'application/json');
  utl_http.set_header(l_http_request, 'Content-Length', length(L_CONTENT));

  --UTL_HTTP.SET_BODY_CHARSET('UTF-8');

  dbms_output.put_line('L_CONTENT=' || L_CONTENT);

  utl_http.write_text(l_http_request, L_CONTENT);

  UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(L_CONTENT));

  l_http_response := utl_http.get_response(l_http_request);

  dbms_output.put_line('status code=' || l_http_response.status_code);

  l_resp_ok := FALSE;
  SELECT decode(l_http_response.status_code, 200, 1, 0)
    INTO l_resp_num
    FROM dual;

  dbms_output.put_line('l_resp_num=' || l_resp_num);

  IF l_resp_num = 1 THEN
    l_resp_ok := TRUE;
  ELSIF l_resp_num = 0 THEN
    l_resp_ok := FALSE;
  END IF;

  IF l_resp_ok THEN
    -- process the response from the HTTP call
    begin
      loop
        utl_http.read_line(l_http_response, buffer);
        --dbms_output.put_line(buffer);
        buffer1 := buffer1 || buffer;
      end loop;
      utl_http.end_response(l_http_response);
    exception
      when utl_http.end_of_body then
        utl_http.end_response(l_http_response);
      when others then
        dbms_output.put_line('ERROR CODE=' || SQLCODE);
        dbms_output.put_line('ERROR MESSAGE=' || SQLERRM);
    end;
  
    P_RESPONSE := buffer1;
  
    debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);
  
  END IF;

  IF l_http_request.private_hndl IS NOT NULL THEN
    utl_http.end_request(l_http_request);
  END IF;

  IF l_http_response.private_hndl IS NOT NULL THEN
    utl_http.end_response(l_http_response);
  END IF;

  --    dbms_lob.freetemporary(buffer1); --buffer2 may be check

  IF l_resp_ok THEN
    dbms_output.put_line('OK_RETURN TRUE NOW');
    RETURN TRUE;
  ELSE
    dbms_output.put_line('PROBLEM...RETURN FALSE');
    RETURN FALSE;
  END IF;

  RETURN TRUE;

EXCEPTION
  WHEN OTHERS THEN
    DEBUG.PR_DEBUG('AC', 'FAILED IN FN_AML_PAYMENT_CALL');
    DEBUG.PR_DEBUG('AC', 'ERROR CODE IN FN_AML_PAYMENT_CALL=' || SQLCODE);
    DEBUG.PR_DEBUG('AC',
                   'ERROR MESSAGE IN FN_AML_PAYMENT_CALL=' || SQLERRM);
    RETURN FALSE;
END FN_AML_PAYMENT_CALL;
