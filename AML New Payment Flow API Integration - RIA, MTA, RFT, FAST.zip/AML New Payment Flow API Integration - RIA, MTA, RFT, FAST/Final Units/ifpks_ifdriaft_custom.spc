CREATE OR REPLACE PACKAGE ifpks_ifdriaft_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdriaft_custom.spc
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2022 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  SFR Number         :
  Changed By         :
  Change Description :

  -------------------------------------------------------------------------------------------------------
  */

  L_RIA_DYNAMIC_FEE NUMBER(22, 3);

  PROCEDURE Pr_Skip_Handler(P_Stage IN VARCHAR2);

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC;

  FUNCTION Fn_Post_Build_Type_Structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdriaft         IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdriaft         IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdriaft         IN ifpks_ifdriaft_Main.ty_ifdriaft,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Pre_Default_And_Validate(p_source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdriaft         IN ifpks_ifdriaft_Main.Ty_ifdriaft,
                                       p_Prev_ifdriaft    IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                                       p_Wrk_ifdriaft     IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdriaft         IN ifpks_ifdriaft_Main.Ty_ifdriaft,
                                        p_Prev_ifdriaft    IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                                        p_Wrk_ifdriaft     IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdriaft         IN ifpks_ifdriaft_Main.ty_ifdriaft,
                            p_Prev_ifdriaft    IN ifpks_ifdriaft_Main.ty_ifdriaft,
                            p_Wrk_ifdriaft     IN OUT ifpks_ifdriaft_Main.ty_ifdriaft,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_source_operation IN VARCHAR2,
                             p_Function_id      IN VARCHAR2,
                             p_action_code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdriaft         IN ifpks_ifdriaft_Main.ty_ifdriaft,
                             p_Prev_ifdriaft    IN ifpks_ifdriaft_Main.ty_ifdriaft,
                             p_Wrk_ifdriaft     IN OUT ifpks_ifdriaft_Main.ty_ifdriaft,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdriaft         IN ifpks_ifdriaft_Main.ty_ifdriaft,
                        p_Wrk_ifdriaft     IN OUT ifpks_ifdriaft_Main.ty_ifdriaft,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdriaft         IN ifpks_ifdriaft_Main.Ty_ifdriaft,
                         p_Wrk_ifdriaft     IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_GET_RIA_PAYMENT_CASHPICKUP RETURN CLOB;

  FUNCTION FN_GET_FMT_RIA_PAY_CASHPIC_DIG(P_TXN_UNIQUE_NO IN VARCHAR2,
                                          P_BEN_COUNTRY   IN VARCHAR2,
                                          P_PAY_CCY       IN VARCHAR2,
                                          P_PAY_AMOUNT    IN VARCHAR2,
                                          P_OFS_ACC       IN VARCHAR2,
                                          P_BEN_FIRSTNAME IN VARCHAR2,
                                          P_BEN_LASTNAME  IN VARCHAR2,
                                          P_BEN_CITY      IN VARCHAR2,
                                          P_BEN_STATE     IN VARCHAR2)
    RETURN CLOB;

  FUNCTION FN_GET_FMT_RIA_PAYMENT_DIG(P_TXN_UNIQUE_NO_RIAA         IN VARCHAR2,
                                      P_BEN_COUNTRY_RIAA           IN VARCHAR2,
                                      P_PAYMENT_CCY                IN VARCHAR2,
                                      P_PAYMENT_AMOUNT             IN VARCHAR2,
                                      P_OFS_ACC                    IN VARCHAR2,
                                      P_BEN_FIRST_NAME_RIAA        IN VARCHAR2,
                                      P_BEN_LAST_NAME_RIAA         IN VARCHAR2,
                                      P_BANK_ID_RIAA               IN VARCHAR2,
                                      P_BEN_ACCOUNT_NO_RIAA        IN VARCHAR2,
                                      P_BEN_CITY_RIAA              IN VARCHAR2,
                                      P_BEN_STATE_RIAA             IN VARCHAR2,
                                      P_BANK_ACCOUNT_TYPE_RIAA     IN VARCHAR2,
                                      P_BANK_ROUTING_CODE_RIAA     IN VARCHAR2,
                                      P_PURPOSE_OF_TRF_RIAA        IN VARCHAR2,
                                      P_BEN_ID_TYPE_RIAA           IN VARCHAR2,
                                      P_BEN_ID_NO_RIAA             IN VARCHAR2,
                                      P_BIC_SWIFT_RIAA             IN VARCHAR2,
                                      P_BEN_PHONE_RIAA             IN VARCHAR2,
                                      P_VALUE_TYPE_RIAA            IN VARCHAR2,
                                      P_BEN_ADDRESS_RIAA           IN VARCHAR2,
                                      P_CUST_BEN_RELATIONSHIP_RIAA IN VARCHAR2,
                                      P_UNITARY_BANK_ACC_NO_RIAA   IN VARCHAR2,
                                      P_BEN_CELL_NO_RIAA           IN VARCHAR2)
    RETURN CLOB;

  FUNCTION fn_msg_upload_dig(P_TRN_REF_NO IN OUT VARCHAR2,
                             P_REQ_TYPE   IN VARCHAR2,
                             P_REQ_MSG    IN OUT CLOB,
                             P_ADDL_INFO  IN VARCHAR2,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2,
                             P_RIA_PIN    OUT VARCHAR2) RETURN BOOLEAN;
  
  --AML New Payment Flow Starts
  
  FUNCTION FN_GET_BEN_AGENT_NAME(P_AGENT_ID IN IFTB_RIA_AGENT_DTLS.CORRESPONDENT_ID%TYPE)
    RETURN LMTM_TYPE_VALUES.VALUE%TYPE;
    
  FUNCTION FN_GET_BEN_BANK_NAME(P_BANK_ID IN IFTB_RIA_BANK_DTLS.BANK_ID%TYPE)
    RETURN LMTM_TYPE_VALUES.VALUE%TYPE;
  
  --AML New Payment Flow Ends
  
END ifpks_ifdriaft_custom;
