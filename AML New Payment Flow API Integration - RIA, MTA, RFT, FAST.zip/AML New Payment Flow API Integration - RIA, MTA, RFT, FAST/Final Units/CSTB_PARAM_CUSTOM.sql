prompt Importing table CSTB_PARAM_CUSTOM...
set feedback off
set define off
insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('CORAL_VALIDATE_PAY_WS_URL_A', 'http://10.80.81.80/AMLWSRMTA/AMLWSRMT.svc?singleWsdl', 'N');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('CORAL_VALIDATE_PAY_WS_URL_B', 'http://10.80.81.80/AMLWSRMTB/AMLWSRMT.svc?singleWsdl', 'N');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('CORAL_VALIDATION_PAY_STAT_URL', 'http://10.80.81.80/AMLRMTStatus/AMLStatus.svc?singleWsdl', 'N');

prompt Done.
