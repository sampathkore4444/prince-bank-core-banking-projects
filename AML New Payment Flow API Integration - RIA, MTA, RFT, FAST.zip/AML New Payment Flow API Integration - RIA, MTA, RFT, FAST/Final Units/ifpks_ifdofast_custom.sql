CREATE OR REPLACE PACKAGE BODY ifpks_ifdofast_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdofast_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2018 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India

  **    Modified By      : KORE SAMPATH KUMAR
  **    Modified Reason  : PRINCE FAST Interface Changes
  **    Modified On      : 21-June-2018
  **    Search String    : PRINCE 12.4 FAST CUSTOMIZATION CHANGES



  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE dbg(p_msg VARCHAR2) IS
    l_msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_msg := 'ifpks_ifdofast_Custom ==>' || p_msg;
      debug.pr_debug('IF', l_msg);
    END IF;
  END dbg;

  PROCEDURE pr_log_error(p_function_id IN VARCHAR2,
                         p_source      VARCHAR2,
                         p_err_code    VARCHAR2,
                         p_err_params  VARCHAR2) IS
  BEGIN
    cspks_req_utils.pr_log_error(p_source,
                                 p_function_id,
                                 p_err_code,
                                 p_err_params);
  END pr_log_error;

  PROCEDURE pr_skip_handler(p_stage IN VARCHAR2) IS
  BEGIN
    --DBG('In Pr_Skip_Handler..');
    NULL;
  END pr_skip_handler;

  -- PRINCE 12.4 FAST CUSTOMIZATION CHANGES - START

  FUNCTION get_param_val(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END get_param_val;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN

    SELECT TRSQ_FAST_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;

    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

    RETURN L_REF;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  PROCEDURE PR_UPDATE_STATUS_FAST_OUTGOING(P_TRN_REF_NO IN VARCHAR2,
                                           P_STATUS     IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_TXN_REMARKS IFTBS_FAST_MASTER.TXN_REMARKS%TYPE;
  BEGIN
    DBG('START OF PR_UPDATE_STATUS_FAST_OUTGOING');
    DBG('BEFORE UPDATING IFTBS_FAST_MASTER');

    --Get Remarks for a status
    BEGIN
      SELECT VALUE
        INTO L_TXN_REMARKS
        FROM LMTM_TYPE_VALUES
       WHERE TYPE = 'FAST_OUT_STATUS'
         AND CODE = P_STATUS;
    EXCEPTION
      WHEN OTHERS THEN
        L_TXN_REMARKS := NULL;
    END;

    DBG('L_TXN_REMARKS=' || L_TXN_REMARKS);

    UPDATE IFTBS_FAST_MASTER
       SET TXN_STATUS = P_STATUS, TXN_REMARKS = L_TXN_REMARKS
     WHERE TRN_REF_NO = P_TRN_REF_NO;

    DBG('AFTER UPDATING IFTBS_FAST_MASTER');
    COMMIT;
    DBG('END OF PR_UPDATE_STATUS_FAST_OUTGOING');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_STATUS_FAST_OUTGOING');
  END PR_UPDATE_STATUS_FAST_OUTGOING;

  PROCEDURE PR_UPDATE_STATUS_FAST_INCOMING(P_TRN_REF_NO IN VARCHAR2,
                                           P_STATUS     IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_TXN_REMARKS IFTBS_FAST_MASTER.TXN_REMARKS%TYPE;
  BEGIN
    DBG('START OF PR_UPDATE_STATUS_FAST_INCOMING');
    DBG('BEFORE UPDATING IFTBS_FAST_MASTER');

    --Get Remarks for a status
    BEGIN
      SELECT VALUE
        INTO L_TXN_REMARKS
        FROM LMTM_TYPE_VALUES
       WHERE TYPE = 'FAST_IN_STATUS'
         AND CODE = P_STATUS;
    EXCEPTION
      WHEN OTHERS THEN
        L_TXN_REMARKS := NULL;
    END;

    DBG('L_TXN_REMARKS=' || L_TXN_REMARKS);

    UPDATE IFTBS_FAST_MASTER
       SET TXN_STATUS = P_STATUS, TXN_REMARKS = L_TXN_REMARKS
     WHERE TRN_REF_NO = P_TRN_REF_NO;

    DBG('AFTER UPDATING IFTBS_FAST_MASTER');
    COMMIT;
    DBG('END OF PR_UPDATE_STATUS_FAST_INCOMING');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_STATUS_FAST_INCOMING');
  END PR_UPDATE_STATUS_FAST_INCOMING;

  PROCEDURE PR_INSERT_FAST_WS_LOG(P_MSG_ID            IN VARCHAR2,
                                  P_SEQ_NO            IN VARCHAR2,
                                  P_TRN_REF_NO        IN VARCHAR2,
                                  P_DATE              IN DATE,
                                  P_REQ_TYPE          IN VARCHAR2,
                                  P_REQ_MSG           IN CLOB,
                                  P_PAY_TYPE          IN CHAR,
                                  P_ACK_REFUND_REASON IN VARCHAR2,
                                  P_ADDL_INFO         IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_FAST_WS_LOG');
    DBG('BEFORE INSERTING INTO STTB_FAST_WS_LOG');
    INSERT INTO STTB_FAST_WS_LOG
      (MSG_ID,
       SEQ_NO,
       TRN_REF_NO,
       INVOKE_DATE,
       REQ_TYPE,
       REQ_MSG,
       PAYMENT_TYPE,
       REFUND_REASON,
       ADDL_INFO)
    VALUES
      (P_MSG_ID,
       P_SEQ_NO,
       P_TRN_REF_NO,
       P_DATE,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_PAY_TYPE,
       P_ACK_REFUND_REASON,

       P_ADDL_INFO);

    COMMIT;
    DBG('AFTER INSERTING INTO STTB_FAST_WS_LOG');
    DBG('END OF PR_INSERT_FAST_WS_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_FAST_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_FAST_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_FAST_WS_LOG=' || SQLERRM);

  END PR_INSERT_FAST_WS_LOG;

  PROCEDURE PR_UPDATE_FAST_WS_LOG(P_MSG_ID  IN VARCHAR2,
                                  P_SEQ_NO  IN VARCHAR2,
                                  P_STATUS  IN CHAR,
                                  P_RES_MSG IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_FAST_WS_LOG');
    DBG('BEFORE UPDATING STTB_FAST_WS_LOG');
    UPDATE STTB_FAST_WS_LOG
       SET STATUS = P_STATUS, RES_MSG = P_RES_MSG
     WHERE MSG_ID = P_MSG_ID
       AND SEQ_NO = P_SEQ_NO;

    COMMIT;
    DBG('AFTER UPDATING STTB_FAST_WS_LOG');
    DBG('END OF PR_UPDATE_FAST_WS_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_FAST_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_FAST_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_FAST_WS_LOG=' || SQLERRM);
  END PR_UPDATE_FAST_WS_LOG;

  PROCEDURE PR_UPDATE_DOC_TRACKER(P_MSG_ID   IN IFTB_FAST_MASTER.MSG_ID%TYPE,
                                  P_STATUS   IN IFTB_FAST_INCOMING_TRACK.STATUS%TYPE,
                                  P_ERR_CODE IN ERTB_MSGS.ERR_CODE%TYPE,
                                  P_ERR_MSGS IN ERTB_MSGS.MESSAGE%TYPE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_MSG_ID IFTBS_FAST_MASTER.MSG_ID%TYPE;
  BEGIN
    DBG('START OF PR_UPDATE_DOC_TRACKER');

    UPDATE IFTBS_FAST_INCOMING_TRACK
       SET STATUS     = P_STATUS,
           ERROR_CODE = P_ERR_CODE,
           ERROR_MSG  = P_ERR_MSGS
     WHERE MSG_ID = P_MSG_ID;
    COMMIT;

    DBG('END OF PR_UPDATE_DOC_TRACKER');

    DBG('RETURNING SUCCESSFULLY FROM PR_UPDATE_DOC_TRACKER');

  EXCEPTION

    WHEN OTHERS THEN
      DBG('FAILED WHILE UPDATING INTO PR_UPDATE_DOC_TRACKER');
      DBG('ERROR CODE IN PR_UPDATE_DOC_TRACKER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_DOC_TRACKER=' || SQLERRM);

  END PR_UPDATE_DOC_TRACKER;

  FUNCTION FN_GET_FAST_OUT_STATUS(P_STATUS IN VARCHAR2) RETURN VARCHAR2 IS
    L_TXN_REMARKS IFTBS_FAST_MASTER.TXN_REMARKS%TYPE;
  BEGIN
    DBG('START OF FN_GET_FAST_OUT_STATUS');

    --Get Remarks for a status
    BEGIN
      SELECT VALUE
        INTO L_TXN_REMARKS
        FROM LMTM_TYPE_VALUES
       WHERE TYPE = 'FAST_OUT_STATUS'
         AND CODE = P_STATUS;
    EXCEPTION
      WHEN OTHERS THEN
        L_TXN_REMARKS := NULL;
    END;

    DBG('L_TXN_REMARKS=' || L_TXN_REMARKS);

    RETURN L_TXN_REMARKS;

    DBG('END OF FN_GET_FAST_OUT_STATUS');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FAST_OUT_STATUS');
      RETURN L_TXN_REMARKS;
  END FN_GET_FAST_OUT_STATUS;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;

    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION fn_process_entries(p_ifdofast  IN OUT ifpks_ifdofast_main.ty_ifdofast,
                              p_action    CHAR,
                              p_errcode   IN OUT VARCHAR2,
                              p_errparams IN OUT VARCHAR2) RETURN BOOLEAN IS
    CURSOR cur_acc IS
      SELECT t.trn_ref_no, t.event_sr_no, t.ac_ccy, t.ac_branch, t.user_id
        FROM actb_daily_log t, iftb_fast_master t1
       WHERE t.trn_ref_no = t1.trn_ref_no
         AND t.trn_ref_no = p_ifdofast.v_iftbs_fast_master.trn_ref_no
         AND t.event_sr_no = 1
         AND t.auth_stat <> 'A';
    i           NUMBER := 0;
    l_terminate BOOLEAN := FALSE;
  BEGIN
    dbg('In fn_process_entries with ' ||
        p_ifdofast.v_iftbs_fast_master.trn_ref_no || '~~~' || p_action);
    IF p_action NOT IN ('D', 'A') THEN
      dbg('Action code not in Delete or Auth...Return TRUE now');
      RETURN TRUE;
    END IF;
    FOR c1 IN cur_acc LOOP
      i := 0;
      IF acpkss.fn_acservice(c1.ac_branch,
                             global.application_date,
                             global.lcy,
                             c1.trn_ref_no,
                             c1.event_sr_no,
                             p_action,
                             c1.user_id,
                             p_errcode,
                             p_errparams) THEN
        dbg('SUCCESS - ' || c1.trn_ref_no);
      ELSE
        dbg('ERROR - ' || c1.trn_ref_no || SQLERRM);
        dbg('ERROR - ' || p_errcode || '~~~' || p_errparams);
        l_terminate := TRUE;
        dbg('After setting l_terminate to TRUE and leave the LOOP');
        EXIT;
      END IF;
      UPDATE detbs_rtl_teller
         SET auth_stat        = 'A',
             checker_id       = global.user_id,
             checker_dt_stamp = csfn_timestamp,
             record_stat      = decode(record_stat, 'O', 'A', record_stat),
             mod_no           = 1
       WHERE trn_ref_no = c1.trn_ref_no;

      i := i + 1;
      dbg('COUNT-->' || i);
    END LOOP;
    IF NOT l_terminate THEN
      dbg('AUTH is fine...Return TRUE now ');
      RETURN TRUE;
    ELSE
      dbg('AUTH is NOT fine...Return FALSE now ');
      RETURN FALSE;
    END IF;
    dbg('Leaving fn_process_entries now....');
  END fn_process_entries;

  FUNCTION FN_RETURN_MSG_ID RETURN IFTBS_FAST_MASTER.MSG_ID%TYPE IS
    l_bank_code cstm_arc_settle.route_code%TYPE;
    l_seq       NUMBER;
    L_MSG_ID    IFTBS_FAST_MASTER.MSG_ID%TYPE;
  BEGIN
    BEGIN
      SELECT route_code
        INTO l_bank_code
        FROM cstm_arc_settle
       WHERE product_code = 'FS01'
         AND auth_stat = 'A'
         AND record_stat = 'O';
    EXCEPTION
      WHEN no_data_found THEN
        dbg('query fail with ' || SQLERRM);
        l_bank_code := 'ABAAKHPPXXXX';
        --RETURN FALSE;
    END;

    DBG('l_bank_code=' || l_bank_code);

    SELECT trsq_msgid.nextval INTO l_seq FROM dual;
    L_MSG_ID := l_bank_code || lpad(TRIM(to_char(l_seq)), 5, '0');
    dbg('Returns p_msgid as ' || L_MSG_ID);
    RETURN L_MSG_ID;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END FN_RETURN_MSG_ID;

  FUNCTION fn_gen_out_msg_pay_id(p_ifdofast IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                 p_msgid    OUT VARCHAR2,
                                 p_payid    OUT VARCHAR2,
                                 p_instrid  OUT VARCHAR2) RETURN BOOLEAN IS
    l_bank_code        cstm_arc_settle.route_code%TYPE;
    l_seq              NUMBER;
    L_PARTICIPANT_CODE LMTM_TYPE_VALUES.VALUE%TYPE;
  BEGIN
    dbg('In fn_gen_out_msg_pay_id');

    --Get Bic Code
    BEGIN
      SELECT route_code
        INTO l_bank_code
        FROM cstm_arc_settle
       WHERE product_code = p_ifdofast.v_iftbs_fast_master.product_code
         AND auth_stat = 'A'
         AND record_stat = 'O';
    EXCEPTION
      WHEN no_data_found THEN
        dbg('query fail with ' || SQLERRM);
        l_bank_code := 'PINCKHPPXXXX';
        --RETURN FALSE;
    END;

    DBG('l_bank_code=' || l_bank_code);

    --Get Beneficiary participant Code
    BEGIN

      SELECT VALUE
        INTO L_PARTICIPANT_CODE
        FROM LMTM_TYPE_VALUES
       WHERE TYPE = 'FAST_MEMBERS'
         AND CODE = P_IFDOFAST.V_IFTBS_FAST_MASTER.BEN_BIC;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('query fail with ' || SQLERRM);
        pr_log_error('IFDOFAST',
                     p_ifdofast.v_iftbs_fast_master.source_code,
                     'IF-FST001',
                     NULL);
        RETURN FALSE;
    END;

    DBG('L_PARTICIPANT_CODE=' || L_PARTICIPANT_CODE);

    SELECT trsq_msgid.nextval INTO l_seq FROM dual;
    -- msg id
    p_msgid := l_bank_code || lpad(TRIM(to_char(l_seq)), 5, '0');
    dbg('Returns p_msgid as ' || p_msgid);

    -- pay id
    /*p_payid := l_bank_code || '/' || 'ACLBKHPP' || 'XXXX/' ||
    lpad(TRIM(to_char(l_seq)), 5, '0');*/

    /*p_payid := l_bank_code || '/' ||
    SUBSTR(p_ifdofast.v_iftbs_fast_master.BEN_BIC, 1, 4) ||
    'KHPP' || 'XXXX/' || lpad(TRIM(to_char(l_seq)), 5, '0');*/

    /*p_payid := l_bank_code || '/' ||
    SUBSTR(p_ifdofast.v_iftbs_fast_master.BEN_BIC, 1, 4) ||
    SUBSTR(p_ifdofast.v_iftbs_fast_master.BEN_BIC, 5, 4) ||
    'XXXX/' || lpad(TRIM(to_char(l_seq)), 5, '0');*/

    p_payid := l_bank_code || '/' || L_PARTICIPANT_CODE || '/' ||
               lpad(TRIM(to_char(l_seq)), 5, '0');

    dbg('Returns p_payid as ' || p_payid);
    -- instr id
    p_instrid := l_bank_code || '/' || lpad(TRIM(to_char(l_seq)), 5, '0');
    dbg('Returns p_instrid as ' || p_instrid);

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('bombed with ' || SQLERRM);
      RETURN FALSE;
  END fn_gen_out_msg_pay_id;

  FUNCTION fn_enrich_chg(p_ifdofast   IN OUT ifpks_ifdofast_main.ty_ifdofast,
                         p_err_code   IN OUT VARCHAR2,
                         p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS

    l_tot_chg_amt NUMBER(22, 3);
    l_prod        cstm_product%ROWTYPE;
    l_rate        NUMBER;

    l_rel_customer sttm_customer.customer_no%TYPE;
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_arc_maint    iftm_arc_maint%ROWTYPE;
    l_ib_flag      VARCHAR2(1) DEFAULT 'Y';
    l_charge_amt   NUMBER := 0;

  BEGIN
    dbg('Inside fn_enrich_chg');

    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdofast.v_iftbs_fast_master.product_code;

    --Sum of all charges
    FOR each_chg IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP

      dbg('Inside each_chg~waiver' || each_chg || '~' || p_ifdofast.v_iftbs_fast_charge(each_chg)
          .waiver);
      dbg('l_tot_chg_amt' || l_tot_chg_amt);
      IF p_ifdofast.v_iftbs_fast_charge(each_chg).waiver = 'Y' THEN
        dbg('Waiver is Y');

        l_tot_chg_amt := nvl(l_tot_chg_amt, 0) + 0;

      ELSE
        dbg('LCY_CHG' || p_ifdofast.v_iftbs_fast_charge(each_chg).lcy_chg);
        l_tot_chg_amt := nvl(l_tot_chg_amt, 0) +
                         nvl(p_ifdofast.v_iftbs_fast_charge(each_chg)
                             .lcy_chg,
                             0);
      END IF;

    END LOOP;

    dbg('L_TOT_CHG_AMT~P_IFDOFAST.V_IFTBS_FAST_MASTER.TXN_CCY~GLOBAL.LCY' ||
        l_tot_chg_amt || '~' || p_ifdofast.v_iftbs_fast_master.txn_ccy || '~' ||
        global.lcy);

    IF p_ifdofast.v_iftbs_fast_master.txn_ccy <> global.lcy THEN
      IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                    global.lcy,
                                    p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                    l_prod.rate_type_preferred,
                                    l_prod.rate_code_preferred,
                                    l_tot_chg_amt,
                                    'Y',
                                    p_ifdofast.v_iftbs_fast_master.tot_chg_amt,
                                    l_rate,
                                    p_err_params) THEN
        debug.pr_debug('**', 'In When Others of EX RATE.');
        debug.pr_debug('**', SQLERRM);
        p_err_code   := 'ST-OTHR-001';
        p_err_params := NULL;
        RETURN FALSE;
      END IF;
    ELSE
      p_ifdofast.v_iftbs_fast_master.tot_chg_amt := l_tot_chg_amt;
    END IF;
    dbg('P_IFDOFAST.V_IFTBS_FAST_MASTER.TOT_CHG_AMT ' ||
        p_ifdofast.v_iftbs_fast_master.tot_chg_amt);

    p_ifdofast.v_iftbs_fast_master.net_txn_amt := p_ifdofast.v_iftbs_fast_master.txn_amt +
                                                  p_ifdofast.v_iftbs_fast_master.tot_chg_amt;

    dbg('Successfully completed fn_enrich_chg');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('bombed with ' || SQLERRM);
      RETURN FALSE;
  END fn_enrich_chg;

  FUNCTION fn_enrich_product(p_ifdofast   IN OUT ifpks_ifdofast_main.ty_ifdofast,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
    l_serial_no    VARCHAR2(16);
    l_trn_ref_no   iftb_fast_master.trn_ref_no%TYPE;
    l_ty_rtupld    depks_retailtellerupload.typ_retailtellerupld_rec;
    l_ret          BOOLEAN;
    l_tot_chg_amt  NUMBER(22, 3);
    l_rel_customer sttm_customer.customer_no%TYPE;
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_ib_flag      VARCHAR2(1) DEFAULT 'Y';
    l_arc_maint    iftm_arc_maint%ROWTYPE;
    l_prod         cstm_product%ROWTYPE;
    l_rate         NUMBER;
    l_charge_amt   NUMBER := 0;
    l_rate_flag    NUMBER;
    l_ccy1         iftb_fast_master.txn_ccy%TYPE;
    l_ccy2         iftb_fast_master.txn_ccy%TYPE;

    l_tot_chg_amount            iftb_fast_master.net_txn_amt%TYPE;
    l_txn_amt                   iftb_fast_master.txn_amt%TYPE;
    l_txn_amt1                  iftb_fast_master.txn_amt%TYPE;
    l_rate_code                 cstm_product.rate_code_preferred%Type;
    l_rate_code1                cstm_product.rate_code_preferred%Type;
    l_tot_chg_amt_in_txn_ccy    iftb_fast_master.txn_amt%TYPE;
    l_tot_chg_amt_in_lcy_ccy    iftb_fast_master.txn_amt%TYPE;
    l_arc_rate_code_type        iftm_arc_maint.cod_rate_code%Type;
    l_tot_chg_amount_in_txn_ccy iftb_fast_master.txn_amt%TYPE;
    l_tot_chg_amount_in_acc_ccy iftb_fast_master.txn_amt%TYPE;
    L_STTB_ACCOUNT              STTB_ACCOUNT%ROWTYPE;
    L_STTM_CUST_ACCOUNT         STTM_CUST_ACCOUNT%ROWTYPE;
  BEGIN

    dbg('In FN_ENRICH_PRODUCT');
    --dbg('p_Action_Code' || p_action_code);

    -- mandatory check
    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN

      --Get Account details
      BEGIN
        SELECT *
          INTO L_STTB_ACCOUNT
          FROM STTB_ACCOUNT
         WHERE AC_GL_NO = p_ifdofast.v_iftbs_fast_master.rem_acc;

      EXCEPTION
        WHEN OTHERS THEN
          L_STTB_ACCOUNT := NULL;
          DBG('FAILED IN GETTING ACCOUNT DETAILS');
      END;

      --Get Account details
      BEGIN
        SELECT *
          INTO L_STTM_CUST_ACCOUNT
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = p_ifdofast.v_iftbs_fast_master.rem_acc;

      EXCEPTION
        WHEN OTHERS THEN
          L_STTM_CUST_ACCOUNT := NULL;
          DBG('FAILED IN GETTING ACCOUNT DETAILS');
      END;

      IF L_STTB_ACCOUNT.AC_STAT_DORMANT = 'Y' THEN
        dbg('Account Status is Dormant');
        p_err_code   := 'AC-VAC33';
        p_err_params := 'Status';
        RETURN FALSE;
      END IF;

      IF L_STTB_ACCOUNT.AC_STAT_NO_DR = 'Y' THEN
        dbg('Account Status is No Debit');
        p_err_code   := 'AC-VAC07';
        p_err_params := 'Status';
        RETURN FALSE;
      END IF;

      IF L_STTM_CUST_ACCOUNT.RECORD_STAT = 'C' THEN
        dbg('Account is Closed');
        p_err_code   := 'AC-VAC12';
        p_err_params := L_STTM_CUST_ACCOUNT.CUST_AC_NO;
        RETURN FALSE;
      END IF;

      IF L_STTB_ACCOUNT.AC_STAT_FROZEN = 'Y' THEN
        dbg('Account Status is Frozen');
        p_err_code   := 'AC-VAC04';
        p_err_params := 'Status';
        RETURN FALSE;
      END IF;

      IF p_ifdofast.v_iftbs_fast_master.product_code IS NULL THEN
        dbg('Mandatory Field Product Code cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Product Code';
        RETURN FALSE;
      END IF;
      IF p_ifdofast.v_iftbs_fast_master.txn_ccy IS NULL THEN
        dbg('Mandatory Fields Transaction Currency cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Transaction Currency';
        RETURN FALSE;
      END IF;
      IF p_ifdofast.v_iftbs_fast_master.txn_amt IS NULL THEN
        dbg('Mandatory Fields Transaction Amount cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Transaction Amount';
        RETURN FALSE;
      END IF;
      IF p_ifdofast.v_iftbs_fast_master.rem_acc IS NULL THEN
        dbg('Mandatory Fields Remitter Account cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Remitter Account';
        RETURN FALSE;
      END IF;
    END IF;

    -- reference no
    IF p_ifdofast.v_iftbs_fast_master.trn_ref_no IS NULL THEN
      IF NOT trpkss.fn_get_product_refno(p_ifdofast.v_iftbs_fast_master.branch_code,
                                         p_ifdofast.v_iftbs_fast_master.product_code,
                                         p_ifdofast.v_iftbs_fast_master.transfer_date,
                                         l_serial_no,
                                         l_trn_ref_no,
                                         p_err_code) THEN
        dbg('Failed in generation Transaction Ref No');
        RETURN FALSE;
      ELSE
        dbg('l_trn_ref_no=' || l_trn_ref_no);
        p_ifdofast.v_iftbs_fast_master.trn_ref_no := l_trn_ref_no;

      END IF;
    END IF;

    -- charge pickup
    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdofast.v_iftbs_fast_master.product_code;

    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      SELECT cust_no, ccy
        INTO l_rel_customer, l_ac_ccy
        FROM sttm_cust_account
       WHERE cust_ac_no = p_ifdofast.v_iftbs_fast_master.rem_acc;
    ELSE
      BEGIN
        SELECT cust_no, ccy
          INTO l_rel_customer, l_ac_ccy
          FROM sttm_cust_account
         WHERE cust_ac_no = p_ifdofast.v_iftbs_fast_master.ben_acc;
      EXCEPTION
        WHEN no_data_found THEN
          dbg('Invalid Ben Account for Incoming Txn');
          pr_log_error('IFDOFAST',
                       p_ifdofast.v_iftbs_fast_master.source_code,
                       'IF-FST017',
                       NULL);
      END;
    END IF;

    dbg('got l_rel_customer' || l_rel_customer);

    IF NOT
        cspkss_arc.fn_charge_pickup(p_ifdofast.v_iftbs_fast_master.branch_code,
                                    p_ifdofast.v_iftbs_fast_master.product_code,
                                    'P',
                                    p_ifdofast.v_iftbs_fast_master.product_code,
                                    p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                    l_rel_customer,
                                    p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                    p_ifdofast.v_iftbs_fast_master.txn_amt,
                                    l_prod.rate_type_preferred,
                                    l_prod.rate_code_preferred,
                                    NULL,
                                    l_rel_customer,
                                    l_ib_flag,
                                    l_arc_maint,
                                    p_err_code,
                                    p_err_params,
                                    p_ifdofast.v_iftbs_fast_master.rem_acc,
                                    p_ifdofast.v_iftbs_fast_master.branch_code) THEN
      dbg('CHARGE PICKUP failed');
      RETURN FALSE;
    END IF;

    DBG('l_arc_maint.cod_chg_amt =' || l_arc_maint.cod_chg_amt);

    --Charge1
    IF l_arc_maint.cod_chg_amt IS NOT NULL THEN
      p_ifdofast.v_iftbs_fast_charge(1).trn_ref_no := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      p_ifdofast.v_iftbs_fast_charge(1).chg_srno := 1;
      p_ifdofast.v_iftbs_fast_charge(1).chg_desc := l_arc_maint.cod_chg_desc;
      p_ifdofast.v_iftbs_fast_charge(1).waiver := 'N';
      p_ifdofast.v_iftbs_fast_charge(1).chg_amt := l_arc_maint.cod_chg_amt;
      p_ifdofast.v_iftbs_fast_charge(1).chg_ccy := l_arc_maint.cod_chg_ccy;

      DBG('p_ifdofast.v_iftbs_fast_charge(1).trn_ref_no=' || p_ifdofast.v_iftbs_fast_charge(1)
          .trn_ref_no);
      DBG('p_ifdofast.v_iftbs_fast_charge(1).chg_srno=' || p_ifdofast.v_iftbs_fast_charge(1)
          .chg_srno);
      DBG('p_ifdofast.v_iftbs_fast_charge(1).chg_desc=' || p_ifdofast.v_iftbs_fast_charge(1)
          .chg_desc);
      DBG('p_ifdofast.v_iftbs_fast_charge(1).waiver=' || p_ifdofast.v_iftbs_fast_charge(1)
          .waiver);
      DBG('p_ifdofast.v_iftbs_fast_charge(1).chg_amt=' || p_ifdofast.v_iftbs_fast_charge(1)
          .chg_amt);
      DBG('p_ifdofast.v_iftbs_fast_charge(1).chg_ccy=' || p_ifdofast.v_iftbs_fast_charge(1)
          .chg_ccy);

      DBG('p_ifdofast.v_iftbs_fast_charge.count=' ||
          p_ifdofast.v_iftbs_fast_charge.count);

      DBG('global.lcy=' || global.lcy);
      DBG('l_arc_maint.cod_chg_ccy=' || l_arc_maint.cod_chg_ccy);

      -- Converting charge into local ccy for display in charge tab
      IF l_arc_maint.cod_chg_ccy <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(1).lcy_chg := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(1).xrate := l_rate;
      ELSE
        p_ifdofast.v_iftbs_fast_charge(1).lcy_chg := l_arc_maint.cod_chg_amt;
        p_ifdofast.v_iftbs_fast_charge(1).xrate := 1;
      END IF;
      dbg('Amount 1 in Local ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
          .lcy_chg);

      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy <> p_ifdofast.v_iftbs_fast_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      l_prod.rate_type_preferred,
                                      NVL(l_arc_maint.cod_rate_code_Type, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                      l_arc_maint.cod_chg_amt,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(1).chg_in_txn := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(1).txn_xrate := l_rate;
        dbg(' * Amount 1 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
            .chg_in_txn);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(1).chg_in_txn := l_arc_maint.cod_chg_amt;
        p_ifdofast.v_iftbs_fast_charge(1).txn_xrate := 1;
        dbg('** Amount 1 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
            .chg_in_txn);
      END IF;

      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy,
                                      l_ac_ccy,
                                      l_prod.rate_type_preferred,
                                      NVL(l_arc_maint.cod_rate_code_Type, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                      l_arc_maint.cod_chg_amt,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(1).chg_in_acc := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(1).acc_xrate := l_rate;
        dbg('* Amount 1 in acc ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
            .chg_in_acc);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(1).chg_in_acc := l_arc_maint.cod_chg_amt;
        p_ifdofast.v_iftbs_fast_charge(1).acc_xrate := 1;
        dbg('** Amount 1 in acc ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
            .chg_in_acc);
      END IF;
    END IF;

    --Charge2
    IF l_arc_maint.cod_chg_amt1 IS NOT NULL THEN
      p_ifdofast.v_iftbs_fast_charge(2).trn_ref_no := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      p_ifdofast.v_iftbs_fast_charge(2).chg_srno := 2;
      p_ifdofast.v_iftbs_fast_charge(2).chg_desc := l_arc_maint.cod_chg_desc1;
      p_ifdofast.v_iftbs_fast_charge(2).waiver := 'N';
      p_ifdofast.v_iftbs_fast_charge(2).chg_amt := l_arc_maint.cod_chg_amt1;
      p_ifdofast.v_iftbs_fast_charge(2).chg_ccy := l_arc_maint.cod_chg_ccy1;

      IF l_arc_maint.cod_chg_ccy1 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy1,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt1,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(2).lcy_chg := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(2).xrate := l_rate;
      ELSE
        p_ifdofast.v_iftbs_fast_charge(2).lcy_chg := l_arc_maint.cod_chg_amt1;
        p_ifdofast.v_iftbs_fast_charge(2).xrate := 1;
      END IF;

      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy1 <> p_ifdofast.v_iftbs_fast_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy1,
                                   p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type1, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt1,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(2).chg_in_txn := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(2).txn_xrate := l_rate;
        dbg('* Amount 2 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(2)
            .chg_in_txn);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(2).chg_in_txn := l_arc_maint.cod_chg_amt1;
        p_ifdofast.v_iftbs_fast_charge(2).txn_xrate := 1;
        dbg('** Amount 2 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(2)
            .chg_in_txn);
      END IF;

      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy1 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy1,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type1, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt1,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(2).chg_in_acc := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(2).acc_xrate := l_rate;
        dbg('* Amount 2 in acc ccy->' || p_ifdofast.v_iftbs_fast_charge(2)
            .chg_in_acc);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(2).chg_in_acc := l_arc_maint.cod_chg_amt1;
        p_ifdofast.v_iftbs_fast_charge(2).acc_xrate := 1;
        dbg('** Amount 2 in acc ccy->' || p_ifdofast.v_iftbs_fast_charge(2)
            .chg_in_acc);
      END IF;
      p_ifdofast.v_iftbs_fast_charge(2).oth_ccy := l_arc_maint.cod_chg_ccy1;

    END IF;

    --Charge3
    IF l_arc_maint.cod_chg_amt2 IS NOT NULL THEN
      p_ifdofast.v_iftbs_fast_charge(3).trn_ref_no := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      p_ifdofast.v_iftbs_fast_charge(3).chg_srno := 3;
      p_ifdofast.v_iftbs_fast_charge(3).chg_desc := l_arc_maint.cod_chg_desc2;
      p_ifdofast.v_iftbs_fast_charge(3).waiver := 'N';
      p_ifdofast.v_iftbs_fast_charge(3).chg_amt := l_arc_maint.cod_chg_amt2;
      p_ifdofast.v_iftbs_fast_charge(3).chg_ccy := l_arc_maint.cod_chg_ccy2;

      IF l_arc_maint.cod_chg_ccy2 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy2,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt2,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(3).lcy_chg := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(3).xrate := l_rate;
      ELSE
        p_ifdofast.v_iftbs_fast_charge(3).lcy_chg := l_arc_maint.cod_chg_amt2;
        p_ifdofast.v_iftbs_fast_charge(3).xrate := 1;
      END IF;

      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy2 <> p_ifdofast.v_iftbs_fast_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy2,
                                   p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type2, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt2,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(3).chg_in_txn := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(3).txn_xrate := l_rate;
        dbg('* Amount 3 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(3)
            .chg_in_txn);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(3).chg_in_txn := l_arc_maint.cod_chg_amt2;
        p_ifdofast.v_iftbs_fast_charge(3).txn_xrate := 1;
        dbg('** Amount 3 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(3)
            .chg_in_txn);
      END IF;

      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy2 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy2,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type2, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt2,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(3).chg_in_acc := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(3).acc_xrate := l_rate;
        dbg('* Amount 3 in ACC ccy->' || p_ifdofast.v_iftbs_fast_charge(3)
            .chg_in_acc);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(3).chg_in_acc := l_arc_maint.cod_chg_amt2;
        p_ifdofast.v_iftbs_fast_charge(3).acc_xrate := 1;
        dbg('** Amount 3 in ACC ccy->' || p_ifdofast.v_iftbs_fast_charge(3)
            .chg_in_acc);
      END IF;
      p_ifdofast.v_iftbs_fast_charge(3).oth_ccy := l_arc_maint.cod_chg_ccy2;
    END IF;

    --Charge4
    IF l_arc_maint.cod_chg_amt3 IS NOT NULL THEN
      p_ifdofast.v_iftbs_fast_charge(4).trn_ref_no := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      p_ifdofast.v_iftbs_fast_charge(4).chg_srno := 4;
      p_ifdofast.v_iftbs_fast_charge(4).chg_desc := l_arc_maint.cod_chg_desc3;
      p_ifdofast.v_iftbs_fast_charge(4).waiver := 'N';
      p_ifdofast.v_iftbs_fast_charge(4).chg_amt := l_arc_maint.cod_chg_amt3;
      p_ifdofast.v_iftbs_fast_charge(4).chg_ccy := l_arc_maint.cod_chg_ccy3;

      IF l_arc_maint.cod_chg_ccy3 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy3,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt3,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(4).lcy_chg := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(4).xrate := l_rate;
      ELSE
        p_ifdofast.v_iftbs_fast_charge(4).lcy_chg := l_arc_maint.cod_chg_amt3;
        p_ifdofast.v_iftbs_fast_charge(4).xrate := 1;
      END IF;

      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy3 <> p_ifdofast.v_iftbs_fast_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy3,
                                   p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type3, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt3,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(4).chg_in_txn := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(4).txn_xrate := l_rate;
        dbg('* Amount 4 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(4)
            .chg_in_txn);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(4).chg_in_txn := l_arc_maint.cod_chg_amt3;
        p_ifdofast.v_iftbs_fast_charge(4).txn_xrate := 1;
        dbg('** Amount 4 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(4)
            .chg_in_txn);
      END IF;

      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy3 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy3,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type3, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt3,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(4).chg_in_acc := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(4).acc_xrate := l_rate;
        dbg('* Amount 4 in OTH ccy->' || p_ifdofast.v_iftbs_fast_charge(4)
            .chg_in_acc);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(4).chg_in_acc := l_arc_maint.cod_chg_amt3;
        p_ifdofast.v_iftbs_fast_charge(4).acc_xrate := 1;
        dbg('** Amount 4 in OTH ccy->' || p_ifdofast.v_iftbs_fast_charge(4)
            .chg_in_acc);
      END IF;
      p_ifdofast.v_iftbs_fast_charge(4).oth_ccy := l_arc_maint.cod_chg_ccy3;

    END IF;

    --Charge5
    IF l_arc_maint.cod_chg_amt4 IS NOT NULL THEN
      p_ifdofast.v_iftbs_fast_charge(5).trn_ref_no := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      p_ifdofast.v_iftbs_fast_charge(5).chg_srno := 5;
      p_ifdofast.v_iftbs_fast_charge(5).chg_desc := l_arc_maint.cod_chg_desc4;
      p_ifdofast.v_iftbs_fast_charge(5).waiver := 'N';
      p_ifdofast.v_iftbs_fast_charge(5).chg_amt := l_arc_maint.cod_chg_amt4;
      p_ifdofast.v_iftbs_fast_charge(5).chg_ccy := l_arc_maint.cod_chg_ccy4;

      IF l_arc_maint.cod_chg_ccy4 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy4,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt4,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(5).lcy_chg := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(5).xrate := l_rate;
      ELSE
        p_ifdofast.v_iftbs_fast_charge(5).lcy_chg := l_arc_maint.cod_chg_amt4;
        p_ifdofast.v_iftbs_fast_charge(5).xrate := 1;
      END IF;

      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy4 <> p_ifdofast.v_iftbs_fast_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy4,
                                   p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type4, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt4,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(5).chg_in_txn := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(5).txn_xrate := l_rate;
        dbg('* Amount 5 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(5)
            .chg_in_txn);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(5).chg_in_txn := l_arc_maint.cod_chg_amt4;
        p_ifdofast.v_iftbs_fast_charge(5).txn_xrate := 1;
        dbg('** Amount 5 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(5)
            .chg_in_txn);
      END IF;

      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy4 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy4,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type4, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt4,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(5).chg_in_acc := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(5).acc_xrate := l_rate;
        dbg('* Amount 5 in OTH ccy->' || p_ifdofast.v_iftbs_fast_charge(5)
            .chg_in_acc);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(5).chg_in_acc := l_arc_maint.cod_chg_amt4;
        p_ifdofast.v_iftbs_fast_charge(5).acc_xrate := 1;
        dbg('** Amount 5 in OTH ccy->' || p_ifdofast.v_iftbs_fast_charge(5)
            .chg_in_acc);
      END IF;
      p_ifdofast.v_iftbs_fast_charge(5).oth_ccy := l_arc_maint.cod_chg_ccy4;

    END IF;

    dbg('Done all charges calculation');

    -- Total Charge amount in transaction currency
    FOR J IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP

      l_tot_chg_amt_in_txn_ccy := nvl(l_tot_chg_amt_in_txn_ccy, 0) +
                                  nvl(p_ifdofast.v_iftbs_fast_charge(j)
                                      .chg_in_txn,
                                      0);

    END LOOP;
    dbg('L_TOT_CHG_AMT~P_IFDOFAST.v_iftbs_pgw_master_custom.TXN_CCY~GLOBAL.LCY' ||
        l_tot_chg_amt || '~' || p_ifdofast.v_iftbs_fast_master.txn_ccy || '~' ||
        global.lcy);

    dbg('Total charge to be paid in TXN CCY ->' ||
        l_tot_chg_amt_in_txn_ccy);
    p_ifdofast.v_iftbs_fast_master.tot_chg_amt := l_tot_chg_amt_in_txn_ccy; -- We are displaying total charge in txn amount only --Tuning of code in charge calculation

    -- Total Charge amount in local and remitter/account ccy
    FOR J IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP
      dbg('1 l_tot_chg_amt_in_lcy_ccy->' || l_tot_chg_amt_in_lcy_ccy ||
          'p_ifdofast.v_iftbs_fast_charge(j).lcy_chg' || p_ifdofast.v_iftbs_fast_charge(j)
          .lcy_chg);
      dbg('1 l_tot_chg_amount_in_acc_ccy->' || l_tot_chg_amount_in_acc_ccy ||
          'p_ifdofast.v_iftbs_fast_charge(j).chg_in_acc' || p_ifdofast.v_iftbs_fast_charge(j)
          .chg_in_acc);
      l_tot_chg_amt_in_lcy_ccy    := nvl(l_tot_chg_amt_in_lcy_ccy, 0) +
                                     nvl(p_ifdofast.v_iftbs_fast_charge(j)
                                         .lcy_chg,
                                         0);
      l_tot_chg_amount_in_acc_ccy := nvl(l_tot_chg_amount_in_acc_ccy, 0) +
                                     nvl(p_ifdofast.v_iftbs_fast_charge(j)
                                         .chg_in_acc,
                                         0);

      dbg('2 l_tot_chg_amt_in_lcy_ccy->' || l_tot_chg_amt_in_lcy_ccy);
      dbg('2 l_tot_chg_amount_in_acc_ccy->' || l_tot_chg_amount_in_acc_ccy);
    End Loop;

    dbg('chgs calculated ->');

    If l_prod.rate_code_preferred = 'B' and
       p_ifdofast.v_iftbs_fast_master.transfer_mode in ('F') Then
      l_rate_code := Null;
      If (p_ifdofast.v_iftbs_fast_master.txn_ccy = global.lcy and
         l_ac_ccy != global.lcy) OR
         (p_ifdofast.v_iftbs_fast_master.txn_ccy != global.lcy and
         l_ac_ccy <> global.lcy and
         p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_ac_ccy) Then
        l_rate_code := 'B';

      Else
        l_rate_code := l_prod.rate_code_preferred;
      End If;
    Else
      l_rate_code := l_prod.rate_code_preferred;
    End If;
    dbg('p_ifdofast.v_iftbs_pgw_master_custom.txn_amt->' ||
        p_ifdofast.v_iftbs_fast_master.txn_amt);

    dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
        l_rate_code1);

    If l_ac_ccy <> global.lcy Then
      begin
        select decode(l_rate_code,
                      'B',
                      'S',
                      'S',
                      'B',
                      'M',
                      'M',
                      l_rate_code)
          Into l_rate_code1
          from dual;
      exception
        when others then
          dbg('Exception found l_rate_code-> ' || l_rate_code);
      end;
    End If;
    dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
        l_rate_code1);
    dbg('l_txn_amt l_txn_amt l_txn_amt=' || l_txn_amt);
    -- Total Txn amount in remitter currency
    IF p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_ac_ccy THEN
      l_rate := NULL;
      --l_charge_amt := NULL;
      l_txn_amt1 := p_ifdofast.v_iftbs_fast_master.txn_amt;
      /*IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                    p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                    l_ac_ccy,
                                    l_prod.rate_type_preferred,
                                    nvl(l_rate_code1, l_rate_code),
                                    l_txn_amt1,
                                    'Y',
                                    l_txn_amt,
                                    l_rate,
                                    p_err_params) THEN
        debug.pr_debug('**', '');
        debug.pr_debug('**', SQLERRM);
        p_err_code   := 'ST-OTHR-001';
        p_err_params := NULL;
        RETURN FALSE;
      END IF;*/

      -- xrate
      IF p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_ac_ccy THEN

        IF p_ifdofast.v_iftbs_fast_master.txn_ccy = global.lcy THEN
          l_ccy1 := l_ac_ccy;
          l_ccy2 := p_ifdofast.v_iftbs_fast_master.txn_ccy;
        ELSE
          l_ccy1 := p_ifdofast.v_iftbs_fast_master.txn_ccy;
          l_ccy2 := l_ac_ccy;
        END IF;
        dbg('l_rate_code->' || l_rate_code || 'l_prod.rate_type_preferred' ||
            l_prod.rate_type_preferred);
        dbg('Before p_ifdofast.v_iftbs_pgw_master_custom.exch_rate->' ||
            p_ifdofast.v_iftbs_fast_master.exch_rate);

        If (p_ifdofast.v_iftbs_fast_master.txn_ccy != global.lcy and
           l_ac_ccy <> global.lcy and
           p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_ac_ccy) and
           l_prod.rate_code_preferred = 'B' Then
          l_rate_code := 'S';
        End If;

        dbg('l_rate_code->' || l_rate_code);

        dbg('l_prod.rate_type_preferred=' || l_prod.rate_type_preferred);

        IF NOT cypkss.fn_getrate(p_ifdofast.v_iftbs_fast_master.branch_code,
                                 l_ccy2,
                                 l_ccy1, --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                 l_prod.rate_type_preferred,
                                 l_rate_code, --l_prod.rate_code_preferred,
                                 p_ifdofast.v_iftbs_fast_master.transfer_date,
                                 p_ifdofast.v_iftbs_fast_master.transfer_date,
                                 p_ifdofast.v_iftbs_fast_master.exch_rate,
                                 l_rate_flag,
                                 p_err_code) THEN
          dbg('Failed in Fn_GetRate');
          RETURN FALSE;
        END IF;
      ELSE
        p_ifdofast.v_iftbs_fast_master.exch_rate := 1;
      END IF;

      DBG('p_ifdofast.v_iftbs_fast_master.exch_rate==' ||
          p_ifdofast.v_iftbs_fast_master.exch_rate);

      --Using above rate..convert khr to usd amount
      IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                    l_ac_ccy,
                                    l_txn_amt1,
                                    p_ifdofast.v_iftbs_fast_master.exch_rate,
                                    'Y',
                                    l_txn_amt,
                                    p_err_params) THEN
        RETURN FALSE;
      END IF;
    END IF;
    dbg('Final txn_amt->' || l_txn_amt || 'Final chg_amount->' ||
        l_tot_chg_amount);
    dbg('Total Charges in local ccy->' || l_tot_chg_amt_in_lcy_ccy);
    dbg('Total Charges in txn ccy->' || l_tot_chg_amount_in_txn_ccy);
    dbg('Total Charges in acc ccy->' || l_tot_chg_amount_in_acc_ccy);

    -- Net DB Amount (Charges + Txn amount)
    If p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_ac_ccy Then
      dbg('apple');
      p_ifdofast.v_iftbs_fast_master.net_txn_amt := nvl(l_txn_amt, 0) +
                                                    (Nvl(l_tot_chg_amount_in_acc_ccy,
                                                         0));

    Elsif p_ifdofast.v_iftbs_fast_master.txn_ccy = l_ac_ccy Then
      dbg('mango');
      p_ifdofast.v_iftbs_fast_master.net_txn_amt := nvl(p_ifdofast.v_iftbs_fast_master.txn_amt,
                                                        0) +
                                                    (Nvl(l_tot_chg_amount_in_acc_ccy,
                                                         0));

    End If;
    dbg('p_ifdofast.v_iftbs_fast_master.net_txn_amt->' ||
        p_ifdofast.v_iftbs_fast_master.net_txn_amt);

    /*FOR j IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP
      dbg('P_IFDOFAST.V_IFTBS_FAST_CHARGE(J).LCY_CHG' || p_ifdofast.v_iftbs_fast_charge(j)
          .lcy_chg);
      l_tot_chg_amt := nvl(l_tot_chg_amt, 0) +
                       nvl(p_ifdofast.v_iftbs_fast_charge(j).lcy_chg, 0);
    END LOOP;

    dbg('L_TOT_CHG_AMT~P_IFDOFAST.V_IFTBS_FAST_MASTER.TXN_CCY~GLOBAL.LCY' ||
        l_tot_chg_amt || '~' || p_ifdofast.v_iftbs_fast_master.txn_ccy || '~' ||
        global.lcy);

    IF p_ifdofast.v_iftbs_fast_master.txn_ccy <> global.lcy THEN
      IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                    global.lcy,
                                    p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                    l_prod.rate_type_preferred,
                                    l_prod.rate_code_preferred,
                                    l_tot_chg_amt,
                                    'Y',
                                    p_ifdofast.v_iftbs_fast_master.tot_chg_amt,
                                    l_rate,
                                    p_err_params) THEN
        debug.pr_debug('**', 'In When Others of EX RATE.');
        debug.pr_debug('**', SQLERRM);
        p_err_code   := 'ST-OTHR-001';
        p_err_params := NULL;
        RETURN FALSE;
      END IF;
    ELSE
      p_ifdofast.v_iftbs_fast_master.tot_chg_amt := l_tot_chg_amt;
    END IF;
    dbg('P_IFDOFAST.V_IFTBS_FAST_MASTER.TOT_CHG_AMT ' ||
        p_ifdofast.v_iftbs_fast_master.tot_chg_amt);

    p_ifdofast.v_iftbs_fast_master.net_txn_amt := p_ifdofast.v_iftbs_fast_master.txn_amt +
                                                  p_ifdofast.v_iftbs_fast_master.tot_chg_amt;

    -- xrate
    IF p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_ac_ccy THEN
      IF p_ifdofast.v_iftbs_fast_master.txn_ccy = global.lcy THEN
        l_ccy1 := l_ac_ccy;
        l_ccy2 := p_ifdofast.v_iftbs_fast_master.txn_ccy;
      ELSE
        l_ccy1 := p_ifdofast.v_iftbs_fast_master.txn_ccy;
        l_ccy2 := l_ac_ccy;
      END IF;
      IF NOT cypkss.fn_getrate(p_ifdofast.v_iftbs_fast_master.branch_code,
                               l_ccy1, --P_IFDOFAST.V_IFTBS_FAST_MASTER.TXN_CCY,
                               l_ccy2, --L_AC_CCY,
                               l_prod.rate_type_preferred,
                               l_prod.rate_code_preferred,
                               p_ifdofast.v_iftbs_fast_master.transfer_date,
                               p_ifdofast.v_iftbs_fast_master.transfer_date,
                               p_ifdofast.v_iftbs_fast_master.exch_rate,
                               l_rate_flag,
                               p_err_code) THEN
        dbg('Failed in Fn_GetRate');
        RETURN FALSE;
      END IF;
    ELSE
      p_ifdofast.v_iftbs_fast_master.exch_rate := 1;
    END IF;*/

    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      SELECT address1, address2, address3, address4
        INTO p_ifdofast.v_iftbs_fast_master.rem_add1,
             p_ifdofast.v_iftbs_fast_master.rem_add2,
             p_ifdofast.v_iftbs_fast_master.rem_add3,
             p_ifdofast.v_iftbs_fast_master.rem_add4
        FROM sttm_cust_account
       WHERE cust_ac_no = p_ifdofast.v_iftbs_fast_master.rem_acc;
    END IF;

    dbg('Returning Success From FN_ENRICH_PRODUCT..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.FN_ENRICH_PRODUCT ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_enrich_product;

  FUNCTION fn_save(p_ifdofast              IN OUT ifpks_ifdofast_main.ty_ifdofast,
                   pkg_detb_rtl_teller_rec IN OUT detbs_rtl_teller%ROWTYPE,
                   p_err_code              IN OUT VARCHAR2,
                   p_err_params            IN OUT VARCHAR2) RETURN BOOLEAN IS

    l_cust_ac    sttm_cust_account%ROWTYPE;
    l_arc_maint  iftms_arc_maint%ROWTYPE;
    l_cust       sttm_customer%ROWTYPE;
    l_prod       cstm_product%ROWTYPE;
    l_ib_flag    VARCHAR2(1) DEFAULT 'Y';
    l_txn_amt    iftbs_fast_master.txn_amt%TYPE;
    l_txn_amt1   iftbs_fast_master.txn_amt%TYPE;
    l_rate       NUMBER;
    l_rate_code  cstm_product.rate_code_preferred%Type;
    l_rate_code1 cstm_product.rate_code_preferred%Type;

  BEGIN
    dbg('In FN_SAVE');

    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdofast.v_iftbs_fast_master.product_code;

    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN

      SELECT x.*
        INTO l_cust_ac
        FROM sttm_cust_account x
       WHERE x.cust_ac_no = p_ifdofast.v_iftbs_fast_master.rem_acc;

      -- msg id
      IF p_ifdofast.v_iftbs_fast_master.transfer_mode = 'F' THEN
        IF NOT
            fn_gen_out_msg_pay_id(p_ifdofast,
                                  p_ifdofast.v_iftbs_fast_master.msg_id,
                                  p_ifdofast.v_iftbs_fast_master.pay_id,
                                  p_ifdofast.v_iftbs_fast_master.instr_id) THEN
          dbg('Failed in generation Msg id');
          RETURN FALSE;
        END IF;

        -- end to end id
        p_ifdofast.v_iftbs_fast_master.etend_id := p_ifdofast.v_iftbs_fast_master.rem_acc || '-' ||
                                                   p_ifdofast.v_iftbs_fast_master.ben_acc;

      END IF;
    ELSE

      SELECT x.*
        INTO l_cust_ac
        FROM sttm_cust_account x
       WHERE x.cust_ac_no = p_ifdofast.v_iftbs_fast_master.ben_acc;

    END IF;

    SELECT x.*
      INTO l_cust
      FROM sttm_customer x
     WHERE x.customer_no = l_cust_ac.cust_no;

    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      cspkss_arc.pr_get_arc_row(p_ifdofast.v_iftbs_fast_master.branch_code,
                                p_ifdofast.v_iftbs_fast_master.product_code,
                                'P',
                                '*.*', -- trans_type
                                p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                l_ib_flag,
                                l_arc_maint,
                                p_err_code,
                                p_err_params,
                                p_ifdofast.v_iftbs_fast_master.rem_acc,
                                p_ifdofast.v_iftbs_fast_master.branch_code);
    ELSE
      cspkss_arc.pr_get_arc_row(p_ifdofast.v_iftbs_fast_master.branch_code,
                                p_ifdofast.v_iftbs_fast_master.product_code,
                                'P',
                                '*.*', -- trans_type
                                p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                l_ib_flag,
                                l_arc_maint,
                                p_err_code,
                                p_err_params,
                                p_ifdofast.v_iftbs_fast_master.ben_acc,
                                p_ifdofast.v_iftbs_fast_master.branch_code);
    END IF;

    IF p_err_code IS NOT NULL THEN
      dbg('CSPKSS_ARC.PR_GET_ARC_ROW returned false');
      RETURN FALSE;
    END IF;

    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      IF NOT
          cspkss_arc.fn_charge_pickup(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      p_ifdofast.v_iftbs_fast_master.product_code,
                                      'P',
                                      p_ifdofast.v_iftbs_fast_master.product_code,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      l_cust_ac.cust_no,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      p_ifdofast.v_iftbs_fast_master.txn_amt,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      NULL,
                                      l_cust_ac.cust_no,
                                      l_ib_flag,
                                      depks_rtl_teller.pkg_arc_row,
                                      p_err_code,
                                      p_err_params,
                                      p_ifdofast.v_iftbs_fast_master.rem_acc,
                                      p_ifdofast.v_iftbs_fast_master.branch_code) THEN
        dbg('CHARGE PICKUP failed');
        RETURN FALSE;
      END IF;
    ELSE
      IF NOT
          cspkss_arc.fn_charge_pickup(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      p_ifdofast.v_iftbs_fast_master.product_code,
                                      'P',
                                      p_ifdofast.v_iftbs_fast_master.product_code,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      l_cust_ac.cust_no,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      p_ifdofast.v_iftbs_fast_master.txn_amt,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      NULL,
                                      l_cust_ac.cust_no,
                                      l_ib_flag,
                                      depks_rtl_teller.pkg_arc_row,
                                      p_err_code,
                                      p_err_params,
                                      p_ifdofast.v_iftbs_fast_master.ben_acc,
                                      p_ifdofast.v_iftbs_fast_master.branch_code) THEN
        dbg('CHARGE PICKUP failed');
        RETURN FALSE;
      END IF;
    END IF;

    pkg_detb_rtl_teller_rec.xref         := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
    pkg_detb_rtl_teller_rec.product_code := p_ifdofast.v_iftbs_fast_master.product_code;
    pkg_detb_rtl_teller_rec.branch_code  := p_ifdofast.v_iftbs_fast_master.branch_code;
    pkg_detb_rtl_teller_rec.trn_ref_no   := p_ifdofast.v_iftbs_fast_master.trn_ref_no;

    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      pkg_detb_rtl_teller_rec.txn_acc := p_ifdofast.v_iftbs_fast_master.rem_acc;
      pkg_detb_rtl_teller_rec.txn_ccy := l_cust_ac.ccy;
      --pkg_detb_rtl_teller_rec.txn_branch := p_ifdofast.v_iftbs_fast_master.branch_code;
      pkg_detb_rtl_teller_rec.txn_branch := l_cust_ac.branch_code;

      pkg_detb_rtl_teller_rec.ofs_acc    := l_arc_maint.cod_offset_acc;
      pkg_detb_rtl_teller_rec.ofs_ccy    := p_ifdofast.v_iftbs_fast_master.txn_ccy;
      pkg_detb_rtl_teller_rec.ofs_amount := p_ifdofast.v_iftbs_fast_master.txn_amt;
      /* pkg_detb_rtl_teller_rec.ofs_branch := REPLACE(l_arc_maint.cod_offset_brn,
                                                      '*.*',
                                                      p_ifdofast.v_iftbs_fast_master.branch_code);
      */
      --Get Nostro Account Branch for the offset leg
      BEGIN
        SELECT BRANCH_CODE
          INTO pkg_detb_rtl_teller_rec.ofs_branch
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = pkg_detb_rtl_teller_rec.ofs_acc;
      EXCEPTION
        WHEN OTHERS THEN
          pkg_detb_rtl_teller_rec.ofs_branch := '991';
      END;
      -- Begin ACCOUNTING ENTRIES Display and fix for Wrong Exch calculation
      IF p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_cust_ac.ccy THEN
        l_rate     := NULL;
        l_txn_amt1 := p_ifdofast.v_iftbs_fast_master.txn_amt;

        If l_prod.rate_code_preferred = 'B' and
           p_ifdofast.v_iftbs_fast_master.transfer_mode in ('F') Then
          l_rate_code := Null;
          If (p_ifdofast.v_iftbs_fast_master.txn_ccy = global.lcy and
             l_cust_ac.ccy != global.lcy) Or
             (p_ifdofast.v_iftbs_fast_master.txn_ccy != global.lcy and
             l_cust_ac.ccy <> global.lcy and
             p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_cust_ac.ccy) Then
            l_rate_code := 'B';
          Elsif p_ifdofast.v_iftbs_fast_master.txn_ccy != global.lcy and
                l_cust_ac.ccy = global.lcy and
                p_ifdofast.v_iftbs_fast_master.transfer_mode = 'L' Then
            l_rate_code := 'S';
          Else
            l_rate_code := l_prod.rate_code_preferred;
          End If;
        Else
          l_rate_code := l_prod.rate_code_preferred;
        End If;

        dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
            l_rate_code1);
        If l_cust_ac.ccy <> global.lcy Then
          begin
            select decode(l_rate_code,
                          'B',
                          'S',
                          'S',
                          'B',
                          'M',
                          'M',
                          l_rate_code)
              Into l_rate_code1
              from dual;
          exception
            when others then
              dbg('Exception found l_rate_code-> ' || l_rate_code);
          end;
        End If;
        dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
            l_rate_code1);

        /*IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      l_cust_ac.ccy,
                                      l_prod.rate_type_preferred,
                                      nvl(l_rate_code1, l_rate_code),
                                      l_txn_amt1,
                                      'Y',
                                      l_txn_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', '');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;*/

        IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      l_cust_ac.ccy,
                                      l_txn_amt1,
                                      p_ifdofast.v_iftbs_fast_master.exch_rate,
                                      'Y',
                                      l_txn_amt,
                                      p_err_params) THEN
          RETURN FALSE;
        END IF;
      END IF;
      dbg('l_txn_amt1->' || l_txn_amt1);
      dbg('l_txn_amt1->' || l_txn_amt);
      pkg_detb_rtl_teller_rec.txn_amount := l_txn_amt;
      -- END

    ELSE
      pkg_detb_rtl_teller_rec.txn_acc := p_ifdofast.v_iftbs_fast_master.ben_acc;
      pkg_detb_rtl_teller_rec.txn_ccy := l_cust_ac.ccy;
      --pkg_detb_rtl_teller_rec.txn_branch := p_ifdofast.v_iftbs_fast_master.branch_code;
      pkg_detb_rtl_teller_rec.txn_branch := l_cust_ac.branch_code;

      pkg_detb_rtl_teller_rec.ofs_acc    := l_arc_maint.cod_offset_acc;
      pkg_detb_rtl_teller_rec.ofs_ccy    := p_ifdofast.v_iftbs_fast_master.txn_ccy;
      pkg_detb_rtl_teller_rec.ofs_amount := p_ifdofast.v_iftbs_fast_master.txn_amt;
      pkg_detb_rtl_teller_rec.txn_amount := p_ifdofast.v_iftbs_fast_master.txn_amt;
      pkg_detb_rtl_teller_rec.ofs_branch := REPLACE(l_arc_maint.cod_offset_brn,
                                                    '*.*',
                                                    p_ifdofast.v_iftbs_fast_master.branch_code);
    END IF;
    pkg_detb_rtl_teller_rec.txn_trn_code     := l_arc_maint.cod_main_txn_code;
    pkg_detb_rtl_teller_rec.ofs_trn_code     := l_arc_maint.cod_offset_txn_code;
    pkg_detb_rtl_teller_rec.exch_rate        := p_ifdofast.v_iftbs_fast_master.exch_rate;
    pkg_detb_rtl_teller_rec.trn_dt           := p_ifdofast.v_iftbs_fast_master.transfer_date;
    pkg_detb_rtl_teller_rec.value_dt         := p_ifdofast.v_iftbs_fast_master.transfer_date;
    pkg_detb_rtl_teller_rec.rel_customer     := l_cust_ac.cust_no;
    pkg_detb_rtl_teller_rec.benef_name       := l_cust.customer_name1;
    pkg_detb_rtl_teller_rec.benef_addr1      := l_cust.address_line1;
    pkg_detb_rtl_teller_rec.benef_addr2      := l_cust.address_line2;
    pkg_detb_rtl_teller_rec.benef_addr3      := l_cust.address_line3;
    pkg_detb_rtl_teller_rec.benef_addr4      := l_cust.address_line4;
    pkg_detb_rtl_teller_rec.liqn_dt          := p_ifdofast.v_iftbs_fast_master.transfer_date;
    pkg_detb_rtl_teller_rec.record_stat      := 'A';
    pkg_detb_rtl_teller_rec.auth_stat        := 'U';
    pkg_detb_rtl_teller_rec.maker_id         := p_ifdofast.v_iftbs_fast_master.maker_id;
    pkg_detb_rtl_teller_rec.maker_dt_stamp   := p_ifdofast.v_iftbs_fast_master.maker_dt_stamp;
    pkg_detb_rtl_teller_rec.checker_id       := p_ifdofast.v_iftbs_fast_master.checker_id;
    pkg_detb_rtl_teller_rec.checker_dt_stamp := p_ifdofast.v_iftbs_fast_master.checker_dt_stamp;
    pkg_detb_rtl_teller_rec.mod_no           := p_ifdofast.v_iftbs_fast_master.mod_no;
    pkg_detb_rtl_teller_rec.scode            := p_ifdofast.v_iftbs_fast_master.source_code;
    pkg_detb_rtl_teller_rec.dr_acc           := l_arc_maint.dr_acc;
    pkg_detb_rtl_teller_rec.module           := 'RT';
    pkg_detb_rtl_teller_rec.esn              := 1;
    pkg_detb_rtl_teller_rec.event_code       := 'INIT';
    pkg_detb_rtl_teller_rec.track_receivable := 'N';
    pkg_detb_rtl_teller_rec.time_received    := SYSDATE;

    -- 1
    FOR k IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP
      IF k = 1 THEN
        dbg('CHG AMT' || p_ifdofast.v_iftbs_fast_charge(k).chg_amt);
        IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
          pkg_detb_rtl_teller_rec.charge_account := p_ifdofast.v_iftbs_fast_master.rem_acc;
        ELSE
          pkg_detb_rtl_teller_rec.charge_account := p_ifdofast.v_iftbs_fast_master.ben_acc;
        END IF;
        pkg_detb_rtl_teller_rec.chg_gl           := l_arc_maint.cod_chg_gl;
        pkg_detb_rtl_teller_rec.chg_ccy          := l_arc_maint.cod_chg_ccy;
        pkg_detb_rtl_teller_rec.chg_amt          := p_ifdofast.v_iftbs_fast_charge(k)
                                                    .chg_amt;
        depks_rtl_teller.pkg_arc_row.cod_chg_amt := p_ifdofast.v_iftbs_fast_charge(k)
                                                    .chg_amt;

        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt);
        depks_rtl_teller.pkg_arc_row.cod_chg_type := l_arc_maint.cod_chg_type;

        IF l_arc_maint.cod_chg_ccy <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                     l_arc_maint.cod_chg_ccy,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdofast.v_iftbs_fast_charge(k).chg_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;

        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy       := p_ifdofast.v_iftbs_fast_charge(k)
                                                      .chg_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate := 1;
        END IF;

        DBG('pkg_detb_rtl_teller_rec.chg_in_acy=' ||
            pkg_detb_rtl_teller_rec.chg_in_acy);
        DBG('pkg_detb_rtl_teller_rec.chg_ccy_acy_rate=' ||
            pkg_detb_rtl_teller_rec.chg_ccy_acy_rate);

        pkg_detb_rtl_teller_rec.chg_in_lcy   := p_ifdofast.v_iftbs_fast_charge(k)
                                                .lcy_chg;
        pkg_detb_rtl_teller_rec.acy_lcy_rate := p_ifdofast.v_iftbs_fast_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind  := l_arc_maint.cod_chg_netting;
        pkg_detb_rtl_teller_rec.txn_code     := l_arc_maint.cod_chg_txn_code;
        pkg_detb_rtl_teller_rec.mis_head_1   := l_arc_maint.cod_mis_head;
        pkg_detb_rtl_teller_rec.chg_desc     := l_arc_maint.cod_chg_desc;
        pkg_detb_rtl_teller_rec.chg_type     := l_arc_maint.cod_chg_type;
        pkg_detb_rtl_teller_rec.waiver       := p_ifdofast.v_iftbs_fast_charge(k)
                                                .waiver;
        pkg_detb_rtl_teller_rec.their_chgs   := l_arc_maint.cod_their_chgs;
      END IF;
      -- 2
      IF k = 2 THEN
        pkg_detb_rtl_teller_rec.chg_gl_1  := l_arc_maint.cod_chg_gl1;
        pkg_detb_rtl_teller_rec.chg_ccy_1 := l_arc_maint.cod_chg_ccy1;
        pkg_detb_rtl_teller_rec.chg_amt_1 := p_ifdofast.v_iftbs_fast_charge(k)
                                             .chg_amt;

        depks_rtl_teller.pkg_arc_row.cod_chg_amt1 := p_ifdofast.v_iftbs_fast_charge(k)
                                                     .chg_amt;

        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT1' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt1);
        depks_rtl_teller.pkg_arc_row.cod_chg_type1 := l_arc_maint.cod_chg_type1;

        IF l_arc_maint.cod_chg_ccy1 <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                     l_arc_maint.cod_chg_ccy1,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdofast.v_iftbs_fast_charge(k).chg_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy_1,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_1       := p_ifdofast.v_iftbs_fast_charge(k)
                                                        .chg_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1 := 1;
        END IF;

        pkg_detb_rtl_teller_rec.chg_in_lcy_1   := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .lcy_chg;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_1 := p_ifdofast.v_iftbs_fast_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_1  := l_arc_maint.cod_chg_netting1;
        pkg_detb_rtl_teller_rec.txn_code_1     := l_arc_maint.cod_chg_txn_code1;
        pkg_detb_rtl_teller_rec.mis_head_2     := l_arc_maint.cod_mis_head1;
        pkg_detb_rtl_teller_rec.chg_desc1      := l_arc_maint.cod_chg_desc1;
        pkg_detb_rtl_teller_rec.chg_type1      := l_arc_maint.cod_chg_type1;
        pkg_detb_rtl_teller_rec.waiver1        := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .waiver;
        pkg_detb_rtl_teller_rec.their_chgs1    := l_arc_maint.cod_their_chgs1;
      END IF;
      -- 3
      IF k = 3 THEN
        pkg_detb_rtl_teller_rec.chg_gl_2  := l_arc_maint.cod_chg_gl2;
        pkg_detb_rtl_teller_rec.chg_ccy_2 := l_arc_maint.cod_chg_ccy2;
        pkg_detb_rtl_teller_rec.chg_amt_2 := p_ifdofast.v_iftbs_fast_charge(k)
                                             .chg_amt;

        depks_rtl_teller.pkg_arc_row.cod_chg_amt2 := p_ifdofast.v_iftbs_fast_charge(k)
                                                     .chg_amt;

        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT2' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt2);
        depks_rtl_teller.pkg_arc_row.cod_chg_type2 := l_arc_maint.cod_chg_type2;

        IF l_arc_maint.cod_chg_ccy2 <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                     l_arc_maint.cod_chg_ccy2,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdofast.v_iftbs_fast_charge(k).chg_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy_2,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_2,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_2       := p_ifdofast.v_iftbs_fast_charge(k)
                                                        .chg_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_2 := 1;
        END IF;

        pkg_detb_rtl_teller_rec.chg_in_lcy_2   := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .lcy_chg;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_2 := p_ifdofast.v_iftbs_fast_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_2  := l_arc_maint.cod_chg_netting2;
        pkg_detb_rtl_teller_rec.txn_code_2     := l_arc_maint.cod_chg_txn_code2;
        pkg_detb_rtl_teller_rec.mis_head_3     := l_arc_maint.cod_mis_head2;
        pkg_detb_rtl_teller_rec.chg_desc2      := l_arc_maint.cod_chg_desc2;
        pkg_detb_rtl_teller_rec.chg_type2      := l_arc_maint.cod_chg_type2;
        pkg_detb_rtl_teller_rec.waiver2        := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .waiver;
        pkg_detb_rtl_teller_rec.their_chgs2    := l_arc_maint.cod_their_chgs2;
      END IF;

      -- 4
      IF k = 4 THEN
        pkg_detb_rtl_teller_rec.chg_gl_3  := l_arc_maint.cod_chg_gl3;
        pkg_detb_rtl_teller_rec.chg_ccy_3 := l_arc_maint.cod_chg_ccy3;
        pkg_detb_rtl_teller_rec.chg_amt_3 := p_ifdofast.v_iftbs_fast_charge(k)
                                             .chg_amt;

        depks_rtl_teller.pkg_arc_row.cod_chg_amt3 := p_ifdofast.v_iftbs_fast_charge(k)
                                                     .chg_amt;

        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT3' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt3);
        depks_rtl_teller.pkg_arc_row.cod_chg_type3 := l_arc_maint.cod_chg_type3;
        IF l_arc_maint.cod_chg_ccy3 <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                     l_arc_maint.cod_chg_ccy3,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdofast.v_iftbs_fast_charge(k).chg_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy_3,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_3,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_3       := p_ifdofast.v_iftbs_fast_charge(k)
                                                        .chg_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_3 := 1;
        END IF;

        pkg_detb_rtl_teller_rec.chg_in_lcy_3   := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .lcy_chg;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_3 := p_ifdofast.v_iftbs_fast_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_3  := l_arc_maint.cod_chg_netting3;
        pkg_detb_rtl_teller_rec.txn_code_3     := l_arc_maint.cod_chg_txn_code3;
        pkg_detb_rtl_teller_rec.mis_head_4     := l_arc_maint.cod_mis_head3;
        pkg_detb_rtl_teller_rec.chg_desc3      := l_arc_maint.cod_chg_desc3;
        pkg_detb_rtl_teller_rec.chg_type3      := l_arc_maint.cod_chg_type3;
        pkg_detb_rtl_teller_rec.waiver3        := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .waiver;
        pkg_detb_rtl_teller_rec.their_chgs3    := l_arc_maint.cod_their_chgs3;
      END IF;
      -- 5
      IF k = 5 THEN
        pkg_detb_rtl_teller_rec.chg_gl_4  := l_arc_maint.cod_chg_gl4;
        pkg_detb_rtl_teller_rec.chg_ccy_4 := l_arc_maint.cod_chg_ccy4;
        pkg_detb_rtl_teller_rec.chg_amt_4 := p_ifdofast.v_iftbs_fast_charge(k)
                                             .chg_amt;

        depks_rtl_teller.pkg_arc_row.cod_chg_amt4 := p_ifdofast.v_iftbs_fast_charge(k)
                                                     .chg_amt;

        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT4' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt4);
        depks_rtl_teller.pkg_arc_row.cod_chg_type4 := l_arc_maint.cod_chg_type4;
        IF l_arc_maint.cod_chg_ccy4 <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                     l_arc_maint.cod_chg_ccy4,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdofast.v_iftbs_fast_charge(k).chg_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy_4,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_4,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_4       := p_ifdofast.v_iftbs_fast_charge(k)
                                                        .chg_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_4 := 1;
        END IF;

        pkg_detb_rtl_teller_rec.chg_in_lcy_4   := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .lcy_chg;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_4 := p_ifdofast.v_iftbs_fast_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_4  := l_arc_maint.cod_chg_netting4;
        pkg_detb_rtl_teller_rec.txn_code_4     := l_arc_maint.cod_chg_txn_code4;
        pkg_detb_rtl_teller_rec.mis_head_5     := l_arc_maint.cod_mis_head4;
        pkg_detb_rtl_teller_rec.chg_desc4      := l_arc_maint.cod_chg_desc4;
        pkg_detb_rtl_teller_rec.chg_type4      := l_arc_maint.cod_chg_type4;
        pkg_detb_rtl_teller_rec.waiver4        := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .waiver;
        pkg_detb_rtl_teller_rec.their_chgs4    := l_arc_maint.cod_their_chgs4;
      END IF;
    END LOOP;
    /*
     PKG_DETB_RTL_TELLER_REC.their_acc :=
    PKG_DETB_RTL_TELLER_REC.their_acc1 :=
    PKG_DETB_RTL_TELLER_REC.their_acc2 :=
    PKG_DETB_RTL_TELLER_REC.their_acc3 :=
    PKG_DETB_RTL_TELLER_REC.their_acc4 :=
    PKG_DETB_RTL_TELLER_REC.lcy_exch_rate :=
    PKG_DETB_RTL_TELLER_REC.tot_chg_in_tcy :=
    PKG_DETB_RTL_TELLER_REC.lcy_chg_exch_rate :=
    PKG_DETB_RTL_TELLER_REC.lcy_chg_exch_rate1 :=
    PKG_DETB_RTL_TELLER_REC.lcy_chg_exch_rate2 :=
    PKG_DETB_RTL_TELLER_REC.lcy_chg_exch_rate3 :=
    PKG_DETB_RTL_TELLER_REC.lcy_chg_exch_rate4 :=
    PKG_DETB_RTL_TELLER_REC.chg_contra_leg :=
    PKG_DETB_RTL_TELLER_REC.netting_reqd := */
    dbg('Calling depks_rtl_teller.fn_save');

    IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                    p_err_code,
                                    p_err_params) THEN
      dbg('Failed in Fn_Save');
      RETURN FALSE;
    END IF;
    dbg('Calling depks_rtl_teller.pr_messaging');
    --depks_rtl_teller.pr_messaging;

    dbg('Returning Success From FN_SAVE..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.FN_SAVE ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_save;

  FUNCTION fn_fast_out_msg_gen(p_ifdofast   IN OUT ifpks_ifdofast_main.ty_ifdofast,
                               p_msg        IN OUT CLOB,
                               p_err_code   IN OUT VARCHAR2,
                               p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS

    l_xml_hdr_comp VARCHAR2(1000) := '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
                                     <Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.05"
                                     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="xsd/pain.001.001.05.xsd"> ';

    l_xml_tag     CLOB;
    l_date        VARCHAR2(23);
    l_reqdexctndt VARCHAR2(23);
    l_gl_walkin   VARCHAR2(35);
    l_str1        VARCHAR2(10);
    l_date_ins    DATE;
    l_instr_id    VARCHAR2(35);
    l_etend_id    VARCHAR2(35);
  BEGIN
    dbg('In FN_FAST_OUT_MSG_GEN..');
    dbg('Start of pr_gen_pain_001_001_05');
    dbg('Message Identfication' || p_ifdofast.v_iftbs_fast_master.msg_id);
    l_date        := to_char(SYSDATE, 'YYYY-MM-DD') || 'T' ||
                     to_char(SYSDATE, 'hh24:MM:SS');
    l_reqdexctndt := to_char(SYSDATE, 'YYYY-MM-DD');
    l_str1        := substr(l_date, 1, 10);
    l_date_ins    := to_date(l_str1, 'YYYY-MM-DD');
    dbg('Date-->' || l_date);
    dbg('Date_INS-->' || l_date_ins);

    dbms_lob.createtemporary(l_xml_tag, cache => TRUE);

    /*SELECT cod_txn_account
      INTO l_gl_walkin
      FROM iftm_arc_maint
     WHERE cod_prod_acc_cls = p_ifdofast.v_iftbs_fast_master.product_code;

    dbg('l_GL_Walkin-->' || l_gl_walkin);*/

    l_xml_hdr_comp := l_xml_hdr_comp || chr(10) || '<CstmrCdtTrfInitn>' ||
                      chr(10);
    l_xml_hdr_comp := l_xml_hdr_comp || '<GrpHdr>' || chr(10);

    dbms_lob.append(l_xml_tag, l_xml_hdr_comp);

    dbg('Going to for loop');

    dbg('Msg_id-->' || p_ifdofast.v_iftbs_fast_master.msg_id);
    dbms_lob.append(l_xml_tag,
                    '<MsgId>' || p_ifdofast.v_iftbs_fast_master.msg_id ||
                    '</MsgId>' || chr(10));

    dbms_lob.append(l_xml_tag,
                    '<CreDtTm>' || l_date || '</CreDtTm>' || chr(10));
    dbms_lob.append(l_xml_tag,
                    '<NbOfTxs>' || '1' || '</NbOfTxs>' || chr(10));

    dbg('Total transfer amount-->' ||
        p_ifdofast.v_iftbs_fast_master.txn_amt);
    dbms_lob.append(l_xml_tag,
                    '<CtrlSum>' || p_ifdofast.v_iftbs_fast_master.txn_amt ||
                    '</CtrlSum>' || chr(10));
    dbms_lob.append(l_xml_tag,
                    '<InitgPty>' || chr(10) || '<Nm>' || 'Prince Bank PLC' ||
                    '</Nm>' || chr(10) || '</InitgPty>' || chr(10));

    dbms_lob.append(l_xml_tag, '</GrpHdr>' || chr(10));

    dbg('PAYMNT_IDENT_CODE -->' || p_ifdofast.v_iftbs_fast_master.pay_id); -- PAY_ID

    dbg('REQ_EXEC_DATE -->' || l_date);

    dbms_lob.append(l_xml_tag,
                    '<PmtInf>' || chr(10) || '<PmtInfId>' ||
                    p_ifdofast.v_iftbs_fast_master.pay_id || '</PmtInfId>' || -- PAY_ID
                    chr(10) || '<PmtMtd>' || 'TRF' || '</PmtMtd>' ||
                    chr(10) || '<BtchBookg>' || 'false' || '</BtchBookg>' ||
                    chr(10) || '<ReqdExctnDt>' || l_reqdexctndt ||
                    '</ReqdExctnDt>' || chr(10));

    dbms_lob.append(l_xml_tag,
                    '<Dbtr>' || chr(10) || '<Nm>' ||
                    p_ifdofast.v_iftbs_fast_master.rem_name || '</Nm>' ||
                    chr(10) || '</Dbtr>' || chr(10));

    dbg('Account number  -->' || p_ifdofast.v_iftbs_fast_master.rem_acc);

    dbms_lob.append(l_xml_tag,
                    '<DbtrAcct>' || chr(10) || '<Id>' || chr(10) ||
                    '<Othr>' || chr(10) || '<Id>' ||
                    p_ifdofast.v_iftbs_fast_master.rem_acc || '</Id>' ||
                    chr(10) || '</Othr>' || chr(10) || '</Id>' || chr(10) ||
                    '<Ccy>' || p_ifdofast.v_iftbs_fast_master.txn_ccy ||
                    '</Ccy>' || chr(10) || '</DbtrAcct>' || chr(10));

    dbms_lob.append(l_xml_tag,
                    '<DbtrAgt>' || chr(10) || '<FinInstnId>' || chr(10) ||
                    '<BICFI>' || 'PINCXXXX' || '</BICFI>' || chr(10) ||
                    '</FinInstnId>' || chr(10) || '</DbtrAgt>' || chr(10));

    dbg('p_ifdofast.v_iftbs_fast_master.etend_id' ||
        p_ifdofast.v_iftbs_fast_master.etend_id);
    dbg('p_ifdofast.v_iftbs_fast_master.instr_id' ||
        p_ifdofast.v_iftbs_fast_master.instr_id);

    SELECT instr_id, etend_id
      INTO l_instr_id, l_etend_id
      FROM iftb_fast_master
     WHERE trn_ref_no = p_ifdofast.v_iftbs_fast_master.trn_ref_no;

    dbms_lob.append(l_xml_tag,
                    '<CdtTrfTxInf>' || chr(10) || '<PmtId>' || chr(10) ||
                    '<InstrId>' ||
                    nvl(p_ifdofast.v_iftbs_fast_master.instr_id, l_instr_id) ||
                    '</InstrId>' || chr(10) || '<EndToEndId>' ||
                    nvl(p_ifdofast.v_iftbs_fast_master.etend_id, l_etend_id) ||
                    '</EndToEndId>' || chr(10) || '</PmtId>' || chr(10) ||
                    '<Amt>' || chr(10) || '<InstdAmt Ccy = "' ||
                    p_ifdofast.v_iftbs_fast_master.txn_ccy || '">' ||
                    p_ifdofast.v_iftbs_fast_master.txn_amt || '</InstdAmt>' ||
                    chr(10) || '</Amt>' || chr(10) || '<ChrgBr>' || 'CRED' ||
                    '</ChrgBr>' || chr(10));

    dbg('BEN_BIC  -->' || p_ifdofast.v_iftbs_fast_master.ben_bic);

    /*dbms_lob.append(l_xml_tag,
    '<CdtrAgt>' || chr(10) || '<FinInstnId>' || chr(10) ||
    '<BICFI>' || 'ACLB' || 'XXXX' || '</BICFI>' || chr(10) ||
    '</FinInstnId>' || chr(10) || '</CdtrAgt>' || chr(10));*/

    dbms_lob.append(l_xml_tag,
                    '<CdtrAgt>' || chr(10) || '<FinInstnId>' || chr(10) ||
                    '<BICFI>' ||
                    SUBSTR(p_ifdofast.v_iftbs_fast_master.BEN_BIC, 1, 4) ||
                    'XXXX' || '</BICFI>' || chr(10) || '</FinInstnId>' ||
                    chr(10) || '</CdtrAgt>' || chr(10));

    dbg('BENEF_NAME  -->' || p_ifdofast.v_iftbs_fast_master.ben_name);

    dbms_lob.append(l_xml_tag,
                    '<Cdtr>' || chr(10) || '<Nm>' ||
                    p_ifdofast.v_iftbs_fast_master.ben_name || '</Nm>' ||
                    chr(10) || '</Cdtr>' || chr(10));

    dbg('BEN_ACCOUNT  -->' || p_ifdofast.v_iftbs_fast_master.ben_acc);

    dbms_lob.append(l_xml_tag,
                    '<CdtrAcct>' || chr(10) || '<Id>' || chr(10) ||
                    '<Othr>' || chr(10) || '<Id>' ||
                    p_ifdofast.v_iftbs_fast_master.ben_acc || '</Id>' ||
                    chr(10) || '</Othr>' || chr(10) || '</Id>' || chr(10) ||
                    '</CdtrAcct>' || chr(10));

    dbms_lob.append(l_xml_tag,
                    '<Purp>' || chr(10) || '<Cd>' || 'GDDS' || '</Cd>' ||
                    chr(10) || '</Purp>' || chr(10));

    dbg('DESCRIPTION  -->' || p_ifdofast.v_iftbs_fast_master.ben_remarks);

    dbms_lob.append(l_xml_tag,
                    '<RmtInf>' || chr(10) || '<Ustrd>' ||
                    p_ifdofast.v_iftbs_fast_master.ben_remarks || '/' ||
                    substr(p_ifdofast.v_iftbs_fast_master.pay_id, -8) ||
                    '</Ustrd>' || chr(10) || '<Strd>' || chr(10) ||
                    '<RfrdDocInf>' || chr(10) || '<Tp>' || chr(10) ||
                    '<CdOrPrtry>' || chr(10) || '<Cd>' || 'CINV' || '</Cd>' ||
                    chr(10) || '</CdOrPrtry>' || chr(10) || '</Tp>' ||
                    chr(10) || '<Nb>' || '987-AC' || '</Nb>' || chr(10) ||
                    '<RltdDt>' || to_char(SYSDATE, 'YYYY-MM-DD') ||
                    '</RltdDt>' || chr(10) || '</RfrdDocInf>' || chr(10) ||
                    '</Strd>' || chr(10) || '</RmtInf>' || chr(10));

    dbms_lob.append(l_xml_tag,
                    '</CdtTrfTxInf>' || chr(10) || '</PmtInf>' || chr(10));
    l_xml_tag := l_xml_tag || '</CstmrCdtTrfInitn>' || chr(10);
    l_xml_tag := l_xml_tag || '</Document>' || chr(10);
    dbg('Final message-->' || dbms_lob.substr(l_xml_tag, 32767, 1));
    p_msg := l_xml_tag;
    dbms_lob.freetemporary(l_xml_tag);
    dbg('Returning Success From FN_FAST_OUT_MSG_GEN..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.FN_FAST_OUT_MSG_GEN ..');
      debug.pr_debug('**', SQLERRM);
      dbms_lob.freetemporary(l_xml_tag);
      p_err_code   := 'IF-FAST-009';
      p_err_params := 'Can not generate pain_001.001.05';
      RETURN FALSE;
  END fn_fast_out_msg_gen;

  FUNCTION FN_FAST_HTTP_CALL(p_msg_type VARCHAR2,
                             p_out_msg  VARCHAR2,
                             p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_buffer_size   NUMBER(10) := 512;
    l_substring_msg VARCHAR2(32767);
    l_raw_data      RAW(2000);
    l_clob_response CLOB;
    l_url           cstb_param.param_val%TYPE;
    l_resp_ok       BOOLEAN;
    l_resp_num      NUMBER;

  BEGIN
    dbg('In FN_FAST_HTTP_CALL');
    dbg(p_msg_type || '~' || length(p_out_msg));
    dbms_lob.createtemporary(lob_loc => l_clob_response, cache => TRUE);

    IF p_msg_type = 'F' THEN
      utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));
      l_url := get_param_val('PGW_OUT_FAST_URL');

    END IF;

    dbg('l_url-->' || l_url);
    l_http_request := utl_http.begin_request(url          => l_url,
                                             method       => 'POST',
                                             http_version => 'HTTP/1.1');
    utl_http.set_header(l_http_request, 'User-Agent', 'Mozilla/4.0');
    utl_http.set_header(l_http_request, 'Connection', 'close');
    utl_http.set_header(l_http_request,
                        'Content-Type',
                        'text/xml; charset=utf-8');
    -- UTL_HTTP.set_header (l_http_request, 'Content-Length', lengthb(CONVERT(p_out_msg, 'UTF8')));

    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
    <<request_loop>>

    FOR i IN 0 .. ceil(length(p_out_msg) / l_buffer_size) - 1 LOOP
      l_substring_msg := substr(p_out_msg,
                                i * l_buffer_size + 1,
                                l_buffer_size);
      BEGIN
        l_raw_data := utl_raw.cast_to_raw(l_substring_msg);
        utl_http.write_raw(r => l_http_request, data => l_raw_data);
      EXCEPTION
        WHEN no_data_found THEN
          dbg('Request Loop NDF');
          EXIT request_loop;
      END;
    END LOOP request_loop;
    l_http_response := utl_http.get_response(l_http_request);
    dbg('Response> status_code: "' || l_http_response.status_code || '"');

    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;

    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;

    IF l_resp_ok THEN
      BEGIN
        <<response_loop>>
        LOOP
          utl_http.read_raw(l_http_response, l_raw_data, l_buffer_size);
          l_clob_response := l_clob_response ||
                              --CONVERT(utl_raw.cast_to_varchar2(l_raw_data),'AR8MSWIN1256','AL32UTF8');
                             --utl_raw.cast_to_varchar2(l_raw_data);    
                             --CONVERT(utl_raw.cast_to_varchar2(l_raw_data),'WE8MSWIN1256','UTF8');
                             CONVERT(utl_raw.cast_to_varchar2(l_raw_data)||'','WE8MSWIN1252','UTF8');
        END LOOP response_loop;
      EXCEPTION
        WHEN utl_http.end_of_body THEN
          utl_http.end_response(l_http_response);
        WHEN OTHERS THEN
          dbg('Inside Exception others in response');
          dbg(SQLERRM);
          dbg(dbms_utility.format_error_backtrace);
          utl_http.end_response(l_http_response);
      END;
      dbg('Out of Loop');
      --dbg('Length of response-->' || dbms_lob.getlength(l_clob_response));
      -- dbg('value of response-->' ||
      --    dbms_lob.substr(l_clob_response, 32767));
      p_in_resp := l_clob_response;

    END IF;

    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;

    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;

    dbms_lob.freetemporary(l_clob_response);

    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      RETURN FALSE;
  END FN_FAST_HTTP_CALL;

  PROCEDURE PR_MSG_UPDATE(P_MSG_ID IN IFTB_FAST_MASTER.MSG_ID%TYPE,
                          p_msg    IN OUT CLOB) IS
    -- PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    UPDATE iftbs_pgw_msgs SET RESP_XML = p_msg WHERE MSG_ID = P_MSG_ID;

    --COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE IN PR_MSG_UPDATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_MSG_UPDATE=' || SQLERRM);
  END;

  FUNCTION fn_msg_upload(p_source      IN VARCHAR2,
                         p_function_id IN VARCHAR2,
                         p_ifdofast    IN OUT ifpks_ifdofast_main.ty_ifdofast,
                         p_msg         IN OUT CLOB,
                         p_err_code    IN OUT VARCHAR2,
                         p_err_params  IN OUT VARCHAR2) RETURN BOOLEAN IS

    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
    l_in_resp       CLOB;
    e_update_error EXCEPTION;
    l_txnstatus iftb_fast_master.txn_status%TYPE := get_param_val('PGW_TEMP_TXN_STAT');
    l_rejreason iftb_fast_master.txn_remarks%TYPE := get_param_val('PGW_TEMP_TXN_REMARKS');
    l_pos       NUMBER := 0;
    r_pos       NUMBER := 0;
  BEGIN
    dbg('Inside fn_msg_upload - inserting to iftbs_pgw_msgs');

    INSERT INTO iftbs_pgw_msgs
    VALUES
      (p_ifdofast.v_iftbs_fast_master.msg_id,
       p_ifdofast.v_iftbs_fast_master.trn_ref_no,
       p_ifdofast.v_iftbs_fast_master.transfer_mode,
       p_msg,
       NULL,
       csfn_timestamp,
       p_ifdofast.v_iftbs_fast_master.msg_flow,
       'G');

    dbg('Insert done');
    dbg('transfer mode' || p_ifdofast.v_iftbs_fast_master.transfer_mode);

    IF p_ifdofast.v_iftbs_fast_master.transfer_mode = 'F' THEN

      l_formatted_msg := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fas="http://fastwebservice.nbc.org.kh/">
            <soapenv:Header/>
            <soapenv:Body>
               <fas:makeFullFundTransfer>
                  <cm_user_name>' ||
                         get_param_val('PGW_OUT_FAST_UID') ||
                         '</cm_user_name>
                  <cm_password>' ||
                         get_param_val('PGW_OUT_FAST_PWD') ||
                         '</cm_password>
                  <iso_message><![CDATA[' || p_msg ||
                         ']]></iso_message>
                  <import_file_name></import_file_name>
               </fas:makeFullFundTransfer>
            </soapenv:Body>
          </soapenv:Envelope>';

      dbg('l_formatted_msg for fast' || l_formatted_msg);

      IF NOT FN_FAST_HTTP_CALL('F', L_FORMATTED_MSG, L_IN_RESP) THEN
        DBG('failed to send pain_001_001_05');
        RAISE E_UPDATE_ERROR;
      END IF;

      DBG('Sent and response is ' || L_IN_RESP);
      L_IN_RESP := FN_CLOBREPLACE(L_IN_RESP, '&lt;', '<');
      DBG('One step done-->' || L_IN_RESP);
      L_IN_RESP := FN_CLOBREPLACE(L_IN_RESP, '&gt;', '>');
      DBG('Two step done and after UNESCAPE, it is ' || L_IN_RESP);
      L_POS := DBMS_LOB.INSTR(L_IN_RESP, '<return>', 1, 1);
      DBG('l_pos is ' || L_POS);
      R_POS := DBMS_LOB.INSTR(L_IN_RESP, '</return>', 1, 1);
      DBG('r_pos is ' || R_POS);
      L_IN_RESP := TRIM(DBMS_LOB.SUBSTR(L_IN_RESP,
                                        R_POS - L_POS - LENGTH('<return>'),
                                        L_POS + LENGTH('<return>')));

      DBG('After cutting other irrelevant parts , it is ' || L_IN_RESP);

      --Update the table
      PR_MSG_UPDATE(p_ifdofast.v_iftbs_fast_master.msg_id, L_IN_RESP);

      SELECT XT.TXSTS TXSTS, XT.REJREASON REJREASON
        INTO L_TXNSTATUS, L_REJREASON
        FROM XMLTABLE(XMLNAMESPACES(DEFAULT 'urn:iso:std:iso:20022:tech:xsd:pain.002.001.06'),
                      '/Document/CstmrPmtStsRpt' PASSING XMLTYPE(L_IN_RESP)
                      COLUMNS TXSTS VARCHAR2(23) PATH
                      'OrgnlPmtInfAndSts/TxInfAndSts/TxSts',
                      REJREASON VARCHAR2(20) PATH
                      'OrgnlPmtInfAndSts/TxInfAndSts/StsRsnInf/AddtlInf') XT;
      DBG('l_txnstatus is ' || L_TXNSTATUS);
      DBG('l_rejreason is ' || L_REJREASON); -- COMMENTED TEMPORARILY FOR OFFSHORE TESTING - ALL TXN TO GO AS ACCEPTED

    END IF; -- Based on msg type, calling the FUNCTION http call and processing the response accordingly

    IF l_txnstatus = 'RJCT' THEN
      dbg('Transaction Rejected. Cannot procede further.');
      /* p_err_code   := 'GI-FST-013';
      p_err_params := l_rejreason || '~';*/

      dbg('Need to DELETE any accounting entries fired UNAUTH since it is REJT from NBC-->' ||
          p_ifdofast.v_iftbs_fast_master.trn_ref_no || '~' ||
          p_ifdofast.v_iftbs_fast_master.msg_id);
      IF NOT depks_rtl_teller.fn_delete(p_ifdofast.v_iftbs_fast_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN

        dbg('Fail in DELETE accounting entries');
        RAISE e_update_error;
      END IF;

      /*UPDATE iftb_fast_master
         SET txn_status = l_txnstatus, txn_remarks = l_rejreason
       WHERE trn_ref_no = p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      dbg('updated-->' || SQL%ROWCOUNT);*/
      PR_UPDATE_STATUS_FAST_OUTGOING(P_IFDOFAST.V_IFTBS_FAST_MASTER.TRN_REF_NO,
                                     L_TXNSTATUS);

      pr_log_error(p_function_id,
                   p_source,
                   'IF-FST006',
                   l_txnstatus || '~' || l_rejreason);

    ELSE

      --Call getOutgoingTransaction API call
      IF NOT fn_process_entries(p_ifdofast, 'A', p_err_code, p_err_params) THEN
        dbg('Fail in AUTH accounting entries');
        RAISE e_update_error;
      END IF;
    END IF;

    dbg('updated the status and reject reason to ALL transactions in the BATCH');

    /*UPDATE iftb_fast_master
       SET txn_status = l_txnstatus, txn_remarks = l_rejreason
     WHERE trn_ref_no = p_ifdofast.v_iftbs_fast_master.trn_ref_no;
    dbg('updated-->' || SQL%ROWCOUNT);*/

    PR_UPDATE_STATUS_FAST_OUTGOING(P_IFDOFAST.V_IFTBS_FAST_MASTER.TRN_REF_NO,
                                   L_TXNSTATUS);

    pr_log_error(p_function_id,
                 p_source,
                 'IF-FST005',
                 l_txnstatus || '~' || l_rejreason);

    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      RETURN FALSE;
  END fn_msg_upload;

  -- PRINCE 12.4 FAST CUSTOMIZATION CHANGES - END
  FUNCTION fn_post_build_type_structure(p_source           IN VARCHAR2,
                                        p_source_operation IN VARCHAR2,
                                        p_function_id      IN VARCHAR2,
                                        p_action_code      IN VARCHAR2,
                                        p_child_function   IN VARCHAR2,
                                        p_addl_info        IN cspks_req_global.ty_addl_info,
                                        p_ifdofast         IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                        p_err_code         IN OUT VARCHAR2,
                                        p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Post_Build_type_structure..');

    dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others Of ifpks_ifdofast_Custom.Fn_Post_Build_type_structure ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_build_type_structure;

  FUNCTION fn_pre_check_mandatory(p_source           IN VARCHAR2,
                                  p_source_operation IN VARCHAR2,
                                  p_function_id      IN VARCHAR2,
                                  p_action_code      IN VARCHAR2,
                                  p_child_function   IN VARCHAR2,
                                  p_ifdofast         IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                  p_err_code         IN OUT VARCHAR2,
                                  p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
    -- PRINCE 12.4 FAST CUSTOMIZATION CHANGES - START
    l_detb_rtl_teller_rec detb_rtl_teller%ROWTYPE;
    l_out_msg             CLOB;
    -- PRINCE 12.4 FAST CUSTOMIZATION CHANGES - END
    
     --AML New Payment Flow Starts
  
    L_REF          VARCHAR2(16);
    L_SEQ          NUMBER;
    L_RESPONSE     CLOB;
    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_IN_RESP      CLOB;
    P_HIT_STATUS   VARCHAR2(100);
    P_SCAN_ID      VARCHAR2(100);
  
    L_CUSTOMER               STTM_CUSTOMER%ROWTYPE;
    L_STTB_CORAL_FAST_WS_LOG STTB_CORAL_FAST_WS_LOG%ROWTYPE;
    L_COUNT                  NUMBER;
    L_SENDER_NAME            STTB_CORAL_FAST_WS_LOG.SENDER_NAME%TYPE;
    L_SENDER_COUNTRY         STTB_CORAL_FAST_WS_LOG.SENDER_HIGH_CNT%TYPE;
    L_BEN_NAME               STTB_CORAL_FAST_WS_LOG.BEN_NAME%TYPE;
    L_BEN_COUNTRY            STTB_CORAL_FAST_WS_LOG.BEN_HIGH_CNT%TYPE;
    --AML New Payment Flow Ends
     
     

  BEGIN

    dbg('In Fn_Pre_Check_Mandatory' || p_action_code);
    -- PRINCE 12.4 FAST CUSTOMIZATION CHANGES - START

    dbg('p_Action_Code' || p_action_code);
    IF p_action_code = 'PICKUP' THEN
      IF NOT fn_enrich_product(p_ifdofast, p_err_code, p_err_params) THEN
        dbg('Failed in Fn_Enrich_Product');
        RETURN FALSE;
      END IF;
    END IF;

    IF p_action_code = 'ENRICHCHG' THEN

      IF NOT fn_enrich_chg(p_ifdofast, p_err_code, p_err_params) THEN
        dbg('Failed in fn_enrich_chg');
        DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_call_stack);
        DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_ERROR_stack);

        RETURN FALSE;
      END IF;
    END IF;

    --Get Outgoing Transaction by ID
    IF p_action_code = 'GETOUTTXNSTATUS' THEN

      dbg(' Message generation success, going to upload now');
      IF NOT FN_GET_OUTGOING_TXN_BY_ID(p_ifdofast,
                                       l_out_msg,
                                       p_err_code,
                                       p_err_params) THEN
        dbg('Failed in fn_msg_upload');
        RETURN FALSE;
      END IF;
    END IF;

    --Save Transaction
    IF p_action_code = cspks_req_global.p_new THEN
      
    --AML New Payment Flow Starts
    
      BEGIN
      
        SELECT *
          INTO L_CUSTOMER
          FROM STTM_CUSTOMER
         WHERE CUSTOMER_NO IN
               (SELECT CUST_NO
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = p_ifdofast.v_iftbs_fast_master.rem_acc);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CUSTOMER := NULL;
      END;
    
      --check the count
      BEGIN
      
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_CORAL_FAST_WS_LOG A
         WHERE A.SCAN_ID IS NOT NULL
           AND A.REQ_MSG IS NOT NULL
           AND A.RES_MSG IS NOT NULL
           AND A.BEN_NAME = p_ifdofast.v_iftbs_fast_master.BEN_NAME
           AND A.BEN_HIGH_CNT = 'KH'
           AND A.FC_REF_NO = p_ifdofast.v_iftbs_fast_master.TRN_REF_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          L_COUNT := 0;
        
      END;
    
      DBG('L_COUNT=' || L_COUNT);
    
      IF L_COUNT = 0 THEN
      
        /*IF NOT IFPKS_SANCTION_UTILS.FN_AML_PAYMENT_CALL_A(GLOBAL.user_id,
                                                          GLOBAL.current_branch,
                                                          'OTC',
                                                          
                                                          L_REF,
                                                          p_ifdofast.v_iftbs_fast_master.BEN_NAME,
                                                          'KH', --L_HIGH_BEN_CNT,
                                                          'PINCKHPPXXX',
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          100,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          'FAST',
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          L_CUSTOMER.Customer_No,
                                                          NULL, --L_SENDER_NAME
                                                          NULL, --L_SENDER_COUNTRY
                                                          p_ifdofast.v_iftbs_fast_master.BEN_NAME, --L_BEN_NAME
                                                          'KH', --L_BEN_COUNTRY
                                                          p_ifdofast.v_iftbs_fast_master.TRN_REF_NO,
                                                          P_SCAN_ID,
                                                          P_HIT_STATUS,
                                                          L_IN_RESP) THEN
        
          DBG('FAILED IN FN_AML_PAYMENT_CALL_A');
        
          RETURN FALSE;
        
        ELSE
        
          \*--Get JSON in XML
          L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
          DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
          
          L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                               '&lt;',
                                                               '<');
          DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
          
          L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                               '&gt;',
                                                               '>');
          DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
          
          DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
              L_RESP_IN_XML);
          
          P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
          
          P_HIT_STATUS := P_DOCUMENT_XML.EXTRACT('/root/RtnHit/text()')
                          .GETSTRINGVAL;
          
          P_SCAN_ID := P_DOCUMENT_XML.EXTRACT('/root/RtnScanID/text()')
                       .GETSTRINGVAL;*\
        
          DBG('P_HIT_STATUS OF API-A =' || P_HIT_STATUS);
        
          DBG('P_SCAN_ID OF API-A=' || P_SCAN_ID);
        
          IF P_HIT_STATUS = 'X' THEN
          
            PR_LOG_ERROR('IFDOFAST', 'FLEXCUBE', 'IF-RIA-013', P_SCAN_ID);
          
            --OVPKSS.PR_APPENDTBL('IF-RIA-030',
            --                          P_SCAN_ID);  
          
            RETURN FALSE; --AUTO REJECT 
          
          ELSE*/
      
        --call api B
      
        IF NOT IFPKS_SANCTION_UTILS.FN_AML_PAYMENT_CALL_B(GLOBAL.user_id,
                                                          GLOBAL.current_branch,
                                                          'OTC',
                                                          
                                                          L_REF,
                                                          p_ifdofast.v_iftbs_fast_master.BEN_NAME,
                                                          'KH', --L_HIGH_BEN_CNT,
                                                          p_ifdofast.v_iftbs_fast_master.BEN_BIC,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          p_ifdofast.v_iftbs_fast_master.BEN_ADD1 || ' ' ||
                                                          p_ifdofast.v_iftbs_fast_master.BEN_ADD2 || ' ' ||
                                                          p_ifdofast.v_iftbs_fast_master.BEN_ADD3 || ' ' ||
                                                          p_ifdofast.v_iftbs_fast_master.BEN_ADD4,
                                                          NULL,
                                                          p_ifdofast.v_iftbs_fast_master.BEN_REMARKS,
                                                          p_ifdofast.v_iftbs_fast_master.txn_amt, --100,
                                                          p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                                          p_ifdofast.v_iftbs_fast_master.BEN_ACC,
                                                          NULL,
                                                          NULL,
                                                          'FAST',
                                                          'FS01',
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          L_CUSTOMER.Customer_No,
                                                          NULL, --L_SENDER_NAME
                                                          NULL, --L_SENDER_COUNTRY
                                                          p_ifdofast.v_iftbs_fast_master.BEN_NAME, --L_BEN_NAME
                                                          'KH', --L_BEN_COUNTRY
                                                          p_ifdofast.v_iftbs_fast_master.TRN_REF_NO,
                                                          P_SCAN_ID,
                                                          P_HIT_STATUS,
                                                          L_IN_RESP) THEN
          
        
          
          
          PR_LOG_ERROR('IFDOFAST',
                         'FLEXCUBE',
                         'IF-AML-001',
                         NULL);
                         
          RETURN FALSE;
        
        ELSE
          /*--Get JSON in XML
          L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
          DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
          
          L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                               '&lt;',
                                                               '<');
          DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' ||
              L_RESP_IN_XML);
          
          L_RESP_IN_XML := IFPKS_SANCTION_UTILS.FN_CLOBREPLACE(L_RESP_IN_XML,
                                                               '&gt;',
                                                               '>');
          DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' ||
              L_RESP_IN_XML);
          
          DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
              L_RESP_IN_XML);
          
          P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
          
          P_HIT_STATUS := P_DOCUMENT_XML.EXTRACT('/root/RtnHit/text()')
                          .GETSTRINGVAL;
          
          P_SCAN_ID := P_DOCUMENT_XML.EXTRACT('/root/RtnScanID/text()')
                       .GETSTRINGVAL;*/
        
          DBG('P_HIT_STATUS OF API-B =' || P_HIT_STATUS);
        
          DBG('P_SCAN_ID OF API-B=' || P_SCAN_ID);
        
          DBG('CSPKS_SERVICE.P_NEW=' || CSPKS_SERVICE.P_NEW);
        
          IF P_HIT_STATUS = 'Y' THEN
          
            PR_LOG_ERROR('IFDOFAST',
                         'FLEXCUBE',
                         'IF-RIA-030',
                         P_SCAN_ID /*|| CASE P_WHO_HIT WHEN 'S' THEN
                                                                                                                                                                                                              'For Sender' WHEN 'R' THEN 'For Beneficiary' WHEN 'B' THEN
                                                                                                                                                                                                              'For Both Sender and Beneficiary' END*/);
          
          END IF;
        
        END IF;
      
      END IF;
    
      --END IF;
      --END IF;
    
      --AML New Payment Flow Ends   
      
      IF NOT fn_save(p_ifdofast,
                     l_detb_rtl_teller_rec,
                     p_err_code,
                     p_err_params) THEN
        dbg('Failed in FN_SAVE');
        RETURN FALSE;
      END IF;
    END IF;

    --Modify Transaction
    IF p_action_code = cspks_req_global.p_modify THEN
      dbg('Voila 2');

      IF NOT depks_rtl_teller.fn_delete(p_ifdofast.v_iftbs_fast_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in modify fn_delete');
        RETURN FALSE;
      END IF;

      IF NOT fn_save(p_ifdofast,
                     l_detb_rtl_teller_rec,
                     p_err_code,
                     p_err_params) THEN
        dbg('Failed in modify fn_save');
        RETURN FALSE;
      END IF;
    END IF;

    --Delete Transaction
    IF p_action_code = cspks_req_global.p_delete THEN
      IF NOT depks_rtl_teller.fn_delete(p_ifdofast.v_iftbs_fast_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in FN_DELETE');
        RETURN FALSE;
      END IF;
    END IF;

    --Auth Transaction
    IF p_action_code = cspks_req_global.p_auth THEN

      dbg('P_IFDOFAST.V_IFTBS_FAST_MASTER.TRANSFER_MODE ' ||
          p_ifdofast.v_iftbs_fast_master.transfer_mode);

      IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
        IF p_ifdofast.v_iftbs_fast_master.transfer_mode = 'F' THEN
          DBG('p_ifdofast.v_iftbs_fast_master.MAKER_ID=' ||
              p_ifdofast.v_iftbs_fast_master.MAKER_ID);
          DBG('p_ifdofast.v_iftbs_fast_master.CHECKER_ID=' ||
              p_ifdofast.v_iftbs_fast_master.CHECKER_ID);
          DBG('GLOBAL.USER_ID' || GLOBAL.USER_ID);
          --Maker Can not authorize
          IF p_ifdofast.v_iftbs_fast_master.MAKER_ID = GLOBAL.USER_ID THEN
            pr_log_error(p_function_id, p_source, 'CF-AUT-002', NULL);
            RETURN FALSE;
          END IF;
          --Generate Fast Outgoing message
          IF NOT fn_fast_out_msg_gen(p_ifdofast,
                                     l_out_msg,
                                     p_err_code,
                                     p_err_params) THEN
            dbg('Failed in FN_FAST_OUT_MSG_GEN');
            RETURN FALSE;
          END IF;

        END IF;

        dbg(' Message generation success, going to upload now');
        IF NOT fn_msg_upload(p_source,
                             p_function_id,
                             p_ifdofast,
                             l_out_msg,
                             p_err_code,
                             p_err_params) THEN
          dbg('Failed in fn_msg_upload');
          RETURN FALSE;
        END IF;
        dbg('fn_msg_upload successful');
      END IF;
      dbg('Done with upload process, going to generate advice');
      depks_rtl_teller.pr_gen_adv_for_contract(p_ifdofast.v_iftbs_fast_master.trn_ref_no);
      dbg('Done with advice generation ');
    END IF;
    -- PRINCE 12.4 FAST CUSTOMIZATION CHANGES - END
    dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Pre_Check_Mandatory ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION fn_post_check_mandatory(p_source           IN VARCHAR2,
                                   p_source_operation IN VARCHAR2,
                                   p_function_id      IN VARCHAR2,
                                   p_action_code      IN VARCHAR2,
                                   p_child_function   IN VARCHAR2,
                                   p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                                   p_err_code         IN OUT VARCHAR2,
                                   p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
  BEGIN

    dbg('In Fn_Post_Check_Mandatory..');

    dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Post_Check_Mandatory ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_check_mandatory;

  FUNCTION fn_pre_default_and_validate(p_source           IN VARCHAR2,
                                       p_source_operation IN VARCHAR2,
                                       p_function_id      IN VARCHAR2,
                                       p_action_code      IN VARCHAR2,
                                       p_child_function   IN VARCHAR2,
                                       p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                                       p_prev_ifdofast    IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                       p_wrk_ifdofast     IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                       p_err_code         IN OUT VARCHAR2,
                                       p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    l_result       NUMBER(2);
    l_lcl_ben_name sttm_customer.customer_name1%TYPE;
    l_cust_name    sttm_customer.customer_name1%TYPE;
    l_match        VARCHAR2(1) := 'N';
  BEGIN

    dbg('In Fn_Pre_Default_And_Validate..' || p_action_code);
    dbg('p_ifdofast.v_iftbs_fast_master.transfer_mode' ||
        p_ifdofast.v_iftbs_fast_master.transfer_mode);

    IF p_action_code = cspks_req_global.p_modify THEN
      dbg('p_prev_ifdofast.v_iftbs_fast_master.maker_id' ||
          p_prev_ifdofast.v_iftbs_fast_master.maker_id);
      dbg('p_prev_ifdofast.v_iftbs_fast_master.auth_stat' ||
          p_prev_ifdofast.v_iftbs_fast_master.auth_stat);

      IF p_prev_ifdofast.v_iftbs_fast_master.auth_stat = 'U' AND
         p_prev_ifdofast.v_iftbs_fast_master.maker_id != global.user_id THEN
        pr_log_error(p_function_id, p_source, 'IA-ONL-016', NULL);
      END IF;
    END IF;

    -- only alpha numeric for fast & local
    IF p_action_code IN (cspks_req_global.p_new, cspks_req_global.p_modify) AND
       p_ifdofast.v_iftbs_fast_master.transfer_mode IN ('F') AND
       p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      l_result := length(TRIM(translate(p_ifdofast.v_iftbs_fast_master.ben_name,
                                        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
                                        ' ')));
      IF l_result > 0 THEN
        dbg('Ben Name is not alpha numeric');
        pr_log_error(p_function_id, p_source, 'IF-FST003', NULL);
      END IF;

      IF (p_ifdofast.v_iftbs_fast_master.ben_acc IS NULL OR
         p_ifdofast.v_iftbs_fast_master.ben_name IS NULL OR
         p_ifdofast.v_iftbs_fast_master.ben_bic IS NULL) THEN
        dbg('Ben Acc, Ben Name, Ben Bic is mandatory for FAST Payment');
        pr_log_error(p_function_id, p_source, 'IF-FST010', NULL);
      END IF;

    END IF;

    -- generic vals
    IF p_ifdofast.v_iftbs_fast_master.txn_amt < 0 THEN
      dbg('Txn Amount cannot be negative');
      pr_log_error(p_function_id, p_source, 'IF-FST012', NULL);
    END IF;

    IF p_ifdofast.v_iftbs_fast_master.ben_phone IS NOT NULL THEN
      l_result := length(TRIM(translate(p_ifdofast.v_iftbs_fast_master.ben_phone,
                                        '0123456789',
                                        ' ')));
      IF l_result > 0 THEN
        dbg('Ben Phone is not numeric');
        pr_log_error(p_function_id, p_source, 'IF-FST013', NULL);
      END IF;
    END IF;

    IF p_ifdofast.v_iftbs_fast_master.transfer_mode IN ('F') AND
       p_ifdofast.v_iftbs_fast_master.ben_acc IS NOT NULL THEN
      l_result := length(TRIM(translate(p_ifdofast.v_iftbs_fast_master.ben_acc,
                                        '0123456789',
                                        ' ')));
      IF l_result > 0 THEN
        dbg('Ben Account is not numeric for FAST Payments');
        pr_log_error(p_function_id, p_source, 'IF-FST015', NULL);
      END IF;
    END IF;

    -- local ben name validation
    IF p_action_code IN (cspks_req_global.p_new, cspks_req_global.p_modify) AND
       p_ifdofast.v_iftbs_fast_master.transfer_mode = 'L' AND
       p_ifdofast.v_iftbs_fast_master.msg_flow = 'I' THEN
      dbg('In here for ben name validation' ||
          p_ifdofast.v_iftbs_fast_master.ben_name);

      l_lcl_ben_name := p_ifdofast.v_iftbs_fast_master.ben_name;

      SELECT customer_name1
        INTO l_cust_name
        FROM sttm_customer, sttm_cust_account
       WHERE customer_no = cust_no
         AND cust_ac_no = p_ifdofast.v_iftbs_fast_master.ben_acc;

      IF upper(l_lcl_ben_name) = upper(l_cust_name) THEN
        dbg('1st step matched');
        l_match := 'Y';
      ELSIF TRIM(regexp_replace(upper(l_lcl_ben_name),
                                'LTD|LIMITED|CO|INC|LNC',
                                '')) = upper(l_cust_name) THEN
        dbg('2nd step matched');
        l_match := 'Y';
      END IF;
      IF l_match = 'N' THEN
        pr_log_error(p_function_id,
                     p_source,
                     'IF-FST004',
                     l_lcl_ben_name || '~' || l_cust_name);
      END IF;

    END IF;

    dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Pre_Default_And_Validate ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_default_and_validate;

  FUNCTION fn_post_default_and_validate(p_source           IN VARCHAR2,
                                        p_source_operation IN VARCHAR2,
                                        p_function_id      IN VARCHAR2,
                                        p_action_code      IN VARCHAR2,
                                        p_child_function   IN VARCHAR2,
                                        p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                                        p_prev_ifdofast    IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                        p_wrk_ifdofast     IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                        p_err_code         IN OUT VARCHAR2,
                                        p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Post_Default_And_Validate..');

    dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Post_Default_And_Validate ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_default_and_validate;

  FUNCTION fn_pre_upload_db(p_source           IN VARCHAR2,
                            p_source_operation IN VARCHAR2,
                            p_function_id      IN VARCHAR2,
                            p_action_code      IN VARCHAR2,
                            p_child_function   IN VARCHAR2,
                            p_post_upl_stat    IN VARCHAR2,
                            p_multi_trip_id    IN VARCHAR2,
                            p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                            p_prev_ifdofast    IN ifpks_ifdofast_main.ty_ifdofast,
                            p_wrk_ifdofast     IN OUT ifpks_ifdofast_main.ty_ifdofast,
                            p_err_code         IN OUT VARCHAR2,
                            p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_KEY_ID varchar2(1000);
  BEGIN

    dbg('In Fn_Pre_Upload_Db..');

    dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Pre_Upload_Db ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_upload_db;

  FUNCTION fn_post_upload_db(p_source           IN VARCHAR2,
                             p_source_operation IN VARCHAR2,
                             p_function_id      IN VARCHAR2,
                             p_action_code      IN VARCHAR2,
                             p_child_function   IN VARCHAR2,
                             p_post_upl_stat    IN VARCHAR2,
                             p_multi_trip_id    IN VARCHAR2,
                             p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                             p_prev_ifdofast    IN ifpks_ifdofast_main.ty_ifdofast,
                             p_wrk_ifdofast     IN OUT ifpks_ifdofast_main.ty_ifdofast,
                             p_err_code         IN OUT VARCHAR2,
                             p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    l_ovd_cnt             NUMBER(1) := 0;
    l_auto_auth           VARCHAR2(1) := 'N';
    l_usd_txn_amt         NUMBER(22, 3);
    l_rate                NUMBER;
    l_prod                cstm_product%ROWTYPE;
    l_ifdofast            ifpks_ifdofast_main.ty_ifdofast;
    l_lcl_ben_name        sttm_customer.customer_name1%TYPE;
    l_cust_name           sttm_customer.customer_name1%TYPE;
    l_match               VARCHAR2(1) := 'N';
    l_detb_rtl_teller_rec detb_rtl_teller%ROWTYPE;
  BEGIN

    dbg('In Fn_Post_Upload_Db..');

    dbg('Checking for Local Auto Auth.' ||
        p_ifdofast.v_iftbs_fast_master.msg_flow || '~' ||
        p_ifdofast.v_iftbs_fast_master.transfer_mode || '~' ||
        p_ifdofast.v_iftbs_fast_master.trn_ref_no || '~' ||
        p_ifdofast.v_iftbs_fast_master.txn_ccy || '~' ||
        p_ifdofast.v_iftbs_fast_master.txn_amt);

    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdofast.v_iftbs_fast_master.product_code;

    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'I' AND
       p_ifdofast.v_iftbs_fast_master.transfer_mode = 'L' THEN
      dbg('In here USD Limit is' || get_param_val('PGW_IN_LCL_USD_LIMIT'));
      IF p_ifdofast.v_iftbs_fast_master.txn_ccy = 'USD' THEN
        IF p_ifdofast.v_iftbs_fast_master.txn_amt <=
           get_param_val('PGW_IN_LCL_USD_LIMIT') THEN
          l_auto_auth := 'Y';
        END IF;
      ELSE
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      'USD',
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      p_ifdofast.v_iftbs_fast_master.txn_amt,
                                      'Y',
                                      l_usd_txn_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;

        dbg('in here l_usd_txn_amt' || l_usd_txn_amt);
        IF l_usd_txn_amt <= get_param_val('PGW_IN_LCL_USD_LIMIT') THEN
          l_auto_auth := 'Y';
        END IF;
      END IF;

      /*BEGIN
        SELECT COUNT(1)
          INTO l_ovd_cnt
          FROM sttb_record_log t1, cstb_request_ovd_details t2
         WHERE t1.msg_id = t2.msg_id
           AND t1.key_id LIKE
               '%' || p_ifdofast.v_iftbs_fast_master.trn_ref_no || '%'
           AND t2.error_code = 'IF-FST004';
      EXCEPTION
        WHEN no_data_found THEN
          dbg('In no data found');
          l_ovd_cnt := 0;
        WHEN OTHERS THEN
          dbg('In when others');
          l_ovd_cnt := 0;
      END;
      dbg('l_ovd_cnt' || l_ovd_cnt);*/

      -- local ben name validation
      IF p_action_code IN
         (cspks_req_global.p_new, cspks_req_global.p_modify) AND
         p_ifdofast.v_iftbs_fast_master.transfer_mode = 'L' AND
         p_ifdofast.v_iftbs_fast_master.msg_flow = 'I' THEN
        dbg('In here for ben name validation' ||
            p_ifdofast.v_iftbs_fast_master.ben_name);

        l_lcl_ben_name := p_ifdofast.v_iftbs_fast_master.ben_name;

        SELECT customer_name1
          INTO l_cust_name
          FROM sttm_customer, sttm_cust_account
         WHERE customer_no = cust_no
           AND cust_ac_no = p_ifdofast.v_iftbs_fast_master.ben_acc;

        IF upper(l_lcl_ben_name) = upper(l_cust_name) THEN
          dbg('1st step matched');
          l_match := 'Y';
        ELSIF TRIM(regexp_replace(upper(l_lcl_ben_name),
                                  'LTD|LIMITED|CO|INC|LNC',
                                  '')) = upper(l_cust_name) THEN
          dbg('2nd step matched');
          l_match := 'Y';
        ELSIF TRIM(regexp_replace(upper(l_cust_name),
                                  'LTD|LIMITED|CO|INC|LNC',
                                  '')) = upper(l_lcl_ben_name) THEN
          dbg('3rd step matched');
          l_match := 'Y';
        ELSIF TRIM(regexp_replace(upper(l_lcl_ben_name),
                                  'LTD|LIMITED|CO|INC|LNC',
                                  '')) =
              TRIM(regexp_replace(upper(l_cust_name),
                                  'LTD|LIMITED|CO|INC|LNC',
                                  '')) THEN
          dbg('4th step matched');
          l_match := 'Y';
        END IF;

        IF l_match = 'N' THEN
          ovpkss.pr_appendtbl('IF-FST004',
                              l_lcl_ben_name || '~' || l_cust_name || '~');
        END IF;

      END IF;

      IF l_match = 'Y' AND l_auto_auth = 'Y' THEN
        dbg('going to do auto auth');
        UPDATE iftb_fast_master
           SET auth_stat        = 'A',
               once_auth        = 'Y',
               checker_id       = global.user_id,
               checker_dt_stamp = csfn_timestamp,
               mod_no           = 1
         WHERE trn_ref_no = p_ifdofast.v_iftbs_fast_master.trn_ref_no;

        UPDATE detb_rtl_teller
           SET auth_stat        = 'A',
               checker_id       = global.user_id,
               checker_dt_stamp = csfn_timestamp,
               record_stat      = decode(record_stat, 'O', 'A', record_stat),
               mod_no           = 1
         WHERE trn_ref_no = p_ifdofast.v_iftbs_fast_master.trn_ref_no;

        UPDATE sttb_record_log
           SET auth_stat              = 'A',
               checker_id             = global.user_id,
               checker_dt_stamp       = csfn_timestamp,
               first_auth_stat        = 'A',
               first_checker_id       = global.user_id,
               first_checker_dt_stamp = csfn_timestamp
         WHERE function_id = 'IFDOFAST'
           AND key_id LIKE
               '%' || p_ifdofast.v_iftbs_fast_master.trn_ref_no || '%';

        UPDATE sttb_record_master
           SET auth_stat              = 'A',
               checker_id             = global.user_id,
               checker_dt_stamp       = csfn_timestamp,
               first_auth_stat        = 'A',
               first_checker_id       = global.user_id,
               first_checker_dt_stamp = csfn_timestamp,
               latest_auth_mod_no     = 1
         WHERE function_id = 'IFDOFAST'
           AND key_id LIKE
               '%' || p_ifdofast.v_iftbs_fast_master.trn_ref_no || '%';

        l_ifdofast := p_ifdofast;
        IF NOT fn_process_entries(l_ifdofast, 'A', p_err_code, p_err_params) THEN
          dbg('Fail in AUTH accounting entries');
          RETURN FALSE;
        END IF;

      END IF;
    END IF;
    dbg('Out of Auto AUTH for Local Payment');

    dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Post_Upload_Db ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_upload_db;

  FUNCTION fn_pre_query(p_source           IN VARCHAR2,
                        p_source_operation IN VARCHAR2,
                        p_function_id      IN VARCHAR2,
                        p_action_code      IN VARCHAR2,
                        p_child_function   IN VARCHAR2,
                        p_full_data        IN VARCHAR2 DEFAULT 'Y',
                        p_with_lock        IN VARCHAR2 DEFAULT 'N',
                        p_qrydata_reqd     IN VARCHAR2,
                        p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                        p_wrk_ifdofast     IN OUT ifpks_ifdofast_main.ty_ifdofast,
                        p_err_code         IN OUT VARCHAR2,
                        p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Pre_Query ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_query;

  FUNCTION fn_post_query(p_source           IN VARCHAR2,
                         p_source_operation IN VARCHAR2,
                         p_function_id      IN VARCHAR2,
                         p_action_code      IN VARCHAR2,
                         p_child_function   IN VARCHAR2,
                         p_full_data        IN VARCHAR2 DEFAULT 'Y',
                         p_with_lock        IN VARCHAR2 DEFAULT 'N',
                         p_qrydata_reqd     IN VARCHAR2,
                         p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                         p_wrk_ifdofast     IN OUT ifpks_ifdofast_main.ty_ifdofast,
                         p_err_code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_csvw_retail_charge_details csvw_retail_charge_details%ROWTYPE;

  BEGIN

    dbg('In Fn_Post_Query..=' || p_action_code);

    dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When others of ifpks_ifdofast_Custom.Fn_Post_Query ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_query;

  FUNCTION FN_GET_OUTGOING_TXN_BY_ID(P_IFDOFAST        IN OUT IFPKS_IFDOFAST_MAIN.TY_IFDOFAST,
                                     P_PAYER_PART_CODE IN VARCHAR2,
                                     P_ERR_CODE        IN OUT VARCHAR2,
                                     P_ERR_PARAMS      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_BANK_CODE     CSTM_ARC_SETTLE.ROUTE_CODE%TYPE;
    L_REFERENCE_NO  VARCHAR2(100);
    L_FORMATTED_MSG CLOB;
    L_IN_RESP       CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_POS       NUMBER := 0;
    R_POS       NUMBER := 0;
    L_TXNSTATUS IFTB_FAST_MASTER.TXN_STATUS%TYPE := GET_PARAM_VAL('PGW_TEMP_TXN_STAT');
    L_TXNREASON IFTB_FAST_MASTER.TXN_REMARKS%TYPE := GET_PARAM_VAL('PGW_TEMP_TXN_REMARKS');

    L_GEN_SEQ_NO VARCHAR2(100);

  BEGIN
    DBG('************START OF FN_GET_OUTGOING_TXN_BY_ID*********');

    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

    --If already reversed then on click of this button has to be thrown an override
    IF P_IFDOFAST.V_IFTBS_FAST_MASTER.TXN_STATUS = 'ACSP' AND
       P_IFDOFAST.V_IFTBS_FAST_MASTER.MSG_FLOW = 'O' AND
       P_IFDOFAST.V_IFTBS_FAST_MASTER.TXN_REMARKS =
       'SuccessFull Acknowledgement for Refund - Customer Account has been credited back' THEN
      pr_log_error('IFDOFAST', 'FLEXCUBE', 'IF-FST011', NULL);
    END IF;

    --Get Participant Code
    SELECT ROUTE_CODE
      INTO L_BANK_CODE
      FROM CSTM_ARC_SETTLE
     WHERE PRODUCT_CODE = P_IFDOFAST.V_IFTBS_FAST_MASTER.PRODUCT_CODE
       AND AUTH_STAT = 'A'
       AND RECORD_STAT = 'O';

    --Get reference no

    L_REFERENCE_NO := SUBSTR(P_IFDOFAST.V_IFTBS_FAST_MASTER.MSG_ID, -5);

    l_formatted_msg := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fas="http://fastwebservice.nbc.org.kh/">
            <soapenv:Header/>
            <soapenv:Body>
               <fas:getOutgoingTransactionByPmtInfId>
                  <cm_user_name>' ||
                       get_param_val('PGW_OUT_FAST_UID') ||
                       '</cm_user_name>
                  <cm_password>' ||
                       get_param_val('PGW_OUT_FAST_PWD') ||
                       '</cm_password>
                  <payer_participant_code>' ||
                       l_bank_code || '</payer_participant_code>

                  <instruction_ref>' ||
                       l_reference_no || '</instruction_ref>
               </fas:getOutgoingTransactionByPmtInfId>
            </soapenv:Body>
          </soapenv:Envelope>';

    dbg('l_formatted_msg for fast' || l_formatted_msg);

    --Log Above request
    PR_INSERT_FAST_WS_LOG(P_IFDOFAST.V_IFTBS_FAST_MASTER.MSG_ID,
                          L_GEN_SEQ_NO,
                          P_IFDOFAST.V_IFTBS_FAST_MASTER.TRN_REF_NO,
                          SYSDATE,
                          'GetOutStat',
                          L_FORMATTED_MSG,
                          'O',
                          null,
                          'Get Outgoing Txn Stat');

    IF NOT FN_FAST_HTTP_CALL('F', L_FORMATTED_MSG, L_IN_RESP) THEN
      DBG('FAILED TO SEND PAIN_001_001_05');
      RAISE E_UPDATE_ERROR;
    END IF;

    DBG('SENT AND RESPONSE IS ' || L_IN_RESP);
    L_IN_RESP := FN_CLOBREPLACE(L_IN_RESP, '&lt;', '<');
    DBG('One step done-->' || L_IN_RESP);
    L_IN_RESP := FN_CLOBREPLACE(L_IN_RESP, '&gt;', '>');
    DBG('Two step done and after UNESCAPE, it is ' || L_IN_RESP);
    L_POS := DBMS_LOB.INSTR(L_IN_RESP, '<return>', 1, 1);
    DBG('l_pos is ' || L_POS);
    R_POS := DBMS_LOB.INSTR(L_IN_RESP, '</return>', 1, 1);
    DBG('r_pos is ' || R_POS);
    L_IN_RESP := TRIM(DBMS_LOB.SUBSTR(L_IN_RESP,
                                      R_POS - L_POS - LENGTH('<return>'),
                                      L_POS + LENGTH('<return>')));

    DBG('After cutting other irrelevant parts , it is ' || L_IN_RESP);

    SELECT XT.Ustrd TXSTS, XT.TXNREASON TXNREASON
      INTO L_TXNSTATUS, L_TXNREASON
      FROM XMLTABLE(XMLNAMESPACES(DEFAULT 'urn:iso:std:iso:20022:tech:xsd:pain.001.001.05'),
                    '/Document/CstmrCdtTrfInitn' PASSING XMLTYPE(L_IN_RESP)
                    COLUMNS Ustrd VARCHAR2(23) PATH
                    'PmtInf/CdtTrfTxInf/RmtInf/Ustrd',
                    TXNREASON VARCHAR2(20) PATH
                    'PmtInf/CdtTrfTxInf/RmtInf/Strd/AddtlRmtInf') XT;
    DBG('L_TXNSTATUS is ' || L_TXNSTATUS);
    DBG('L_TXNREASON is ' || L_TXNREASON);

    --Log Above Response
    PR_UPDATE_FAST_WS_LOG(P_IFDOFAST.V_IFTBS_FAST_MASTER.MSG_ID,
                          L_GEN_SEQ_NO,
                          L_TXNSTATUS,
                          L_IN_RESP);

    --Updating Status in the master table
    P_IFDOFAST.V_IFTBS_FAST_MASTER.TXN_STATUS  := L_TXNSTATUS;
    P_IFDOFAST.V_IFTBS_FAST_MASTER.TXN_REMARKS := FN_GET_FAST_OUT_STATUS(L_TXNSTATUS);
    PR_UPDATE_STATUS_FAST_OUTGOING(P_IFDOFAST.V_IFTBS_FAST_MASTER.TRN_REF_NO,
                                   L_TXNSTATUS);

    DBG('SUCCESSFULLY PROCESSED FN_GET_OUTGOING_TXN_BY_ID');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in FN_GET_OUTGOING_TXN_BY_ID' ||
          SQLERRM);
      RETURN FALSE;

  END FN_GET_OUTGOING_TXN_BY_ID;

  FUNCTION FN_RETURN_ACCOUNT_ENQUIRY(P_IFDOFAST        IN OUT IFPKS_IFDOFAST_MAIN.TY_IFDOFAST,
                                     P_PAYER_PART_CODE IN VARCHAR2,
                                     P_ERR_CODE        IN OUT VARCHAR2,
                                     P_ERR_PARAMS      IN OUT VARCHAR2)
    RETURN CLOB IS
    L_FORMATTED_MSG CLOB;
    L_BANK_CODE     CSTM_ARC_SETTLE.ROUTE_CODE%TYPE;
  BEGIN
    DBG('SATRT OF FN_RETURN_ACCOUNT_ENQUIRY');

    --Get Participant Code
    SELECT ROUTE_CODE
      INTO L_BANK_CODE
      FROM CSTM_ARC_SETTLE
     WHERE PRODUCT_CODE = P_IFDOFAST.V_IFTBS_FAST_MASTER.PRODUCT_CODE
       AND AUTH_STAT = 'A'
       AND RECORD_STAT = 'O';

    L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fas="http://fastwebservice.nbc.org.kh/">
   <soapenv:Header/>
   <soapenv:Body>
      <fas:getAccountInquiry>
         <cm_user_name>' ||
                       GET_PARAM_VAL('PGW_OUT_FAST_UID') ||
                       '</cm_user_name>
         <cm_password>' ||
                       GET_PARAM_VAL('PGW_OUT_FAST_PWD') ||
                       '</cm_password>
         <participant_code>' || L_BANK_CODE ||
                       '</participant_code>
      </fas:getAccountInquiry>
   </soapenv:Body>
</soapenv:Envelope>';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_ACCOUNT_ENQUIRY');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_ACCOUNT_ENQUIRY');
      DBG('ERROR CODE IN FN_RETURN_ACCOUNT_ENQUIRY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_ACCOUNT_ENQUIRY=' || SQLERRM);
  END FN_RETURN_ACCOUNT_ENQUIRY;

  PROCEDURE PR_PRINT_ACCTNG_TABLE(P_ACC_HAND IN ACPKS.TBL_ACHOFF) IS
    I      NUMBER;
    L_ROW  VARCHAR2(500);
    L_LINE VARCHAR2(500);
  BEGIN

    SELECT RPAD('-',
                20 + 15 + 15 + 15 + 15 + 1 + 1 + 3 + 3 + 3 + 6 + 3,
                '-')
      INTO L_LINE
      FROM DUAL;
    DBG(L_LINE);
    SELECT '|' || RPAD('Tag', 10, '.') || '|' || RPAD('Brn', 3, '.') || '|' ||
           RPAD('Acc', 20, '.') || '|' || RPAD('Lcy Amt', 15, '.') || '|' ||
           RPAD('Fcy Amt', 15, '.') || '|' || RPAD('Exch Rate', 15, '.') || '|' ||
           RPAD('D/C', 1, '.') || '|' || RPAD('Netting', 1, '.') || '|' ||
           RPAD('Ccy', 3, '.') || '|' || RPAD('TrnCode', 3, '.') || '|' ||
           RPAD('Brn', 3, '.') || '|'
      INTO L_ROW
      FROM DUAL;
    DBG(L_ROW);
    DBG(L_LINE);

    FOR I IN 1 .. P_ACC_HAND.COUNT LOOP
      IF P_ACC_HAND.EXISTS(I) THEN
        SELECT '|' || RPAD(P_ACC_HAND(I).AMOUNT_TAG, 10, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_BRANCH, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_NO, 20, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).LCY_AMOUNT, -1111), 15, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).FCY_AMOUNT, -1111), 15, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).EXCH_RATE, -1111), 15, '.') || '|' ||
               RPAD(P_ACC_HAND(I).DRCR_IND, 1, '.') || '|' ||
               RPAD(P_ACC_HAND(I).NETTING_IND, 1, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_CCY, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).TRN_CODE, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_BRANCH, 3, '.') || '|'
          INTO L_ROW
          FROM DUAL;
        DBG(L_ROW);
        DBG(L_LINE);
      END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN;
  END PR_PRINT_ACCTNG_TABLE;

  PROCEDURE PR_CHARGE_REVERSAL(P_AC_ENTS IN OUT NOCOPY ACPKS.TBL_ACHOFF) IS

    L_INDEX       NUMBER;
    L_REV_REQD    VARCHAR2(1);
    L_NET_CHARGES VARCHAR2(1);
    L_CHG_FROM    VARCHAR2(3);
    L_AMT_SUM     NUMBER;
    L_CONTRA_LEG  NUMBER;
    L_PROD        VARCHAR2(4);

    L_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM VARCHAR2(250);

  BEGIN

    DBG('inside pr_chrge_reversal with product as ');

    BEGIN
      SELECT PRODUCT_CODE
        INTO L_PROD
        FROM DETB_RTL_TELLER
       WHERE TRN_REF_NO = P_AC_ENTS(1).TRN_REF_NO;

      DBG('Calling Fn_Get_Detm_Rt_Pref_Rec_Wrp...for the product...' ||
          L_PROD);
      IF NOT
          CSPKSS_FUNCTION_CACHE.FN_GET_DETM_RT_PREF_REC_WRP(L_PROD,
                                                            L_ERR_CODE,
                                                            L_ERR_PARAM) THEN
        IF L_ERR_CODE = 'CS-FRC-001' THEN
          DBG('No data Found exception so assignin value as Y ..');
          L_REV_REQD  := 'Y';
          L_ERR_CODE  := NULL;
          L_ERR_PARAM := NULL;
        ELSE
          DBG('In others exception..');
          L_ERR_CODE  := NULL;
          L_ERR_PARAM := NULL;
          DBG('Proceed..');
        END IF;
      ELSE
        L_REV_REQD := NVL(CSPKSS_FUNCTION_CACHE.G_TBL_DETM_RT_PREF_REC.REVERSAL_INCLUDES_CHARGES,
                          'N');
        DBG('Value of l_rev_reqd is - ' || L_REV_REQD);
      END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_REV_REQD := 'Y';
      WHEN OTHERS THEN
        DBG('Failed while checking if charge reversal is required');

    END;

    DBG('GWPKS_UTIL.G_REJECTFLAG => ' || GWPKS_UTIL.G_REJECTFLAG);

    IF L_REV_REQD = 'N' OR NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' THEN
      BEGIN
        SELECT NVL(COD_NET_CHARGES, 'Y')
          INTO L_NET_CHARGES
          FROM IFTMS_ARC_MAINT
         WHERE COD_PROD_ACC_CLS = L_PROD;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_NET_CHARGES := 'N';
        WHEN OTHERS THEN
          DBG('Failed while checking if charge netting is required');

      END;
      DBG('l_net_charges => ' || L_NET_CHARGES);
      IF L_NET_CHARGES = 'Y' THEN
        BEGIN

          SELECT CHG_CONTRA_LEG
            INTO L_CHG_FROM
            FROM DETBS_RTL_TELLER
           WHERE TRN_REF_NO = P_AC_ENTS(1).TRN_REF_NO;

        END;
        L_AMT_SUM := 0;

        IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
          DBG('INSIDE THE LOOP TO FETCH THE CHARGES');
          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF P_AC_ENTS(L_INDEX)
             .AMOUNT_TAG IN
                ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
              DBG('l_index ' || L_INDEX);
              DBG('p_ac_ents(l_index).AMOUNT_TAG => ' || P_AC_ENTS(L_INDEX)
                  .AMOUNT_TAG);
              L_AMT_SUM := L_AMT_SUM + P_AC_ENTS(L_INDEX).LCY_AMOUNT;
            END IF;

          END LOOP;
          DBG('OUT OF THE LOOP WITH l_amt_sum :- ' || L_AMT_SUM);

        ELSE

          DBG('INSIDE THE ELSE PART');
          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF P_AC_ENTS(L_INDEX)
             .AMOUNT_TAG IN ('CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
              L_AMT_SUM := L_AMT_SUM + P_AC_ENTS(L_INDEX).LCY_AMOUNT;
            END IF;

          END LOOP;

        END IF;

        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
          IF P_AC_ENTS(L_INDEX).AMOUNT_TAG = (L_CHG_FROM || '_AMT') THEN
            P_AC_ENTS(L_INDEX).LCY_AMOUNT := P_AC_ENTS(L_INDEX)
                                             .LCY_AMOUNT - L_AMT_SUM;
          END IF;
        END LOOP;

      END IF;

      IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
        DBG('GOING FOR THE LOOP TO DLETE THE CHARGE ENTRIES');

        BEGIN
          DBG('pr_print_acctng_table is cmd in begin.....');
          PR_PRINT_ACCTNG_TABLE(P_AC_ENTS);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In OTHERS with line tracking  ::::: ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        END;

        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
          IF P_AC_ENTS(L_INDEX)
           .AMOUNT_TAG IN
              ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
            DBG('l_index ' || L_INDEX);
            DBG('p_ac_ents(l_index).AMOUNT_TAG => ' || P_AC_ENTS(L_INDEX)
                .AMOUNT_TAG);
            P_AC_ENTS.DELETE(L_INDEX);
          END IF;
        END LOOP;
        DBG('OUT OF LOOP');

        IF (P_AC_ENTS.COUNT > 2) AND GWPKS_UTIL.PKG_FUNC = 'LOCH' THEN

          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF L_INDEX > 2 THEN
              DBG('Removing the other entries when l_index for reject is ' ||
                  L_INDEX);
              P_AC_ENTS.DELETE(L_INDEX);
            END IF;
          END LOOP;
        END IF;

      ELSE

        /*--sampath starts
        dbg('before deleting charge entries=' || P_AC_ENTS.COUNT);
        dbg('before deleting charge FIRST=' || P_AC_ENTS.FIRST);
        dbg('before deleting charge LAST=' || P_AC_ENTS.LAST);

        FOR L_RECNO1 IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP

          DBG('P_AC_ENTS(L_RECNO1).AC_ENTRY_SR_NO=' || P_AC_ENTS(L_RECNO1)
              .AC_ENTRY_SR_NO);

          DBG('P_AC_ENTS(L_RECNO1).EVENT_SR_NO=' || P_AC_ENTS(L_RECNO1)
              .EVENT_SR_NO);

          DBG('P_AC_ENTS(L_RECNO1).EVENT=' || P_AC_ENTS(L_RECNO1).EVENT);
          DBG('P_AC_ENTS(L_RECNO1).FCY_AMOUNT=' || P_AC_ENTS(L_RECNO1)
              .FCY_AMOUNT);
          DBG('P_AC_ENTS(L_RECNO1).LCY_AMOUNT=' || P_AC_ENTS(L_RECNO1)
              .LCY_AMOUNT);
          DBG('P_AC_ENTS(L_RECNO1).TRN_DT=' || P_AC_ENTS(L_RECNO1).TRN_DT);
          DBG('P_AC_ENTS(L_RECNO1).USER_ID=' || P_AC_ENTS(L_RECNO1)
              .USER_ID);

          DBG('P_AC_ENTS(L_RECNO1).AMOUNT_TAG=' || P_AC_ENTS(L_RECNO1)
              .AMOUNT_TAG);

          DBG('P_AC_ENTS(L_RECNO1).AC_BRANCH=' || P_AC_ENTS(L_RECNO1)
              .AC_BRANCH);

        END LOOP;
        --sampath ends*/

        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP

          IF P_AC_ENTS(L_INDEX)
           .AMOUNT_TAG IN ('CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
            P_AC_ENTS.DELETE(L_INDEX);

          END IF;
        END LOOP;

        /*--sampath starts
        dbg('after deleting charge entries=' || P_AC_ENTS.COUNT);
        dbg('after deleting charge FIRST=' || P_AC_ENTS.FIRST);
        dbg('after deleting charge LAST=' || P_AC_ENTS.LAST);

        FOR L_RECNO1 IN P_AC_ENTS.FIRST .. P_AC_ENTS.COUNT LOOP
          DBG('L_RECNO1='||L_RECNO1);
          DBG('P_AC_ENTS(L_RECNO1).EVENT=' || P_AC_ENTS(L_RECNO1).EVENT);

          DBG('P_AC_ENTS(L_RECNO1).LCY_AMOUNT=' || P_AC_ENTS(L_RECNO1)
              .LCY_AMOUNT);
          DBG('P_AC_ENTS(L_RECNO1).TRN_DT=' || P_AC_ENTS(L_RECNO1).TRN_DT);

          DBG('P_AC_ENTS(L_RECNO1).AMOUNT_TAG=' || P_AC_ENTS(L_RECNO1)
              .AMOUNT_TAG);

          DBG('P_AC_ENTS(L_RECNO1).AC_BRANCH=' || P_AC_ENTS(L_RECNO1)
              .AC_BRANCH);

        END LOOP;
        --sampath ends*/

      END IF;
    END IF;

  END PR_CHARGE_REVERSAL;

  PROCEDURE PR_UPDATE_TRACKED_BALANCES(P_CONTRACT_REF_NO IN CSTB_CONTRACT.CONTRACT_REF_NO%TYPE) IS

    CURSOR CR_UPDATE_BALANCES IS
      SELECT *
        FROM CSTB_AUTO_SETTLE_BLOCK
       WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO
         AND AMOUNT_DUE != AMOUNT_PAID;
    L_AMOUNT_TO_BE_RELEASED NUMBER(22, 3) := 0;

  BEGIN

    FOR REC IN CR_UPDATE_BALANCES LOOP

      L_AMOUNT_TO_BE_RELEASED := REC.AMOUNT_AVAILABLE;

      DBG('account is :::: ' || REC.ACCOUNT_NO);

      DBG('L_AMOUNT_TO_BE_RELEASED is :::: ' || L_AMOUNT_TO_BE_RELEASED);

      ACPKS_CUSTBAL_PROCESS.PR_UPDATE_RECEIVABLE_AMT(REC.ACCOUNT_NO,
                                                     REC.ACCOUNT_BR,
                                                     'D',
                                                     L_AMOUNT_TO_BE_RELEASED);
      DEBUG.PR_DEBUG('LD', 'after updating recievable');

    END LOOP;

    INSERT INTO CSTB_AUTO_SETTLE_BLOCK_TEMP
      (SELECT *
         FROM CSTB_AUTO_SETTLE_BLOCK
        WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO);

    DBG('umber of rows iserted IN TEMP are :::: ' || SQL%ROWCOUNT);
    DELETE CSTB_AUTO_SETTLE_BLOCK
     WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO;

  END;

  FUNCTION FN_REVERSE(P_TRN_REF_NO IN VARCHAR2,
                      P_ERR_CODE   IN OUT VARCHAR2,
                      P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_AUTH_STAT        DETBS_RTL_TELLER.AUTH_STAT%TYPE;
    L_AC_ENTS          ACPKS.TBL_ACHOFF;
    L_ROWID            ROWID;
    L_AUTHORISE        VARCHAR2(1);
    L_CHECKER_DT_STAMP DATE;
    L_TRACK_RECEIVABLE VARCHAR2(1);
    L_SCODE            DETBS_RTL_TELLER.SCODE%TYPE;
    L_CHECK_ENTRIES    BOOLEAN := TRUE;
    L_SETTLE_COUNT     NUMBER := 0;
    L_ON_ERROR         BOOLEAN := FALSE;
    L_BOOK_DATE        DATE;

    L_ACC_TYPE_1   VARCHAR2(20);
    L_ACC_TYPE_2   VARCHAR2(20);
    L_BRANCH       DETBS_RTL_TELLER.BRANCH_CODE%TYPE;
    L_PRODUCT_CODE DETBS_RTL_TELLER.PRODUCT_CODE%TYPE;
    L_MODULE       CSTM_PRODUCT.MODULE%TYPE;
    V_TBL_RESTR    STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR;
    L_EVENT_CODE   DETB_RTL_TELLER.EVENT_CODE%TYPE;
    L_TRN_DATE     DETB_RTL_TELLER.TRN_DT%TYPE;
    L_PRDGRP       CSTM_PRODUCT.PRODUCT_GROUP%TYPE;
    L_DETB_ROW     DETB_RTL_TELLER%ROWTYPE;
    L_REV_UTIL     NUMBER := 0;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DBG('Inside the fn_reverse OF Depks_Rtl_Teller PACKAGE...');
    SAVEPOINT RTL_REVERSE;
    DBG('Issued savepoint rtl reverse');
    BEGIN
      SELECT AUTH_STAT, ROWID, NVL(SCODE, '*')
        INTO L_AUTH_STAT, L_ROWID, L_SCODE
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
            P_TRN_REF_NO || '~' || SQLERRM);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;

    BEGIN
      SELECT NVL(TRACK_RECEIVABLE, 'N')
        INTO L_TRACK_RECEIVABLE
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed while selecting track_receivable from detb_rtl_teller with -->' ||
            SQLERRM);
        DBG('Txn Ref No is --->' || P_TRN_REF_NO);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;

    BEGIN
      DBG('Initial value of l_settle_count ' || L_SETTLE_COUNT);
      DBG('Query to get record count from cstb_auto_settle_block');
      SELECT COUNT(*)
        INTO L_SETTLE_COUNT
        FROM CSTB_AUTO_SETTLE_BLOCK
       WHERE CONTRACT_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found for the record.. cstb_auto_settle_block ');
        L_SETTLE_COUNT := 0;
      WHEN OTHERS THEN
        DBG('Failed while selecting entries from cstb_auto_settle_block with -->' ||
            SQLERRM);
        DBG('contract_ref_no --->' || P_TRN_REF_NO);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;
    DBG('l_settle_count ' || L_SETTLE_COUNT);

    IF L_AUTH_STAT = 'A' OR L_AUTH_STAT IS NULL THEN
      DBG('Proceeding for Reversal with l_auth_stat  ' || L_AUTH_STAT ||
          ' and l_settle_count ' || L_SETTLE_COUNT);

      DBG('Cspks_Req_Global.g_Release_Type :::: ' ||
          CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('p_trn_ref_no while calling depks_rtl_teller_cluster.fn_reverse ::::: ' ||
            P_TRN_REF_NO);
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 1;

        IF L_CHECK_ENTRIES THEN
          L_TB_CLUSTER_DATA('l_check_entries') := 'T';
        ELSE
          L_TB_CLUSTER_DATA('l_check_entries') := 'F';
        END IF;

        IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_REVERSE(P_TRN_REF_NO,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM,
                                                   L_FN_CALL_ID,
                                                   L_TB_CLUSTER_DATA) THEN
          DBG('Failed inside depks_rtl_teller_cluster.Fn_Save');
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          RETURN FALSE;
        END IF;

        IF L_TB_CLUSTER_DATA.EXISTS('l_check_entries') THEN
          IF L_TB_CLUSTER_DATA('l_check_entries') = 'T' THEN
            L_CHECK_ENTRIES := TRUE;
          ELSE
            L_CHECK_ENTRIES := FALSE;
          END IF;
        END IF;

      END IF;

      IF L_SETTLE_COUNT > 0 THEN
        DBG('Before Validation For Same Day Reversal ');
        BEGIN
          SELECT BOOK_DATE
            INTO L_BOOK_DATE
            FROM CSTB_AUTO_SETTLE_BLOCK
           WHERE CONTRACT_REF_NO = P_TRN_REF_NO
             AND ROWNUM = 1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found for the record.. cstb_auto_settle_block ');
            L_BOOK_DATE := NULL;
          WHEN OTHERS THEN
            DBG('Failed while selecting BOOK_DATE from cstb_auto_settle_block with -->' ||
                SQLERRM);
            DBG('contract_ref_no --->' || P_TRN_REF_NO);
            P_ERR_CODE := 'DE-TUD-002';
            ROLLBACK TO RTL_REVERSE;
            RETURN FALSE;
        END;
        DBG('l_BOOK_DATE ' || L_BOOK_DATE);

        IF L_BOOK_DATE <> GLOBAL.APPLICATION_DATE THEN
          DBG('For Tracked Transaction Only same date Reversal is Allwoed.');
          P_ERR_CODE := 'DE-TUD-946';
          ROLLBACK TO RTL_REVERSE;
          RETURN FALSE;
        END IF;
      END IF;

      IF GWPKS_UTIL.G_FROM_BEAN OR L_SCODE = 'FLEXSWITCH' THEN
        DEPKS_RTL_TELLER.PR_AUTH_REVERSAL_REQD(TRUE);
      END IF;
      IF DEPKS_RTL_TELLER.PKG_AUTH_REVERSAL_REQD THEN

        L_AUTHORISE := 'B';
      ELSE
        L_AUTHORISE := 'U';
      END IF;
      DBG('Getting a/c entries BY calling Acpks.fn_acEntry_Retrieval...');

      IF NVL(GWPKS_UTIL.G_TWOSTEPPROCESS, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.G_BRNNEWFLOW, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.G_FIRSTSTEPDONE, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1401' AND
         NVL(GWPKS_UTIL.G_TWOSTEPPROCESSNO, '1') = '1' THEN
        L_CHECK_ENTRIES := FALSE;
      END IF;
      DBG('after setting check entries.');
      IF L_CHECK_ENTRIES THEN
        DBG(' going to check for entries .');

        IF ACPKS_CUSTOM.FN_ACENTRY_RETRIEVAL_CUSTOM(P_TRN_REF_NO,
                                                    1,
                                                    L_AC_ENTS) > 0 THEN
          DBG('Doing the actual reversal...');

          IF L_TRACK_RECEIVABLE = 'Y' OR L_SETTLE_COUNT > 0 THEN

            IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'N' THEN
              DBG(' Before Call to pr_update_tracked_balances ');
              PR_UPDATE_TRACKED_BALANCES(P_TRN_REF_NO);
            END IF;
            DBG('After Call to pr_update_tracked_balances ');
          END IF;

          PR_CHARGE_REVERSAL(L_AC_ENTS);

          DBG('L_AC_ENTS.COUNT=' || L_AC_ENTS.COUNT);

          FOR L_RECNO IN L_AC_ENTS.FIRST .. L_AC_ENTS.LAST LOOP
            L_AC_ENTS(L_RECNO).EVENT_SR_NO := 2;
            L_AC_ENTS(L_RECNO).EVENT := 'REVR';
            L_AC_ENTS(L_RECNO).FCY_AMOUNT := L_AC_ENTS(L_RECNO)
                                             .FCY_AMOUNT * -1;
            L_AC_ENTS(L_RECNO).LCY_AMOUNT := L_AC_ENTS(L_RECNO)
                                             .LCY_AMOUNT * -1;

            DBG('gwpks_util.g_branch_date:::' || GWPKS_UTIL.G_BRANCH_DATE);
            DBG('global.application_date:::' || GLOBAL.APPLICATION_DATE);
            IF GWPKS_UTIL.G_BRANCH_DATE > GLOBAL.APPLICATION_DATE AND
               GWPKS_UTIL.G_FROM_BEAN THEN
              L_AC_ENTS(L_RECNO).TRN_DT := GWPKS_UTIL.G_BRANCH_DATE;
            ELSE
              L_AC_ENTS(L_RECNO).TRN_DT := GLOBAL.APPLICATION_DATE;
            END IF;

            L_AC_ENTS(L_RECNO).USER_ID := NVL(L_AC_ENTS(L_RECNO).USER_ID,
                                              GLOBAL.USER_ID);

            IF NOT GWPKS_UTIL.G_FROM_BEAN THEN

              L_AC_ENTS(L_RECNO).TRN_DT := GLOBAL.APPLICATION_DATE;
            END IF;

            L_AC_ENTS(L_RECNO).USER_ID := NVL(L_AC_ENTS(L_RECNO).USER_ID,
                                              GLOBAL.USER_ID);
          END LOOP;
          IF CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
            DBG('Setting l_auth_stat as B since g_auto_ac_closure is true ...');
            L_AUTH_STAT := 'B';
          END IF;
          DBG('Putting back the reversal entries BY calling Acpks.fn_achandoff...');

          IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
            L_AUTHORISE := 'B';
            DBG('THE ACTION CODE FLAG IS FORCEFULLY SET TO B ' ||
                L_AUTHORISE);
          END IF;

          IF NOT ACPKS.FN_ACHANDOFF(P_TRN_REF_NO,
                                    2,
                                    GLOBAL.APPLICATION_DATE,
                                    L_AC_ENTS,
                                    L_AUTHORISE,
                                    'N',
                                    'Y',
                                    GLOBAL.USER_ID,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
            DBG('Failed IN Acpks.fn_achandoff OF fn_reversal IN Depks_Rtl_Teller...');
            DBG('Rolling back to savepoint rtl reverse');
            ROLLBACK TO RTL_REVERSE;
            RETURN FALSE;
          END IF;

          DBG('Cspks_Req_Global.g_Release_Type :::: ' ||
              CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            DBG('p_trn_ref_no while calling depks_rtl_teller_cluster.fn_reverse ::::: ' ||
                P_TRN_REF_NO);
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_FN_CALL_ID      := 1;
            IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_REVERSE(P_TRN_REF_NO,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
              DBG('Failed inside depks_rtl_teller_cluster.Fn_Save');
              DBG('Rolling back to savepoint rtl reverse');
              ROLLBACK TO RTL_REVERSE;
              RETURN FALSE;
            END IF;
          END IF;

        ELSE
          DBG('No entries corresponding TO this p_trn_ref_no IN actb_daily_log...');
          DBG('Rolling back to savepoint rtl reverse');
          ROLLBACK TO RTL_REVERSE;
          RETURN FALSE;
        END IF;

        BEGIN
          SELECT COUNT(*)
            INTO L_REV_UTIL
            FROM STTB_CUST_LIMIT_TRACKING
           WHERE CONTRACT_REF_NO = P_TRN_REF_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
                P_TRN_REF_NO || '~' || SQLERRM);
        END;

        IF L_REV_UTIL > 0 THEN
          BEGIN
            SELECT BRANCH_CODE, PRODUCT_CODE
              INTO L_BRANCH, L_PRODUCT_CODE
              FROM DETBS_RTL_TELLER
             WHERE TRN_REF_NO = P_TRN_REF_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
                  P_TRN_REF_NO || '~' || SQLERRM);
              P_ERR_CODE := 'DE-TUD-002';
              ROLLBACK TO RTL_REVERSE;
              RETURN FALSE;
          END;

          SELECT MODULE, PRODUCT_GROUP
            INTO L_MODULE, L_PRDGRP
            FROM CSTM_PRODUCT
           WHERE PRODUCT_CODE = L_PRODUCT_CODE;

          DBG('l_module' || L_MODULE);

          IF NOT
              STPKS_CUST_RESTR_UTIL_TRACK.FN_PROCESS_CHK_LIMIT(L_SCODE,
                                                               L_MODULE,
                                                               L_BRANCH,
                                                               P_TRN_REF_NO,
                                                               NULL,
                                                               NULL,
                                                               L_EVENT_CODE,
                                                               1,
                                                               L_PRDGRP,
                                                               L_TRN_DATE,
                                                               NULL,
                                                               '',
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               'D',
                                                               V_TBL_RESTR,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAM) THEN
            DBG('error Code' || P_ERR_CODE);
            DBG('error params' || P_ERR_PARAM);
          ELSE
            DBG('NTHNG');
          END IF;
        END IF;

      END IF;
    ELSE

      IF L_SETTLE_COUNT > 0 THEN
        DBG('Cannot proceed to reversal with l_settle_count ' ||
            L_SETTLE_COUNT);
        DBG('This TRANSACTION is NSF tracked Hence cannot be reversed...');
        L_ON_ERROR := TRUE;
      ELSE
        DBG('This TRANSACTION IS unauthorised AND can NOT be reversed...');
        L_ON_ERROR := TRUE;
      END IF;

    END IF;

    IF L_ON_ERROR THEN
      DBG('Reversal cannot be processed ');
      DBG('contract_ref_no --->' || P_TRN_REF_NO);
      P_ERR_CODE := 'DE-TUD-945';
      DBG('Rolling back to savepoint rtl reverse');
      ROLLBACK TO RTL_REVERSE;
      RETURN FALSE;
    END IF;

    DBG('Now UPDATING the Record_stat OF detbs_rtl_teller FOR the trn_ref_no...' ||
        P_TRN_REF_NO);

    IF L_AUTHORISE = 'B' THEN
      L_CHECKER_DT_STAMP := FN_SYSDATE;
      L_CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE +
                            (L_CHECKER_DT_STAMP - TRUNC(L_CHECKER_DT_STAMP));
      DBG('Checker date stamp is' || L_CHECKER_DT_STAMP);
      UPDATE DETBS_RTL_TELLER
         SET RECORD_STAT      = 'V',
             AUTH_STAT        = 'A',
             CHECKER_ID       = NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID),
             CHECKER_DT_STAMP = L_CHECKER_DT_STAMP,

             REVR_DT = GLOBAL.APPLICATION_DATE

       WHERE ROWID = L_ROWID;
    ELSE

      UPDATE DETBS_RTL_TELLER
         SET RECORD_STAT      = 'V',
             AUTH_STAT        = 'U',
             CHECKER_ID       = NULL,
             CHECKER_DT_STAMP = NULL

            ,
             REVR_DT = GLOBAL.APPLICATION_DATE

       WHERE ROWID = L_ROWID;

    END IF;
    DBG('RECORD stat IS updated FOR the trn_ref_no IN detbs_rtl_teller...' ||
        P_TRN_REF_NO);
    RETURN TRUE;
  END FN_REVERSE;

  PROCEDURE PR_REVERSE_FAST_OUT_TXN(P_DOCUMENT_XML IN XMLTYPE) IS

    /*CURSOR C1 IS
    SELECT *
      FROM IFTB_FAST_MASTER
     WHERE TXN_STATUS = 'RCFI'
       AND MSG_FLOW = 'O'
       AND AUTH_STAT = 'A'
       AND RECORD_STAT = 'O';*/
    L_ADDL_RMT_INFO VARCHAR2(255);
    L_INSTR_ID      IFTBS_FAST_MASTER.INSTR_ID%TYPE;
    L_TRN_REF_NO    IFTBS_FAST_MASTER.TRN_REF_NO%TYPE;
    L_MSG_ID        IFTBS_FAST_MASTER.MSG_ID%TYPE;
    L_CREDTTM       VARCHAR2(100);
    L_NBOFTXS       CHAR(1);
    L_CTRLSUM       VARCHAR2(100);
    L_INITGPTY_NM   VARCHAR2(100);

    L_PMTINFID      VARCHAR2(100);
    L_PMTMTD        VARCHAR2(100);
    L_BTCHBOOKG     VARCHAR2(100);
    L_REQDEXCTNDT   VARCHAR2(100);
    L_DBTR_NM       IFTBS_FAST_MASTER.REM_NAME%TYPE;
    L_DBTRACCT_NO   IFTBS_FAST_MASTER.REM_ACC%TYPE;
    L_DBTRACCT_CCY  IFTBS_FAST_MASTER.TXN_CCY%TYPE;
    L_DBTRAGT_BICFI IFTBS_FAST_MASTER.BEN_BIC%TYPE;
    L_INSTRID       IFTBS_FAST_MASTER.INSTR_ID%TYPE;
    L_ENDTOENDID    IFTBS_FAST_MASTER.ETEND_ID%TYPE;
    L_AMT           IFTBS_FAST_MASTER.TXN_AMT%TYPE;

    L_CHRGBR        VARCHAR2(100);
    L_CRTRAGT_BICFI IFTBS_FAST_MASTER.BEN_BIC%TYPE;
    L_CDTR_NM       IFTBS_FAST_MASTER.BEN_NAME%TYPE;
    L_CDTRACCT_NO   IFTBS_FAST_MASTER.BEN_ACC%TYPE;
    L_PURP          IFTBS_FAST_MASTER.TXN_REMARKS%TYPE;

    L_FORMATTED_MSG    CLOB;
    L_IN_RESP          CLOB;
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML1    XMLTYPE;
    L_TXN_STATUS       VARCHAR2(10);

    P_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    P_ERR_PARAM ERTB_MSGS.MESSAGE%TYPE;

    L_GEN_SEQ_NO VARCHAR2(100);

  BEGIN

    DEBUG.PR_DEBUG('IF', 'START OF PR_REVERSE_FAST_OUT_TXN');

    SAVEPOINT REVERSE_POINT;

    P_DOCUMENT_XML1 := P_DOCUMENT_XML;

    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

    /*FOR G IN C1 LOOP

      GLOBAL.PR_INIT(G.BRANCH_CODE, 'SYSTEM');

      DBG('I AM REVERSING REFERENCE NO:' || G.TRN_REF_NO);

      IF NOT
          DEPKS_RTL_TELLER.FN_REVERSE(G.TRN_REF_NO, P_ERR_CODE, P_ERR_PARAM) THEN

        DBG('FAILED IN REVERSING THE FAST OUTGOING TRANSACTION');
        DBG('P_ERR_CODE=' || P_ERR_CODE);
        DBG('P_ERR_PARAM=' || P_ERR_PARAM);

      ELSE
        DBG('SUCCESS IN REVERSING THE FAST OUTGOING TRANSACTION');
      END IF;

    --Need to make Ack webservicall call which is pending

    END LOOP;*/

    L_ADDL_RMT_INFO := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/RmtInf/Strd/AddtlRmtInf/text()')
                       .GETSTRINGVAL;
    L_INSTR_ID      := SUBSTR(SUBSTR(L_ADDL_RMT_INFO,
                                     1,
                                     INSTR(L_ADDL_RMT_INFO, '/') - 1),
                              10 + 1);

    BEGIN
      SELECT TRN_REF_NO
        INTO L_TRN_REF_NO
        FROM IFTB_FAST_MASTER
       WHERE MSG_ID = 'PINCKHPPXXXX' || L_INSTR_ID;
    EXCEPTION
      WHEN OTHERS THEN
        L_TRN_REF_NO := NULL;
    END;

    DBG('I AM REVERSING REFERENCE NO:' || L_TRN_REF_NO);

    IF L_TRN_REF_NO IS NOT NULL THEN

      IF NOT FN_REVERSE(L_TRN_REF_NO, P_ERR_CODE, P_ERR_PARAM) THEN

        DBG('FAILED IN REVERSING THE FAST OUTGOING TRANSACTION');
        DBG('P_ERR_CODE=' || P_ERR_CODE);
        DBG('P_ERR_PARAM=' || P_ERR_PARAM);

        ROLLBACK TO REVERSE_POINT;

      ELSE
        DBG('SUCCESS IN REVERSING THE FAST OUTGOING TRANSACTION');
        IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(GLOBAL.CURRENT_BRANCH,
                                                    L_TRN_REF_NO,
                                                    GLOBAL.USER_ID,
                                                    GLOBAL.LCY,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM) THEN
          DBG('AUTH RETURNED FALSE ' || P_ERR_CODE);
          ROLLBACK TO REVERSE_POINT;
          --RETURN FALSE;
        ELSE
          --Get All tag values

          L_MSG_ID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/MsgId/text()')
                      .GETSTRINGVAL;
          DBG('L_MSG_ID=' || L_MSG_ID);

          L_CREDTTM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/CreDtTm/text()')
                       .GETSTRINGVAL;
          DBG('L_CreDtTm=' || L_CreDtTm);

          L_NBOFTXS := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/NbOfTxs/text()')
                       .GETSTRINGVAL;
          DBG('L_NbOfTxs=' || L_NbOfTxs);

          L_CTRLSUM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/CtrlSum/text()')
                       .GETSTRINGVAL;
          DBG('L_CTRLSUM=' || L_CTRLSUM);

          L_INITGPTY_NM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/GrpHdr/InitgPty/Nm/text()')
                           .GETSTRINGVAL;
          DBG('L_INITGPTY_NM=' || L_INITGPTY_NM);

          L_PMTINFID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/PmtInfId/text()')
                        .GETSTRINGVAL;
          DBG('L_PMTINFID=' || L_PMTINFID);

          L_PMTMTD := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/PmtMtd/text()')
                      .GETSTRINGVAL;
          DBG('L_PMTMTD=' || L_PMTMTD);

          L_BTCHBOOKG := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/BtchBookg/text()')
                         .GETSTRINGVAL;
          DBG('L_BTCHBOOKG=' || L_BTCHBOOKG);

          L_REQDEXCTNDT := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/ReqdExctnDt/text()')
                           .GETSTRINGVAL;
          DBG('L_REQDEXCTNDT=' || L_REQDEXCTNDT);

          L_DBTR_NM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/Dbtr/Nm/text()')
                       .GETSTRINGVAL;
          DBG('L_DBTR_NM=' || L_DBTR_NM);

          L_DBTRACCT_NO := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/DbtrAcct/Id/Othr/Id/text()')
                           .GETSTRINGVAL;
          DBG('L_DBTRACCT_NO=' || L_DBTRACCT_NO);

          L_DBTRACCT_CCY := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/DbtrAcct/Ccy/text()')
                            .GETSTRINGVAL;
          DBG('L_DBTRACCT_CCY=' || L_DBTRACCT_CCY);

          L_DBTRAGT_BICFI := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/DbtrAgt/FinInstnId/BICFI/text()')
                             .GETSTRINGVAL;
          DBG('L_DBTRAGT_BICFI=' || L_DBTRAGT_BICFI);

          L_INSTRID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/PmtId/InstrId/text()')
                       .GETSTRINGVAL;
          DBG('L_INSTRID=' || L_INSTRID);

          L_ENDTOENDID := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/PmtId/EndToEndId/text()')
                          .GETSTRINGVAL;
          DBG('L_ENDTOENDID=' || L_ENDTOENDID);

          L_AMT := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Amt/InstdAmt/text()')
                   .GETSTRINGVAL;
          DBG('L_AMT=' || L_AMT);

          L_CHRGBR := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/ChrgBr/text()')
                      .GETSTRINGVAL;
          DBG('L_CHRGBR=' || L_CHRGBR);

          L_CRTRAGT_BICFI := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/CdtrAgt/FinInstnId/BICFI/text()')
                             .GETSTRINGVAL;
          DBG('L_CRTRAGT_BICFI=' || L_CRTRAGT_BICFI);

          L_CDTR_NM := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Cdtr/Nm/text()')
                       .GETSTRINGVAL;
          DBG('L_CDTR_NM=' || L_CDTR_NM);

          L_CDTRACCT_NO := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/CdtrAcct/Id/Othr/Id/text()')
                           .GETSTRINGVAL;
          DBG('L_CDTRACCT_NO=' || L_CDTRACCT_NO);

          L_PURP := P_DOCUMENT_XML.EXTRACT('/Document/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Purp/Cd/text()')
                    .GETSTRINGVAL;
          DBG('L_PURP=' || L_PURP);

          --Need to make Ack webservicall call which is pending

          --Get Ack Message
          L_FORMATTED_MSG := IFPKS_FAST_INCOMING.FN_RETURN_ACK_MSG;

          DBG('BEFORE REPLACEMENT OF ACK XML=' || L_FORMATTED_MSG);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_MSG_ID', L_MSG_ID);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_CREDTTM',
                                     L_CREDTTM);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_INITGPTY_NM',
                                     L_INITGPTY_NM);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_CRTRAGT_BICFI',
                                     L_CRTRAGT_BICFI);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_DBTRAGT_BICFI',
                                     L_DBTRAGT_BICFI);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_PMTINFID',
                                     L_PMTINFID);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_ENDTOENDID',
                                     L_ENDTOENDID);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMT', L_AMT);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_DBTR_NM',
                                     L_DBTR_NM);

          L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                     '$L_CDTR_NM',
                                     L_CDTR_NM);

          DBG('AFTER REPLACEMENT OF ACK XML=' || L_FORMATTED_MSG);

          --Log Ack Request to NBC
          DBG('LOGGING ACK REQUEST TO NBC');
          PR_INSERT_FAST_WS_LOG(L_MSG_ID,
                                L_GEN_SEQ_NO,
                                L_TRN_REF_NO,
                                SYSDATE,
                                'Ack',
                                L_FORMATTED_MSG,
                                'I',
                                NULL,
                                'Ack for Refund');

          IF NOT IFPKS_IFDOFAST_CUSTOM.FN_FAST_HTTP_CALL('F',
                                                         L_FORMATTED_MSG,
                                                         L_IN_RESP) THEN
            DBG('FAILED IN ACKNOWLEDGING THE ORIGINAL INCOMING TXN');
            ROLLBACK TO REVERSE_POINT;
          ELSE
            DBG('SUCCESS IN ACKNOWLEDGING THE ORIGINAL FAST INCOMING TXN');

            --Log Ack Resonse
            L_IN_RESP := REPLACE(L_IN_RESP, '&lt;', '<');
            L_IN_RESP := REPLACE(L_IN_RESP, '&gt;', '>');

            --Get Cosmetic XML
            IFPKS_FAST_INCOMING.PR_RETURN_COSMETIC_XML(L_IN_RESP,
                                                       L_COSMETIC_RES_MSG);

            DBG('L_COSMETIC_RES_MSG OF ACK RESPONSE=' ||
                L_COSMETIC_RES_MSG);

            --Convert into XMLTYPE
            P_DOCUMENT_XML1 := XMLTYPE(L_COSMETIC_RES_MSG);

            --Get Node Value
            L_TXN_STATUS := P_DOCUMENT_XML1.EXTRACT('/Document/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/TxSts/text()')
                            .getstringval;

            DBG('L_TXN_STATUS=' || L_TXN_STATUS);

            DBG('LOGGING ACK RESPONSE FROM NBC');

            PR_UPDATE_FAST_WS_LOG(L_MSG_ID,
                                  L_GEN_SEQ_NO,
                                  L_TXN_STATUS,
                                  L_IN_RESP);

            PR_UPDATE_STATUS_FAST_INCOMING(L_TRN_REF_NO, L_TXN_STATUS);

            PR_UPDATE_DOC_TRACKER(L_MSG_ID, 'P', P_ERR_CODE, P_ERR_PARAM);

            DBG('SUCCESS IN ACKNOWLEDGING THE FAST INCOMING TRANSACTION');

          END IF;

        END IF;
      END IF;

      DBG('END OF PR_REVERSE_FAST_OUT_TXN');
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_REVERSE_FAST_OUT_TXN');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
  END PR_REVERSE_FAST_OUT_TXN;

END ifpks_ifdofast_custom;
