-- Create table
create table STTB_CORAL_FAST_WS_LOG
(
  unique_reference_no VARCHAR2(16) not null,
  customer_no         VARCHAR2(9),
  scan_id             VARCHAR2(10),
  invoke_date         DATE,
  req_type            VARCHAR2(16),
  req_msg             CLOB,
  res_msg             CLOB,
  status              VARCHAR2(16),
  action              VARCHAR2(25),
  risk_level          CHAR(1),
  hit_value           VARCHAR2(20),
  fc_ref_no           VARCHAR2(16) not null,
  sender_name         VARCHAR2(105),
  ben_name            VARCHAR2(105),
  sender_high_cnt     VARCHAR2(2),
  ben_high_cnt        VARCHAR2(2)
)
/
alter table STTB_CORAL_FAST_WS_LOG add primary key (UNIQUE_REFERENCE_NO, FC_REF_NO)
/
-- Create sequence 
create sequence FC_AML_API_WS_CALL_LOG_ID
minvalue 1
maxvalue 999999999
start with 1293
increment by 1
nocache
cycle;
/
ALTER TABLE STTB_CORAL_MTA_WS_LOG ADD (sender_name VARCHAR2(105),ben_name VARCHAR2(105),sender_high_cnt VARCHAR2(2),ben_high_cnt VARCHAR2(2))
/
-- Create table
create table STTB_CORAL_RFT_WS_LOG
(
  unique_reference_no VARCHAR2(16) not null,
  customer_no         VARCHAR2(9),
  scan_id             VARCHAR2(10),
  invoke_date         DATE,
  req_type            VARCHAR2(16),
  req_msg             CLOB,
  res_msg             CLOB,
  status              VARCHAR2(16),
  action              VARCHAR2(25),
  risk_level          CHAR(1),
  hit_value           VARCHAR2(20),
  fc_ref_no           VARCHAR2(16) not null,
  sender_name         VARCHAR2(105),
  ben_name            VARCHAR2(105),
  sender_high_cnt     VARCHAR2(2),
  ben_high_cnt        VARCHAR2(2)
)
/
alter table STTB_CORAL_RFT_WS_LOG add primary key (UNIQUE_REFERENCE_NO, FC_REF_NO)
/