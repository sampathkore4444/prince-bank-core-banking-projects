CREATE OR REPLACE PACKAGE IFPKS_SANCTION_UTILS AS

  FUNCTION FN_AML_HTTP_CALL(P_OUT_MSG        CLOB,
                            P_IN_RESP        IN OUT CLOB,
                            P_url            IN VARCHAR2,
                            p_soapaction_url in varchar2,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN;

  --RIA Phase2 Changes Starts
  FUNCTION FN_AML_HTTP_CALL(P_OUT_MSG        CLOB,
                            P_IN_RESP        IN OUT CLOB,
                            P_url            IN VARCHAR2,
                            p_soapaction_url in varchar2,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAMS     IN OUT VARCHAR2,
                            P_LENGTH         IN NUMBER) RETURN BOOLEAN;

  FUNCTION FN_GET_AML_STATUS_RIA_OUT(P_RTN_SCAN_ID IN VARCHAR2,
                                     P_CUSTOMER_NO IN VARCHAR2,
                                     P_FCREF_NO    IN VARCHAR2,
                                     p_Err_Code    IN OUT VARCHAR2,
                                     p_Err_Params  IN OUT VARCHAR2)
    RETURN BOOLEAN;


/*  FUNCTION FN_RETURN_AML_RESP_RIA(P_SEND_HIGH_CNT IN VARCHAR2,
                                  P_BEN_HIGH_CNT  IN VARCHAR2,
                                  P_CUSTOMER_NO   IN VARCHAR2,
                                  P_SENDER_NAME   IN VARCHAR2,
                                  P_BEN_NAME      IN VARCHAR2,
                                  P_ACTION_CODE   IN VARCHAR2,
                                  P_FCREF_NO      IN VARCHAR2,

                                  P_HIT_STATUS OUT VARCHAR2,
                                  P_WHO_HIT    OUT CHAR,
                                  P_SCAN_ID    OUT VARCHAR2,
                                  p_Err_Code   IN OUT VARCHAR2,
                                  p_Err_Params IN OUT VARCHAR2)
    RETURN BOOLEAN;*/

  FUNCTION FN_RETURN_AML_RESP_RIA_CASHREM(P_SEND_HIGH_CNT IN VARCHAR2,
                                          P_BEN_HIGH_CNT  IN VARCHAR2,
                                          P_CUSTOMER_NO   IN VARCHAR2,
                                          P_SENDER_NAME   IN VARCHAR2,
                                          P_BEN_NAME      IN VARCHAR2,
                                          P_ACTION_CODE   IN VARCHAR2,
                                          P_FCREF_NO      IN VARCHAR2,
                                          P_HIT_STATUS    OUT VARCHAR2,
                                          P_WHO_HIT       OUT CHAR,
                                          P_SCAN_ID       OUT VARCHAR2,
                                          p_Err_Code      IN OUT VARCHAR2,
                                          p_Err_Params    IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_RETURN_AML_RESP_RIA_INC(P_SEND_HIGH_CNT IN VARCHAR2,
                                      P_BEN_HIGH_CNT  IN VARCHAR2,
                                      P_CUSTOMER_NO   IN VARCHAR2,
                                      P_SENDER_NAME   IN VARCHAR2,
                                      P_BEN_NAME      IN VARCHAR2,
                                      P_ACTION_CODE   IN VARCHAR2,
                                      P_FCREF_NO      IN VARCHAR2,
                                      P_PRODUCT       IN VARCHAR2,
                                      P_HIT_STATUS    OUT VARCHAR2,
                                      P_WHO_HIT       OUT CHAR,
                                      P_SCAN_ID       OUT VARCHAR2,
                                      p_Err_Code      IN OUT VARCHAR2,
                                      p_Err_Params    IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_RETURN_AML_RESP_RIA_OUT(P_BEN_HIGH_CNT IN VARCHAR2,
                                      P_CUSTOMER_NO  IN VARCHAR2,

                                      P_BEN_NAME    IN VARCHAR2,
                                      P_ACTION_CODE IN VARCHAR2,
                                      P_FCREF_NO    IN VARCHAR2,
                                      P_HIT_STATUS  OUT VARCHAR2,
                                      P_WHO_HIT     OUT CHAR,
                                      P_SCAN_ID     OUT VARCHAR2,
                                      p_Err_Code    IN OUT VARCHAR2,
                                      p_Err_Params  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_RETURN_AML_RESP_RIA_OUT_NEW(P_BEN_HIGH_CNT IN VARCHAR2,
                                          P_CUSTOMER_NO  IN VARCHAR2,

                                          P_BEN_NAME    IN VARCHAR2,
                                          P_ACTION_CODE IN VARCHAR2,
                                          P_FCREF_NO    IN VARCHAR2,
                                          P_HIT_STATUS  OUT VARCHAR2,
                                          P_WHO_HIT     OUT CHAR,
                                          P_SCAN_ID     OUT VARCHAR2,
                                          p_Err_Code    IN OUT VARCHAR2,
                                          p_Err_Params  IN OUT VARCHAR2)
    RETURN BOOLEAN;
  --RIA Phase2 Changes Ends
  FUNCTION FN_RETURN_AML_RESP_RIA(P_SEND_HIGH_CNT IN VARCHAR2,
                                  P_BEN_HIGH_CNT  IN VARCHAR2,
                                  P_CUSTOMER_NO   IN VARCHAR2,
                                  P_SENDER_NAME   IN VARCHAR2,
                                  P_BEN_NAME      IN VARCHAR2,
                                  P_ACTION_CODE   IN VARCHAR2,
                                  P_FCREF_NO      IN VARCHAR2,

                                  P_HIT_STATUS OUT VARCHAR2,
                                  P_WHO_HIT    OUT CHAR,
                                  P_SCAN_ID    OUT VARCHAR2,
                                  p_Err_Code   IN OUT VARCHAR2,
                                  p_Err_Params IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_RETURN_AML_RESP_MTA(P_SEND_HIGH_CNT IN VARCHAR2,
                                  P_BEN_HIGH_CNT  IN VARCHAR2,
                                  P_CUSTOMER_NO   IN VARCHAR2,
                                  P_SENDER_NAME   IN VARCHAR2,
                                  P_BEN_NAME      IN VARCHAR2,
                                  P_ACTION_CODE   IN VARCHAR2,
                                  P_FCREF_NO      IN VARCHAR2,

                                  P_HIT_STATUS OUT VARCHAR2,
                                  P_WHO_HIT    OUT CHAR,
                                  P_SCAN_ID    OUT VARCHAR2,
                                  p_Err_Code   IN OUT VARCHAR2,
                                  p_Err_Params IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_GET_AML_STATUS_MTA(P_RTN_SCAN_ID IN VARCHAR2,
                                 P_CUSTOMER_NO IN VARCHAR2,
                                 P_FCREF_NO    IN VARCHAR2,
                                 p_Err_Code    IN OUT VARCHAR2,
                                 p_Err_Params  IN OUT VARCHAR2)
    RETURN BOOLEAN;
  
  --AML New Payment Flow Starts
  
  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC;

  FUNCTION FN_AML_PAYMENT_CALL_A(P_USER_NAME               IN VARCHAR2,
                                 P_BRANCH_CODE             IN VARCHAR2,
                                 P_SYS_NAME                IN VARCHAR2,
                                 P_UNIQUE_NO               IN VARCHAR2,
                                 P_SEARCH_NAME             IN VARCHAR2,
                                 P_SEARCH_COUNTRY          IN VARCHAR2,
                                 P_SEARCH_F1_BANK_NAME     IN VARCHAR2,
                                 P_SEARCH_ID               IN VARCHAR2,
                                 P_PASSPORT_VERIFY         IN VARCHAR2,
                                 P_SECURITY_NO1            IN VARCHAR2,
                                 P_PASSPORT_EXPDATE_VERIFY IN VARCHAR2,
                                 P_PASSPORT_EXPDATE        IN VARCHAR2,
                                 P_SECURITY_NO2            IN VARCHAR2,
                                 P_RISK_FACTORS            IN VARCHAR2,
                                 P_SEARCH_F2_ADDR          IN VARCHAR2,
                                 P_SEARCH_F3_PURPOSE       IN VARCHAR2,
                                 P_SEARCH_F4_REMARKS       IN VARCHAR2,
                                 P_SEARCH_F5_TXN_AMT       IN VARCHAR2,
                                 P_SEARCH_F6_TXN_CCY       IN VARCHAR2,
                                 P_SEARCH_F7_ACC_NO        IN VARCHAR2,
                                 P_SEARCH_F8               IN VARCHAR2,
                                 P_SEARCH_F9               IN VARCHAR2,
                                 P_PROD_CHANNEL            IN VARCHAR2,
                                 P_PROD_CODE               IN VARCHAR2,
                                 P_CONTENT                 IN VARCHAR2,
                                 P_RETURN_HIT              IN VARCHAR2,
                                 P_RETURN_SCANID           IN VARCHAR2,
                                 P_RETURN_ENCRYPT_SCANID   IN VARCHAR2,
                                 P_CUSTOMER_NO             IN VARCHAR2,
                                 P_SENDER_NAME             IN VARCHAR2,
                                 P_SENDER_COUNTRY          IN VARCHAR2,
                                 P_BEN_NAME                IN VARCHAR2,
                                 P_BEN_COUNTRY             IN VARCHAR2,
                                 P_FCREF_NO                IN VARCHAR2,
                                 P_SCAN_ID                 OUT VARCHAR2,
                                 P_HIT_STATUS              OUT VARCHAR2,
                                 P_RESPONSE                OUT CLOB)
    RETURN BOOLEAN;

  FUNCTION FN_AML_PAYMENT_CALL_B(P_USER_NAME               IN VARCHAR2,
                                 P_BRANCH_CODE             IN VARCHAR2,
                                 P_SYS_NAME                IN VARCHAR2,
                                 P_UNIQUE_NO               IN VARCHAR2,
                                 P_SEARCH_NAME             IN VARCHAR2,
                                 P_SEARCH_COUNTRY          IN VARCHAR2,
                                 P_SEARCH_F1_BANK_NAME     IN VARCHAR2,
                                 P_SEARCH_ID               IN VARCHAR2,
                                 P_PASSPORT_VERIFY         IN VARCHAR2,
                                 P_SECURITY_NO1            IN VARCHAR2,
                                 P_PASSPORT_EXPDATE_VERIFY IN VARCHAR2,
                                 P_PASSPORT_EXPDATE        IN VARCHAR2,
                                 P_SECURITY_NO2            IN VARCHAR2,
                                 P_RISK_FACTORS            IN VARCHAR2,
                                 P_SEARCH_F2_ADDR          IN VARCHAR2,
                                 P_SEARCH_F3_PURPOSE       IN VARCHAR2,
                                 P_SEARCH_F4_REMARKS       IN VARCHAR2,
                                 P_SEARCH_F5_TXN_AMT       IN VARCHAR2,
                                 P_SEARCH_F6_TXN_CCY       IN VARCHAR2,
                                 P_SEARCH_F7_ACC_NO        IN VARCHAR2,
                                 P_SEARCH_F8               IN VARCHAR2,
                                 P_SEARCH_F9               IN VARCHAR2,
                                 P_PROD_CHANNEL            IN VARCHAR2,
                                 P_PROD_CODE               IN VARCHAR2,
                                 P_CONTENT                 IN VARCHAR2,
                                 P_RETURN_HIT              IN VARCHAR2,
                                 P_RETURN_SCANID           IN VARCHAR2,
                                 P_RETURN_ENCRYPT_SCANID   IN VARCHAR2,
                                 P_CUSTOMER_NO             IN VARCHAR2,
                                 P_SENDER_NAME             IN VARCHAR2,
                                 P_SENDER_COUNTRY          IN VARCHAR2,
                                 P_BEN_NAME                IN VARCHAR2,
                                 P_BEN_COUNTRY             IN VARCHAR2,
                                 P_FCREF_NO                IN VARCHAR2,
                                 P_SCAN_ID                 OUT VARCHAR2,
                                 P_HIT_STATUS              OUT VARCHAR2,
                                 P_RESPONSE                OUT CLOB)
    RETURN BOOLEAN;

  FUNCTION FN_GET_AML_PAYMENT_STATUS(P_SYS_NAME     IN VARCHAR2,
                                     P_UNIQUE_NO    IN VARCHAR2,
                                     P_SCAN_ID      IN VARCHAR2,
                                     P_CUSTOMER_NO  IN VARCHAR2,
                                     P_FCREF_NO     IN VARCHAR2,
                                     P_PROD_CHANNEL IN VARCHAR2,
                                     P_PROD_CODE IN VARCHAR2,
                                     P_RESPONSE OUT CLOB) RETURN BOOLEAN;
  
  --AML New Payment Flow Ends
END IFPKS_SANCTION_UTILS;
