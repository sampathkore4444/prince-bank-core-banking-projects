CREATE OR REPLACE PACKAGE BODY ifpks_ifdrftpm_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdrftpm_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  SFR Number         :
  Changed By         :
  Change Description :

  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdrftpm_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;

  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;

  PROCEDURE PR_POPULATE_RECORD_LOG(P_IFDRFTPM IN ifpks_ifdrftpm_Main.Ty_ifdrftpm) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_COUNT NUMBER;
  BEGIN
    DBG('START OF PR_POPULATE_RECORD_LOG');
    DBG('BEFORE INSERTING INTO PR_POPULATE_RECORD_LOG');

    --log starts

    BEGIN
      INSERT INTO STTB_RECORD_LOG
        (KEY_ID,
         MOD_NO,
         BRANCH_CODE,
         FUNCTION_ID,
         TABLE_NAME,
         MAKER_ID,
         MAKER_DT_STAMP,
         CHECKER_ID,
         CHECKER_DT_STAMP,
         RECORD_STAT,
         AUTH_STAT,
         ACTION_CODE)
      VALUES
        ('~IFTB_RFT_MASTER~' || P_IFDRFTPM.v_iftbs_rft_master.TRN_REF_NO || '~',
         '2',
         GLOBAL.current_branch,
         'IFDRFTPM',
         'IFTB_RFT_MASTER',
         GLOBAL.USER_ID, --p_ifdrftpm.v_iftbs_rft_master.MAKER_ID,
         GLOBAL.APPLICATION_DATE, --p_ifdrftpm.v_iftbs_rft_master.MAKER_DT_STAMP,
         NULL,
         NULL,
         p_ifdrftpm.v_iftbs_rft_master.RECORD_STAT,
         'U',
         'REVERSE');

    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        DBG('UPDATING STTB_RECORD_LOG BECAUSE OF UNIQUE');
        BEGIN
          UPDATE STTB_RECORD_LOG
             SET BRANCH_CODE      = GLOBAL.current_branch,
                 FUNCTION_ID      = 'IFDRFTPM',
                 TABLE_NAME       = 'IFTB_RFT_MASTER',
                 MAKER_ID         = p_ifdrftpm.v_iftbs_rft_master.MAKER_ID,
                 MAKER_DT_STAMP   = p_ifdrftpm.v_iftbs_rft_master.MAKER_DT_STAMP,
                 CHECKER_ID       = p_ifdrftpm.v_iftbs_rft_master.CHECKER_ID,
                 CHECKER_DT_STAMP = p_ifdrftpm.v_iftbs_rft_master.CHECKER_DT_STAMP,
                 RECORD_STAT      = p_ifdrftpm.v_iftbs_rft_master.RECORD_STAT,
                 AUTH_STAT        = p_ifdrftpm.v_iftbs_rft_master.AUTH_STAT,
                 ACTION_CODE      = 'REVERSE'
           WHERE KEY_ID = '~IFTB_RFT_MASTER~' ||
                 P_IFDRFTPM.v_iftbs_rft_master.TRN_REF_NO || '~'
             AND MOD_NO = '2';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
        END;

    END;

    DBG('INSERT ROW COUNT=' || SQL%ROWCOUNT);

    UPDATE IFTB_RFT_MASTER
       SET MAKER_ID         = p_ifdrftpm.v_iftbs_rft_master.MAKER_ID,
           MAKER_DT_STAMP   = p_ifdrftpm.v_iftbs_rft_master.MAKER_DT_STAMP,
           CHECKER_ID       = NULL,
           CHECKER_DT_STAMP = NULL,
           AUTH_STAT        = 'U',
           MOD_NO           = 2
     WHERE TRN_REF_NO = p_ifdrftpm.v_iftbs_rft_master.TRN_REF_NO;

    DBG('INSERT ROW COUNT=' || SQL%ROWCOUNT);

    --log ends

    COMMIT;
    DBG('END OF PR_POPULATE_RECORD_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_POPULATE_RECORD_LOG');
      DBG('ERROR CODE IN PR_POPULATE_RECORD_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_POPULATE_RECORD_LOG=' || SQLERRM);

  END PR_POPULATE_RECORD_LOG;

  PROCEDURE PR_INSERT_RFT_WS_LOG(P_SEQ_NO     IN VARCHAR2,
                                 P_TRN_REF_NO IN VARCHAR2,
                                 P_DATE       IN DATE,
                                 P_REQ_TYPE   IN VARCHAR2,

                                 P_REQ_MSG   IN CLOB,
                                 P_ADDL_INFO IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_RFT_WS_LOG');
    DBG('BEFORE INSERTING INTO PR_INSERT_RFT_WS_LOG');
    INSERT INTO STTB_RFT_WS_LOG
      (SEQ_NO, TRN_REF_NO, INVOKE_DATE, REQ_TYPE, REQ_MSG, ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_TRN_REF_NO,
       P_DATE,
       P_REQ_TYPE,
       P_REQ_MSG,

       P_ADDL_INFO);

    COMMIT;
    DBG('END OF PR_INSERT_RFT_WS_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_RFT_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_RFT_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_RFT_WS_LOG=' || SQLERRM);

  END PR_INSERT_RFT_WS_LOG;

  PROCEDURE PR_UPDATE_RFT_WS_LOG(P_TRN_REF_NO IN VARCHAR2,
                                 P_SEQ_NO     IN VARCHAR2,
                                 P_STATUS     IN CHAR,
                                 P_RES_MSG    IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_RFT_WS_LOG');

    UPDATE STTB_RFT_WS_LOG
       SET STATUS = P_STATUS, RES_MSG = P_RES_MSG
     WHERE TRN_REF_NO = P_TRN_REF_NO
       AND SEQ_NO = P_SEQ_NO;

    COMMIT;

    DBG('END OF PR_UPDATE_RFT_WS_LOG');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_RFT_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_RFT_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_RFT_WS_LOG=' || SQLERRM);
  END PR_UPDATE_RFT_WS_LOG;

  PROCEDURE PR_UPDATE_RFT_WS_LOG(P_TRN_REF_NO IN VARCHAR2,
                                 P_SEQ_NO     IN VARCHAR2,
                                 P_STATUS     IN CHAR,
                                 P_SECRET_KEY IN VARCHAR2,
                                 P_RES_MSG    IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF OVERLOADED PR_UPDATE_RFT_WS_LOG');

    UPDATE STTB_RFT_WS_LOG
       SET STATUS     = P_STATUS,
           RES_MSG    = P_RES_MSG,
           SECRET_KEY = P_SECRET_KEY
     WHERE TRN_REF_NO = P_TRN_REF_NO
       AND SEQ_NO = P_SEQ_NO;

    COMMIT;

    DBG('END OF OVERLOADED PR_UPDATE_RFT_WS_LOG');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN OVERLOADED PR_UPDATE_RFT_WS_LOG');
      DBG('ERROR CODE IN OVERLOADED PR_UPDATE_RFT_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN OVERLOADED PR_UPDATE_RFT_WS_LOG=' || SQLERRM);
  END PR_UPDATE_RFT_WS_LOG;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;

    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;
  
  --AML New Payment Flow Starts
  FUNCTION FN_GET_BEN_BANK_NAME(P_CODE IN LMTM_TYPE_VALUES.CODE%TYPE)
    RETURN LMTM_TYPE_VALUES.VALUE%TYPE AS
    L_BEN_BANK_NAME LMTM_TYPE_VALUES.VALUE%TYPE;
  BEGIN
  
    SELECT B.VALUE
      INTO L_BEN_BANK_NAME
      FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
     WHERE A.TYPE = B.TYPE
       AND A.TYPE = 'RFT_MEMBERS'
       AND B.CODE NOT IN ('100', '096')
       AND B.CODE = P_CODE
       AND A.RECORD_STAT = 'O'
       AND A.AUTH_STAT = 'A';
  
    RETURN L_BEN_BANK_NAME;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_BEN_BANK_NAME');
      DBG('ERROR CODE IN FN_GET_BEN_BANK_NAME=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_BEN_BANK_NAME=' || SQLERRM);
    
      RETURN L_BEN_BANK_NAME;
    
  END FN_GET_BEN_BANK_NAME;
  --AML New Payment Flow Ends

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN

    SELECT TRSQ_RFT_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;

    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

    RETURN L_REF;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  PROCEDURE PR_INSERT_RFT_CANCEL_WS_LOG(P_SEQ_NO     IN VARCHAR2,
                                        P_TRN_REF_NO IN VARCHAR2,
                                        P_DATE       IN DATE,
                                        P_REQ_TYPE   IN VARCHAR2,
                                        P_REQ_MSG    IN CLOB,
                                        P_ADDL_INFO  IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_INSERT_RFT_CANCEL_WS_LOG');

    DBG('BEFORE INSERTING INTO STTB_RFT_WS_LOG');

    INSERT INTO STTB_RFT_WS_LOG
      (SEQ_NO, TRN_REF_NO, INVOKE_DATE, REQ_TYPE, REQ_MSG, ADDL_INFO)
    VALUES
      (P_SEQ_NO, P_TRN_REF_NO, P_DATE, P_REQ_TYPE, P_REQ_MSG, P_ADDL_INFO);

    COMMIT;

    DBG('AFTER INSERTING INTO STTB_RFT_WS_LOG');

    DBG('END OF PR_INSERT_RFT_CANCEL_WS_LOG');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_RFT_CANCEL_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_RFT_CANCEL_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_RFT_CANCEL_WS_LOG=' || SQLERRM);

  END PR_INSERT_RFT_CANCEL_WS_LOG;

  FUNCTION FN_RETURN_RFT_TXN_STATUS RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN

    DBG('SATRT OF FN_RETURN_RFT_TXN_STATUS');

    L_FORMATTED_MSG := '{
    "trxDate": "$L_TXN_DATE",
    "txnUnqNo": "$L_TXN_UNQ_ID"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_RFT_TXN_STATUS');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_RFT_TXN_STATUS');
      DBG('ERROR CODE IN FN_RETURN_RFT_TXN_STATUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_RFT_TXN_STATUS=' || SQLERRM);

  END FN_RETURN_RFT_TXN_STATUS;

  FUNCTION FN_RETURN_FMT_TXN_STATUS(P_IFDRFTPM IN ifpks_ifdrftpm_Main.Ty_ifdrftpm)
    RETURN CLOB IS

    L_TXN_DATE   VARCHAR2(100);
    L_TXN_UNQ_ID VARCHAR2(100);

    L_FORMATTED_MSG CLOB; --varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_RETURN_FMT_TXN_STATUS');

    L_FORMATTED_MSG := FN_RETURN_RFT_TXN_STATUS;

    DBG('BEFORE REPLACEMENT OF RFT TXN STATUS JSON=' || L_FORMATTED_MSG);

    --Replace tags with actual values
    L_TXN_DATE := TO_CHAR(p_ifdrftpm.v_iftbs_rft_master.TRANSFER_DATE,
                          'YYYYMMDD');

    DBG('L_TXN_DATE=' || L_TXN_DATE);

    L_TXN_UNQ_ID := p_ifdrftpm.v_iftbs_rft_master.TXN_UNQ_NO;

    DBG('L_TXN_UNQ_ID=' || L_TXN_UNQ_ID);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_DATE', L_TXN_DATE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_UNQ_ID',
                               L_TXN_UNQ_ID);

    DBG('AFTER REPLACEMENT OF RFT TXN STATUS JSON=' || L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_FMT_TXN_STATUS');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_FMT_TXN_STATUS');
      DBG('ERROR CODE IN FN_RETURN_FMT_TXN_STATUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_FMT_TXN_STATUS=' || SQLERRM);
  END FN_RETURN_FMT_TXN_STATUS;

  FUNCTION FN_RETURN_RFT_ACC_ENQUIRY RETURN CLOB IS
    L_FORMATTED_MSG varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_RETURN_RFT_ACC_ENQUIRY');

    L_FORMATTED_MSG := '{
    "chnlCd": "02",
    "sndAcctNo": "$L_SENDER_ACC",
    "sndNm": "$L_SENDER_NAME",
    "rcvBkCd": "$L_BEN_BIC_CODE",
    "rcvAcctNo": "$L_BEN_ACC_NO",
    "crrcy": "$L_TXN_CCY",
    "amt": "$L_TXN_AMT"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_RFT_ACC_ENQUIRY');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_RFT_ACC_ENQUIRY');
      DBG('ERROR CODE IN FN_RETURN_RFT_ACC_ENQUIRY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_RFT_ACC_ENQUIRY=' || SQLERRM);
  END FN_RETURN_RFT_ACC_ENQUIRY;

  FUNCTION FN_RETURN_FORMATTED_ACC_ENQ(P_IFDRFTPM IN ifpks_ifdrftpm_Main.Ty_ifdrftpm)
    RETURN CLOB IS

    L_SENDER_ACC    VARCHAR2(100);
    L_SENDER_NAME   VARCHAR2(100);
    L_BEN_BIC_CODE  VARCHAR2(100);
    L_BEN_ACC_NO    VARCHAR2(100);
    L_TXN_CCY       VARCHAR2(100);
    L_TXN_AMT       VARCHAR2(100);
    L_FORMATTED_MSG CLOB; --varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_RETURN_FORMATTED_ACC_ENQ');

    L_FORMATTED_MSG := FN_RETURN_RFT_ACC_ENQUIRY;

    DBG('BEFORE REPLACEMENT OF RFT OUT ACC ENQUIRY JSON=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values
    L_SENDER_ACC := p_ifdrftpm.v_iftbs_rft_master.rem_acc;

    DBG('L_SENDER_ACC=' || L_SENDER_ACC);

    L_SENDER_NAME := p_ifdrftpm.v_iftbs_rft_master.rem_name;

    DBG('L_SENDER_NAME=' || L_SENDER_NAME);

    L_BEN_BIC_CODE := p_ifdrftpm.v_iftbs_rft_master.BEN_BIC;

    DBG('L_BEN_BIC_CODE=' || L_BEN_BIC_CODE);

    L_BEN_ACC_NO := p_ifdrftpm.v_iftbs_rft_master.BEN_ACC;

    DBG('L_BEN_ACC_NO=' || L_BEN_ACC_NO);

    L_TXN_CCY := p_ifdrftpm.v_iftbs_rft_master.TXN_CCY;

    DBG('L_TXN_CCY=' || L_TXN_CCY);

    L_TXN_AMT := p_ifdrftpm.v_iftbs_rft_master.TXN_AMT;

    DBG('L_TXN_AMT=' || L_TXN_AMT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SENDER_ACC',
                               L_SENDER_ACC);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SENDER_NAME',
                               L_SENDER_NAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BIC_CODE',
                               L_BEN_BIC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ACC_NO',
                               L_BEN_ACC_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_CCY', L_TXN_CCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_AMT', L_TXN_AMT);

    DBG('BEFORE REPLACEMENT OF RFT OUT ACC ENQUIRY JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_FORMATTED_ACC_ENQ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_FORMATTED_ACC_ENQ');
      DBG('ERROR CODE IN FN_RETURN_FORMATTED_ACC_ENQ=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_FORMATTED_ACC_ENQ=' || SQLERRM);
  END FN_RETURN_FORMATTED_ACC_ENQ;

  FUNCTION FN_RETURN_RFT_CANCEL_MSG RETURN CLOB IS
    L_FORMATTED_MSG varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_RETURN_RFT_CANCEL_MSG');

    L_FORMATTED_MSG := '{
    "sndDt": "$L_SENDER_DATE",
    "rcvBkCd": "$L_BEN_BIC_CODE",
    "txnUnqNo": "$L_TXN_UNIQUE_NO"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_RFT_CANCEL_MSG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_RFT_CANCEL_MSG');
      DBG('ERROR CODE IN FN_RETURN_RFT_CANCEL_MSG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_RFT_CANCEL_MSG=' || SQLERRM);
  END FN_RETURN_RFT_CANCEL_MSG;

  FUNCTION FN_RETURN_FORMATTED_CANCEL_MSG(P_IFDRFTPM IN ifpks_ifdrftpm_Main.Ty_ifdrftpm)
    RETURN CLOB IS

    L_SENDER_DATE   VARCHAR2(100);
    L_BEN_BIC_CODE  VARCHAR2(100);
    L_TXN_UNIQUE_NO VARCHAR2(100);
    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_RETURN_FORMATTED_CANCEL_MSG');

    L_FORMATTED_MSG := FN_RETURN_RFT_CANCEL_MSG;

    DBG('BEFORE REPLACEMENT OF RFT OUT ACC ENQUIRY JSON=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values
    L_SENDER_DATE := TO_CHAR(SYSDATE, 'YYYYMMDD'); --TO_CHAR(p_ifdrftpm.v_iftbs_rft_master.transfer_date,'YYYYMMDD');

    DBG('L_SENDER_DATE=' || L_SENDER_DATE);

    L_BEN_BIC_CODE := p_ifdrftpm.v_iftbs_rft_master.BEN_BIC;

    DBG('L_BEN_BIC_CODE=' || L_BEN_BIC_CODE);

    L_TXN_UNIQUE_NO := p_ifdrftpm.v_iftbs_rft_master.TXN_UNQ_NO;

    DBG('L_TXN_UNIQUE_NO=' || L_TXN_UNIQUE_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SENDER_DATE',
                               L_SENDER_DATE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BIC_CODE',
                               L_BEN_BIC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_UNIQUE_NO',
                               L_TXN_UNIQUE_NO);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_FORMATTED_CANCEL_MSG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_FORMATTED_CANCEL_MSG');
      DBG('ERROR CODE IN FN_RETURN_FORMATTED_CANCEL_MSG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_FORMATTED_CANCEL_MSG=' || SQLERRM);
  END FN_RETURN_FORMATTED_CANCEL_MSG;

  --FN_RETURN_FMT_CASA_TRF
  FUNCTION FN_RETURN_CASA_TRF RETURN CLOB IS
    L_FORMATTED_MSG varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_RETURN_CASA_TRF');

    L_FORMATTED_MSG := '{
    "scrtKey": "$L_SCRTKEY"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_CASA_TRF');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_CASA_TRF');
      DBG('ERROR CODE IN FN_RETURN_CASA_TRF=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_CASA_TRF=' || SQLERRM);
  END FN_RETURN_CASA_TRF;

  FUNCTION FN_RETURN_FMT_CASA_TRF(P_IFDRFTPM IN ifpks_ifdrftpm_Main.Ty_ifdrftpm)
    RETURN CLOB IS

    L_SECRET_KEY    VARCHAR2(1000);
    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_RETURN_FMT_CASA_TRF');

    L_FORMATTED_MSG := FN_RETURN_CASA_TRF;

    DBG('BEFORE REPLACEMENT OF RFT CASA TRANSFER JSON=' || L_FORMATTED_MSG);

    --Replace tags with actual values
    L_SECRET_KEY := P_IFDRFTPM.V_IFTBS_RFT_MASTER.SECRETE_KEY;

    DBG('L_SECRET_KEY=' || L_SECRET_KEY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SCRTKEY', L_SECRET_KEY);

    DBG('BEFORE REPLACEMENT OF RFT CASA TRANSFER JSON=' || L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_RETURN_FMT_CASA_TRF');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_FMT_CASA_TRF');
      DBG('ERROR CODE IN FN_RETURN_FMT_CASA_TRF=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_FMT_CASA_TRF=' || SQLERRM);
  END FN_RETURN_FMT_CASA_TRF;

  PROCEDURE PR_PRINT_ACCTNG_TABLE(P_ACC_HAND IN ACPKS.TBL_ACHOFF) IS
    I      NUMBER;
    L_ROW  VARCHAR2(500);
    L_LINE VARCHAR2(500);
  BEGIN

    SELECT RPAD('-',
                20 + 15 + 15 + 15 + 15 + 1 + 1 + 3 + 3 + 3 + 6 + 3,
                '-')
      INTO L_LINE
      FROM DUAL;
    DBG(L_LINE);
    SELECT '|' || RPAD('Tag', 10, '.') || '|' || RPAD('Brn', 3, '.') || '|' ||
           RPAD('Acc', 20, '.') || '|' || RPAD('Lcy Amt', 15, '.') || '|' ||
           RPAD('Fcy Amt', 15, '.') || '|' || RPAD('Exch Rate', 15, '.') || '|' ||
           RPAD('D/C', 1, '.') || '|' || RPAD('Netting', 1, '.') || '|' ||
           RPAD('Ccy', 3, '.') || '|' || RPAD('TrnCode', 3, '.') || '|' ||
           RPAD('Brn', 3, '.') || '|'
      INTO L_ROW
      FROM DUAL;
    DBG(L_ROW);
    DBG(L_LINE);

    FOR I IN 1 .. P_ACC_HAND.COUNT LOOP
      IF P_ACC_HAND.EXISTS(I) THEN
        SELECT '|' || RPAD(P_ACC_HAND(I).AMOUNT_TAG, 10, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_BRANCH, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_NO, 20, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).LCY_AMOUNT, -1111), 15, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).FCY_AMOUNT, -1111), 15, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).EXCH_RATE, -1111), 15, '.') || '|' ||
               RPAD(P_ACC_HAND(I).DRCR_IND, 1, '.') || '|' ||
               RPAD(P_ACC_HAND(I).NETTING_IND, 1, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_CCY, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).TRN_CODE, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_BRANCH, 3, '.') || '|'
          INTO L_ROW
          FROM DUAL;
        DBG(L_ROW);
        DBG(L_LINE);
      END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN;
  END PR_PRINT_ACCTNG_TABLE;

  PROCEDURE PR_CHARGE_REVERSAL(P_AC_ENTS IN OUT NOCOPY ACPKS.TBL_ACHOFF) IS

    L_INDEX       NUMBER;
    L_REV_REQD    VARCHAR2(1);
    L_NET_CHARGES VARCHAR2(1);
    L_CHG_FROM    VARCHAR2(3);
    L_AMT_SUM     NUMBER;
    L_CONTRA_LEG  NUMBER;
    L_PROD        VARCHAR2(4);

    L_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM VARCHAR2(250);

  BEGIN

    DBG('inside pr_chrge_reversal with product as ');

    BEGIN
      SELECT PRODUCT_CODE
        INTO L_PROD
        FROM DETB_RTL_TELLER
       WHERE TRN_REF_NO = P_AC_ENTS(1).TRN_REF_NO;

      DBG('Calling Fn_Get_Detm_Rt_Pref_Rec_Wrp...for the product...' ||
          L_PROD);
      IF NOT
          CSPKSS_FUNCTION_CACHE.FN_GET_DETM_RT_PREF_REC_WRP(L_PROD,
                                                            L_ERR_CODE,
                                                            L_ERR_PARAM) THEN
        IF L_ERR_CODE = 'CS-FRC-001' THEN
          DBG('No data Found exception so assignin value as Y ..');
          L_REV_REQD  := 'Y';
          L_ERR_CODE  := NULL;
          L_ERR_PARAM := NULL;
        ELSE
          DBG('In others exception..');
          L_ERR_CODE  := NULL;
          L_ERR_PARAM := NULL;
          DBG('Proceed..');
        END IF;
      ELSE
        L_REV_REQD := NVL(CSPKSS_FUNCTION_CACHE.G_TBL_DETM_RT_PREF_REC.REVERSAL_INCLUDES_CHARGES,
                          'N');
        DBG('Value of l_rev_reqd is - ' || L_REV_REQD);
      END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_REV_REQD := 'Y';
      WHEN OTHERS THEN
        DBG('Failed while checking if charge reversal is required');

    END;

    DBG('GWPKS_UTIL.G_REJECTFLAG => ' || GWPKS_UTIL.G_REJECTFLAG);

    IF L_REV_REQD = 'N' OR NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' THEN
      BEGIN
        SELECT NVL(COD_NET_CHARGES, 'Y')
          INTO L_NET_CHARGES
          FROM IFTMS_ARC_MAINT
         WHERE COD_PROD_ACC_CLS = L_PROD;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_NET_CHARGES := 'N';
        WHEN OTHERS THEN
          DBG('Failed while checking if charge netting is required');

      END;
      DBG('l_net_charges => ' || L_NET_CHARGES);
      IF L_NET_CHARGES = 'Y' THEN
        BEGIN

          SELECT CHG_CONTRA_LEG
            INTO L_CHG_FROM
            FROM DETBS_RTL_TELLER
           WHERE TRN_REF_NO = P_AC_ENTS(1).TRN_REF_NO;

        END;
        L_AMT_SUM := 0;

        IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
          DBG('INSIDE THE LOOP TO FETCH THE CHARGES');
          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF P_AC_ENTS(L_INDEX)
             .AMOUNT_TAG IN
                ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
              DBG('l_index ' || L_INDEX);
              DBG('p_ac_ents(l_index).AMOUNT_TAG => ' || P_AC_ENTS(L_INDEX)
                  .AMOUNT_TAG);
              L_AMT_SUM := L_AMT_SUM + P_AC_ENTS(L_INDEX).LCY_AMOUNT;
            END IF;

          END LOOP;
          DBG('OUT OF THE LOOP WITH l_amt_sum :- ' || L_AMT_SUM);

        ELSE

          DBG('INSIDE THE ELSE PART');
          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF P_AC_ENTS(L_INDEX)
             .AMOUNT_TAG IN ('CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
              L_AMT_SUM := L_AMT_SUM + P_AC_ENTS(L_INDEX).LCY_AMOUNT;
            END IF;

          END LOOP;

        END IF;

        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
          IF P_AC_ENTS(L_INDEX).AMOUNT_TAG = (L_CHG_FROM || '_AMT') THEN
            P_AC_ENTS(L_INDEX).LCY_AMOUNT := P_AC_ENTS(L_INDEX)
                                             .LCY_AMOUNT - L_AMT_SUM;
          END IF;
        END LOOP;

      END IF;

      IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
        DBG('GOING FOR THE LOOP TO DLETE THE CHARGE ENTRIES');

        BEGIN
          DBG('pr_print_acctng_table is cmd in begin.....');
          PR_PRINT_ACCTNG_TABLE(P_AC_ENTS);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In OTHERS with line tracking  ::::: ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        END;

        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
          IF P_AC_ENTS(L_INDEX)
           .AMOUNT_TAG IN
              ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
            DBG('l_index ' || L_INDEX);
            DBG('p_ac_ents(l_index).AMOUNT_TAG => ' || P_AC_ENTS(L_INDEX)
                .AMOUNT_TAG);
            P_AC_ENTS.DELETE(L_INDEX);
          END IF;
        END LOOP;
        DBG('OUT OF LOOP');

      ELSE

        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP

          IF P_AC_ENTS(L_INDEX)
           .AMOUNT_TAG IN ('CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
            P_AC_ENTS.DELETE(L_INDEX);

          END IF;
        END LOOP;

      END IF;
    END IF;

  END PR_CHARGE_REVERSAL;

  PROCEDURE PR_UPDATE_TRACKED_BALANCES(P_CONTRACT_REF_NO IN CSTB_CONTRACT.CONTRACT_REF_NO%TYPE) IS

    CURSOR CR_UPDATE_BALANCES IS
      SELECT *
        FROM CSTB_AUTO_SETTLE_BLOCK
       WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO
         AND AMOUNT_DUE != AMOUNT_PAID;
    L_AMOUNT_TO_BE_RELEASED NUMBER(22, 3) := 0;

  BEGIN

    FOR REC IN CR_UPDATE_BALANCES LOOP

      L_AMOUNT_TO_BE_RELEASED := REC.AMOUNT_AVAILABLE;

      DBG('account is :::: ' || REC.ACCOUNT_NO);

      DBG('L_AMOUNT_TO_BE_RELEASED is :::: ' || L_AMOUNT_TO_BE_RELEASED);

      ACPKS_CUSTBAL_PROCESS.PR_UPDATE_RECEIVABLE_AMT(REC.ACCOUNT_NO,
                                                     REC.ACCOUNT_BR,
                                                     'D',
                                                     L_AMOUNT_TO_BE_RELEASED);
      DEBUG.PR_DEBUG('LD', 'after updating recievable');

    END LOOP;

    INSERT INTO CSTB_AUTO_SETTLE_BLOCK_TEMP
      (SELECT *
         FROM CSTB_AUTO_SETTLE_BLOCK
        WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO);

    DBG('umber of rows iserted IN TEMP are :::: ' || SQL%ROWCOUNT);
    DELETE CSTB_AUTO_SETTLE_BLOCK
     WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO;

  END;

  FUNCTION FN_REVERSE(P_TRN_REF_NO IN VARCHAR2,
                      P_ERR_CODE   IN OUT VARCHAR2,
                      P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_AUTH_STAT        DETBS_RTL_TELLER.AUTH_STAT%TYPE;
    L_AC_ENTS          ACPKS.TBL_ACHOFF;
    L_ROWID            ROWID;
    L_AUTHORISE        VARCHAR2(1);
    L_CHECKER_DT_STAMP DATE;
    L_TRACK_RECEIVABLE VARCHAR2(1);
    L_SCODE            DETBS_RTL_TELLER.SCODE%TYPE;
    L_CHECK_ENTRIES    BOOLEAN := TRUE;
    L_SETTLE_COUNT     NUMBER := 0;
    L_ON_ERROR         BOOLEAN := FALSE;
    L_BOOK_DATE        DATE;

    L_ACC_TYPE_1   VARCHAR2(20);
    L_ACC_TYPE_2   VARCHAR2(20);
    L_BRANCH       DETBS_RTL_TELLER.BRANCH_CODE%TYPE;
    L_PRODUCT_CODE DETBS_RTL_TELLER.PRODUCT_CODE%TYPE;
    L_MODULE       CSTM_PRODUCT.MODULE%TYPE;
    V_TBL_RESTR    STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR;
    L_EVENT_CODE   DETB_RTL_TELLER.EVENT_CODE%TYPE;
    L_TRN_DATE     DETB_RTL_TELLER.TRN_DT%TYPE;
    L_PRDGRP       CSTM_PRODUCT.PRODUCT_GROUP%TYPE;
    L_DETB_ROW     DETB_RTL_TELLER%ROWTYPE;
    L_REV_UTIL     NUMBER := 0;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_IFTB_RFT_MASTER       IFTB_RFT_MASTER%ROWTYPE;

  BEGIN
    DBG('Inside the fn_reverse OF Depks_Rtl_Teller PACKAGE...');
    SAVEPOINT RTL_REVERSE;
    DBG('Issued savepoint rtl reverse');
    BEGIN
      SELECT AUTH_STAT, ROWID, NVL(SCODE, '*')
        INTO L_AUTH_STAT, L_ROWID, L_SCODE
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
            P_TRN_REF_NO || '~' || SQLERRM);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;

    BEGIN
      SELECT NVL(TRACK_RECEIVABLE, 'N')
        INTO L_TRACK_RECEIVABLE
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed while selecting track_receivable from detb_rtl_teller with -->' ||
            SQLERRM);
        DBG('Txn Ref No is --->' || P_TRN_REF_NO);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;

    BEGIN
      DBG('Initial value of l_settle_count ' || L_SETTLE_COUNT);
      DBG('Query to get record count from cstb_auto_settle_block');
      SELECT COUNT(*)
        INTO L_SETTLE_COUNT
        FROM CSTB_AUTO_SETTLE_BLOCK
       WHERE CONTRACT_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found for the record.. cstb_auto_settle_block ');
        L_SETTLE_COUNT := 0;
      WHEN OTHERS THEN
        DBG('Failed while selecting entries from cstb_auto_settle_block with -->' ||
            SQLERRM);
        DBG('contract_ref_no --->' || P_TRN_REF_NO);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;
    DBG('l_settle_count ' || L_SETTLE_COUNT);

    IF L_AUTH_STAT = 'A' OR L_AUTH_STAT IS NULL THEN
      DBG('Proceeding for Reversal with l_auth_stat  ' || L_AUTH_STAT ||
          ' and l_settle_count ' || L_SETTLE_COUNT);

      DBG('Cspks_Req_Global.g_Release_Type :::: ' ||
          CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('p_trn_ref_no while calling depks_rtl_teller_cluster.fn_reverse ::::: ' ||
            P_TRN_REF_NO);
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 1;

        IF L_CHECK_ENTRIES THEN
          L_TB_CLUSTER_DATA('l_check_entries') := 'T';
        ELSE
          L_TB_CLUSTER_DATA('l_check_entries') := 'F';
        END IF;

        IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_REVERSE(P_TRN_REF_NO,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM,
                                                   L_FN_CALL_ID,
                                                   L_TB_CLUSTER_DATA) THEN
          DBG('Failed inside depks_rtl_teller_cluster.Fn_Save');
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          RETURN FALSE;
        END IF;

        IF L_TB_CLUSTER_DATA.EXISTS('l_check_entries') THEN
          IF L_TB_CLUSTER_DATA('l_check_entries') = 'T' THEN
            L_CHECK_ENTRIES := TRUE;
          ELSE
            L_CHECK_ENTRIES := FALSE;
          END IF;
        END IF;

      END IF;

      IF L_SETTLE_COUNT > 0 THEN
        DBG('Before Validation For Same Day Reversal ');
        BEGIN
          SELECT BOOK_DATE
            INTO L_BOOK_DATE
            FROM CSTB_AUTO_SETTLE_BLOCK
           WHERE CONTRACT_REF_NO = P_TRN_REF_NO
             AND ROWNUM = 1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found for the record.. cstb_auto_settle_block ');
            L_BOOK_DATE := NULL;
          WHEN OTHERS THEN
            DBG('Failed while selecting BOOK_DATE from cstb_auto_settle_block with -->' ||
                SQLERRM);
            DBG('contract_ref_no --->' || P_TRN_REF_NO);
            P_ERR_CODE := 'DE-TUD-002';
            ROLLBACK TO RTL_REVERSE;
            RETURN FALSE;
        END;
        DBG('l_BOOK_DATE ' || L_BOOK_DATE);

        IF L_BOOK_DATE <> GLOBAL.APPLICATION_DATE THEN
          DBG('For Tracked Transaction Only same date Reversal is Allwoed.');
          P_ERR_CODE := 'DE-TUD-946';
          ROLLBACK TO RTL_REVERSE;
          RETURN FALSE;
        END IF;
      END IF;

      IF GWPKS_UTIL.G_FROM_BEAN OR L_SCODE = 'FLEXSWITCH' THEN
        DEPKS_RTL_TELLER.PR_AUTH_REVERSAL_REQD(TRUE);
      END IF;
      IF DEPKS_RTL_TELLER.PKG_AUTH_REVERSAL_REQD THEN

        L_AUTHORISE := 'B';
      ELSE
        L_AUTHORISE := 'U';
      END IF;
      DBG('Getting a/c entries BY calling Acpks.fn_acEntry_Retrieval...');

      IF NVL(GWPKS_UTIL.G_TWOSTEPPROCESS, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.G_BRNNEWFLOW, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.G_FIRSTSTEPDONE, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1401' AND
         NVL(GWPKS_UTIL.G_TWOSTEPPROCESSNO, '1') = '1' THEN
        L_CHECK_ENTRIES := FALSE;
      END IF;
      DBG('after setting check entries.');
      IF L_CHECK_ENTRIES THEN
        DBG(' going to check for entries .');

        IF ACPKS_CUSTOM.FN_ACENTRY_RETRIEVAL_RFT(P_TRN_REF_NO, 1, L_AC_ENTS) > 0 THEN
          DBG('Doing the actual reversal...');

          IF L_TRACK_RECEIVABLE = 'Y' OR L_SETTLE_COUNT > 0 THEN

            IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'N' THEN
              DBG(' Before Call to pr_update_tracked_balances ');
              PR_UPDATE_TRACKED_BALANCES(P_TRN_REF_NO);
            END IF;
            DBG('After Call to pr_update_tracked_balances ');
          END IF;

          PR_CHARGE_REVERSAL(L_AC_ENTS);

          DBG('L_AC_ENTS.COUNT=' || L_AC_ENTS.COUNT);

          FOR L_RECNO IN L_AC_ENTS.FIRST .. L_AC_ENTS.LAST LOOP
            L_AC_ENTS(L_RECNO).EVENT_SR_NO := 2;
            L_AC_ENTS(L_RECNO).EVENT := 'REVR';
            L_AC_ENTS(L_RECNO).FCY_AMOUNT := L_AC_ENTS(L_RECNO)
                                             .FCY_AMOUNT * -1;
            L_AC_ENTS(L_RECNO).LCY_AMOUNT := L_AC_ENTS(L_RECNO)
                                             .LCY_AMOUNT * -1;

            DBG('gwpks_util.g_branch_date:::' || GWPKS_UTIL.G_BRANCH_DATE);
            DBG('global.application_date:::' || GLOBAL.APPLICATION_DATE);
            IF GWPKS_UTIL.G_BRANCH_DATE > GLOBAL.APPLICATION_DATE AND
               GWPKS_UTIL.G_FROM_BEAN THEN
              L_AC_ENTS(L_RECNO).TRN_DT := GWPKS_UTIL.G_BRANCH_DATE;
            ELSE
              L_AC_ENTS(L_RECNO).TRN_DT := GLOBAL.APPLICATION_DATE;
            END IF;

            L_AC_ENTS(L_RECNO).USER_ID := NVL(L_AC_ENTS(L_RECNO).USER_ID,
                                              GLOBAL.USER_ID);

            IF NOT GWPKS_UTIL.G_FROM_BEAN THEN

              L_AC_ENTS(L_RECNO).TRN_DT := GLOBAL.APPLICATION_DATE;
            END IF;

            L_AC_ENTS(L_RECNO).USER_ID := NVL(L_AC_ENTS(L_RECNO).USER_ID,
                                              GLOBAL.USER_ID);
          END LOOP;
          IF CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
            DBG('Setting l_auth_stat as B since g_auto_ac_closure is true ...');
            L_AUTH_STAT := 'B';
          END IF;
          DBG('Putting back the reversal entries BY calling Acpks.fn_achandoff...');

          IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
            L_AUTHORISE := 'B';
            DBG('THE ACTION CODE FLAG IS FORCEFULLY SET TO B ' ||
                L_AUTHORISE);
          END IF;

          IF NOT ACPKS.FN_ACHANDOFF(P_TRN_REF_NO,
                                    2,
                                    GLOBAL.APPLICATION_DATE,
                                    L_AC_ENTS,
                                    L_AUTHORISE,
                                    'N',
                                    'Y',
                                    GLOBAL.USER_ID,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
            DBG('Failed IN Acpks.fn_achandoff OF fn_reversal IN Depks_Rtl_Teller...');
            DBG('Rolling back to savepoint rtl reverse');
            ROLLBACK TO RTL_REVERSE;
            RETURN FALSE;
          END IF;

          DBG('Cspks_Req_Global.g_Release_Type :::: ' ||
              CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            DBG('p_trn_ref_no while calling depks_rtl_teller_cluster.fn_reverse ::::: ' ||
                P_TRN_REF_NO);
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_FN_CALL_ID      := 1;
            IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_REVERSE(P_TRN_REF_NO,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
              DBG('Failed inside depks_rtl_teller_cluster.Fn_Save');
              DBG('Rolling back to savepoint rtl reverse');
              ROLLBACK TO RTL_REVERSE;
              RETURN FALSE;
            END IF;
          END IF;

        ELSE
          DBG('No entries corresponding TO this p_trn_ref_no IN actb_daily_log...');
          DBG('Rolling back to savepoint rtl reverse');
          ROLLBACK TO RTL_REVERSE;
          RETURN FALSE;
        END IF;

        BEGIN
          SELECT COUNT(*)
            INTO L_REV_UTIL
            FROM STTB_CUST_LIMIT_TRACKING
           WHERE CONTRACT_REF_NO = P_TRN_REF_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
                P_TRN_REF_NO || '~' || SQLERRM);
        END;

        IF L_REV_UTIL > 0 THEN
          BEGIN
            SELECT BRANCH_CODE, PRODUCT_CODE
              INTO L_BRANCH, L_PRODUCT_CODE
              FROM DETBS_RTL_TELLER
             WHERE TRN_REF_NO = P_TRN_REF_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
                  P_TRN_REF_NO || '~' || SQLERRM);
              P_ERR_CODE := 'DE-TUD-002';
              ROLLBACK TO RTL_REVERSE;
              RETURN FALSE;
          END;

          SELECT MODULE, PRODUCT_GROUP
            INTO L_MODULE, L_PRDGRP
            FROM CSTM_PRODUCT
           WHERE PRODUCT_CODE = L_PRODUCT_CODE;

          DBG('l_module' || L_MODULE);

          IF NOT
              STPKS_CUST_RESTR_UTIL_TRACK.FN_PROCESS_CHK_LIMIT(L_SCODE,
                                                               L_MODULE,
                                                               L_BRANCH,
                                                               P_TRN_REF_NO,
                                                               NULL,
                                                               NULL,
                                                               L_EVENT_CODE,
                                                               1,
                                                               L_PRDGRP,
                                                               L_TRN_DATE,
                                                               NULL,
                                                               '',
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               'D',
                                                               V_TBL_RESTR,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAM) THEN
            DBG('error Code' || P_ERR_CODE);
            DBG('error params' || P_ERR_PARAM);
          ELSE
            DBG('NTHNG');
          END IF;
        END IF;

      END IF;
    ELSE

      IF L_SETTLE_COUNT > 0 THEN
        DBG('Cannot proceed to reversal with l_settle_count ' ||
            L_SETTLE_COUNT);
        DBG('This TRANSACTION is NSF tracked Hence cannot be reversed...');
        L_ON_ERROR := TRUE;
      ELSE
        DBG('This TRANSACTION IS unauthorised AND can NOT be reversed...');
        L_ON_ERROR := TRUE;
      END IF;

    END IF;

    IF L_ON_ERROR THEN
      DBG('Reversal cannot be processed ');
      DBG('contract_ref_no --->' || P_TRN_REF_NO);
      P_ERR_CODE := 'DE-TUD-945';
      DBG('Rolling back to savepoint rtl reverse');
      ROLLBACK TO RTL_REVERSE;
      RETURN FALSE;
    END IF;

    DBG('Now UPDATING the Record_stat OF detbs_rtl_teller FOR the trn_ref_no...' ||
        P_TRN_REF_NO);

    IF L_AUTHORISE = 'B' THEN
      L_CHECKER_DT_STAMP := FN_SYSDATE;
      L_CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE +
                            (L_CHECKER_DT_STAMP - TRUNC(L_CHECKER_DT_STAMP));
      DBG('Checker date stamp is' || L_CHECKER_DT_STAMP);

      UPDATE DETBS_RTL_TELLER
         SET RECORD_STAT = 'V',
             AUTH_STAT   = 'A',

             CHECKER_ID       = NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID),
             CHECKER_DT_STAMP = L_CHECKER_DT_STAMP,

             REVR_DT = GLOBAL.APPLICATION_DATE

       WHERE ROWID = L_ROWID;
    ELSE

      --Get the maker id from iftb_rft_master table
      BEGIN
        SELECT *
          INTO L_IFTB_RFT_MASTER
          FROM IFTB_RFT_MASTER
         WHERE TRN_REF_NO = P_TRN_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          L_IFTB_RFT_MASTER := NULL;
      END;

      DBG('L_IFTB_RFT_MASTER.MAKER_ID=' || L_IFTB_RFT_MASTER.MAKER_ID);

      UPDATE DETBS_RTL_TELLER
         SET RECORD_STAT      = 'V',
             AUTH_STAT        = 'U',
             MAKER_ID         = L_IFTB_RFT_MASTER.MAKER_ID,
             MAKER_DT_STAMP   = L_IFTB_RFT_MASTER.MAKER_DT_STAMP,
             CHECKER_ID = GLOBAL.USER_ID,--NULL,
             CHECKER_DT_STAMP = FN_SYSDATE--L_CHECKER_DT_STAMP--NULL

            ,
             REVR_DT = GLOBAL.APPLICATION_DATE

       WHERE TRN_REF_NO = L_IFTB_RFT_MASTER.TRN_REF_NO;
       --ROWID = L_ROWID;

    END IF;
    DBG('RECORD stat IS updated FOR the trn_ref_no IN detbs_rtl_teller...' ||
        P_TRN_REF_NO);
    RETURN TRUE;
  END FN_REVERSE;

  FUNCTION fn_process_entries(p_ifdrftpm  IN OUT ifpks_ifdrftpm_main.ty_ifdrftpm,
                              p_action    CHAR,
                              p_errcode   IN OUT VARCHAR2,
                              p_errparams IN OUT VARCHAR2) RETURN BOOLEAN IS
    CURSOR cur_acc IS
      SELECT t.trn_ref_no, t.event_sr_no, t.ac_ccy, t.ac_branch, t.user_id
        FROM actb_daily_log t, iftb_rft_master t1
       WHERE t.trn_ref_no = t1.trn_ref_no
         AND t.trn_ref_no = p_ifdrftpm.v_iftbs_rft_master.trn_ref_no
         AND t.event_sr_no = 1
         AND t.auth_stat <> 'A';
    i           NUMBER := 0;
    l_terminate BOOLEAN := FALSE;
  BEGIN
    dbg('In fn_process_entries with ' ||
        p_ifdrftpm.v_iftbs_rft_master.trn_ref_no || '~~~' || p_action);
    IF p_action NOT IN ('D', 'A') THEN
      dbg('Action code not in Delete or Auth...Return TRUE now');
      RETURN TRUE;
    END IF;
    FOR c1 IN cur_acc LOOP
      i := 0;
      IF acpkss.fn_acservice(c1.ac_branch,
                             global.application_date,
                             global.lcy,
                             c1.trn_ref_no,
                             c1.event_sr_no,
                             p_action,
                             global.user_id, --c1.user_id,
                             p_errcode,
                             p_errparams) THEN
        dbg('SUCCESS - ' || c1.trn_ref_no);
      ELSE
        dbg('ERROR - ' || c1.trn_ref_no || SQLERRM);
        dbg('ERROR - ' || p_errcode || '~~~' || p_errparams);
        l_terminate := TRUE;
        dbg('After setting l_terminate to TRUE and leave the LOOP');
        EXIT;
      END IF;
      UPDATE detbs_rtl_teller
         SET auth_stat        = 'A',
             checker_id       = global.user_id,
             checker_dt_stamp = csfn_timestamp,
             record_stat      = decode(record_stat, 'O', 'A', record_stat),
             mod_no           = 1
       WHERE trn_ref_no = c1.trn_ref_no;

      i := i + 1;
      dbg('COUNT-->' || i);
    END LOOP;
    IF NOT l_terminate THEN
      dbg('AUTH is fine...Return TRUE now ');
      RETURN TRUE;
    ELSE
      dbg('AUTH is NOT fine...Return FALSE now ');
      RETURN FALSE;
    END IF;
    dbg('Leaving fn_process_entries now....');
  END fn_process_entries;

  FUNCTION fn_enrich_product(p_ifdrftpm   IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
    l_serial_no    VARCHAR2(16);
    l_trn_ref_no   iftb_rft_master.trn_ref_no%TYPE;
    l_ty_rtupld    depks_retailtellerupload.typ_retailtellerupld_rec;
    l_ret          BOOLEAN;
    l_tot_chg_amt  NUMBER(22, 3);
    l_rel_customer sttm_customer.customer_no%TYPE;
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_ib_flag      VARCHAR2(1) DEFAULT 'Y';
    l_arc_maint    iftm_arc_maint%ROWTYPE;
    l_prod         cstm_product%ROWTYPE;
    l_rate         NUMBER;
    l_charge_amt   NUMBER := 0;
    l_rate_flag    NUMBER;
    l_ccy1         iftb_rft_master.txn_ccy%TYPE;
    l_ccy2         iftb_rft_master.txn_ccy%TYPE;

    l_tot_chg_amount            iftb_rft_master.net_txn_amt%TYPE;
    l_txn_amt                   iftb_rft_master.txn_amt%TYPE;
    l_txn_amt1                  iftb_rft_master.txn_amt%TYPE;
    l_rate_code                 cstm_product.rate_code_preferred%Type;
    l_rate_code1                cstm_product.rate_code_preferred%Type;
    l_tot_chg_amt_in_txn_ccy    iftb_rft_master.txn_amt%TYPE;
    l_tot_chg_amt_in_lcy_ccy    iftb_rft_master.txn_amt%TYPE;
    l_arc_rate_code_type        iftm_arc_maint.cod_rate_code%Type;
    l_tot_chg_amount_in_txn_ccy iftb_rft_master.txn_amt%TYPE;
    l_tot_chg_amount_in_acc_ccy iftb_rft_master.txn_amt%TYPE;
    L_STTB_ACCOUNT              STTB_ACCOUNT%ROWTYPE;
    L_STTM_CUST_ACCOUNT         STTM_CUST_ACCOUNT%ROWTYPE;
  BEGIN

    dbg('In FN_ENRICH_PRODUCT');

    p_ifdrftpm.v_iftbs_rft_master.msg_flow := 'O';

    --Validate
    IF P_IFDRFTPM.V_IFTBS_RFT_MASTER.TXN_CCY = 'USD' AND
       P_IFDRFTPM.V_IFTBS_RFT_MASTER.TXN_AMT > 50000 THEN

      dbg('Transaction Amount Can not be greater than 50K USD');

      p_err_code := 'IF-RFT-012';

      pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

      RETURN FALSE;

    END IF;

    IF P_IFDRFTPM.V_IFTBS_RFT_MASTER.TXN_CCY = 'KHR' AND
       P_IFDRFTPM.V_IFTBS_RFT_MASTER.TXN_AMT > 200000000 THEN

      dbg('Transaction Amount Can not be greater than 200 Million KHR');

      p_err_code := 'IF-RFT-013';

      pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

      RETURN FALSE;

    END IF;

    --Get Account details
    BEGIN
      SELECT *
        INTO L_STTB_ACCOUNT
        FROM STTB_ACCOUNT
       WHERE AC_GL_NO = p_ifdrftpm.v_iftbs_rft_master.rem_acc;

    EXCEPTION
      WHEN OTHERS THEN
        L_STTB_ACCOUNT := NULL;
        DBG('FAILED IN GETTING ACCOUNT DETAILS');
    END;

    --Get Account details
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = p_ifdrftpm.v_iftbs_rft_master.rem_acc;

    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
        DBG('FAILED IN GETTING ACCOUNT DETAILS');
    END;

    /*IF P_IFDRFTPM.V_IFTBS_RFT_MASTER.TXN_CCY <> L_STTM_CUST_ACCOUNT.CCY THEN

      dbg('Transaction Currency must be same as Account Currency');
      p_err_code := 'IF-RFT-005';

      pr_log_error('IFDRFTPP', 'FLEXCUBE', p_err_code, NULL);

      RETURN FALSE;
    END IF;*/

    IF L_STTB_ACCOUNT.AC_STAT_DORMANT = 'Y' THEN
      dbg('Account Status is Dormant');
      p_err_code   := 'AC-VAC33';
      p_err_params := 'Status';
      RETURN FALSE;
    END IF;

    IF L_STTB_ACCOUNT.AC_STAT_NO_DR = 'Y' THEN
      dbg('Account Status is No Debit');
      p_err_code   := 'AC-VAC07';
      p_err_params := 'Status';
      RETURN FALSE;
    END IF;

    IF L_STTM_CUST_ACCOUNT.RECORD_STAT = 'C' THEN
      dbg('Account is Closed');
      p_err_code   := 'AC-VAC12';
      p_err_params := L_STTM_CUST_ACCOUNT.CUST_AC_NO;
      RETURN FALSE;
    END IF;

    IF L_STTB_ACCOUNT.AC_STAT_FROZEN = 'Y' THEN
      dbg('Account Status is Frozen');
      p_err_code   := 'AC-VAC04';
      p_err_params := 'Status';
      RETURN FALSE;
    END IF;

    IF p_ifdrftpm.v_iftbs_rft_master.product_code IS NULL THEN
      dbg('Mandatory Field Product Code cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Product Code';
      RETURN FALSE;
    END IF;
    IF p_ifdrftpm.v_iftbs_rft_master.txn_ccy IS NULL THEN
      dbg('Mandatory Fields Transaction Currency cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Transaction Currency';
      RETURN FALSE;
    END IF;
    IF p_ifdrftpm.v_iftbs_rft_master.txn_amt IS NULL THEN
      dbg('Mandatory Fields Transaction Amount cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Transaction Amount';
      RETURN FALSE;
    END IF;
    IF p_ifdrftpm.v_iftbs_rft_master.rem_acc IS NULL THEN
      dbg('Mandatory Fields Remitter Account cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Remitter Account';
      RETURN FALSE;
    END IF;

    IF p_ifdrftpm.v_iftbs_rft_master.rem_acc IS NULL THEN
      dbg('Mandatory Fields Remitter Account cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Remitter Account';
      RETURN FALSE;
    END IF;

    IF p_ifdrftpm.v_iftbs_rft_master.ben_bic IS NULL THEN
      dbg('Mandatory Fields beneficiary bank code cannot be null');
      p_err_code := 'IF-RFT-020';
      --p_err_params := 'Remitter Account';
      RETURN FALSE;
    END IF;

    IF p_ifdrftpm.v_iftbs_rft_master.ben_acc IS NULL THEN
      dbg('Mandatory Fields beneficiary Account cannot be null');
      p_err_code := 'IF-RFT-021';
      --p_err_params := 'Remitter Account';
      RETURN FALSE;
    END IF;

    -- reference no
    IF p_ifdrftpm.v_iftbs_rft_master.trn_ref_no IS NULL THEN
      IF NOT trpkss.fn_get_product_refno(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                         p_ifdrftpm.v_iftbs_rft_master.product_code,
                                         p_ifdrftpm.v_iftbs_rft_master.transfer_date,
                                         l_serial_no,
                                         l_trn_ref_no,
                                         p_err_code) THEN
        dbg('Failed in generation Transaction Ref No');
        RETURN FALSE;
      ELSE
        dbg('l_trn_ref_no=' || l_trn_ref_no);
        p_ifdrftpm.v_iftbs_rft_master.trn_ref_no := l_trn_ref_no;

      END IF;
    END IF;

    -- charge pickup
    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdrftpm.v_iftbs_rft_master.product_code;

    SELECT cust_no, ccy
      INTO l_rel_customer, l_ac_ccy
      FROM sttm_cust_account
     WHERE cust_ac_no = p_ifdrftpm.v_iftbs_rft_master.rem_acc;

    dbg('got l_rel_customer' || l_rel_customer);

    IF NOT
        cspkss_arc.fn_charge_pickup(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                    p_ifdrftpm.v_iftbs_rft_master.product_code,
                                    'P',
                                    p_ifdrftpm.v_iftbs_rft_master.product_code,
                                    p_ifdrftpm.v_iftbs_rft_master.txn_ccy,
                                    l_rel_customer,
                                    p_ifdrftpm.v_iftbs_rft_master.txn_ccy,
                                    p_ifdrftpm.v_iftbs_rft_master.txn_amt,
                                    l_prod.rate_type_preferred,
                                    l_prod.rate_code_preferred,
                                    NULL,
                                    l_rel_customer,
                                    l_ib_flag,
                                    l_arc_maint,
                                    p_err_code,
                                    p_err_params,
                                    p_ifdrftpm.v_iftbs_rft_master.rem_acc,
                                    p_ifdrftpm.v_iftbs_rft_master.branch_code) THEN
      dbg('CHARGE PICKUP failed');
      RETURN FALSE;
    END IF;

    DBG('l_arc_maint.cod_chg_amt =' || l_arc_maint.cod_chg_amt);

    /*IF l_arc_maint.cod_chg_track_prf = 'W' THEN

      l_arc_maint.cod_chg_amt := null; --0;

    END IF;

    IF l_arc_maint.cod_chg_track_prf1 = 'W' THEN

      l_arc_maint.cod_chg_amt1 := null; --0;

    END IF;*/

    --Charge1
    IF l_arc_maint.cod_chg_amt IS NOT NULL THEN
      DBG('Populating Charge 1');

      p_ifdrftpm.v_iftbs_rft_charge(1).trn_ref_no := p_ifdrftpm.v_iftbs_rft_master.trn_ref_no;
      p_ifdrftpm.v_iftbs_rft_charge(1).chg_srno := 1;
      p_ifdrftpm.v_iftbs_rft_charge(1).chg1_desc := l_arc_maint.cod_chg_desc;
      p_ifdrftpm.v_iftbs_rft_charge(1).chg1_waiver := 'N';
      p_ifdrftpm.v_iftbs_rft_charge(1).chg1_amt := case
                                                    l_arc_maint.cod_chg_track_prf
                                                     when 'W' then
                                                      0
                                                     else
                                                      l_arc_maint.cod_chg_amt
                                                   end; --waive charges fix

      p_ifdrftpm.v_iftbs_rft_charge(1).chg1_ccy := l_arc_maint.cod_chg_ccy;

      DBG('p_ifdrftpm.v_iftbs_rft_charge(1).trn_ref_no=' || p_ifdrftpm.v_iftbs_rft_charge(1)
          .trn_ref_no);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(1).chg_srno=' || p_ifdrftpm.v_iftbs_rft_charge(1)
          .chg_srno);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(1).chg1_desc=' || p_ifdrftpm.v_iftbs_rft_charge(1)
          .chg1_desc);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(1).chg1_waiver=' || p_ifdrftpm.v_iftbs_rft_charge(1)
          .chg1_waiver);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(1).chg1_amt=' || p_ifdrftpm.v_iftbs_rft_charge(1)
          .chg1_amt);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(1).chg1_ccy=' || p_ifdrftpm.v_iftbs_rft_charge(1)
          .chg1_ccy);

      DBG('p_ifdrftpm.v_iftbs_rft_charge.count=' ||
          p_ifdrftpm.v_iftbs_rft_charge.count);

      DBG('global.lcy=' || global.lcy);
      DBG('l_arc_maint.cod_chg_ccy=' || l_arc_maint.cod_chg_ccy);

      -- Converting charge into local ccy for display in charge tab
      IF l_arc_maint.cod_chg_ccy <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                   l_arc_maint.cod_chg_ccy,
                                   global.lcy,
                                   l_prod.rate_type_preferred,
                                   l_prod.rate_code_preferred,
                                   p_ifdrftpm.v_iftbs_rft_charge(1).chg1_amt, --l_arc_maint.cod_chg_amt, --waive charges fix
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpm.v_iftbs_rft_charge(1).lcy_chg1 := l_charge_amt;
        p_ifdrftpm.v_iftbs_rft_charge(1).xrate := l_rate;
      ELSE
        p_ifdrftpm.v_iftbs_rft_charge(1).lcy_chg1 := p_ifdrftpm.v_iftbs_rft_charge(1)
                                                     .chg1_amt; --l_arc_maint.cod_chg_amt, --waive charges fix
        p_ifdrftpm.v_iftbs_rft_charge(1).xrate := 1;
      END IF;
      dbg('Amount 1 in Local ccy->' || p_ifdrftpm.v_iftbs_rft_charge(1)
          .lcy_chg1);

      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy <> p_ifdrftpm.v_iftbs_rft_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                   l_arc_maint.cod_chg_ccy,
                                   p_ifdrftpm.v_iftbs_rft_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   p_ifdrftpm.v_iftbs_rft_charge(1).chg1_amt, --l_arc_maint.cod_chg_amt, --waive charges fix
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpm.v_iftbs_rft_charge(1).chg1_in_txn := l_charge_amt;
        p_ifdrftpm.v_iftbs_rft_charge(1).txn_xrate := l_rate;
        dbg(' * Amount 1 in TXN ccy->' || p_ifdrftpm.v_iftbs_rft_charge(1)
            .chg1_in_txn);
      ELSE
        p_ifdrftpm.v_iftbs_rft_charge(1).chg1_in_txn := p_ifdrftpm.v_iftbs_rft_charge(1)
                                                        .chg1_amt; --l_arc_maint.cod_chg_amt; --waive charges fix
        p_ifdrftpm.v_iftbs_rft_charge(1).txn_xrate := 1;
        dbg('** Amount 1 in TXN ccy->' || p_ifdrftpm.v_iftbs_rft_charge(1)
            .chg1_in_txn);
      END IF;

      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                   l_arc_maint.cod_chg_ccy,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   p_ifdrftpm.v_iftbs_rft_charge(1).chg1_amt, --l_arc_maint.cod_chg_amt, --waive charges fix
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpm.v_iftbs_rft_charge(1).chg1_in_acc := l_charge_amt;
        p_ifdrftpm.v_iftbs_rft_charge(1).acc_xrate := l_rate;
        dbg('* Amount 1 in acc ccy->' || p_ifdrftpm.v_iftbs_rft_charge(1)
            .chg1_in_acc);
      ELSE
        p_ifdrftpm.v_iftbs_rft_charge(1).chg1_in_acc := p_ifdrftpm.v_iftbs_rft_charge(1)
                                                        .chg1_amt; --l_arc_maint.cod_chg_amt; --waive charges fix
        p_ifdrftpm.v_iftbs_rft_charge(1).acc_xrate := 1;
        dbg('** Amount 1 in acc ccy->' || p_ifdrftpm.v_iftbs_rft_charge(1)
            .chg1_in_acc);
      END IF;
    END IF;

    --Charge2
    IF l_arc_maint.cod_chg_amt1 IS NOT NULL THEN
      DBG('Populating Charge 2');
      p_ifdrftpm.v_iftbs_rft_charge(2).trn_ref_no := p_ifdrftpm.v_iftbs_rft_master.trn_ref_no;
      p_ifdrftpm.v_iftbs_rft_charge(2).chg_srno := 2;
      p_ifdrftpm.v_iftbs_rft_charge(2).chg2_desc := l_arc_maint.cod_chg_desc1;
      p_ifdrftpm.v_iftbs_rft_charge(2).chg2_waiver := 'N';
      p_ifdrftpm.v_iftbs_rft_charge(2).chg2_amt := case
                                                    l_arc_maint.cod_chg_track_prf1
                                                     when 'W' then
                                                      0
                                                     else
                                                      l_arc_maint.cod_chg_amt1
                                                   end; --waive charges fix
      p_ifdrftpm.v_iftbs_rft_charge(2).chg2_ccy := l_arc_maint.cod_chg_ccy1;

      DBG('p_ifdrftpm.v_iftbs_rft_charge(2).trn_ref_no=' || p_ifdrftpm.v_iftbs_rft_charge(2)
          .trn_ref_no);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(2).chg_srno=' || p_ifdrftpm.v_iftbs_rft_charge(2)
          .chg_srno);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(2).chg2_desc=' || p_ifdrftpm.v_iftbs_rft_charge(2)
          .chg2_desc);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(2).chg2_waiver=' || p_ifdrftpm.v_iftbs_rft_charge(2)
          .chg2_waiver);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(2).chg2_amt=' || p_ifdrftpm.v_iftbs_rft_charge(2)
          .chg2_amt);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(2).chg2_ccy=' || p_ifdrftpm.v_iftbs_rft_charge(2)
          .chg2_ccy);

      IF l_arc_maint.cod_chg_ccy1 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                   l_arc_maint.cod_chg_ccy1,
                                   global.lcy,
                                   l_prod.rate_type_preferred,
                                   l_prod.rate_code_preferred,
                                   p_ifdrftpm.v_iftbs_rft_charge(2).chg2_amt, --l_arc_maint.cod_chg_amt1, --waive charges fix
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpm.v_iftbs_rft_charge(2).lcy_chg2 := l_charge_amt;
        p_ifdrftpm.v_iftbs_rft_charge(2).xrate := l_rate;
      ELSE
        p_ifdrftpm.v_iftbs_rft_charge(2).lcy_chg2 := p_ifdrftpm.v_iftbs_rft_charge(2)
                                                     .chg2_amt; --l_arc_maint.cod_chg_amt1; --waive charges fix
        p_ifdrftpm.v_iftbs_rft_charge(2).xrate := 1;
      END IF;

      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy1 <> p_ifdrftpm.v_iftbs_rft_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                   l_arc_maint.cod_chg_ccy1,
                                   p_ifdrftpm.v_iftbs_rft_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type1, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   p_ifdrftpm.v_iftbs_rft_charge(2).chg2_amt, --l_arc_maint.cod_chg_amt1, --waive charges fix
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpm.v_iftbs_rft_charge(2).chg2_in_txn := l_charge_amt;
        p_ifdrftpm.v_iftbs_rft_charge(2).txn_xrate := l_rate;
        dbg('* Amount 2 in TXN ccy->' || p_ifdrftpm.v_iftbs_rft_charge(2)
            .chg2_in_txn);
      ELSE
        p_ifdrftpm.v_iftbs_rft_charge(2).chg2_in_txn := p_ifdrftpm.v_iftbs_rft_charge(2)
                                                        .chg2_amt; --l_arc_maint.cod_chg_amt1; --waive charges fix
        p_ifdrftpm.v_iftbs_rft_charge(2).txn_xrate := 1;
        dbg('** Amount 2 in TXN ccy->' || p_ifdrftpm.v_iftbs_rft_charge(2)
            .chg2_in_txn);
      END IF;

      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy1 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                   l_arc_maint.cod_chg_ccy1,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type1, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   p_ifdrftpm.v_iftbs_rft_charge(2).chg2_amt, --l_arc_maint.cod_chg_amt1, --waive charges fix
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpm.v_iftbs_rft_charge(2).chg2_in_acc := l_charge_amt;
        p_ifdrftpm.v_iftbs_rft_charge(2).acc_xrate := l_rate;
        dbg('* Amount 2 in acc ccy->' || p_ifdrftpm.v_iftbs_rft_charge(2)
            .chg2_in_acc);
      ELSE
        p_ifdrftpm.v_iftbs_rft_charge(2).chg2_in_acc := p_ifdrftpm.v_iftbs_rft_charge(2)
                                                        .chg2_amt; --l_arc_maint.cod_chg_amt1; --waive charges fix
        p_ifdrftpm.v_iftbs_rft_charge(2).acc_xrate := 1;
        dbg('** Amount 2 in acc ccy->' || p_ifdrftpm.v_iftbs_rft_charge(2)
            .chg2_in_acc);
      END IF;
      p_ifdrftpm.v_iftbs_rft_charge(2).oth_ccy := l_arc_maint.cod_chg_ccy1;

    END IF;

    --Charge3
    /*IF l_arc_maint.cod_chg_amt2 IS NOT NULL THEN
      DBG('Populating Charge 3');
      p_ifdrftpm.v_iftbs_rft_charge(3).trn_ref_no := p_ifdrftpm.v_iftbs_rft_master.trn_ref_no;
      p_ifdrftpm.v_iftbs_rft_charge(3).chg_srno := 3;
      p_ifdrftpm.v_iftbs_rft_charge(3).chg3_desc := l_arc_maint.cod_chg_desc2;
      p_ifdrftpm.v_iftbs_rft_charge(3).chg3_waiver := 'N';
      p_ifdrftpm.v_iftbs_rft_charge(3).chg3_amt := l_arc_maint.cod_chg_amt2;
      p_ifdrftpm.v_iftbs_rft_charge(3).chg3_ccy := l_arc_maint.cod_chg_ccy2;

      DBG('p_ifdrftpm.v_iftbs_rft_charge(3).trn_ref_no=' || p_ifdrftpm.v_iftbs_rft_charge(3)
          .trn_ref_no);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(3).chg_srno=' || p_ifdrftpm.v_iftbs_rft_charge(3)
          .chg_srno);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(3).chg3_desc=' || p_ifdrftpm.v_iftbs_rft_charge(3)
          .chg3_desc);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(3).chg3_waiver=' || p_ifdrftpm.v_iftbs_rft_charge(3)
          .chg3_waiver);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(3).chg3_amt=' || p_ifdrftpm.v_iftbs_rft_charge(3)
          .chg3_amt);
      DBG('p_ifdrftpm.v_iftbs_rft_charge(3).chg3_ccy=' || p_ifdrftpm.v_iftbs_rft_charge(3)
          .chg3_ccy);

      IF l_arc_maint.cod_chg_ccy2 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                      l_arc_maint.cod_chg_ccy2,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt2,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpm.v_iftbs_rft_charge(3).lcy_chg3 := l_charge_amt;
        p_ifdrftpm.v_iftbs_rft_charge(3).xrate := l_rate;
      ELSE
        p_ifdrftpm.v_iftbs_rft_charge(3).lcy_chg3 := l_arc_maint.cod_chg_amt2;
        p_ifdrftpm.v_iftbs_rft_charge(3).xrate := 1;
      END IF;

      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy2 <> p_ifdrftpm.v_iftbs_rft_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                   l_arc_maint.cod_chg_ccy2,
                                   p_ifdrftpm.v_iftbs_rft_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type2, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt2,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpm.v_iftbs_rft_charge(3).chg3_in_txn := l_charge_amt;
        p_ifdrftpm.v_iftbs_rft_charge(3).txn_xrate := l_rate;
        dbg('* Amount 3 in TXN ccy->' || p_ifdrftpm.v_iftbs_rft_charge(3)
            .chg3_in_txn);
      ELSE
        p_ifdrftpm.v_iftbs_rft_charge(3).chg3_in_txn := l_arc_maint.cod_chg_amt2;
        p_ifdrftpm.v_iftbs_rft_charge(3).txn_xrate := 1;
        dbg('** Amount 3 in TXN ccy->' || p_ifdrftpm.v_iftbs_rft_charge(3)
            .chg3_in_txn);
      END IF;

      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy2 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                   l_arc_maint.cod_chg_ccy2,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type2, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt2,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdrftpm.v_iftbs_rft_charge(3).chg3_in_acc := l_charge_amt;
        p_ifdrftpm.v_iftbs_rft_charge(3).acc_xrate := l_rate;
        dbg('* Amount 3 in ACC ccy->' || p_ifdrftpm.v_iftbs_rft_charge(3)
            .chg3_in_acc);
      ELSE
        p_ifdrftpm.v_iftbs_rft_charge(3).chg3_in_acc := l_arc_maint.cod_chg_amt2;
        p_ifdrftpm.v_iftbs_rft_charge(3).acc_xrate := 1;
        dbg('** Amount 3 in ACC ccy->' || p_ifdrftpm.v_iftbs_rft_charge(3)
            .chg3_in_acc);
      END IF;
      p_ifdrftpm.v_iftbs_rft_charge(3).oth_ccy := l_arc_maint.cod_chg_ccy2;
    END IF;*/

    l_tot_chg_amt_in_txn_ccy := nvl(l_tot_chg_amt_in_txn_ccy, 0) +
                                nvl(p_ifdrftpm.v_iftbs_rft_charge(1)
                                    .chg1_in_txn,
                                    0) /*+ nvl(p_ifdrftpm.v_iftbs_rft_charge(2)
                                                                                                                                                                                                                 .chg2_in_txn,
                                                                                                                                                                                                                 0)  + nvl(p_ifdrftpm.v_iftbs_rft_charge(3)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              .chg3_in_txn,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              0)*/
     ;

    dbg('L_TOT_CHG_AMT~p_ifdrftpm.v_iftbs_pgw_master_custom.TXN_CCY~GLOBAL.LCY' ||
        l_tot_chg_amt || '~' || p_ifdrftpm.v_iftbs_rft_master.txn_ccy || '~' ||
        global.lcy);

    dbg('Total charge to be paid in TXN CCY ->' ||
        l_tot_chg_amt_in_txn_ccy);
    p_ifdrftpm.v_iftbs_rft_master.tot_chg_amt := l_tot_chg_amt_in_txn_ccy; -- We are displaying total charge in txn amount only --Tuning of code in charge calculation

    -- Total Charge amount in local and remitter/account ccy
    /*FOR J IN 1 .. p_ifdrftpm.v_iftbs_rft_charge.count LOOP
      dbg('1 l_tot_chg_amt_in_lcy_ccy->' || l_tot_chg_amt_in_lcy_ccy ||
          'p_ifdrftpm.v_iftbs_rft_charge(j).lcy_chg' || p_ifdrftpm.v_iftbs_rft_charge(j)
          .lcy_chg);
      dbg('1 l_tot_chg_amount_in_acc_ccy->' || l_tot_chg_amount_in_acc_ccy ||
          'p_ifdrftpm.v_iftbs_rft_charge(j).chg_in_acc' || p_ifdrftpm.v_iftbs_rft_charge(j)
          .chg_in_acc);
      l_tot_chg_amt_in_lcy_ccy    := nvl(l_tot_chg_amt_in_lcy_ccy, 0) +
                                     nvl(p_ifdrftpm.v_iftbs_rft_charge(j)
                                         .lcy_chg,
                                         0);
      l_tot_chg_amount_in_acc_ccy := nvl(l_tot_chg_amount_in_acc_ccy, 0) +
                                     nvl(p_ifdrftpm.v_iftbs_rft_charge(j)
                                         .chg_in_acc,
                                         0);

      dbg('2 l_tot_chg_amt_in_lcy_ccy->' || l_tot_chg_amt_in_lcy_ccy);
      dbg('2 l_tot_chg_amount_in_acc_ccy->' || l_tot_chg_amount_in_acc_ccy);
    End Loop;*/

    l_tot_chg_amt_in_lcy_ccy    := nvl(l_tot_chg_amt_in_lcy_ccy, 0) +
                                   nvl(p_ifdrftpm.v_iftbs_rft_charge(1)
                                       .lcy_chg1,
                                       0) + nvl(p_ifdrftpm.v_iftbs_rft_charge(2)
                                                .lcy_chg2,
                                                0) /* +
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       nvl(p_ifdrftpm.v_iftbs_rft_charge(3)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           .lcy_chg3,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           0)*/
     ;
    l_tot_chg_amount_in_acc_ccy := nvl(l_tot_chg_amount_in_acc_ccy, 0) +
                                   nvl(p_ifdrftpm.v_iftbs_rft_charge(1)
                                       .chg1_in_acc,
                                       0) /*+ nvl(p_ifdrftpm.v_iftbs_rft_charge(2)
                                                                                .chg2_in_acc,
                                                                                0)  +
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       nvl(p_ifdrftpm.v_iftbs_rft_charge(3)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           .chg3_in_acc,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           0)*/
     ;

    dbg('chgs calculated ->');

    If l_prod.rate_code_preferred = 'B' Then
      l_rate_code := Null;
      If (p_ifdrftpm.v_iftbs_rft_master.txn_ccy = global.lcy and
         l_ac_ccy != global.lcy) OR
         (p_ifdrftpm.v_iftbs_rft_master.txn_ccy != global.lcy and
         l_ac_ccy <> global.lcy and
         p_ifdrftpm.v_iftbs_rft_master.txn_ccy <> l_ac_ccy) Then
        l_rate_code := 'B';

      Else
        l_rate_code := l_prod.rate_code_preferred;
      End If;
    Else
      l_rate_code := l_prod.rate_code_preferred;
    End If;
    dbg('p_ifdrftpm.v_iftbs_rft_master.txn_amt->' ||
        p_ifdrftpm.v_iftbs_rft_master.txn_amt);

    dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
        l_rate_code1);

    If l_ac_ccy <> global.lcy Then
      begin
        select decode(l_rate_code,
                      'B',
                      'S',
                      'S',
                      'B',
                      'M',
                      'M',
                      l_rate_code)
          Into l_rate_code1
          from dual;
      exception
        when others then
          dbg('Exception found l_rate_code-> ' || l_rate_code);
      end;
    End If;
    dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
        l_rate_code1);
    dbg('l_txn_amt l_txn_amt l_txn_amt=' || l_txn_amt);
    -- Total Txn amount in remitter currency
    IF p_ifdrftpm.v_iftbs_rft_master.txn_ccy <> l_ac_ccy THEN
      l_rate := NULL;
      --l_charge_amt := NULL;
      l_txn_amt1 := p_ifdrftpm.v_iftbs_rft_master.txn_amt;
      /*IF NOT cypkss.fn_amt1_to_amt2(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                    p_ifdrftpm.v_iftbs_rft_master.txn_ccy,
                                    l_ac_ccy,
                                    l_prod.rate_type_preferred,
                                    nvl(l_rate_code1, l_rate_code),
                                    l_txn_amt1,
                                    'Y',
                                    l_txn_amt,
                                    l_rate,
                                    p_err_params) THEN
        debug.pr_debug('**', '');
        debug.pr_debug('**', SQLERRM);
        p_err_code   := 'ST-OTHR-001';
        p_err_params := NULL;
        RETURN FALSE;
      END IF;*/

      -- xrate
      IF p_ifdrftpm.v_iftbs_rft_master.txn_ccy <> l_ac_ccy THEN

        IF p_ifdrftpm.v_iftbs_rft_master.txn_ccy = global.lcy THEN
          l_ccy1 := l_ac_ccy;
          l_ccy2 := p_ifdrftpm.v_iftbs_rft_master.txn_ccy;
        ELSE
          l_ccy1 := p_ifdrftpm.v_iftbs_rft_master.txn_ccy;
          l_ccy2 := l_ac_ccy;
        END IF;
        dbg('l_rate_code->' || l_rate_code || 'l_prod.rate_type_preferred' ||
            l_prod.rate_type_preferred);
        dbg('Before p_ifdrftpm.v_iftbs_pgw_master_custom.exch_rate->' ||
            p_ifdrftpm.v_iftbs_rft_master.exch_rate);

        If (p_ifdrftpm.v_iftbs_rft_master.txn_ccy != global.lcy and
           --l_ac_ccy <> global.lcy and
           l_ac_ccy = global.lcy and
           p_ifdrftpm.v_iftbs_rft_master.txn_ccy <> l_ac_ccy) and
           l_prod.rate_code_preferred = 'B' Then
          l_rate_code := 'B'; --l_rate_code := 'S';
        ELSE
          l_rate_code := 'S'; --added else condition
        End If;

        dbg('l_rate_code->' || l_rate_code);

        dbg('l_prod.rate_type_preferred=' || l_prod.rate_type_preferred);

        IF NOT cypkss.fn_getrate(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                 l_ccy2,
                                 l_ccy1, --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                 l_prod.rate_type_preferred,
                                 l_rate_code, --l_prod.rate_code_preferred,
                                 p_ifdrftpm.v_iftbs_rft_master.transfer_date,
                                 p_ifdrftpm.v_iftbs_rft_master.transfer_date,
                                 p_ifdrftpm.v_iftbs_rft_master.exch_rate,
                                 l_rate_flag,
                                 p_err_code) THEN
          dbg('Failed in Fn_GetRate');
          RETURN FALSE;
        END IF;
      ELSE
        p_ifdrftpm.v_iftbs_rft_master.exch_rate := 1;
      END IF;

      DBG('p_ifdrftpm.v_iftbs_rft_master.exch_rate==' ||
          p_ifdrftpm.v_iftbs_rft_master.exch_rate);

      --Using above rate..convert khr to usd amount
      IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdrftpm.v_iftbs_rft_master.txn_ccy,
                                    l_ac_ccy,
                                    l_txn_amt1,
                                    p_ifdrftpm.v_iftbs_rft_master.exch_rate,
                                    'Y',
                                    l_txn_amt,
                                    p_err_params) THEN
        RETURN FALSE;
      END IF;
    ELSE
      p_ifdrftpm.v_iftbs_rft_master.exch_rate := 1;
    END IF;
    dbg('Final txn_amt->' || l_txn_amt || 'Final chg_amount->' ||
        l_tot_chg_amount);
    dbg('Total Charges in local ccy->' || l_tot_chg_amt_in_lcy_ccy);
    dbg('Total Charges in txn ccy->' || l_tot_chg_amount_in_txn_ccy);
    dbg('Total Charges in acc ccy->' || l_tot_chg_amount_in_acc_ccy);

    -- Net DB Amount (Charges + Txn amount)
    If p_ifdrftpm.v_iftbs_rft_master.txn_ccy <> l_ac_ccy Then
      dbg('apple');
      p_ifdrftpm.v_iftbs_rft_master.net_txn_amt := nvl(l_txn_amt, 0) +
                                                   (Nvl(l_tot_chg_amount_in_acc_ccy,
                                                        0));

    Elsif p_ifdrftpm.v_iftbs_rft_master.txn_ccy = l_ac_ccy Then
      dbg('mango');
      p_ifdrftpm.v_iftbs_rft_master.net_txn_amt := nvl(p_ifdrftpm.v_iftbs_rft_master.txn_amt,
                                                       0) +
                                                   (Nvl(l_tot_chg_amount_in_acc_ccy,
                                                        0));

    End If;
    dbg('p_ifdrftpm.v_iftbs_rft_master.net_txn_amt->' ||
        p_ifdrftpm.v_iftbs_rft_master.net_txn_amt);

    dbg('got l_rel_customer' || l_rel_customer);

    dbg('Returning Success From FN_ENRICH_PRODUCT..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.FN_ENRICH_PRODUCT ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_enrich_product;
  FUNCTION FN_RFT_TXN_SAVE(p_ifdrftpm IN OUT ifpks_ifdrftpm_main.ty_ifdrftpm,

                           pkg_detb_rtl_teller_rec IN OUT detbs_rtl_teller%ROWTYPE,
                           p_err_code              IN OUT VARCHAR2,
                           p_err_params            IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    l_cust_ac           sttm_cust_account%ROWTYPE;
    l_arc_maint         iftms_arc_maint%ROWTYPE;
    l_cust              sttm_customer%ROWTYPE;
    l_prod              cstm_product%ROWTYPE;
    l_ib_flag           VARCHAR2(1) DEFAULT 'Y';
    l_txn_amt           iftbs_rft_master.txn_amt%TYPE;
    l_txn_amt1          iftbs_rft_master.txn_amt%TYPE;
    l_rate              NUMBER;
    l_rate_code         cstm_product.rate_code_preferred%Type;
    l_rate_code1        cstm_product.rate_code_preferred%Type;
    L_STTM_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;

  BEGIN
    dbg('INSIDE FN_RFT_TXN_SAVE');

    --Enrich once again
    IF NOT fn_enrich_product(p_ifdrftpm, p_err_code, p_err_params) THEN
      dbg('Failed in Fn_Enrich_Product');
      RETURN FALSE;
    END IF;

    --Get Account details
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = p_ifdrftpm.v_iftbs_rft_master.rem_acc;

    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
        DBG('FAILED IN GETTING ACCOUNT DETAILS');
    END;

    /*IF P_IFDRFTPM.V_IFTBS_RFT_MASTER.TXN_CCY <> L_STTM_CUST_ACCOUNT.CCY THEN

      dbg('Transaction Currency must be same as Account Currency');
      p_err_code := 'IF-RFT-005';

      pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

      RETURN FALSE;
    END IF;*/

    IF P_IFDRFTPM.V_IFTBS_RFT_MASTER.TXN_CCY = 'USD' AND
       P_IFDRFTPM.V_IFTBS_RFT_MASTER.TXN_AMT > 50000 THEN

      dbg('Transaction Amount Can not be greater than 50K USD');

      p_err_code := 'IF-RFT-012';

      pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

      RETURN FALSE;

    END IF;

    IF P_IFDRFTPM.V_IFTBS_RFT_MASTER.TXN_CCY = 'KHR' AND
       P_IFDRFTPM.V_IFTBS_RFT_MASTER.TXN_AMT > 200000000 THEN

      dbg('Transaction Amount Can not be greater than 200 Million KHR');

      p_err_code := 'IF-RFT-013';

      pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

      RETURN FALSE;

    END IF;

    DBG('PKG_ARC_ROW.COD_CHG_TYPE2 1=' ||
        DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE2);

    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdrftpm.v_iftbs_rft_master.product_code;

    SELECT x.*
      INTO l_cust_ac
      FROM sttm_cust_account x
     WHERE x.cust_ac_no = p_ifdrftpm.v_iftbs_rft_master.rem_acc;

    SELECT x.*
      INTO l_cust
      FROM sttm_customer x
     WHERE x.customer_no = l_cust_ac.cust_no;

    cspkss_arc.pr_get_arc_row(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                              p_ifdrftpm.v_iftbs_rft_master.product_code,
                              'P',
                              '*.*', -- trans_type
                              p_ifdrftpm.v_iftbs_rft_master.txn_ccy,
                              l_ib_flag,
                              l_arc_maint,
                              p_err_code,
                              p_err_params,
                              p_ifdrftpm.v_iftbs_rft_master.rem_acc,
                              p_ifdrftpm.v_iftbs_rft_master.branch_code);

    DBG('PKG_ARC_ROW.COD_CHG_TYPE2 1=' ||
        DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE2);

    IF p_err_code IS NOT NULL THEN
      dbg('CSPKSS_ARC.PR_GET_ARC_ROW returned false');
      RETURN FALSE;
    END IF;

    IF NOT
        cspkss_arc.fn_charge_pickup(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                    p_ifdrftpm.v_iftbs_rft_master.product_code,
                                    'P',
                                    p_ifdrftpm.v_iftbs_rft_master.product_code,
                                    p_ifdrftpm.v_iftbs_rft_master.txn_ccy,
                                    l_cust_ac.cust_no,
                                    p_ifdrftpm.v_iftbs_rft_master.txn_ccy,
                                    p_ifdrftpm.v_iftbs_rft_master.txn_amt,
                                    l_prod.rate_type_preferred,
                                    l_prod.rate_code_preferred,
                                    NULL,
                                    l_cust_ac.cust_no,
                                    l_ib_flag,
                                    depks_rtl_teller.pkg_arc_row,
                                    p_err_code,
                                    p_err_params,
                                    p_ifdrftpm.v_iftbs_rft_master.rem_acc,
                                    p_ifdrftpm.v_iftbs_rft_master.branch_code) THEN
      dbg('CHARGE PICKUP failed');
      RETURN FALSE;
    END IF;

    DBG('PKG_ARC_ROW.COD_CHG_TYPE2 after charge pickup=' ||
        DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE2);

    pkg_detb_rtl_teller_rec.xref         := p_ifdrftpm.v_iftbs_rft_master.trn_ref_no;
    pkg_detb_rtl_teller_rec.product_code := p_ifdrftpm.v_iftbs_rft_master.product_code;
    pkg_detb_rtl_teller_rec.branch_code  := p_ifdrftpm.v_iftbs_rft_master.branch_code;
    pkg_detb_rtl_teller_rec.trn_ref_no   := p_ifdrftpm.v_iftbs_rft_master.trn_ref_no;

    pkg_detb_rtl_teller_rec.txn_acc := p_ifdrftpm.v_iftbs_rft_master.rem_acc;
    pkg_detb_rtl_teller_rec.txn_ccy := l_cust_ac.ccy;
    --pkg_detb_rtl_teller_rec.txn_branch := p_ifdrftpm.v_iftbs_rft_master.branch_code;
    pkg_detb_rtl_teller_rec.txn_branch := l_cust_ac.branch_code;

    pkg_detb_rtl_teller_rec.ofs_acc    := l_arc_maint.cod_offset_acc;
    pkg_detb_rtl_teller_rec.ofs_ccy    := p_ifdrftpm.v_iftbs_rft_master.txn_ccy;
    pkg_detb_rtl_teller_rec.ofs_amount := p_ifdrftpm.v_iftbs_rft_master.txn_amt;
    /* pkg_detb_rtl_teller_rec.ofs_branch := REPLACE(l_arc_maint.cod_offset_brn,
                                                    '*.*',
                                                    p_ifdrftpm.v_iftbs_rft_master.branch_code);
    */
    --Get Nostro Account Branch for the offset leg
    BEGIN
      SELECT BRANCH_CODE
        INTO pkg_detb_rtl_teller_rec.ofs_branch
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = pkg_detb_rtl_teller_rec.ofs_acc;
    EXCEPTION
      WHEN OTHERS THEN
        pkg_detb_rtl_teller_rec.ofs_branch := '991';
    END;

    -- Begin ACCOUNTING ENTRIES Display and fix for Wrong Exch calculation
    IF p_ifdrftpm.v_iftbs_rft_master.txn_ccy <> l_cust_ac.ccy THEN
      l_rate     := NULL;
      l_txn_amt1 := p_ifdrftpm.v_iftbs_rft_master.txn_amt;

      If l_prod.rate_code_preferred = 'B' --and p_ifdrftpm.v_iftbs_rft_master.transfer_mode in ('F')
       Then
        l_rate_code := Null;
        If (p_ifdrftpm.v_iftbs_rft_master.txn_ccy = global.lcy and
           l_cust_ac.ccy != global.lcy) Or
           (p_ifdrftpm.v_iftbs_rft_master.txn_ccy != global.lcy and
           l_cust_ac.ccy <> global.lcy and
           p_ifdrftpm.v_iftbs_rft_master.txn_ccy <> l_cust_ac.ccy) Then
          l_rate_code := 'B';
        Elsif p_ifdrftpm.v_iftbs_rft_master.txn_ccy != global.lcy and
              l_cust_ac.ccy = global.lcy --and p_ifdrftpm.v_iftbs_rft_master.transfer_mode = 'L'
         Then
          l_rate_code := 'S';
        Else
          l_rate_code := l_prod.rate_code_preferred;
        End If;
      Else
        l_rate_code := l_prod.rate_code_preferred;
      End If;

      dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
          l_rate_code1);
      If l_cust_ac.ccy <> global.lcy Then
        begin
          select decode(l_rate_code,
                        'B',
                        'S',
                        'S',
                        'B',
                        'M',
                        'M',
                        l_rate_code)
            Into l_rate_code1
            from dual;
        exception
          when others then
            dbg('Exception found l_rate_code-> ' || l_rate_code);
        end;
      End If;
      dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
          l_rate_code1);

      IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdrftpm.v_iftbs_rft_master.txn_ccy,
                                    l_cust_ac.ccy,
                                    l_txn_amt1,
                                    p_ifdrftpm.v_iftbs_rft_master.exch_rate,
                                    'Y',
                                    l_txn_amt,
                                    p_err_params) THEN
        RETURN FALSE;
      END IF;
    END IF;
    dbg('l_txn_amt1->' || l_txn_amt1);
    dbg('l_txn_amt1->' || l_txn_amt);
    pkg_detb_rtl_teller_rec.txn_amount := l_txn_amt;
    -- END

    pkg_detb_rtl_teller_rec.txn_trn_code     := l_arc_maint.cod_main_txn_code;
    pkg_detb_rtl_teller_rec.ofs_trn_code     := l_arc_maint.cod_offset_txn_code;
    pkg_detb_rtl_teller_rec.exch_rate        := p_ifdrftpm.v_iftbs_rft_master.exch_rate;
    pkg_detb_rtl_teller_rec.trn_dt           := p_ifdrftpm.v_iftbs_rft_master.transfer_date;
    pkg_detb_rtl_teller_rec.value_dt         := p_ifdrftpm.v_iftbs_rft_master.transfer_date;
    pkg_detb_rtl_teller_rec.rel_customer     := l_cust_ac.cust_no;
    pkg_detb_rtl_teller_rec.benef_name       := l_cust.customer_name1;
    pkg_detb_rtl_teller_rec.benef_addr1      := l_cust.address_line1;
    pkg_detb_rtl_teller_rec.benef_addr2      := l_cust.address_line2;
    pkg_detb_rtl_teller_rec.benef_addr3      := l_cust.address_line3;
    pkg_detb_rtl_teller_rec.benef_addr4      := l_cust.address_line4;
    pkg_detb_rtl_teller_rec.liqn_dt          := p_ifdrftpm.v_iftbs_rft_master.transfer_date;
    pkg_detb_rtl_teller_rec.record_stat      := 'A';
    pkg_detb_rtl_teller_rec.auth_stat        := 'U';
    pkg_detb_rtl_teller_rec.maker_id         := GLOBAL.USER_ID; --p_ifdrftpm.v_iftbs_rft_master.maker_id;
    pkg_detb_rtl_teller_rec.maker_dt_stamp   := p_ifdrftpm.v_iftbs_rft_master.maker_dt_stamp;
    pkg_detb_rtl_teller_rec.checker_id       := p_ifdrftpm.v_iftbs_rft_master.checker_id;
    pkg_detb_rtl_teller_rec.checker_dt_stamp := p_ifdrftpm.v_iftbs_rft_master.checker_dt_stamp;
    pkg_detb_rtl_teller_rec.mod_no           := p_ifdrftpm.v_iftbs_rft_master.mod_no;
    pkg_detb_rtl_teller_rec.scode            := 'FLEXCUBE';
    pkg_detb_rtl_teller_rec.dr_acc           := l_arc_maint.dr_acc;
    pkg_detb_rtl_teller_rec.module           := 'RT';
    pkg_detb_rtl_teller_rec.esn              := 1;
    pkg_detb_rtl_teller_rec.event_code       := 'INIT';
    pkg_detb_rtl_teller_rec.track_receivable := 'N';
    pkg_detb_rtl_teller_rec.time_received    := SYSDATE;

    DBG('p_ifdrftpm.v_iftbs_rft_charge.count=' ||
        p_ifdrftpm.v_iftbs_rft_charge.count);

    -- 1
    FOR k IN 1 .. p_ifdrftpm.v_iftbs_rft_charge.count LOOP
      IF k = 1 THEN
        dbg('CHG AMT' || p_ifdrftpm.v_iftbs_rft_charge(k).chg1_amt);
        pkg_detb_rtl_teller_rec.charge_account := p_ifdrftpm.v_iftbs_rft_master.rem_acc;

        pkg_detb_rtl_teller_rec.chg_gl           := l_arc_maint.cod_chg_gl;
        pkg_detb_rtl_teller_rec.chg_ccy          := l_arc_maint.cod_chg_ccy;
        pkg_detb_rtl_teller_rec.chg_amt          := p_ifdrftpm.v_iftbs_rft_charge(k)
                                                    .chg1_amt;
        depks_rtl_teller.pkg_arc_row.cod_chg_amt := p_ifdrftpm.v_iftbs_rft_charge(k)
                                                    .chg1_amt;

        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt);
        depks_rtl_teller.pkg_arc_row.cod_chg_type := l_arc_maint.cod_chg_type;

        IF l_arc_maint.cod_chg_ccy <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                     l_arc_maint.cod_chg_ccy,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdrftpm.v_iftbs_rft_charge(k).chg1_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;

        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy       := p_ifdrftpm.v_iftbs_rft_charge(k)
                                                      .chg1_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate := 1;
        END IF;

        DBG('pkg_detb_rtl_teller_rec.chg_in_acy=' ||
            pkg_detb_rtl_teller_rec.chg_in_acy);
        DBG('pkg_detb_rtl_teller_rec.chg_ccy_acy_rate=' ||
            pkg_detb_rtl_teller_rec.chg_ccy_acy_rate);

        pkg_detb_rtl_teller_rec.chg_in_lcy   := p_ifdrftpm.v_iftbs_rft_charge(k)
                                                .lcy_chg1;
        pkg_detb_rtl_teller_rec.acy_lcy_rate := p_ifdrftpm.v_iftbs_rft_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind  := l_arc_maint.cod_chg_netting;
        pkg_detb_rtl_teller_rec.txn_code     := l_arc_maint.cod_chg_txn_code;
        pkg_detb_rtl_teller_rec.mis_head_1   := l_arc_maint.cod_mis_head;
        pkg_detb_rtl_teller_rec.chg_desc     := l_arc_maint.cod_chg_desc;
        pkg_detb_rtl_teller_rec.chg_type     := l_arc_maint.cod_chg_type;
        pkg_detb_rtl_teller_rec.waiver       := p_ifdrftpm.v_iftbs_rft_charge(k)
                                                .chg1_waiver;
        pkg_detb_rtl_teller_rec.their_chgs   := l_arc_maint.cod_their_chgs;
      END IF;
      -- 2
      IF k = 2 THEN
        pkg_detb_rtl_teller_rec.chg_gl_1  := l_arc_maint.cod_chg_gl1;
        pkg_detb_rtl_teller_rec.chg_ccy_1 := l_arc_maint.cod_chg_ccy1;
        pkg_detb_rtl_teller_rec.chg_amt_1 := p_ifdrftpm.v_iftbs_rft_charge(k)
                                             .chg2_amt;

        depks_rtl_teller.pkg_arc_row.cod_chg_amt1 := p_ifdrftpm.v_iftbs_rft_charge(k)
                                                     .chg2_amt;

        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT1' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt1);
        depks_rtl_teller.pkg_arc_row.cod_chg_type1 := l_arc_maint.cod_chg_type1;

        IF l_arc_maint.cod_chg_ccy1 <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdrftpm.v_iftbs_rft_master.branch_code,
                                     l_arc_maint.cod_chg_ccy1,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdrftpm.v_iftbs_rft_charge(k).chg2_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy_1,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_1       := p_ifdrftpm.v_iftbs_rft_charge(k)
                                                        .chg2_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1 := 1;
        END IF;

        pkg_detb_rtl_teller_rec.chg_in_lcy_1   := p_ifdrftpm.v_iftbs_rft_charge(k)
                                                  .lcy_chg2;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_1 := p_ifdrftpm.v_iftbs_rft_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_1  := l_arc_maint.cod_chg_netting1;
        pkg_detb_rtl_teller_rec.txn_code_1     := l_arc_maint.cod_chg_txn_code1;
        pkg_detb_rtl_teller_rec.mis_head_2     := l_arc_maint.cod_mis_head1;
        pkg_detb_rtl_teller_rec.chg_desc1      := l_arc_maint.cod_chg_desc1;
        pkg_detb_rtl_teller_rec.chg_type1      := l_arc_maint.cod_chg_type1;
        pkg_detb_rtl_teller_rec.waiver1        := p_ifdrftpm.v_iftbs_rft_charge(k)
                                                  .chg2_waiver;
        pkg_detb_rtl_teller_rec.their_chgs1    := l_arc_maint.cod_their_chgs1;
      END IF;

    END LOOP;

    dbg('Calling depks_rtl_teller.fn_save');

    DBG('PKG_ARC_ROW.COD_CHG_TYPE2 1=' ||
        DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE2);

    IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                    p_err_code,
                                    p_err_params) THEN
      dbg('Failed in Fn_Save');
      RETURN FALSE;
    END IF;
    dbg('Calling depks_rtl_teller.pr_messaging');
    --depks_rtl_teller.pr_messaging;

    dbg('Returning Success From FN_RFT_TXN_SAVE..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.FN_RFT_TXN_SAVE ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END FN_RFT_TXN_SAVE;

  FUNCTION FN_RFT_HTTP_CALL(p_rft_call in varchar2,
                            p_out_msg  VARCHAR2,
                            p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS

    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255); -- := 'http://10.80.80.11:8282/prnc-app/nbc/rft-out/rcpt-acct-inq';
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);

    /*content varchar2(4000) := '{
        "chnlCd": "01",
        "sndAcctNo": "000162694",
        "sndNm": "borey1111111111111111111111111111111",
        "rcvBkCd": "001",
        "rcvAcctNo": "11111111111111111",
        "crrcy": "KHR",
        "amt": "2000"
    }';*/

    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;

  BEGIN
    dbg('START OF FN_RFT_HTTP_CALL');

    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_RFT_TIMEOUT'));

    IF P_RFT_CALL = 'I' THEN
      L_URL := FN_GET_PARAM_VAL('PGW_NBC_RFT_ACC_ENQ_URL');
    ELSIF P_RFT_CALL = 'A' THEN
      L_URL := FN_GET_PARAM_VAL('PGW_NBC_RFT_OUT_BY_ACC_URL');
    ELSIF P_RFT_CALL = 'C' THEN
      L_URL := FN_GET_PARAM_VAL('PGW_NBC_RFT_OUT_CANCEL_URL');
    ELSIF P_RFT_CALL = 'G' THEN
      L_URL := FN_GET_PARAM_VAL('PGW_NBC_RFT_TXN_STAT_ENQ_URL');
    END IF;

    DBG('l_url-->' || L_URL);

    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');

    utl_http.set_authentication(l_http_request,
                                FN_GET_PARAM_VAL('PGW_NBC_RFT_AUTH_UID'),
                                FN_GET_PARAM_VAL('PGW_NBC_RFT_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));

    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');

    utl_http.set_transfer_timeout(300);

    utl_http.write_text(l_http_request, p_out_msg);

    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));

    l_http_response := utl_http.get_response(l_http_request);

    dbg('Response> status_code: "' || l_http_response.status_code || '"');

    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;

    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;

    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;

      p_in_resp := buffer1;

      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);

    END IF;

    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;

    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;

    dbms_lob.freetemporary(buffer1); --buffer2 may be check

    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('error line number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_RFT_HTTP_CALL;

  FUNCTION FN_RFT_REVERSE(p_ifdrftpm IN ifpks_ifdrftpm_main.ty_ifdrftpm)
    RETURN BOOLEAN IS

    P_ERR_CODE         ERTB_MSGS.ERR_CODE%TYPE;
    P_ERR_PARAM        ERTB_MSGS.MESSAGE%TYPE;
    L_FORMATTED_MSG    CLOB;
    L_IN_RESP          CLOB;
    L_COSMETIC_RES_MSG CLOB;
    L_GEN_SEQ_NO       VARCHAR2(100);
    L_COUNT            NUMBER;

    P_DOCUMENT_XML  XMLTYPE;
    L_RESP_IN_XML   CLOB;
    L_RESPONSE_CODE IFTBS_RFT_MASTER.TXN_STATUS%TYPE;
    L_RESPONSE_MSG  IFTBS_RFT_MASTER.TXN_REMARKS%TYPE;

  BEGIN

    DEBUG.PR_DEBUG('IF', 'START OF FN_RFT_REVERSE');

    --Go for Cancellation API
    --Get Cancel Message
    L_FORMATTED_MSG := FN_RETURN_FORMATTED_CANCEL_MSG(P_IFDRFTPM); --REPLACE(L_FORMATTED_MSG, '$L_MSG_ID', L_MSG_ID);

    DBG('AFTER REPLACEMENT OF CANCEL MSG=' || L_FORMATTED_MSG);

    --Log Cancel Request of RFT

    DBG('LOGGING CANCEL REQUEST OF RFT');

    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

    PR_INSERT_RFT_CANCEL_WS_LOG(L_GEN_SEQ_NO,
                                p_ifdrftpm.v_iftbs_rft_master.trn_ref_no,
                                SYSDATE,
                                'Cancel',
                                L_FORMATTED_MSG,
                                'Cancel of RFT');

    IF NOT IFPKS_IFDRFTPM_CUSTOM.FN_RFT_HTTP_CALL('C',
                                                  L_FORMATTED_MSG,
                                                  L_IN_RESP) THEN

      DBG('FAILED IN CALLING THE CANCELLATION API');

      RETURN FALSE;

    ELSE

      DBG('RESPONSE OF CANCELLATION IN JSON IS ' || L_IN_RESP);

      --Get JSON in XML
      L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
      DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

      L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
      DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);

      L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;;', '>');
      DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);

      DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);

      P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

      L_RESPONSE_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                         .GETSTRINGVAL;

      L_RESPONSE_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                        .GETSTRINGVAL;

      DBG('L_RESPONSE_CODE =' || L_RESPONSE_CODE);
      DBG('L_RESPONSE_MSG =' || L_RESPONSE_MSG);

      IF L_RESPONSE_CODE = 'ERROR_500' THEN

        dbg('RFT Client Module is Down');

        p_err_code := 'IF-RFT-017';

        pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

        RETURN FALSE;

      END IF;

      IF L_RESPONSE_CODE = 'SUCCESS' THEN

        DBG('SUCCESS IN CANCELLING THE ORIGINAL RFT OUTGOING TXN');

        SAVEPOINT REVERSE_POINT;

        IF P_IFDRFTPM.V_IFTBS_RFT_MASTER.TRN_REF_NO IS NOT NULL THEN

          IF NOT FN_REVERSE(p_ifdrftpm.v_iftbs_rft_master.trn_ref_no,
                            P_ERR_CODE,
                            P_ERR_PARAM) THEN

            DBG('FAILED IN REVERSING THE RFT OUTGOING TRANSACTION');
            DBG('P_ERR_CODE=' || P_ERR_CODE);
            DBG('P_ERR_PARAM=' || P_ERR_PARAM);

            ROLLBACK TO REVERSE_POINT;

            RETURN FALSE;

          ELSE

            DBG('SUCCESS IN REVERSING THE RFT OUTGOING TRANSACTION');

            IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(GLOBAL.CURRENT_BRANCH,
                                                        p_ifdrftpm.v_iftbs_rft_master.trn_ref_no,
                                                        GLOBAL.USER_ID,
                                                        GLOBAL.LCY,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAM) THEN
              DBG('AUTH RETURNED FALSE ' || P_ERR_CODE);

              ROLLBACK TO REVERSE_POINT;

              RETURN FALSE;

            ELSE

              RETURN TRUE;

            END IF;

          END IF;
        END IF;

      ELSE

        DBG('FAILED IN CANCELLING THE ORIGINAL RFT OUTGOING TXN');
        RETURN FALSE;

      END IF;

    END IF;

    DBG('END OF FN_RFT_REVERSE');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RFT_REVERSE');
      DBG('ERROR CODE IN FN_RFT_REVERSE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RFT_REVERSE=' || SQLERRM);
      RETURN FALSE;
  END FN_RFT_REVERSE;

  /*FUNCTION FN_AUTH_REVERSAL(P_IFDRFTPM IN ifpks_ifdrftpm_Main.Ty_ifdrftpm)
    RETURN BOOLEAN IS

    P_ERR_CODE         ERTB_MSGS.ERR_CODE%TYPE;
    P_ERR_PARAM        ERTB_MSGS.MESSAGE%TYPE;
    L_FORMATTED_MSG    CLOB;
    L_IN_RESP          CLOB;
    L_COSMETIC_RES_MSG CLOB;
    L_GEN_SEQ_NO       VARCHAR2(100);
    P_DOCUMENT_XML     XMLTYPE;
    L_RESP_IN_XML      CLOB;
    L_RESPONSE_CODE    IFTBS_RFT_MASTER.TXN_STATUS%TYPE;
    L_RESPONSE_MSG     IFTBS_RFT_MASTER.TXN_REMARKS%TYPE;

  BEGIN

    IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(GLOBAL.CURRENT_BRANCH,
                                                p_ifdrftpm.v_iftbs_rft_master.trn_ref_no,
                                                GLOBAL.USER_ID,
                                                GLOBAL.LCY,
                                                P_ERR_CODE,
                                                P_ERR_PARAM) THEN
      DBG('AUTH RETURNED FALSE ' || P_ERR_CODE);
      ROLLBACK TO REVERSE_AUTH_POINT;
      --RETURN FALSE;
    ELSE

      --Get Cancel Message

      L_FORMATTED_MSG := FN_RETURN_FORMATTED_CANCEL_MSG(P_IFDRFTPM); --REPLACE(L_FORMATTED_MSG, '$L_MSG_ID', L_MSG_ID);

      DBG('AFTER REPLACEMENT OF CANCEL MSG=' || L_FORMATTED_MSG);

      --Log Cancel Request of RFT

      DBG('LOGGING CANCEL REQUEST OF RFT');

      L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

      PR_INSERT_RFT_CANCEL_WS_LOG(L_GEN_SEQ_NO,
                                  p_ifdrftpm.v_iftbs_rft_master.trn_ref_no,
                                  SYSDATE,
                                  'Cancel',
                                  L_FORMATTED_MSG,
                                  'Cancel of RFT');

      IF NOT IFPKS_IFDRFTPM_CUSTOM.FN_RFT_HTTP_CALL('C',

                                                    L_FORMATTED_MSG,
                                                    L_IN_RESP) THEN

        DBG('FAILED IN ACKNOWLEDGING THE ORIGINAL INCOMING TXN');

        ROLLBACK TO REVERSE_AUTH_POINT;

      ELSE

        DBG('RESPONSE OF CANCELLATION IN JSON IS ' || L_IN_RESP);

        --Get JSON in XML
        L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
        DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

        L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
        DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);

        L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
        DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);

        DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
            L_RESP_IN_XML);

        P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

        L_RESPONSE_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                           .GETSTRINGVAL;

        L_RESPONSE_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                          .GETSTRINGVAL;

        DBG('L_RESPONSE_CODE =' || L_RESPONSE_CODE);
        DBG('L_RESPONSE_MSG =' || L_RESPONSE_MSG);

        IF L_RESPONSE_CODE = 'SUCCESS' THEN

          DBG('SUCCESS IN CANCELLING THE ORIGINAL RFT OUTGOING TXN');
          COMMIT;

        ELSE

          DBG('FAILED IN CANCELLING THE ORIGINAL RFT OUTGOING TXN');
          ROLLBACK TO REVERSE_AUTH_POINT;
          RETURN FALSE;

        END IF;

        --Convert into XMLTYPE
        -- P_DOCUMENT_XML1 := XMLTYPE(L_COSMETIC_RES_MSG);

        --Get Node Value
        --L_TXN_STATUS := P_DOCUMENT_XML1.EXTRACT('/Document/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/TxSts/text()')
        --               .getstringval;

        --DBG('L_TXN_STATUS=' || L_TXN_STATUS);

        --PR_UPDATE_FAST_WS_LOG(L_MSG_ID,
        --                      L_GEN_SEQ_NO,
        --                     L_TXN_STATUS,
        --                    L_IN_RESP);

        --PR_UPDATE_STATUS_FAST_INCOMING(L_TRN_REF_NO, L_TXN_STATUS);

        --PR_UPDATE_DOC_TRACKER(L_MSG_ID, 'P', P_ERR_CODE, P_ERR_PARAM);

        RETURN TRUE;

      END IF;

    END IF;

  EXCEPTION

    WHEN OTHERS THEN
      DBG('FAILED IN FN_AUTH_REVERSAL');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN FALSE;
  END FN_AUTH_REVERSAL;*/

  FUNCTION FN_MSG_UPLOAD(P_SOURCE      IN VARCHAR2,
                         P_FUNCTION_ID IN VARCHAR2,
                         P_IFDRFTPM    IN OUT IFPKS_IFDRFTPM_MAIN.TY_IFDRFTPM,
                         P_MSG         IN OUT CLOB,
                         P_RFT_CALL    IN VARCHAR2,
                         P_MSG_TYPE    IN VARCHAR2,
                         P_ADDL_INFO   IN VARCHAR2,
                         P_ERR_CODE    IN OUT VARCHAR2,
                         P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_TXNSTATUS_CODE IFTBS_RFT_MASTER.TXN_STATUS%TYPE;
    L_TXNSTATUS_MSG  IFTBS_RFT_MASTER.TXN_REMARKS%TYPE;

    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_SECRET_KEY   VARCHAR2(100);
    L_GEN_SEQ_NO   VARCHAR2(100);

    L_TXN_UNIQUE_NO IFTB_RFT_MASTER_MOB.TXN_UNQ_NO%TYPE;
    L_TRACE_NO      IFTB_RFT_MASTER_MOB.TRACE_NO%TYPE;

    L_BEN_NAME IFTB_RFT_MASTER.BEN_NAME%TYPE;

  BEGIN

    dbg('INSIDE FN_MSG_UPLOAD');

    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);

    --Log Webservice Call
    PR_INSERT_RFT_WS_LOG(L_GEN_SEQ_NO,
                         p_ifdrftpm.v_iftbs_rft_master.trn_ref_no,
                         SYSDATE,
                         P_MSG_TYPE,
                         p_msg,
                         P_ADDL_INFO);

    IF NOT FN_RFT_HTTP_CALL(p_rft_call, p_msg, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;

    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);

    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);

    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);

    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);

    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

    L_TXNSTATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                        .GETSTRINGVAL;

    L_TXNSTATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                       .GETSTRINGVAL;

    DBG('L_TXNSTATUS_CODE =' || L_TXNSTATUS_CODE);
    DBG('L_TXNSTATUS_MSG =' || L_TXNSTATUS_MSG); -- COMMENTED TEMPORARILY FOR OFFSHORE TESTING - ALL TXN TO GO AS ACCEPTED

    IF L_TXNSTATUS_CODE = 'ERROR_104' THEN

      dbg('The sender bank exceeded net debit limit.');

      p_err_code   := 'IF-RFT-019';
      p_err_params := L_TXNSTATUS_MSG;

      --pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, L_TXNSTATUS_MSG);

      RETURN FALSE;

    END IF;

    IF L_TXNSTATUS_CODE = 'ERROR_500' THEN

      dbg('RFT Client Module is Down');

      p_err_code := 'IF-RFT-017';

      pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

      RETURN FALSE;

    END IF;

    IF P_RFT_CALL = 'I' /* AND L_TXNSTATUS_CODE = 'SUCCESS' */
     THEN

      L_SECRET_KEY := P_DOCUMENT_XML.EXTRACT('/root/data/scrtKey/text()')
                      .GETSTRINGVAL;

      DBG('L_SECRET_KEY =' || L_SECRET_KEY);

      L_BEN_NAME := P_DOCUMENT_XML.EXTRACT('/root/data/rcvNm/text()')

                    .GETSTRINGVAL;

      DBG('L_BEN_NAME =' || L_BEN_NAME);

      p_ifdrftpm.v_iftbs_rft_master.ben_name := L_BEN_NAME;

      IF L_SECRET_KEY IS NOT NULL THEN

        P_IFDRFTPM.V_IFTBS_RFT_MASTER.SECRETE_KEY := L_SECRET_KEY;

        --Update webservice call
        PR_UPDATE_RFT_WS_LOG(P_IFDRFTPM.V_IFTBS_RFT_MASTER.TRN_REF_NO,
                             L_GEN_SEQ_NO,
                             L_TXNSTATUS_CODE,
                             L_SECRET_KEY,
                             L_IN_RESP);

      ELSE

        dbg('SECRET KEY CAN BE NOT NULL');

        P_ERR_CODE := 'IF-RFT-008';

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, NULL);

        RETURN FALSE;

      END IF;

    ELSE

      L_TXN_UNIQUE_NO := P_DOCUMENT_XML.EXTRACT('/root/data/txnUnqNo/text()')
                         .GETSTRINGVAL;

      p_ifdrftpm.v_iftbs_rft_master.TXN_UNQ_NO := L_TXN_UNIQUE_NO;

      L_TRACE_NO := P_DOCUMENT_XML.EXTRACT('/root/data/tracNo/text()')
                    .GETSTRINGVAL;

      p_ifdrftpm.v_iftbs_rft_master.TRACE_NO := L_TRACE_NO;

      --Update webservice call
      PR_UPDATE_RFT_WS_LOG(P_IFDRFTPM.V_IFTBS_RFT_MASTER.TRN_REF_NO,
                           L_GEN_SEQ_NO,
                           L_TXNSTATUS_CODE,
                           L_IN_RESP);

    END IF;

    IF L_TXNSTATUS_CODE NOT IN ('SUCCESS') THEN

      DBG('Transaction Rejected. Cannot procede further.');
      P_ERR_CODE   := 'GI-FST-013';
      P_ERR_PARAMS := NULL; --l_rejreason || '~'; Pls check

      IF NOT DEPKS_RTL_TELLER.FN_DELETE(P_IFDRFTPM.V_IFTBS_RFT_MASTER.TRN_REF_NO,
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN

        DBG('FAIED IN DELETING ACCOUNTING ENTRIES');
        RAISE E_UPDATE_ERROR;
      END IF;

      --PR_UPDATE_STATUS_FAST_OUTGOING(p_ifdrftpm.v_iftbs_rft_master.TRN_REF_NO,
      --                           L_TXNSTATUS);

      PR_LOG_ERROR(P_FUNCTION_ID,
                   P_SOURCE,
                   'IF-RFT-028',
                   L_TXNSTATUS_CODE || '~' || NULL); --L_REJREASON);

    ELSE

      IF P_RFT_CALL = 'A' AND L_TXNSTATUS_CODE = 'SUCCESS' THEN

        --Post Accounting Entries only for A
        IF NOT FN_PROCESS_ENTRIES(P_IFDRFTPM, 'A', P_ERR_CODE, P_ERR_PARAMS) THEN
          DBG('FAILED IN AUTH ACCOUNTING ENTRIES');
          RAISE E_UPDATE_ERROR;
        END IF;

      END IF;

    END IF;

    PR_LOG_ERROR(P_FUNCTION_ID,
                 P_SOURCE,
                 'IF-RFT-027',
                 L_TXNSTATUS_CODE || '~' || NULL); --L_REJREASON);

    DBG('Successfully processed fn_msg_upload');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('IN WOT...RETURN FALSE NOW...FAILED IN FN_MSG_UPLOAD' || SQLERRM);
      RETURN FALSE;
  END FN_MSG_UPLOAD;

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdrftpm         IN OUT ifpks_ifdrftpm_Main.ty_ifdrftpm,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Build_type_structure..');

    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of ifpks_ifdrftpm_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION FN_GET_OUTGOING_TXN_BY_ID(P_IFDRFTPM   IN OUT IFPKS_IFDRFTPM_MAIN.TY_IFDRFTPM,
                                     P_UNQ_TXN_ID IN VARCHAR2,
                                     P_ERR_CODE   IN OUT VARCHAR2,
                                     P_ERR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_FORMATTED_MSG    CLOB;
    L_IN_RESP          CLOB;
    L_COSMETIC_RES_MSG CLOB;
    L_GEN_SEQ_NO       VARCHAR2(100);
    L_COUNT            NUMBER;

    P_DOCUMENT_XML  XMLTYPE;
    L_RESP_IN_XML   CLOB;
    L_RESPONSE_CODE IFTBS_RFT_MASTER.TXN_STATUS%TYPE;
    L_RESPONSE_MSG  VARCHAR2(32567);

  BEGIN

    DEBUG.PR_DEBUG('IF', 'START OF FN_GET_OUTGOING_TXN_BY_ID');

    --Get Txn Status API Message
    L_FORMATTED_MSG := FN_RETURN_FMT_TXN_STATUS(P_IFDRFTPM);

    DBG('AFTER REPLACEMENT OF TXN STATUS MSG=' || L_FORMATTED_MSG);

    --Log TXN STATUS Request of RFT

    DBG('LOGGING TXN STATUS REQUEST OF RFT');

    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

    PR_INSERT_RFT_WS_LOG(L_GEN_SEQ_NO,
                         p_ifdrftpm.v_iftbs_rft_master.trn_ref_no,
                         SYSDATE,
                         'GetOutStat',
                         L_FORMATTED_MSG,
                         'Get Outgoing Txn Stat');

    IF NOT IFPKS_IFDRFTPM_CUSTOM.FN_RFT_HTTP_CALL('G',

                                                  L_FORMATTED_MSG,
                                                  L_IN_RESP) THEN

      DBG('FAILED IN CALLING THE GET TXN STATUS API');

      RETURN FALSE;

    ELSE

      DBG('RESPONSE OF GET TXN STATUS IN JSON IS ' || L_IN_RESP);

      --Get JSON in XML
      L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
      DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

      L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
      DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);

      L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;;', '>');
      DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);

      DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);

      P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

      L_RESPONSE_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                         .GETSTRINGVAL;

      L_RESPONSE_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                        .GETSTRINGVAL;

      DBG('L_RESPONSE_CODE =' || L_RESPONSE_CODE);
      DBG('L_RESPONSE_MSG =' || L_RESPONSE_MSG);

      IF L_RESPONSE_CODE = 'ERROR_500' THEN

        dbg('RFT Client Module is Down');

        p_err_code := 'IF-RFT-017';

        pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

        RETURN FALSE;

      END IF;

      IF L_RESPONSE_CODE = 'ERROR_104' THEN

        dbg('There is no original transaction');

        p_err_code := 'IF-RFT-029';

        pr_log_error('IFDRFTXN', 'FLEXCUBE', p_err_code, NULL);

        RETURN FALSE;

      END IF;

      IF L_RESPONSE_CODE = 'SUCCESS' THEN

        DBG('SUCCESS IN CALLING THE GET TXN STATUS OF RFT OUTGOING TXN');

        --Updating Status in the master table
        P_IFDRFTPM.v_iftbs_rft_master.TXN_STATUS  := L_RESPONSE_CODE;
        P_IFDRFTPM.v_iftbs_rft_master.TXN_REMARKS := L_RESPONSE_MSG;

        RETURN TRUE;

      ELSE

        RETURN FALSE;

      END IF;

      --Updating Status in the master table
      P_IFDRFTPM.v_iftbs_rft_master.TXN_STATUS  := L_RESPONSE_CODE;
      P_IFDRFTPM.v_iftbs_rft_master.TXN_REMARKS := L_RESPONSE_MSG;
      --PR_UPDATE_STATUS_FAST_OUTGOING(P_IFDOFAST.V_IFTBS_FAST_MASTER.TRN_REF_NO,
      --                 L_TXNSTATUS);

    END IF;

    DBG('SUCCESSFULLY PROCESSED FN_GET_OUTGOING_TXN_BY_ID');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in FN_GET_OUTGOING_TXN_BY_ID' ||
          SQLERRM);
      RETURN FALSE;

  END FN_GET_OUTGOING_TXN_BY_ID;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdrftpm         IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS

    l_detb_rtl_teller_rec detb_rtl_teller%ROWTYPE;
    l_out_msg             CLOB;

    L_FORMATTED_MSG CLOB;

    L_MSG_TYPE   VARCHAR2(100);
    L_ADDL_INFO  VARCHAR2(100);
    L_GEN_SEQ_NO VARCHAR2(100);
    L_SECRET_KEY VARCHAR2(100);
    
    --AML New Payment Flow Starts
  
    L_REF                   VARCHAR2(16);
    L_SEQ                   NUMBER;
    L_RESPONSE              CLOB;
    L_RESP_IN_XML           CLOB;
    P_DOCUMENT_XML          XMLTYPE;
    L_IN_RESP               CLOB;
    P_HIT_STATUS            VARCHAR2(100);
    P_SCAN_ID               VARCHAR2(100);
    L_CUSTOMER              STTM_CUSTOMER%ROWTYPE;
    L_COUNT                 NUMBER := 0;
    L_STTB_CORAL_RFT_WS_LOG STTB_CORAL_RFT_WS_LOG%ROWTYPE;
    L_SENDER_NAME           STTB_CORAL_RFT_WS_LOG.SENDER_NAME%TYPE;
    L_SENDER_COUNTRY        STTB_CORAL_RFT_WS_LOG.SENDER_HIGH_CNT%TYPE;
    L_BEN_NAME              STTB_CORAL_RFT_WS_LOG.BEN_NAME%TYPE;
    L_BEN_COUNTRY           STTB_CORAL_RFT_WS_LOG.BEN_HIGH_CNT%TYPE;
    --AML New Payment Flow Ends
  

  BEGIN

    dbg('In Fn_Pre_Check_Mandatory' || p_action_code);
    IF p_action_code = 'PICKUP' THEN
      IF NOT fn_enrich_product(p_ifdrftpm, p_err_code, p_err_params) THEN
        dbg('Failed in Fn_Enrich_Product');
        RETURN FALSE;
      END IF;

      --Default Account Name Enquiry
      --Get RFT Out Payment Account Enquiry
      L_FORMATTED_MSG := FN_RETURN_FORMATTED_ACC_ENQ(P_IFDRFTPM);

      DBG('AFTER REPLACEMENT OF RFT OUT ACC ENQUIRY JSON=' ||
          L_FORMATTED_MSG);

      DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

      L_MSG_TYPE  := 'ACCENQUIRY';
      L_ADDL_INFO := 'Account Enquiry Call';

      DBG('CALLING RFT ACCOUNT ENQUIRY WEBSERVICE');

      IF NOT FN_MSG_UPLOAD(P_SOURCE,
                           P_FUNCTION_ID,
                           P_IFDRFTPM,
                           L_FORMATTED_MSG,
                           'I', --ACCOUNT ENQUIRY
                           L_MSG_TYPE,
                           L_ADDL_INFO,
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN

        DBG('FAILED IN ACCOUNT ENQUIRY CALL');

        --Update the table
        PR_UPDATE_RFT_WS_LOG(P_IFDRFTPM.V_IFTBS_RFT_MASTER.TRN_REF_NO,
                             L_GEN_SEQ_NO,
                             P_ERR_CODE,
                             P_ERR_PARAMS);

        RETURN FALSE;

      ELSE

        DBG('SUCCESS IN ACCOUNT ENQUIRY CALL');

        IF p_ifdrftpm.v_iftbs_rft_master.ben_name IS NULL THEN

          DBG('FAILED IN ACCOUNT ENQUIRY CALL');
          pr_log_error(p_function_id, p_source, 'IF-RFT-018', NULL);
          RETURN FALSE;

        END IF;

      END IF;

    END IF;

    --Save Transaction
    IF p_action_code = cspks_req_global.p_new THEN
      
     --AML New Payment Flow Starts
    
      BEGIN
      
        SELECT *
          INTO L_CUSTOMER
          FROM STTM_CUSTOMER
         WHERE CUSTOMER_NO IN
               (SELECT CUST_NO
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = p_ifdrftpm.v_iftbs_rft_master.rem_acc);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CUSTOMER := NULL;
      END;
    
      --check the count
      BEGIN
      
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_CORAL_RFT_WS_LOG A
         WHERE A.SCAN_ID IS NOT NULL
           AND A.REQ_MSG IS NOT NULL
           AND A.RES_MSG IS NOT NULL
           AND A.BEN_NAME = p_ifdrftpm.v_iftbs_rft_master.BEN_NAME
           AND A.BEN_HIGH_CNT = 'KH'
           AND A.FC_REF_NO = p_ifdrftpm.v_iftbs_rft_master.TRN_REF_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          L_COUNT := 0;
        
      END;
    
      DBG('L_COUNT=' || L_COUNT);
    
      IF L_COUNT = 0 THEN
      
        --call api B
      
        IF NOT IFPKS_SANCTION_UTILS.FN_AML_PAYMENT_CALL_B(GLOBAL.user_id,
                                                          GLOBAL.current_branch,
                                                          'OTC',
                                                          
                                                          L_REF,
                                                          p_ifdrftpm.v_iftbs_rft_master.BEN_NAME,
                                                          'KH', --L_HIGH_BEN_CNT,
                                                          FN_GET_BEN_BANK_NAME(p_ifdrftpm.v_iftbs_rft_master.BEN_BIC),
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          p_ifdrftpm.v_iftbs_rft_master.BEN_ADD1 || ' ' ||
                                                          p_ifdrftpm.v_iftbs_rft_master.BEN_ADD2 || ' ' ||
                                                          p_ifdrftpm.v_iftbs_rft_master.BEN_ADD3 || ' ' ||
                                                          p_ifdrftpm.v_iftbs_rft_master.BEN_ADD4,
                                                          NULL,
                                                          p_ifdrftpm.v_iftbs_rft_master.BEN_REMARKS,
                                                          p_ifdrftpm.v_iftbs_rft_master.txn_amt, --100,
                                                          p_ifdrftpm.v_iftbs_rft_master.txn_ccy,
                                                          p_ifdrftpm.v_iftbs_rft_master.BEN_ACC,
                                                          NULL,
                                                          NULL,
                                                          'RFT',
                                                          'RFTP',
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          L_CUSTOMER.Customer_No,
                                                          NULL, --L_SENDER_NAME
                                                          NULL, --L_SENDER_COUNTRY
                                                          p_ifdrftpm.v_iftbs_rft_master.BEN_NAME, --L_BEN_NAME
                                                          'KH', --L_BEN_COUNTRY
                                                          p_ifdrftpm.v_iftbs_rft_master.TRN_REF_NO,
                                                          P_SCAN_ID,
                                                          P_HIT_STATUS,
                                                          L_RESPONSE) THEN
        
          PR_LOG_ERROR('IFDRFTPM',
                         'FLEXCUBE',
                         'IF-AML-001',
                         NULL);
                         
          RETURN FALSE;
        
        ELSE
        
          DBG('P_HIT_STATUS OF API-B =' || P_HIT_STATUS);
        
          DBG('P_SCAN_ID OF API-B=' || P_SCAN_ID);
        
          IF P_HIT_STATUS = 'Y' THEN
          
            PR_LOG_ERROR('IFDOFAST',
                         'FLEXCUBE',
                         'IF-RIA-030',
                         P_SCAN_ID /*|| CASE P_WHO_HIT WHEN 'S' THEN
                                                                                                                                                        'For Sender' WHEN 'R' THEN 'For Beneficiary' WHEN 'B' THEN
                                                                                                                                                        'For Both Sender and Beneficiary' END*/);
          
          END IF;
        
        END IF;
      
      END IF;

      --AML New Payment Flow Ends     
      
      IF NOT FN_RFT_TXN_SAVE(p_ifdrftpm,
                             l_detb_rtl_teller_rec,
                             p_err_code,
                             p_err_params) THEN
        dbg('Failed in FN_SAVE');
        RETURN FALSE;
      END IF;
    END IF;

    --Modify Transaction
    IF p_action_code = cspks_req_global.p_modify THEN
      dbg('Voila 2');

      IF NOT depks_rtl_teller.fn_delete(p_ifdrftpm.v_iftbs_rft_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in modify fn_delete');
        RETURN FALSE;
      END IF;

      IF NOT FN_RFT_TXN_SAVE(p_ifdrftpm,
                             l_detb_rtl_teller_rec,
                             p_err_code,
                             p_err_params) THEN
        dbg('Failed in modify fn_save');
        RETURN FALSE;
      END IF;
    END IF;

    --Delete Transaction
    IF p_action_code = cspks_req_global.p_delete THEN
      IF NOT depks_rtl_teller.fn_delete(p_ifdrftpm.v_iftbs_rft_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in FN_DELETE');
        RETURN FALSE;
      END IF;
    END IF;

    --Auth Transaction
    IF p_action_code = cspks_req_global.p_auth AND
       p_ifdrftpm.v_iftbs_rft_master.MOD_NO = 2 THEN

      IF p_ifdrftpm.v_iftbs_rft_master.BRANCH_CODE <> GLOBAL.CURRENT_BRANCH THEN

        DBG('Authorization can be done only in transaction branch');
        pr_log_error(p_function_id, p_source, 'IF-RFT-026', NULL);
        RETURN FALSE;

      END IF;

      IF NOT FN_RFT_REVERSE(P_IFDRFTPM) THEN
        DBG('TRANSACTION HAS NOT BEEN REVERSED');
        RETURN FALSE;

      ELSE
        DBG('TRANSACTION HAS BEEN REVERSED');
        RETURN TRUE;

      END IF;

      /*SAVEPOINT REVERSE_AUTH_POINT;

      IF NOT FN_AUTH_REVERSAL(p_ifdrftpm) THEN

        ROLLBACK TO REVERSE_AUTH_POINT;
        RETURN FALSE;

      ELSE

        COMMIT;

      END IF;*/

    ELSE
      IF p_action_code = cspks_req_global.p_auth THEN

        DBG('p_ifdrftpm.v_iftbs_rft_master.MAKER_ID=' ||
            p_ifdrftpm.v_iftbs_rft_master.MAKER_ID);
        DBG('p_ifdrftpm.v_iftbs_rft_master.CHECKER_ID=' ||
            p_ifdrftpm.v_iftbs_rft_master.CHECKER_ID);
        DBG('GLOBAL.USER_ID' || GLOBAL.USER_ID);

        DBG('GLOBAL.CURRENT_BRANCH' || GLOBAL.CURRENT_BRANCH);

        IF p_ifdrftpm.v_iftbs_rft_master.BRANCH_CODE <>
           GLOBAL.CURRENT_BRANCH THEN

          DBG('Authorization can be done only in transaction branch');
          pr_log_error(p_function_id, p_source, 'IF-RFT-026', NULL);
          RETURN FALSE;

        END IF;

        --Maker Can not authorize
        IF p_ifdrftpm.v_iftbs_rft_master.MAKER_ID = GLOBAL.USER_ID THEN
          pr_log_error(p_function_id, p_source, 'CF-AUT-002', NULL);
          RETURN FALSE;
        END IF;

        --Get RFT Out Payment Account Enquiry
        L_FORMATTED_MSG := FN_RETURN_FORMATTED_ACC_ENQ(P_IFDRFTPM);

        DBG('AFTER REPLACEMENT OF RFT OUT ACC ENQUIRY JSON=' ||
            L_FORMATTED_MSG);

        DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

        L_MSG_TYPE  := 'ACCENQUIRY';
        L_ADDL_INFO := 'Account Enquiry Call';

        DBG('CALLING RFT ACCOUNT ENQUIRY WEBSERVICE');

        IF NOT FN_MSG_UPLOAD(P_SOURCE,
                             P_FUNCTION_ID,
                             P_IFDRFTPM,
                             L_FORMATTED_MSG,
                             'I', --ACCOUNT ENQUIRY
                             L_MSG_TYPE,
                             L_ADDL_INFO,
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN

          DBG('FAILED IN ACCOUNT ENQUIRY CALL');

          --Update the table
          PR_UPDATE_RFT_WS_LOG(P_IFDRFTPM.V_IFTBS_RFT_MASTER.TRN_REF_NO,
                               L_GEN_SEQ_NO,
                               P_ERR_CODE,
                               P_ERR_PARAMS);

          RETURN FALSE;

        ELSE

          DBG('SUCCESS IN ACCOUNT ENQUIRY CALL');

          --Update the table
          PR_UPDATE_RFT_WS_LOG(P_IFDRFTPM.V_IFTBS_RFT_MASTER.TRN_REF_NO,
                               L_GEN_SEQ_NO,
                               P_ERR_CODE,
                               P_ERR_PARAMS);

          --Get RFT Out Payment Account Enquiry
          L_FORMATTED_MSG := FN_RETURN_FMT_CASA_TRF(P_IFDRFTPM);

          DBG('AFTER REPLACEMENT OF RFT OUT ACC ENQUIRY JSON=' ||
              L_FORMATTED_MSG);

          DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

          DBG('CALLING RFT FUND TRANSFER CALL');

          L_MSG_TYPE  := 'ACCTRF';
          L_ADDL_INFO := 'Account Transfer Call';

          IF NOT FN_MSG_UPLOAD(P_SOURCE,
                               P_FUNCTION_ID,
                               P_IFDRFTPM,
                               L_FORMATTED_MSG,
                               'A', --ACCOUNT ENQUIRY
                               L_MSG_TYPE,
                               L_ADDL_INFO,
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
            DBG('FAILED IN FUND TRANSFER CALL');
            RETURN FALSE;

          ELSE

            DBG('SUCCESS IN FUND TRANSFER CALL');

          END IF;

        END IF;
        DBG('fn_msg_upload successful');

        dbg('Done with upload process, going to generate advice');
        --depks_rtl_teller.pr_gen_adv_for_contract(p_ifdrftpm.v_iftbs_rft_charge.trn_ref_no);
        dbg('Done with advice generation ');
      END IF;
    END IF;

    --Reverse Transaction
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REVERSE THEN

      --Check if cancellation today or not

      IF --TO_CHAR(SYSDATE, 'YYYYMMDD')
       TO_CHAR(P_IFDRFTPM.v_iftbs_rft_master.transfer_date, 'YYYYMMDD') <>
       TO_CHAR(SYSDATE, 'YYYYMMDD') THEN

        dbg('RFT Payment Can Be Cancelled only on the day it is created');
        pr_log_error(p_function_id, p_source, 'IF-RFT-016', NULL);

      END IF;

      P_IFDRFTPM.v_iftbs_rft_master.MAKER_ID       := GLOBAL.user_id;
      P_IFDRFTPM.v_iftbs_rft_master.MAKER_DT_STAMP := FN_SYSDATE;

      /*
      IF NOT FN_RFT_REVERSE(P_IFDRFTPM) THEN
        DBG('TRANSACTION HAS BEEN REVERSED');
      END IF;*/

      PR_POPULATE_RECORD_LOG(P_IFDRFTPM);

    END IF;

    --Get Outgoing Transaction by ID
    IF p_action_code = 'GETOUTTXNSTATUS' THEN

      DBG('CALLING GET TXN STATUS API');
      IF NOT FN_GET_OUTGOING_TXN_BY_ID(p_ifdrftpm,
                                       l_out_msg,
                                       p_err_code,
                                       p_err_params) THEN
        dbg('Failed in fn_msg_upload');
        RETURN FALSE;
      END IF;
    END IF;

    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdrftpm         IN ifpks_ifdrftpm_Main.ty_ifdrftpm,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
  BEGIN

    Dbg('In Fn_Post_Check_Mandatory..');

    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdrftpm         IN ifpks_ifdrftpm_Main.ty_ifdrftpm,
                                       p_Prev_ifdrftpm    IN OUT ifpks_ifdrftpm_Main.ty_ifdrftpm,
                                       p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.ty_ifdrftpm,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    l_result NUMBER(2);
  BEGIN

    Dbg('In Fn_Pre_Default_And_Validate..');

    -- only alpha numeric for rft
    IF p_action_code IN (cspks_req_global.p_new, cspks_req_global.p_modify) THEN
      /* l_result := length(TRIM(translate(p_ifdrftpm.v_iftbs_rft_master.ben_name,
                                        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
                                        ' ')));
      IF l_result > 0 THEN
        dbg('Ben Name is not alpha numeric');
        pr_log_error(p_function_id, p_source, 'IF-FST003', NULL);
      END IF;*/

      IF (p_ifdrftpm.v_iftbs_rft_master.ben_acc IS NULL OR
         --p_ifdrftpm.v_iftbs_rft_master.ben_name IS NULL OR
         p_ifdrftpm.v_iftbs_rft_master.ben_bic IS NULL) THEN
        dbg('Ben Acc, Ben Name, Ben Bic is mandatory for RFT Payment');
        pr_log_error(p_function_id, p_source, 'IF-RFT-006', NULL);
      END IF;

    END IF;

    -- generic vals
    IF p_ifdrftpm.v_iftbs_rft_master.txn_amt < 0 THEN
      dbg('Txn Amount cannot be negative');
      pr_log_error(p_function_id, p_source, 'IF-FST012', NULL);
    END IF;

    /*IF p_ifdrftpm.v_iftbs_rft_master.ben_acc IS NOT NULL THEN
      l_result := length(TRIM(translate(p_ifdrftpm.v_iftbs_rft_master.ben_acc,
                                        '0123456789',
                                        ' ')));
      IF l_result > 0 THEN
        dbg('Ben Account is not numeric for RFT Payments');
        pr_log_error(p_function_id, p_source, 'IF-RFT-007', NULL);
      END IF;
    END IF;*/

    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdrftpm         IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                        p_Prev_ifdrftpm    IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                        p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Default_And_Validate..');

    DBG('p_ifdrftpm.v_iftbs_rft_master.BEN_NAME=' ||
        p_ifdrftpm.v_iftbs_rft_master.BEN_NAME);

    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdrftpm         IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                            p_Prev_ifdrftpm    IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                            p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_KEY_ID VARCHAR2(1000);
  BEGIN

    Dbg('In Fn_Pre_Upload_Db..=' || p_Action_Code);

    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdrftpm         IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                             p_prev_ifdrftpm    IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                             p_wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Upload_Db..');

    IF p_Action_Code = 'AUTH' THEN

      DBG('p_ifdrftpm.v_iftbs_rft_master.BEN_NAME=' ||
          p_ifdrftpm.v_iftbs_rft_master.BEN_NAME);

      BEGIN
        UPDATE IFTB_RFT_MASTER
           SET txn_status  = p_ifdrftpm.v_iftbs_rft_master.txn_status,
               txn_remarks = p_ifdrftpm.v_iftbs_rft_master.txn_remarks,
               TXN_UNQ_NO  = p_ifdrftpm.v_iftbs_rft_master.TXN_UNQ_NO,
               TRACE_NO    = p_ifdrftpm.v_iftbs_rft_master.TRACE_NO,
               BEN_NAME    = p_ifdrftpm.v_iftbs_rft_master.BEN_NAME
         WHERE TRN_REF_NO = p_ifdrftpm.v_iftbs_rft_master.TRN_REF_NO;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN UPDATING MASTER TABLE');
      END;
    END IF;

    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdrftpm         IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                        p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Query..');

    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdrftpm         IN ifpks_ifdrftpm_Main.ty_ifdrftpm,
                         p_wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.ty_ifdrftpm,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Query..');

    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of ifpks_ifdrftpm_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END ifpks_ifdrftpm_custom;
