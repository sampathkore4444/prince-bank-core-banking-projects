CREATE OR REPLACE PACKAGE ifpks_ifdrftpm_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdrftpm_custom.spc
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  --9NT1466 FCUBS 11.3.1 Service Charge Changes starts
  TYPE typ_chgdets_rec IS RECORD(
    cod_chg_desc iftm_arc_maint.cod_chg_desc%TYPE,
    waiver       VARCHAR2(1),
    chg_amt      iftm_arc_maint.cod_chg_amt%TYPE,
    cod_chg_ccy  iftms_arc_maint.cod_chg_ccy%TYPE,
    mis_head     iftms_arc_maint.cod_mis_head%TYPE,
    txn_code     iftms_arc_maint.cod_chg_txn_code%TYPE,
    netting_ind  iftms_arc_maint.cod_chg_netting%TYPE,
    chg_gl       iftms_arc_maint.cod_chg_gl%TYPE);
  TYPE typ_tblchgdets IS TABLE OF typ_chgdets_rec INDEX BY PLS_INTEGER;
  --9NT1466 FCUBS 11.3.1 Service Charge Changes ends.

  PROCEDURE Pr_Skip_Handler(P_Stage IN VARCHAR2);
  FUNCTION Fn_Post_Build_Type_Structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdrftpm         IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdrftpm         IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdrftpm         IN ifpks_ifdrftpm_Main.ty_ifdrftpm,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Pre_Default_And_Validate(p_source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdrftpm         IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                       p_Prev_ifdrftpm    IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                       p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdrftpm         IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                        p_Prev_ifdrftpm    IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                        p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdrftpm         IN ifpks_ifdrftpm_Main.ty_ifdrftpm,
                            p_Prev_ifdrftpm    IN ifpks_ifdrftpm_Main.ty_ifdrftpm,
                            p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.ty_ifdrftpm,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_source_operation IN VARCHAR2,
                             p_Function_id      IN VARCHAR2,
                             p_action_code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdrftpm         IN ifpks_ifdrftpm_Main.ty_ifdrftpm,
                             p_Prev_ifdrftpm    IN ifpks_ifdrftpm_Main.ty_ifdrftpm,
                             p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.ty_ifdrftpm,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdrftpm         IN ifpks_ifdrftpm_Main.ty_ifdrftpm,
                        p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.ty_ifdrftpm,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdrftpm         IN ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                         p_Wrk_ifdrftpm     IN OUT ifpks_ifdrftpm_Main.Ty_ifdrftpm,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN;
  
   --AML New Payment Flow Starts
  FUNCTION FN_GET_BEN_BANK_NAME(P_CODE IN LMTM_TYPE_VALUES.CODE%TYPE)
    RETURN LMTM_TYPE_VALUES.VALUE%TYPE;
  --AML New Payment Flow Ends
  
END ifpks_ifdrftpm_custom;
