CREATE OR REPLACE PACKAGE BODY ifpks_ifdmtapa_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdmtapa_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2021 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  SFR Number         :
  Changed By         :
  Change Description :

  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdmtapa_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdmtapa         IN OUT ifpks_ifdmtapa_Main.ty_ifdmtapa,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Build_type_structure..');

    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of ifpks_ifdmtapa_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION FN_GET_RISK_LEVEL_CNT(P_COUNTRY_CODE IN VARCHAR2) RETURN NUMBER IS
    L_VALUE NUMBER;
  BEGIN
    SELECT DECODE(CODE, 'P', 5, 'V', 4, 'H', 3, 'M', '2', 'L', 1, 5)
      INTO L_VALUE
      FROM LMTM_TYPE_VALUES
     WHERE TYPE = 'RISK_LEVEL_CNT'
       AND VALUE = P_COUNTRY_CODE;

    RETURN L_VALUE;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_VALUE;
  END FN_GET_RISK_LEVEL_CNT;

  FUNCTION FN_GET_CUST_CORPORATE_CNT(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN VARCHAR2 AS

    L_INCORP_CNT STTM_CUST_CORPORATE.INCORP_COUNTRY%TYPE;

  BEGIN

    SELECT e.incorp_country
      INTO L_INCORP_CNT

      FROM sttb_account         a,
           sttm_customer        b,
           sttm_cust_personal   c,
           sttm_customer_custom d,
           sttm_cust_corporate  e
     WHERE a.cust_no = b.customer_no
       AND b.customer_no = c.customer_no
       AND c.customer_no = d.customer_no
       AND b.customer_no = e.customer_no
       AND a.ac_gl_rec_status = 'O'
       AND a.once_auth = 'Y'
       AND a.auth_stat = 'A'
       AND b.record_stat = 'O'
       AND b.auth_stat = 'A'
       AND (ac_or_gl = 'A' AND
           ac_gl_no = P_IFDMTAPA.v_iftb_mta_master.REM_ACC);

    RETURN L_INCORP_CNT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_CUST_CORPORATE_CNT');
      DBG('ERROR CODE IN FN_GET_CUST_CORPORATE_CNT=' || SQLCODE);
      DBG('ERROR MESAAGE IN FN_GET_CUST_CORPORATE_CNT=' || SQLERRM);
      RETURN L_INCORP_CNT;
  END FN_GET_CUST_CORPORATE_CNT;

  FUNCTION FN_GET_NOB_CODE(P_NOB_NAME IN VARCHAR2) RETURN VARCHAR2 AS

    L_NOB_CODE STTB_MTA_STATIC_NOB_CODES.NOB_CODE%type;

  BEGIN

    BEGIN

      SELECT NOB_CODE
        INTO L_NOB_CODE
        FROM STTB_MTA_STATIC_NOB_CODES A
       where A.NOB_NAME = P_NOB_NAME;

      RETURN L_NOB_CODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_NOB_CODE := NULL;
    END;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING NOB CODE');
      DBG('ERROR CODE IN FN_GET_NOB_CODE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_NOB_CODE=' || SQLERRM);
      RETURN L_NOB_CODE;
  END FN_GET_NOB_CODE;

  FUNCTION FN_GET_REMMITANCE_CODE(P_REASON_OF_REMMITANCEE IN VARCHAR2)
    RETURN VARCHAR2 AS

    L_REMITTANCE_CODE STTB_MTA_REMITTANCE_PURPOSE.REMIT_CODE%type;

  BEGIN

    BEGIN

      SELECT REMIT_CODE
        INTO L_REMITTANCE_CODE
        FROM STTB_MTA_REMITTANCE_PURPOSE
       where REMIT_PURPOSE = P_REASON_OF_REMMITANCEE;

      RETURN L_REMITTANCE_CODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_REMITTANCE_CODE := NULL;
    END;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING RESON OF REMITTANCE CODE');
      DBG('ERROR CODE IN FN_GET_REMMITANCE_CODE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_REMMITANCE_CODE=' || SQLERRM);
      RETURN L_REMITTANCE_CODE;
  END FN_GET_REMMITANCE_CODE;

  FUNCTION FN_GET_SEN_OCC_CODE(P_OCC_NAME IN VARCHAR2) RETURN VARCHAR2 AS

    L_OCC_CODE STTB_MTA_STATIS_OCC_CODES.Occ_Code%type;

  BEGIN

    BEGIN

      SELECT OCC_CODE
        INTO L_OCC_CODE
        FROM STTB_MTA_STATIS_OCC_CODES
       where occ_name = P_OCC_NAME
         AND ROWNUM = 1;

      RETURN L_OCC_CODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_OCC_CODE := NULL;
    END;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING OCCUPATION CODE');
      DBG('ERROR CODE IN FN_GET_SEN_OCC_CODE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_SEN_OCC_CODE=' || SQLERRM);
      RETURN L_OCC_CODE;
  END FN_GET_SEN_OCC_CODE;

  FUNCTION FN_GET_BEN_NAT_CODE(P_NATIONALITY_NAME IN VARCHAR2)
    RETURN VARCHAR2 AS

    L_BEN_NAT_CODE STTB_MTA_NATIONALITY_DTLS.COUNTRY_CODE%type;

  BEGIN

    DBG('START OF FN_GET_BEN_NAT_CODE=' || P_NATIONALITY_NAME);

    BEGIN

      SELECT COUNTRY_CODE
        INTO L_BEN_NAT_CODE
        FROM STTB_MTA_NATIONALITY_DTLS
       where nationality = P_NATIONALITY_NAME;

      DBG('L_BEN_NAT_CODE=' || L_BEN_NAT_CODE);

    EXCEPTION
      WHEN OTHERS THEN
        L_BEN_NAT_CODE := NULL;
    END;

    RETURN L_BEN_NAT_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_BEN_NAT_CODE');
      DBG('ERROR CODE IN FN_GET_BEN_NAT_CODE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_BEN_NAT_CODE=' || SQLERRM);
      RETURN L_BEN_NAT_CODE;
  END FN_GET_BEN_NAT_CODE;

  FUNCTION FN_GET_BEN_NAT_ISO_CODE(P_NATIONALITY_NAME IN VARCHAR2)
    RETURN VARCHAR2 AS

    L_BEN_NAT_ISO_CODE STTB_MTA_NATIONALITY_DTLS.ISO_COUNTRY_CODE%type;

  BEGIN

    DBG('START OF FN_GET_BEN_NAT_CODE=' || P_NATIONALITY_NAME);

    BEGIN

      SELECT ISO_COUNTRY_CODE
        INTO L_BEN_NAT_ISO_CODE
        FROM STTB_MTA_NATIONALITY_DTLS
       where nationality = P_NATIONALITY_NAME;

      DBG('L_BEN_NAT_ISO_CODE=' || L_BEN_NAT_ISO_CODE);

    EXCEPTION
      WHEN OTHERS THEN
        L_BEN_NAT_ISO_CODE := NULL;
    END;

    RETURN L_BEN_NAT_ISO_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_BEN_NAT_ISO_CODE');
      DBG('ERROR CODE IN FN_GET_BEN_NAT_ISO_CODE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_BEN_NAT_ISO_CODE=' || SQLERRM);
      RETURN L_BEN_NAT_ISO_CODE;
  END FN_GET_BEN_NAT_ISO_CODE;

  FUNCTION FN_AML_VALIDATION(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN BOOLEAN AS

    L_CUSTOMER           STTM_CUSTOMER%ROWTYPE;
    L_CUST_TYPE          VARCHAR2(100);
    L_SENDER_NATIONALITY STTM_CUSTOMER.NATIONALITY%TYPE;
    L_COUNTRY_FROM       STTM_CUSTOMER.NATIONALITY%TYPE;
    L_COUNTRY_TO         VARCHAR2(100); --STTM_CUSTOMER.NATIONALITY%TYPE; pls check
    L_SENDER_FIRST_NAME  STTM_CUST_PERSONAL.FIRST_NAME%TYPE;
    L_SENDER_LAST_NAME   STTM_CUST_PERSONAL.LAST_NAME%TYPE;
    P_HIT_STATUS         VARCHAR2(100);
    P_WHO_HIT            CHAR(1);
    L_REG_ADDR_COUNTRY   STTM_CUSTOMER.NATIONALITY%TYPE;
    P_SCAN_ID            VARCHAR2(100);
    P_ERR_CODE           VARCHAR2(100);
    P_ERR_PARAM          VARCHAR2(100);
    L_BEN_NATIONALITY    STTM_CUSTOMER.NATIONALITY%TYPE;
    L_BEN_NAME           STTM_CUSTOMER.FULL_NAME%TYPE;

    TYPE TYPE_RISK_SCORE IS VARRAY(5) OF INTEGER;
    L_RISK_SCORE   TYPE_RISK_SCORE;
    L_MAX_INDEX    NUMBER;
    L_MAX_VALUE    NUMBER;
    L_HIGH_SEN_CNT STTM_CUSTOMER.NATIONALITY%TYPE;
    L_HIGH_BEN_CNT STTM_CUSTOMER.NATIONALITY%TYPE;

  BEGIN

    --Get Customer Type
    BEGIN

      SELECT *
        INTO L_CUSTOMER
        FROM STTM_CUSTOMER
       WHERE CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = p_ifdmtapa.v_iftb_mta_master.Rem_acc);

    EXCEPTION
      WHEN OTHERS THEN
        L_CUSTOMER := NULL;
    END;

    DBG('L_CUSTOMER.CUSTOMER_TYPE=' || L_CUSTOMER.CUSTOMER_TYPE);

    IF L_CUSTOMER.CUSTOMER_TYPE = 'I' THEN

      BEGIN
        SELECT B.FIRST_NAME, B.LAST_NAME
          INTO L_SENDER_FIRST_NAME, L_SENDER_LAST_NAME
          FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
         WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
           AND A.CUSTOMER_NO IN
               (SELECT CUST_NO
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
      EXCEPTION
        WHEN OTHERS THEN
          L_SENDER_FIRST_NAME := NULL;
          L_SENDER_LAST_NAME  := NULL;
      END;

    ELSIF L_CUSTOMER.CUSTOMER_TYPE = 'C' THEN

      BEGIN
        SELECT A.CUSTOMER_NAME1
          INTO L_SENDER_FIRST_NAME
          FROM STTM_CUSTOMER A, STTM_CUST_CORPORATE B
         WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
           AND A.CUSTOMER_NO IN
               (SELECT CUST_NO
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
      EXCEPTION
        WHEN OTHERS THEN
          L_SENDER_FIRST_NAME := NULL;

      END;

      L_SENDER_LAST_NAME := NULL;

    END IF;

    DBG('L_SENDER_FIRST_NAME=' || L_SENDER_FIRST_NAME);
    DBG('L_SENDER_LAST_NAME=' || L_SENDER_LAST_NAME);

    L_SENDER_NATIONALITY := P_IFDMTAPA.v_iftb_mta_master.REM_NATIONALITY;

    DBG('L_SENDER_NATIONALITY=' || L_SENDER_NATIONALITY);

    L_COUNTRY_FROM := 'KH';

    DBG('L_COUNTRY_FROM=' || L_COUNTRY_FROM);

    L_COUNTRY_TO := P_IFDMTAPA.v_iftb_mta_master.BEN_COUNTRY; --BEN_COUNTRY PLS CHECK

    DBG('L_COUNTRY_TO=' || L_COUNTRY_TO);

    DBG('P_IFDMTAPA.v_iftb_mta_master.ben_nationality=' ||
        P_IFDMTAPA.v_iftb_mta_master.ben_nationality);

    L_BEN_NATIONALITY := FN_GET_BEN_NAT_ISO_CODE(P_IFDMTAPA.v_iftb_mta_master.ben_nationality);

    DBG('L_BEN_NATIONALITY=' || L_BEN_NATIONALITY);

    L_BEN_NAME := P_IFDMTAPA.v_iftb_mta_master.BEN_NAME;

    DBG('L_BEN_NAME=' || L_BEN_NAME);

    L_REG_ADDR_COUNTRY := P_IFDMTAPA.v_iftb_mta_master.REM_NATIONALITY;

    DBG('L_REG_ADDR_COUNTRY=' || L_REG_ADDR_COUNTRY);

    DBG('L_CUST_TYPE=' || L_CUSTOMER.CUSTOMER_TYPE);

    --IF L_CUSTOMER.CUSTOMER_TYPE = 'I' THEN

    --Sender Highest Country
    L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_SENDER_NATIONALITY),
                                    FN_GET_RISK_LEVEL_CNT(L_COUNTRY_FROM));

    L_MAX_INDEX := 1;
    L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

    FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

      IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
        L_MAX_VALUE := L_RISK_SCORE(G);
        L_MAX_INDEX := G;
      END IF;
    END LOOP;

    IF L_MAX_INDEX = 1 THEN
      L_HIGH_SEN_CNT := L_SENDER_NATIONALITY;
    ELSE
      --ELSIF L_MAX_INDEX = 2 THEN
      L_HIGH_SEN_CNT := L_COUNTRY_FROM;

    END IF;

    --Beneficiary Highest Country
    L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_BEN_NATIONALITY),
                                    FN_GET_RISK_LEVEL_CNT(L_COUNTRY_TO));

    L_MAX_INDEX := 1;
    L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

    FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

      IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
        L_MAX_VALUE := L_RISK_SCORE(G);
        L_MAX_INDEX := G;
      END IF;
    END LOOP;

    IF L_MAX_INDEX = 1 THEN
      L_HIGH_BEN_CNT := L_BEN_NATIONALITY;
    ELSE
      --ELSIF L_MAX_INDEX = 2 THEN
      L_HIGH_BEN_CNT := L_COUNTRY_TO;

    END IF;

    --Call AML for both Sender and Beneficiary for individual
    IF NOT IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_MTA(L_HIGH_SEN_CNT,
                                                       L_HIGH_BEN_CNT,
                                                       L_CUSTOMER.CUSTOMER_NO,
                                                       CASE
                                                       L_CUSTOMER.CUSTOMER_TYPE WHEN 'I' THEN
                                                       L_SENDER_FIRST_NAME || ' ' ||
                                                       L_SENDER_LAST_NAME WHEN 'C' THEN
                                                       L_SENDER_FIRST_NAME END,
                                                       L_BEN_NAME,
                                                       'DOSCAN_AUTH',
                                                       P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO,
                                                       P_HIT_STATUS,
                                                       P_WHO_HIT,
                                                       P_SCAN_ID,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM) THEN

      DBG('P_HIT_STATUS=' || P_HIT_STATUS);

      DBG('P_WHO_HIT=' || P_WHO_HIT);

      PR_LOG_ERROR('IFDMTAPA',
                   'FLEXCUBE',
                   'IF-MTA-018',
                   P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN 'For Sender' WHEN 'R' THEN
                   'For Beneficiary' WHEN 'B' THEN
                   'For Both Sender and Beneficiary' END);
      RETURN FALSE;

    ELSE
      RETURN TRUE;
    END IF;

    RETURN FALSE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_AML_VALIDATION=' ||
          DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE IN FN_AML_VALIDATION=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_AML_VALIDATION=' || SQLERRM);
      RETURN FALSE;
  END FN_AML_VALIDATION;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;

    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN

    SELECT TRSQ_MTA_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;

    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

    RETURN L_REF;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  FUNCTION FN_GET_PINCODE_CUST(P_IFDMTAPA IN IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN VARCHAR2 AS

    L_REM_POSTCODE STTM_CUST_PERSONAL.P_PINCODE%TYPE;
  BEGIN

    DBG('START OF FN_GET_PINCODE_CUST');

    BEGIN

      SELECT B.P_PINCODE
        INTO L_REM_POSTCODE
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = p_ifdmtapa.v_iftb_mta_master.Rem_acc)
         AND A.RECORD_STAT = 'O'
         AND A.AUTH_STAT = 'A';
    EXCEPTION
      WHEN OTHERS THEN
        L_REM_POSTCODE := null;
    END;

    DBG('L_REM_POSTCODE=' || L_REM_POSTCODE);

    RETURN L_REM_POSTCODE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_PINCODE_CUST');
      DBG('ERROR CODE IN FN_GET_PINCODE_CUST=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_PINCODE_CUST=' || SQLERRM);
      RETURN L_REM_POSTCODE;
  END FN_GET_PINCODE_CUST;

  PROCEDURE PR_GET_PAY_GROUP_MODE_CODE(P_IFDMTAPA        IN IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa,
                                       P_PAYOUT_GRP_CODE OUT VARCHAR2,
                                       P_PAY_MODE        OUT VARCHAR2) AS

  BEGIN

    DBG('START OF PR_GET_PAY_GROUP_MODE_CODE');

    DBG('P_IFDMTAPA.v_iftb_mta_master.ben_country=' ||
        P_IFDMTAPA.v_iftb_mta_master.ben_country);
    DBG('P_IFDMTAPA.v_iftb_mta_master.payment_mode=' ||
        P_IFDMTAPA.v_iftb_mta_master.payment_mode);

    BEGIN
      SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
        INTO P_PAYOUT_GRP_CODE, P_PAY_MODE
        FROM STTB_MTA_STATIC_AGENT_DTLS
       WHERE UPPER(COUNTRY_CODE) = P_IFDMTAPA.v_iftb_mta_master.ben_country
         AND PAYMENT_MODE = P_IFDMTAPA.v_iftb_mta_master.payment_mode;

      DBG('P_PAYOUT_GRP_CODE=' || P_PAYOUT_GRP_CODE);
      DBG('P_PAY_MODE=' || P_PAY_MODE);

    EXCEPTION
      WHEN OTHERS THEN
        P_PAYOUT_GRP_CODE := NULL;
        P_PAY_MODE        := NULL;
    END;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_GET_PAY_GROUP_MODE_CODE');
      DBG('ERROR CODE IN PR_GET_PAY_GROUP_MODE_CODE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_GET_PAY_GROUP_MODE_CODE=' || SQLERRM);
  END PR_GET_PAY_GROUP_MODE_CODE;

  FUNCTION FN_GET_MTA_PICKUP_PAYMENT RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_MTA_PICKUP_PAYMENT');

    L_FORMATTED_MSG := '{
        "amount": "$L_AMOUNT",
        "channelCode": "CBS",
        "currency": "$L_CURRENCY",
        "payoutGroupCode": "$L_PAYOUT_GRP_CODE",
        "payoutMode": "$L_PAYOUT_MODE",
        "reasonOfRemittanceCode": "1",
        "receiverAddress": "$L_BEN_ADDRESS",
        "receiverLastName": "$L_BEN_LASTNAME",
        "receiverNationalityCode": "$L_BEN_NAT_CODE",
        "remitType": "P2P",
        "senderAddress": "$L_SEN_ADDR",
        "senderBirthDate": "$L_SEN_DOB",
        "senderFirstName": "$L_SEN_FIRSTNAME",
        "senderIdCardTypeCode": "$L_SEN_CARD_TYPE_CODE",
        "senderIdCardTypeNo": "$L_SEN_CARD_TYPE_VAL",
        "senderLastName": "$L_SEN_LASTNAME",
        "senderNationalityCode": "$L_SEN_NAT_CODE",
        "senderOccupationCode": "$L_SEN_OCC_CODE",
        "cbsRefNo": "$L_CBS_REF_NO"
    }';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_MTA_PICKUP_PAYMENT');

  EXCEPTION

    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MTA_PICKUP_PAYMENT');
      DBG('ERROR CODE IN FN_GET_MTA_PICKUP_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MTA_PICKUP_PAYMENT=' || SQLERRM);

  END FN_GET_MTA_PICKUP_PAYMENT;

  FUNCTION FN_GET_FMT_MTA_PICKUP_PAYMENT(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN CLOB IS

    L_AMOUNT       VARCHAR2(105);
    L_CHANNEL_CODE VARCHAR2(105);
    L_CURRENCY     VARCHAR2(105);

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);
    L_COUNTRY         VARCHAR2(105);
    L_PAYMENT_MODE    VARCHAR2(105);

    L_REASON_REMIT_CODE VARCHAR2(105);

    L_BEN_BANK_AC_NO       VARCHAR2(105);
    L_BEN_BANK_BRANCH_CODE VARCHAR2(105);
    L_BEN_BANK_CODE        VARCHAR2(105);
    L_BEN_LASTNAME         VARCHAR2(105);
    L_BEN_NAT_CODE         VARCHAR2(105);

    L_REMIT_TYPE         VARCHAR2(105);
    L_SEN_ADDR           VARCHAR2(1000);
    L_SEN_DOB            VARCHAR2(105);
    L_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_SEN_FIRSTNAME      VARCHAR2(105);
    L_SEN_LASTNAME       VARCHAR2(105);
    L_SEN_NAT_CODE       VARCHAR2(105);
    L_SEN_OCC_CODE       VARCHAR2(105);

    L_BEN_ADDRESS VARCHAR2(1000);

    L_CBS_REF_NO IFTB_MTA_MASTER.TRN_REF_NO%TYPE;

    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('START OF FN_GET_FMT_MTA_PICKUP_PAYMENT=' ||
        DBMS_UTILITY.format_call_stack);

    L_FORMATTED_MSG := FN_GET_MTA_PICKUP_PAYMENT;

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT JSON APPLE1=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values

    --Amount
    L_AMOUNT := P_IFDMTAPA.v_iftb_mta_master.txn_amt;

    DBG('L_AMOUNT=' || L_AMOUNT);

    --Currency
    L_CURRENCY := P_IFDMTAPA.v_iftb_mta_master.txn_ccy;

    DBG('L_CURRENCY=' || L_CURRENCY);

    --L_PAYOUT_GRP_CODE and L_PAYOUT_MODE
    --Get country
    L_COUNTRY := P_IFDMTAPA.v_iftb_mta_master.ben_country_name;
    DBG('L_COUNTRY=' || L_COUNTRY);

    --Get Payment Mode
    L_PAYMENT_MODE := P_IFDMTAPA.v_iftb_mta_master.payment_mode;
    DBG('L_PAYMENT_MODE=' || L_PAYMENT_MODE);

    BEGIN
      SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
        INTO L_PAYOUT_GRP_CODE, L_PAYOUT_MODE
        FROM STTB_MTA_CASHPICKUP_AGENTS -- STTB_MTA_STATIC_AGENT_DTLS
       WHERE UPPER(COUNTRY_CODE) = L_COUNTRY
         AND PAYMENT_MODE = L_PAYMENT_MODE
         AND CASHPICKUP_LOC = P_IFDMTAPA.v_iftb_mta_master.CASHPICKUP_LOC;

    EXCEPTION
      WHEN OTHERS THEN
        L_PAYOUT_GRP_CODE := NULL;
        L_PAYOUT_MODE     := NULL;
    END;

    DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
    DBG('L_PAYOUT_MODE=' || L_PAYOUT_MODE);

    --L_PAYOUT_GRP_CODE := 'LK02';
    --L_PAYOUT_MODE     := '2';

    --Reason of Remittance Code
    L_REASON_REMIT_CODE := FN_GET_REMMITANCE_CODE(P_IFDMTAPA.v_iftb_mta_master.remit_reason_code);
    DBG('L_REASON_REMIT_CODE=' || L_REASON_REMIT_CODE);

    --Receiver Address
    L_BEN_ADDRESS := TRIM(P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS);
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);

    --Receiver Last Name nothing but ben name
    L_BEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.ben_name;
    DBG('L_BEN_LASTNAME=' || L_BEN_LASTNAME);

    --Receiver Nationality Code
    L_BEN_NAT_CODE := FN_GET_BEN_NAT_CODE(P_IFDMTAPA.v_iftb_mta_master.ben_nationality);
    DBG('L_BEN_NAT_CODE=' || L_BEN_NAT_CODE);

    --Remit Type
    L_REMIT_TYPE := P_IFDMTAPA.v_iftb_mta_master.remit_type;
    DBG('L_REMIT_TYPE=' || L_REMIT_TYPE);

    --Sender Address
    L_SEN_ADDR := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_2 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_3 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_4;

    DBG('L_SEN_ADDR=' || L_SEN_ADDR);

    --Sender DOB
    L_SEN_DOB := TO_CHAR(P_IFDMTAPA.v_iftb_mta_master.rem_dob, 'YYYY-MM-DD');
    DBG('L_SEN_DOB=' || L_SEN_DOB);

    --Sender card type code
    BEGIN
      SELECT CARD_TYPE_CODE
        INTO L_SEN_CARD_TYPE_CODE
        FROM sttb_mta_card_type_dtls
       WHERE card_type_name =
             P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_CARD_TYPE_CODE := NULL;
    END;
    DBG('L_SEN_CARD_TYPE_CODE=' || L_SEN_CARD_TYPE_CODE);

    IF L_SEN_CARD_TYPE_CODE IS NULL THEN
      L_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    END IF;

    --Sender card type val
    L_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_value;
    DBG('L_SEN_CARD_TYPE_VAL=' || L_SEN_CARD_TYPE_VAL);

    --Sender First name
    --L_SEN_FIRSTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;

    BEGIN
      SELECT B.FIRST_NAME, B.LAST_NAME
        INTO L_SEN_FIRSTNAME, L_SEN_LASTNAME
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_FIRSTNAME := NULL;
        L_SEN_LASTNAME  := NULL;
    END;

    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);
    L_SEN_FIRSTNAME := NVL(L_SEN_FIRSTNAME,
                           P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);

    --Sender Last Name
    --L_SEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    L_SEN_LASTNAME := NVL(L_SEN_LASTNAME,
                          P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    --Sender Nationality Code
    L_SEN_NAT_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_nationality;
    DBG('L_SEN_NAT_CODE=' || L_SEN_NAT_CODE);

    --Sender Occupation Code
    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('B2P', 'B2B') THEN
      L_SEN_OCC_CODE := FN_GET_NOB_CODE(P_IFDMTAPA.v_iftb_mta_master.REM_NOB);
    ELSE
      L_SEN_OCC_CODE := FN_GET_SEN_OCC_CODE(P_IFDMTAPA.v_iftb_mta_master.rem_occupation);
    END IF;
    DBG('L_SEN_OCC_CODE=' || L_SEN_OCC_CODE);

    --CBS Ref No
    L_CBS_REF_NO := P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO;

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CURRENCY', L_CURRENCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_COUNTRY', L_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_MODE',
                               L_PAYMENT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_GRP_CODE',
                               L_PAYOUT_GRP_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_MODE',
                               L_PAYOUT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REASON_REMIT_CODE',
                               L_REASON_REMIT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ADDRESS',
                               L_BEN_ADDRESS);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LASTNAME',
                               L_BEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_NAT_CODE',
                               L_BEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REMIT_TYPE',
                               L_REMIT_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_ADDR', L_SEN_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_DOB', L_SEN_DOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_CODE',
                               L_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_VAL',
                               L_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_FIRSTNAME',
                               L_SEN_FIRSTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_LASTNAME',
                               L_SEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_NAT_CODE',
                               L_SEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_OCC_CODE',
                               L_SEN_OCC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CBS_REF_NO',
                               L_CBS_REF_NO);

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_MTA_PICKUP_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_MTA_PICKUP_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_MTA_PICKUP_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_MTA_PICKUP_PAYMENT=' || SQLERRM);
      RETURN L_FORMATTED_MSG;

  END FN_GET_FMT_MTA_PICKUP_PAYMENT;

  FUNCTION FN_GET_MTA_P2P_PAYMENT RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_MTA_P2P_PAYMENT');

    --L_FORMATTED_MSG := '{"channelCode":"MB","insuranceCode":"$L_INSURANCE_CODE","transactionUniqueNo":"$L_TXN_UNIQUE_NO","policyNumber":"$L_POLICY_NUMBER"
    --,"amount":"$L_AMOUNT","currency":"$L_CCY"}';

    /*L_FORMATTED_MSG := '{
        "amount": "$L_AMOUNT",
        "channelCode": "CBS",
        "currency": "$L_CCY",
        "payoutGroupCode": "$L_PAYOUT_GROUP_CODE",
        "payoutMode": "$L_PAYOUT_MODE_CODE",
        "reasonOfRemittanceCode": "1",
        "receiverAddress": "$L_BEN_ADDR",
        "receiverLastName": "$L_BEN_LASTNAME",
        "receiverNationalityCode": "$L_BEN_NAT",
        "remitType": "P2P",
        "senderAddress": "$L_SENDER_ADDR",
        "senderBirthDate": "$L_SENDER_DOB",
        "senderIdCardTypeCode": "$L_CARD_TYPE",
        "senderIdCardTypeNo": "$L_CARD_NO",
        "senderLastName": "$L_SENDER_LASTNAME",
        "senderNationalityCode": "$L_SENDER_NAT",
        "senderOccupationCode": "$L_SEN_OCC_CODE"
    }';*/

    L_FORMATTED_MSG := '{
    "amount": "$L_AMOUNT",
    "channelCode": "CBS",
    "currency": "$L_CURRENCY",
    "payoutGroupCode": "$L_PAYOUT_GRP_CODE",
    "payoutMode": "$L_PAYOUT_MODE",
    "reasonOfRemittanceCode": "$L_REASON_REMIT_CODE",
    "receiverAddress": "$L_BEN_ADDRESS",
    "receiverBankAcNo": "$L_BEN_BANK_AC_NO",
    "receiverBankBranchCode": "$L_BEN_BANK_BRANCH_CODE",
    "receiverBankCode": "$L_BEN_BANK_CODE",
    "receiverLastName": "$L_BEN_LASTNAME",
    "receiverNationalityCode": "$L_BEN_NAT_CODE",
    "remitType": "$L_REMIT_TYPE",
    "senderAddress": "$L_SEN_ADDR",
    "senderBirthDate": "$L_SEN_DOB",
    "senderFirstName": "$L_SEN_LASTNAME",
    "senderIdCardTypeCode": "$L_SEN_CARD_TYPE_CODE",
    "senderIdCardTypeNo": "$L_SEN_CARD_TYPE_VAL",
    "senderLastName": "$L_SEN_LASTNAME",
    "senderNationalityCode": "$L_SEN_NAT_CODE",
    "senderOccupationCode": "$L_SEN_OCC_CODE",
    "cbsRefNo": "$L_CBS_REF_NO"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_MTA_P2P_PAYMENT');

  EXCEPTION

    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MTA_P2P_PAYMENT');
      DBG('ERROR CODE IN FN_GET_MTA_P2P_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MTA_P2P_PAYMENT=' || SQLERRM);

  END FN_GET_MTA_P2P_PAYMENT;

  FUNCTION FN_GET_FMT_MTA_P2P_PAYMENT(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN CLOB IS

    L_AMOUNT       VARCHAR2(105);
    L_CHANNEL_CODE VARCHAR2(105);
    L_CURRENCY     VARCHAR2(105);

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);
    L_COUNTRY         VARCHAR2(105);
    L_PAYMENT_MODE    VARCHAR2(105);

    L_REASON_REMIT_CODE VARCHAR2(105);
    L_BEN_ADDRESS       VARCHAR2(1000);

    L_BEN_BANK_AC_NO       VARCHAR2(105);
    L_BEN_BANK_BRANCH_CODE VARCHAR2(105);
    L_BEN_BANK_CODE        VARCHAR2(105);
    L_BEN_LASTNAME         VARCHAR2(105);
    L_BEN_NAT_CODE         VARCHAR2(105);

    L_REMIT_TYPE         VARCHAR2(105);
    L_SEN_ADDR           VARCHAR2(1000);
    L_SEN_DOB            VARCHAR2(105);
    L_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_SEN_FIRSTNAME      VARCHAR2(105);
    L_SEN_LASTNAME       VARCHAR2(105);
    L_SEN_NAT_CODE       VARCHAR2(105);
    L_SEN_OCC_CODE       VARCHAR2(105);
    L_CBS_REF_NO         IFTB_MTA_MASTER.TRN_REF_NO%TYPE;

    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('START OF FN_GET_FMT_MTA_P2P_PAYMENT=' ||
        DBMS_UTILITY.format_call_stack);

    L_FORMATTED_MSG := FN_GET_MTA_P2P_PAYMENT;

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT JSON=' || L_FORMATTED_MSG);

    --Replace tags with actual values

    --Amount
    L_AMOUNT := P_IFDMTAPA.v_iftb_mta_master.txn_amt;

    DBG('L_AMOUNT=' || L_AMOUNT);

    --Currency
    L_CURRENCY := P_IFDMTAPA.v_iftb_mta_master.txn_ccy;

    DBG('L_CURRENCY=' || L_CURRENCY);

    --L_PAYOUT_GRP_CODE and L_PAYOUT_MODE
    --Get country
    L_COUNTRY := P_IFDMTAPA.v_iftb_mta_master.ben_country;
    DBG('L_COUNTRY=' || L_COUNTRY);

    --Get Payment Mode
    L_PAYMENT_MODE := P_IFDMTAPA.v_iftb_mta_master.payment_mode;
    DBG('L_PAYMENT_MODE=' || L_PAYMENT_MODE);

    BEGIN
      SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
        INTO L_PAYOUT_GRP_CODE, L_PAYOUT_MODE
        FROM STTB_MTA_STATIC_AGENT_DTLS
       WHERE UPPER(COUNTRY_CODE) = L_COUNTRY
         AND PAYMENT_MODE = L_PAYMENT_MODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_PAYOUT_GRP_CODE := NULL;
        L_PAYOUT_MODE     := NULL;
    END;

    DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
    DBG('L_PAYOUT_MODE=' || L_PAYOUT_MODE);

    --Reason of Remittance Code
    L_REASON_REMIT_CODE := FN_GET_REMMITANCE_CODE(P_IFDMTAPA.v_iftb_mta_master.remit_reason_code);
    DBG('L_REASON_REMIT_CODE=' || L_REASON_REMIT_CODE);

    --Receiver Address
    L_BEN_ADDRESS := TRIM(P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS);
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);
    -- L_BEN_ADDRESS := replace(L_BEN_ADDRESS,CHR(13),'');
    --DBG('L_BEN_ADDRESS after removing new line=' || length(L_BEN_ADDRESS));
    L_BEN_ADDRESS := REPLACE(L_BEN_ADDRESS, chr(10), '');
    DBG('L_BEN_ADDRESS after removing new line=' || length(L_BEN_ADDRESS));
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);

    --Receiver Bank Acc No
    L_BEN_BANK_AC_NO := P_IFDMTAPA.v_iftb_mta_master.ben_acc;
    DBG('L_BEN_BANK_AC_NO=' || L_BEN_BANK_AC_NO);

    --Receiver Bank Branch Code
    L_BEN_BANK_BRANCH_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bank_branch;
    DBG('L_BEN_BANK_BRANCH_CODE=' || L_BEN_BANK_BRANCH_CODE);

    --Receiver Bank Code
    L_BEN_BANK_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bic;
    DBG('L_BEN_BANK_CODE=' || L_BEN_BANK_CODE);

    --Receiver Last Name nothing but ben name
    L_BEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.ben_name;
    DBG('L_BEN_LASTNAME=' || L_BEN_LASTNAME);

    --Receiver Nationality Code
    L_BEN_NAT_CODE := FN_GET_BEN_NAT_CODE(P_IFDMTAPA.v_iftb_mta_master.ben_nationality);
    DBG('L_BEN_NAT_CODE=' || L_BEN_NAT_CODE);

    --Remit Type
    L_REMIT_TYPE := P_IFDMTAPA.v_iftb_mta_master.remit_type;
    DBG('L_REMIT_TYPE=' || L_REMIT_TYPE);

    --Sender Address
    L_SEN_ADDR := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_2 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_3 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_4;

    DBG('L_SEN_ADDR=' || L_SEN_ADDR);

    --Sender DOB
    L_SEN_DOB := TO_CHAR(P_IFDMTAPA.v_iftb_mta_master.rem_dob, 'YYYY-MM-DD');
    DBG('L_SEN_DOB=' || L_SEN_DOB);

    --Sender card type code
    BEGIN
      SELECT CARD_TYPE_CODE
        INTO L_SEN_CARD_TYPE_CODE
        FROM sttb_mta_card_type_dtls
       WHERE card_type_name =
             P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_CARD_TYPE_CODE := NULL;
    END;
    DBG('L_SEN_CARD_TYPE_CODE=' || L_SEN_CARD_TYPE_CODE);

    IF L_SEN_CARD_TYPE_CODE IS NULL THEN
      L_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    END IF;

    --Sender card type val
    L_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_value;
    DBG('L_SEN_CARD_TYPE_VAL=' || L_SEN_CARD_TYPE_VAL);

    --Sender First name
    --L_SEN_FIRSTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;

    BEGIN
      SELECT B.FIRST_NAME, B.LAST_NAME
        INTO L_SEN_FIRSTNAME, L_SEN_LASTNAME
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_FIRSTNAME := NULL;
        L_SEN_LASTNAME  := NULL;
    END;

    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);
    L_SEN_FIRSTNAME := NVL(L_SEN_FIRSTNAME,
                           P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);

    --Sender Last Name
    --L_SEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    L_SEN_LASTNAME := NVL(L_SEN_LASTNAME,
                          P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    --Sender Nationality Code
    L_SEN_NAT_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_nationality;
    DBG('L_SEN_NAT_CODE=' || L_SEN_NAT_CODE);

    --Sender Occupation Code
    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('B2P', 'B2B') THEN
      L_SEN_OCC_CODE := FN_GET_NOB_CODE(P_IFDMTAPA.v_iftb_mta_master.REM_NOB);
    ELSE
      L_SEN_OCC_CODE := FN_GET_SEN_OCC_CODE(P_IFDMTAPA.v_iftb_mta_master.rem_occupation);
    END IF;
    DBG('L_SEN_OCC_CODE=' || L_SEN_OCC_CODE);

    --CBS Ref No
    L_CBS_REF_NO := P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO;

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CURRENCY', L_CURRENCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_COUNTRY', L_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_MODE',
                               L_PAYMENT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_GRP_CODE',
                               L_PAYOUT_GRP_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_MODE',
                               L_PAYOUT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REASON_REMIT_CODE',
                               L_REASON_REMIT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ADDRESS',
                               L_BEN_ADDRESS);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_AC_NO',
                               L_BEN_BANK_AC_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_BRANCH_CODE',
                               L_BEN_BANK_BRANCH_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_CODE',
                               L_BEN_BANK_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LASTNAME',
                               L_BEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_NAT_CODE',
                               L_BEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REMIT_TYPE',
                               L_REMIT_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_ADDR', L_SEN_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_DOB', L_SEN_DOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_CODE',
                               L_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_VAL',
                               L_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_FIRSTNAME',
                               L_SEN_FIRSTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_LASTNAME',
                               L_SEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_NAT_CODE',
                               L_SEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_OCC_CODE',
                               L_SEN_OCC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CBS_REF_NO',
                               L_CBS_REF_NO);

    DBG('AFTER REPLACEMENT OF MTA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_MTA_P2P_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_MTA_P2P_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_MTA_P2P_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_MTA_P2P_PAYMENT=' || SQLERRM);
      RETURN L_FORMATTED_MSG;

  END FN_GET_FMT_MTA_P2P_PAYMENT;

  FUNCTION FN_GET_MTA_PAYMENT_P2PUK RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_MTA_PAYMENT_P2PUK');

    L_FORMATTED_MSG := '{
    "amount": "$L_AMOUNT",
    "channelCode": "CBS",
    "currency": "$L_CURRENCY",
    "payoutGroupCode": "$L_PAYOUT_GRP_CODE",
    "payoutMode": "$L_PAYOUT_MODE",
    "reasonOfRemittanceCode": "$L_REASON_REMIT_CODE",
  "receiverAddress":"$L_BEN_ADDRESS",
  "receiverBankAcNo": "$L_BEN_BANK_AC_NO",
  "receiverBankBranchCode": "$L_BEN_BANK_BRANCH_CODE",
  "receiverBankCode": "$L_BEN_BANK_CODE",
    "receiverLastName": "$L_BEN_LASTNAME",
    "receiverNationalityCode": "$L_BEN_NAT_CODE",
    "remitType": "$L_REMIT_TYPE",
    "senderAddress": "$L_SEN_ADDR",
    "senderBirthDate": "$L_SEN_DOB",
  "senderFirstName": "$L_SEN_LASTNAME",
    "senderIdCardTypeCode": "$L_SEN_CARD_TYPE_CODE",
    "senderIdCardTypeNo": "$L_SEN_CARD_TYPE_VAL",
    "senderLastName": "$L_SEN_LASTNAME",
    "senderNationalityCode": "$L_SEN_NAT_CODE",
    "senderOccupationCode": "$L_SEN_OCC_CODE",
  "streetName": "$L_STREET_NAME",
    "streetNo": "$L_STREET_NO",
    "streetType": "$L_STREET_TYPE",
    "cbsRefNo": "$L_CBS_REF_NO"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_MTA_PAYMENT_P2PUK');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MTA_PAYMENT_P2PUK');
      DBG('ERROR CODE IN FN_GET_MTA_PAYMENT_P2PUK=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MTA_PAYMENT_P2PUK=' || SQLERRM);

  END FN_GET_MTA_PAYMENT_P2PUK;

  FUNCTION FN_GET_FMT_MTA_PAYMENT_P2PUK(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN CLOB IS

    L_AMOUNT       VARCHAR2(105);
    L_CHANNEL_CODE VARCHAR2(105);
    L_CURRENCY     VARCHAR2(105);

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);
    L_COUNTRY         VARCHAR2(105);
    L_PAYMENT_MODE    VARCHAR2(105);

    L_REASON_REMIT_CODE VARCHAR2(105);

    L_BEN_BANK_AC_NO       VARCHAR2(105);
    L_BEN_BANK_BRANCH_CODE VARCHAR2(105);
    L_BEN_BANK_CODE        VARCHAR2(105);
    L_BEN_LASTNAME         VARCHAR2(105);
    L_BEN_NAT_CODE         VARCHAR2(105);
    L_BEN_ADDR             VARCHAR2(105);

    L_REMIT_TYPE         VARCHAR2(105);
    L_SEN_ADDR           VARCHAR2(1000);
    L_SEN_DOB            VARCHAR2(105);
    L_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_SEN_FIRSTNAME      VARCHAR2(105);
    L_SEN_LASTNAME       VARCHAR2(105);
    L_SEN_NAT_CODE       VARCHAR2(105);
    L_SEN_OCC_CODE       VARCHAR2(105);

    L_BEN_ADDRESS VARCHAR2(1000);
    L_STREET_NAME VARCHAR2(105);
    L_STREET_NO   VARCHAR2(105);
    L_STREET_TYPE VARCHAR2(105);
    L_CBS_REF_NO  IFTB_MTA_MASTER.TRN_REF_NO%TYPE;

    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('START OF FN_GET_FMT_MTA_PAYMENT_P2PUK=' ||
        DBMS_UTILITY.format_call_stack);

    L_FORMATTED_MSG := FN_GET_MTA_PAYMENT_P2PUK;

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT JSON APPLE2=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values

    --Amount
    L_AMOUNT := P_IFDMTAPA.v_iftb_mta_master.txn_amt;

    DBG('L_AMOUNT=' || L_AMOUNT);

    --Currency
    L_CURRENCY := P_IFDMTAPA.v_iftb_mta_master.txn_ccy;

    DBG('L_CURRENCY=' || L_CURRENCY);

    --L_PAYOUT_GRP_CODE and L_PAYOUT_MODE
    --Get country
    L_COUNTRY := P_IFDMTAPA.v_iftb_mta_master.ben_country;
    DBG('L_COUNTRY=' || L_COUNTRY);

    --Get Payment Mode
    L_PAYMENT_MODE := P_IFDMTAPA.v_iftb_mta_master.payment_mode;
    DBG('L_PAYMENT_MODE=' || L_PAYMENT_MODE);

    BEGIN
      SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
        INTO L_PAYOUT_GRP_CODE, L_PAYOUT_MODE
        FROM STTB_MTA_STATIC_AGENT_DTLS
       WHERE UPPER(COUNTRY_CODE) = L_COUNTRY
         AND PAYMENT_MODE = L_PAYMENT_MODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_PAYOUT_GRP_CODE := NULL;
        L_PAYOUT_MODE     := NULL;
    END;

    DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
    DBG('L_PAYOUT_MODE=' || L_PAYOUT_MODE);

    --Reason of Remittance Code
    L_REASON_REMIT_CODE := FN_GET_REMMITANCE_CODE(P_IFDMTAPA.v_iftb_mta_master.remit_reason_code);
    DBG('L_REASON_REMIT_CODE=' || L_REASON_REMIT_CODE);

    --Receiver Address
    L_BEN_ADDRESS := TRIM(P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS);
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);
    L_BEN_ADDRESS := REPLACE(L_BEN_ADDRESS, chr(10), '');
    DBG('L_BEN_ADDRESS after removing new line=' || length(L_BEN_ADDRESS));
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);

    --Receiver Bank Acc No
    L_BEN_BANK_AC_NO := P_IFDMTAPA.v_iftb_mta_master.ben_acc;
    DBG('L_BEN_BANK_AC_NO=' || L_BEN_BANK_AC_NO);

    --Receiver Bank Branch Code
    L_BEN_BANK_BRANCH_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bank_branch;
    DBG('L_BEN_BANK_BRANCH_CODE=' || L_BEN_BANK_BRANCH_CODE);

    --Receiver Bank Code
    L_BEN_BANK_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bic;
    DBG('L_BEN_BANK_CODE=' || L_BEN_BANK_CODE);

    --Receiver Last Name nothing but ben name
    L_BEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.ben_name;
    DBG('L_BEN_LASTNAME=' || L_BEN_LASTNAME);

    --Receiver Nationality Code
    L_BEN_NAT_CODE := FN_GET_BEN_NAT_CODE(P_IFDMTAPA.v_iftb_mta_master.ben_nationality);
    DBG('L_BEN_NAT_CODE=' || L_BEN_NAT_CODE);

    --Remit Type
    L_REMIT_TYPE := P_IFDMTAPA.v_iftb_mta_master.remit_type;
    DBG('L_REMIT_TYPE=' || L_REMIT_TYPE);

    --Sender Address
    L_SEN_ADDR := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_2 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_3 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_4;

    DBG('L_SEN_ADDR=' || L_SEN_ADDR);

    --Sender DOB
    L_SEN_DOB := TO_CHAR(P_IFDMTAPA.v_iftb_mta_master.rem_dob, 'YYYY-MM-DD');
    DBG('L_SEN_DOB=' || L_SEN_DOB);

    --Sender card type code
    BEGIN
      SELECT CARD_TYPE_CODE
        INTO L_SEN_CARD_TYPE_CODE
        FROM sttb_mta_card_type_dtls
       WHERE card_type_name =
             P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_CARD_TYPE_CODE := NULL;
    END;
    DBG('L_SEN_CARD_TYPE_CODE=' || L_SEN_CARD_TYPE_CODE);

    IF L_SEN_CARD_TYPE_CODE IS NULL THEN
      L_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    END IF;

    --Sender card type val
    L_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_value;
    DBG('L_SEN_CARD_TYPE_VAL=' || L_SEN_CARD_TYPE_VAL);

    --Sender First name
    --L_SEN_FIRSTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;

    BEGIN
      SELECT B.FIRST_NAME, B.LAST_NAME
        INTO L_SEN_FIRSTNAME, L_SEN_LASTNAME
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_FIRSTNAME := NULL;
        L_SEN_LASTNAME  := NULL;
    END;

    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);
    L_SEN_FIRSTNAME := NVL(L_SEN_FIRSTNAME,
                           P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);

    --Sender Last Name
    --L_SEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    L_SEN_LASTNAME := NVL(L_SEN_LASTNAME,
                          P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    --Sender Nationality Code
    L_SEN_NAT_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_nationality;
    DBG('L_SEN_NAT_CODE=' || L_SEN_NAT_CODE);

    --Sender Occupation Code
    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('B2P', 'B2B') THEN
      L_SEN_OCC_CODE := FN_GET_NOB_CODE(P_IFDMTAPA.v_iftb_mta_master.REM_NOB);
    ELSE
      L_SEN_OCC_CODE := FN_GET_SEN_OCC_CODE(P_IFDMTAPA.v_iftb_mta_master.rem_occupation);
    END IF;
    DBG('L_SEN_OCC_CODE=' || L_SEN_OCC_CODE);

    --Street Name
    L_STREET_NAME := P_IFDMTAPA.v_iftb_mta_master.STREET_NAME;
    DBG('L_STREET_NAME=' || L_STREET_NAME);

    --Street Type
    L_STREET_NO := P_IFDMTAPA.v_iftb_mta_master.STREET_NO;
    DBG('L_STREET_NO=' || L_STREET_NO);

    --Street No
    L_STREET_TYPE := P_IFDMTAPA.v_iftb_mta_master.STREET_TYPE;
    DBG('L_STREET_TYPE=' || L_STREET_TYPE);

    --CBS Ref No
    L_CBS_REF_NO := P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO;

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CURRENCY', L_CURRENCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_COUNTRY', L_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_MODE',
                               L_PAYMENT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_GRP_CODE',
                               L_PAYOUT_GRP_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_MODE',
                               L_PAYOUT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REASON_REMIT_CODE',
                               L_REASON_REMIT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ADDRESS',
                               L_BEN_ADDRESS);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_AC_NO',
                               L_BEN_BANK_AC_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_BRANCH_CODE',
                               L_BEN_BANK_BRANCH_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_CODE',
                               L_BEN_BANK_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LASTNAME',
                               L_BEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_NAT_CODE',
                               L_BEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REMIT_TYPE',
                               L_REMIT_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_ADDR', L_SEN_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_DOB', L_SEN_DOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_CODE',
                               L_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_VAL',
                               L_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_FIRSTNAME',
                               L_SEN_FIRSTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_LASTNAME',
                               L_SEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_NAT_CODE',
                               L_SEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_OCC_CODE',
                               L_SEN_OCC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_STREET_NAME',
                               L_STREET_NAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_STREET_NO', L_STREET_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_STREET_TYPE',
                               L_STREET_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CBS_REF_NO',
                               L_CBS_REF_NO);

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_MTA_PAYMENT_P2PUK');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_MTA_PAYMENT_P2PUK');
      DBG('ERROR CODE IN FN_GET_FMT_MTA_PAYMENT_P2PUK=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_MTA_PAYMENT_P2PUK=' || SQLERRM);
      RETURN L_FORMATTED_MSG;
  END FN_GET_FMT_MTA_PAYMENT_P2PUK;

  FUNCTION FN_GET_MTA_PAYMENT_P2PAUS RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_MTA_PAYMENT_P2PAUS');

    L_FORMATTED_MSG := '{
    "amount": "$L_AMOUNT",
    "channelCode": "CBS",
  "city": "$L_BEN_CITY",
    "currency": "$L_CURRENCY",
  "documentRefNo": "$L_DOC_REF_NO",
    "payoutGroupCode": "$L_PAYOUT_GRP_CODE",
    "payoutMode": "$L_PAYOUT_MODE",
  "postCode": "$L_BEN_POST_CODE",
    "reasonOfRemittanceCode": "$L_REASON_REMIT_CODE",
  "receiverAddress":"$L_BEN_ADDRESS",
  "receiverBankAcNo": "$L_BEN_BANK_AC_NO",
  "receiverBankBranchCode": "$L_BEN_BANK_BRANCH_CODE",
  "receiverBankCode": "$L_BEN_BANK_CODE",
  "receiverEmail": "$L_BEN_EMAIL",
    "receiverLastName": "$L_BEN_LASTNAME",
    "receiverNationalityCode": "$L_BEN_NAT_CODE",
  "receiverPhoneNo": "$L_BEN_MOB",
    "remitType": "$L_REMIT_TYPE",
    "senderAddress": "$L_SEN_ADDR",
    "senderBirthDate": "$L_SEN_DOB",
  "senderCity": "$L_REM_CITY",
  "senderEmail": "$L_REM_EMAIL",
  "senderFirstName": "$L_SEN_FIRSTNAME",
    "senderIdCardTypeCode": "$L_SEN_CARD_TYPE_CODE",
    "senderIdCardTypeNo": "$L_SEN_CARD_TYPE_VAL",
    "senderLastName": "$L_SEN_LASTNAME",
    "senderNationalityCode": "$L_SEN_NAT_CODE",
    "senderOccupationCode": "$L_SEN_OCC_CODE",
    "senderPhoneNo": "$L_REM_MOB",
    "senderPostCode": "$L_REM_POSTCODE",
    "senderState": "$L_REM_STATE",
    "state": "$L_STATE",
    "cbsRefNo": "$L_CBS_REF_NO"
    }';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_MTA_PAYMENT_P2PAUS');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MTA_PAYMENT_P2PAUS');
      DBG('ERROR CODE IN FN_GET_MTA_PAYMENT_P2PAUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MTA_PAYMENT_P2PAUS=' || SQLERRM);

  END FN_GET_MTA_PAYMENT_P2PAUS;

  FUNCTION FN_GET_FMT_MTA_PAYMENT_P2PAUS(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN CLOB IS

    L_AMOUNT       VARCHAR2(105);
    L_CHANNEL_CODE VARCHAR2(105);
    L_BEN_CITY     VARCHAR2(105);
    L_CURRENCY     VARCHAR2(105);
    L_DOC_REF_NO   VARCHAR2(105);

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);
    L_COUNTRY         VARCHAR2(105);

    L_BEN_POST_CODE VARCHAR2(105);

    L_PAYMENT_MODE VARCHAR2(105);

    L_REASON_REMIT_CODE VARCHAR2(105);

    L_BEN_ADDRESS          VARCHAR2(105);
    L_BEN_BANK_AC_NO       VARCHAR2(105);
    L_BEN_BANK_BRANCH_CODE VARCHAR2(105);
    L_BEN_BANK_CODE        VARCHAR2(105);
    L_BEN_EMAIL            VARCHAR2(105);
    L_BEN_LASTNAME         VARCHAR2(105);
    L_BEN_NAT_CODE         VARCHAR2(105);
    L_BEN_MOB              VARCHAR2(105);

    L_REMIT_TYPE         VARCHAR2(105);
    L_SEN_ADDR           VARCHAR2(1000);
    L_SEN_DOB            VARCHAR2(105);
    L_REM_CITY           VARCHAR2(105);
    L_REM_EMAIL          VARCHAR2(105);
    L_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_SEN_FIRSTNAME      VARCHAR2(105);
    L_SEN_LASTNAME       VARCHAR2(105);
    L_SEN_NAT_CODE       VARCHAR2(105);
    L_SEN_OCC_CODE       VARCHAR2(105);
    L_REM_MOB            VARCHAR2(105);
    L_REM_POSTCODE       VARCHAR2(105);
    L_REM_STATE          VARCHAR2(105);
    L_STATE              VARCHAR2(105);
    L_CBS_REF_NO         IFTB_MTA_MASTER.TRN_REF_NO%TYPE;

    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('START OF FN_GET_FMT_MTA_PAYMENT_P2PAUS=' ||
        DBMS_UTILITY.format_call_stack);

    L_FORMATTED_MSG := FN_GET_MTA_PAYMENT_P2PAUS;

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT JSON APPLE3=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values

    --Amount
    L_AMOUNT := P_IFDMTAPA.v_iftb_mta_master.txn_amt;

    DBG('L_AMOUNT=' || L_AMOUNT);

    --City
    L_BEN_CITY := P_IFDMTAPA.v_iftb_mta_master.BEN_CITY;
    DBG('L_BEN_CITY=' || L_BEN_CITY);

    --Currency
    L_CURRENCY := P_IFDMTAPA.v_iftb_mta_master.txn_ccy;

    DBG('L_CURRENCY=' || L_CURRENCY);

    L_DOC_REF_NO := P_IFDMTAPA.v_iftb_mta_master.DOCUMENT_REF_NO; --pls check
    DBG('L_DOC_REF_NO=' || L_DOC_REF_NO);

    --L_PAYOUT_GRP_CODE and L_PAYOUT_MODE
    --Get country
    L_COUNTRY := P_IFDMTAPA.v_iftb_mta_master.ben_country;
    DBG('L_COUNTRY=' || L_COUNTRY);

    --Get Payment Mode
    L_PAYMENT_MODE := P_IFDMTAPA.v_iftb_mta_master.payment_mode;
    DBG('L_PAYMENT_MODE=' || L_PAYMENT_MODE);

    BEGIN
      SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
        INTO L_PAYOUT_GRP_CODE, L_PAYOUT_MODE
        FROM STTB_MTA_STATIC_AGENT_DTLS
       WHERE UPPER(COUNTRY_CODE) = L_COUNTRY
         AND PAYMENT_MODE = L_PAYMENT_MODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_PAYOUT_GRP_CODE := NULL;
        L_PAYOUT_MODE     := NULL;
    END;

    DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
    DBG('L_PAYOUT_MODE=' || L_PAYOUT_MODE);

    L_BEN_POST_CODE := P_IFDMTAPA.v_iftb_mta_master.BEN_POST_CODE;
    DBG('L_BEN_POST_CODE=' || L_BEN_POST_CODE);

    --Reason of Remittance Code
    L_REASON_REMIT_CODE := FN_GET_REMMITANCE_CODE(P_IFDMTAPA.v_iftb_mta_master.remit_reason_code);
    DBG('L_REASON_REMIT_CODE=' || L_REASON_REMIT_CODE);

    --Receiver Address
    L_BEN_ADDRESS := TRIM(P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS);
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);
    L_BEN_ADDRESS := REPLACE(L_BEN_ADDRESS, chr(10), '');
    DBG('L_BEN_ADDRESS after removing new line=' || length(L_BEN_ADDRESS));
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);

    --Receiver Bank Acc No
    L_BEN_BANK_AC_NO := P_IFDMTAPA.v_iftb_mta_master.ben_acc;
    DBG('L_BEN_BANK_AC_NO=' || L_BEN_BANK_AC_NO);

    --Receiver Bank Branch Code
    L_BEN_BANK_BRANCH_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bank_branch;
    DBG('L_BEN_BANK_BRANCH_CODE=' || L_BEN_BANK_BRANCH_CODE);

    --Receiver Bank Code
    L_BEN_BANK_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bic;
    DBG('L_BEN_BANK_CODE=' || L_BEN_BANK_CODE);

    --Receiver Email
    L_BEN_EMAIL := P_IFDMTAPA.v_iftb_mta_master.BEN_EMAIL;
    DBG('L_BEN_EMAIL=' || L_BEN_EMAIL);

    --Receiver Last Name nothing but ben name
    L_BEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.ben_name;
    DBG('L_BEN_LASTNAME=' || L_BEN_LASTNAME);

    --Receiver Nationality Code
    L_BEN_NAT_CODE := FN_GET_BEN_NAT_CODE(P_IFDMTAPA.v_iftb_mta_master.ben_nationality);
    DBG('L_BEN_NAT_CODE=' || L_BEN_NAT_CODE);

    --Receiver Mobile No
    L_BEN_MOB := P_IFDMTAPA.v_iftb_mta_master.ben_phone;
    DBG('L_BEN_MOB=' || L_BEN_MOB);

    --Remit Type
    L_REMIT_TYPE := P_IFDMTAPA.v_iftb_mta_master.remit_type;
    DBG('L_REMIT_TYPE=' || L_REMIT_TYPE);

    --Sender Address
    L_SEN_ADDR := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1 || ',' ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_2 || ',' ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_3 || ',' ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_4;

    DBG('L_SEN_ADDR=' || L_SEN_ADDR);

    --Sender DOB
    L_SEN_DOB := TO_CHAR(P_IFDMTAPA.v_iftb_mta_master.rem_dob, 'YYYY-MM-DD');
    DBG('L_SEN_DOB=' || L_SEN_DOB);

    --Sender city
    L_REM_CITY := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1; --pls check
    DBG('L_REM_CITY=' || L_REM_CITY);

    --Sender Email
    L_REM_EMAIL := P_IFDMTAPA.v_iftb_mta_master.rem_email;
    DBG('L_REM_EMAIL=' || L_REM_EMAIL);

    --Sender First name
    --L_SEN_FIRSTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;

    BEGIN
      SELECT B.FIRST_NAME, B.LAST_NAME
        INTO L_SEN_FIRSTNAME, L_SEN_LASTNAME
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_FIRSTNAME := NULL;
        L_SEN_LASTNAME  := NULL;
    END;

    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);
    L_SEN_FIRSTNAME := NVL(L_SEN_FIRSTNAME,
                           P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);

    --Sender Last Name
    --L_SEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    L_SEN_LASTNAME := NVL(L_SEN_LASTNAME,
                          P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    DBG('P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type=' ||
        P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type);
    --Sender card type code
    BEGIN
      SELECT CARD_TYPE_CODE
        INTO L_SEN_CARD_TYPE_CODE
        FROM sttb_mta_card_type_dtls
       WHERE card_type_name =
             P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_CARD_TYPE_CODE := NULL;
    END;
    DBG('L_SEN_CARD_TYPE_CODE=' || L_SEN_CARD_TYPE_CODE);

    IF L_SEN_CARD_TYPE_CODE IS NULL THEN
      L_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    END IF;

    --Sender card type val
    L_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_value;
    DBG('L_SEN_CARD_TYPE_VAL=' || L_SEN_CARD_TYPE_VAL);

    --Sender Last Name
    L_SEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    --Sender Nationality Code
    L_SEN_NAT_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_nationality;
    DBG('L_SEN_NAT_CODE=' || L_SEN_NAT_CODE);

    --Sender Occupation Code
    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('B2P', 'B2B') THEN
      L_SEN_OCC_CODE := FN_GET_NOB_CODE(P_IFDMTAPA.v_iftb_mta_master.REM_NOB);
    ELSE
      L_SEN_OCC_CODE := FN_GET_SEN_OCC_CODE(P_IFDMTAPA.v_iftb_mta_master.rem_occupation);
    END IF;
    DBG('L_SEN_OCC_CODE=' || L_SEN_OCC_CODE);

    --Sender Mobile
    L_REM_MOB := P_IFDMTAPA.v_iftb_mta_master.rem_phone;
    DBG('L_REM_MOB=' || L_REM_MOB);

    --Sender post code
    L_REM_POSTCODE := FN_GET_PINCODE_CUST(P_IFDMTAPA); --pls check

    DBG('L_REM_POSTCODE=' || L_REM_POSTCODE);

    --Sender state
    L_REM_STATE := 'CAMBODIA'; --null; --P_IFDMTAPA.v_iftb_mta_master.rem_phone; --pls check
    DBG('L_REM_STATE=' || L_REM_STATE);

    --Ben State
    L_STATE := P_IFDMTAPA.v_iftb_mta_master.BEN_state; --pls check
    DBG('L_BEN_STATE=' || L_STATE);

    --CBS Ref No
    L_CBS_REF_NO := P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO;

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_CITY', L_BEN_CITY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CURRENCY', L_CURRENCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_DOC_REF_NO',
                               L_DOC_REF_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_COUNTRY', L_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_MODE',
                               L_PAYMENT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_GRP_CODE',
                               L_PAYOUT_GRP_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_MODE',
                               L_PAYOUT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_POST_CODE',
                               L_BEN_POST_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REASON_REMIT_CODE',
                               L_REASON_REMIT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ADDRESS',
                               L_BEN_ADDRESS);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_AC_NO',
                               L_BEN_BANK_AC_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_BRANCH_CODE',
                               L_BEN_BANK_BRANCH_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_CODE',
                               L_BEN_BANK_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_EMAIL', L_BEN_EMAIL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LASTNAME',
                               L_BEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_NAT_CODE',
                               L_BEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_MOB', L_BEN_MOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REMIT_TYPE',
                               L_REMIT_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_ADDR', L_SEN_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_DOB', L_SEN_DOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_CITY', L_REM_CITY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_EMAIL', L_REM_EMAIL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_FIRSTNAME',
                               L_SEN_FIRSTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_CODE',
                               L_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_VAL',
                               L_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_LASTNAME',
                               L_SEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_NAT_CODE',
                               L_SEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_OCC_CODE',
                               L_SEN_OCC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_MOB', L_REM_MOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REM_POSTCODE',
                               L_REM_POSTCODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_STATE', L_REM_STATE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_STATE', L_STATE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CBS_REF_NO',
                               L_CBS_REF_NO);

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_MTA_PAYMENT_P2PAUS');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_MTA_PAYMENT_P2PAUS');
      DBG('ERROR CODE IN FN_GET_FMT_MTA_PAYMENT_P2PAUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_MTA_PAYMENT_P2PAUS=' || SQLERRM);
      RETURN L_FORMATTED_MSG;
  END FN_GET_FMT_MTA_PAYMENT_P2PAUS;

  FUNCTION FN_GET_MTA_P2P_EURO_PAYMENT RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_MTA_P2P_EURO_PAYMENT');

    L_FORMATTED_MSG := '{
    "amount": "$L_AMOUNT",
  "bic": "$L_BIC",
    "channelCode": "CBS",
    "currency": "$L_CURRENCY",
    "payoutGroupCode": "$L_PAYOUT_GRP_CODE",
    "payoutMode": "$L_PAYOUT_MODE",
    "reasonOfRemittanceCode": "$L_REASON_REMIT_CODE",
  "receiverAddress": "$L_BEN_ADDRESS",
  "receiverBankAcNo": "$L_BEN_BANK_AC_NO",
  "receiverBankBranchCode": "$L_BEN_BANK_BRANCH_CODE",
  "receiverBankCode": "$L_BEN_BANK_CODE",
    "receiverLastName": "$L_BEN_LASTNAME",
    "receiverNationalityCode": "$L_BEN_NAT_CODE",
    "remitType": "$L_REMIT_TYPE",
    "senderAddress": "$L_SEN_ADDR",
    "senderBirthDate": "$L_SEN_DOB",
  "senderFirstName": "$L_SEN_LASTNAME",
    "senderIdCardTypeCode": "$L_SEN_CARD_TYPE_CODE",
    "senderIdCardTypeNo": "$L_SEN_CARD_TYPE_VAL",
    "senderLastName": "$L_SEN_LASTNAME",
    "senderNationalityCode": "$L_SEN_NAT_CODE",
    "senderOccupationCode": "$L_SEN_OCC_CODE",
    "cbsRefNo": "$L_CBS_REF_NO"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_MTA_P2P_EURO_PAYMENT');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MTA_P2P_EURO_PAYMENT');
      DBG('ERROR CODE IN FN_GET_MTA_P2P_EURO_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MTA_P2P_EURO_PAYMENT=' || SQLERRM);

  END FN_GET_MTA_P2P_EURO_PAYMENT;

  FUNCTION FN_GET_FMT_MTA_P2PEURO_PAYMENT(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN CLOB IS

    L_AMOUNT       VARCHAR2(105);
    L_BIC          VARCHAR2(105);
    L_CHANNEL_CODE VARCHAR2(105);
    L_CURRENCY     VARCHAR2(105);

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);
    L_COUNTRY         VARCHAR2(105);
    L_PAYMENT_MODE    VARCHAR2(105);

    L_REASON_REMIT_CODE VARCHAR2(105);

    L_BEN_ADDRESS          VARCHAR2(105);
    L_BEN_BANK_AC_NO       VARCHAR2(105);
    L_BEN_BANK_BRANCH_CODE VARCHAR2(105);
    L_BEN_BANK_CODE        VARCHAR2(105);
    L_BEN_LASTNAME         VARCHAR2(105);
    L_BEN_NAT_CODE         VARCHAR2(105);

    L_REMIT_TYPE         VARCHAR2(105);
    L_SEN_ADDR           VARCHAR2(1000);
    L_SEN_DOB            VARCHAR2(105);
    L_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_SEN_FIRSTNAME      VARCHAR2(105);
    L_SEN_LASTNAME       VARCHAR2(105);
    L_SEN_NAT_CODE       VARCHAR2(105);
    L_SEN_OCC_CODE       VARCHAR2(105);
    L_CBS_REF_NO         IFTB_MTA_MASTER.TRN_REF_NO%TYPE;

    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('START OF FN_GET_FMT_MTA_P2PEURO_PAYMENT=' ||
        DBMS_UTILITY.format_call_stack);

    L_FORMATTED_MSG := FN_GET_MTA_P2P_EURO_PAYMENT;

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT JSON APPLE4=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values

    --Amount
    L_AMOUNT := P_IFDMTAPA.v_iftb_mta_master.txn_amt;

    DBG('L_AMOUNT=' || L_AMOUNT);

    --Bic
    L_BIC := NULL; --P_IFDMTAPA.v_iftb_mta_master.txn_amt; --pls check

    DBG('L_BIC=' || L_BIC);

    --Currency
    L_CURRENCY := P_IFDMTAPA.v_iftb_mta_master.txn_ccy;

    DBG('L_CURRENCY=' || L_CURRENCY);

    --L_PAYOUT_GRP_CODE and L_PAYOUT_MODE
    --Get country
    L_COUNTRY := P_IFDMTAPA.v_iftb_mta_master.ben_country;
    DBG('L_COUNTRY=' || L_COUNTRY);

    --Get Payment Mode
    L_PAYMENT_MODE := P_IFDMTAPA.v_iftb_mta_master.payment_mode;
    DBG('L_PAYMENT_MODE=' || L_PAYMENT_MODE);

    BEGIN
      SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
        INTO L_PAYOUT_GRP_CODE, L_PAYOUT_MODE
        FROM STTB_MTA_STATIC_AGENT_DTLS
       WHERE UPPER(COUNTRY_CODE) = L_COUNTRY
         AND PAYMENT_MODE = L_PAYMENT_MODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_PAYOUT_GRP_CODE := NULL;
        L_PAYOUT_MODE     := NULL;
    END;

    DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
    DBG('L_PAYOUT_MODE=' || L_PAYOUT_MODE);

    --Reason of Remittance Code
    L_REASON_REMIT_CODE := FN_GET_REMMITANCE_CODE(P_IFDMTAPA.v_iftb_mta_master.remit_reason_code);
    DBG('L_REASON_REMIT_CODE=' || L_REASON_REMIT_CODE);

    --Receiver Address
    L_BEN_ADDRESS := TRIM(P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS);
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);
    L_BEN_ADDRESS := REPLACE(L_BEN_ADDRESS, chr(10), '');
    DBG('L_BEN_ADDRESS after removing new line=' || length(L_BEN_ADDRESS));
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);

    --Receiver Bank Acc No
    L_BEN_BANK_AC_NO := P_IFDMTAPA.v_iftb_mta_master.ben_acc;
    DBG('L_BEN_BANK_AC_NO=' || L_BEN_BANK_AC_NO);

    --Receiver Bank Branch Code
    L_BEN_BANK_BRANCH_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bank_branch;
    DBG('L_BEN_BANK_BRANCH_CODE=' || L_BEN_BANK_BRANCH_CODE);

    --Receiver Bank Code
    L_BEN_BANK_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bic;
    DBG('L_BEN_BANK_CODE=' || L_BEN_BANK_CODE);

    --Receiver Last Name nothing but ben name
    L_BEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.ben_name;
    DBG('L_BEN_LASTNAME=' || L_BEN_LASTNAME);

    --Receiver Nationality Code
    L_BEN_NAT_CODE := FN_GET_BEN_NAT_CODE(P_IFDMTAPA.v_iftb_mta_master.ben_nationality);
    DBG('L_BEN_NAT_CODE=' || L_BEN_NAT_CODE);

    --Remit Type
    L_REMIT_TYPE := P_IFDMTAPA.v_iftb_mta_master.remit_type;
    DBG('L_REMIT_TYPE=' || L_REMIT_TYPE);

    --Sender Address
    L_SEN_ADDR := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_2 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_3 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_4;

    DBG('L_SEN_ADDR=' || L_SEN_ADDR);

    --Sender DOB
    L_SEN_DOB := TO_CHAR(P_IFDMTAPA.v_iftb_mta_master.rem_dob, 'YYYY-MM-DD');
    DBG('L_SEN_DOB=' || L_SEN_DOB);

    --Sender card type code
    BEGIN
      SELECT CARD_TYPE_CODE
        INTO L_SEN_CARD_TYPE_CODE
        FROM sttb_mta_card_type_dtls
       WHERE card_type_name =
             P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_CARD_TYPE_CODE := NULL;
    END;
    DBG('L_SEN_CARD_TYPE_CODE=' || L_SEN_CARD_TYPE_CODE);

    IF L_SEN_CARD_TYPE_CODE IS NULL THEN
      L_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    END IF;

    --Sender card type val
    L_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_value;
    DBG('L_SEN_CARD_TYPE_VAL=' || L_SEN_CARD_TYPE_VAL);

    --Sender First name
    --L_SEN_FIRSTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;

    BEGIN
      SELECT B.FIRST_NAME, B.LAST_NAME
        INTO L_SEN_FIRSTNAME, L_SEN_LASTNAME
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_FIRSTNAME := NULL;
        L_SEN_LASTNAME  := NULL;
    END;

    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);
    L_SEN_FIRSTNAME := NVL(L_SEN_FIRSTNAME,
                           P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);

    --Sender Last Name
    --L_SEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    L_SEN_LASTNAME := NVL(L_SEN_LASTNAME,
                          P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    --Sender Nationality Code
    L_SEN_NAT_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_nationality;
    DBG('L_SEN_NAT_CODE=' || L_SEN_NAT_CODE);

    --Sender Occupation Code
    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('B2P', 'B2B') THEN
      L_SEN_OCC_CODE := FN_GET_NOB_CODE(P_IFDMTAPA.v_iftb_mta_master.REM_NOB);
    ELSE
      L_SEN_OCC_CODE := FN_GET_SEN_OCC_CODE(P_IFDMTAPA.v_iftb_mta_master.rem_occupation);
    END IF;
    DBG('L_SEN_OCC_CODE=' || L_SEN_OCC_CODE);

    --CBS Ref No
    L_CBS_REF_NO := P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO;

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BIC', L_BIC);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CURRENCY', L_CURRENCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_COUNTRY', L_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_MODE',
                               L_PAYMENT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_GRP_CODE',
                               L_PAYOUT_GRP_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_MODE',
                               L_PAYOUT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REASON_REMIT_CODE',
                               L_REASON_REMIT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ADDRESS',
                               L_BEN_ADDRESS);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_AC_NO',
                               L_BEN_BANK_AC_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_BRANCH_CODE',
                               L_BEN_BANK_BRANCH_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_CODE',
                               L_BEN_BANK_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LASTNAME',
                               L_BEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_NAT_CODE',
                               L_BEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REMIT_TYPE',
                               L_REMIT_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_ADDR', L_SEN_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_DOB', L_SEN_DOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_CODE',
                               L_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_VAL',
                               L_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_FIRSTNAME',
                               L_SEN_FIRSTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_LASTNAME',
                               L_SEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_NAT_CODE',
                               L_SEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_OCC_CODE',
                               L_SEN_OCC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CBS_REF_NO',
                               L_CBS_REF_NO);

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_MTA_P2PEURO_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_MTA_P2PEURO_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_MTA_P2PEURO_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_MTA_P2PEURO_PAYMENT=' || SQLERRM);
      RETURN L_FORMATTED_MSG;
  END FN_GET_FMT_MTA_P2PEURO_PAYMENT;

  FUNCTION FN_GET_MTA_P2B_PAYMENT RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_MTA_P2B_PAYMENT');

    L_FORMATTED_MSG := '{
    "amount": "$L_AMOUNT",
    "channelCode": "CBS",
    "currency": "$L_CURRENCY",
    "payoutGroupCode": "$L_PAYOUT_GRP_CODE",
    "payoutMode": "$L_PAYOUT_MODE",
    "reasonOfRemittanceCode": "$L_REASON_REMIT_CODE",
    "receiverBankAcNo": "$L_BEN_BANK_AC_NO",
    "receiverBankBranchCode": "$L_BEN_BANK_BRANCH_CODE",
    "receiverBankCode": "$L_BEN_BANK_CODE",
    "receiverLastName": "$L_BEN_LASTNAME",
    "receiverNationalityCode": "$L_BEN_NAT_CODE",
    "remitType": "$L_REMIT_TYPE",
    "senderAddress": "$L_SEN_ADDR",
    "senderBirthDate": "$L_SEN_DOB",
    "senderFirstName": "$L_SEN_LASTNAME",
    "senderIdCardTypeCode": "$L_SEN_CARD_TYPE_CODE",
    "senderIdCardTypeNo": "$L_SEN_CARD_TYPE_VAL",
    "senderLastName": "$L_SEN_LASTNAME",
    "senderNationalityCode": "$L_SEN_NAT_CODE",
    "senderOccupationCode": "$L_SEN_OCC_CODE",
    "cbsRefNo": "$L_CBS_REF_NO"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_MTA_P2B_PAYMENT');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MTA_P2B_PAYMENT');
      DBG('ERROR CODE IN FN_GET_MTA_P2B_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MTA_P2B_PAYMENT=' || SQLERRM);

  END FN_GET_MTA_P2B_PAYMENT;

  FUNCTION FN_GET_FMT_MTA_P2B_PAYMENT(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN CLOB IS

    L_AMOUNT       VARCHAR2(105);
    L_CHANNEL_CODE VARCHAR2(105);
    L_CURRENCY     VARCHAR2(105);

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);
    L_COUNTRY         VARCHAR2(105);
    L_PAYMENT_MODE    VARCHAR2(105);

    L_REASON_REMIT_CODE VARCHAR2(105);

    L_BEN_BANK_AC_NO       VARCHAR2(105);
    L_BEN_BANK_BRANCH_CODE VARCHAR2(105);
    L_BEN_BANK_CODE        VARCHAR2(105);
    L_BEN_LASTNAME         VARCHAR2(105);
    L_BEN_NAT_CODE         VARCHAR2(105);

    L_REMIT_TYPE         VARCHAR2(105);
    L_SEN_ADDR           VARCHAR2(1000);
    L_SEN_DOB            VARCHAR2(105);
    L_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_SEN_FIRSTNAME      VARCHAR2(105);
    L_SEN_LASTNAME       VARCHAR2(105);
    L_SEN_NAT_CODE       VARCHAR2(105);
    L_SEN_OCC_CODE       VARCHAR2(105);
    L_CBS_REF_NO         IFTB_MTA_MASTER.TRN_REF_NO%TYPE;

    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('START OF FN_GET_FMT_MTA_P2B_PAYMENT=' ||
        DBMS_UTILITY.format_call_stack);

    L_FORMATTED_MSG := FN_GET_MTA_P2B_PAYMENT;

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT JSON APPLE5=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values

    --Amount
    L_AMOUNT := P_IFDMTAPA.v_iftb_mta_master.txn_amt;

    DBG('L_AMOUNT=' || L_AMOUNT);

    --Currency
    L_CURRENCY := P_IFDMTAPA.v_iftb_mta_master.txn_ccy;

    DBG('L_CURRENCY=' || L_CURRENCY);

    --L_PAYOUT_GRP_CODE and L_PAYOUT_MODE
    --Get country
    L_COUNTRY := P_IFDMTAPA.v_iftb_mta_master.ben_country;
    DBG('L_COUNTRY=' || L_COUNTRY);

    --Get Payment Mode
    L_PAYMENT_MODE := P_IFDMTAPA.v_iftb_mta_master.payment_mode;
    DBG('L_PAYMENT_MODE=' || L_PAYMENT_MODE);

    BEGIN
      SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
        INTO L_PAYOUT_GRP_CODE, L_PAYOUT_MODE
        FROM STTB_MTA_STATIC_AGENT_DTLS
       WHERE UPPER(COUNTRY_CODE) = L_COUNTRY
         AND PAYMENT_MODE = L_PAYMENT_MODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_PAYOUT_GRP_CODE := NULL;
        L_PAYOUT_MODE     := NULL;
    END;

    DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
    DBG('L_PAYOUT_MODE=' || L_PAYOUT_MODE);

    --Reason of Remittance Code
    L_REASON_REMIT_CODE := FN_GET_REMMITANCE_CODE(P_IFDMTAPA.v_iftb_mta_master.remit_reason_code);
    DBG('L_REASON_REMIT_CODE=' || L_REASON_REMIT_CODE);

    --Receiver Bank Acc No
    L_BEN_BANK_AC_NO := P_IFDMTAPA.v_iftb_mta_master.ben_acc;
    DBG('L_BEN_BANK_AC_NO=' || L_BEN_BANK_AC_NO);

    --Receiver Bank Branch Code
    L_BEN_BANK_BRANCH_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bank_branch;
    DBG('L_BEN_BANK_BRANCH_CODE=' || L_BEN_BANK_BRANCH_CODE);

    --Receiver Bank Code
    L_BEN_BANK_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bic;
    DBG('L_BEN_BANK_CODE=' || L_BEN_BANK_CODE);

    --Receiver Last Name nothing but ben name
    L_BEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.ben_name;
    DBG('L_BEN_LASTNAME=' || L_BEN_LASTNAME);

    --Receiver Nationality Code
    L_BEN_NAT_CODE := FN_GET_BEN_NAT_CODE(P_IFDMTAPA.v_iftb_mta_master.ben_nationality);
    DBG('L_BEN_NAT_CODE=' || L_BEN_NAT_CODE);

    --Remit Type
    L_REMIT_TYPE := P_IFDMTAPA.v_iftb_mta_master.remit_type;
    DBG('L_REMIT_TYPE=' || L_REMIT_TYPE);

    --Sender Address
    L_SEN_ADDR := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_2 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_3 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_4;

    DBG('L_SEN_ADDR=' || L_SEN_ADDR);

    --Sender DOB
    L_SEN_DOB := TO_CHAR(P_IFDMTAPA.v_iftb_mta_master.rem_dob, 'YYYY-MM-DD');
    DBG('L_SEN_DOB=' || L_SEN_DOB);

    --Sender card type code
    BEGIN
      SELECT CARD_TYPE_CODE
        INTO L_SEN_CARD_TYPE_CODE
        FROM sttb_mta_card_type_dtls
       WHERE card_type_name =
             P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_CARD_TYPE_CODE := NULL;
    END;
    DBG('L_SEN_CARD_TYPE_CODE=' || L_SEN_CARD_TYPE_CODE);

    IF L_SEN_CARD_TYPE_CODE IS NULL THEN
      L_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    END IF;

    --Sender card type val
    L_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_value;
    DBG('L_SEN_CARD_TYPE_VAL=' || L_SEN_CARD_TYPE_VAL);

    --Sender First name
    --L_SEN_FIRSTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;

    BEGIN
      SELECT B.FIRST_NAME, B.LAST_NAME
        INTO L_SEN_FIRSTNAME, L_SEN_LASTNAME
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_FIRSTNAME := NULL;
        L_SEN_LASTNAME  := NULL;
    END;

    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);
    L_SEN_FIRSTNAME := NVL(L_SEN_FIRSTNAME,
                           P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);

    --Sender Last Name
    --L_SEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    L_SEN_LASTNAME := NVL(L_SEN_LASTNAME,
                          P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    --Sender Nationality Code
    L_SEN_NAT_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_nationality;
    DBG('L_SEN_NAT_CODE=' || L_SEN_NAT_CODE);

    --Sender Occupation Code
    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('B2P', 'B2B') THEN
      L_SEN_OCC_CODE := FN_GET_NOB_CODE(P_IFDMTAPA.v_iftb_mta_master.REM_NOB);
    ELSE
      L_SEN_OCC_CODE := FN_GET_SEN_OCC_CODE(P_IFDMTAPA.v_iftb_mta_master.rem_occupation);
    END IF;
    DBG('L_SEN_OCC_CODE=' || L_SEN_OCC_CODE);

    --CBS Ref No
    L_CBS_REF_NO := P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO;

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CURRENCY', L_CURRENCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_COUNTRY', L_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_MODE',
                               L_PAYMENT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_GRP_CODE',
                               L_PAYOUT_GRP_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_MODE',
                               L_PAYOUT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REASON_REMIT_CODE',
                               L_REASON_REMIT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_AC_NO',
                               L_BEN_BANK_AC_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_BRANCH_CODE',
                               L_BEN_BANK_BRANCH_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_CODE',
                               L_BEN_BANK_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LASTNAME',
                               L_BEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_NAT_CODE',
                               L_BEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REMIT_TYPE',
                               L_REMIT_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_ADDR', L_SEN_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_DOB', L_SEN_DOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_CODE',
                               L_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_VAL',
                               L_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_FIRSTNAME',
                               L_SEN_FIRSTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_LASTNAME',
                               L_SEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_NAT_CODE',
                               L_SEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_OCC_CODE',
                               L_SEN_OCC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CBS_REF_NO',
                               L_CBS_REF_NO);

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_MTA_P2B_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_MTA_P2B_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_MTA_P2B_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_MTA_P2B_PAYMENT=' || SQLERRM);
      RETURN L_FORMATTED_MSG;
  END FN_GET_FMT_MTA_P2B_PAYMENT;

  FUNCTION FN_GET_MTA_PAYMENT_P2BAUS RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_MTA_PAYMENT_P2BAUS');

    L_FORMATTED_MSG := '{
    "amount": "$L_AMOUNT",
    "channelCode": "CBS",
  "city": "$L_BEN_CITY",
  "companyType": "$L_COMPANY_TYPE",
    "currency": "$L_CURRENCY",
  "documentRefNo": "$L_DOC_REF_NO",
    "payoutGroupCode": "$L_PAYOUT_GRP_CODE",
    "payoutMode": "$L_PAYOUT_MODE",
  "postCode": "$L_BEN_POST_CODE",
    "reasonOfRemittanceCode": "$L_REASON_REMIT_CODE",
  "receiverAddress":"$L_BEN_ADDRESS",
  "receiverBankAcNo": "$L_BEN_BANK_AC_NO",
  "receiverBankBranchCode": "$L_BEN_BANK_BRANCH_CODE",
  "receiverBankCode": "$L_BEN_BANK_CODE",
  "receiverEmail": "$L_BEN_EMAIL",
    "receiverLastName": "$L_BEN_LASTNAME",
    "receiverNationalityCode": "$L_BEN_NAT_CODE",
  "receiverPhoneNo": "$L_BEN_MOB",
    "remitType": "$L_REMIT_TYPE",
    "senderAddress": "$L_SEN_ADDR",
    "senderBirthDate": "$L_SEN_DOB",
  "senderCity": "$L_REM_CITY",
  "senderEmail": "$L_REM_EMAIL",
  "senderFirstName": "$L_SEN_FIRSTNAME",
    "senderIdCardTypeCode": "$L_SEN_CARD_TYPE_CODE",
    "senderIdCardTypeNo": "$L_SEN_CARD_TYPE_VAL",
    "senderLastName": "$L_SEN_LASTNAME",
    "senderNationalityCode": "$L_SEN_NAT_CODE",
    "senderOccupationCode": "$L_SEN_OCC_CODE",
  "senderPhoneNo": "$L_REM_MOB",
    "senderPostCode": "$L_REM_POSTCODE",
    "senderState": "$L_REM_STATE",
    "state": "$L_STATE",
    "cbsRefNo": "$L_CBS_REF_NO"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_MTA_PAYMENT_P2BAUS');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MTA_PAYMENT_P2BAUS');
      DBG('ERROR CODE IN FN_GET_MTA_PAYMENT_P2BAUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MTA_PAYMENT_P2BAUS=' || SQLERRM);

  END FN_GET_MTA_PAYMENT_P2BAUS;

  FUNCTION FN_GET_FMT_MTA_PAYMENT_P2BAUS(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN CLOB IS

    L_AMOUNT       VARCHAR2(105);
    L_CHANNEL_CODE VARCHAR2(105);
    L_BEN_CITY     VARCHAR2(105);
    L_COMPANY_TYPE VARCHAR2(105);
    L_CURRENCY     VARCHAR2(105);
    L_DOC_REF_NO   VARCHAR2(105);

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);
    L_COUNTRY         VARCHAR2(105);

    L_BEN_POST_CODE VARCHAR2(105);

    L_PAYMENT_MODE VARCHAR2(105);

    L_REASON_REMIT_CODE VARCHAR2(105);

    L_BEN_ADDRESS          VARCHAR2(105);
    L_BEN_BANK_AC_NO       VARCHAR2(105);
    L_BEN_BANK_BRANCH_CODE VARCHAR2(105);
    L_BEN_BANK_CODE        VARCHAR2(105);
    L_BEN_EMAIL            VARCHAR2(105);
    L_BEN_LASTNAME         VARCHAR2(105);
    L_BEN_NAT_CODE         VARCHAR2(105);
    L_BEN_MOB              VARCHAR2(105);

    L_REMIT_TYPE         VARCHAR2(105);
    L_SEN_ADDR           VARCHAR2(1000);
    L_SEN_DOB            VARCHAR2(105);
    L_REM_CITY           VARCHAR2(105);
    L_REM_EMAIL          VARCHAR2(105);
    L_SEN_FIRSTNAME      VARCHAR2(105);
    L_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_SEN_LASTNAME       VARCHAR2(105);
    L_SEN_NAT_CODE       VARCHAR2(105);
    L_SEN_OCC_CODE       VARCHAR2(105);
    L_REM_MOB            VARCHAR2(105);
    L_REM_POSTCODE       VARCHAR2(105);
    L_POST_CODE          VARCHAR2(105);
    L_REM_STATE          VARCHAR2(105);
    L_STATE              VARCHAR2(105);
    L_CBS_REF_NO         IFTB_MTA_MASTER.TRN_REF_NO%TYPE;

    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('START OF FN_GET_FMT_MTA_PAYMENT_P2BAUS=' ||
        DBMS_UTILITY.format_call_stack);

    L_FORMATTED_MSG := FN_GET_MTA_PAYMENT_P2BAUS;

    DBG('BEFORE REPLACEMENT OF AITAA PAYMENT JSON APPLE6=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values

    --Amount
    L_AMOUNT := P_IFDMTAPA.v_iftb_mta_master.txn_amt;

    DBG('L_AMOUNT=' || L_AMOUNT);

    --City
    L_BEN_CITY := P_IFDMTAPA.v_iftb_mta_master.BEN_CITY;
    DBG('L_BEN_CITY=' || L_BEN_CITY);

    --Company Type
    L_COMPANY_TYPE := P_IFDMTAPA.v_iftb_mta_master.COMPANY_TYPE; --pls check add this field
    DBG('L_COMPANY_TYPE=' || L_COMPANY_TYPE);

    --Currency
    L_CURRENCY := P_IFDMTAPA.v_iftb_mta_master.txn_ccy;

    DBG('L_CURRENCY=' || L_CURRENCY);

    --Document ref no
    L_DOC_REF_NO := P_IFDMTAPA.v_iftb_mta_master.DOCUMENT_REF_NO; --pls check
    DBG('L_DOC_REF_NO=' || L_DOC_REF_NO);

    --L_PAYOUT_GRP_CODE and L_PAYOUT_MODE
    --Get country
    L_COUNTRY := P_IFDMTAPA.v_iftb_mta_master.ben_country;
    DBG('L_COUNTRY=' || L_COUNTRY);

    --Get Payment Mode
    L_PAYMENT_MODE := P_IFDMTAPA.v_iftb_mta_master.payment_mode;
    DBG('L_PAYMENT_MODE=' || L_PAYMENT_MODE);

    BEGIN
      SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
        INTO L_PAYOUT_GRP_CODE, L_PAYOUT_MODE
        FROM STTB_MTA_STATIC_AGENT_DTLS
       WHERE UPPER(COUNTRY_CODE) = L_COUNTRY
         AND PAYMENT_MODE = L_PAYMENT_MODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_PAYOUT_GRP_CODE := NULL;
        L_PAYOUT_MODE     := NULL;
    END;

    DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
    DBG('L_PAYOUT_MODE=' || L_PAYOUT_MODE);

    L_BEN_POST_CODE := P_IFDMTAPA.v_iftb_mta_master.BEN_POST_CODE;
    DBG('L_BEN_POST_CODE=' || L_BEN_POST_CODE);

    --Reason of Remittance Code
    L_REASON_REMIT_CODE := FN_GET_REMMITANCE_CODE(P_IFDMTAPA.v_iftb_mta_master.remit_reason_code);
    DBG('L_REASON_REMIT_CODE=' || L_REASON_REMIT_CODE);

    --Receiver Address
    L_BEN_ADDRESS := TRIM(P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS);
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);
    L_BEN_ADDRESS := REPLACE(L_BEN_ADDRESS, chr(10), '');
    DBG('L_BEN_ADDRESS after removing new line=' || length(L_BEN_ADDRESS));
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);

    --Receiver Bank Acc No
    L_BEN_BANK_AC_NO := P_IFDMTAPA.v_iftb_mta_master.ben_acc;
    DBG('L_BEN_BANK_AC_NO=' || L_BEN_BANK_AC_NO);

    --Receiver Bank Branch Code
    L_BEN_BANK_BRANCH_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bank_branch;
    DBG('L_BEN_BANK_BRANCH_CODE=' || L_BEN_BANK_BRANCH_CODE);

    --Receiver Bank Code
    L_BEN_BANK_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bic;
    DBG('L_BEN_BANK_CODE=' || L_BEN_BANK_CODE);

    --Receiver Email
    L_BEN_EMAIL := P_IFDMTAPA.v_iftb_mta_master.BEN_EMAIL;
    DBG('L_BEN_EMAIL=' || L_BEN_EMAIL);

    --Receiver Last Name nothing but ben name
    L_BEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.ben_name;
    DBG('L_BEN_LASTNAME=' || L_BEN_LASTNAME);

    --Receiver Nationality Code
    L_BEN_NAT_CODE := FN_GET_BEN_NAT_CODE(P_IFDMTAPA.v_iftb_mta_master.ben_nationality);
    DBG('L_BEN_NAT_CODE=' || L_BEN_NAT_CODE);

    --Receiver Mobile No
    L_BEN_MOB := P_IFDMTAPA.v_iftb_mta_master.ben_phone;
    DBG('L_BEN_MOB=' || L_BEN_MOB);

    --Remit Type
    L_REMIT_TYPE := P_IFDMTAPA.v_iftb_mta_master.remit_type;
    DBG('L_REMIT_TYPE=' || L_REMIT_TYPE);

    --Sender Address
    L_SEN_ADDR := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_2 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_3 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_4;

    DBG('L_SEN_ADDR=' || L_SEN_ADDR);

    --Sender DOB
    L_SEN_DOB := TO_CHAR(P_IFDMTAPA.v_iftb_mta_master.rem_dob, 'YYYY-MM-DD');
    DBG('L_SEN_DOB=' || L_SEN_DOB);

    --Sender city
    L_REM_CITY := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1; --pls check
    DBG('L_REM_CITY=' || L_REM_CITY);

    --Sender Email
    L_REM_EMAIL := P_IFDMTAPA.v_iftb_mta_master.rem_email;
    DBG('L_REM_EMAIL=' || L_REM_EMAIL);

    --Sender card type code
    BEGIN
      SELECT CARD_TYPE_CODE
        INTO L_SEN_CARD_TYPE_CODE
        FROM sttb_mta_card_type_dtls
       WHERE card_type_name =
             P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_CARD_TYPE_CODE := NULL;
    END;
    DBG('L_SEN_CARD_TYPE_CODE=' || L_SEN_CARD_TYPE_CODE);

    IF L_SEN_CARD_TYPE_CODE IS NULL THEN
      L_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    END IF;

    --Sender card type val
    L_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_value;
    DBG('L_SEN_CARD_TYPE_VAL=' || L_SEN_CARD_TYPE_VAL);

    --Sender First name
    --L_SEN_FIRSTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;

    BEGIN
      SELECT B.FIRST_NAME, B.LAST_NAME
        INTO L_SEN_FIRSTNAME, L_SEN_LASTNAME
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_FIRSTNAME := NULL;
        L_SEN_LASTNAME  := NULL;
    END;

    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);
    L_SEN_FIRSTNAME := NVL(L_SEN_FIRSTNAME,
                           P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);

    --Sender Last Name
    --L_SEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    L_SEN_LASTNAME := NVL(L_SEN_LASTNAME,
                          P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    --Sender Nationality Code
    L_SEN_NAT_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_nationality;
    DBG('L_SEN_NAT_CODE=' || L_SEN_NAT_CODE);

    --Sender Occupation Code
    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('B2P', 'B2B') THEN
      L_SEN_OCC_CODE := FN_GET_NOB_CODE(P_IFDMTAPA.v_iftb_mta_master.REM_NOB);
    ELSE
      L_SEN_OCC_CODE := FN_GET_SEN_OCC_CODE(P_IFDMTAPA.v_iftb_mta_master.rem_occupation);
    END IF;
    DBG('L_SEN_OCC_CODE=' || L_SEN_OCC_CODE);

    --Sender Mobile
    L_REM_MOB := P_IFDMTAPA.v_iftb_mta_master.rem_phone;
    DBG('L_REM_MOB=' || L_REM_MOB);

    --Sender post code
    L_REM_POSTCODE := FN_GET_PINCODE_CUST(P_IFDMTAPA); --P_IFDMTAPA.v_iftb_mta_master.rem_phone; --pls check

    L_POST_CODE := FN_GET_PINCODE_CUST(P_IFDMTAPA);

    DBG('L_REM_POSTCODE=' || L_REM_POSTCODE);

    --Sender state
    L_REM_STATE := 'CAMBODIA'; --P_IFDMTAPA.v_iftb_mta_master.rem_phone; --pls check
    DBG('L_REM_STATE=' || L_REM_STATE);

    --Ben State
    L_STATE := P_IFDMTAPA.v_iftb_mta_master.BEN_state; --pls check
    DBG('L_BEN_STATE=' || L_STATE);

    --CBS Ref No
    L_CBS_REF_NO := P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO;

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_CITY', L_BEN_CITY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_COMPANY_TYPE',
                               L_COMPANY_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CURRENCY', L_CURRENCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_DOC_REF_NO',
                               L_DOC_REF_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_COUNTRY', L_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_MODE',
                               L_PAYMENT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_GRP_CODE',
                               L_PAYOUT_GRP_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_MODE',
                               L_PAYOUT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_POST_CODE',
                               L_BEN_POST_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REASON_REMIT_CODE',
                               L_REASON_REMIT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ADDRESS',
                               L_BEN_ADDRESS);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_AC_NO',
                               L_BEN_BANK_AC_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_BRANCH_CODE',
                               L_BEN_BANK_BRANCH_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_CODE',
                               L_BEN_BANK_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_EMAIL', L_BEN_EMAIL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LASTNAME',
                               L_BEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_NAT_CODE',
                               L_BEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_MOB', L_BEN_MOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REMIT_TYPE',
                               L_REMIT_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_ADDR', L_SEN_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_DOB', L_SEN_DOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_CITY', L_REM_CITY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_EMAIL', L_REM_EMAIL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_FIRSTNAME',
                               L_SEN_FIRSTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_CODE',
                               L_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_VAL',
                               L_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_LASTNAME',
                               L_SEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_NAT_CODE',
                               L_SEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_OCC_CODE',
                               L_SEN_OCC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_MOB', L_REM_MOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REM_POSTCODE',
                               L_REM_POSTCODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_POST_CODE', L_POST_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_STATE', L_REM_STATE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_STATE', L_STATE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CBS_REF_NO',
                               L_CBS_REF_NO);

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_MTA_PAYMENT_P2BAUS');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_MTA_PAYMENT_P2BAUS');
      DBG('ERROR CODE IN FN_GET_FMT_MTA_PAYMENT_P2BAUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_MTA_PAYMENT_P2BAUS=' || SQLERRM);
      RETURN L_FORMATTED_MSG;
  END FN_GET_FMT_MTA_PAYMENT_P2BAUS;

  FUNCTION FN_GET_MTA_B2B_PAYMENT RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_MTA_B2B_PAYMENT');

    L_FORMATTED_MSG := '{
    "amount": "$L_AMOUNT",
    "channelCode": "CBS",
  "countryofBusiness": "$L_COUNTRY_OF_BUS",
    "currency": "$L_CURRENCY",
    "payoutGroupCode": "$L_PAYOUT_GRP_CODE",
    "payoutMode": "$L_PAYOUT_MODE",
  "personIdCardTypeCode": "1",
    "personIdCardTypeNo": "personIdCardTypeNo",
    "personName": "personName",
    "reasonOfRemittanceCode": "$L_REASON_REMIT_CODE",
  "receiverBankAcNo": "$L_BEN_BANK_AC_NO",
  "receiverBankBranchCode": "$L_BEN_BANK_BRANCH_CODE",
  "receiverBankCode": "$L_BEN_BANK_CODE",
    "receiverLastName": "$L_BEN_LASTNAME",
    "receiverNationalityCode": "$L_BEN_NAT_CODE",
    "remitType": "$L_REMIT_TYPE",
    "senderAddress": "$L_SEN_ADDR",
    "senderBirthDate": "$L_SEN_DOB",
  "senderFirstName": "$L_SEN_LASTNAME",
    "senderIdCardTypeCode": "$L_SEN_CARD_TYPE_CODE",
    "senderIdCardTypeNo": "$L_SEN_CARD_TYPE_VAL",
    "senderLastName": "$L_SEN_LASTNAME",
    "senderNationalityCode": "$L_SEN_NAT_CODE",
    "senderOccupationCode": "$L_SEN_OCC_CODE",
    "cbsRefNo": "$L_CBS_REF_NO"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_MTA_B2B_PAYMENT');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MTA_B2B_PAYMENT');
      DBG('ERROR CODE IN FN_GET_MTA_B2B_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MTA_B2B_PAYMENT=' || SQLERRM);

  END FN_GET_MTA_B2B_PAYMENT;

  FUNCTION FN_GET_FMT_MTA_B2B_PAYMENT(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN CLOB IS

    L_AMOUNT         VARCHAR2(105);
    L_CHANNEL_CODE   VARCHAR2(105);
    L_COUNTRY_OF_BUS VARCHAR2(105);
    L_CURRENCY       VARCHAR2(105);

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);
    L_COUNTRY         VARCHAR2(105);
    L_PAYMENT_MODE    VARCHAR2(105);

    L_BUS_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_BUS_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_BUS_SEN_NAME           VARCHAR2(1000);

    L_REASON_REMIT_CODE VARCHAR2(105);

    L_BEN_BANK_AC_NO       VARCHAR2(105);
    L_BEN_BANK_BRANCH_CODE VARCHAR2(105);
    L_BEN_BANK_CODE        VARCHAR2(105);
    L_BEN_LASTNAME         VARCHAR2(105);
    L_BEN_NAT_CODE         VARCHAR2(105);

    L_REMIT_TYPE         VARCHAR2(105);
    L_SEN_ADDR           VARCHAR2(1000);
    L_SEN_DOB            VARCHAR2(105);
    L_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_SEN_FIRSTNAME      VARCHAR2(105);
    L_SEN_LASTNAME       VARCHAR2(105);
    L_SEN_NAT_CODE       VARCHAR2(105);
    L_SEN_OCC_CODE       VARCHAR2(105);
    L_CBS_REF_NO         IFTB_MTA_MASTER.TRN_REF_NO%TYPE;

    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('START OF FN_GET_FMT_MTA_B2B_PAYMENT=' ||
        DBMS_UTILITY.format_call_stack);

    L_FORMATTED_MSG := FN_GET_MTA_B2B_PAYMENT;

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT JSON APPLE7=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values

    --Amount
    L_AMOUNT := P_IFDMTAPA.v_iftb_mta_master.txn_amt;

    DBG('L_AMOUNT=' || L_AMOUNT);

    --Country of Business
    L_COUNTRY_OF_BUS := 'KH'; --null; --pls check add field

    DBG('L_COUNTRY_OF_BUS=' || L_COUNTRY_OF_BUS);

    --Currency
    L_CURRENCY := P_IFDMTAPA.v_iftb_mta_master.txn_ccy;

    DBG('L_CURRENCY=' || L_CURRENCY);

    --L_PAYOUT_GRP_CODE and L_PAYOUT_MODE
    --Get country
    L_COUNTRY := P_IFDMTAPA.v_iftb_mta_master.ben_country;
    DBG('L_COUNTRY=' || L_COUNTRY);

    --Get Payment Mode
    L_PAYMENT_MODE := P_IFDMTAPA.v_iftb_mta_master.payment_mode;
    DBG('L_PAYMENT_MODE=' || L_PAYMENT_MODE);

    BEGIN
      SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
        INTO L_PAYOUT_GRP_CODE, L_PAYOUT_MODE
        FROM STTB_MTA_STATIC_AGENT_DTLS
       WHERE UPPER(COUNTRY_CODE) = L_COUNTRY
         AND PAYMENT_MODE = L_PAYMENT_MODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_PAYOUT_GRP_CODE := NULL;
        L_PAYOUT_MODE     := NULL;
    END;

    DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
    DBG('L_PAYOUT_MODE=' || L_PAYOUT_MODE);

    --Bus sen card type code
    L_BUS_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.BUS_SEN_CARD_TYPE_CODE; --null; --pls check add field
    DBG('L_BUS_SEN_CARD_TYPE_CODE=' || L_BUS_SEN_CARD_TYPE_CODE);

    --Bus sen card type value
    L_BUS_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.BUS_SEN_CARD_TYPE_VAL; -- null; --pls check add field
    DBG('L_BUS_SEN_CARD_TYPE_VAL=' || L_BUS_SEN_CARD_TYPE_VAL);

    --Bus sen name
    L_BUS_SEN_NAME := P_IFDMTAPA.v_iftb_mta_master.BUS_SEN_NAME; --null; --pls check add field
    DBG('L_BUS_SEN_NAME=' || L_BUS_SEN_NAME);

    --Reason of Remittance Code
    L_REASON_REMIT_CODE := FN_GET_REMMITANCE_CODE(P_IFDMTAPA.v_iftb_mta_master.remit_reason_code);
    DBG('L_REASON_REMIT_CODE=' || L_REASON_REMIT_CODE);

    --Receiver Bank Acc No
    L_BEN_BANK_AC_NO := P_IFDMTAPA.v_iftb_mta_master.ben_acc;
    DBG('L_BEN_BANK_AC_NO=' || L_BEN_BANK_AC_NO);

    --Receiver Bank Branch Code
    L_BEN_BANK_BRANCH_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bank_branch;
    DBG('L_BEN_BANK_BRANCH_CODE=' || L_BEN_BANK_BRANCH_CODE);

    --Receiver Bank Code
    L_BEN_BANK_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bic;
    DBG('L_BEN_BANK_CODE=' || L_BEN_BANK_CODE);

    --Receiver Last Name nothing but ben name
    L_BEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.ben_name;
    DBG('L_BEN_LASTNAME=' || L_BEN_LASTNAME);

    --Receiver Nationality Code
    L_BEN_NAT_CODE := FN_GET_BEN_NAT_CODE(P_IFDMTAPA.v_iftb_mta_master.ben_nationality);
    DBG('L_BEN_NAT_CODE=' || L_BEN_NAT_CODE);

    --Remit Type
    L_REMIT_TYPE := P_IFDMTAPA.v_iftb_mta_master.remit_type;
    DBG('L_REMIT_TYPE=' || L_REMIT_TYPE);

    --Sender Address
    L_SEN_ADDR := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_2 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_3 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_4;

    DBG('L_SEN_ADDR=' || L_SEN_ADDR);

    --Sender DOB
    L_SEN_DOB := TO_CHAR(P_IFDMTAPA.v_iftb_mta_master.rem_dob, 'YYYY-MM-DD');
    DBG('L_SEN_DOB=' || L_SEN_DOB);

    --Sender card type code
    BEGIN
      SELECT CARD_TYPE_CODE
        INTO L_SEN_CARD_TYPE_CODE
        FROM sttb_mta_card_type_dtls
       WHERE card_type_name =
             P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_CARD_TYPE_CODE := NULL;
    END;
    DBG('L_SEN_CARD_TYPE_CODE=' || L_SEN_CARD_TYPE_CODE);

    IF L_SEN_CARD_TYPE_CODE IS NULL THEN
      L_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    END IF;

    --Sender card type val
    L_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_value;
    DBG('L_SEN_CARD_TYPE_VAL=' || L_SEN_CARD_TYPE_VAL);

    --Sender First name
    --L_SEN_FIRSTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;

    BEGIN
      SELECT B.FIRST_NAME, B.LAST_NAME
        INTO L_SEN_FIRSTNAME, L_SEN_LASTNAME
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_FIRSTNAME := NULL;
        L_SEN_LASTNAME  := NULL;
    END;

    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);
    L_SEN_FIRSTNAME := NVL(L_SEN_FIRSTNAME,
                           P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);

    --Sender Last Name
    --L_SEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    L_SEN_LASTNAME := NVL(L_SEN_LASTNAME,
                          P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    --Sender Nationality Code
    L_SEN_NAT_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_nationality;
    DBG('L_SEN_NAT_CODE=' || L_SEN_NAT_CODE);

    --Sender Occupation Code
    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('B2P', 'B2B') THEN
      L_SEN_OCC_CODE := FN_GET_NOB_CODE(P_IFDMTAPA.v_iftb_mta_master.REM_NOB);
    ELSE
      L_SEN_OCC_CODE := FN_GET_SEN_OCC_CODE(P_IFDMTAPA.v_iftb_mta_master.rem_occupation);
    END IF;
    DBG('L_SEN_OCC_CODE=' || L_SEN_OCC_CODE);

    --CBS Ref No
    L_CBS_REF_NO := P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO;

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_COUNTRY_OF_BUS',
                               L_COUNTRY_OF_BUS);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CURRENCY', L_CURRENCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_COUNTRY', L_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_MODE',
                               L_PAYMENT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_GRP_CODE',
                               L_PAYOUT_GRP_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_MODE',
                               L_PAYOUT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BUS_SEN_CARD_TYPE_CODE',
                               L_BUS_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BUS_SEN_CARD_TYPE_VAL',
                               L_BUS_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BUS_SEN_NAME',
                               L_BUS_SEN_NAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REASON_REMIT_CODE',
                               L_REASON_REMIT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_AC_NO',
                               L_BEN_BANK_AC_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_BRANCH_CODE',
                               L_BEN_BANK_BRANCH_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_CODE',
                               L_BEN_BANK_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LASTNAME',
                               L_BEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_NAT_CODE',
                               L_BEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REMIT_TYPE',
                               L_REMIT_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_ADDR', L_SEN_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_DOB', L_SEN_DOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_CODE',
                               L_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_VAL',
                               L_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_FIRSTNAME',
                               L_SEN_FIRSTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_LASTNAME',
                               L_SEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_NAT_CODE',
                               L_SEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_OCC_CODE',
                               L_SEN_OCC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CBS_REF_NO',
                               L_CBS_REF_NO);

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_MTA_B2B_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_MTA_B2B_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_MTA_B2B_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_MTA_B2B_PAYMENT=' || SQLERRM);
      RETURN L_FORMATTED_MSG;
  END FN_GET_FMT_MTA_B2B_PAYMENT;

  FUNCTION FN_GET_MTA_PAYMENT_B2BAUS RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_MTA_PAYMENT_B2BAUS');

    L_FORMATTED_MSG := '{
    "amount": "$L_AMOUNT",
    "channelCode": "CBS",
  "city": "$L_BEN_CITY",
  "companyType": "$L_COMPANY_TYPE",
  "countryofBusiness": "KH",
    "currency": "$L_CURRENCY",
  "documentRefNo": "$L_DOC_REF_NO",
    "payoutGroupCode": "$L_PAYOUT_GRP_CODE",
    "payoutMode": "$L_PAYOUT_MODE",
  "personIdCardTypeCode": "1",
    "personIdCardTypeNo": "personIdCardTypeNo",
    "personName": "personName",
  "postCode": "$L_BEN_POST_CODE",
    "reasonOfRemittanceCode": "$L_REASON_REMIT_CODE",
  "receiverAddress":"$L_BEN_ADDRESS",
  "receiverBankAcNo": "$L_BEN_BANK_AC_NO",
  "receiverBankBranchCode": "$L_BEN_BANK_BRANCH_CODE",
  "receiverBankCode": "$L_BEN_BANK_CODE",
  "receiverEmail": "$L_BEN_EMAIL",
    "receiverLastName": "$L_BEN_LASTNAME",
    "receiverNationalityCode": "$L_BEN_NAT_CODE",
  "receiverPhoneNo": "$L_BEN_MOB",
    "remitType": "$L_REMIT_TYPE",
    "senderAddress": "$L_SEN_ADDR",
    "senderBirthDate": "$L_SEN_DOB",
  "senderCity": "$L_REM_CITY",
  "senderEmail": "$L_REM_EMAIL",
  "senderFirstName": "$L_SEN_FIRSTNAME",
    "senderIdCardTypeCode": "$L_SEN_CARD_TYPE_CODE",
    "senderIdCardTypeNo": "$L_SEN_CARD_TYPE_VAL",
    "senderLastName": "$L_SEN_LASTNAME",
    "senderNationalityCode": "$L_SEN_NAT_CODE",
    "senderOccupationCode": "$L_SEN_OCC_CODE",
  "senderPhoneNo": "$L_REM_MOB",
    "senderPostCode": "$L_REM_POSTCODE",
    "senderState": "$L_REM_STATE",
    "state": "$L_STATE",
    "cbsRefNo": "$L_CBS_REF_NO"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_MTA_PAYMENT_B2BAUS');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MTA_PAYMENT_B2BAUS');
      DBG('ERROR CODE IN FN_GET_MTA_PAYMENT_B2BAUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MTA_PAYMENT_B2BAUS=' || SQLERRM);

  END FN_GET_MTA_PAYMENT_B2BAUS;

  FUNCTION FN_GET_FMT_MTA_PAYMENT_B2BAUS(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN CLOB IS

    L_AMOUNT       VARCHAR2(105);
    L_CHANNEL_CODE VARCHAR2(105);
    L_BEN_CITY     VARCHAR2(105);
    L_COMPANY_TYPE VARCHAR2(105);
    L_CURRENCY     VARCHAR2(105);
    L_DOC_REF_NO   VARCHAR2(105);

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);

    L_BUS_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_BUS_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_BUS_SEN_NAME           VARCHAR2(1000);

    L_COUNTRY VARCHAR2(105);

    L_BEN_POST_CODE VARCHAR2(105);

    L_PAYMENT_MODE VARCHAR2(105);

    L_REASON_REMIT_CODE VARCHAR2(105);

    L_BEN_ADDRESS          VARCHAR2(105);
    L_BEN_BANK_AC_NO       VARCHAR2(105);
    L_BEN_BANK_BRANCH_CODE VARCHAR2(105);
    L_BEN_BANK_CODE        VARCHAR2(105);
    L_BEN_EMAIL            VARCHAR2(105);
    L_BEN_LASTNAME         VARCHAR2(105);
    L_BEN_NAT_CODE         VARCHAR2(105);
    L_BEN_MOB              VARCHAR2(105);

    L_REMIT_TYPE         VARCHAR2(105);
    L_SEN_ADDR           VARCHAR2(1000);
    L_SEN_DOB            VARCHAR2(105);
    L_REM_CITY           VARCHAR2(105);
    L_REM_EMAIL          VARCHAR2(105);
    L_SEN_FIRSTNAME      VARCHAR2(105);
    L_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_SEN_LASTNAME       VARCHAR2(105);
    L_SEN_NAT_CODE       VARCHAR2(105);
    L_SEN_OCC_CODE       VARCHAR2(105);
    L_REM_MOB            VARCHAR2(105);
    L_REM_POSTCODE       VARCHAR2(105);
    L_POST_CODE          VARCHAR2(105);
    L_REM_STATE          VARCHAR2(105);
    L_STATE              VARCHAR2(105);
    L_CBS_REF_NO         IFTB_MTA_MASTER.TRN_REF_NO%TYPE;

    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('START OF FN_GET_FMT_MTA_PAYMENT_B2BAUS=' ||
        DBMS_UTILITY.format_call_stack);

    L_FORMATTED_MSG := FN_GET_MTA_PAYMENT_B2BAUS;

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT JSON APPLE8=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values

    --Amount
    L_AMOUNT := P_IFDMTAPA.v_iftb_mta_master.txn_amt;

    DBG('L_AMOUNT=' || L_AMOUNT);

    --City
    L_BEN_CITY := P_IFDMTAPA.v_iftb_mta_master.BEN_CITY;
    DBG('L_BEN_CITY=' || L_BEN_CITY);

    --Company Type
    L_COMPANY_TYPE := P_IFDMTAPA.v_iftb_mta_master.COMPANY_TYPE; --pls check add this field
    DBG('L_COMPANY_TYPE=' || L_COMPANY_TYPE);

    --Currency
    L_CURRENCY := P_IFDMTAPA.v_iftb_mta_master.txn_ccy;

    DBG('L_CURRENCY=' || L_CURRENCY);

    --Document ref no
    L_DOC_REF_NO := P_IFDMTAPA.v_iftb_mta_master.DOCUMENT_REF_NO; --pls check
    DBG('L_DOC_REF_NO=' || L_DOC_REF_NO);

    --L_PAYOUT_GRP_CODE and L_PAYOUT_MODE
    --Get country
    L_COUNTRY := P_IFDMTAPA.v_iftb_mta_master.ben_country;
    DBG('L_COUNTRY=' || L_COUNTRY);

    --Get Payment Mode
    L_PAYMENT_MODE := P_IFDMTAPA.v_iftb_mta_master.payment_mode;
    DBG('L_PAYMENT_MODE=' || L_PAYMENT_MODE);

    BEGIN
      SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
        INTO L_PAYOUT_GRP_CODE, L_PAYOUT_MODE
        FROM STTB_MTA_STATIC_AGENT_DTLS
       WHERE UPPER(COUNTRY_CODE) = L_COUNTRY
         AND PAYMENT_MODE = L_PAYMENT_MODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_PAYOUT_GRP_CODE := NULL;
        L_PAYOUT_MODE     := NULL;
    END;

    DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
    DBG('L_PAYOUT_MODE=' || L_PAYOUT_MODE);

    --Bus sen card type code
    L_BUS_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.BUS_SEN_CARD_TYPE_CODE; --pls check add field
    DBG('L_BUS_SEN_CARD_TYPE_CODE=' || L_BUS_SEN_CARD_TYPE_CODE);

    --Bus sen card type value
    L_BUS_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.BUS_SEN_CARD_TYPE_VAL; --pls check add field
    DBG('L_BUS_SEN_CARD_TYPE_VAL=' || L_BUS_SEN_CARD_TYPE_VAL);

    --Bus sen name
    L_BUS_SEN_NAME := P_IFDMTAPA.v_iftb_mta_master.BUS_SEN_NAME; --pls check add field
    DBG('L_BUS_SEN_NAME=' || L_BUS_SEN_NAME);

    L_BEN_POST_CODE := P_IFDMTAPA.v_iftb_mta_master.BEN_POST_CODE;
    DBG('L_BEN_POST_CODE=' || L_BEN_POST_CODE);

    --Reason of Remittance Code
    L_REASON_REMIT_CODE := FN_GET_REMMITANCE_CODE(P_IFDMTAPA.v_iftb_mta_master.remit_reason_code);
    DBG('L_REASON_REMIT_CODE=' || L_REASON_REMIT_CODE);

    --Receiver Address
    L_BEN_ADDRESS := TRIM(P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS);
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);
    L_BEN_ADDRESS := REPLACE(L_BEN_ADDRESS, chr(10), '');
    DBG('L_BEN_ADDRESS after removing new line=' || length(L_BEN_ADDRESS));
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);

    --Receiver Bank Acc No
    L_BEN_BANK_AC_NO := P_IFDMTAPA.v_iftb_mta_master.ben_acc;
    DBG('L_BEN_BANK_AC_NO=' || L_BEN_BANK_AC_NO);

    --Receiver Bank Branch Code
    L_BEN_BANK_BRANCH_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bank_branch;
    DBG('L_BEN_BANK_BRANCH_CODE=' || L_BEN_BANK_BRANCH_CODE);

    --Receiver Bank Code
    L_BEN_BANK_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bic;
    DBG('L_BEN_BANK_CODE=' || L_BEN_BANK_CODE);

    --Receiver Email
    L_BEN_EMAIL := P_IFDMTAPA.v_iftb_mta_master.BEN_EMAIL;
    DBG('L_BEN_EMAIL=' || L_BEN_EMAIL);

    --Receiver Last Name nothing but ben name
    L_BEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.ben_name;
    DBG('L_BEN_LASTNAME=' || L_BEN_LASTNAME);

    --Receiver Nationality Code
    L_BEN_NAT_CODE := FN_GET_BEN_NAT_CODE(P_IFDMTAPA.v_iftb_mta_master.ben_nationality);
    DBG('L_BEN_NAT_CODE=' || L_BEN_NAT_CODE);

    --Receiver Mobile No
    L_BEN_MOB := P_IFDMTAPA.v_iftb_mta_master.ben_phone;
    DBG('L_BEN_MOB=' || L_BEN_MOB);

    --Remit Type
    L_REMIT_TYPE := P_IFDMTAPA.v_iftb_mta_master.remit_type;
    DBG('L_REMIT_TYPE=' || L_REMIT_TYPE);

    --Sender Address
    L_SEN_ADDR := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_2 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_3 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_4;

    DBG('L_SEN_ADDR=' || L_SEN_ADDR);

    --Sender DOB
    L_SEN_DOB := TO_CHAR(P_IFDMTAPA.v_iftb_mta_master.rem_dob, 'YYYY-MM-DD');
    DBG('L_SEN_DOB=' || L_SEN_DOB);

    --Sender city
    L_REM_CITY := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1; --pls check
    DBG('L_REM_CITY=' || L_REM_CITY);

    --Sender Email
    L_REM_EMAIL := P_IFDMTAPA.v_iftb_mta_master.rem_email;
    DBG('L_REM_EMAIL=' || L_REM_EMAIL);

    --Sender card type code
    BEGIN
      SELECT CARD_TYPE_CODE
        INTO L_SEN_CARD_TYPE_CODE
        FROM sttb_mta_card_type_dtls
       WHERE card_type_name =
             P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_CARD_TYPE_CODE := NULL;
    END;
    DBG('L_SEN_CARD_TYPE_CODE=' || L_SEN_CARD_TYPE_CODE);

    IF L_SEN_CARD_TYPE_CODE IS NULL THEN
      L_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    END IF;

    --Sender card type val
    L_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_value;
    DBG('L_SEN_CARD_TYPE_VAL=' || L_SEN_CARD_TYPE_VAL);

    --Sender First name
    --L_SEN_FIRSTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;

    BEGIN
      SELECT B.FIRST_NAME, B.LAST_NAME
        INTO L_SEN_FIRSTNAME, L_SEN_LASTNAME
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_FIRSTNAME := NULL;
        L_SEN_LASTNAME  := NULL;
    END;

    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);
    L_SEN_FIRSTNAME := NVL(L_SEN_FIRSTNAME,
                           P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);

    --Sender Last Name
    --L_SEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    L_SEN_LASTNAME := NVL(L_SEN_LASTNAME,
                          P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    --Sender Nationality Code
    L_SEN_NAT_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_nationality;
    DBG('L_SEN_NAT_CODE=' || L_SEN_NAT_CODE);

    --Sender Occupation Code
    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('B2P', 'B2B') THEN
      L_SEN_OCC_CODE := FN_GET_NOB_CODE(P_IFDMTAPA.v_iftb_mta_master.REM_NOB);
    ELSE
      L_SEN_OCC_CODE := FN_GET_SEN_OCC_CODE(P_IFDMTAPA.v_iftb_mta_master.rem_occupation);
    END IF;
    DBG('L_SEN_OCC_CODE=' || L_SEN_OCC_CODE);

    --Sender Mobile
    L_REM_MOB := P_IFDMTAPA.v_iftb_mta_master.rem_phone;
    DBG('L_REM_MOB=' || L_REM_MOB);

    --Sender post code
    L_REM_POSTCODE := FN_GET_PINCODE_CUST(P_IFDMTAPA); --pls check

    L_POST_CODE := FN_GET_PINCODE_CUST(P_IFDMTAPA);

    DBG('L_REM_POSTCODE=' || L_REM_POSTCODE);
    DBG('L_POST_CODE=' || L_POST_CODE);

    --Sender state
    L_REM_STATE := 'CAMBODIA'; --P_IFDMTAPA.v_iftb_mta_master.rem_phone; --pls check
    DBG('L_REM_STATE=' || L_REM_STATE);

    --Ben State
    L_STATE := P_IFDMTAPA.v_iftb_mta_master.BEN_state; --pls check
    DBG('L_BEN_STATE=' || L_STATE);

    --CBS Ref No
    L_CBS_REF_NO := P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO;

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_CITY', L_BEN_CITY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_COMPANY_TYPE',
                               L_COMPANY_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CURRENCY', L_CURRENCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_DOC_REF_NO',
                               L_DOC_REF_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_COUNTRY', L_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_MODE',
                               L_PAYMENT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_GRP_CODE',
                               L_PAYOUT_GRP_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_MODE',
                               L_PAYOUT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BUS_SEN_CARD_TYPE_CODE',
                               L_BUS_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BUS_SEN_CARD_TYPE_VAL',
                               L_BUS_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BUS_SEN_NAME',
                               L_BUS_SEN_NAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_POST_CODE',
                               L_BEN_POST_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REASON_REMIT_CODE',
                               L_REASON_REMIT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ADDRESS',
                               L_BEN_ADDRESS);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_AC_NO',
                               L_BEN_BANK_AC_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_BRANCH_CODE',
                               L_BEN_BANK_BRANCH_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_CODE',
                               L_BEN_BANK_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_EMAIL', L_BEN_EMAIL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LASTNAME',
                               L_BEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_NAT_CODE',
                               L_BEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_MOB', L_BEN_MOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REMIT_TYPE',
                               L_REMIT_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_ADDR', L_SEN_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_DOB', L_SEN_DOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_CITY', L_REM_CITY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_EMAIL', L_REM_EMAIL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_FIRSTNAME',
                               L_SEN_FIRSTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_CODE',
                               L_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_VAL',
                               L_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_LASTNAME',
                               L_SEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_NAT_CODE',
                               L_SEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_OCC_CODE',
                               L_SEN_OCC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_MOB', L_REM_MOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REM_POSTCODE',
                               L_REM_POSTCODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_POST_CODE', L_POST_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_STATE', L_REM_STATE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_STATE', L_STATE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CBS_REF_NO',
                               L_CBS_REF_NO);

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_MTA_PAYMENT_B2BAUS');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_MTA_PAYMENT_B2BAUS');
      DBG('ERROR CODE IN FN_GET_FMT_MTA_PAYMENT_B2BAUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_MTA_PAYMENT_B2BAUS=' || SQLERRM);
      RETURN L_FORMATTED_MSG;
  END FN_GET_FMT_MTA_PAYMENT_B2BAUS;

  FUNCTION FN_GET_MTA_B2P_PAYMENT RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_MTA_B2P_PAYMENT');

    L_FORMATTED_MSG := '{
    "amount": "$L_AMOUNT",
    "channelCode": "CBS",
  "countryofBusiness": "$L_COUNTRY_OF_BUS",
    "currency": "$L_CURRENCY",
    "payoutGroupCode": "$L_PAYOUT_GRP_CODE",
    "payoutMode": "$L_PAYOUT_MODE",
  "personIdCardTypeCode": "1",
    "personIdCardTypeNo": "personIdCardTypeNo",
    "personName": "personName",
    "reasonOfRemittanceCode": "$L_REASON_REMIT_CODE",
  "receiverBankAcNo": "$L_BEN_BANK_AC_NO",
  "receiverBankBranchCode": "$L_BEN_BANK_BRANCH_CODE",
  "receiverBankCode": "$L_BEN_BANK_CODE",
    "receiverLastName": "$L_BEN_LASTNAME",
    "receiverNationalityCode": "$L_BEN_NAT_CODE",
    "remitType": "$L_REMIT_TYPE",
    "senderAddress": "$L_SEN_ADDR",
    "senderBirthDate": "$L_SEN_DOB",
  "senderFirstName": "$L_SEN_LASTNAME",
    "senderIdCardTypeCode": "$L_SEN_CARD_TYPE_CODE",
    "senderIdCardTypeNo": "$L_SEN_CARD_TYPE_VAL",
    "senderLastName": "$L_SEN_LASTNAME",
    "senderNationalityCode": "$L_SEN_NAT_CODE",
    "senderOccupationCode": "$L_SEN_OCC_CODE",
    "cbsRefNo": "$L_CBS_REF_NO"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_MTA_B2P_PAYMENT');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MTA_B2P_PAYMENT');
      DBG('ERROR CODE IN FN_GET_MTA_B2P_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MTA_B2P_PAYMENT=' || SQLERRM);

  END FN_GET_MTA_B2P_PAYMENT;

  FUNCTION FN_GET_FMT_MTA_B2P_PAYMENT(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN CLOB IS

    L_AMOUNT         VARCHAR2(105);
    L_CHANNEL_CODE   VARCHAR2(105);
    L_COUNTRY_OF_BUS VARCHAR2(105);
    L_CURRENCY       VARCHAR2(105);

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);
    L_COUNTRY         VARCHAR2(105);
    L_PAYMENT_MODE    VARCHAR2(105);

    L_BUS_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_BUS_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_BUS_SEN_NAME           VARCHAR2(1000);

    L_REASON_REMIT_CODE VARCHAR2(105);

    L_BEN_BANK_AC_NO       VARCHAR2(105);
    L_BEN_BANK_BRANCH_CODE VARCHAR2(105);
    L_BEN_BANK_CODE        VARCHAR2(105);
    L_BEN_LASTNAME         VARCHAR2(105);
    L_BEN_NAT_CODE         VARCHAR2(105);

    L_REMIT_TYPE         VARCHAR2(105);
    L_SEN_ADDR           VARCHAR2(1000);
    L_SEN_DOB            VARCHAR2(105);
    L_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_SEN_FIRSTNAME      VARCHAR2(105);
    L_SEN_LASTNAME       VARCHAR2(105);
    L_SEN_NAT_CODE       VARCHAR2(105);
    L_SEN_OCC_CODE       VARCHAR2(105);
    L_CBS_REF_NO         IFTB_MTA_MASTER.TRN_REF_NO%TYPE;

    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('START OF FN_GET_FMT_MTA_B2P_PAYMENT=' ||
        DBMS_UTILITY.format_call_stack);

    L_FORMATTED_MSG := FN_GET_MTA_B2P_PAYMENT;

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT JSON APPLE9=' ||
        L_FORMATTED_MSG);

    --Replace tags with actual values

    --Amount
    L_AMOUNT := P_IFDMTAPA.v_iftb_mta_master.txn_amt;

    DBG('L_AMOUNT=' || L_AMOUNT);

    --Country of Business
    L_COUNTRY_OF_BUS := 'KH'; --pls check add field

    DBG('L_COUNTRY_OF_BUS=' || L_COUNTRY_OF_BUS);

    --Currency
    L_CURRENCY := P_IFDMTAPA.v_iftb_mta_master.txn_ccy;

    DBG('L_CURRENCY=' || L_CURRENCY);

    --L_PAYOUT_GRP_CODE and L_PAYOUT_MODE
    --Get country
    L_COUNTRY := P_IFDMTAPA.v_iftb_mta_master.ben_country;
    DBG('L_COUNTRY=' || L_COUNTRY);

    --Get Payment Mode
    L_PAYMENT_MODE := P_IFDMTAPA.v_iftb_mta_master.payment_mode;
    DBG('L_PAYMENT_MODE=' || L_PAYMENT_MODE);

    BEGIN
      SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
        INTO L_PAYOUT_GRP_CODE, L_PAYOUT_MODE
        FROM STTB_MTA_STATIC_AGENT_DTLS
       WHERE UPPER(COUNTRY_CODE) = L_COUNTRY
         AND PAYMENT_MODE = L_PAYMENT_MODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_PAYOUT_GRP_CODE := NULL;
        L_PAYOUT_MODE     := NULL;
    END;

    DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
    DBG('L_PAYOUT_MODE=' || L_PAYOUT_MODE);

    --Bus sen card type code
    L_BUS_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.BUS_SEN_CARD_TYPE_CODE; --pls check add field
    DBG('L_BUS_SEN_CARD_TYPE_CODE=' || L_BUS_SEN_CARD_TYPE_CODE);

    --Bus sen card type value
    L_BUS_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.BUS_SEN_CARD_TYPE_VAL; --pls check add field
    DBG('L_BUS_SEN_CARD_TYPE_VAL=' || L_BUS_SEN_CARD_TYPE_VAL);

    --Bus sen name
    L_BUS_SEN_NAME := P_IFDMTAPA.v_iftb_mta_master.BUS_SEN_NAME; --pls check add field
    DBG('L_BUS_SEN_NAME=' || L_BUS_SEN_NAME);

    --Reason of Remittance Code
    L_REASON_REMIT_CODE := FN_GET_REMMITANCE_CODE(P_IFDMTAPA.v_iftb_mta_master.remit_reason_code);
    DBG('L_REASON_REMIT_CODE=' || L_REASON_REMIT_CODE);

    --Receiver Bank Acc No
    L_BEN_BANK_AC_NO := P_IFDMTAPA.v_iftb_mta_master.ben_acc;
    DBG('L_BEN_BANK_AC_NO=' || L_BEN_BANK_AC_NO);

    --Receiver Bank Branch Code
    L_BEN_BANK_BRANCH_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bank_branch;
    DBG('L_BEN_BANK_BRANCH_CODE=' || L_BEN_BANK_BRANCH_CODE);

    --Receiver Bank Code
    L_BEN_BANK_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bic;
    DBG('L_BEN_BANK_CODE=' || L_BEN_BANK_CODE);

    --Receiver Last Name nothing but ben name
    L_BEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.ben_name;
    DBG('L_BEN_LASTNAME=' || L_BEN_LASTNAME);

    --Receiver Nationality Code
    L_BEN_NAT_CODE := FN_GET_BEN_NAT_CODE(P_IFDMTAPA.v_iftb_mta_master.ben_nationality);
    DBG('L_BEN_NAT_CODE=' || L_BEN_NAT_CODE);

    --Remit Type
    L_REMIT_TYPE := P_IFDMTAPA.v_iftb_mta_master.remit_type;
    DBG('L_REMIT_TYPE=' || L_REMIT_TYPE);

    --Sender Address
    L_SEN_ADDR := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_2 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_3 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_4;

    DBG('L_SEN_ADDR=' || L_SEN_ADDR);

    --Sender DOB
    L_SEN_DOB := TO_CHAR(P_IFDMTAPA.v_iftb_mta_master.rem_dob, 'YYYY-MM-DD');
    DBG('L_SEN_DOB=' || L_SEN_DOB);

    --Sender card type code
    BEGIN
      SELECT CARD_TYPE_CODE
        INTO L_SEN_CARD_TYPE_CODE
        FROM sttb_mta_card_type_dtls
       WHERE card_type_name =
             P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_CARD_TYPE_CODE := NULL;
    END;
    DBG('L_SEN_CARD_TYPE_CODE=' || L_SEN_CARD_TYPE_CODE);

    IF L_SEN_CARD_TYPE_CODE IS NULL THEN
      L_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    END IF;

    --Sender card type val
    L_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_value;
    DBG('L_SEN_CARD_TYPE_VAL=' || L_SEN_CARD_TYPE_VAL);

    --Sender First name
    --L_SEN_FIRSTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;

    BEGIN
      SELECT B.FIRST_NAME, B.LAST_NAME
        INTO L_SEN_FIRSTNAME, L_SEN_LASTNAME
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_FIRSTNAME := NULL;
        L_SEN_LASTNAME  := NULL;
    END;

    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);
    L_SEN_FIRSTNAME := NVL(L_SEN_FIRSTNAME,
                           P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);

    --Sender Last Name
    --L_SEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    L_SEN_LASTNAME := NVL(L_SEN_LASTNAME,
                          P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    --Sender Nationality Code
    L_SEN_NAT_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_nationality;
    DBG('L_SEN_NAT_CODE=' || L_SEN_NAT_CODE);

    --Sender Occupation Code
    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('B2P', 'B2B') THEN
      L_SEN_OCC_CODE := FN_GET_NOB_CODE(P_IFDMTAPA.v_iftb_mta_master.REM_NOB);
    ELSE
      L_SEN_OCC_CODE := FN_GET_SEN_OCC_CODE(P_IFDMTAPA.v_iftb_mta_master.rem_occupation);
    END IF;
    DBG('L_SEN_OCC_CODE=' || L_SEN_OCC_CODE);

    --CBS Ref No
    L_CBS_REF_NO := P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO;

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_COUNTRY_OF_BUS',
                               L_COUNTRY_OF_BUS);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CURRENCY', L_CURRENCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_COUNTRY', L_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_MODE',
                               L_PAYMENT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_GRP_CODE',
                               L_PAYOUT_GRP_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_MODE',
                               L_PAYOUT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BUS_SEN_CARD_TYPE_CODE',
                               L_BUS_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BUS_SEN_CARD_TYPE_VAL',
                               L_BUS_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BUS_SEN_NAME',
                               L_BUS_SEN_NAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REASON_REMIT_CODE',
                               L_REASON_REMIT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_AC_NO',
                               L_BEN_BANK_AC_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_BRANCH_CODE',
                               L_BEN_BANK_BRANCH_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_CODE',
                               L_BEN_BANK_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LASTNAME',
                               L_BEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_NAT_CODE',
                               L_BEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REMIT_TYPE',
                               L_REMIT_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_ADDR', L_SEN_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_DOB', L_SEN_DOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_CODE',
                               L_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_VAL',
                               L_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_FIRSTNAME',
                               L_SEN_FIRSTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_LASTNAME',
                               L_SEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_NAT_CODE',
                               L_SEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_OCC_CODE',
                               L_SEN_OCC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CBS_REF_NO',
                               L_CBS_REF_NO);

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_MTA_B2P_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_MTA_B2P_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_MTA_B2P_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_MTA_B2P_PAYMENT=' || SQLERRM);
      RETURN L_FORMATTED_MSG;
  END FN_GET_FMT_MTA_B2P_PAYMENT;

  FUNCTION FN_GET_MTA_PAYMENT_B2PAUS RETURN CLOB IS

    L_FORMATTED_MSG varchar2(4000);

  BEGIN
    DBG('SATRT OF FN_GET_MTA_PAYMENT_B2PAUS APPLE');

    L_FORMATTED_MSG := '{
    "amount": "$L_AMOUNT",
    "channelCode": "CBS",
  "city": "$L_BEN_CITY",
  "companyType": "$L_COMPANY_TYPE",
  "countryofBusiness": "$L_COUNTRY_OF_BUS",
    "currency": "$L_CURRENCY",
  "documentRefNo": "$L_DOC_REF_NO",
    "payoutGroupCode": "$L_PAYOUT_GRP_CODE",
    "payoutMode": "$L_PAYOUT_MODE",
  "personIdCardTypeCode": "1",
    "personIdCardTypeNo": "personIdCardTypeNo",
    "personName": "personName",
  "postCode": "$L_BEN_POST_CODE",
    "reasonOfRemittanceCode": "$L_REASON_REMIT_CODE",
  "receiverAddress":"$L_BEN_ADDRESS",
  "receiverBankAcNo": "$L_BEN_BANK_AC_NO",
  "receiverBankBranchCode": "$L_BEN_BANK_BRANCH_CODE",
  "receiverBankCode": "$L_BEN_BANK_CODE",
  "receiverEmail": "$L_BEN_EMAIL",
    "receiverLastName": "$L_BEN_LASTNAME",
    "receiverNationalityCode": "$L_BEN_NAT_CODE",
  "receiverPhoneNo": "$L_BEN_MOB",
    "remitType": "$L_REMIT_TYPE",
    "senderAddress": "$L_SEN_ADDR",
    "senderBirthDate": "$L_SEN_DOB",
  "senderCity": "$L_REM_CITY",
  "senderEmail": "$L_REM_EMAIL",
  "senderFirstName": "$L_SEN_FIRSTNAME",
    "senderIdCardTypeCode": "$L_SEN_CARD_TYPE_CODE",
    "senderIdCardTypeNo": "$L_SEN_CARD_TYPE_VAL",
    "senderLastName": "$L_SEN_LASTNAME",
    "senderNationalityCode": "$L_SEN_NAT_CODE",
    "senderOccupationCode": "$L_SEN_OCC_CODE",
  "senderPhoneNo": "$L_REM_MOB",
    "senderPostCode": "$L_REM_POSTCODE",
    "senderState": "$L_REM_STATE",
    "state": "$L_STATE",
    "cbsRefNo": "$L_CBS_REF_NO"
}';

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_MTA_PAYMENT_B2PAUS');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MTA_PAYMENT_B2PAUS');
      DBG('ERROR CODE IN FN_GET_MTA_PAYMENT_B2PAUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MTA_PAYMENT_B2PAUS=' || SQLERRM);

  END FN_GET_MTA_PAYMENT_B2PAUS;

  FUNCTION FN_GET_FMT_MTA_PAYMENT_B2PAUS(p_ifdmtapa IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa)
    RETURN CLOB IS

    L_AMOUNT         VARCHAR2(105);
    L_CHANNEL_CODE   VARCHAR2(105);
    L_BEN_CITY       VARCHAR2(105);
    L_COMPANY_TYPE   VARCHAR2(105);
    L_COUNTRY_OF_BUS VARCHAR2(105);
    L_CURRENCY       VARCHAR2(105);
    L_DOC_REF_NO     VARCHAR2(105);

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);

    L_BUS_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_BUS_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_BUS_SEN_NAME           VARCHAR2(1000);

    L_COUNTRY VARCHAR2(105);

    L_BEN_POST_CODE VARCHAR2(105);

    L_PAYMENT_MODE VARCHAR2(105);

    L_REASON_REMIT_CODE VARCHAR2(105);

    L_BEN_ADDRESS          VARCHAR2(105);
    L_BEN_BANK_AC_NO       VARCHAR2(105);
    L_BEN_BANK_BRANCH_CODE VARCHAR2(105);
    L_BEN_BANK_CODE        VARCHAR2(105);
    L_BEN_EMAIL            VARCHAR2(105);
    L_BEN_LASTNAME         VARCHAR2(105);
    L_BEN_NAT_CODE         VARCHAR2(105);
    L_BEN_MOB              VARCHAR2(105);

    L_REMIT_TYPE         VARCHAR2(105);
    L_SEN_ADDR           VARCHAR2(1000);
    L_SEN_DOB            VARCHAR2(105);
    L_REM_CITY           VARCHAR2(105);
    L_REM_EMAIL          VARCHAR2(105);
    L_SEN_FIRSTNAME      VARCHAR2(105);
    L_SEN_CARD_TYPE_CODE VARCHAR2(105);
    L_SEN_CARD_TYPE_VAL  VARCHAR2(105);
    L_SEN_LASTNAME       VARCHAR2(105);
    L_SEN_NAT_CODE       VARCHAR2(105);
    L_SEN_OCC_CODE       VARCHAR2(105);
    L_REM_MOB            VARCHAR2(105);
    L_REM_POSTCODE       VARCHAR2(105);
    L_POST_CODE          VARCHAR2(105);
    L_REM_STATE          VARCHAR2(105);
    L_STATE              VARCHAR2(105);
    L_CBS_REF_NO         IFTB_MTA_MASTER.TRN_REF_NO%TYPE;

    L_FORMATTED_MSG CLOB; --varchar2(4000);

  BEGIN
    DBG('START OF FN_GET_FMT_MTA_PAYMENT_B2PAUS=' ||
        DBMS_UTILITY.format_call_stack);

    L_FORMATTED_MSG := FN_GET_MTA_PAYMENT_B2PAUS;

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT JSON=' || L_FORMATTED_MSG);

    --Replace tags with actual values

    --Amount
    L_AMOUNT := P_IFDMTAPA.v_iftb_mta_master.txn_amt;

    DBG('L_AMOUNT=' || L_AMOUNT);

    --City
    L_BEN_CITY := P_IFDMTAPA.v_iftb_mta_master.BEN_CITY;
    DBG('L_BEN_CITY=' || L_BEN_CITY);

    --Company Type
    L_COMPANY_TYPE := P_IFDMTAPA.v_iftb_mta_master.COMPANY_TYPE; --pls check add this field
    DBG('L_COMPANY_TYPE=' || L_COMPANY_TYPE);

    --Country of Business
    L_COUNTRY_OF_BUS := 'KH'; --null; --pls check add field

    --Currency
    L_CURRENCY := P_IFDMTAPA.v_iftb_mta_master.txn_ccy;

    DBG('L_CURRENCY=' || L_CURRENCY);

    --Document ref no
    L_DOC_REF_NO := P_IFDMTAPA.v_iftb_mta_master.DOCUMENT_REF_NO; --pls check
    DBG('L_DOC_REF_NO=' || L_DOC_REF_NO);

    --L_PAYOUT_GRP_CODE and L_PAYOUT_MODE
    --Get country
    L_COUNTRY := P_IFDMTAPA.v_iftb_mta_master.ben_country;
    DBG('L_COUNTRY=' || L_COUNTRY);

    --Get Payment Mode
    L_PAYMENT_MODE := P_IFDMTAPA.v_iftb_mta_master.payment_mode;
    DBG('L_PAYMENT_MODE=' || L_PAYMENT_MODE);

    BEGIN
      SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
        INTO L_PAYOUT_GRP_CODE, L_PAYOUT_MODE
        FROM STTB_MTA_STATIC_AGENT_DTLS
       WHERE UPPER(COUNTRY_CODE) = L_COUNTRY
         AND PAYMENT_MODE = L_PAYMENT_MODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_PAYOUT_GRP_CODE := NULL;
        L_PAYOUT_MODE     := NULL;
    END;

    DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
    DBG('L_PAYOUT_MODE=' || L_PAYOUT_MODE);

    --Bus sen card type code
    L_BUS_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.BUS_SEN_CARD_TYPE_CODE; --pls check add field
    DBG('L_BUS_SEN_CARD_TYPE_CODE=' || L_BUS_SEN_CARD_TYPE_CODE);

    --Bus sen card type value
    L_BUS_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.BUS_SEN_CARD_TYPE_VAL; --pls check add field
    DBG('L_BUS_SEN_CARD_TYPE_VAL=' || L_BUS_SEN_CARD_TYPE_VAL);

    --Bus sen name
    L_BUS_SEN_NAME := P_IFDMTAPA.v_iftb_mta_master.BUS_SEN_NAME; --pls check add field
    DBG('L_BUS_SEN_NAME=' || L_BUS_SEN_NAME);

    L_BEN_POST_CODE := P_IFDMTAPA.v_iftb_mta_master.BEN_POST_CODE;
    DBG('L_BEN_POST_CODE=' || L_BEN_POST_CODE);

    --Reason of Remittance Code
    L_REASON_REMIT_CODE := FN_GET_REMMITANCE_CODE(P_IFDMTAPA.v_iftb_mta_master.remit_reason_code);
    DBG('L_REASON_REMIT_CODE=' || L_REASON_REMIT_CODE);

    --Receiver Address
    L_BEN_ADDRESS := TRIM(P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS);
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);
    L_BEN_ADDRESS := REPLACE(L_BEN_ADDRESS, chr(10), '');
    DBG('L_BEN_ADDRESS after removing new line=' || length(L_BEN_ADDRESS));
    DBG('L_BEN_ADDRESS=' || L_BEN_ADDRESS);

    --Receiver Bank Acc No
    L_BEN_BANK_AC_NO := P_IFDMTAPA.v_iftb_mta_master.ben_acc;
    DBG('L_BEN_BANK_AC_NO=' || L_BEN_BANK_AC_NO);

    --Receiver Bank Branch Code
    L_BEN_BANK_BRANCH_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bank_branch;
    DBG('L_BEN_BANK_BRANCH_CODE=' || L_BEN_BANK_BRANCH_CODE);

    --Receiver Bank Code
    L_BEN_BANK_CODE := P_IFDMTAPA.v_iftb_mta_master.ben_bic;
    DBG('L_BEN_BANK_CODE=' || L_BEN_BANK_CODE);

    --Receiver Email
    L_BEN_EMAIL := P_IFDMTAPA.v_iftb_mta_master.BEN_EMAIL;
    DBG('L_BEN_EMAIL=' || L_BEN_EMAIL);

    --Receiver Last Name nothing but ben name
    L_BEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.ben_name;
    DBG('L_BEN_LASTNAME=' || L_BEN_LASTNAME);

    --Receiver Nationality Code
    L_BEN_NAT_CODE := FN_GET_BEN_NAT_CODE(P_IFDMTAPA.v_iftb_mta_master.ben_nationality);
    DBG('L_BEN_NAT_CODE=' || L_BEN_NAT_CODE);

    --Receiver Mobile No
    L_BEN_MOB := P_IFDMTAPA.v_iftb_mta_master.ben_phone;
    DBG('L_BEN_MOB=' || L_BEN_MOB);

    --Remit Type
    L_REMIT_TYPE := P_IFDMTAPA.v_iftb_mta_master.remit_type;
    DBG('L_REMIT_TYPE=' || L_REMIT_TYPE);

    --Sender Address
    L_SEN_ADDR := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_2 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_3 ||
                  P_IFDMTAPA.v_iftb_mta_master.rem_addr_4;

    DBG('L_SEN_ADDR=' || L_SEN_ADDR);

    --Sender DOB
    L_SEN_DOB := TO_CHAR(P_IFDMTAPA.v_iftb_mta_master.rem_dob, 'YYYY-MM-DD');
    DBG('L_SEN_DOB=' || L_SEN_DOB);

    --Sender city
    L_REM_CITY := P_IFDMTAPA.v_iftb_mta_master.rem_addr_1; --pls check
    DBG('L_REM_CITY=' || L_REM_CITY);

    --Sender Email
    L_REM_EMAIL := P_IFDMTAPA.v_iftb_mta_master.rem_email;
    DBG('L_REM_EMAIL=' || L_REM_EMAIL);

    --Sender card type code
    BEGIN
      SELECT CARD_TYPE_CODE
        INTO L_SEN_CARD_TYPE_CODE
        FROM sttb_mta_card_type_dtls
       WHERE card_type_name =
             P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_CARD_TYPE_CODE := NULL;
    END;
    DBG('L_SEN_CARD_TYPE_CODE=' || L_SEN_CARD_TYPE_CODE);

    IF L_SEN_CARD_TYPE_CODE IS NULL THEN
      L_SEN_CARD_TYPE_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_type;
    END IF;

    --Sender card type val
    L_SEN_CARD_TYPE_VAL := P_IFDMTAPA.v_iftb_mta_master.rem_unique_id_value;
    DBG('L_SEN_CARD_TYPE_VAL=' || L_SEN_CARD_TYPE_VAL);

    --Sender First name
    --L_SEN_FIRSTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;

    BEGIN
      SELECT B.FIRST_NAME, B.LAST_NAME
        INTO L_SEN_FIRSTNAME, L_SEN_LASTNAME
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_IFDMTAPA.v_iftb_mta_master.rem_acc);
    EXCEPTION
      WHEN OTHERS THEN
        L_SEN_FIRSTNAME := NULL;
        L_SEN_LASTNAME  := NULL;
    END;

    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);
    L_SEN_FIRSTNAME := NVL(L_SEN_FIRSTNAME,
                           P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_FIRSTNAME=' || L_SEN_FIRSTNAME);

    --Sender Last Name
    --L_SEN_LASTNAME := P_IFDMTAPA.v_iftb_mta_master.rem_name;
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    L_SEN_LASTNAME := NVL(L_SEN_LASTNAME,
                          P_IFDMTAPA.v_iftb_mta_master.rem_name);
    DBG('L_SEN_LASTNAME=' || L_SEN_LASTNAME);

    --Sender Nationality Code
    L_SEN_NAT_CODE := P_IFDMTAPA.v_iftb_mta_master.rem_nationality;
    DBG('L_SEN_NAT_CODE=' || L_SEN_NAT_CODE);

    --Sender Occupation Code
    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('B2P', 'B2B') THEN
      L_SEN_OCC_CODE := FN_GET_NOB_CODE(P_IFDMTAPA.v_iftb_mta_master.REM_NOB);
    ELSE
      L_SEN_OCC_CODE := FN_GET_SEN_OCC_CODE(P_IFDMTAPA.v_iftb_mta_master.rem_occupation);
    END IF;
    DBG('L_SEN_OCC_CODE=' || L_SEN_OCC_CODE);

    --Sender Mobile
    L_REM_MOB := P_IFDMTAPA.v_iftb_mta_master.rem_phone;
    DBG('L_REM_MOB=' || L_REM_MOB);

    --Sender post code
    L_REM_POSTCODE := FN_GET_PINCODE_CUST(P_IFDMTAPA); --P_IFDMTAPA.v_iftb_mta_master.rem_phone; --pls check

    L_POST_CODE := FN_GET_PINCODE_CUST(P_IFDMTAPA);

    DBG('L_REM_POSTCODE=' || L_REM_POSTCODE);
    DBG('L_POST_CODE=' || L_POST_CODE);

    --Sender state
    L_REM_STATE := 'CAMBODIA'; --P_IFDMTAPA.v_iftb_mta_master.rem_phone; --pls check
    DBG('L_REM_STATE=' || L_REM_STATE);

    --Ben State
    L_STATE := P_IFDMTAPA.v_iftb_mta_master.BEN_state; --pls check
    DBG('L_BEN_STATE=' || L_STATE);

    --CBS Ref No
    L_CBS_REF_NO := P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO;

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMOUNT', L_AMOUNT);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_CITY', L_BEN_CITY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_COMPANY_TYPE',
                               L_COMPANY_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_COUNTRY_OF_BUS',
                               L_COUNTRY_OF_BUS);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CURRENCY', L_CURRENCY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_DOC_REF_NO',
                               L_DOC_REF_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_COUNTRY', L_COUNTRY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_MODE',
                               L_PAYMENT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_GRP_CODE',
                               L_PAYOUT_GRP_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYOUT_MODE',
                               L_PAYOUT_MODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BUS_SEN_CARD_TYPE_CODE',
                               L_BUS_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BUS_SEN_CARD_TYPE_VAL',
                               L_BUS_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BUS_SEN_NAME',
                               L_BUS_SEN_NAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_POST_CODE',
                               L_BEN_POST_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REASON_REMIT_CODE',
                               L_REASON_REMIT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ADDRESS',
                               L_BEN_ADDRESS);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_AC_NO',
                               L_BEN_BANK_AC_NO);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_BRANCH_CODE',
                               L_BEN_BANK_BRANCH_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_BANK_CODE',
                               L_BEN_BANK_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_EMAIL', L_BEN_EMAIL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LASTNAME',
                               L_BEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_NAT_CODE',
                               L_BEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_MOB', L_BEN_MOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REMIT_TYPE',
                               L_REMIT_TYPE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_ADDR', L_SEN_ADDR);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEN_DOB', L_SEN_DOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_CITY', L_REM_CITY);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_EMAIL', L_REM_EMAIL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_FIRSTNAME',
                               L_SEN_FIRSTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_CODE',
                               L_SEN_CARD_TYPE_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_CARD_TYPE_VAL',
                               L_SEN_CARD_TYPE_VAL);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_LASTNAME',
                               L_SEN_LASTNAME);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_NAT_CODE',
                               L_SEN_NAT_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEN_OCC_CODE',
                               L_SEN_OCC_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_MOB', L_REM_MOB);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_REM_POSTCODE',
                               L_REM_POSTCODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_POST_CODE', L_POST_CODE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REM_STATE', L_REM_STATE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_STATE', L_STATE);

    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CBS_REF_NO',
                               L_CBS_REF_NO);

    DBG('BEFORE REPLACEMENT OF MTA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);

    RETURN L_FORMATTED_MSG;

    DBG('END OF FN_GET_FMT_MTA_PAYMENT_B2PAUS');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_MTA_PAYMENT_B2PAUS');
      DBG('ERROR CODE IN FN_GET_FMT_MTA_PAYMENT_B2PAUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_MTA_PAYMENT_B2PAUS=' || SQLERRM);
      RETURN L_FORMATTED_MSG;
  END FN_GET_FMT_MTA_PAYMENT_B2PAUS;

  PROCEDURE PR_INSERT_MTA_WS_LOG(P_SEQ_NO      IN VARCHAR2,
                                 P_TRN_REF_NO  IN VARCHAR2,
                                 P_INVOKE_DATE IN VARCHAR2,
                                 P_REQ_TYPE    IN VARCHAR2,
                                 P_REQ_MSG     IN VARCHAR2,
                                 P_ADDL_INFO   IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN
    DBG('START OF PR_INSERT_MTA_WS_LOG');

    INSERT INTO IFTB_MTA_WS_LOG
      (SEQ_NO, TRN_REF_NO, INVOKE_DATE, REQ_TYPE, REQ_MSG, ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_TRN_REF_NO,
       P_INVOKE_DATE,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ADDL_INFO);

    COMMIT;

    DBG('END OF PR_INSERT_MTA_WS_LOG');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_MTA_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_MTA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_MTA_WS_LOG=' || SQLERRM);

  END PR_INSERT_MTA_WS_LOG;

  PROCEDURE PR_UPDATE_MTA_WS_LOG(P_TRN_REF_NO   IN IFTB_MTA_MASTER.TRN_REF_NO%TYPE,
                                 P_SEQ_NO       IN VARCHAR2,
                                 P_REFERENCE_NO IN IFTB_MTA_WS_LOG.REFERENCE_NO%TYPE,
                                 P_TXN_ID       IN IFTB_MTA_WS_LOG.TXN_ID%TYPE,

                                 P_COLLTRANID IN IFTB_MTA_WS_LOG.COLLTRANID%TYPE,
                                 P_STATUS     IN CHAR,
                                 P_RES_MSG    IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_MTA_WS_LOG');

    UPDATE IFTB_MTA_WS_LOG
       SET REFERENCE_NO = P_REFERENCE_NO,
           TXN_ID       = P_TXN_ID,
           COLLTRANID   = P_COLLTRANID,
           RES_MSG      = P_RES_MSG,
           STATUS       = P_STATUS
     WHERE TRN_REF_NO = P_TRN_REF_NO
       AND SEQ_NO = P_SEQ_NO;

    COMMIT;

    DBG('END OF PR_UPDATE_MTA_WS_LOG');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_MTA_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_MTA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_MTA_WS_LOG=' || SQLERRM);
  END PR_UPDATE_MTA_WS_LOG;

  PROCEDURE PR_PRINT_ACCTNG_TABLE(P_ACC_HAND IN ACPKS.TBL_ACHOFF) IS
    I      NUMBER;
    L_ROW  VARCHAR2(500);
    L_LINE VARCHAR2(500);
  BEGIN

    SELECT RPAD('-',
                20 + 15 + 15 + 15 + 15 + 1 + 1 + 3 + 3 + 3 + 6 + 3,
                '-')
      INTO L_LINE
      FROM DUAL;
    DBG(L_LINE);
    SELECT '|' || RPAD('Tag', 10, '.') || '|' || RPAD('Brn', 3, '.') || '|' ||
           RPAD('Acc', 20, '.') || '|' || RPAD('Lcy Amt', 15, '.') || '|' ||
           RPAD('Fcy Amt', 15, '.') || '|' || RPAD('Exch Rate', 15, '.') || '|' ||
           RPAD('D/C', 1, '.') || '|' || RPAD('Netting', 1, '.') || '|' ||
           RPAD('Ccy', 3, '.') || '|' || RPAD('TrnCode', 3, '.') || '|' ||
           RPAD('Brn', 3, '.') || '|'
      INTO L_ROW
      FROM DUAL;
    DBG(L_ROW);
    DBG(L_LINE);

    FOR I IN 1 .. P_ACC_HAND.COUNT LOOP
      IF P_ACC_HAND.EXISTS(I) THEN
        SELECT '|' || RPAD(P_ACC_HAND(I).AMOUNT_TAG, 10, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_BRANCH, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_NO, 20, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).LCY_AMOUNT, -1111), 15, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).FCY_AMOUNT, -1111), 15, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).EXCH_RATE, -1111), 15, '.') || '|' ||
               RPAD(P_ACC_HAND(I).DRCR_IND, 1, '.') || '|' ||
               RPAD(P_ACC_HAND(I).NETTING_IND, 1, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_CCY, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).TRN_CODE, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_BRANCH, 3, '.') || '|'
          INTO L_ROW
          FROM DUAL;
        DBG(L_ROW);
        DBG(L_LINE);
      END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN;
  END PR_PRINT_ACCTNG_TABLE;

  PROCEDURE PR_CHARGE_REVERSAL(P_AC_ENTS IN OUT NOCOPY ACPKS.TBL_ACHOFF) IS

    L_INDEX       NUMBER;
    L_REV_REQD    VARCHAR2(1);
    L_NET_CHARGES VARCHAR2(1);
    L_CHG_FROM    VARCHAR2(3);
    L_AMT_SUM     NUMBER;
    L_CONTRA_LEG  NUMBER;
    L_PROD        VARCHAR2(4);

    L_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM VARCHAR2(250);

  BEGIN

    DBG('inside pr_chrge_reversal with product as ');

    BEGIN
      SELECT PRODUCT_CODE
        INTO L_PROD
        FROM DETB_RTL_TELLER
       WHERE TRN_REF_NO = P_AC_ENTS(1).TRN_REF_NO;

      DBG('Calling Fn_Get_Detm_Rt_Pref_Rec_Wrp...for the product...' ||
          L_PROD);
      IF NOT
          CSPKSS_FUNCTION_CACHE.FN_GET_DETM_RT_PREF_REC_WRP(L_PROD,
                                                            L_ERR_CODE,
                                                            L_ERR_PARAM) THEN
        IF L_ERR_CODE = 'CS-FRC-001' THEN
          DBG('No data Found exception so assignin value as Y ..');
          L_REV_REQD  := 'Y';
          L_ERR_CODE  := NULL;
          L_ERR_PARAM := NULL;
        ELSE
          DBG('In others exception..');
          L_ERR_CODE  := NULL;
          L_ERR_PARAM := NULL;
          DBG('Proceed..');
        END IF;
      ELSE
        L_REV_REQD := NVL(CSPKSS_FUNCTION_CACHE.G_TBL_DETM_RT_PREF_REC.REVERSAL_INCLUDES_CHARGES,
                          'N');
        DBG('Value of l_rev_reqd is - ' || L_REV_REQD);
      END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_REV_REQD := 'Y';
      WHEN OTHERS THEN
        DBG('Failed while checking if charge reversal is required');

    END;

    DBG('GWPKS_UTIL.G_REJECTFLAG => ' || GWPKS_UTIL.G_REJECTFLAG);

    IF L_REV_REQD = 'N' OR NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' THEN
      BEGIN
        SELECT NVL(COD_NET_CHARGES, 'Y')
          INTO L_NET_CHARGES
          FROM IFTMS_ARC_MAINT
         WHERE COD_PROD_ACC_CLS = L_PROD;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_NET_CHARGES := 'N';
        WHEN OTHERS THEN
          DBG('Failed while checking if charge netting is required');

      END;
      DBG('l_net_charges => ' || L_NET_CHARGES);
      IF L_NET_CHARGES = 'Y' THEN
        BEGIN

          SELECT CHG_CONTRA_LEG
            INTO L_CHG_FROM
            FROM DETBS_RTL_TELLER
           WHERE TRN_REF_NO = P_AC_ENTS(1).TRN_REF_NO;

        END;
        L_AMT_SUM := 0;

        IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
          DBG('INSIDE THE LOOP TO FETCH THE CHARGES');
          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF P_AC_ENTS(L_INDEX)
             .AMOUNT_TAG IN
                ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
              DBG('l_index ' || L_INDEX);
              DBG('p_ac_ents(l_index).AMOUNT_TAG => ' || P_AC_ENTS(L_INDEX)
                  .AMOUNT_TAG);
              L_AMT_SUM := L_AMT_SUM + P_AC_ENTS(L_INDEX).LCY_AMOUNT;
            END IF;

          END LOOP;
          DBG('OUT OF THE LOOP WITH l_amt_sum :- ' || L_AMT_SUM);

        ELSE

          DBG('INSIDE THE ELSE PART');
          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF P_AC_ENTS(L_INDEX)
             .AMOUNT_TAG IN ('CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
              L_AMT_SUM := L_AMT_SUM + P_AC_ENTS(L_INDEX).LCY_AMOUNT;
            END IF;

          END LOOP;

        END IF;

        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
          IF P_AC_ENTS(L_INDEX).AMOUNT_TAG = (L_CHG_FROM || '_AMT') THEN
            P_AC_ENTS(L_INDEX).LCY_AMOUNT := P_AC_ENTS(L_INDEX)
                                             .LCY_AMOUNT - L_AMT_SUM;
          END IF;
        END LOOP;

      END IF;

      IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
        DBG('GOING FOR THE LOOP TO DLETE THE CHARGE ENTRIES');

        BEGIN
          DBG('pr_print_acctng_table is cmd in begin.....');
          PR_PRINT_ACCTNG_TABLE(P_AC_ENTS);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In OTHERS with line tracking  ::::: ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        END;

        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
          IF P_AC_ENTS(L_INDEX)
           .AMOUNT_TAG IN
              ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
            DBG('l_index ' || L_INDEX);
            DBG('p_ac_ents(l_index).AMOUNT_TAG => ' || P_AC_ENTS(L_INDEX)
                .AMOUNT_TAG);
            P_AC_ENTS.DELETE(L_INDEX);
          END IF;
        END LOOP;
        DBG('OUT OF LOOP');

      ELSE

        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP

          IF P_AC_ENTS(L_INDEX)
           .AMOUNT_TAG IN ('CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
            P_AC_ENTS.DELETE(L_INDEX);

          END IF;
        END LOOP;

      END IF;
    END IF;

  END PR_CHARGE_REVERSAL;

  PROCEDURE PR_UPDATE_TRACKED_BALANCES(P_CONTRACT_REF_NO IN CSTB_CONTRACT.CONTRACT_REF_NO%TYPE) IS

    CURSOR CR_UPDATE_BALANCES IS
      SELECT *
        FROM CSTB_AUTO_SETTLE_BLOCK
       WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO
         AND AMOUNT_DUE != AMOUNT_PAID;
    L_AMOUNT_TO_BE_RELEASED NUMBER(22, 3) := 0;

  BEGIN

    FOR REC IN CR_UPDATE_BALANCES LOOP

      L_AMOUNT_TO_BE_RELEASED := REC.AMOUNT_AVAILABLE;

      DBG('account is :::: ' || REC.ACCOUNT_NO);

      DBG('L_AMOUNT_TO_BE_RELEASED is :::: ' || L_AMOUNT_TO_BE_RELEASED);

      ACPKS_CUSTBAL_PROCESS.PR_UPDATE_RECEIVABLE_AMT(REC.ACCOUNT_NO,
                                                     REC.ACCOUNT_BR,
                                                     'D',
                                                     L_AMOUNT_TO_BE_RELEASED);
      DEBUG.PR_DEBUG('LD', 'after updating recievable');

    END LOOP;

    INSERT INTO CSTB_AUTO_SETTLE_BLOCK_TEMP
      (SELECT *
         FROM CSTB_AUTO_SETTLE_BLOCK
        WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO);

    DBG('umber of rows iserted IN TEMP are :::: ' || SQL%ROWCOUNT);
    DELETE CSTB_AUTO_SETTLE_BLOCK
     WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO;

  END;

  FUNCTION FN_REVERSE(P_TRN_REF_NO IN VARCHAR2,
                      P_ERR_CODE   IN OUT VARCHAR2,
                      P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_AUTH_STAT        DETBS_RTL_TELLER.AUTH_STAT%TYPE;
    L_AC_ENTS          ACPKS.TBL_ACHOFF;
    L_ROWID            ROWID;
    L_AUTHORISE        VARCHAR2(1);
    L_CHECKER_DT_STAMP DATE;
    L_TRACK_RECEIVABLE VARCHAR2(1);
    L_SCODE            DETBS_RTL_TELLER.SCODE%TYPE;
    L_CHECK_ENTRIES    BOOLEAN := TRUE;
    L_SETTLE_COUNT     NUMBER := 0;
    L_ON_ERROR         BOOLEAN := FALSE;
    L_BOOK_DATE        DATE;

    L_ACC_TYPE_1   VARCHAR2(20);
    L_ACC_TYPE_2   VARCHAR2(20);
    L_BRANCH       DETBS_RTL_TELLER.BRANCH_CODE%TYPE;
    L_PRODUCT_CODE DETBS_RTL_TELLER.PRODUCT_CODE%TYPE;
    L_MODULE       CSTM_PRODUCT.MODULE%TYPE;
    V_TBL_RESTR    STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR;
    L_EVENT_CODE   DETB_RTL_TELLER.EVENT_CODE%TYPE;
    L_TRN_DATE     DETB_RTL_TELLER.TRN_DT%TYPE;
    L_PRDGRP       CSTM_PRODUCT.PRODUCT_GROUP%TYPE;
    L_DETB_ROW     DETB_RTL_TELLER%ROWTYPE;
    L_REV_UTIL     NUMBER := 0;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_IFTB_RFT_MASTER       IFTB_RFT_MASTER%ROWTYPE;

  BEGIN
    DBG('Inside the fn_reverse OF Depks_Rtl_Teller PACKAGE...');
    SAVEPOINT RTL_REVERSE;
    DBG('Issued savepoint rtl reverse');
    BEGIN
      SELECT AUTH_STAT, ROWID, NVL(SCODE, '*')
        INTO L_AUTH_STAT, L_ROWID, L_SCODE
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
            P_TRN_REF_NO || '~' || SQLERRM);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;

    BEGIN
      SELECT NVL(TRACK_RECEIVABLE, 'N')
        INTO L_TRACK_RECEIVABLE
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed while selecting track_receivable from detb_rtl_teller with -->' ||
            SQLERRM);
        DBG('Txn Ref No is --->' || P_TRN_REF_NO);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;

    BEGIN
      DBG('Initial value of l_settle_count ' || L_SETTLE_COUNT);
      DBG('Query to get record count from cstb_auto_settle_block');
      SELECT COUNT(*)
        INTO L_SETTLE_COUNT
        FROM CSTB_AUTO_SETTLE_BLOCK
       WHERE CONTRACT_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found for the record.. cstb_auto_settle_block ');
        L_SETTLE_COUNT := 0;
      WHEN OTHERS THEN
        DBG('Failed while selecting entries from cstb_auto_settle_block with -->' ||
            SQLERRM);
        DBG('contract_ref_no --->' || P_TRN_REF_NO);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;
    DBG('l_settle_count ' || L_SETTLE_COUNT);

    IF L_AUTH_STAT = 'A' OR L_AUTH_STAT IS NULL THEN
      DBG('Proceeding for Reversal with l_auth_stat  ' || L_AUTH_STAT ||
          ' and l_settle_count ' || L_SETTLE_COUNT);

      DBG('Cspks_Req_Global.g_Release_Type :::: ' ||
          CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('p_trn_ref_no while calling depks_rtl_teller_cluster.fn_reverse ::::: ' ||
            P_TRN_REF_NO);
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 1;

        IF L_CHECK_ENTRIES THEN
          L_TB_CLUSTER_DATA('l_check_entries') := 'T';
        ELSE
          L_TB_CLUSTER_DATA('l_check_entries') := 'F';
        END IF;

        IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_REVERSE(P_TRN_REF_NO,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM,
                                                   L_FN_CALL_ID,
                                                   L_TB_CLUSTER_DATA) THEN
          DBG('Failed inside depks_rtl_teller_cluster.Fn_Save');
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          RETURN FALSE;
        END IF;

        IF L_TB_CLUSTER_DATA.EXISTS('l_check_entries') THEN
          IF L_TB_CLUSTER_DATA('l_check_entries') = 'T' THEN
            L_CHECK_ENTRIES := TRUE;
          ELSE
            L_CHECK_ENTRIES := FALSE;
          END IF;
        END IF;

      END IF;

      IF L_SETTLE_COUNT > 0 THEN
        DBG('Before Validation For Same Day Reversal ');
        BEGIN
          SELECT BOOK_DATE
            INTO L_BOOK_DATE
            FROM CSTB_AUTO_SETTLE_BLOCK
           WHERE CONTRACT_REF_NO = P_TRN_REF_NO
             AND ROWNUM = 1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found for the record.. cstb_auto_settle_block ');
            L_BOOK_DATE := NULL;
          WHEN OTHERS THEN
            DBG('Failed while selecting BOOK_DATE from cstb_auto_settle_block with -->' ||
                SQLERRM);
            DBG('contract_ref_no --->' || P_TRN_REF_NO);
            P_ERR_CODE := 'DE-TUD-002';
            ROLLBACK TO RTL_REVERSE;
            RETURN FALSE;
        END;
        DBG('l_BOOK_DATE ' || L_BOOK_DATE);

        IF L_BOOK_DATE <> GLOBAL.APPLICATION_DATE THEN
          DBG('For Tracked Transaction Only same date Reversal is Allwoed.');
          P_ERR_CODE := 'DE-TUD-946';
          ROLLBACK TO RTL_REVERSE;
          RETURN FALSE;
        END IF;
      END IF;

      IF GWPKS_UTIL.G_FROM_BEAN OR L_SCODE = 'FLEXSWITCH' THEN
        DEPKS_RTL_TELLER.PR_AUTH_REVERSAL_REQD(TRUE);
      END IF;
      IF DEPKS_RTL_TELLER.PKG_AUTH_REVERSAL_REQD THEN

        L_AUTHORISE := 'B';
      ELSE
        L_AUTHORISE := 'U';
      END IF;
      DBG('Getting a/c entries BY calling Acpks.fn_acEntry_Retrieval...');

      IF NVL(GWPKS_UTIL.G_TWOSTEPPROCESS, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.G_BRNNEWFLOW, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.G_FIRSTSTEPDONE, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1401' AND
         NVL(GWPKS_UTIL.G_TWOSTEPPROCESSNO, '1') = '1' THEN
        L_CHECK_ENTRIES := FALSE;
      END IF;
      DBG('after setting check entries.');
      IF L_CHECK_ENTRIES THEN
        DBG(' going to check for entries .');

        IF ACPKS_CUSTOM.FN_ACENTRY_RETRIEVAL_RFT(P_TRN_REF_NO, 1, L_AC_ENTS) > 0 THEN
          DBG('Doing the actual reversal...');

          IF L_TRACK_RECEIVABLE = 'Y' OR L_SETTLE_COUNT > 0 THEN

            IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'N' THEN
              DBG(' Before Call to pr_update_tracked_balances ');
              PR_UPDATE_TRACKED_BALANCES(P_TRN_REF_NO);
            END IF;
            DBG('After Call to pr_update_tracked_balances ');
          END IF;

          PR_CHARGE_REVERSAL(L_AC_ENTS);

          DBG('L_AC_ENTS.COUNT=' || L_AC_ENTS.COUNT);

          FOR L_RECNO IN L_AC_ENTS.FIRST .. L_AC_ENTS.LAST LOOP
            L_AC_ENTS(L_RECNO).EVENT_SR_NO := 2;
            L_AC_ENTS(L_RECNO).EVENT := 'REVR';
            L_AC_ENTS(L_RECNO).FCY_AMOUNT := L_AC_ENTS(L_RECNO)
                                             .FCY_AMOUNT * -1;
            L_AC_ENTS(L_RECNO).LCY_AMOUNT := L_AC_ENTS(L_RECNO)
                                             .LCY_AMOUNT * -1;

            DBG('gwpks_util.g_branch_date:::' || GWPKS_UTIL.G_BRANCH_DATE);
            DBG('global.application_date:::' || GLOBAL.APPLICATION_DATE);
            IF GWPKS_UTIL.G_BRANCH_DATE > GLOBAL.APPLICATION_DATE AND
               GWPKS_UTIL.G_FROM_BEAN THEN
              L_AC_ENTS(L_RECNO).TRN_DT := GWPKS_UTIL.G_BRANCH_DATE;
            ELSE
              L_AC_ENTS(L_RECNO).TRN_DT := GLOBAL.APPLICATION_DATE;
            END IF;

            L_AC_ENTS(L_RECNO).USER_ID := NVL(L_AC_ENTS(L_RECNO).USER_ID,
                                              GLOBAL.USER_ID);

            IF NOT GWPKS_UTIL.G_FROM_BEAN THEN

              L_AC_ENTS(L_RECNO).TRN_DT := GLOBAL.APPLICATION_DATE;
            END IF;

            L_AC_ENTS(L_RECNO).USER_ID := NVL(L_AC_ENTS(L_RECNO).USER_ID,
                                              GLOBAL.USER_ID);
          END LOOP;
          IF CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
            DBG('Setting l_auth_stat as B since g_auto_ac_closure is true ...');
            L_AUTH_STAT := 'B';
          END IF;
          DBG('Putting back the reversal entries BY calling Acpks.fn_achandoff...');

          IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
            L_AUTHORISE := 'B';
            DBG('THE ACTION CODE FLAG IS FORCEFULLY SET TO B ' ||
                L_AUTHORISE);
          END IF;

          IF NOT ACPKS.FN_ACHANDOFF(P_TRN_REF_NO,
                                    2,
                                    GLOBAL.APPLICATION_DATE,
                                    L_AC_ENTS,
                                    L_AUTHORISE,
                                    'N',
                                    'Y',
                                    GLOBAL.USER_ID,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
            DBG('Failed IN Acpks.fn_achandoff OF fn_reversal IN Depks_Rtl_Teller...');
            DBG('Rolling back to savepoint rtl reverse');
            ROLLBACK TO RTL_REVERSE;
            RETURN FALSE;
          END IF;

          DBG('Cspks_Req_Global.g_Release_Type :::: ' ||
              CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            DBG('p_trn_ref_no while calling depks_rtl_teller_cluster.fn_reverse ::::: ' ||
                P_TRN_REF_NO);
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_FN_CALL_ID      := 1;
            IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_REVERSE(P_TRN_REF_NO,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
              DBG('Failed inside depks_rtl_teller_cluster.Fn_Save');
              DBG('Rolling back to savepoint rtl reverse');
              ROLLBACK TO RTL_REVERSE;
              RETURN FALSE;
            END IF;
          END IF;

        ELSE
          DBG('No entries corresponding TO this p_trn_ref_no IN actb_daily_log...');
          DBG('Rolling back to savepoint rtl reverse');
          ROLLBACK TO RTL_REVERSE;
          RETURN FALSE;
        END IF;

        BEGIN
          SELECT COUNT(*)
            INTO L_REV_UTIL
            FROM STTB_CUST_LIMIT_TRACKING
           WHERE CONTRACT_REF_NO = P_TRN_REF_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
                P_TRN_REF_NO || '~' || SQLERRM);
        END;

        IF L_REV_UTIL > 0 THEN
          BEGIN
            SELECT BRANCH_CODE, PRODUCT_CODE
              INTO L_BRANCH, L_PRODUCT_CODE
              FROM DETBS_RTL_TELLER
             WHERE TRN_REF_NO = P_TRN_REF_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
                  P_TRN_REF_NO || '~' || SQLERRM);
              P_ERR_CODE := 'DE-TUD-002';
              ROLLBACK TO RTL_REVERSE;
              RETURN FALSE;
          END;

          SELECT MODULE, PRODUCT_GROUP
            INTO L_MODULE, L_PRDGRP
            FROM CSTM_PRODUCT
           WHERE PRODUCT_CODE = L_PRODUCT_CODE;

          DBG('l_module' || L_MODULE);

          IF NOT
              STPKS_CUST_RESTR_UTIL_TRACK.FN_PROCESS_CHK_LIMIT(L_SCODE,
                                                               L_MODULE,
                                                               L_BRANCH,
                                                               P_TRN_REF_NO,
                                                               NULL,
                                                               NULL,
                                                               L_EVENT_CODE,
                                                               1,
                                                               L_PRDGRP,
                                                               L_TRN_DATE,
                                                               NULL,
                                                               '',
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               'D',
                                                               V_TBL_RESTR,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAM) THEN
            DBG('error Code' || P_ERR_CODE);
            DBG('error params' || P_ERR_PARAM);
          ELSE
            DBG('NTHNG');
          END IF;
        END IF;

      END IF;
    ELSE

      IF L_SETTLE_COUNT > 0 THEN
        DBG('Cannot proceed to reversal with l_settle_count ' ||
            L_SETTLE_COUNT);
        DBG('This TRANSACTION is NSF tracked Hence cannot be reversed...');
        L_ON_ERROR := TRUE;
      ELSE
        DBG('This TRANSACTION IS unauthorised AND can NOT be reversed...');
        L_ON_ERROR := TRUE;
      END IF;

    END IF;

    IF L_ON_ERROR THEN
      DBG('Reversal cannot be processed ');
      DBG('contract_ref_no --->' || P_TRN_REF_NO);
      P_ERR_CODE := 'DE-TUD-945';
      DBG('Rolling back to savepoint rtl reverse');
      ROLLBACK TO RTL_REVERSE;
      RETURN FALSE;
    END IF;

    DBG('Now UPDATING the Record_stat OF detbs_rtl_teller FOR the trn_ref_no...' ||
        P_TRN_REF_NO);

    IF L_AUTHORISE = 'B' THEN
      L_CHECKER_DT_STAMP := FN_SYSDATE;
      L_CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE +
                            (L_CHECKER_DT_STAMP - TRUNC(L_CHECKER_DT_STAMP));
      DBG('Checker date stamp is' || L_CHECKER_DT_STAMP);

      UPDATE DETBS_RTL_TELLER
         SET RECORD_STAT = 'V',
             AUTH_STAT   = 'A',

             CHECKER_ID       = NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID),
             CHECKER_DT_STAMP = L_CHECKER_DT_STAMP,

             REVR_DT = GLOBAL.APPLICATION_DATE

       WHERE ROWID = L_ROWID;
    ELSE

      --Get the maker id from iftb_rft_master table
      BEGIN
        SELECT *
          INTO L_IFTB_RFT_MASTER
          FROM IFTB_RFT_MASTER
         WHERE TRN_REF_NO = P_TRN_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          L_IFTB_RFT_MASTER := NULL;
      END;

      DBG('L_IFTB_RFT_MASTER.MAKER_ID=' || L_IFTB_RFT_MASTER.MAKER_ID);

      UPDATE DETBS_RTL_TELLER
         SET RECORD_STAT      = 'V',
             AUTH_STAT        = 'U',
             MAKER_ID         = L_IFTB_RFT_MASTER.MAKER_ID,
             MAKER_DT_STAMP   = L_IFTB_RFT_MASTER.MAKER_DT_STAMP,
             CHECKER_ID       = GLOBAL.USER_ID, --NULL,
             CHECKER_DT_STAMP = FN_SYSDATE --L_CHECKER_DT_STAMP--NULL

            ,
             REVR_DT = GLOBAL.APPLICATION_DATE

       WHERE TRN_REF_NO = L_IFTB_RFT_MASTER.TRN_REF_NO;
      --ROWID = L_ROWID;

    END IF;
    DBG('RECORD stat IS updated FOR the trn_ref_no IN detbs_rtl_teller...' ||
        P_TRN_REF_NO);
    RETURN TRUE;
  END FN_REVERSE;

  FUNCTION fn_enrich_product(p_ifdmtapa   IN OUT ifpks_ifdmtapa_Main.ty_ifdmtapa,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
    l_serial_no    VARCHAR2(16);
    l_trn_ref_no   iftb_rft_master.trn_ref_no%TYPE;
    l_ty_rtupld    depks_retailtellerupload.typ_retailtellerupld_rec;
    l_ret          BOOLEAN;
    l_tot_chg_amt  NUMBER(22, 3);
    l_rel_customer sttm_customer.customer_no%TYPE;
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_ib_flag      VARCHAR2(1) DEFAULT 'Y';
    l_arc_maint    iftm_arc_maint%ROWTYPE;
    l_prod         cstm_product%ROWTYPE;
    l_rate         NUMBER;
    l_charge_amt   NUMBER := 0;
    l_rate_flag    NUMBER;
    l_ccy1         iftb_mta_master.txn_ccy%TYPE;
    l_ccy2         iftb_mta_master.txn_ccy%TYPE;

    l_tot_chg_amount            iftb_mta_master.net_txn_amt%TYPE;
    l_txn_amt                   iftb_mta_master.txn_amt%TYPE;
    l_txn_amt1                  iftb_mta_master.txn_amt%TYPE;
    l_rate_code                 cstm_product.rate_code_preferred%Type;
    l_rate_code1                cstm_product.rate_code_preferred%Type;
    l_tot_chg_amt_in_txn_ccy    iftb_mta_master.txn_amt%TYPE;
    l_tot_chg_amt_in_lcy_ccy    iftb_mta_master.txn_amt%TYPE;
    l_arc_rate_code_type        iftm_arc_maint.cod_rate_code%Type;
    l_tot_chg_amount_in_txn_ccy iftb_mta_master.txn_amt%TYPE;
    l_tot_chg_amount_in_acc_ccy iftb_mta_master.txn_amt%TYPE;
    L_STTB_ACCOUNT              STTB_ACCOUNT%ROWTYPE;
    L_STTM_CUST_ACCOUNT         STTM_CUST_ACCOUNT%ROWTYPE;

    L_REM_POSTCODE varchar2(105);

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);

  BEGIN

    dbg('In FN_ENRICH_PRODUCT');

    p_ifdmtapa.v_iftb_mta_master.msg_flow := 'O';

    IF P_IFDMTAPA.v_iftb_mta_master.BEN_NATIONALITY IS NULL THEN

      DBG('BENEFICIARY NATIONALITY SHOULD NOT BE NULL');

      p_err_code := 'IF-MTA-016';

      pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

    END IF;

    IF LENGTH(P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS) < 12 THEN

      DBG('BENEFICIARY ADDRESS LENGTH MUST BE 12 CHARACTERS');

      p_err_code := 'IF-MTA-017';

      pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

    END IF;

    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('B2P', 'B2B') THEN

      IF P_IFDMTAPA.v_iftb_mta_master.REM_NOB IS NULL THEN

        p_err_code := 'IF-MTA-019';

        pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

      END IF;

    END IF;

    --Validate
    IF P_IFDMTAPA.v_iftb_mta_master.PAYMENT_MODE <> 'Cash Pickup' THEN

      PR_GET_PAY_GROUP_MODE_CODE(P_IFDMTAPA,
                                 L_PAYOUT_GRP_CODE,
                                 L_PAYOUT_MODE);
    END IF;

    DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
    DBG('P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE=' ||
        P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE);
    DBG('P_IFDMTAPA.v_iftb_mta_master.PAYMENT_MODE=' ||
        P_IFDMTAPA.v_iftb_mta_master.PAYMENT_MODE);

    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE IN ('P2B') AND
       P_IFDMTAPA.v_iftb_mta_master.PAYMENT_MODE = 'Account Credit' AND
       L_PAYOUT_GRP_CODE = 'AU01' THEN

      IF P_IFDMTAPA.v_iftb_mta_master.COMPANY_TYPE IS NULL THEN

        p_err_code := 'IF-MTA-020';

        pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

      END IF;

    END IF;

    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE = 'P2P' AND
       P_IFDMTAPA.v_iftb_mta_master.PAYMENT_MODE = 'Cash Pickup' THEN

      IF P_IFDMTAPA.v_iftb_mta_master.CASHPICKUP_LOC IS NULL THEN

        DBG('CASHPICKUP LOCATION SHOULD NOT BE NULL');

        p_err_code := 'IF-MTA-015';

        pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

      END IF;

      IF P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS IS NULL THEN

        DBG('BENEFICIARY ADDRESS SHOULD NOT BE NULL');

        p_err_code := 'IF-MTA-012';

        pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

      END IF;

      IF P_IFDMTAPA.v_iftb_mta_master.BEN_BIC IS NULL THEN

        DBG('Beneficiary BIC should not be null for Remit Type : P2P');

        p_err_code := 'IF-MTA-013';

        pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

      END IF;

      IF P_IFDMTAPA.v_iftb_mta_master.BEN_NAME IS NULL THEN

        DBG('BENEFICIARY ADDRESS SHOULD NOT BE NULL');

        p_err_code := 'IF-MTA-014';

        pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

      END IF;

    END IF;

    IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE = 'P2P' AND
       P_IFDMTAPA.v_iftb_mta_master.PAYMENT_MODE = 'Account Credit' THEN

      IF L_PAYOUT_GRP_CODE = 'AU01' THEN

        DBG('P_IFDMTAPA.v_iftb_mta_master.BEN_STATE=' ||
            P_IFDMTAPA.v_iftb_mta_master.BEN_STATE);

        DBG('P_IFDMTAPA.v_iftb_mta_master.BEN_CITY=' ||
            P_IFDMTAPA.v_iftb_mta_master.BEN_CITY);

        DBG('P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS=' ||
            P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS);

        DBG('P_IFDMTAPA.v_iftb_mta_master.BEN_EMAIL=' ||
            P_IFDMTAPA.v_iftb_mta_master.BEN_EMAIL);

        DBG('P_IFDMTAPA.v_iftb_mta_master.DOCUMENT_REF_NO=' ||
            P_IFDMTAPA.v_iftb_mta_master.DOCUMENT_REF_NO);

        DBG('P_IFDMTAPA.v_iftb_mta_master.BEN_phone=' ||
            P_IFDMTAPA.v_iftb_mta_master.BEN_phone);

        --Check Remitter/Sender Account selected or not
        IF P_IFDMTAPA.v_iftb_mta_master.REM_aCC IS NULL THEN

          DBG('SENDER ACCOUNT SHOULD NOT BE NULL');

          p_err_code := 'IF-MTA-011';

          pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

        END IF;

        --Pin Code of a customer
        L_REM_POSTCODE := FN_GET_PINCODE_CUST(P_IFDMTAPA);

        IF L_REM_POSTCODE IS NULL THEN

          dbg('PINC CODE IS NULL AT CUSTOMER LEVEL');

          --OVPKSS.PR_APPENDTBL('IF-MTA-001', null);

          p_err_code := 'IF-MTA-001';

          pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

          --RETURN FALSE;

        END IF;

        IF P_IFDMTAPA.v_iftb_mta_master.BEN_STATE IS NULL THEN

          DBG('BENEFICIARY STATE SHOULD NOT BE NULL');

          p_err_code := 'IF-MTA-002';

          --OVPKSS.PR_APPENDTBL(p_err_code, null);

          pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

          --RETURN FALSE;

        END IF;

        IF P_IFDMTAPA.v_iftb_mta_master.rem_phone IS NULL THEN

          DBG('REMITTER PHONE SHOULD NOT BE NULL');

          p_err_code := 'IF-MTA-003';

          --OVPKSS.PR_APPENDTBL(p_err_code, null);

          pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

          --RETURN FALSE;

        END IF;

        IF P_IFDMTAPA.v_iftb_mta_master.rem_EMAIL IS NULL THEN

          DBG('REMITTER EMAIL SHOULD NOT BE NULL');

          p_err_code := 'IF-MTA-004';

          --OVPKSS.PR_APPENDTBL(p_err_code, null);

          pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

          --RETURN FALSE;

        END IF;

        IF P_IFDMTAPA.v_iftb_mta_master.BEN_PHONE IS NULL THEN

          DBG('BENEFICIARY MOBILE NO SHOULD NOT BE NULL');

          p_err_code := 'IF-MTA-005';

          --OVPKSS.PR_APPENDTBL(p_err_code, null);

          pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

          --RETURN FALSE;

        END IF;

        IF P_IFDMTAPA.v_iftb_mta_master.BEN_EMAIL IS NULL THEN

          DBG('BENEFICIARY EMAIL SHOULD NOT BE NULL');

          p_err_code := 'IF-MTA-006';

          --OVPKSS.PR_APPENDTBL(p_err_code, null);

          pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

          --RETURN FALSE;

        END IF;

        IF P_IFDMTAPA.v_iftb_mta_master.BEN_ADDRESS IS NULL THEN

          DBG('BENEFICIARY ADDRESS SHOULD NOT BE NULL');

          p_err_code := 'IF-MTA-007';

          --OVPKSS.PR_APPENDTBL(p_err_code, null);

          pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

          --RETURN FALSE;

        END IF;

        IF P_IFDMTAPA.v_iftb_mta_master.BEN_POST_CODE IS NULL THEN

          DBG('BENEFICIARY POSTAL CODE SHOULD NOT BE NULL');

          p_err_code := 'IF-MTA-008';

          --OVPKSS.PR_APPENDTBL(p_err_code, null);

          pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

          --RETURN FALSE;

        END IF;

        IF P_IFDMTAPA.v_iftb_mta_master.DOCUMENT_REF_NO IS NULL THEN

          DBG('DOCUMENT REFERENCE NO SHOULD NOT BE NULL');

          p_err_code := 'IF-MTA-009';

          --OVPKSS.PR_APPENDTBL(p_err_code, null);

          pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

          --RETURN FALSE;

        END IF;

        IF P_IFDMTAPA.v_iftb_mta_master.BEN_CITY IS NULL THEN

          DBG('BENEFICIARY CITY SHOULD NOT BE NULL');

          p_err_code := 'IF-MTA-010';

          --OVPKSS.PR_APPENDTBL(p_err_code, null);

          pr_log_error('IFDMTAPA', 'FLEXCUBE', p_err_code, NULL);

          --RETURN FALSE;

        END IF;

      END IF;

    END IF;

    --Get Account details
    BEGIN
      SELECT *
        INTO L_STTB_ACCOUNT
        FROM STTB_ACCOUNT
       WHERE AC_GL_NO = p_ifdmtapa.v_iftb_mta_master.rem_acc;

    EXCEPTION
      WHEN OTHERS THEN
        L_STTB_ACCOUNT := NULL;
        DBG('FAILED IN GETTING ACCOUNT DETAILS');
    END;

    --Get Account details
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = p_ifdmtapa.v_iftb_mta_master.rem_acc;

    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
        DBG('FAILED IN GETTING ACCOUNT DETAILS');
    END;

    /*IF p_ifdmtapa.v_iftb_mta_master.TXN_CCY <> L_STTM_CUST_ACCOUNT.CCY THEN

      dbg('Transaction Currency must be same as Account Currency');
      p_err_code := 'IF-RFT-005';

      pr_log_error('IFDRFTPP', 'FLEXCUBE', p_err_code, NULL);

      RETURN FALSE;
    END IF;*/

    IF L_STTB_ACCOUNT.AC_STAT_DORMANT = 'Y' THEN
      dbg('Account Status is Dormant');
      p_err_code   := 'AC-VAC33';
      p_err_params := 'Status';
      RETURN FALSE;
    END IF;

    IF L_STTB_ACCOUNT.AC_STAT_NO_DR = 'Y' THEN
      dbg('Account Status is No Debit');
      p_err_code   := 'AC-VAC07';
      p_err_params := 'Status';
      RETURN FALSE;
    END IF;

    IF L_STTM_CUST_ACCOUNT.RECORD_STAT = 'C' THEN
      dbg('Account is Closed');
      p_err_code   := 'AC-VAC12';
      p_err_params := L_STTM_CUST_ACCOUNT.CUST_AC_NO;
      RETURN FALSE;
    END IF;

    IF L_STTB_ACCOUNT.AC_STAT_FROZEN = 'Y' THEN
      dbg('Account Status is Frozen');
      p_err_code   := 'AC-VAC04';
      p_err_params := 'Status';
      RETURN FALSE;
    END IF;

    IF p_ifdmtapa.v_iftb_mta_master.product_code IS NULL THEN
      dbg('Mandatory Field Product Code cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Product Code';
      RETURN FALSE;
    END IF;
    IF p_ifdmtapa.v_iftb_mta_master.txn_ccy IS NULL THEN
      dbg('Mandatory Fields Transaction Currency cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Transaction Currency';
      RETURN FALSE;
    END IF;
    IF p_ifdmtapa.v_iftb_mta_master.txn_amt IS NULL THEN
      dbg('Mandatory Fields Transaction Amount cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Transaction Amount';
      RETURN FALSE;
    END IF;
    IF p_ifdmtapa.v_iftb_mta_master.rem_acc IS NULL THEN
      dbg('Mandatory Fields Remitter Account cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Remitter Account';
      RETURN FALSE;
    END IF;

    IF p_ifdmtapa.v_iftb_mta_master.rem_acc IS NULL THEN
      dbg('Mandatory Fields Remitter Account cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Remitter Account';
      RETURN FALSE;
    END IF;

    IF p_ifdmtapa.v_iftb_mta_master.payment_mode = 'Account Credit' then
      IF p_ifdmtapa.v_iftb_mta_master.ben_bic IS NULL THEN
        dbg('Mandatory Fields beneficiary bank code cannot be null');
        p_err_code := 'IF-RFT-020';
        --p_err_params := 'Remitter Account';
        RETURN FALSE;
      END IF;

      IF p_ifdmtapa.v_iftb_mta_master.ben_acc IS NULL THEN
        dbg('Mandatory Fields beneficiary Account cannot be null');
        p_err_code := 'IF-RFT-021';
        --p_err_params := 'Remitter Account';
        RETURN FALSE;
      END IF;
    END IF;

    DBG('p_ifdmtapa.v_iftb_mta_master.branch_code=' ||
        p_ifdmtapa.v_iftb_mta_master.branch_code);
    DBG('p_ifdmtapa.v_iftb_mta_master.product_code=' ||
        p_ifdmtapa.v_iftb_mta_master.product_code);
    DBG('p_ifdmtapa.v_iftb_mta_master.transfer_date=' ||
        p_ifdmtapa.v_iftb_mta_master.transfer_date);

    -- reference no
    IF p_ifdmtapa.v_iftb_mta_master.trn_ref_no IS NULL THEN
      IF NOT trpkss.fn_get_product_refno(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                         p_ifdmtapa.v_iftb_mta_master.product_code,
                                         global.application_date,
                                         --p_ifdmtapa.v_iftb_mta_master.transfer_date,
                                         l_serial_no,
                                         l_trn_ref_no,
                                         p_err_code) THEN
        dbg('Failed in generation Transaction Ref No');
        dbg('who called me=' || dbms_utility.format_error_backtrace);
        dbg('who called me=' || dbms_utility.format_call_stack);
        RETURN FALSE;
      ELSE
        dbg('l_trn_ref_no=' || l_trn_ref_no);
        p_ifdmtapa.v_iftb_mta_master.trn_ref_no := l_trn_ref_no;

      END IF;
    END IF;

    -- charge pickup
    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdmtapa.v_iftb_mta_master.product_code;

    SELECT cust_no, ccy
      INTO l_rel_customer, l_ac_ccy
      FROM sttm_cust_account
     WHERE cust_ac_no = p_ifdmtapa.v_iftb_mta_master.rem_acc;

    dbg('got l_rel_customer' || l_rel_customer);

    IF NOT
        cspkss_arc.fn_charge_pickup(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                    p_ifdmtapa.v_iftb_mta_master.product_code,
                                    'P',
                                    p_ifdmtapa.v_iftb_mta_master.product_code,
                                    p_ifdmtapa.v_iftb_mta_master.txn_ccy,
                                    l_rel_customer,
                                    p_ifdmtapa.v_iftb_mta_master.txn_ccy,
                                    p_ifdmtapa.v_iftb_mta_master.txn_amt,
                                    l_prod.rate_type_preferred,
                                    l_prod.rate_code_preferred,
                                    NULL,
                                    l_rel_customer,
                                    l_ib_flag,
                                    l_arc_maint,
                                    p_err_code,
                                    p_err_params,
                                    p_ifdmtapa.v_iftb_mta_master.rem_acc,
                                    p_ifdmtapa.v_iftb_mta_master.branch_code) THEN
      dbg('CHARGE PICKUP failed');
      RETURN FALSE;
    END IF;

    DBG('l_arc_maint.cod_chg_amt =' || l_arc_maint.cod_chg_amt);
    DBG('p_ifdmtapa.v_iftb_mta_master.BEN_COUNTRY=' ||
        p_ifdmtapa.v_iftb_mta_master.BEN_COUNTRY);

    --Get custom fee
    BEGIN
      SELECT CODE
        INTO l_arc_maint.cod_chg_amt
        FROM LMTM_TYPE_VALUES
       WHERE TYPE = 'MTA_OUT_FEE_USD'
         AND VALUE = p_ifdmtapa.v_iftb_mta_master.BEN_COUNTRY;
    EXCEPTION
      WHEN OTHERS THEN
        l_arc_maint.cod_chg_amt := 0;
    END;

    DBG('l_arc_maint.cod_chg_amt =' || l_arc_maint.cod_chg_amt);

    /*IF l_arc_maint.cod_chg_track_prf = 'W' THEN

      l_arc_maint.cod_chg_amt := null; --0;

    END IF;

    IF l_arc_maint.cod_chg_track_prf1 = 'W' THEN

      l_arc_maint.cod_chg_amt1 := null; --0;

    END IF;*/

    --Charge1
    IF l_arc_maint.cod_chg_amt IS NOT NULL THEN
      DBG('Populating Charge 1');

      p_ifdmtapa.v_iftb_mta_charge(1).trn_ref_no := p_ifdmtapa.v_iftb_mta_master.trn_ref_no;
      p_ifdmtapa.v_iftb_mta_charge(1).chg_srno := 1;
      p_ifdmtapa.v_iftb_mta_charge(1).chg1_desc := l_arc_maint.cod_chg_desc;
      p_ifdmtapa.v_iftb_mta_charge(1).chg1_waiver := 'N';
      p_ifdmtapa.v_iftb_mta_charge(1).chg1_amt := case
                                                   l_arc_maint.cod_chg_track_prf
                                                    when 'W' then
                                                     0
                                                    else
                                                     l_arc_maint.cod_chg_amt
                                                  end; --waive charges fix

      p_ifdmtapa.v_iftb_mta_charge(1).chg1_ccy := l_arc_maint.cod_chg_ccy;

      DBG('p_ifdmtapa.v_iftb_mta_charge(1).trn_ref_no=' || p_ifdmtapa.v_iftb_mta_charge(1)
          .trn_ref_no);
      DBG('p_ifdmtapa.v_iftb_mta_charge(1).chg_srno=' || p_ifdmtapa.v_iftb_mta_charge(1)
          .chg_srno);
      DBG('p_ifdmtapa.v_iftb_mta_charge(1).chg1_desc=' || p_ifdmtapa.v_iftb_mta_charge(1)
          .chg1_desc);
      DBG('p_ifdmtapa.v_iftb_mta_charge(1).chg1_waiver=' || p_ifdmtapa.v_iftb_mta_charge(1)
          .chg1_waiver);
      DBG('p_ifdmtapa.v_iftb_mta_charge(1).chg1_amt=' || p_ifdmtapa.v_iftb_mta_charge(1)
          .chg1_amt);
      DBG('p_ifdmtapa.v_iftb_mta_charge(1).chg1_ccy=' || p_ifdmtapa.v_iftb_mta_charge(1)
          .chg1_ccy);

      DBG('p_ifdmtapa.v_iftb_mta_charge.count=' ||
          p_ifdmtapa.v_iftb_mta_charge.count);

      DBG('global.lcy=' || global.lcy);
      DBG('l_arc_maint.cod_chg_ccy=' || l_arc_maint.cod_chg_ccy);

      -- Converting charge into local ccy for display in charge tab
      IF l_arc_maint.cod_chg_ccy <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                      l_arc_maint.cod_chg_ccy,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      p_ifdmtapa.v_iftb_mta_charge(1).chg1_amt, --l_arc_maint.cod_chg_amt, --waive charges fix
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdmtapa.v_iftb_mta_charge(1).lcy_chg1 := l_charge_amt;
        p_ifdmtapa.v_iftb_mta_charge(1).xrate := l_rate;
      ELSE
        p_ifdmtapa.v_iftb_mta_charge(1).lcy_chg1 := p_ifdmtapa.v_iftb_mta_charge(1)
                                                    .chg1_amt; --l_arc_maint.cod_chg_amt, --waive charges fix
        p_ifdmtapa.v_iftb_mta_charge(1).xrate := 1;
      END IF;
      dbg('Amount 1 in Local ccy->' || p_ifdmtapa.v_iftb_mta_charge(1)
          .lcy_chg1);

      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy <> p_ifdmtapa.v_iftb_mta_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                      l_arc_maint.cod_chg_ccy,
                                      p_ifdmtapa.v_iftb_mta_master.txn_ccy,
                                      l_prod.rate_type_preferred,
                                      NVL(l_arc_maint.cod_rate_code_Type, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                      p_ifdmtapa.v_iftb_mta_charge(1).chg1_amt, --l_arc_maint.cod_chg_amt, --waive charges fix
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdmtapa.v_iftb_mta_charge(1).chg1_in_txn := l_charge_amt;
        p_ifdmtapa.v_iftb_mta_charge(1).txn_xrate := l_rate;
        dbg(' * Amount 1 in TXN ccy->' || p_ifdmtapa.v_iftb_mta_charge(1)
            .chg1_in_txn);
      ELSE
        p_ifdmtapa.v_iftb_mta_charge(1).chg1_in_txn := p_ifdmtapa.v_iftb_mta_charge(1)
                                                       .chg1_amt; --l_arc_maint.cod_chg_amt; --waive charges fix
        p_ifdmtapa.v_iftb_mta_charge(1).txn_xrate := 1;
        dbg('** Amount 1 in TXN ccy->' || p_ifdmtapa.v_iftb_mta_charge(1)
            .chg1_in_txn);
      END IF;

      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                      l_arc_maint.cod_chg_ccy,
                                      l_ac_ccy,
                                      l_prod.rate_type_preferred,
                                      NVL(l_arc_maint.cod_rate_code_Type, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                      p_ifdmtapa.v_iftb_mta_charge(1).chg1_amt, --l_arc_maint.cod_chg_amt, --waive charges fix
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdmtapa.v_iftb_mta_charge(1).chg1_in_acc := l_charge_amt;
        p_ifdmtapa.v_iftb_mta_charge(1).acc_xrate := l_rate;
        dbg('* Amount 1 in acc ccy->' || p_ifdmtapa.v_iftb_mta_charge(1)
            .chg1_in_acc);
      ELSE
        p_ifdmtapa.v_iftb_mta_charge(1).chg1_in_acc := p_ifdmtapa.v_iftb_mta_charge(1)
                                                       .chg1_amt; --l_arc_maint.cod_chg_amt; --waive charges fix
        p_ifdmtapa.v_iftb_mta_charge(1).acc_xrate := 1;
        dbg('** Amount 1 in acc ccy->' || p_ifdmtapa.v_iftb_mta_charge(1)
            .chg1_in_acc);
      END IF;
    END IF;

    --Charge2
    IF l_arc_maint.cod_chg_amt1 IS NOT NULL THEN
      DBG('Populating Charge 2');
      p_ifdmtapa.v_iftb_mta_charge(2).trn_ref_no := p_ifdmtapa.v_iftb_mta_master.trn_ref_no;
      p_ifdmtapa.v_iftb_mta_charge(2).chg_srno := 2;
      p_ifdmtapa.v_iftb_mta_charge(2).chg2_desc := l_arc_maint.cod_chg_desc1;
      p_ifdmtapa.v_iftb_mta_charge(2).chg2_waiver := 'N';
      p_ifdmtapa.v_iftb_mta_charge(2).chg2_amt := case
                                                   l_arc_maint.cod_chg_track_prf1
                                                    when 'W' then
                                                     0
                                                    else
                                                     l_arc_maint.cod_chg_amt1
                                                  end; --waive charges fix
      p_ifdmtapa.v_iftb_mta_charge(2).chg2_ccy := l_arc_maint.cod_chg_ccy1;

      DBG('p_ifdmtapa.v_iftb_mta_charge(2).trn_ref_no=' || p_ifdmtapa.v_iftb_mta_charge(2)
          .trn_ref_no);
      DBG('p_ifdmtapa.v_iftb_mta_charge(2).chg_srno=' || p_ifdmtapa.v_iftb_mta_charge(2)
          .chg_srno);
      DBG('p_ifdmtapa.v_iftb_mta_charge(2).chg2_desc=' || p_ifdmtapa.v_iftb_mta_charge(2)
          .chg2_desc);
      DBG('p_ifdmtapa.v_iftb_mta_charge(2).chg2_waiver=' || p_ifdmtapa.v_iftb_mta_charge(2)
          .chg2_waiver);
      DBG('p_ifdmtapa.v_iftb_mta_charge(2).chg2_amt=' || p_ifdmtapa.v_iftb_mta_charge(2)
          .chg2_amt);
      DBG('p_ifdmtapa.v_iftb_mta_charge(2).chg2_ccy=' || p_ifdmtapa.v_iftb_mta_charge(2)
          .chg2_ccy);

      IF l_arc_maint.cod_chg_ccy1 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                      l_arc_maint.cod_chg_ccy1,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      p_ifdmtapa.v_iftb_mta_charge(2).chg2_amt, --l_arc_maint.cod_chg_amt1, --waive charges fix
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdmtapa.v_iftb_mta_charge(2).lcy_chg2 := l_charge_amt;
        p_ifdmtapa.v_iftb_mta_charge(2).xrate := l_rate;
      ELSE
        p_ifdmtapa.v_iftb_mta_charge(2).lcy_chg2 := p_ifdmtapa.v_iftb_mta_charge(2)
                                                    .chg2_amt; --l_arc_maint.cod_chg_amt1; --waive charges fix
        p_ifdmtapa.v_iftb_mta_charge(2).xrate := 1;
      END IF;

      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy1 <> p_ifdmtapa.v_iftb_mta_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                   l_arc_maint.cod_chg_ccy1,
                                   p_ifdmtapa.v_iftb_mta_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type1, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   p_ifdmtapa.v_iftb_mta_charge(2).chg2_amt, --l_arc_maint.cod_chg_amt1, --waive charges fix
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdmtapa.v_iftb_mta_charge(2).chg2_in_txn := l_charge_amt;
        p_ifdmtapa.v_iftb_mta_charge(2).txn_xrate := l_rate;
        dbg('* Amount 2 in TXN ccy->' || p_ifdmtapa.v_iftb_mta_charge(2)
            .chg2_in_txn);
      ELSE
        p_ifdmtapa.v_iftb_mta_charge(2).chg2_in_txn := p_ifdmtapa.v_iftb_mta_charge(2)
                                                       .chg2_amt; --l_arc_maint.cod_chg_amt1; --waive charges fix
        p_ifdmtapa.v_iftb_mta_charge(2).txn_xrate := 1;
        dbg('** Amount 2 in TXN ccy->' || p_ifdmtapa.v_iftb_mta_charge(2)
            .chg2_in_txn);
      END IF;

      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy1 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                   l_arc_maint.cod_chg_ccy1,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type1, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   p_ifdmtapa.v_iftb_mta_charge(2).chg2_amt, --l_arc_maint.cod_chg_amt1, --waive charges fix
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdmtapa.v_iftb_mta_charge(2).chg2_in_acc := l_charge_amt;
        p_ifdmtapa.v_iftb_mta_charge(2).acc_xrate := l_rate;
        dbg('* Amount 2 in acc ccy->' || p_ifdmtapa.v_iftb_mta_charge(2)
            .chg2_in_acc);
      ELSE
        p_ifdmtapa.v_iftb_mta_charge(2).chg2_in_acc := p_ifdmtapa.v_iftb_mta_charge(2)
                                                       .chg2_amt; --l_arc_maint.cod_chg_amt1; --waive charges fix
        p_ifdmtapa.v_iftb_mta_charge(2).acc_xrate := 1;
        dbg('** Amount 2 in acc ccy->' || p_ifdmtapa.v_iftb_mta_charge(2)
            .chg2_in_acc);
      END IF;
      p_ifdmtapa.v_iftb_mta_charge(2).oth_ccy := l_arc_maint.cod_chg_ccy1;

    END IF;

    --Charge3
    /*IF l_arc_maint.cod_chg_amt2 IS NOT NULL THEN
      DBG('Populating Charge 3');
      p_ifdmtapa.v_iftb_mta_charge(3).trn_ref_no := p_ifdmtapa.v_iftb_mta_master.trn_ref_no;
      p_ifdmtapa.v_iftb_mta_charge(3).chg_srno := 3;
      p_ifdmtapa.v_iftb_mta_charge(3).chg3_desc := l_arc_maint.cod_chg_desc2;
      p_ifdmtapa.v_iftb_mta_charge(3).chg3_waiver := 'N';
      p_ifdmtapa.v_iftb_mta_charge(3).chg3_amt := l_arc_maint.cod_chg_amt2;
      p_ifdmtapa.v_iftb_mta_charge(3).chg3_ccy := l_arc_maint.cod_chg_ccy2;

      DBG('p_ifdmtapa.v_iftb_mta_charge(3).trn_ref_no=' || p_ifdmtapa.v_iftb_mta_charge(3)
          .trn_ref_no);
      DBG('p_ifdmtapa.v_iftb_mta_charge(3).chg_srno=' || p_ifdmtapa.v_iftb_mta_charge(3)
          .chg_srno);
      DBG('p_ifdmtapa.v_iftb_mta_charge(3).chg3_desc=' || p_ifdmtapa.v_iftb_mta_charge(3)
          .chg3_desc);
      DBG('p_ifdmtapa.v_iftb_mta_charge(3).chg3_waiver=' || p_ifdmtapa.v_iftb_mta_charge(3)
          .chg3_waiver);
      DBG('p_ifdmtapa.v_iftb_mta_charge(3).chg3_amt=' || p_ifdmtapa.v_iftb_mta_charge(3)
          .chg3_amt);
      DBG('p_ifdmtapa.v_iftb_mta_charge(3).chg3_ccy=' || p_ifdmtapa.v_iftb_mta_charge(3)
          .chg3_ccy);

      IF l_arc_maint.cod_chg_ccy2 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                      l_arc_maint.cod_chg_ccy2,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt2,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdmtapa.v_iftb_mta_charge(3).lcy_chg3 := l_charge_amt;
        p_ifdmtapa.v_iftb_mta_charge(3).xrate := l_rate;
      ELSE
        p_ifdmtapa.v_iftb_mta_charge(3).lcy_chg3 := l_arc_maint.cod_chg_amt2;
        p_ifdmtapa.v_iftb_mta_charge(3).xrate := 1;
      END IF;

      -- Converting charge into txn ccy
      IF l_arc_maint.cod_chg_ccy2 <> p_ifdmtapa.v_iftb_mta_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                   l_arc_maint.cod_chg_ccy2,
                                   p_ifdmtapa.v_iftb_mta_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type2, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt2,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdmtapa.v_iftb_mta_charge(3).chg3_in_txn := l_charge_amt;
        p_ifdmtapa.v_iftb_mta_charge(3).txn_xrate := l_rate;
        dbg('* Amount 3 in TXN ccy->' || p_ifdmtapa.v_iftb_mta_charge(3)
            .chg3_in_txn);
      ELSE
        p_ifdmtapa.v_iftb_mta_charge(3).chg3_in_txn := l_arc_maint.cod_chg_amt2;
        p_ifdmtapa.v_iftb_mta_charge(3).txn_xrate := 1;
        dbg('** Amount 3 in TXN ccy->' || p_ifdmtapa.v_iftb_mta_charge(3)
            .chg3_in_txn);
      END IF;

      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy2 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                   l_arc_maint.cod_chg_ccy2,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type2, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt2,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdmtapa.v_iftb_mta_charge(3).chg3_in_acc := l_charge_amt;
        p_ifdmtapa.v_iftb_mta_charge(3).acc_xrate := l_rate;
        dbg('* Amount 3 in ACC ccy->' || p_ifdmtapa.v_iftb_mta_charge(3)
            .chg3_in_acc);
      ELSE
        p_ifdmtapa.v_iftb_mta_charge(3).chg3_in_acc := l_arc_maint.cod_chg_amt2;
        p_ifdmtapa.v_iftb_mta_charge(3).acc_xrate := 1;
        dbg('** Amount 3 in ACC ccy->' || p_ifdmtapa.v_iftb_mta_charge(3)
            .chg3_in_acc);
      END IF;
      p_ifdmtapa.v_iftb_mta_charge(3).oth_ccy := l_arc_maint.cod_chg_ccy2;
    END IF;*/

    l_tot_chg_amt_in_txn_ccy := nvl(l_tot_chg_amt_in_txn_ccy, 0) +
                                nvl(p_ifdmtapa.v_iftb_mta_charge(1)
                                    .chg1_in_txn,
                                    0) /*+ nvl(p_ifdmtapa.v_iftb_mta_charge(2)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             .chg2_in_txn,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0)  + nvl(p_ifdmtapa.v_iftb_mta_charge(3)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          .chg3_in_txn,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          0)*/
     ;

    dbg('L_TOT_CHG_AMT~p_ifdmtapa.v_iftbs_pgw_master_custom.TXN_CCY~GLOBAL.LCY' ||
        l_tot_chg_amt || '~' || p_ifdmtapa.v_iftb_mta_master.txn_ccy || '~' ||
        global.lcy);

    dbg('Total charge to be paid in TXN CCY ->' ||
        l_tot_chg_amt_in_txn_ccy);
    p_ifdmtapa.v_iftb_mta_master.tot_chg_amt := l_tot_chg_amt_in_txn_ccy; -- We are displaying total charge in txn amount only --Tuning of code in charge calculation

    -- Total Charge amount in local and remitter/account ccy
    /*FOR J IN 1 .. p_ifdmtapa.v_iftb_mta_charge.count LOOP
      dbg('1 l_tot_chg_amt_in_lcy_ccy->' || l_tot_chg_amt_in_lcy_ccy ||
          'p_ifdmtapa.v_iftb_mta_charge(j).lcy_chg' || p_ifdmtapa.v_iftb_mta_charge(j)
          .lcy_chg);
      dbg('1 l_tot_chg_amount_in_acc_ccy->' || l_tot_chg_amount_in_acc_ccy ||
          'p_ifdmtapa.v_iftb_mta_charge(j).chg_in_acc' || p_ifdmtapa.v_iftb_mta_charge(j)
          .chg_in_acc);
      l_tot_chg_amt_in_lcy_ccy    := nvl(l_tot_chg_amt_in_lcy_ccy, 0) +
                                     nvl(p_ifdmtapa.v_iftb_mta_charge(j)
                                         .lcy_chg,
                                         0);
      l_tot_chg_amount_in_acc_ccy := nvl(l_tot_chg_amount_in_acc_ccy, 0) +
                                     nvl(p_ifdmtapa.v_iftb_mta_charge(j)
                                         .chg_in_acc,
                                         0);

      dbg('2 l_tot_chg_amt_in_lcy_ccy->' || l_tot_chg_amt_in_lcy_ccy);
      dbg('2 l_tot_chg_amount_in_acc_ccy->' || l_tot_chg_amount_in_acc_ccy);
    End Loop;*/

    l_tot_chg_amt_in_lcy_ccy    := nvl(l_tot_chg_amt_in_lcy_ccy, 0) +
                                   nvl(p_ifdmtapa.v_iftb_mta_charge(1)
                                       .lcy_chg1,
                                       0) /*+ nvl(p_ifdmtapa.v_iftb_mta_charge(2)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                .lcy_chg2,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                0)  +
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   nvl(p_ifdmtapa.v_iftb_mta_charge(3)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       .lcy_chg3,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       0)*/
     ;
    l_tot_chg_amount_in_acc_ccy := nvl(l_tot_chg_amount_in_acc_ccy, 0) +
                                   nvl(p_ifdmtapa.v_iftb_mta_charge(1)
                                       .chg1_in_acc,
                                       0) /*+ nvl(p_ifdmtapa.v_iftb_mta_charge(2)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            .chg2_in_acc,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            0)  +
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   nvl(p_ifdmtapa.v_iftb_mta_charge(3)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       .chg3_in_acc,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       0)*/
     ;

    dbg('chgs calculated ->');

    If l_prod.rate_code_preferred = 'B' Then
      l_rate_code := Null;
      If (p_ifdmtapa.v_iftb_mta_master.txn_ccy = global.lcy and
         l_ac_ccy != global.lcy) OR
         (p_ifdmtapa.v_iftb_mta_master.txn_ccy != global.lcy and
         l_ac_ccy <> global.lcy and
         p_ifdmtapa.v_iftb_mta_master.txn_ccy <> l_ac_ccy) Then
        l_rate_code := 'B';

      Else
        l_rate_code := l_prod.rate_code_preferred;
      End If;
    Else
      l_rate_code := l_prod.rate_code_preferred;
    End If;
    dbg('p_ifdmtapa.v_iftb_mta_master.txn_amt->' ||
        p_ifdmtapa.v_iftb_mta_master.txn_amt);

    dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
        l_rate_code1);

    If l_ac_ccy <> global.lcy Then
      begin
        select decode(l_rate_code,
                      'B',
                      'S',
                      'S',
                      'B',
                      'M',
                      'M',
                      l_rate_code)
          Into l_rate_code1
          from dual;
      exception
        when others then
          dbg('Exception found l_rate_code-> ' || l_rate_code);
      end;
    End If;
    dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
        l_rate_code1);
    dbg('l_txn_amt l_txn_amt l_txn_amt=' || l_txn_amt);
    -- Total Txn amount in remitter currency
    IF p_ifdmtapa.v_iftb_mta_master.txn_ccy <> l_ac_ccy THEN
      l_rate := NULL;
      --l_charge_amt := NULL;
      l_txn_amt1 := p_ifdmtapa.v_iftb_mta_master.txn_amt;
      /*IF NOT cypkss.fn_amt1_to_amt2(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                    p_ifdmtapa.v_iftb_mta_master.txn_ccy,
                                    l_ac_ccy,
                                    l_prod.rate_type_preferred,
                                    nvl(l_rate_code1, l_rate_code),
                                    l_txn_amt1,
                                    'Y',
                                    l_txn_amt,
                                    l_rate,
                                    p_err_params) THEN
        debug.pr_debug('**', '');
        debug.pr_debug('**', SQLERRM);
        p_err_code   := 'ST-OTHR-001';
        p_err_params := NULL;
        RETURN FALSE;
      END IF;*/

      -- xrate
      IF p_ifdmtapa.v_iftb_mta_master.txn_ccy <> l_ac_ccy THEN

        IF p_ifdmtapa.v_iftb_mta_master.txn_ccy = global.lcy THEN
          l_ccy1 := l_ac_ccy;
          l_ccy2 := p_ifdmtapa.v_iftb_mta_master.txn_ccy;
        ELSE
          l_ccy1 := p_ifdmtapa.v_iftb_mta_master.txn_ccy;
          l_ccy2 := l_ac_ccy;
        END IF;
        dbg('l_rate_code->' || l_rate_code || 'l_prod.rate_type_preferred' ||
            l_prod.rate_type_preferred);
        dbg('Before p_ifdmtapa.v_iftbs_pgw_master_custom.exch_rate->' ||
            p_ifdmtapa.v_iftb_mta_master.exch_rate);

        If (p_ifdmtapa.v_iftb_mta_master.txn_ccy != global.lcy and
           --l_ac_ccy <> global.lcy and
           l_ac_ccy = global.lcy and
           p_ifdmtapa.v_iftb_mta_master.txn_ccy <> l_ac_ccy) and
           l_prod.rate_code_preferred = 'B' Then
          l_rate_code := 'B'; --l_rate_code := 'S';
        ELSE
          l_rate_code := 'S'; --added else condition
        End If;

        dbg('l_rate_code->' || l_rate_code);

        dbg('l_prod.rate_type_preferred=' || l_prod.rate_type_preferred);

        IF NOT cypkss.fn_getrate(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                 l_ccy2,
                                 l_ccy1, --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                 l_prod.rate_type_preferred,
                                 l_rate_code, --l_prod.rate_code_preferred,
                                 p_ifdmtapa.v_iftb_mta_master.transfer_date,
                                 p_ifdmtapa.v_iftb_mta_master.transfer_date,
                                 p_ifdmtapa.v_iftb_mta_master.exch_rate,
                                 l_rate_flag,
                                 p_err_code) THEN
          dbg('Failed in Fn_GetRate');
          RETURN FALSE;
        END IF;
      ELSE
        p_ifdmtapa.v_iftb_mta_master.exch_rate := 1;
      END IF;

      DBG('p_ifdmtapa.v_iftb_mta_master.exch_rate==' ||
          p_ifdmtapa.v_iftb_mta_master.exch_rate);

      --Using above rate..convert khr to usd amount
      IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdmtapa.v_iftb_mta_master.txn_ccy,
                                    l_ac_ccy,
                                    l_txn_amt1,
                                    p_ifdmtapa.v_iftb_mta_master.exch_rate,
                                    'Y',
                                    l_txn_amt,
                                    p_err_params) THEN
        RETURN FALSE;
      END IF;
    ELSE
      p_ifdmtapa.v_iftb_mta_master.exch_rate := 1;
    END IF;
    dbg('Final txn_amt->' || l_txn_amt || 'Final chg_amount->' ||
        l_tot_chg_amount);
    dbg('Total Charges in local ccy->' || l_tot_chg_amt_in_lcy_ccy);
    dbg('Total Charges in txn ccy->' || l_tot_chg_amount_in_txn_ccy);
    dbg('Total Charges in acc ccy->' || l_tot_chg_amount_in_acc_ccy);

    -- Net DB Amount (Charges + Txn amount)
    If p_ifdmtapa.v_iftb_mta_master.txn_ccy <> l_ac_ccy Then
      dbg('apple');
      p_ifdmtapa.v_iftb_mta_master.net_txn_amt := nvl(l_txn_amt, 0) +
                                                  (Nvl(l_tot_chg_amount_in_acc_ccy,
                                                       0));

    Elsif p_ifdmtapa.v_iftb_mta_master.txn_ccy = l_ac_ccy Then
      dbg('mango');
      p_ifdmtapa.v_iftb_mta_master.net_txn_amt := nvl(p_ifdmtapa.v_iftb_mta_master.txn_amt,
                                                      0) +
                                                  (Nvl(l_tot_chg_amount_in_acc_ccy,
                                                       0));

    End If;
    dbg('p_ifdmtapa.v_iftb_mta_master.net_txn_amt->' ||
        p_ifdmtapa.v_iftb_mta_master.net_txn_amt);

    dbg('got l_rel_customer' || l_rel_customer);

    dbg('Returning Success From FN_ENRICH_PRODUCT..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.FN_ENRICH_PRODUCT ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_enrich_product;

  /*FUNCTION FN_MTA_REVERSE(p_ifdmtapa IN ifpks_ifdmtapa_main.ty_ifdmtapa)
    RETURN BOOLEAN IS

    P_ERR_CODE         ERTB_MSGS.ERR_CODE%TYPE;
    P_ERR_PARAM        ERTB_MSGS.MESSAGE%TYPE;
    L_FORMATTED_MSG    CLOB;
    L_IN_RESP          CLOB;
    L_COSMETIC_RES_MSG CLOB;
    L_GEN_SEQ_NO       VARCHAR2(100);
    L_COUNT            NUMBER;

    P_DOCUMENT_XML  XMLTYPE;
    L_RESP_IN_XML   CLOB;
    L_RESPONSE_CODE IFTBS_RFT_MASTER.TXN_STATUS%TYPE;
    L_RESPONSE_MSG  IFTBS_RFT_MASTER.TXN_REMARKS%TYPE;

  BEGIN

    DEBUG.PR_DEBUG('IF', 'START OF FN_MTA_REVERSE');

    --Go for Cancellation API
    --Get Cancel Message
    L_FORMATTED_MSG := FN_RETURN_FORMATTED_CANCEL_MSG(p_ifdmtapa); --REPLACE(L_FORMATTED_MSG, '$L_MSG_ID', L_MSG_ID);

    DBG('AFTER REPLACEMENT OF CANCEL MSG=' || L_FORMATTED_MSG);

    --Log Cancel Request of RFT

    DBG('LOGGING CANCEL REQUEST OF RFT');

    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

    PR_INSERT_RFT_CANCEL_WS_LOG(L_GEN_SEQ_NO,
                                p_ifdrftpm.v_iftbs_rft_master.trn_ref_no,
                                SYSDATE,
                                'Cancel',
                                L_FORMATTED_MSG,
                                'Cancel of RFT');

    IF NOT IFPKS_IFDRFTPM_CUSTOM.FN_RFT_HTTP_CALL('C',
                                                  L_FORMATTED_MSG,
                                                  L_IN_RESP) THEN

      DBG('FAILED IN CALLING THE CANCELLATION API');

      RETURN FALSE;

    ELSE

      DBG('RESPONSE OF CANCELLATION IN JSON IS ' || L_IN_RESP);

      --Get JSON in XML
      L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
      DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

      L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
      DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);

      L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;;', '>');
      DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);

      DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);

      P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

      L_RESPONSE_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                         .GETSTRINGVAL;

      L_RESPONSE_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                        .GETSTRINGVAL;

      DBG('L_RESPONSE_CODE =' || L_RESPONSE_CODE);
      DBG('L_RESPONSE_MSG =' || L_RESPONSE_MSG);

      IF L_RESPONSE_CODE = 'ERROR_500' THEN

        dbg('RFT Client Module is Down');

        p_err_code := 'IF-RFT-017';

        pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

        RETURN FALSE;

      END IF;

      IF L_RESPONSE_CODE = 'SUCCESS' THEN

        DBG('SUCCESS IN CANCELLING THE ORIGINAL RFT OUTGOING TXN');

        SAVEPOINT REVERSE_POINT;

        IF P_IFDRFTPM.V_IFTBS_RFT_MASTER.TRN_REF_NO IS NOT NULL THEN

          IF NOT FN_REVERSE(p_ifdrftpm.v_iftbs_rft_master.trn_ref_no,
                            P_ERR_CODE,
                            P_ERR_PARAM) THEN

            DBG('FAILED IN REVERSING THE RFT OUTGOING TRANSACTION');
            DBG('P_ERR_CODE=' || P_ERR_CODE);
            DBG('P_ERR_PARAM=' || P_ERR_PARAM);

            ROLLBACK TO REVERSE_POINT;

            RETURN FALSE;

          ELSE

            DBG('SUCCESS IN REVERSING THE RFT OUTGOING TRANSACTION');

            IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(GLOBAL.CURRENT_BRANCH,
                                                        p_ifdrftpm.v_iftbs_rft_master.trn_ref_no,
                                                        GLOBAL.USER_ID,
                                                        GLOBAL.LCY,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAM) THEN
              DBG('AUTH RETURNED FALSE ' || P_ERR_CODE);

              ROLLBACK TO REVERSE_POINT;

              RETURN FALSE;

            ELSE

              RETURN TRUE;

            END IF;

          END IF;
        END IF;

      ELSE

        DBG('FAILED IN CANCELLING THE ORIGINAL RFT OUTGOING TXN');
        RETURN FALSE;

      END IF;

    END IF;

    DBG('END OF FN_RFT_REVERSE');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RFT_REVERSE');
      DBG('ERROR CODE IN FN_RFT_REVERSE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RFT_REVERSE=' || SQLERRM);
      RETURN FALSE;
  END FN_MTA_REVERSE;*/

  FUNCTION FN_MTA_TXN_SAVE(p_ifdmtapa IN OUT ifpks_ifdmtapa_Main.ty_ifdmtapa,

                           pkg_detb_rtl_teller_rec IN OUT detbs_rtl_teller%ROWTYPE,
                           p_err_code              IN OUT VARCHAR2,
                           p_err_params            IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    l_cust_ac           sttm_cust_account%ROWTYPE;
    l_arc_maint         iftms_arc_maint%ROWTYPE;
    l_cust              sttm_customer%ROWTYPE;
    l_prod              cstm_product%ROWTYPE;
    l_ib_flag           VARCHAR2(1) DEFAULT 'Y';
    l_txn_amt           iftbs_rft_master.txn_amt%TYPE;
    l_txn_amt1          iftbs_rft_master.txn_amt%TYPE;
    l_rate              NUMBER;
    l_rate_code         cstm_product.rate_code_preferred%Type;
    l_rate_code1        cstm_product.rate_code_preferred%Type;
    L_STTM_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;

  BEGIN
    dbg('INSIDE FN_MTA_TXN_SAVE');

    --Enrich once again
    IF NOT fn_enrich_product(p_ifdmtapa, p_err_code, p_err_params) THEN
      dbg('Failed in Fn_Enrich_Product');
      RETURN FALSE;
    END IF;

    --Get Account details
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = p_ifdmtapa.v_iftb_mta_master.rem_acc;

    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
        DBG('FAILED IN GETTING ACCOUNT DETAILS');
    END;

    /*IF p_ifdmtapa.v_iftb_mta_master.TXN_CCY <> L_STTM_CUST_ACCOUNT.CCY THEN

      dbg('Transaction Currency must be same as Account Currency');
      p_err_code := 'IF-RFT-005';

      pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

      RETURN FALSE;
    END IF;*/

    /* IF p_ifdmtapa.v_iftb_mta_master.TXN_CCY = 'USD' AND
       p_ifdmtapa.v_iftb_mta_master.TXN_AMT > 50000 THEN

      dbg('Transaction Amount Can not be greater than 50K USD');

      p_err_code := 'IF-RFT-012';

      pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

      RETURN FALSE;

    END IF;

    IF p_ifdmtapa.v_iftb_mta_master.TXN_CCY = 'KHR' AND
       p_ifdmtapa.v_iftb_mta_master.TXN_AMT > 200000000 THEN

      dbg('Transaction Amount Can not be greater than 200 Million KHR');

      p_err_code := 'IF-RFT-013';

      pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

      RETURN FALSE;

    END IF;*/

    DBG('PKG_ARC_ROW.COD_CHG_TYPE2 1=' ||
        DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE2);

    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdmtapa.v_iftb_mta_master.product_code;

    SELECT x.*
      INTO l_cust_ac
      FROM sttm_cust_account x
     WHERE x.cust_ac_no = p_ifdmtapa.v_iftb_mta_master.rem_acc;

    SELECT x.*
      INTO l_cust
      FROM sttm_customer x
     WHERE x.customer_no = l_cust_ac.cust_no;

    cspkss_arc.pr_get_arc_row(p_ifdmtapa.v_iftb_mta_master.branch_code,
                              p_ifdmtapa.v_iftb_mta_master.product_code,
                              'P',
                              '*.*', -- trans_type
                              p_ifdmtapa.v_iftb_mta_master.txn_ccy,
                              l_ib_flag,
                              l_arc_maint,
                              p_err_code,
                              p_err_params,
                              p_ifdmtapa.v_iftb_mta_master.rem_acc,
                              p_ifdmtapa.v_iftb_mta_master.branch_code);

    DBG('PKG_ARC_ROW.COD_CHG_TYPE2 1=' ||
        DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE2);

    IF p_err_code IS NOT NULL THEN
      dbg('CSPKSS_ARC.PR_GET_ARC_ROW returned false');
      RETURN FALSE;
    END IF;

    IF NOT
        cspkss_arc.fn_charge_pickup(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                    p_ifdmtapa.v_iftb_mta_master.product_code,
                                    'P',
                                    p_ifdmtapa.v_iftb_mta_master.product_code,
                                    p_ifdmtapa.v_iftb_mta_master.txn_ccy,
                                    l_cust_ac.cust_no,
                                    p_ifdmtapa.v_iftb_mta_master.txn_ccy,
                                    p_ifdmtapa.v_iftb_mta_master.txn_amt,
                                    l_prod.rate_type_preferred,
                                    l_prod.rate_code_preferred,
                                    NULL,
                                    l_cust_ac.cust_no,
                                    l_ib_flag,
                                    depks_rtl_teller.pkg_arc_row,
                                    p_err_code,
                                    p_err_params,
                                    p_ifdmtapa.v_iftb_mta_master.rem_acc,
                                    p_ifdmtapa.v_iftb_mta_master.branch_code) THEN
      dbg('CHARGE PICKUP failed');
      RETURN FALSE;
    END IF;

    DBG('PKG_ARC_ROW.COD_CHG_TYPE2 after charge pickup=' ||
        DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE2);

    pkg_detb_rtl_teller_rec.xref         := p_ifdmtapa.v_iftb_mta_master.trn_ref_no;
    pkg_detb_rtl_teller_rec.product_code := p_ifdmtapa.v_iftb_mta_master.product_code;
    pkg_detb_rtl_teller_rec.branch_code  := p_ifdmtapa.v_iftb_mta_master.branch_code;
    pkg_detb_rtl_teller_rec.trn_ref_no   := p_ifdmtapa.v_iftb_mta_master.trn_ref_no;

    pkg_detb_rtl_teller_rec.txn_acc := p_ifdmtapa.v_iftb_mta_master.rem_acc;
    pkg_detb_rtl_teller_rec.txn_ccy := l_cust_ac.ccy;
    --pkg_detb_rtl_teller_rec.txn_branch := p_ifdmtapa.v_iftb_mta_master.branch_code;
    pkg_detb_rtl_teller_rec.txn_branch := l_cust_ac.branch_code;

    pkg_detb_rtl_teller_rec.ofs_acc    := l_arc_maint.cod_offset_acc;
    pkg_detb_rtl_teller_rec.ofs_ccy    := p_ifdmtapa.v_iftb_mta_master.txn_ccy;
    pkg_detb_rtl_teller_rec.ofs_amount := p_ifdmtapa.v_iftb_mta_master.txn_amt;
    /* pkg_detb_rtl_teller_rec.ofs_branch := REPLACE(l_arc_maint.cod_offset_brn,
                                                    '*.*',
                                                    p_ifdmtapa.v_iftb_mta_master.branch_code);
    */
    --Get Nostro Account Branch for the offset leg
    BEGIN
      SELECT BRANCH_CODE
        INTO pkg_detb_rtl_teller_rec.ofs_branch
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = pkg_detb_rtl_teller_rec.ofs_acc;
    EXCEPTION
      WHEN OTHERS THEN
        pkg_detb_rtl_teller_rec.ofs_branch := '991';
    END;

    -- Begin ACCOUNTING ENTRIES Display and fix for Wrong Exch calculation
    IF p_ifdmtapa.v_iftb_mta_master.txn_ccy <> l_cust_ac.ccy THEN
      l_rate     := NULL;
      l_txn_amt1 := p_ifdmtapa.v_iftb_mta_master.txn_amt;

      If l_prod.rate_code_preferred = 'B' --and p_ifdmtapa.v_iftb_mta_master.transfer_mode in ('F')
       Then
        l_rate_code := Null;
        If (p_ifdmtapa.v_iftb_mta_master.txn_ccy = global.lcy and
           l_cust_ac.ccy != global.lcy) Or
           (p_ifdmtapa.v_iftb_mta_master.txn_ccy != global.lcy and
           l_cust_ac.ccy <> global.lcy and
           p_ifdmtapa.v_iftb_mta_master.txn_ccy <> l_cust_ac.ccy) Then
          l_rate_code := 'B';
        Elsif p_ifdmtapa.v_iftb_mta_master.txn_ccy != global.lcy and
              l_cust_ac.ccy = global.lcy --and p_ifdmtapa.v_iftb_mta_master.transfer_mode = 'L'
         Then
          l_rate_code := 'S';
        Else
          l_rate_code := l_prod.rate_code_preferred;
        End If;
      Else
        l_rate_code := l_prod.rate_code_preferred;
      End If;

      dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
          l_rate_code1);
      If l_cust_ac.ccy <> global.lcy Then
        begin
          select decode(l_rate_code,
                        'B',
                        'S',
                        'S',
                        'B',
                        'M',
                        'M',
                        l_rate_code)
            Into l_rate_code1
            from dual;
        exception
          when others then
            dbg('Exception found l_rate_code-> ' || l_rate_code);
        end;
      End If;
      dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
          l_rate_code1);

      IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdmtapa.v_iftb_mta_master.txn_ccy,
                                    l_cust_ac.ccy,
                                    l_txn_amt1,
                                    p_ifdmtapa.v_iftb_mta_master.exch_rate,
                                    'Y',
                                    l_txn_amt,
                                    p_err_params) THEN
        RETURN FALSE;
      END IF;
    END IF;
    dbg('l_txn_amt1->' || l_txn_amt1);
    dbg('l_txn_amt1->' || l_txn_amt);
    pkg_detb_rtl_teller_rec.txn_amount := l_txn_amt;
    -- END

    pkg_detb_rtl_teller_rec.txn_trn_code     := l_arc_maint.cod_main_txn_code;
    pkg_detb_rtl_teller_rec.ofs_trn_code     := l_arc_maint.cod_offset_txn_code;
    pkg_detb_rtl_teller_rec.exch_rate        := p_ifdmtapa.v_iftb_mta_master.exch_rate;
    pkg_detb_rtl_teller_rec.trn_dt           := p_ifdmtapa.v_iftb_mta_master.transfer_date;
    pkg_detb_rtl_teller_rec.value_dt         := p_ifdmtapa.v_iftb_mta_master.transfer_date;
    pkg_detb_rtl_teller_rec.rel_customer     := l_cust_ac.cust_no;
    pkg_detb_rtl_teller_rec.benef_name       := l_cust.customer_name1;
    pkg_detb_rtl_teller_rec.benef_addr1      := l_cust.address_line1;
    pkg_detb_rtl_teller_rec.benef_addr2      := l_cust.address_line2;
    pkg_detb_rtl_teller_rec.benef_addr3      := l_cust.address_line3;
    pkg_detb_rtl_teller_rec.benef_addr4      := l_cust.address_line4;
    pkg_detb_rtl_teller_rec.liqn_dt          := p_ifdmtapa.v_iftb_mta_master.transfer_date;
    pkg_detb_rtl_teller_rec.record_stat      := 'A';
    pkg_detb_rtl_teller_rec.auth_stat        := 'U';
    pkg_detb_rtl_teller_rec.maker_id         := GLOBAL.USER_ID; --p_ifdmtapa.v_iftb_mta_master.maker_id;
    pkg_detb_rtl_teller_rec.maker_dt_stamp   := p_ifdmtapa.v_iftb_mta_master.maker_dt_stamp;
    pkg_detb_rtl_teller_rec.checker_id       := p_ifdmtapa.v_iftb_mta_master.checker_id;
    pkg_detb_rtl_teller_rec.checker_dt_stamp := p_ifdmtapa.v_iftb_mta_master.checker_dt_stamp;
    pkg_detb_rtl_teller_rec.mod_no           := p_ifdmtapa.v_iftb_mta_master.mod_no;
    pkg_detb_rtl_teller_rec.scode            := 'FLEXCUBE';
    pkg_detb_rtl_teller_rec.dr_acc           := l_arc_maint.dr_acc;
    pkg_detb_rtl_teller_rec.module           := 'RT';
    pkg_detb_rtl_teller_rec.esn              := 1;
    pkg_detb_rtl_teller_rec.event_code       := 'INIT';
    pkg_detb_rtl_teller_rec.track_receivable := 'N';
    pkg_detb_rtl_teller_rec.time_received    := SYSDATE;

    DBG('p_ifdmtapa.v_iftb_mta_charge.count=' ||
        p_ifdmtapa.v_iftb_mta_charge.count);

    -- 1
    FOR k IN 1 .. p_ifdmtapa.v_iftb_mta_charge.count LOOP
      IF k = 1 THEN
        dbg('CHG AMT' || p_ifdmtapa.v_iftb_mta_charge(k).chg1_amt);
        pkg_detb_rtl_teller_rec.charge_account := p_ifdmtapa.v_iftb_mta_master.rem_acc;

        pkg_detb_rtl_teller_rec.chg_gl           := l_arc_maint.cod_chg_gl;
        pkg_detb_rtl_teller_rec.chg_ccy          := l_arc_maint.cod_chg_ccy;
        pkg_detb_rtl_teller_rec.chg_amt          := p_ifdmtapa.v_iftb_mta_charge(k)
                                                    .chg1_amt;
        depks_rtl_teller.pkg_arc_row.cod_chg_amt := p_ifdmtapa.v_iftb_mta_charge(k)
                                                    .chg1_amt;

        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt);
        depks_rtl_teller.pkg_arc_row.cod_chg_type := l_arc_maint.cod_chg_type;

        IF l_arc_maint.cod_chg_ccy <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                     l_arc_maint.cod_chg_ccy,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdmtapa.v_iftb_mta_charge(k).chg1_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;

        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy       := p_ifdmtapa.v_iftb_mta_charge(k)
                                                      .chg1_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate := 1;
        END IF;

        DBG('pkg_detb_rtl_teller_rec.chg_in_acy=' ||
            pkg_detb_rtl_teller_rec.chg_in_acy);
        DBG('pkg_detb_rtl_teller_rec.chg_ccy_acy_rate=' ||
            pkg_detb_rtl_teller_rec.chg_ccy_acy_rate);

        pkg_detb_rtl_teller_rec.chg_in_lcy   := p_ifdmtapa.v_iftb_mta_charge(k)
                                                .lcy_chg1;
        pkg_detb_rtl_teller_rec.acy_lcy_rate := p_ifdmtapa.v_iftb_mta_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind  := l_arc_maint.cod_chg_netting;
        pkg_detb_rtl_teller_rec.txn_code     := l_arc_maint.cod_chg_txn_code;
        pkg_detb_rtl_teller_rec.mis_head_1   := l_arc_maint.cod_mis_head;
        pkg_detb_rtl_teller_rec.chg_desc     := l_arc_maint.cod_chg_desc;
        pkg_detb_rtl_teller_rec.chg_type     := l_arc_maint.cod_chg_type;
        pkg_detb_rtl_teller_rec.waiver       := p_ifdmtapa.v_iftb_mta_charge(k)
                                                .chg1_waiver;
        pkg_detb_rtl_teller_rec.their_chgs   := l_arc_maint.cod_their_chgs;
      END IF;
      -- 2
      IF k = 2 THEN
        pkg_detb_rtl_teller_rec.chg_gl_1  := l_arc_maint.cod_chg_gl1;
        pkg_detb_rtl_teller_rec.chg_ccy_1 := l_arc_maint.cod_chg_ccy1;
        pkg_detb_rtl_teller_rec.chg_amt_1 := p_ifdmtapa.v_iftb_mta_charge(k)
                                             .chg2_amt;

        depks_rtl_teller.pkg_arc_row.cod_chg_amt1 := p_ifdmtapa.v_iftb_mta_charge(k)
                                                     .chg2_amt;

        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT1' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt1);
        depks_rtl_teller.pkg_arc_row.cod_chg_type1 := l_arc_maint.cod_chg_type1;

        IF l_arc_maint.cod_chg_ccy1 <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdmtapa.v_iftb_mta_master.branch_code,
                                     l_arc_maint.cod_chg_ccy1,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdmtapa.v_iftb_mta_charge(k).chg2_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy_1,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_1       := p_ifdmtapa.v_iftb_mta_charge(k)
                                                        .chg2_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1 := 1;
        END IF;

        pkg_detb_rtl_teller_rec.chg_in_lcy_1   := p_ifdmtapa.v_iftb_mta_charge(k)
                                                  .lcy_chg2;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_1 := p_ifdmtapa.v_iftb_mta_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_1  := l_arc_maint.cod_chg_netting1;
        pkg_detb_rtl_teller_rec.txn_code_1     := l_arc_maint.cod_chg_txn_code1;
        pkg_detb_rtl_teller_rec.mis_head_2     := l_arc_maint.cod_mis_head1;
        pkg_detb_rtl_teller_rec.chg_desc1      := l_arc_maint.cod_chg_desc1;
        pkg_detb_rtl_teller_rec.chg_type1      := l_arc_maint.cod_chg_type1;
        pkg_detb_rtl_teller_rec.waiver1        := p_ifdmtapa.v_iftb_mta_charge(k)
                                                  .chg2_waiver;
        pkg_detb_rtl_teller_rec.their_chgs1    := l_arc_maint.cod_their_chgs1;
      END IF;

    END LOOP;

    dbg('Calling depks_rtl_teller.fn_save');

    DBG('PKG_ARC_ROW.COD_CHG_TYPE2 1=' ||
        DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE2);

    IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                    p_err_code,
                                    p_err_params) THEN
      dbg('Failed in Fn_Save');
      RETURN FALSE;
    END IF;
    dbg('Calling depks_rtl_teller.pr_messaging');
    --depks_rtl_teller.pr_messaging;

    dbg('Returning Success From FN_RFT_TXN_SAVE..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdrftpm_Custom.FN_RFT_TXN_SAVE ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END FN_MTA_TXN_SAVE;

  FUNCTION FN_MTA_HTTP_CALL(p_mta_call in varchar2,
                            p_out_msg  VARCHAR2,
                            p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS

    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255); -- := 'http://10.80.80.11:8282/prnc-app/nbc/rft-out/rcpt-acct-inq';
    buffer          varchar2(32767);
    buffer1         clob;

    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;

  BEGIN
    dbg('START OF FN_MTA_HTTP_CALL');

    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_RFT_TIMEOUT'));

    IF p_mta_call = 'C' THEN

      L_URL := FN_GET_PARAM_VAL('PGW_MTA_PAYCONFIRM_URL');

    END IF;

    DBG('l_url-->' || L_URL);

    --p_out_msg := replace(p_out_msg,chr(49824),' ');

    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');

    utl_http.set_authentication(l_http_request,
                                FN_GET_PARAM_VAL('PGW_MTA_AUTH_UID'),
                                FN_GET_PARAM_VAL('PGW_MTA_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));

    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');

    utl_http.set_transfer_timeout(300);

    utl_http.write_text(l_http_request, p_out_msg);

    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));

    l_http_response := utl_http.get_response(l_http_request);

    dbg('Response> status_code: "' || l_http_response.status_code || '"');

    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;

    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;

    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;

      p_in_resp := buffer1;

      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);

    END IF;

    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;

    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;

    --    dbms_lob.freetemporary(buffer1); --buffer2 may be check

    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('error line number=' || dbms_utility.format_error_backtrace);

      RETURN FALSE;
  END FN_MTA_HTTP_CALL;

  FUNCTION fn_msg_upload(p_ifdmtapa   IN OUT IFPKS_IFDMTAPA_MAIN.ty_ifdmtapa,
                         P_REQ_TYPE   IN VARCHAR2,
                         P_REQ_MSG    IN OUT CLOB,
                         P_ADDL_INFO  IN VARCHAR2,
                         p_err_code   IN OUT VARCHAR2,
                         p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS

    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;

    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);

    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);

    L_REFERENCE_NO IFTB_MTA_WS_LOG.REFERENCE_NO%TYPE;
    L_TXN_ID       IFTB_MTA_WS_LOG.TXN_ID%TYPE;
    L_COLL_TRAN_ID IFTB_MTA_WS_LOG.COLLTRANID%TYPE;

    PERRCODES VARCHAR2(32764);
    PPARAMS   VARCHAR2(32764);

  BEGIN

    dbg('Inside fn_msg_upload');

    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);

    --Log Webservice Call
    PR_INSERT_MTA_WS_LOG(L_GEN_SEQ_NO,
                         p_ifdmtapa.v_iftb_mta_master.trn_ref_no,
                         SYSDATE,
                         P_REQ_TYPE,
                         P_REQ_MSG,
                         P_ADDL_INFO);

    IF NOT FN_MTA_HTTP_CALL(P_REQ_TYPE, P_REQ_MSG, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;

    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);

    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);

    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);

    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);

    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;

    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;

    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);

    IF L_STATUS_CODE <> '000' THEN

      dbg('Error Received from MTA==' || OVPKS.GL_TBLERROR.COUNT);

      p_err_code := 'IF-MTA-000';

      --PR_LOG_ERROR('IFDMTAPA', 'FLEXCUBE', p_err_code, '@'||L_STATUS_MSG);

      OVPKSS.PR_APPENDTBL(p_err_code, L_STATUS_MSG || '~');

      --OVPKSS.PR_APPENDTBL(P_ERR_CODE, L_STATUS_MSG);

      RETURN FALSE;

    END IF;

    --Handle All Errro Codes ad return false

    IF P_REQ_TYPE = 'C' THEN

      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN

        L_REFERENCE_NO := P_DOCUMENT_XML.EXTRACT('/root/data/referenceNo/text()')
                          .GETSTRINGVAL;

        DBG('L_REFERENCE_NO =' || L_REFERENCE_NO);

        P_IFDMTAPA.v_iftb_mta_master.REFERENCE_NO := L_REFERENCE_NO;

        L_TXN_ID := P_DOCUMENT_XML.EXTRACT('/root/data/transactionID/text()')
                    .GETSTRINGVAL;

        DBG('L_TXN_ID =' || L_TXN_ID);

        P_IFDMTAPA.v_iftb_mta_master.TRANSACTION_ID := L_TXN_ID;

        L_COLL_TRAN_ID := P_DOCUMENT_XML.EXTRACT('/root/data/collTranId/text()')
                          .GETSTRINGVAL;

        DBG('L_COLL_TRAN_ID =' || L_COLL_TRAN_ID);

        P_IFDMTAPA.v_iftb_mta_master.COLL_TRAN_ID := L_COLL_TRAN_ID;

        PR_UPDATE_MTA_WS_LOG(p_ifdmtapa.v_iftb_mta_master.trn_ref_no,
                             L_GEN_SEQ_NO,
                             L_REFERENCE_NO,
                             L_TXN_ID,
                             L_COLL_TRAN_ID,
                             'S',
                             L_IN_RESP);

      ELSE

        PR_UPDATE_MTA_WS_LOG(p_ifdmtapa.v_iftb_mta_master.trn_ref_no,
                             L_GEN_SEQ_NO,
                             L_REFERENCE_NO,
                             L_TXN_ID,
                             L_COLL_TRAN_ID,
                             'F',
                             L_IN_RESP);

        RETURN FALSE;

      END IF;
    END IF;

    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      dbg('error line number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END fn_msg_upload;

  FUNCTION FN_MTA_REVERSE(p_ifdmtapa IN ifpks_ifdmtapa_main.ty_ifdmtapa)
    RETURN BOOLEAN IS

    P_ERR_CODE         ERTB_MSGS.ERR_CODE%TYPE;
    P_ERR_PARAM        ERTB_MSGS.MESSAGE%TYPE;
    L_FORMATTED_MSG    CLOB;
    L_IN_RESP          CLOB;
    L_COSMETIC_RES_MSG CLOB;
    L_GEN_SEQ_NO       VARCHAR2(100);
    L_COUNT            NUMBER;

    P_DOCUMENT_XML  XMLTYPE;
    L_RESP_IN_XML   CLOB;
    L_RESPONSE_CODE IFTBS_RFT_MASTER.TXN_STATUS%TYPE;
    L_RESPONSE_MSG  IFTBS_RFT_MASTER.TXN_REMARKS%TYPE;

  BEGIN

    DEBUG.PR_DEBUG('IF', 'START OF FN_RFT_REVERSE');

    --Go for Cancellation API
    --Get Cancel Message
    L_FORMATTED_MSG := null; --FN_RETURN_FORMATTED_CANCEL_MSG(p_ifdmtapa); --REPLACE(L_FORMATTED_MSG, '$L_MSG_ID', L_MSG_ID);

    DBG('AFTER REPLACEMENT OF CANCEL MSG=' || L_FORMATTED_MSG);

    --Log Cancel Request of RFT

    DBG('LOGGING CANCEL REQUEST OF RFT');

    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;

    /*PR_INSERT_RFT_CANCEL_WS_LOG(L_GEN_SEQ_NO,
    p_ifdmtapa.v_iftb_mta_master.trn_ref_no,
    SYSDATE,
    'Cancel',
    L_FORMATTED_MSG,
    'Cancel of RFT');*/

    L_FORMATTED_MSG := replace(L_FORMATTED_MSG, chr(49824), ' '); --replace hard space with white space

    IF NOT IFPKS_IFDMTAPA_CUSTOM.FN_MTA_HTTP_CALL('C',
                                                  L_FORMATTED_MSG,
                                                  L_IN_RESP) THEN

      DBG('FAILED IN CALLING THE CANCELLATION API');

      RETURN FALSE;

    ELSE

      DBG('RESPONSE OF CANCELLATION IN JSON IS ' || L_IN_RESP);

      --Get JSON in XML
      L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
      DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);

      L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
      DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);

      L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;;', '>');
      DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);

      DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);

      P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);

      L_RESPONSE_CODE := P_DOCUMENT_XML.EXTRACT('/root/respCd/text()')
                         .GETSTRINGVAL;

      L_RESPONSE_MSG := P_DOCUMENT_XML.EXTRACT('/root/respMsg/text()')
                        .GETSTRINGVAL;

      DBG('L_RESPONSE_CODE =' || L_RESPONSE_CODE);
      DBG('L_RESPONSE_MSG =' || L_RESPONSE_MSG);

      IF L_RESPONSE_CODE = 'ERROR_500' THEN

        dbg('RFT Client Module is Down');

        p_err_code := 'IF-RFT-017';

        pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);

        RETURN FALSE;

      END IF;

      IF L_RESPONSE_CODE = 'SUCCESS' THEN

        DBG('SUCCESS IN CANCELLING THE ORIGINAL RFT OUTGOING TXN');

        SAVEPOINT REVERSE_POINT;

        IF p_ifdmtapa.v_iftb_mta_master.TRN_REF_NO IS NOT NULL THEN

          IF NOT FN_REVERSE(p_ifdmtapa.v_iftb_mta_master.trn_ref_no,
                            P_ERR_CODE,
                            P_ERR_PARAM) THEN

            DBG('FAILED IN REVERSING THE MTA OUTGOING TRANSACTION');
            DBG('P_ERR_CODE=' || P_ERR_CODE);
            DBG('P_ERR_PARAM=' || P_ERR_PARAM);

            ROLLBACK TO REVERSE_POINT;

            RETURN FALSE;

          ELSE

            DBG('SUCCESS IN REVERSING THE MTA OUTGOING TRANSACTION');

            IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(GLOBAL.CURRENT_BRANCH,
                                                        p_ifdmtapa.v_iftb_mta_master.trn_ref_no,
                                                        GLOBAL.USER_ID,
                                                        GLOBAL.LCY,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAM) THEN
              DBG('AUTH RETURNED FALSE ' || P_ERR_CODE);

              ROLLBACK TO REVERSE_POINT;

              RETURN FALSE;

            ELSE

              RETURN TRUE;

            END IF;

          END IF;
        END IF;

      ELSE

        DBG('FAILED IN CANCELLING THE ORIGINAL RFT OUTGOING TXN');
        RETURN FALSE;

      END IF;

    END IF;

    DBG('END OF FN_MTA_REVERSE');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_MTA_REVERSE');
      DBG('ERROR CODE IN FN_MTA_REVERSE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_MTA_REVERSE=' || SQLERRM);
      RETURN FALSE;
  END FN_MTA_REVERSE;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdmtapa         IN OUT ifpks_ifdmtapa_Main.Ty_ifdmtapa,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
    l_detb_rtl_teller_rec detb_rtl_teller%ROWTYPE;

    L_FORMATTED_MSG CLOB;

    L_MSG_TYPE  VARCHAR2(100);
    L_ADDL_INFO VARCHAR2(100);
    L_COUNT     NUMBER;

    L_PAYOUT_GRP_CODE VARCHAR2(105);
    L_PAYOUT_MODE     VARCHAR2(105);
    L_COUNTRY         VARCHAR2(105);
    L_PAYMENT_MODE    VARCHAR2(105);

    L_STTB_CORAL_MTA_WS_LOG STTB_CORAL_MTA_WS_LOG%ROWTYPE;
    
    --AML New Payment Flow Starts
  
    L_REF          VARCHAR2(16);
    L_SEQ          NUMBER;
    L_RESPONSE     CLOB;
    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_IN_RESP      CLOB;
    P_HIT_STATUS   VARCHAR2(100);
    P_SCAN_ID      VARCHAR2(100);
  
    L_CUSTOMER STTM_CUSTOMER%ROWTYPE;
  
    L_SENDER_NAME    STTB_CORAL_MTA_WS_LOG.SENDER_NAME%TYPE;
    L_SENDER_COUNTRY STTB_CORAL_MTA_WS_LOG.SENDER_HIGH_CNT%TYPE;
    L_BEN_NAME       STTB_CORAL_MTA_WS_LOG.BEN_NAME%TYPE;
    L_BEN_COUNTRY    STTB_CORAL_MTA_WS_LOG.BEN_HIGH_CNT%TYPE;
    --AML New Payment Flow Ends

  BEGIN

    Dbg('In Fn_Pre_Check_Mandatory==' || p_Action_Code);

    IF p_action_code = 'PICKUP' THEN
      IF NOT fn_enrich_product(p_ifdmtapa, p_err_code, p_err_params) THEN
        dbg('Failed in Fn_Enrich_Product');
        RETURN FALSE;
      END IF;

    END IF;

    --Save Transaction
    IF p_action_code in (cspks_req_global.p_new, cspks_req_global.p_copy) THEN

      /*  IF NOT FN_AML_VALIDATION(p_ifdmtapa) THEN
        RETURN FALSE;
      END IF;*/
      
      --AML New Payment Flow Starts
    
      BEGIN
      
        SELECT *
          INTO L_CUSTOMER
          FROM STTM_CUSTOMER
         WHERE CUSTOMER_NO IN
               (SELECT CUST_NO
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = p_ifdmtapa.v_iftb_mta_master.Rem_acc);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CUSTOMER := NULL;
      END;
    
      DBG('p_ifdmtapa.v_iftb_mta_master.BEN_NAME=' ||
          p_ifdmtapa.v_iftb_mta_master.BEN_NAME);
      DBG('p_ifdmtapa.v_iftb_mta_master.BEN_COUNTRY=' ||
          p_ifdmtapa.v_iftb_mta_master.BEN_COUNTRY);
    
      --check the count
      BEGIN
      
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_CORAL_MTA_WS_LOG A
         WHERE A.SCAN_ID IS NOT NULL
           AND A.REQ_MSG IS NOT NULL
           AND A.RES_MSG IS NOT NULL
           AND A.BEN_NAME = p_ifdmtapa.v_iftb_mta_master.BEN_NAME
           AND A.BEN_HIGH_CNT = p_ifdmtapa.v_iftb_mta_master.BEN_COUNTRY
           AND A.FC_REF_NO = p_ifdmtapa.v_iftb_mta_master.TRN_REF_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          L_COUNT := 0;
        
      END;
    
      DBG('L_COUNT=' || L_COUNT);
    
      IF L_COUNT = 0 THEN
      
       
      
        --call api B
      
        IF NOT IFPKS_SANCTION_UTILS.FN_AML_PAYMENT_CALL_B(GLOBAL.user_id,
                                                          GLOBAL.current_branch,
                                                          'OTC',
                                                          
                                                          L_REF,
                                                          p_ifdmtapa.v_iftb_mta_master.BEN_NAME,
                                                          p_ifdmtapa.v_iftb_mta_master.BEN_COUNTRY, --L_HIGH_BEN_CNT,
                                                          p_ifdmtapa.v_iftb_mta_master.BEN_BIC_NAME,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          TRIM(p_ifdmtapa.v_iftb_mta_master.BEN_ADDRESS),
                                                          p_ifdmtapa.v_iftb_mta_master.REMIT_REASON_CODE,
                                                          p_ifdmtapa.v_iftb_mta_master.BEN_REMARKS,
                                                          p_ifdmtapa.v_iftb_mta_master.txn_amt, --100,
                                                          
                                                          p_ifdmtapa.v_iftb_mta_master.txn_ccy,
                                                          p_ifdmtapa.v_iftb_mta_master.BEN_ACC,--BEN_BIC_NAME,
                                                          NULL,
                                                          NULL,
                                                          'MTA',
                                                          'MTAA',
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          L_CUSTOMER.Customer_No,
                                                          NULL, --L_SENDER_NAME
                                                          NULL, --L_SENDER_COUNTRY
                                                          p_ifdmtapa.v_iftb_mta_master.BEN_NAME, --L_BEN_NAME
                                                          p_ifdmtapa.v_iftb_mta_master.BEN_COUNTRY, --L_BEN_COUNTRY
                                                          p_ifdmtapa.v_iftb_mta_master.TRN_REF_NO,
                                                          P_SCAN_ID,
                                                          P_HIT_STATUS,
                                                          L_IN_RESP) THEN
          
        PR_LOG_ERROR('IFDMTAPA',
                         'FLEXCUBE',
                         'IF-AML-001',
                         NULL);
                         
          RETURN FALSE;
        
        ELSE
        
        
          DBG('P_HIT_STATUS OF API-B =' || P_HIT_STATUS);
        
          DBG('P_SCAN_ID OF API-B=' || P_SCAN_ID);
        
          IF P_HIT_STATUS = 'Y' THEN
          
            PR_LOG_ERROR('IFDOFAST',
                         'FLEXCUBE',
                         'IF-RIA-030',
                         P_SCAN_ID /*|| CASE P_WHO_HIT WHEN 'S' THEN
                                                                                                                                 'For Sender' WHEN 'R' THEN 'For Beneficiary' WHEN 'B' THEN
                                                                                                                                 'For Both Sender and Beneficiary' END*/);
          
          END IF;
        
        END IF;
      
      END IF;  
      --AML New Payment Flow Ends   

      IF NOT FN_MTA_TXN_SAVE(p_ifdmtapa,
                             l_detb_rtl_teller_rec,
                             p_err_code,
                             p_err_params) THEN
        dbg('Failed in FN_SAVE');
        RETURN FALSE;
      END IF;
    END IF;

    --Modify Transaction
    IF p_action_code = cspks_req_global.p_modify THEN
      dbg('Voila 2');

      IF NOT depks_rtl_teller.fn_delete(p_ifdmtapa.v_iftb_mta_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in modify fn_delete');
        RETURN FALSE;
      END IF;

      IF NOT FN_MTA_TXN_SAVE(p_ifdmtapa,
                             l_detb_rtl_teller_rec,
                             p_err_code,
                             p_err_params) THEN
        dbg('Failed in modify fn_save');
        RETURN FALSE;
      END IF;
    END IF;

    --Delete Transaction
    IF p_action_code = cspks_req_global.p_delete THEN
      IF NOT depks_rtl_teller.fn_delete(p_ifdmtapa.v_iftb_mta_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in FN_DELETE');
        RETURN FALSE;
      END IF;
    END IF;

    --Auth Transaction
    IF p_action_code = cspks_req_global.p_auth AND
       p_ifdmtapa.v_iftb_mta_master.MOD_NO = 2 THEN

      IF p_ifdmtapa.v_iftb_mta_master.BRANCH_CODE <> GLOBAL.CURRENT_BRANCH THEN

        DBG('Authorization can be done only in transaction branch');
        pr_log_error(p_function_id, p_source, 'IF-RFT-026', NULL);
        RETURN FALSE;

      END IF;

      /*IF NOT FN_MTA_REVERSE(p_ifdmtapa) THEN
        DBG('TRANSACTION HAS NOT BEEN REVERSED');
        RETURN FALSE;

      ELSE
        DBG('TRANSACTION HAS BEEN REVERSED');
        RETURN TRUE;

      END IF;*/

    ELSE
      IF p_action_code = cspks_req_global.p_auth THEN

        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM sttb_coral_mta_ws_log
           WHERE FC_REF_NO = p_ifdmtapa.v_iftb_mta_master.trn_ref_no
             AND ACTION = 'DOSCAN_AUTH'
             AND SCAN_ID IS NOT NULL;
        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;

        DBG('L_COUNT=' || L_COUNT);

        IF L_COUNT = 0 THEN
          IF NOT FN_AML_VALIDATION(p_ifdmtapa) THEN
            RETURN FALSE;
          END IF;
        END IF;

        --Get AML Status
        BEGIN
          SELECT *
            INTO L_STTB_CORAL_MTA_WS_LOG
            FROM STTB_CORAL_MTA_WS_LOG
           WHERE FC_REF_NO = p_ifdmtapa.v_iftb_mta_master.trn_ref_no
             AND UNIQUE_REFERENCE_NO =
                 (SELECT MAX(UNIQUE_REFERENCE_NO)
                    FROM STTB_CORAL_MTA_WS_LOG
                   WHERE FC_REF_NO = p_ifdmtapa.v_iftb_mta_master.trn_ref_no
                     AND REQ_TYPE = 'ONLINE_SCAN'
                     AND ACTION = 'DOSCAN_AUTH');
          --AND STATUS NOT IN ('PENDING');
        EXCEPTION
          WHEN OTHERS THEN
            L_STTB_CORAL_MTA_WS_LOG := NULL;
        END;

        DBG('L_STTB_CORAL_MTA_WS_LOG.CUSTOMER_NO=' ||
            L_STTB_CORAL_MTA_WS_LOG.CUSTOMER_NO);
        DBG('L_STTB_CORAL_MTA_WS_LOG.SCAN_ID=' ||
            L_STTB_CORAL_MTA_WS_LOG.SCAN_ID);

        IF NOT IFPKS_SANCTION_UTILS.FN_GET_AML_STATUS_MTA(L_STTB_CORAL_MTA_WS_LOG.SCAN_ID,
                                                          L_STTB_CORAL_MTA_WS_LOG.CUSTOMER_NO,
                                                          L_STTB_CORAL_MTA_WS_LOG.FC_REF_NO,
                                                          p_Err_Code,
                                                          p_Err_Params) THEN
          RETURN FALSE;
        END IF;

        DBG('p_ifdmtapa.v_iftb_mta_master.MAKER_ID=' ||
            p_ifdmtapa.v_iftb_mta_master.MAKER_ID);
        DBG('p_ifdmtapa.v_iftb_mta_master.CHECKER_ID=' ||
            p_ifdmtapa.v_iftb_mta_master.CHECKER_ID);
        DBG('GLOBAL.USER_ID' || GLOBAL.USER_ID);

        DBG('GLOBAL.CURRENT_BRANCH' || GLOBAL.CURRENT_BRANCH);

        IF p_ifdmtapa.v_iftb_mta_master.BRANCH_CODE <>
           GLOBAL.CURRENT_BRANCH THEN

          DBG('Authorization can be done only in transaction branch');
          pr_log_error(p_function_id, p_source, 'IF-RFT-026', NULL);
          RETURN FALSE;

        END IF;

        --Maker Can not authorize
        IF p_ifdmtapa.v_iftb_mta_master.MAKER_ID = GLOBAL.USER_ID THEN
          pr_log_error(p_function_id, p_source, 'CF-AUT-002', NULL);
          RETURN FALSE;
        END IF;

        DBG('P_IFDMTAPA.v_iftb_mta_master.ben_country=' ||
            P_IFDMTAPA.v_iftb_mta_master.ben_country);
        DBG('P_IFDMTAPA.v_iftb_mta_master.payment_mode=' ||
            P_IFDMTAPA.v_iftb_mta_master.payment_mode);
        --Get MTA Out Payment
        IF P_IFDMTAPA.v_iftb_mta_master.payment_mode = 'Account Credit' THEN
          BEGIN
            SELECT PAYOUT_GROUP_CODE, PAYMENT_MODE_CODE
              INTO L_PAYOUT_GRP_CODE, L_PAYOUT_MODE
              FROM STTB_MTA_STATIC_AGENT_DTLS
             WHERE UPPER(COUNTRY_CODE) =
                   P_IFDMTAPA.v_iftb_mta_master.ben_country
               AND PAYMENT_MODE = P_IFDMTAPA.v_iftb_mta_master.payment_mode;

          EXCEPTION
            WHEN OTHERS THEN
              L_PAYOUT_GRP_CODE := NULL;
              L_PAYOUT_MODE     := NULL;
          END;
        END IF;

        DBG('L_PAYOUT_GRP_CODE=' || L_PAYOUT_GRP_CODE);
        DBG('L_PAYOUT_MODE=' || L_PAYOUT_MODE);

        IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE = 'P2P' AND
           P_IFDMTAPA.v_iftb_mta_master.payment_mode = 'Cash Pickup' THEN

          DBG('INSIDE P2P CAHSPICKUP');

          L_FORMATTED_MSG := FN_GET_FMT_MTA_PICKUP_PAYMENT(P_IFDMTAPA);

        END IF;

        --P2P
        IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE = 'P2P' AND
           P_IFDMTAPA.v_iftb_mta_master.payment_mode = 'Account Credit' THEN

          DBG('INSIDE P2P');

          IF L_PAYOUT_GRP_CODE = 'UK01' THEN

            DBG('INSIDE P2P UK01');
            L_FORMATTED_MSG := FN_GET_FMT_MTA_PAYMENT_P2PUK(P_IFDMTAPA);

          ELSIF L_PAYOUT_GRP_CODE = 'AU01' THEN

            DBG('INSIDE P2P AU01');
            L_FORMATTED_MSG := FN_GET_FMT_MTA_PAYMENT_P2PAUS(P_IFDMTAPA);

          ELSIF L_PAYOUT_GRP_CODE = 'MU01' THEN

            DBG('INSIDE P2P MU01');
            L_FORMATTED_MSG := FN_GET_FMT_MTA_P2PEURO_PAYMENT(P_IFDMTAPA); --pls call appropriate format based on remit type

          ELSE

            DBG('INSIDE P2P GENERAL');
            L_FORMATTED_MSG := FN_GET_FMT_MTA_P2P_PAYMENT(P_IFDMTAPA);

          END IF;

        END IF;

        --P2B
        IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE = 'P2B' THEN

          IF L_PAYOUT_GRP_CODE = 'AU01' THEN

            DBG('INSIDE P2B AU01');
            L_FORMATTED_MSG := FN_GET_FMT_MTA_PAYMENT_P2BAUS(P_IFDMTAPA);

          ELSE

            DBG('INSIDE P2B GENERAL');
            L_FORMATTED_MSG := FN_GET_FMT_MTA_P2B_PAYMENT(P_IFDMTAPA);

          END IF;

        END IF;

        --B2B
        IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE = 'B2B' THEN

          IF L_PAYOUT_GRP_CODE = 'AU01' THEN

            DBG('INSIDE B2B AU01');
            L_FORMATTED_MSG := FN_GET_FMT_MTA_PAYMENT_B2BAUS(P_IFDMTAPA);

          ELSE

            DBG('INSIDE B2B GENERAL');
            L_FORMATTED_MSG := FN_GET_FMT_MTA_B2B_PAYMENT(P_IFDMTAPA);

          END IF;

        END IF;

        --B2P
        IF P_IFDMTAPA.v_iftb_mta_master.REMIT_TYPE = 'B2P' THEN

          DBG('INSIDE B2P');

          IF L_PAYOUT_GRP_CODE = 'AU01' THEN

            DBG('INSIDE B2P AU01');

            L_FORMATTED_MSG := FN_GET_FMT_MTA_PAYMENT_B2PAUS(P_IFDMTAPA);

          ELSE

            DBG('INSIDE B2P GENERAL');

            L_FORMATTED_MSG := FN_GET_FMT_MTA_B2P_PAYMENT(P_IFDMTAPA);

          END IF;

        END IF;

        DBG('AFTER REPLACEMENT OF MTA PAYMENT JSON=' || L_FORMATTED_MSG);

        DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

        L_MSG_TYPE  := 'C';
        L_ADDL_INFO := 'MTA Payment Call';

        DBG('CALLING MTA PAYMENT WEBSERVICE');

        L_FORMATTED_MSG := replace(L_FORMATTED_MSG, chr(49824), ' '); --replace hard space with white space

        IF NOT FN_MSG_UPLOAD(p_ifdmtapa,
                             L_MSG_TYPE,
                             L_FORMATTED_MSG,
                             L_ADDL_INFO,
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN

          DBG('FAILED IN MTA PAYMENT CALL');

          RETURN FALSE;

        ELSE

          DBG('SUCCESS IN MTA PAYMENT CALL');

          --Check if already authorised

          BEGIN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM IFTB_MTA_MASTER
             WHERE TRN_REF_NO = p_ifdmtapa.v_iftb_mta_master.trn_ref_no
                  -- AND AUTH_STAT = 'A'
               AND ONCE_AUTH = 'Y';

          EXCEPTION
            WHEN OTHERS THEN
              L_COUNT := 0;
          END;

          IF L_COUNT > 0 THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'ST-VALS-007',
                         'Transaction No:' ||
                         p_ifdmtapa.v_iftb_mta_master.trn_ref_no);
            RETURN FALSE;
          END IF;

          --AUTH TRANSACTION
          DBG('CALLING DEPKS_RTL_TELLER.FN_RTL_TELLER_AUTH');
          IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(GLOBAL.current_branch,
                                                      p_ifdmtapa.v_iftb_mta_master.trn_ref_no,
                                                      GLOBAL.USER_ID,
                                                      GLOBAL.LCY,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
            DBG('AUTH RETRUNED FALSE' || P_ERR_CODE);
            PR_LOG_ERROR('IFDMTAPA', 'FLEXCUBE', p_err_code, p_err_params);
            RETURN FALSE;
          ELSE
            --generate SVXP File
            dbg('done with authorization');
          END IF;

        END IF;
      END IF;

      DBG('fn_msg_upload successful');

    END IF;

    --Reverse Transaction
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REVERSE THEN

      --Check if cancellation today or not

      IF --TO_CHAR(SYSDATE, 'YYYYMMDD')
       TO_CHAR(p_ifdmtapa.v_iftb_mta_master.transfer_date, 'YYYYMMDD') <>
       TO_CHAR(SYSDATE, 'YYYYMMDD') THEN

        dbg('RFT Payment Can Be Cancelled only on the day it is created');
        pr_log_error(p_function_id, p_source, 'IF-RFT-016', NULL);

      END IF;

      p_ifdmtapa.v_iftb_mta_master.MAKER_ID       := GLOBAL.user_id;
      p_ifdmtapa.v_iftb_mta_master.MAKER_DT_STAMP := FN_SYSDATE;

    END IF;

    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdmtapa_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdmtapa         IN ifpks_ifdmtapa_Main.ty_ifdmtapa,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
  BEGIN

    Dbg('In Fn_Post_Check_Mandatory..');

    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdmtapa_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdmtapa         IN ifpks_ifdmtapa_Main.ty_ifdmtapa,
                                       p_Prev_ifdmtapa    IN OUT ifpks_ifdmtapa_Main.ty_ifdmtapa,
                                       p_Wrk_ifdmtapa     IN OUT ifpks_ifdmtapa_Main.ty_ifdmtapa,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Default_And_Validate..');

    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdmtapa_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdmtapa         IN ifpks_ifdmtapa_Main.Ty_ifdmtapa,
                                        p_Prev_ifdmtapa    IN OUT ifpks_ifdmtapa_Main.Ty_ifdmtapa,
                                        p_Wrk_ifdmtapa     IN OUT ifpks_ifdmtapa_Main.Ty_ifdmtapa,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Default_And_Validate..');

    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdmtapa_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdmtapa         IN ifpks_ifdmtapa_Main.Ty_ifdmtapa,
                            p_Prev_ifdmtapa    IN ifpks_ifdmtapa_Main.Ty_ifdmtapa,
                            p_Wrk_ifdmtapa     IN OUT ifpks_ifdmtapa_Main.Ty_ifdmtapa,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Upload_Db..');

    IF p_Action_Code = CSPKS_REQ_GLOBAL.P_AUTH THEN

      /*  DBG('P_IFDMTAPA.v_iftb_mta_master.REFERENCE_NO=' ||
            P_IFDMTAPA.v_iftb_mta_master.REFERENCE_NO);
        DBG('P_IFDMTAPA.v_iftb_mta_master.TRANSACTION_ID=' ||
            P_IFDMTAPA.v_iftb_mta_master.TRANSACTION_ID);
        DBG('P_IFDMTAPA.v_iftb_mta_master.COLL_TRAN_ID=' ||
            P_IFDMTAPA.v_iftb_mta_master.COLL_TRAN_ID);


        P_WRK_IFDMTAPA.v_iftb_mta_master.REFERENCE_NO   := P_IFDMTAPA.v_iftb_mta_master.REFERENCE_NO;
        P_WRK_IFDMTAPA.v_iftb_mta_master.TRANSACTION_ID := P_IFDMTAPA.v_iftb_mta_master.TRANSACTION_ID;
        P_WRK_IFDMTAPA.v_iftb_mta_master.COLL_TRAN_ID   := P_IFDMTAPA.v_iftb_mta_master.COLL_TRAN_ID;
      */

      UPDATE IFTB_MTA_MASTER A
         SET A.REFERENCE_NO   = P_IFDMTAPA.v_iftb_mta_master.REFERENCE_NO,
             A.TRANSACTION_ID = P_IFDMTAPA.v_iftb_mta_master.TRANSACTION_ID,
             A.COLL_TRAN_ID   = P_IFDMTAPA.v_iftb_mta_master.COLL_TRAN_ID
       WHERE A.TRN_REF_NO = P_IFDMTAPA.v_iftb_mta_master.TRN_REF_NO;

    END IF;

    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdmtapa_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdmtapa         IN ifpks_ifdmtapa_Main.Ty_ifdmtapa,
                             p_prev_ifdmtapa    IN ifpks_ifdmtapa_Main.Ty_ifdmtapa,
                             p_wrk_ifdmtapa     IN OUT ifpks_ifdmtapa_Main.Ty_ifdmtapa,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Upload_Db..');

    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdmtapa_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdmtapa         IN ifpks_ifdmtapa_Main.Ty_ifdmtapa,
                        p_Wrk_ifdmtapa     IN OUT ifpks_ifdmtapa_Main.Ty_ifdmtapa,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Query..');

    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdmtapa_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdmtapa         IN ifpks_ifdmtapa_Main.ty_ifdmtapa,
                         p_wrk_ifdmtapa     IN OUT ifpks_ifdmtapa_Main.ty_ifdmtapa,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Query..');

    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of ifpks_ifdmtapa_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END ifpks_ifdmtapa_custom;

