insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('CORAL_VALIDATE_PAY_WS_URL_A', 'http://192.168.1.154/AMLWSRMTA/AMLWSRMT.svc?singleWsdl', 'N');

insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('CORAL_VALIDATE_PAY_WS_URL_B', 'http://192.168.1.154/AMLWSRMTB/AMLWSRMT.svc?singleWsdl', 'N');

insert into cstb_param_custom (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('CORAL_VALIDATION_PAY_STAT_URL', 'http://192.168.1.154/AMLRMTStatus/AMLStatus.svc?singleWsdl', 'N');

COMMIT;
