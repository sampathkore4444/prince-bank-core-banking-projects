CREATE OR REPLACE PACKAGE IFPKS_SANCTION_UTILS AS

  FUNCTION FN_AML_HTTP_CALL(P_OUT_MSG        CLOB,
                            P_IN_RESP        IN OUT CLOB,
                            P_url            IN VARCHAR2,
                            p_soapaction_url in varchar2,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_RETURN_AML_RESP(P_REMIT_TYPE      IN VARCHAR2,
                              P_NAT_OR_ADDR_CNT IN VARCHAR2,
                              P_COUNTRY_FROM    IN VARCHAR2,
                              P_COUNTRY_TO      IN VARCHAR2,
                              P_CUSTOMER_NO     IN VARCHAR2,
                              P_CUST_NAME       IN VARCHAR2,
                              P_ACTION_CODE     IN VARCHAR2,
                              P_HIT_STATUS      OUT VARCHAR2,
                              P_SCAN_ID         OUT VARCHAR2,
                              P_FCREF_NO        IN VARCHAR2,
                              P_SOURCE          IN VARCHAR2,
                              p_Err_Code        IN OUT VARCHAR2,
                              p_Err_Params      IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_RETURN_AML_RESP_RIA(P_SEND_HIGH_CNT IN VARCHAR2,
                                  P_BEN_HIGH_CNT  IN VARCHAR2,
                                  P_CUSTOMER_NO   IN VARCHAR2,
                                  P_SENDER_NAME   IN VARCHAR2,
                                  P_BEN_NAME      IN VARCHAR2,
                                  P_ACTION_CODE   IN VARCHAR2,
                                  P_FCREF_NO      IN VARCHAR2,
                                  
                                  P_HIT_STATUS OUT VARCHAR2,
                                  P_WHO_HIT    OUT CHAR,
                                  P_SCAN_ID    OUT VARCHAR2,
                                  p_Err_Code   IN OUT VARCHAR2,
                                  p_Err_Params IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_RETURN_AML_RESP_RIA_OUT(P_BEN_HIGH_CNT IN VARCHAR2,
                                      P_CUSTOMER_NO  IN VARCHAR2,
                                      
                                      P_BEN_NAME    IN VARCHAR2,
                                      P_ACTION_CODE IN VARCHAR2,
                                      P_FCREF_NO    IN VARCHAR2,
                                      P_HIT_STATUS  OUT VARCHAR2,
                                      P_WHO_HIT     OUT CHAR,
                                      P_SCAN_ID     OUT VARCHAR2,
                                      p_Err_Code    IN OUT VARCHAR2,
                                      p_Err_Params  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_GET_AML_STATUS_RIA_OUT(P_RTN_SCAN_ID IN VARCHAR2,
                                     P_CUSTOMER_NO IN VARCHAR2,
                                     P_FCREF_NO    IN VARCHAR2,
                                     p_Err_Code    IN OUT VARCHAR2,
                                     p_Err_Params  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_RETURN_AML_RESP_RIA_OUT_NEW(P_BEN_HIGH_CNT IN VARCHAR2,
                                          P_CUSTOMER_NO  IN VARCHAR2,
                                          
                                          P_BEN_NAME    IN VARCHAR2,
                                          P_ACTION_CODE IN VARCHAR2,
                                          P_FCREF_NO    IN VARCHAR2,
                                          P_HIT_STATUS  OUT VARCHAR2,
                                          P_WHO_HIT     OUT CHAR,
                                          P_SCAN_ID     OUT VARCHAR2,
                                          p_Err_Code    IN OUT VARCHAR2,
                                          p_Err_Params  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_RETURN_AML_RESP_MTA(P_REMIT_TYPE      IN VARCHAR2,
                                  P_NAT_OR_ADDR_CNT IN VARCHAR2,
                                  P_COUNTRY_FROM    IN VARCHAR2,
                                  P_COUNTRY_TO      IN VARCHAR2,
                                  P_CUSTOMER_NO     IN VARCHAR2,
                                  P_CUST_NAME       IN VARCHAR2,
                                  P_ACTION_CODE     IN VARCHAR2,
                                  P_HIT_STATUS      OUT VARCHAR2,
                                  P_SCAN_ID         OUT VARCHAR2,
                                  p_Err_Code        IN OUT VARCHAR2,
                                  p_Err_Params      IN OUT VARCHAR2)
    RETURN BOOLEAN;

  --New AML Payment Flow Starts
  FUNCTION FN_AML_PAYMENT_CALL(P_USER_NAME               IN VARCHAR2,
                               P_BRANCH_CODE             IN VARCHAR2,
                               P_SYS_NAME                IN VARCHAR2,
                               P_UNIQUE_NO               IN VARCHAR2,
                               P_SEARCH_NAME             IN VARCHAR2,
                               P_SEARCH_COUNTRY          IN VARCHAR2,
                               P_SEARCH_F1               IN VARCHAR2,
                               P_SEARCH_ID               IN VARCHAR2,
                               P_PASSPORT_VERIFY         IN VARCHAR2,
                               P_SECURITY_NO1            IN VARCHAR2,
                               P_PASSPORT_EXPDATE_VERIFY IN VARCHAR2,
                               P_PASSPORT_EXPDATE        IN VARCHAR2,
                               P_SECURITY_NO2            IN VARCHAR2,
                               P_RISK_FACTORS            IN VARCHAR2,
                               P_SEARCH_F2               IN VARCHAR2,
                               P_SEARCH_F3               IN VARCHAR2,
                               P_SEARCH_F4               IN VARCHAR2,
                               P_SEARCH_F5               IN VARCHAR2,
                               P_SEARCH_F6               IN VARCHAR2,
                               P_SEARCH_F7               IN VARCHAR2,
                               P_SEARCH_F8               IN VARCHAR2,
                               P_SEARCH_F9               IN VARCHAR2,
                               P_PROD_CHANNEL            IN VARCHAR2,
                               P_CONTENT                 IN VARCHAR2,
                               P_RETURN_HIT              IN VARCHAR2,
                               P_RETURN_SCANID           IN VARCHAR2,
                               P_RETURN_ENCRYPT_SCANID   IN VARCHAR2,
                               P_RESPONSE                OUT CLOB)
    RETURN BOOLEAN;

--New AML Payment Flow Ends

END IFPKS_SANCTION_UTILS;
