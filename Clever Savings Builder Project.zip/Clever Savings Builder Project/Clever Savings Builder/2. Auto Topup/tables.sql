-- Create table
create table IFTB_AUTO_TOP_UP_CS_BUILDER_WS_LOG
(
  reference_no  VARCHAR2(105) not null,
  invoke_date   TIMESTAMP(6),
  customer_no   VARCHAR2(105),
  cust_ac_no    VARCHAR2(105),
  plan_name     VARCHAR2(105),
  req_type      VARCHAR2(25),
  req_msg       CLOB,
  res_msg       CLOB,
  status        CHAR(1),
  addl_info     VARCHAR2(105),
  error_code    VARCHAR2(105),
  error_message VARCHAR2(255)
)
/
alter table IFTB_AUTO_TOP_UP_CS_BUILDER_WS_LOG add primary key (REFERENCE_NO)
/
-- Create table
create table IFTB_CS_BUILDER_OVERDUE_ACCS
(
  seq_no          VARCHAR2(25) not null,
  customer_no     VARCHAR2(25),
  acc             VARCHAR2(25),
  brn             VARCHAR2(3),
  ccy             VARCHAR2(3),
  due_date        DATE,
  auto_close_date DATE,
  status          CHAR(1) default 'N',
  alert_sent_time DATE
)
/
alter table IFTB_CS_BUILDER_OVERDUE_ACCS add primary key (SEQ_NO)
/
-- Create table
create table IFTB_CS_BUILDER_OVERDUE_ACCS_AFTER_GRACE
(
  seq_no          VARCHAR2(25) not null,
  customer_no     VARCHAR2(25),
  acc             VARCHAR2(25),
  brn             VARCHAR2(3),
  ccy             VARCHAR2(3),
  due_date        DATE,
  auto_close_date DATE,
  status          CHAR(1),
  alert_sent_time DATE,
  action_code     VARCHAR2(100)
)
/
alter table IFTB_CS_BUILDER_OVERDUE_ACCS_AFTER_GRACE add primary key (SEQ_NO)
/
-- Create table
create table IFTB_AUTO_TOPUP_CS_BUILDER_MASTER
(
  seq_no          VARCHAR2(105) not null,
  acc             VARCHAR2(105),
  brn             VARCHAR2(3),
  ccy             VARCHAR2(3),
  td_topup_ref_no VARCHAR2(20),
  pay_in_ofs_acc  VARCHAR2(105),
  pay_in_ofs_brn  VARCHAR2(3),
  top_up_date     DATE,
  top_up_amount   NUMBER,
  retry_count     NUMBER,
  status          CHAR(1)
)
/
alter table IFTB_AUTO_TOPUP_CS_BUILDER_MASTER add primary key (SEQ_NO)
/