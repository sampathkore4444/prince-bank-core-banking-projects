CREATE OR REPLACE PACKAGE IFPKS_AUTOTDREDEEM_CS_BUILDER_UTILS IS

  PROCEDURE PR_INSERT_TD_AUTO_REDEEM_MASTER(P_SEQ_NO         IN VARCHAR2,
                                            P_ACC            IN VARCHAR2,
                                            P_BRN            IN VARCHAR2,
                                            P_CCY            IN VARCHAR2,
                                            P_TDREDEEM_REFNO IN VARCHAR2,
                                            P_TDREDEEM_DATE  IN DATE,
                                            P_STATUS         IN CHAR)

  ;

  PROCEDURE PR_PROCESS_AUTOTDREDEEM; --(P_ACC IN VARCHAR2, --TD Account
  --P_CCY IN VARCHAR2, --TD Account Currency
  --P_BRN IN VARCHAR2);

  PROCEDURE PR_PROCESS_AUTOTDREDEEM(PARAMNAME  VARCHAR2,
                                    PARAMVALUE VARCHAR2);

END IFPKS_AUTOTDREDEEM_CS_BUILDER_UTILS;
