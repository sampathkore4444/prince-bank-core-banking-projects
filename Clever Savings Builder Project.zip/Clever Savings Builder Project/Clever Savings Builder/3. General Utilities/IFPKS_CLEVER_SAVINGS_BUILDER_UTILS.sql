CREATE OR REPLACE PACKAGE BODY IFPKS_CLEVER_SAVINGS_BUILDER_UTILS AS

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'IFPKS_CLEVER_SAVINGS_BUILDER_UTILS ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  FUNCTION FN_GET_BRANCH_DATE(P_BRN IN VARCHAR2) RETURN STTM_DATES.TODAY%TYPE AS
    L_TODAY STTM_DATES.TODAY%TYPE;
  BEGIN
  
    SELECT A.TODAY
      INTO L_TODAY
      FROM STTM_DATES A
     WHERE A.BRANCH_CODE = P_BRN;
  
    RETURN L_TODAY;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_TODAY;
  END FN_GET_BRANCH_DATE;

  FUNCTION FN_GET_ACCOUNT_DTLS(P_ACC IN VARCHAR2,
                               P_BRN IN VARCHAR2,
                               P_CCY IN VARCHAR2)
    RETURN STTM_CUST_ACCOUNT%ROWTYPE AS
    L_STTM_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;
  
  BEGIN
  
    BEGIN
    
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_aCC
         AND A.BRANCH_CODE = P_BRN
         AND A.CCY = P_CCY
         AND A.RECORD_STAT = 'O'
         AND A.ONCE_AUTH = 'Y';
    
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    RETURN L_STTM_CUST_ACCOUNT;
  
  EXCEPTION
    WHEN OTHERS THEN
      L_STTM_CUST_ACCOUNT := NULL;
    
      RETURN L_STTM_CUST_ACCOUNT;
    
  END FN_GET_ACCOUNT_DTLS;

  FUNCTION FN_GET_TD_MIN_TOPUP_AMT(P_ACC      IN VARCHAR2,
                                   P_BRN      IN VARCHAR2,
                                   P_CCY      IN VARCHAR2,
                                   P_DUE_DATE IN VARCHAR2)
  
   RETURN P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE AS
  
    L_MIN_TOP_UP_AMT    ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;
    L_STTM_CUST_ACCOUNT P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    L_PLAN              VARCHAR2(25);
  
  BEGIN
  
    --get branch
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('CLB1', 'CLB2') THEN
    
      L_PLAN := 'SHORT_TERM_PLAN';
    
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('CLB3', 'CLB4') THEN
    
      L_PLAN := 'LONG_TERM_PLAN';
    
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('CLB1', 'CLB2') THEN
    
      BEGIN
        SELECT B.CODE
          INTO L_MIN_TOP_UP_AMT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'CSB_TOPUP_USD_I'
           AND B.VALUE = L_PLAN;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN GETTING THE MIN TOP UP AMOUNT FOR THE ACCOUNT CLASS');
        
      END;
    
    ELSIF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('CLB3', 'CLB4') THEN
    
      BEGIN
        SELECT B.CODE
          INTO L_MIN_TOP_UP_AMT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'CSB_TOPUP_USD_F'
           AND B.VALUE = L_PLAN;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN GETTING THE MIN TOP UP AMOUNT FOR THE ACCOUNT CLASS');
        
      END;
    
    END IF;
  
    DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
        L_MIN_TOP_UP_AMT);
  
    IF P_CCY = 'USD' THEN
    
      L_MIN_TOP_UP_AMT := L_MIN_TOP_UP_AMT;
    
    ELSIF P_CCY = 'KHR' THEN
    
      L_MIN_TOP_UP_AMT := L_MIN_TOP_UP_AMT * 4000;
    
    END IF;
  
    RETURN L_MIN_TOP_UP_AMT;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_MIN_TOP_UP_AMT;
  END FN_GET_TD_MIN_TOPUP_AMT;

  PROCEDURE PR_GET_TD_TOPUP_SCHEDULES(P_ACC             IN VARCHAR2,
                                      P_BRN             IN VARCHAR2,
                                      P_CCY             IN VARCHAR2,
                                      P_TOPUP_SCHEDULES OUT SYS_REFCURSOR) IS
  
    L_DYNAMIC_SQL_STMT VARCHAR2(32767);
  
    l_original_topup_date   VARCHAR2(100);
    l_min_topup_amount      VARCHAR2(100);
    l_topup_date_with_grace VARCHAR2(100);
    L_INITIAL_DEPOSIT       NUMBER;
    L_TD_PRINCIPAL_BAL      NUMBER;
    L_TENOR                 NUMBER;
    L_COUNT                 NUMBER := 1;
    L_CUST_ACCOUNT          STTM_CUST_ACCOUNT%ROWTYPE;
  
    --l_prev_original_topup_date VARCHAR2(100);
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    IF P_ACC IS NOT NULL AND P_BRN IS NOT NULL AND P_CCY IS NOT NULL THEN
    
      --Get Account Details
      L_CUST_ACCOUNT := FN_GET_ACCOUNT_DTLS(P_ACC, P_BRN, P_CCY);
    
      IF EXTRACT(DAY FROM ADD_MONTHS(IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_OPEN_DATE(P_ACC,
                                                                                   P_BRN,
                                                                                   P_CCY),
                            1)) IN (28) THEN
      
        L_DYNAMIC_SQL_STMT := '
WITH recursive_schedule(original_topup_date,
min_topup_amount, topup_date_with_grace) AS
 (SELECT TRUNC(IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_OPEN_DATE(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''')/*-1*/) AS original_topup_date,
         0 AS amount, -- Starting amount for the first schedule. here instead of zero, you can replace with below IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_MIN_TOPUP_AMT
         null as topup_date_with_grace
      FROM dual
  UNION ALL
  SELECT CASE
           WHEN EXTRACT(DAY FROM ADD_MONTHS(original_topup_date, 1)) = 31
             THEN LAST_DAY(ADD_MONTHS(original_topup_date, 1)) - 3
           ELSE ADD_MONTHS(original_topup_date, 1)
         END/*ADD_MONTHS(original_topup_date, 1)*/, IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_MIN_TOPUP_AMT(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''') -- Incrementing amount for each subsequent schedule
          , DECODE(ADD_MONTHS(original_topup_date, 1),IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_MATURITY_DATE(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              '''),NULL,ADD_MONTHS(TO_CHAR(original_topup_date,''DD - MON - YYYY''), 1) + 3)
    FROM recursive_schedule
   WHERE original_topup_date <
         ADD_MONTHS(TRUNC(IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_OPEN_DATE(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''')),
                    IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TENOR_IN_MONTHS(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''')) -- Generating schedules up to 12 months
  )
SELECT original_topup_date, min_topup_amount, topup_date_with_grace FROM recursive_schedule';
      
      ELSIF EXTRACT(DAY FROM ADD_MONTHS(IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_OPEN_DATE(P_ACC,
                                                                                      P_BRN,
                                                                                      P_CCY),
                               1)) IN (29) THEN
      
        L_DYNAMIC_SQL_STMT := '
WITH recursive_schedule(original_topup_date,
min_topup_amount, topup_date_with_grace) AS
 (SELECT TRUNC(IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_OPEN_DATE(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''')/*-1*/) AS original_topup_date,
         0 AS amount, -- Starting amount for the first schedule. here instead of zero, you can replace with below IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_MIN_TOPUP_AMT
         null as topup_date_with_grace
      FROM dual
  UNION ALL
  SELECT CASE
           WHEN EXTRACT(DAY FROM ADD_MONTHS(original_topup_date, 1)) = 31
             THEN LAST_DAY(ADD_MONTHS(original_topup_date, 1)) - 2
           ELSE ADD_MONTHS(original_topup_date, 1)
         END/*ADD_MONTHS(original_topup_date, 1)*/, IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_MIN_TOPUP_AMT(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''') -- Incrementing amount for each subsequent schedule
          , DECODE(ADD_MONTHS(original_topup_date, 1),IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_MATURITY_DATE(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              '''),NULL,ADD_MONTHS(TO_CHAR(original_topup_date,''DD - MON - YYYY''), 1) + 3)
    FROM recursive_schedule
   WHERE original_topup_date <
         ADD_MONTHS(TRUNC(IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_OPEN_DATE(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''')),
                    IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TENOR_IN_MONTHS(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''')) -- Generating schedules up to 12 months
  )
SELECT original_topup_date, min_topup_amount, topup_date_with_grace FROM recursive_schedule';
      
      ELSIF EXTRACT(DAY FROM ADD_MONTHS(IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_OPEN_DATE(P_ACC,
                                                                                      P_BRN,
                                                                                      P_CCY),
                               1)) IN (31) THEN
      
        L_DYNAMIC_SQL_STMT := '
WITH recursive_schedule(original_topup_date,
min_topup_amount, topup_date_with_grace) AS
 (SELECT TRUNC(IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_OPEN_DATE(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''')/*-1*/) AS original_topup_date,
         0 AS amount, -- Starting amount for the first schedule. here instead of zero, you can replace with below IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_MIN_TOPUP_AMT
         null as topup_date_with_grace
      FROM dual
  UNION ALL
  SELECT CASE
           WHEN EXTRACT(DAY FROM ADD_MONTHS(original_topup_date, 1)) = 31
             THEN LAST_DAY(ADD_MONTHS(original_topup_date, 1))
           ELSE ADD_MONTHS(original_topup_date, 1)
         END/*ADD_MONTHS(original_topup_date, 1)*/, IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_MIN_TOPUP_AMT(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''') -- Incrementing amount for each subsequent schedule
          , DECODE(ADD_MONTHS(original_topup_date, 1),IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_MATURITY_DATE(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              '''),NULL,ADD_MONTHS(TO_CHAR(original_topup_date,''DD - MON - YYYY''), 1) + 3)
    FROM recursive_schedule
   WHERE original_topup_date <
         ADD_MONTHS(TRUNC(IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_OPEN_DATE(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''')),
                    IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TENOR_IN_MONTHS(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''')) -- Generating schedules up to 12 months
  )
SELECT original_topup_date, min_topup_amount, topup_date_with_grace FROM recursive_schedule';
      
      ELSE
      
        L_DYNAMIC_SQL_STMT := '
WITH recursive_schedule(original_topup_date,
min_topup_amount, topup_date_with_grace) AS
 (SELECT TRUNC(IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_OPEN_DATE(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''')/*-1*/) AS original_topup_date,
         0 AS amount, -- Starting amount for the first schedule. here instead of zero, you can replace with below IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_MIN_TOPUP_AMT
         null as topup_date_with_grace
      FROM dual
  UNION ALL
  SELECT CASE
           WHEN EXTRACT(DAY FROM ADD_MONTHS(original_topup_date, 1)) = 31
             THEN LAST_DAY(ADD_MONTHS(original_topup_date, 1)) - 1
           ELSE ADD_MONTHS(original_topup_date, 1)
         END/*ADD_MONTHS(original_topup_date, 1)*/, IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_MIN_TOPUP_AMT(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''') -- Incrementing amount for each subsequent schedule
          , DECODE(ADD_MONTHS(original_topup_date, 1),IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_MATURITY_DATE(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              '''),NULL,ADD_MONTHS(TO_CHAR(original_topup_date,''DD - MON - YYYY''), 1) + 3)
    FROM recursive_schedule
   WHERE original_topup_date <
         ADD_MONTHS(TRUNC(IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TD_OPEN_DATE(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''')),
                    IFPKS_CLEVER_SAVINGS_BUILDER_UTILS.FN_GET_TENOR_IN_MONTHS(''' ||
                              P_ACC || ''',
                                                              ''' ||
                              P_BRN || ''',
                                                              ''' ||
                              P_CCY ||
                              ''')) -- Generating schedules up to 12 months
  )
SELECT original_topup_date, min_topup_amount, topup_date_with_grace FROM recursive_schedule';
      
      END IF;
    
      DBMS_OUTPUT.put_line('L_DYNAMIC_SQL_STMT=' || L_DYNAMIC_SQL_STMT);
      DELETE FROM IFTB_TD_TOPUP_SCHEDULES_CSB_SAV
       WHERE ACC = P_ACC
         AND BRN = P_BRN
         AND CCY = P_CCY;
    
      COMMIT;
    
      --get initial deposit
      L_INITIAL_DEPOSIT := FN_GET_TD_INIT_BAL(P_ACC, P_BRN, P_CCY);
      L_TENOR           := FN_GET_TENOR_IN_MONTHS(P_ACC, P_BRN, P_CCY);
    
      --top-up due date fix starts
      --l_prev_original_topup_date := FN_GET_TD_OPEN_DATE(P_ACC, P_BRN, P_CCY);
      --top-up due date fix ends
    
      OPEN P_TOPUP_SCHEDULES FOR L_DYNAMIC_SQL_STMT;
    
      --populate into the table
      loop
        fetch P_TOPUP_SCHEDULES
          into l_original_topup_date,
               l_min_topup_amount,
               l_topup_date_with_grace;
      
        exit when P_TOPUP_SCHEDULES%notfound;
      
        DBMS_OUTPUT.put_LINE(l_original_topup_date || ',' ||
                             l_min_topup_amount || ',' ||
                             l_topup_date_with_grace);
      
        L_MIN_TOPUP_AMOUNT := FN_GET_TD_MIN_TOPUP_AMT(P_ACC,
                                                      P_BRN,
                                                      P_CCY,
                                                      ADD_MONTHS(L_ORIGINAL_TOPUP_DATE,
                                                                 1));
      
        IF L_COUNT = L_TENOR + 1 OR L_COUNT = 1 THEN
        
          l_min_topup_amount := 0;
        
        END IF;
      
        --top-up due date fix starts
        --l_original_topup_date := ADD_MONTHS(l_prev_original_topup_date, L_COUNT - 1);
        --top-up due date fix ends
      
        L_TD_PRINCIPAL_BAL := L_INITIAL_DEPOSIT + l_min_topup_amount;
      
        DBMS_OUTPUT.PUT_LINE('L_TD_PRINCIPAL_BAL=' || L_TD_PRINCIPAL_BAL);
      
        INSERT INTO IFTB_TD_TOPUP_SCHEDULES_CSB_SAV
        VALUES
          (P_ACC,
           P_BRN,
           P_CCY,
           l_original_topup_date,
           l_topup_date_with_grace,
           l_min_topup_amount,
           L_TD_PRINCIPAL_BAL);
      
        L_INITIAL_DEPOSIT := L_TD_PRINCIPAL_BAL;
      
        --top-up due date fix starts
        --l_prev_original_topup_date := l_original_topup_date;
        --top-up due date fix ends
      
        L_COUNT := L_COUNT + 1;
      
      end loop;
    
      COMMIT;
    
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
    
      P_TOPUP_SCHEDULES := NULL;
      DBMS_OUTPUT.put_line('ERROR CODE=' || SQLCODE);
      DBMS_OUTPUT.put_line('ERROR MESSAGE=' || SQLERRM);
  END PR_GET_TD_TOPUP_SCHEDULES;

  FUNCTION FN_GET_PUSH_NOTIF_CREDENTIALS(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PUSH_NOTIF_CREDENTIALS;

  FUNCTION FN_GET_REMINDER_MSG(P_LANG       IN VARCHAR2,
                               P_WHEN_ALERT IN VARCHAR2)
    RETURN STTB_NOTIF_LANG_CLEVER_SAVING_TEMPLATE.MESSAGE%TYPE AS
  
    L_REMINDER_MSG STTB_NOTIF_LANG_CLEVER_SAVING_TEMPLATE.MESSAGE%TYPE;
  
  BEGIN
  
    BEGIN
      SELECT MESSAGE
        INTO L_REMINDER_MSG
        FROM STTB_NOTIF_LANG_CLEVER_SAVING_TEMPLATE A
       WHERE A.LANGUAGE = P_LANG
         AND A.TRIGGER_ALERT = P_WHEN_ALERT;
    EXCEPTION
      WHEN OTHERS THEN
        L_REMINDER_MSG := NULL;
    END;
  
    RETURN L_REMINDER_MSG;
  
  EXCEPTION
    WHEN OTHERS THEN
    
      RETURN L_REMINDER_MSG;
    
  END FN_GET_REMINDER_MSG;

  PROCEDURE PR_INSERT_PUSH_NOTIF_STATUS(P_CUST_NO   IN VARCHAR2,
                                        P_CUSTAC_NO IN VARCHAR2,
                                        P_CCY       IN VARCHAR2,
                                        P_BRN       IN VARCHAR2,
                                        P_ACTION    IN VARCHAR2,
                                        P_STATUS    IN VARCHAR2) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    INSERT INTO IFTB_CSB_SAV_PUSH_NOTIFICATION
      (CUSTOMER_NO,
       CUST_AC_NO,
       CCY,
       BRANCH_CODE,
       ACTION_CODE,
       STATUS,
       TIMESTAMP)
    VALUES
      (P_CUST_NO, P_CUSTAC_NO, P_CCY, P_BRN, P_ACTION, P_STATUS, SYSDATE);
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_PUSH_NOTIF_STATUS');
      DBG('ERROR CODE IN PR_INSERT_PUSH_NOTIF_STATUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_PUSH_NOTIF_STATUS=' || SQLERRM);
  END PR_INSERT_PUSH_NOTIF_STATUS;

  PROCEDURE PR_UPDATE_PUSH_NOTIF_STATUS(P_CUST_NO   IN VARCHAR2,
                                        P_CUSTAC_NO IN VARCHAR2,
                                        P_CCY       IN VARCHAR2,
                                        P_BRN       IN VARCHAR2,
                                        P_ACTION    IN VARCHAR2,
                                        P_STATUS    IN VARCHAR2) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    UPDATE IFTB_CSB_SAV_PUSH_NOTIFICATION A
       SET A.STATUS = P_STATUS
     WHERE CUSTOMER_NO = P_CUST_NO
       AND CUST_AC_NO = P_CUSTAC_NO
       AND CCY = P_CCY
       AND BRANCH_CODE = P_BRN
       AND ACTION_CODE = P_ACTION;
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_PUSH_NOTIF_STATUS');
      DBG('ERROR CODE IN PR_UPDATE_PUSH_NOTIF_STATUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_PUSH_NOTIF_STATUS=' || SQLERRM);
  END PR_UPDATE_PUSH_NOTIF_STATUS;

  PROCEDURE PR_PROCESS_NEW_NOTIF_JOB IS
  
    CURSOR C1 IS
      SELECT *
        FROM STTM_CUST_ACCOUNT A
       WHERE A.ACCOUNT_CLASS IN
             ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02')
         AND A.ACCOUNT_TYPE = 'Y'
            --AND A.AC_OPEN_DATE = GLOBAL.APPLICATION_DATE
         AND A.RECORD_STAT = 'O'
         AND A.ONCE_AUTH = 'Y'
            --AND A.CUST_AC_NO = '000116481' --Adding account for UAT testing
         AND A.CUST_AC_NO NOT IN
             (SELECT CUST_AC_NO
                FROM IFTB_ClEVER_SAV_PUSH_NOTIFICATION A
               WHERE A.ACTION_CODE = 'NEW'
                 AND A.STATUS = 'Y');
  
    L_TRIED_NOTIF_COUNT NUMBER := 0;
  
  BEGIN
  
    FOR G IN C1 LOOP
      BEGIN
      
        GLOBAL.PR_INIT(G.BRANCH_CODE, 'SYSTEM');
      
        BEGIN
          SELECT COUNT(1)
            INTO L_TRIED_NOTIF_COUNT
            FROM IFTB_CLEVER_SAV_PUSH_NOTIFICATION A
           WHERE A.CUSTOMER_NO = G.CUST_NO
             AND A.CUST_AC_NO = G.CUST_AC_NO
             AND A.ACTION_CODE = 'NEW';
        EXCEPTION
          WHEN OTHERS THEN
            L_TRIED_NOTIF_COUNT := 0;
        END;
      
        IF L_TRIED_NOTIF_COUNT <> 0 THEN
          CONTINUE;
        END IF;
      
        IF NOT FN_PUSH_NOTIFICATION(G.CUST_NO, 'NEW') THEN
        
          DBG('FAILED IN PUSHING THE NOTIFICATION');
        
          PR_UPDATE_PUSH_NOTIF_STATUS(G.CUST_NO,
                                      G.CUST_AC_NO,
                                      G.CCY,
                                      G.BRANCH_CODE,
                                      'NEW',
                                      'N');
        
          CONTINUE;
        
        ELSE
          DBG('SUCCESS IN PUSHING THE NOTIFICATION');
          PR_UPDATE_PUSH_NOTIF_STATUS(G.CUST_NO,
                                      G.CUST_AC_NO,
                                      G.CCY,
                                      G.BRANCH_CODE,
                                      'NEW',
                                      'Y');
        
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN PUSHING THE NOTIFICATION WHEN OTHERS');
          PR_UPDATE_PUSH_NOTIF_STATUS(G.CUST_NO,
                                      G.CUST_AC_NO,
                                      G.CCY,
                                      G.BRANCH_CODE,
                                      'NEW',
                                      'N');
        
          CONTINUE;
      END;
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_NEW_NOTIF_JOB');
      DBG('ERROR CODE IN PR_PROCESS_NEW_NOTIF_JOB=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_NEW_NOTIF_JOB=' || SQLERRM);
  END PR_PROCESS_NEW_NOTIF_JOB;

  PROCEDURE PR_NEW_NOTIF_JOB(P_PARAM_NAME IN VARCHAR2, PARAMVALUE VARCHAR2) IS
  BEGIN
  
    DBG('BEGIN OF PR_NEW_NOTIF_JOB');
  
    PR_PROCESS_NEW_NOTIF_JOB;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_NOTIF_JOB');
      DBG('ERROR CODE IN PR_NEW_NOTIF_JOB=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_NEW_NOTIF_JOB=' || SQLERRM);
  END PR_NEW_NOTIF_JOB;

  PROCEDURE PR_PROCESS_CLOSE_NOTIF_JOB IS
  
    CURSOR C1 IS
      SELECT *
        FROM STTM_CUST_ACCOUNT A
       WHERE A.ACCOUNT_CLASS IN
             ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02')
         AND A.ACCOUNT_TYPE = 'Y'
         AND A.RECORD_STAT = 'C'
         AND A.ONCE_AUTH = 'Y'
            --AND A.CUST_AC_NO = '000116228' --Adding account for UAT testing
         AND A.CUST_AC_NO NOT IN
             (SELECT CUST_AC_NO
                FROM IFTB_ClEVER_SAV_PUSH_NOTIFICATION A
               WHERE A.ACTION_CODE = 'CLOSE'
                 AND A.ACTION_CODE <> 'NEW'
                 AND A.STATUS = 'Y');
    /*   AND A.CUST_AC_NO NOT IN
    (SELECT B.ACC
       FROM IFTB_CLEVER_SAVINGS_OVERDUE_ACCS B
      WHERE B.ACTION_CODE = 'CLEVER_SAVING_CLOSE_ACC_AFTER_3DAY'); --added now*/
  
    L_ACTION_CODE VARCHAR2(100);
  
  BEGIN
  
    FOR G IN C1 LOOP
      BEGIN
      
        GLOBAL.PR_INIT(G.BRANCH_CODE, 'SYSTEM');
      
        --Get the account opening date
      
        --IF G.MAKER_ID <> 'SYSTEM' AND G.CHECKER_ID <> 'SYSTEM' THEN
      
        --   L_ACTION_CODE := 'CLEVER_SAVING_CLOSE_ACC_EARLY';
      
        -- ELSE
      
        L_ACTION_CODE := 'CLOSE';
      
        -- END IF;
      
        IF NOT FN_PUSH_NOTIFICATION(G.CUST_NO, L_ACTION_CODE) THEN
        
          PR_UPDATE_PUSH_NOTIF_STATUS(G.CUST_NO,
                                      G.CUST_AC_NO,
                                      G.CCY,
                                      G.BRANCH_CODE,
                                      L_ACTION_CODE,
                                      'N');
        
          CONTINUE;
        
        ELSE
        
          PR_UPDATE_PUSH_NOTIF_STATUS(G.CUST_NO,
                                      G.CUST_AC_NO,
                                      G.CCY,
                                      G.BRANCH_CODE,
                                      L_ACTION_CODE,
                                      'Y');
        
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          PR_UPDATE_PUSH_NOTIF_STATUS(G.CUST_NO,
                                      G.CUST_AC_NO,
                                      G.CCY,
                                      G.BRANCH_CODE,
                                      L_ACTION_CODE,
                                      'N');
        
          CONTINUE;
      END;
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_CLOSE_NOTIF_JOB');
      DBG('ERROR CODE IN PR_PROCESS_CLOSE_NOTIF_JOB=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_CLOSE_NOTIF_JOB=' || SQLERRM);
  END PR_PROCESS_CLOSE_NOTIF_JOB;

  PROCEDURE PR_CLOSE_NOTIF_JOB(P_PARAM_NAME IN VARCHAR2,
                               PARAMVALUE   VARCHAR2) IS
  BEGIN
  
    DBG('BEGIN OF PR_CLOSE_NOTIF_JOB');
  
    PR_PROCESS_CLOSE_NOTIF_JOB;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_CLOSE_NOTIF_JOB');
      DBG('ERROR CODE IN PR_CLOSE_NOTIF_JOB=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_CLOSE_NOTIF_JOB=' || SQLERRM);
  END PR_CLOSE_NOTIF_JOB;

  PROCEDURE PR_PROCESS_CLOSE_OVERDRAWN_NOTIF_JOB IS
  
    CURSOR C1 IS
      SELECT *
        FROM STTM_CUST_ACCOUNT A
       WHERE A.ACCOUNT_CLASS IN
             ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02')
         AND A.ACCOUNT_TYPE = 'Y'
         AND A.RECORD_STAT = 'C'
         AND A.MAKER_ID = 'SYSTEM'
         AND A.CHECKER_ID = 'SYSTEM'
         AND A.ONCE_AUTH = 'Y'
            
         AND A.CUST_AC_NO NOT IN
             (SELECT CUST_AC_NO
                FROM IFTB_ClEVER_SAV_PUSH_NOTIFICATION A
               WHERE A.ACTION_CODE = 'CLEVER_SAVING_CLOSE_ACC_AFTER_3DAY'
                 AND A.ACTION_CODE <> 'NEW'
                 AND A.ACTION_CODE <> 'CLOSE'
                 AND A.STATUS = 'Y');
  
    L_ACTION_CODE VARCHAR2(100);
  
  BEGIN
  
    FOR G IN C1 LOOP
      BEGIN
      
        GLOBAL.PR_INIT(G.BRANCH_CODE, 'SYSTEM');
      
        --Get the account opening date
      
        L_ACTION_CODE := 'CLEVER_SAVING_CLOSE_ACC_EARLY';
      
        IF NOT FN_PUSH_NOTIFICATION(G.CUST_NO, L_ACTION_CODE) THEN
        
          PR_UPDATE_PUSH_NOTIF_STATUS(G.CUST_NO,
                                      G.CUST_AC_NO,
                                      G.CCY,
                                      G.BRANCH_CODE,
                                      L_ACTION_CODE,
                                      'N');
        
          CONTINUE;
        
        ELSE
        
          PR_UPDATE_PUSH_NOTIF_STATUS(G.CUST_NO,
                                      G.CUST_AC_NO,
                                      G.CCY,
                                      G.BRANCH_CODE,
                                      L_ACTION_CODE,
                                      'Y');
        
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          PR_UPDATE_PUSH_NOTIF_STATUS(G.CUST_NO,
                                      G.CUST_AC_NO,
                                      G.CCY,
                                      G.BRANCH_CODE,
                                      L_ACTION_CODE,
                                      'N');
        
          CONTINUE;
      END;
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_CLOSE_OVERDRAWN_NOTIF_JOB');
      DBG('ERROR CODE IN PR_PROCESS_CLOSE_OVERDRAWN_NOTIF_JOB=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_CLOSE_OVERDRAWN_NOTIF_JOB=' ||
          SQLERRM);
  END PR_PROCESS_CLOSE_OVERDRAWN_NOTIF_JOB;

  PROCEDURE PR_CLOSE_OVERDRAWN_NOTIF_JOB(P_PARAM_NAME IN VARCHAR2,
                                         PARAMVALUE   VARCHAR2) IS
  BEGIN
  
    DBG('BEGIN OF PR_CLOSE_OVERDRAWN_NOTIF_JOB');
  
    PR_PROCESS_CLOSE_OVERDRAWN_NOTIF_JOB;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_CLOSE_OVERDRAWN_NOTIF_JOB');
      DBG('ERROR CODE IN PR_CLOSE_OVERDRAWN_NOTIF_JOB=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_CLOSE_OVERDRAWN_NOTIF_JOB=' || SQLERRM);
  END PR_CLOSE_OVERDRAWN_NOTIF_JOB;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;
  
    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION FN_PUSH_NOTIFICATION(P_CUSTOMER_NO IN VARCHAR2,
                                P_ACTION      IN VARCHAR2) RETURN BOOLEAN AS
  
    req     utl_http.req;
    res     utl_http.resp;
    L_URL   varchar2(4000);
    L_UID   CSTB_PARAM_CUSTOM.PARAM_NAME%TYPE;
    L_PWD   CSTB_PARAM_CUSTOM.PARAM_NAME%TYPE;
    name    varchar2(4000);
    buffer  varchar2(32767);
    buffer1 clob;
    buffer2 clob;
    content varchar2(4000) := '{ "channelCode":"CBS", "contentKey":"$L_ACTION_CODE", "customerId":"$L_CUSTOMER_ID" }';
  
    L_STATUS_CODE  VARCHAR2(100);
    L_STATUS_MSG   VARCHAR2(100);
    P_DOCUMENT_XML XMLTYPE;
  
    L_REMINDER_ENG_CONTENT VARCHAR2(255);
    L_REMINDER_KH_CONTENT  VARCHAR2(2500);
    L_REMINDER_CN_CONTENT  VARCHAR2(255);
  
    L_REMINDER_ENG_TITLE VARCHAR2(255);
    L_REMINDER_KH_TITLE  VARCHAR2(2500);
    L_REMINDER_CN_TITLE  VARCHAR2(255);
  
    l_length number;
  
  BEGIN
  
    DBG('START OF FN_PUSH_NOTIFICATION');
  
    L_URL := FN_GET_PUSH_NOTIF_CREDENTIALS('CLEVER_SAV_PUSH_NOTIF_URL');
  
    L_UID := FN_GET_PUSH_NOTIF_CREDENTIALS('CLEVER_SAV_PUSH_NOTIF_UID');
  
    L_PWD := FN_GET_PUSH_NOTIF_CREDENTIALS('CLEVER_SAV_PUSH_NOTIF_PWD');
  
    req := utl_http.begin_request(L_URL, 'POST', ' HTTP/1.1');
    utl_http.set_authentication(req, L_UID, L_PWD, 'Basic');
    utl_http.set_header(req, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(req, 'content-type', 'application/json');
  
    --utl_http.set_header(req,
    --                  'content-type',
    --                'application/x-www-form-urlencoded');
  
    utl_http.set_header(req,
                        'content-type',
                        'application/json;charset=UTF-8');
  
    content := replace(content, '$L_CUSTOMER_ID', P_CUSTOMER_NO);
  
    IF P_ACTION = 'NEW' THEN
    
      content := replace(content,
                         '$L_ACTION_CODE',
                         'CLEVER_SAVING_PRO_ACC_CREATION');
    
    END IF;
  
    IF P_ACTION = 'CLOSE' THEN
    
      content := replace(content,
                         '$L_ACTION_CODE',
                         'CLEVER_SAVING_PRO_CLOSE_ACC_EARLY'); --'CLEVER_SAVING_CLOSE_ACC_EARLY');
    
    END IF;
    --sotthorn temp testing
    IF P_ACTION = 'CLOSE14DAY' THEN
    
      content := replace(content,
                         '$L_ACTION_CODE',
                         'CLEVER_SAVING_PRO_CLOSE_AFTER_14DAY'); --'CLEVER_SAVING_CLOSE_ACC_EARLY');
    END IF;
    --sotthorn for temp testing
    begin
      insert into iftb_push_notif_log
      values
        (P_CUSTOMER_NO, p_Action, content, sysdate);
    exception
      when others then
        null;
    end;
  
    select REGEXP_COUNT(DUMP(content, 1016), 'c3') into l_length from dual;
  
    debug.pr_debug('IF', 'l_length=' || l_length);
  
    utl_http.set_header(req, 'Content-Length', length(content) + l_length);
  
    --utl_http.set_header(req, 'Content-Length', length(content));
  
    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
  
    dbms_output.put_line('content=' || content);
    DBG('content=' || content);
  
    utl_http.write_text(req, content);
  
    UTL_HTTP.WRITE_RAW(req, UTL_RAW.CAST_TO_RAW(content));
  
    res := utl_http.get_response(req);
  
    dbms_output.put_line('status code=' || res.status_code);
    DBG('status code==' || res.status_code);
  
    -- process the response from the HTTP call
    begin
      loop
        utl_http.read_line(res, buffer);
        buffer1 := buffer1 || buffer;
      end loop;
      utl_http.end_response(res);
    exception
      when utl_http.end_of_body then
        utl_http.end_response(res);
      when others then
        dbms_output.put_line('ERROR CODE=' || SQLCODE);
        dbms_output.put_line('ERROR MESSAGE=' || SQLERRM);
    end;
  
    dbms_output.put_line('buffer1=' || buffer1);
    DBG('buffer1=' || buffer1);
  
    --Get JSON in XML
    buffer2 := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(buffer1);
    dbms_output.put_line('buffer2=' || buffer2);
    DBG('buffer2=' || buffer2);
  
    buffer2 := FN_CLOBREPLACE(buffer2, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || buffer2);
  
    buffer2 := FN_CLOBREPLACE(buffer2, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || buffer2);
  
    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || buffer2);
  
    P_DOCUMENT_XML := XMLTYPE(buffer2);
  
    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;
  
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;
  
    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);
  
    IF L_STATUS_CODE <> '000' THEN
    
      RETURN FALSE;
    
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PUSHING THE NOTIFICATION');
      DBG('ERROR CODE IN FN_PUSH_NOTIFICATION=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_PUSH_NOTIFICATION=' || SQLERRM);
      RETURN FALSE;
  END FN_PUSH_NOTIFICATION;

  FUNCTION FN_PUSH_NOTIFICATION_BKP(P_CUSTOMER_NO IN VARCHAR2,
                                    P_ACTION      IN VARCHAR2) RETURN BOOLEAN AS
  
    req     utl_http.req;
    res     utl_http.resp;
    L_URL   varchar2(4000);
    L_UID   CSTB_PARAM_CUSTOM.PARAM_NAME%TYPE;
    L_PWD   CSTB_PARAM_CUSTOM.PARAM_NAME%TYPE;
    name    varchar2(4000);
    buffer  varchar2(32767);
    buffer1 clob;
    buffer2 clob;
    content varchar2(4000) := '{
   "channelCode":"CBS",
   "contentEN":"$L_EN_CONTENT",
   "contentKH":"$L_KH_CONTENT",,
   "contentZH":"$L_CN_CONTENT",
   "customers":[{"customerId":"$L_CUSTOMER_ID"}],
   "subTitleEN":"$L_EN_SUBTITLE",
   "subTitleKH":"$L_KH_SUBTITLE",
   "subTitleZH":"$L_CN_SUBTITLE",
   "titleEN":"$L_EN_TITLE",
   "titleKH":"$L_KH_TITLE",
   "titleZH":"$L_CN_TITLE"
}';
  
    L_STATUS_CODE  VARCHAR2(100);
    L_STATUS_MSG   VARCHAR2(100);
    P_DOCUMENT_XML XMLTYPE;
  
    L_REMINDER_ENG_CONTENT VARCHAR2(255);
    L_REMINDER_KH_CONTENT  VARCHAR2(2500);
    L_REMINDER_CN_CONTENT  VARCHAR2(255);
  
    L_REMINDER_ENG_TITLE VARCHAR2(255);
    L_REMINDER_KH_TITLE  VARCHAR2(2500);
    L_REMINDER_CN_TITLE  VARCHAR2(255);
  
    l_length number;
  
  BEGIN
  
    DBG('START OF FN_PUSH_NOTIFICATION');
  
    L_URL := FN_GET_PUSH_NOTIF_CREDENTIALS('CLEVER_SAV_PUSH_NOTIF_URL');
  
    L_UID := FN_GET_PUSH_NOTIF_CREDENTIALS('CLEVER_SAV_PUSH_NOTIF_UID');
  
    L_PWD := FN_GET_PUSH_NOTIF_CREDENTIALS('CLEVER_SAV_PUSH_NOTIF_PWD');
  
    req := utl_http.begin_request(L_URL, 'POST', ' HTTP/1.1');
    utl_http.set_authentication(req, L_UID, L_PWD, 'Basic');
    utl_http.set_header(req, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(req, 'content-type', 'application/json');
  
    --utl_http.set_header(req,
    --                  'content-type',
    --                'application/x-www-form-urlencoded');
  
    utl_http.set_header(req,
                        'content-type',
                        'application/json;charset=UTF-8');
  
    content := replace(content, '$L_CUSTOMER_ID', P_CUSTOMER_NO);
  
    IF P_ACTION = 'NEW' THEN
    
      L_REMINDER_ENG_CONTENT := FN_GET_REMINDER_MSG('EN', 'NEW_CONTENT');
    
      content := replace(content, '$L_EN_CONTENT', L_REMINDER_ENG_CONTENT);
    
      L_REMINDER_KH_CONTENT := FN_GET_REMINDER_MSG('KH', 'NEW_CONTENT');
    
      dbg('L_REMINDER_KH_CONTENT=' || L_REMINDER_KH_CONTENT);
    
      content := replace(content, '$L_KH_CONTENT', L_REMINDER_KH_CONTENT);
    
      dbg('content=' || content);
    
      L_REMINDER_CN_CONTENT := FN_GET_REMINDER_MSG('CH', 'NEW_CONTENT');
    
      content := replace(content, '$L_CN_CONTENT', L_REMINDER_CN_CONTENT);
    
      content := replace(content, '$L_EN_SUBTITLE', P_CUSTOMER_NO);
    
      content := replace(content, '$L_KH_SUBTITLE', P_CUSTOMER_NO);
    
      content := replace(content, '$L_CN_SUBTITLE', P_CUSTOMER_NO);
    
      L_REMINDER_ENG_TITLE := FN_GET_REMINDER_MSG('EN', 'NEW_TITLE');
    
      content := replace(content, '$L_EN_TITLE', L_REMINDER_ENG_TITLE);
    
      L_REMINDER_KH_TITLE := FN_GET_REMINDER_MSG('KH', 'NEW_TITLE');
    
      content := replace(content, '$L_KH_TITLE', L_REMINDER_KH_TITLE);
    
      L_REMINDER_CN_TITLE := FN_GET_REMINDER_MSG('CH', 'NEW_TITLE');
    
      content := replace(content, '$L_CN_TITLE', L_REMINDER_CN_TITLE);
    
    END IF;
  
    IF P_ACTION = 'CLOSE' THEN
    
      L_REMINDER_ENG_CONTENT := FN_GET_REMINDER_MSG('EN', 'CLOSE_CONTENT');
    
      content := replace(content, '$L_EN_CONTENT', L_REMINDER_ENG_CONTENT);
    
      L_REMINDER_KH_CONTENT := FN_GET_REMINDER_MSG('KH', 'CLOSE_CONTENT');
    
      content := replace(content, '$L_KH_CONTENT', L_REMINDER_KH_CONTENT);
    
      L_REMINDER_CN_CONTENT := FN_GET_REMINDER_MSG('CH', 'CLOSE_CONTENT');
    
      content := replace(content, '$L_CN_CONTENT', L_REMINDER_CN_CONTENT);
    
      content := replace(content, '$L_EN_SUBTITLE', P_CUSTOMER_NO);
    
      content := replace(content, '$L_KH_SUBTITLE', P_CUSTOMER_NO);
    
      content := replace(content, '$L_CN_SUBTITLE', P_CUSTOMER_NO);
    
      L_REMINDER_ENG_TITLE := FN_GET_REMINDER_MSG('EN', 'CLOSE_TITLE');
    
      content := replace(content, '$L_EN_TITLE', L_REMINDER_ENG_TITLE);
    
      L_REMINDER_KH_TITLE := FN_GET_REMINDER_MSG('KH', 'CLOSE_TITLE');
    
      content := replace(content, '$L_KH_TITLE', L_REMINDER_KH_TITLE);
    
      L_REMINDER_CN_TITLE := FN_GET_REMINDER_MSG('CH', 'CLOSE_TITLE');
    
      content := replace(content, '$L_CN_TITLE', L_REMINDER_CN_TITLE);
    
    END IF;
  
    begin
      insert into iftb_push_notif_log
      values
        (P_CUSTOMER_NO, p_Action, content, sysdate);
    exception
      when others then
        null;
    end;
  
    select REGEXP_COUNT(DUMP(content, 1016), 'c3') into l_length from dual;
  
    debug.pr_debug('IF', 'l_length=' || l_length);
  
    utl_http.set_header(req, 'Content-Length', length(content) + l_length);
  
    --utl_http.set_header(req, 'Content-Length', length(content));
  
    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
  
    dbms_output.put_line('content=' || content);
    DBG('content=' || content);
  
    utl_http.write_text(req, content);
  
    UTL_HTTP.WRITE_RAW(req, UTL_RAW.CAST_TO_RAW(content));
  
    res := utl_http.get_response(req);
  
    dbms_output.put_line('status code=' || res.status_code);
    DBG('status code==' || res.status_code);
  
    -- process the response from the HTTP call
    begin
      loop
        utl_http.read_line(res, buffer);
        buffer1 := buffer1 || buffer;
      end loop;
      utl_http.end_response(res);
    exception
      when utl_http.end_of_body then
        utl_http.end_response(res);
      when others then
        dbms_output.put_line('ERROR CODE=' || SQLCODE);
        dbms_output.put_line('ERROR MESSAGE=' || SQLERRM);
    end;
  
    dbms_output.put_line('buffer1=' || buffer1);
    DBG('buffer1=' || buffer1);
  
    --Get JSON in XML
    buffer2 := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(buffer1);
    dbms_output.put_line('buffer2=' || buffer2);
    DBG('buffer2=' || buffer2);
  
    buffer2 := FN_CLOBREPLACE(buffer2, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || buffer2);
  
    buffer2 := FN_CLOBREPLACE(buffer2, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || buffer2);
  
    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || buffer2);
  
    P_DOCUMENT_XML := XMLTYPE(buffer2);
  
    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;
  
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;
  
    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);
  
    IF L_STATUS_CODE <> '000' THEN
    
      RETURN FALSE;
    
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PUSHING THE NOTIFICATION');
      DBG('ERROR CODE IN FN_PUSH_NOTIFICATION=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_PUSH_NOTIFICATION=' || SQLERRM);
      RETURN FALSE;
  END FN_PUSH_NOTIFICATION_BKP;

  FUNCTION FN_GET_TD_INIT_BAL(P_ACC IN VARCHAR2,
                              P_BRN IN VARCHAR2,
                              P_CCY IN VARCHAR2)
    RETURN P1FCHPRFM.ictm_td.TD_AMOUNT%TYPE AS
  
    L_ICTM_TD  P1FCHPRFM.ictm_td%ROWTYPE;
    L_INIT_BAL P1FCHPRFM.ictm_td.TD_AMOUNT%TYPE;
  
  BEGIN
  
    BEGIN
      SELECT *
        INTO L_ICTM_TD
        FROM P1FCHPRFM.ictm_td A
       WHERE A.ACC = P_ACC
         AND A.BRN = P_BRN
         AND A.CCY = P_CCY;
    EXCEPTION
      WHEN OTHERS THEN
        L_ICTM_TD := NULL;
        RETURN 0;
    END;
  
    L_INIT_BAL := L_ICTM_TD.TD_AMOUNT;
  
    RETURN L_INIT_BAL;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_INIT_BAL;
  END FN_GET_TD_INIT_BAL;

  FUNCTION FN_GET_TD_OPEN_DATE(P_ACC IN VARCHAR2,
                               P_BRN IN VARCHAR2,
                               P_CCY IN VARCHAR2)
    RETURN P1FCHPRFM.STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE AS
  
    L_STTM_CUST_ACCOUNT P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    L_AC_OPEN_DATE      P1FCHPRFM.STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
  
  BEGIN
  
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    L_AC_OPEN_DATE := L_STTM_CUST_ACCOUNT.AC_OPEN_DATE;
  
    RETURN L_AC_OPEN_DATE;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_AC_OPEN_DATE;
  END FN_GET_TD_OPEN_DATE;

  FUNCTION FN_GET_TENOR_IN_MONTHS(P_ACC IN VARCHAR2,
                                  P_BRN IN VARCHAR2,
                                  P_CCY IN VARCHAR2) RETURN NUMBER AS
  
    L_STTM_CUST_ACCOUNT    P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    rec_ictm_acc           P1FCHPRFM.ictm_acc%ROWTYPE;
    l_tenor_in_months      NUMBER := 0;
    L_ICTM_TD_DETAILS      P1FCHPRFM.ICTM_TD_DETAILS%ROWTYPE;
    L_CYTM_CCY_DEFN_MASTER P1FCHPRFM.CYTM_CCY_DEFN_MASTER%ROWTYPE;
  
  BEGIN
  
    --get branch
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    --get td information
    BEGIN
      SELECT *
        INTO rec_ictm_acc
        FROM P1FCHPRFM.ictm_acc A
       WHERE A.acc = P_ACC
         AND A.brn = L_STTM_CUST_ACCOUNT.BRANCH_CODE;
    
      /* SELECT ABS(rec_ictm_acc.int_start_date - rec_ictm_acc.maturity_date)
      INTO l_tenor_in_months
      FROM DUAL;*/
    
      l_tenor_in_months := ABS(MONTHS_BETWEEN(rec_ictm_acc.int_start_date,
                                              rec_ictm_acc.maturity_date));
    
    EXCEPTION
      WHEN OTHERS THEN
        l_tenor_in_months := 0;
    END;
  
    RETURN l_tenor_in_months;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_tenor_in_months;
    
  END FN_GET_TENOR_IN_MONTHS;

  FUNCTION FN_GET_TD_MIN_TOPUP_AMT(P_ACC IN VARCHAR2,
                                   P_BRN IN VARCHAR2,
                                   P_CCY IN VARCHAR2)
  
   RETURN P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE AS
  
    L_MIN_TOP_UP_AMT    ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;
    L_STTM_CUST_ACCOUNT P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    L_PLAN              VARCHAR2(25);
    L_TODAY_DATE        STTM_DATES.TODAY%TYPE;
  
  BEGIN
  
    --get branch
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    L_TODAY_DATE := FN_GET_BRANCH_DATE(P_BRN);
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('CLB1', 'CLB2') THEN
    
      L_PLAN := 'SHORT_TERM_PLAN';
    
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('CLB3', 'CLB4') THEN
    
      L_PLAN := 'LONG_TERM_PLAN';
    
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN
       ('CLB1', 'CLB2') THEN
    
      BEGIN
        SELECT B.CODE
          INTO L_MIN_TOP_UP_AMT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'CSB_TOPUP_USD_I'
           AND B.VALUE = L_PLAN;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN GETTING THE MIN TOP UP AMOUNT FOR THE ACCOUNT CLASS');
        
      END;
    
    ELSIF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN
          ('CLB3', 'CLB4') THEN
    
      BEGIN
        SELECT B.CODE
          INTO L_MIN_TOP_UP_AMT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'CSB_TOPUP_USD_F'
           AND B.VALUE = L_PLAN;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN GETTING THE MIN TOP UP AMOUNT FOR THE ACCOUNT CLASS');
        
      END;
    
    END IF;
  
    DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
        L_MIN_TOP_UP_AMT);
  
    IF P_CCY = 'USD' THEN
    
      L_MIN_TOP_UP_AMT := L_MIN_TOP_UP_AMT;
    
    ELSIF P_CCY = 'KHR' THEN
    
      L_MIN_TOP_UP_AMT := L_MIN_TOP_UP_AMT * 4000;
    
    END IF;
  
    RETURN L_MIN_TOP_UP_AMT;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_MIN_TOP_UP_AMT;
  END FN_GET_TD_MIN_TOPUP_AMT;

  FUNCTION FN_GET_MATURITY_DATE(P_ACC IN VARCHAR2,
                                P_BRN IN VARCHAR2,
                                P_CCY IN VARCHAR2)
    RETURN P1FCHPRFM.ictm_acc.MATURITY_DATE%TYPE AS
  
    L_STTM_CUST_ACCOUNT P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    rec_ictm_acc        P1FCHPRFM.ictm_acc%ROWTYPE;
    L_MATURITY_DATE     P1FCHPRFM.ictm_acc.MATURITY_DATE%TYPE;
  
  BEGIN
  
    --get branch
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    --get td information
    BEGIN
      SELECT *
        INTO rec_ictm_acc
        FROM P1FCHPRFM.ictm_acc A
       WHERE A.acc = P_ACC
         AND A.brn = L_STTM_CUST_ACCOUNT.BRANCH_CODE;
    
      L_MATURITY_DATE := rec_ictm_acc.maturity_date;
    
    EXCEPTION
      WHEN OTHERS THEN
        L_MATURITY_DATE := NULL;
    END;
  
    RETURN L_MATURITY_DATE;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_MATURITY_DATE;
    
  END FN_GET_MATURITY_DATE;

END IFPKS_CLEVER_SAVINGS_BUILDER_UTILS;
