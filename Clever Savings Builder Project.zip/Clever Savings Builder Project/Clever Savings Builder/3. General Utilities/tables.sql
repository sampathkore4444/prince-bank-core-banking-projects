-- Create table
create table IFTB_TD_TOPUP_SCHEDULES_CSB_SAV
(
  acc                 VARCHAR2(20) not null,
  brn                 VARCHAR2(3) not null,
  ccy                 VARCHAR2(3) not null,
  due_date            DATE,
  due_date_with_grace DATE,
  auto_topup_amt      NUMBER,
  principal_bal       NUMBER
)
/
-- Create/Recreate primary, unique and foreign key constraints 
alter table IFTB_TD_TOPUP_SCHEDULES_CSB_SAV
  add primary key (ACC, BRN, CCY)
  disable
  novalidate;
  
-- Create table
create table IFTB_CSB_SAV_PUSH_NOTIFICATION
(
  customer_no VARCHAR2(9) not null,
  cust_ac_no  VARCHAR2(20) not null,
  ccy         VARCHAR2(3) not null,
  branch_code VARCHAR2(3) not null,
  action_code VARCHAR2(100) not null,
  status      CHAR(1),
  timestamp   DATE
)
/
-- Create/Recreate primary, unique and foreign key constraints 
alter table IFTB_CSB_SAV_PUSH_NOTIFICATION
  add primary key (CUSTOMER_NO, CUST_AC_NO, CCY, BRANCH_CODE, ACTION_CODE)