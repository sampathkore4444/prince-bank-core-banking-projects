-- Create table
create table IFTB_AML_PARTICIPANT_INFO_1001
(
  trn_ref_no       VARCHAR2(16) primary key,
  same_as_acc_own  CHAR(1),
  participant_no   VARCHAR2(9),
  participant_name VARCHAR2(255),
  mobile_number    VARCHAR2(105),
  purpose_of_txn   VARCHAR2(255)
)
/
-- Create table
create table IFTB_AML_PARTICIPANT_INFO_1013
(
  trn_ref_no       VARCHAR2(16) primary key,
  same_as_acc_own  CHAR(1),
  participant_no   VARCHAR2(9),
  participant_name VARCHAR2(255),
  mobile_number    VARCHAR2(105),
  purpose_of_txn   VARCHAR2(255),
  uid_name         VARCHAR2(255),
  uid_value        VARCHAR2(255)
)
/
-- Create table
create table IFTB_AML_PARTICIPANT_INFO_1401
(
  trn_ref_no       VARCHAR2(16) primary key,
  same_as_acc_own  CHAR(1),
  participant_no   VARCHAR2(9),
  participant_name VARCHAR2(255),
  mobile_number    VARCHAR2(105),
  purpose_of_txn   VARCHAR2(255),
  source_of_funds  VARCHAR2(255)
)
/
-- Create table
create table IFTB_AML_PARTICIPANT_INFO_8004
(
  trn_ref_no       VARCHAR2(16) primary key,
  purpose_of_txn   VARCHAR2(255),
  source_of_funds  VARCHAR2(255),
  rel_customer     VARCHAR2(255),
  participant_name VARCHAR2(255),
  mobile_number    VARCHAR2(255)
)
/
-- Create table
create table IFTB_AML_PARTICIPANT_INFO_8203
(
  trn_ref_no       VARCHAR2(16) primary key,
  purpose_of_txn   VARCHAR2(255),
  source_of_funds  VARCHAR2(255),
  rel_customer     VARCHAR2(255),
  participant_name VARCHAR2(255),
  mobile_number    VARCHAR2(255)
)
/